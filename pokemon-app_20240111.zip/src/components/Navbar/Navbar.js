
import React from 'react'
import "./Navbar.css"

function Navbar() {
  return (
    <nav>ポケモン図鑑</nav>
  )
}

export default Navbar