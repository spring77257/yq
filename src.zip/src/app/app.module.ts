import { HttpClientModule } from '@angular/common/http';
import { ErrorHandler, Injector, NgModule } from '@angular/core';
import { Http, HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Camera } from '@ionic-native/camera';
import { UniqueDeviceID } from '@ionic-native/unique-device-id';
import { AdepModule } from 'adep/adep.module';
import { InjectionUtils } from 'adep/utils/injection.utils';
import { AppComponent } from 'app.component';
import { DeviceService } from 'dhd/common/services/device.service';

import { AutomaticTransferModule } from 'dhdt/branch/pages/automatic-transfer/automatic-transfer.module';
import { BankSavingsDepositModule } from 'dhdt/branch/pages/bank-savings-deposit/bank-savings-deposit.module';
import { CancelModule } from 'dhdt/branch/pages/cancel/cancel.module';
import { CashCardModule } from 'dhdt/branch/pages/cashcard/cashcard.module';
import { ChangeModule } from 'dhdt/branch/pages/change/change.module';
import { ClerkModule } from 'dhdt/branch/pages/clerk/clerk.module';
import { CreditCardModule } from 'dhdt/branch/pages/creditcard/creditcard.module';
import { ExistingReserveModule } from 'dhdt/branch/pages/existing-reserve/existing-reserve.module';
import { ExistingSavingsModule } from 'dhdt/branch/pages/existing-savings/existing-savings.module';
import { InheritModule } from 'dhdt/branch/pages/inherit/inherit.module';
import { LossReissueFindingModule } from 'dhdt/branch/pages/loss-reissue-finding/loss-reissue-finding.module';
import { MyNumberModule } from 'dhdt/branch/pages/mynumber/mynumber.module';
import { NewestModule } from 'dhdt/branch/pages/newest/newest.module';
import { PointDirectModule } from 'dhdt/branch/pages/point-direct/point-direct.module';
import { ReplacementModule } from 'dhdt/branch/pages/replacement/replacement.module';
import { StudentModule } from 'dhdt/branch/pages/student/student.module';
import { TerminateModule } from 'dhdt/branch/pages/terminate/terminate.module';
import { TimeDepositRewritingModule } from 'dhdt/branch/pages/time-deposit-rewriting/time-deposit-rewriting.module';
import { SystemErrorHandler } from 'dhdt/branch/shared/handler/system-error.handler';
import { CoreBankingModule } from 'dhdt/branch/shared/modules/core-banking/core-banking.module';
import { HttpService } from 'dhdt/branch/shared/services/http.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicApp, IonicModule } from 'ionic-angular';

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        AdepModule.forRoot(),
        BrowserModule,
        IonicModule.forRoot(AppComponent, {
            platforms: {
                ios: {
                    swipeBackEnabled: false
                },
            }
        }),
        BankSavingsDepositModule,
        CancelModule,
        SharedModule,
        BrowserAnimationsModule,
        HttpClientModule,
        HttpModule,
        ChangeModule,
        CashCardModule,
        CreditCardModule,
        CoreBankingModule,
        ExistingReserveModule,
        StudentModule,
        ExistingSavingsModule,
        InheritModule,
        PointDirectModule,
        AutomaticTransferModule,
        TimeDepositRewritingModule,
        LossReissueFindingModule,
        ReplacementModule,
        NewestModule,
        TerminateModule,
        ClerkModule,
        MyNumberModule,
    ],
    exports: [],
    bootstrap: [IonicApp],
    entryComponents: [AppComponent],
    providers: [
        Camera,
        // {
        //     provide: 'BASE_CONFIG', useValue: {
        //         url: 'https://imoocqa.gugujiankong.com/'
        //     }
        // }
        LoggingService,
        DeviceService,
        UniqueDeviceID,
        { provide: Http, useClass: HttpService },
        { provide: ErrorHandler, useClass: SystemErrorHandler }
    ]
})
export class AppModule {
    constructor(private injector: Injector) {
        InjectionUtils.injector = this.injector;
    }
}
