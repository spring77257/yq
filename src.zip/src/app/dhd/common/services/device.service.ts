import { Injectable } from '@angular/core';
import { UniqueDeviceID } from '@ionic-native/unique-device-id';
import { Platform } from 'ionic-angular';
import { BehaviorSubject } from 'rxjs';

declare let ipadnameswift: any;

@Injectable()
export class DeviceService {
    // ipadのdeviceIdとdevice名を取得完了しているかどうか
    public subject: BehaviorSubject<boolean> = new BehaviorSubject(false);

    private deviceId: string;
    private deviceName: string;

    constructor(private uniqueDeviceID: UniqueDeviceID, private platform: Platform) {
        this.deviceId = '';
        this.deviceName = '';
    }

    public init() {
        if (this.platform.is('cordova')) {
            // uuid取得済みのフラグ
            let uuidComplete: boolean = false;
            // ipadName取得済みのフラグ
            let ipadNameComplete: boolean = false;
            this.uniqueDeviceID.get()
                .then((uuid: any) => {
                    this.deviceId = this.getPlatformPrefix().concat(uuid);
                    // uuid取得済みフラグ
                    uuidComplete = true;
                    if (ipadNameComplete) {
                        // ipad名を取得済みの場合は、監視対象の発信。
                        this.subject.next(true);
                        // 監視停止
                        this.subject.complete();
                    }

                })
                .catch((error: any) => {
                    console.log(error);
                });
            ipadnameswift.getName(null,
                (name: string) => {
                    // ipadName取得済みフラグ
                    this.deviceName = name;
                    ipadNameComplete = true;
                    if (uuidComplete) {
                        // uuidを取得済みの場合は、監視対象の発信。
                        this.subject.next(true);
                        // 監視停止
                        this.subject.complete();
                    }
                });
        } else {
            this.deviceId = 'Browser';
            this.deviceName = 'Browser';
            this.subject.next(true);
        }
    }

    public getDeviceId(): string {
        return this.deviceId;
    }

    public getDeviceName(): string {
        return this.deviceName;
    }

    private getPlatformPrefix(): string {
        if (this.platform.is('ios')) {
            return 'io';
        } else if (this.platform.is('android')) {
            return 'ar';
        }
        return '';
    }
}
