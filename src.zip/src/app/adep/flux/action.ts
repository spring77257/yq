import 'reflect-metadata';
import { Dispatcher } from '../flux';
import { InjectionUtils } from '../utils/';

export abstract class Action {
    protected dispatcher;
    constructor() {
        this.dispatcher = InjectionUtils.injector.get(Dispatcher);
    }
}

export function ActionBind(actionType: string): any {
    return Reflect.metadata('actionBind', {
        actionType: actionType
    });
}
