export interface Payload {
    actionType: string;
    data: any;
}
