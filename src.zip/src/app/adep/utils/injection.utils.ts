import { Injector } from '@angular/core';

export class InjectionUtils {
    public static injector: Injector;
}
