import { NgModule, Type } from '@angular/core';
import { HttpModule } from '@angular/http';
import { CommonBusinessModule } from 'dhdt/branch/pages/common-business/common-business.module';
import { LoginModule } from 'dhdt/branch/pages/common/login/login.module';
import { TopModule } from 'dhdt/branch/pages/common/top/top.module';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatComponent } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat.component';
import {
    ExistingSavingsConfirmPageChatComponent
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-confirmpage-chat.component';
import { ExistingSavingsStore } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import {
    ExistingSavingsChangeConfirmComponent
} from 'dhdt/branch/pages/existing-savings/view/existing-savings-change-confirm.component';
import { ExistingSavingsConfirmComponent } from 'dhdt/branch/pages/existing-savings/view/existing-savings-confirm.component';
import {
    ExistingSavingsContentConfirmComponent
} from 'dhdt/branch/pages/existing-savings/view/existing-savings-content-confirm.component';
import { ExistingSavingsInitConfirmComponent } from 'dhdt/branch/pages/existing-savings/view/existing-savings-initconfirm.component';
import { AddressModule } from 'dhdt/branch/shared/components/address/address.module';
import { BranchModule } from 'dhdt/branch/shared/components/branch/branch.module';
import { ConfirmPageCommonModule } from 'dhdt/branch/shared/components/confirmpage-common/confirmpage.common.module';
import { PickerModule } from 'dhdt/branch/shared/components/picker/picker.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';

export const SHARED_FORM_COMPONENT: Array<Type<any>> = [
    ExistingSavingsConfirmPageChatComponent,
    ExistingSavingsChatComponent,
    ExistingSavingsContentConfirmComponent,
    ExistingSavingsInitConfirmComponent,
    ExistingSavingsChangeConfirmComponent,
    ExistingSavingsConfirmComponent,
];

@NgModule({
    imports: [
        LoginModule,
        TopModule,
        IonicModule,
        SharedModule,
        AddressModule,
        BranchModule,
        HttpModule,
        PickerModule,
        ConfirmPageCommonModule,
        CommonBusinessModule
    ],
    declarations: [
        SHARED_FORM_COMPONENT
    ],
    exports: [
        SHARED_FORM_COMPONENT,
        TopModule
    ],
    entryComponents: [
        SHARED_FORM_COMPONENT
    ],
    providers: [
        ExistingSavingsAction,
        ExistingSavingsStore
    ]
})
export class ExistingSavingsModule {
}
