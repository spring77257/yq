import { AppProperties } from 'app.properties';

/**
 * DBに格納する指定文言
 */
export class DBConsts {
    public static readonly deviceId = '111';

    public static readonly applyBusinessType = '01'; // 申込業務区分
    public static readonly insertStatus = '00'; // ステータス

    public static SpecTransactionCode = {
        maruyu: '01', // マル優
        marutoku: '02', // マル特
        maruzai: '03', // マル財取引
        eduFinacialAdmin: '04', // 教育資金管理契約あり
        bussinessLoan: '05', // 事業性融資先
        currentAccount: '10', // 当座預金先
        houseLoan: '06', // 住宅ローン
        other: '07', // その他
        Investment: '08', // 投信有
        specialDeposit: '09', // 特定口座あり
        electronicBond: '11', // 電債取引ある
        bondCustomers: '12', // 債券顧客保有先
        goldBullion: '29', // 金保護預かり利用先
        safeDepositBox: '31', // 貸金庫契約先
        loanCreditOwned: '39' // 融資債権保有先
    };
}

export class FileSrcConsts {
    // 自動継続方法の説明画像
    public static readonly AUTOMIC_RENEWAL_IMAGE_SRC = AppProperties.IMG_ROOT + 'information/img_information_automatic_continuation@3x.png';
}

export const Consts = {
    // 顧客申込完了時間
    CUSTOMER_APPLY_ENDDATE: 'customerApplyEndDate',
    // 行員確認スタート時間
    BANKCLERK_AUTHENTICATION_START_DATE: 'bankclerkAuthenticationStartDate',
    // 選択された商品の名前
    SELECT_PRODUCT_NAME: 'selectProductName',

    HOLDER_ZIP_CODE: 'holderZipCode'
};

export class CdHoldingStatus {
    // CD保有
    public static readonly HOLDING = '1';
    // CD保有なし
    public static readonly NOT_HOLDING = '0';
}

export class BcHoldingStatus {
    // CD保有
    public static readonly HOLDING = '1';
    // CD保有なし
    public static readonly NOT_HOLDING = '0';
}

export class JudgeResultStatus {
    public static readonly RESULT_1 = '1';
    public static readonly RESULT_2 = '2';
    public static readonly RESULT_0 = '0';
    public static readonly RESULT_01 = '01';
    public static readonly RESULT_02 = '02';
    public static readonly RESULT_03 = '03';

    // 離脱
    public static readonly SECESSION = 'secession';
    // 離脱しない
    public static readonly NOT_SECESSION = 'notSecession';

    // 持っている
    public static readonly HAVE = 'have';
    // 持っていない
    public static readonly NOT_HAVE = 'notHave';
}

export class RenderType {
    public static readonly ITEM_LIST = 'itemList';
}

// 業務コード
export class BussinessCode {
    // 普通預金口座開設
    public static readonly OPEN_ACCOUNT = '01';
    // スワイプ有.普通預金口座開設
    public static readonly EXISTING_SAVINGS = '09';
    // 届出事項変更（氏名変更メニュー選択時）
    public static readonly NAME_MENU_CHANGE = '19';
    // 届出事項変更（住所変更・電話番号変更メニュー選択時）
    public static readonly CHANGE = '05';
    // 諸届事項（氏名）の変更（名寄せ時）
    public static readonly NAME_CHANGE = '10';
    // 諸届事項（電話番号or住所・氏名）の変更（名寄せ時）
    public static readonly ADDRESS_TEL_NAME_CHANGE = '11';
    // 諸届事項（電話番号or住所）の変更（名寄せ時）
    public static readonly ADDRESS_TEL_CHANGE = '09';
    // 届出事項変更（氏名変更を含まない住所変更・電話番号変更メニュー選択時）
    public static readonly ADDRESS_TEL_MENU_CHANGE = '24';
    // カード差替
    public static readonly REPLACEMENT = '20';
    // カード新規発行
    public static readonly NEWEST = '21';

}

// BC表示
export class BcStatus {
    // BC保有あり
    public static readonly BC_STATUS_ON = '1';
    // BC保有なし
    public static readonly BC_STATUS_OFF = '0';
}

// 複数BC表示
export class DoubleBcStatus {
    // 複数BC保有あり
    public static readonly DOUBLE_BC_STATUS_ON = '1';
    // 複数BC保有なし
    public static readonly DOUBLE_BC_STATUS_OFF = '0';
}

// 複数ワンセット表示
export class DoubleOsStatus {
    // 複数ワンセットカード保有あり
    public static readonly DOUBLE_OS_STATUS_ON = '1';
    // 複数ワンセットカード保有なし
    public static readonly DOUBLE_OS_STATUS_OFF = '0';
}

// カード使用中
export class CardInUse {
    // カード使用中
    public static readonly CARD_IN_USE = 'カード使用中';
}

// MC表示
export class McStatus {
    // MC保有あり
    public static readonly MC_STATUS_ON = '1';
    // MC保有なし
    public static readonly MC_STATUS_OFF = '0';
}

// IC表示
export class IcStatus {
    // IC保有あり
    public static readonly IC_STATUS_ON = '1';
    // IC保有なし
    public static readonly IC_STATUS_OFF = '0';
}

// ワンセット表示
export class OsStatus {
    // ワンセットカード保有あり
    public static readonly OS_STATUS_ON = '1';
    // ワンセットカード保有なし
    public static readonly OS_STATUS_OFF = '0';
}

export class DeliveryStatus {
    // 変更なし
    public static readonly NON_DELIVERY = '1';
    // 変更する
    public static readonly ARRIVED = '0';
}

export class IdentificationDocument {
    // 各種健康保険証
    public static readonly INSURANCE = '02';
    // パスポート（所持人記入欄なし）
    public static readonly PWD_NO_ENTRY_FIELD_OWNER = '26';
}

export enum UnacceptableCode {
    // エラーモーダルの1行に表示する注意コード最大数
    UNACCEPTABLE_CODE_MAX = 3,
}

export enum isMobileNo {
    // 携帯電話を持っている
    hasMobileNo = '1'
}

export enum Length {
    // 同一名義人照会レスポンス最大数
    DUPLICATE_ACCOUNT_MAX = 10
}
