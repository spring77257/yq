import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { COMMON_CONSTANTS, CountryCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { JudgeResultStatus } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import { ExistingSavingsSignal,
    ExistingSavingsState, ExistingSavingsStore } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { SelectAddressCommonComponent } from 'dhdt/branch/shared/components/address/view/select-address-common.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';

/**
 * 諸届変更修正チャット
 */
export class ExistingSavingsChangeModifyRenderer extends ExistingSavingsChatFlowRenderer {

    public processType = 1;

    private loginStore: LoginStore;
    private state: ExistingSavingsState;
    private modalService: ModalService;
    private serverInfoService: ServerInfoService;
    private phoneIsSkiped: boolean = false;
    private telIsSkiped: boolean = false;

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: ExistingSavingsStore,
        private audioService: AudioService,
        private action: ExistingSavingsAction
    ) {
        super();
        this.state = this.store.getState();
        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.modalService = InjectionUtils.injector.get(ModalService);
        this.serverInfoService = InjectionUtils.injector.get(ServerInfoService);
    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(COMMON_CONSTANTS.YML_CHAT_FLOW_EXISTING_SAVINGS_CHANGE_NAME, pageIndex);
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'prefecturePicker':
            case 'countyUrbanVillagePicker': {
                this.onPicker(question, pageIndex);
                break;
            }
            case 'selectAddress': {
                this.onSelectAddress(question, pageIndex);
                break;
            }
            case 'selectStreet': {
                this.onSelectStreet(question, pageIndex);
                break;
            }
            case 'password4bits': {
                this.onPasswordInput(question, pageIndex);
                break;
            }
        }
    }

    public onKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {

        const choices = entity.choices;
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getExistingSavingChangeDefaultValues(entity.name, this.state.submitData),
            title: entity.options ? entity.options.title : undefined,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            fullwidthHalfwidthDivisionCode: entity.fullwidthHalfwidthDivisionCode
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        if (entity.fullwidthHalfwidthDivisionCode) {
                            this.store.registerSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK, (data) => {
                                this.store.unregisterSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK);
                                this.getNextChat(entity.next, pageIndex);
                            });
                            const params = {
                                tabletApplyId: this._store.getState().tabletApplyId,
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                                    checkStrings: [{
                                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                        checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                    }],
                                }
                            };
                            this._action.characteCheck(params, () => {
                                this._action.editChart(entity.order, pageIndex,
                                    this.state.showChats[this.state.showChats.length - 1].answer.order);
                                this.getNextChat(entity.order, pageIndex);
                            });
                        } else if (entity.name === 'existingChangeHolderNameAlphabet') {
                            // 英字氏名を大文字に固定する
                            answer.text = answer.text.toUpperCase();
                            answer.value[0].value = answer.value[0].value.toUpperCase();
                            answer.value[1].value = answer.value[1].value.toUpperCase();
                            const needSpace = InputUtils.needAddSpace(answer.value[0].key);
                            if (needSpace) { // 全角スペース必要かを判断する
                                const text = answer.value[0].value + COMMON_CONSTANTS.FULL_SPACE + answer.value[1].value;
                                this.setAnswer({
                                    text: text,
                                    value: [...results, { key: entity.name, value: text }]
                                });
                            } else {
                                this.setAnswer({
                                    text: answer.text,
                                    value: [...results, { key: entity.name, value: answer.text }]
                                });
                            }
                            this.getNextChat(entity.next, pageIndex);
                        } else {
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });
                }
            });
    }

    public onSelectAddress(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectAddressCommonComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            this.getNextChat(answer.value ? entity.next : entity.skip, pageIndex);
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                if (!answer.action ||
                    (answer.action.value !== 'noticeButtonModal' &&
                    answer.action.type !== COMMON_CONSTANTS.ACTION_TYPE_MODAL)) {
                        this.setAnswer({
                            text: answer.text,
                            value: [
                                { key: entity.name, value: answer.value },
                                { key: answer.name, value: answer.value }
                            ]
                        });
                }
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onSelectStreet(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const params = {
            prefectureKanji: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillageKanji: this.state.submitData.holderAddressCountyUrbanVillage
        };
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(params, SelectStreetComponent, this.footerContent, options)
            .subscribe((result: { isSkip: boolean, text: string, value: any }) => {
                this.chatFlowAccessor.clearComponent();
                if (result.value) {
                    const answer = {
                        text: result.text,
                        value: [
                            { key: 'holderAddressStreetNameSelect', value: (
                                result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'holderAddressStreetNameFuriKanaSelect', value: (
                                result.isSkip ? undefined : result.value.streetKana) },
                            { key: 'streetWork', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'showStreet', value: (result.isSkip ? undefined : result.value.streetKanji) }
                        ]
                    };
                    this.setAnswer(answer);
                    this.getNextChat(result.isSkip ? entity.skip : entity.next, pageIndex);
                } else {
                    this._action.resetLastNode({ order: entity.next, pageIndex: pageIndex });
                }
            });
    }

    public onPicker(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }

        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData,
            value: undefined
        };

        switch (entity.name) {
            case 'holderAddressPrefecture':
                options.value = this.loginStore.getState().prefectureKanji;
                break;
            case 'olderAddressCountyUrbanVillage':
                options.value = this.loginStore.getState().countyUrbanVillageKanji;
                break;
        }

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onNumberKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === 'skip') {
                    if (entity.name === 'existingChangeHolderMobileNo') {
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'existingChangeHolderMobileNo',
                                value: ''
                            }
                        ]);
                    }
                    if (entity.name === 'existingChangeHolderTelephoneNo') {
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'existingChangeHolderTelephoneNo',
                                value: ''
                            }
                        ]);
                    }
                    this.setAnswer({ text: 'スキップ', value: [] });
                } else {
                    if (entity.name === 'existingChangeHolderMobileNo') {
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'existingChangeHolderMobileNo',
                                value: answer.text
                            }
                        ]);
                    }
                    if (entity.name === 'existingChangeHolderTelephoneNo') {
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'existingChangeHolderTelephoneNo',
                                value: answer.text
                            }
                        ]);
                    }
                    this.setAnswer(answer);
                }

                const isShowModal = this.telSkip(entity.name, answer === 'skip');
                if (!isShowModal) {
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        if (entity.option === 'url') {

            let params;
            switch (entity.name) {
                case 'getAddressFromZipcode': {
                    const zipCode = this.state.submitData.firstZipCode + this.state.submitData.lastZipCode + '';
                    params = { zipCode: zipCode };
                    break;
                }
                case 'getStreetInitialsKana': {
                    params = {
                        prefectureKanji: this.state.submitData.holderAddressPrefecture,
                        countyUrbanVillageKanji: this.state.submitData.holderAddressCountyUrbanVillage,
                    };
                    break;
                }
            }

            this.serverInfoService.getInfoFormServe(entity.name, params).subscribe((result) => {
                entity.choices.forEach((choice) => {
                    if (result === choice.value) {
                        if (choice.value === '1') {
                            this.action.setStateSubmitDataValue([
                                {
                                    key: 'resetZipCodeFlg',
                                    value: true
                                }
                            ]);
                        }
                        this.getNextChat(choice.next, pageIndex);
                        return;
                    }
                });
            });
        } else if (entity.choices) {
            let judgeResult: string;
            switch (entity.name) {
                // 国籍判定(日本人 or 日本人以外)
                case 'nationalityCode': {
                    judgeResult = this.state.submitData.nationalityCode === CountryCode.Japan ?
                        JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
            }
            entity.choices.forEach((choice) => {
                if (judgeResult === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    public onPasswordInput(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            birthday: this.state.submitData.birthdate,
            birthdayText: this.state.submitData.birthdateWithAge,
            telephone: [
                this.state.submitData.holderTelNo1,
                this.state.submitData.holderTelNo2,
                this.state.submitData.holderTelNo3,
                this.state.submitData.existingChangeHolderMobileNo,
                this.state.submitData.existingChangeHolderTelephoneNo
            ],
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PasswordInputComponent,
            this.footerContent, options).subscribe((answer) => {
                if (answer === 'skip') {
                    this.chatFlowAccessor.clearComponent();
                    this.setAnswer({ text: 'スキップ', value: [] });
                } else {
                    this.chatFlowAccessor.clearComponent();
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }

    private telSkip(name: string, isSkip: boolean): boolean {
        if (name === 'existingChangeHolderMobileNo') {
            this.phoneIsSkiped = isSkip;
        }
        if (name === 'existingChangeHolderTelephoneNo') {
            this.telIsSkiped = isSkip;
        }
        if (name === 'existingChangeHolderTelephoneNo' && this.phoneIsSkiped === true && this.telIsSkiped === true) {
            const buttonList = [
                { text: 'OK', buttonValue: 'ok' },
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.warnTelTitle,
                buttonList,
                () => {
                    this.action.needInputPhoenNo();
                }
            );
            return true;
        }
        return false;
    }
}
