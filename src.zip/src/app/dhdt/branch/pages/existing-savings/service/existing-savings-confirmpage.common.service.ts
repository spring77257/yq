import { Injectable, Injector } from '@angular/core';
import { LabelService } from 'adep/services';
import { ConfirmPageComponentParamName } from 'dhdt/branch/pages/bank-savings-deposit/service/confirmpage.common.service';
import { ChangeConfirmComponentParamName } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';

export enum ExistingSavingsConfirmType {
    CARD_DESIGN = 'ExistingSavings_CARD_DESIGN',
    POINT_SERVICE_EXPECTATION = 'ExistingSavings_POINT_SERVICE_EXPECTATION',
    DIRECT_APPLY_EXPECTATION = 'ExistingSavings_DIRECT_APPLY_EXPECTATION',
    FIRST_PWD_6_BITS = 'ExistingSavings_FIRST_PWD_6_BITS',
}

export namespace ExistingSavingsComponentParamName {
    export const BASICINFO_HOLERNAME: string = 'BASICINFO_HOLERNAME';   // お名前
    export const BASICINFO_HOLDERADDRESS: string = 'BASICINFO_HOLDERADDRESS';   // ご住所
    export const BASICINFO_HOLDERMOBILENO: string = 'BASICINFO_HOLDERMOBILENO';   // 携帯電話番号
    export const BASICINFO_CARDDESIGN: string = 'BASICINFO_CARDDESIGN';    // キャッシュカードデザイン
    export const PASSWORD_CARDPASSWORD: string = 'PASSWORD_CARDPASSWORD';   // キャッシュカード暗証番号
    export const PRINT_SEAL_SLIP: string = 'PRINT_SEAL_SLIP';    // 印鑑変更
    export const BASICINFO_HOLERNAME_KANJI: string = 'BASICINFO_HOLERNAME_KANJI';   // お名前漢字
    export const BASICINFO_CONFIRM_DOCUMENT: string = 'BASICINFO_CONFIRM_DOCUMENT';   // 本人確認書類
    export const HOLDER_CAREER = 'ChangeConfirmComponentParamName_HOLDER_CAREER';    // 職業
    export const ORDINARY_DEPOSIT_ACCOUNT_PASSWORD = 'ORDINARY_DEPOSIT_ACCOUNT_PASSWORD'; //    ワンセットカード普通預金口座暗証番号
    export const SAVINGS_DEPOSIT_ACCOUNT_PASSWORD = 'SAVINGS_DEPOSIT_ACCOUNT_PASSWORD'; //    ワンセットカード貯蓄預金口座暗証番号
    export const CHANGE_CONFIRM_DOCUMENT: string = 'CHANGE_CONFIRM_DOCUMENT';   // 届出変更本人確認書類
    export const BASICINFO_ADD_CHECK: string = 'BASICINFO_ADD_CHECK';   // 追加確認
}

@Injectable()
export class ExistingSavingsConfirmPageCommonService {
    private params: Map<string, any>;
    private action: ExistingSavingsAction;
    private pageIndex: number = 99;
    private pageIndexChangeDiff: number = 98;
    private pageIndexChange: number = 97;
    private pageIndexAddCheck: number = 96;
    private pageIndexName: number = 95;
    private pageIndexAddress: number = 94;
    private pageIndexTel: number = 93;
    private labels: any;

    constructor(private injector: Injector) {
        this.action = injector.get(ExistingSavingsAction);
        this.params = new Map();
        this.labels = injector.get(LabelService).labels;
    }

    public loadConfirmTemplate() {
        this.action.loadConfirmPageTemplate('chat-flow-def-existing-savings-change-document-confirm.yml', this.pageIndexChange);
        this.action.loadConfirmPageTemplate('chat-flow-def-existing-savings-confirmpage.yml', this.pageIndex);
        this.action.loadConfirmPageTemplate('chat-flow-def-existing-savings-change-add-check-confirmation.yml', this.pageIndexAddCheck);
        this.action.loadConfirmPageTemplate('chat-flow-def-existing-savings-change-differencial-confirmation.yml',
            this.pageIndexChangeDiff);
        this.action.loadConfirmPageTemplate('chat-flow-def-confirm-page-common-confirmpage.yml', this.pageIndexTel);
    }

    public getShowChatParams() {
        const params: Map<string, any> = new Map();
        // ご職業
        params.set(ConfirmPageComponentParamName.HOLDER_CAREER,
            {
                startOrder: 1, endOrder: 2, name: 'holderCareer',
                currentTitle: this.labels.confirm.customerInfo.career, pageIndex: this.pageIndex
            });
        // お勤め先名称
        params.set(ConfirmPageComponentParamName.HOLDER_WORK_PLACE,
            {
                startOrder: 1, endOrder: 2, name: 'holderWorkPlace',
                currentTitle: this.labels.confirm.customerInfo.workPlace, pageIndex: this.pageIndex
            });
        // 口座開設目的
        params.set(ConfirmPageComponentParamName.ACCOUNT_OPENING_PURPOSE,
            {
                startOrder: 4, endOrder: 4, name: 'accountOpeningPurpose',
                currentTitle: this.labels.confirm.accountInfo.accountPurpose, pageIndex: this.pageIndex
            });
        // キャッシュカード暗証番号
        params.set(ConfirmPageComponentParamName.FIRST_PWD_4_BITS,
            {
                startOrder: 5, endOrder: 5, name: 'firstPwd4bits',
                currentTitle: this.labels.confirm.applyInfo.cardPassword, pageIndex: this.pageIndex
            });

        // 電子サイン
        params.set(ConfirmPageComponentParamName.SIGN,
            {
                startOrder: 6, endOrder: 6, name: 'sign',
                currentTitle: this.labels.confirm.sign.table.title2, pageIndex: this.pageIndex
            });
        // 住所
        params.set(ConfirmPageComponentParamName.OTHER_COUNTRY,
            {
                startOrder: 7, endOrder: 7, name: 'otherCountry',
                currentTitle: this.labels.confirm.sign.table.title4, pageIndex: this.pageIndex
            });
        // お名前の変更
        params.set(ExistingSavingsComponentParamName.BASICINFO_HOLERNAME,
            {
                startOrder: 10, endOrder: 499, name: 'existingChangeHolderName',
                currentTitle: this.labels.change.basic.changeName, pageIndex: this.pageIndexName
            });
        // ご住所の変更
        params.set(ExistingSavingsComponentParamName.BASICINFO_HOLDERADDRESS,
            {
                startOrder: 2, endOrder: 499, name: 'existingChangeHolderAddress',
                currentTitle: this.labels.change.basic.changeAddress, pageIndex: this.pageIndexAddress
            });
        // 携帯電話番号の変更
        params.set(ExistingSavingsComponentParamName.BASICINFO_HOLDERMOBILENO,
            {
                startOrder: 30, endOrder: 170, name: 'existingChangeHolderMobileNo',
                currentTitle: this.labels.change.basic.changeMobile, pageIndex: this.pageIndexTel
            });
        // SMS受信有無の変更
        params.set(ChangeConfirmComponentParamName.BASICINFO_ISSMSPHONE,
            {
                startOrder: 3190, endOrder: 3240, name: 'isSmsPhone',
                currentTitle: this.labels.change.basic.changeMobile, pageIndex: this.pageIndexTel
            });
        // ワンセットカード普通預金口座暗証番号
        params.set(ExistingSavingsComponentParamName.ORDINARY_DEPOSIT_ACCOUNT_PASSWORD,
            {
                startOrder: 480, endOrder: 1000, name: 'savingAccountPassword',
                currentTitle: this.labels.change.oneSetCard.title, pageIndex: this.pageIndexChangeDiff
            });
        // ワンセットカード貯蓄預金口座暗証番号
        params.set(ExistingSavingsComponentParamName.SAVINGS_DEPOSIT_ACCOUNT_PASSWORD,
            {
                startOrder: 500, endOrder: 1000, name: 'savingsDepositAccountPassword',
                currentTitle: this.labels.change.oneSetCard.title, pageIndex: this.pageIndexChangeDiff
            });
        // 届出変更本人確認書類
        params.set(ExistingSavingsComponentParamName.CHANGE_CONFIRM_DOCUMENT,
            {
                startOrder: 1, endOrder: 230, name: 'changeDocumentImages',
                currentTitle: this.labels.change.selfConfirm.title, pageIndex: this.pageIndexChange
            });
        // 追加確認
        params.set(ExistingSavingsComponentParamName.BASICINFO_ADD_CHECK,
            {
                startOrder: 0, endOrder: 30, name: 'addCheckConfirmation',
                currentTitle: this.labels.change.modifyChat.headerTitle2, pageIndex: this.pageIndexAddCheck
            });
        // 支店名修正
        params.set(ConfirmPageComponentParamName.OPENSTORE_SHOWCHART,
            {
                startOrder: 350, endOrder: 1230, name: 'branchNameKanji',
                currentTitle: '支店名', pageIndex: this.pageIndex
            });

        // 他店舗での口座開設理由修正
        params.set(ConfirmPageComponentParamName.OTHERSTORE_RESEAON,
            {
                startOrder: 355, endOrder: 356, name: 'savingBranchReason',
                currentTitle: '他店舗での口座開設理由', pageIndex: this.pageIndex
            });
        return params;
    }
}
