import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import {
    AcceptionResult, AcceptionResultAccount
} from 'dhdt/branch/shared/components/change-flow/entity/change.entity';

export class ExistingSavingsQuestionsModel {
    public order: number;
    public next: number;
    public type: string;
    public question: string;
    public example: string;
    public choices: any[];
    public name: string;
    public options: any;
    public validationRules: any;
    public skip: number;
    public fullwidthHalfwidthDivisionCode: any;
    public option: any;
}

export class PageQuestionsModel {
    public order: number;
    public next: number;
    public type: string;
    public example: string;
    public choices: any[];
    public validationRules: any;
    public question: string;
    public name: string;
    public answer: { order: number, text: string, value: any };
    public pageIndex: number;
    public skip: number;
    public orderIndex: number;
    public payload?: any;
    public options?: any;
}

export class AllCiftradingConditions {
    public tradingConditons: TradingConditionCode[];
}

export class TradingConditionCode {
    public tradingConditionCode: string;
}

export class ExistingSavingsSubmitEntity {
    [key: string]: any;

    public hasLicense: string;
    public hasConfirmFile: string;
    public holderName: string;
    public holderNameFurigana: string;
    public firstName: string;
    public lastName: string;
    public holderGender: string;

    public birthdate: string;
    public birthdateWithAge: string;
    public holderTelNo1: string;
    public holderTelNo2: string;
    public holderTelNo3: string;

    // 本人確認種類
    public identificationCode: string;
    public isSsnWrite: string;
    public isSsnHave: string;

    public firstNameKana: string;
    public lastNameKana: string;

    public holderBirthdate: string;
    public holderBirthdateOCR: string;
    public holderBirthdateText: string;

    public firstZipCode: string;
    public lastZipCode: string;
    public holderZipCode: string;

    public holderAddressPrefecture: string;
    public holderAddressPrefectureFurigana: string;
    public holderAddressCountyUrbanVillage: string;
    public holderAddressCountyUrbanVillageFurigana: string;
    public holderIdentityDocumentAddressReason: string;
    public holderIdentityDocumentPhotographType: string;
    public holderIdentityDocumentAddressType: string;
    public holderIdentityDocumentNoCopyReason: string;
    public holderIdentityDocumentType: string;
    public holderNoCopyReason: string;
    public holderPublisher: string;
    public holderPublishDate: string;
    public holderSignNo: string;
    public holderCardImageFront: string;
    public holderCardImageBack: string;
    public branchNo: string;
    public branchNameKanji: string;
    public bakupNotMaskingConfirmImages: any; // BC複合用マスキング未完了オブジェクトバックアップ

    public holderAddressStreetNameSelect: string;
    public holderAddressStreetNameInput: string;
    public holderAddressStreet: string;
    public holderAddressStreetNameFuriganaSelect: string;

    public holderAddressHouseNumber: string;
    public holderAddressHouseNumberFurigana: string;
    public firstMobileNo: string;
    public secondMobileNo: string;
    public thirdMobileNo: string;
    public mobileNo: string; // 携帯電話番号
    public firstTel: string;
    public secondTel: string;
    public thirdTel: string;
    public telephoneNo: string; // ご自宅電話番号
    public holderCareer: string;
    public holderCareerOtherDetail: string;
    public holderWorkPlace: string;
    public holderRemoteAddressReason: string;
    public accountType: string;
    public accountTypeText: string;
    public cardDesign: string;
    public cardDesignImageSrc: string;
    public pointServiceExpectation: string;
    public showPointServiceApply: boolean = true;
    public directApplyExpectation: string;
    public showDirectApply: boolean = true;
    public cardPassword: string;
    public confirmPassword: string;
    public receiptMethod: string;
    public holderIdentityDocumentPublisher: string;
    public holderIdentityDocumentPublishDate: string;
    public holderIdentityDocumentSignNo: string;
    public passbookType: string;
    public firstPwd4bits: string;
    public firstPwd6bits: string;
    public cashCardFirstPwd4bits: string; // BCキャッシュカード暗証番号
    public passbookPrintMessage: string;
    public accountOpeningPurposeLivingExpenses: string;
    public accountOpeningPurposeBusinessExpenses: string;
    public accountOpeningPurposeSalary: string;
    public accountOpeningPurposeSavings: string;
    public accountOpeningPurposeLoan: string;
    public accountOpeningPurposeOverseasRemittance: string;
    public accountOpeningPurposeTrade: string;
    public accountOpeningPurposeOther: string;
    public accountOpeningPurposeOtherDetail: string;
    public agencyBranchNo: string;
    public accountOpeningBranchNo: string;
    public insertedImagesIds: string[];
    public applyBusinessType: string; // 相談要、申し込み業務区分

    public leaveType: string;
    public bankCardFlag: string;
    public bankCardGoldFlag: string;
    public bankCardSuicaFlag: string;

    public info: any;               // 口座情報

    // ご指定口座（普通預金）－口座番号
    public accountNo;

    public rqNo: string;
    public customerApplyEndDate: string;
    public bankclerkAuthenticationStartDate: string;
    public bankclerkAuthenticationEndDate: string;

    public tabletApplyId: string;
    public userMngNo: string;

    public identityDocuments: string[];
    public additionalInfoDocuments: string[];

    // QRコード受付情報
    public swipeCif: string;        // スワイプ店CIF
    public swipeBranchNo: string;
    public swipeAccountNo: string;
    public swipeAccountType: string;

    public receptionBranchNo: string;        // 受付店番
    public receptionNo: string;        // 受付番号
    public receptionTime: string;        // 受付年月日時分秒
    public regionCode?: string;

    public fileInfo?: any;

    public hasComprehensive: boolean;   // 総合口座を持っているフラグ
    public nameNonConvert: string;
    public editNameKanji: string;

    public redundantReason: string;     // 重複口座の開設理由
    public holderMobileNo: string;
    public holderTelephoneNo: string;
    public nameKanji: string;
    public nameKana: string;
    public cardInfo: any;
    public agentCountryText: string;

    public socialSecurityNumber: string;
    public number1: string;
    public number2: string;
    public number3: string;
    public sign: any;
    public signFatca: any;
    public bcHoldingStatusAllCustomer: AcceptionResult[];

    /** 全店名寄せ照会.顧客情報 */
    public allCifInfos: CifInfo[];
     /** スワイプなし時に手入力された口座情報 */
    public inputAccountInfo: {
         /** 店番号 */
         branchNo: string;
         /** 科目 */
         accountType: string;
         /** 口座番号 */
         accountNo: string;
    };

    // スワイプCIFの受付可否チェック結果
    public swipeCifAcceptCheckResult: {customerId: string, account: AcceptionResultAccount};
    // 氏名に差分があるCIFの受付可否チェック結果
    public nameidentiNameDifCifAcceptCheckResult: Array<{customerId: string, accounts: AcceptionResultAccount}>;
    // 住所に差分があるCIFの受付可否チェック結果
    public nameidentiAddressDifCifAcceptCheckRestlt: Array<{customerId: string, accounts: AcceptionResultAccount}>;
    // 電話番号に差分があるCIFの受付可否チェックの結果
    public nameidentiTelDifCifAcceptCheckResult: Array<{customerId: string, accounts: AcceptionResultAccount}>;

    // 届出事項変更
    public savingAccountFirstPwd4bits: string;    // 普通預金のICキャッシュカードの暗証番号(4桁)
    public savingsDepositAccountFirstPwd4bits: string;    // 貯蓄預金のICキャッシュカードの暗証番号(4桁)

    public existingChangeHolderMobileNo: string;    // 変更　携帯電話
    public existingChangeFirstMobileNo: string;
    public existingChangeSecondMobileNo: string;
    public existingChangeThirdMobileNo: string;

    public existingChangeHolderTelephoneNo: string;    // 変更　自宅電話
    public existingChangeFirstTel: string;
    public existingChangeSecondTel: string;
    public existingChangeThirdTel: string;

    public existingChangeHolderName: string;    // 変更　氏名
    public existingChangeFirstName: string;
    public existingChangeLastName: string;
    public existingChangeHolderNameFurigana: string;    // 変更　かな氏名
    public existingChangeFirstNameKana: string;
    public existingChangeLastNameKana: string;
    public existingChangeHolderNameAlphabet: string;    // 変更　英字氏名
    public existingChangeFirstNameAlphabet: string;
    public existingChangeLastNameAlphabet: string;
    public existingChangePrintSealSlipFlag: string;    // 印鑑変更

    public holderAddressHouseNumberFuriKanaForShow: string;
    public holderAddressStreetNameFuriKanaInput: string;
    public holderAddressStreetNameFuriKanaSelect: string;

    // PID配下すべてのCIFの取引ぶり
    public allCifTradingConditions: AllCiftradingConditions;

    /**
     * 本人氏名を取得
     */
    public getHolderName(): string {
        if (!this.firstName || !this.lastName) {
            return this.holderName;
        }
        return this.firstName + COMMON_CONSTANTS.FULL_SPACE + this.lastName;
    }

    /**
     * 携帯番号を取得する
     */
    public getHolderMobileNo(): string {
        if (!this.firstMobileNo || !this.secondMobileNo || !this.thirdMobileNo) {
            return '';
        }
        return this.firstMobileNo + this.secondMobileNo + this.thirdMobileNo;
    }

    /**
     * ご自宅電話番号を取得する
     */
    public getHolderTelephoneNo(): string {
        if (!this.firstTel || !this.secondTel || !this.thirdTel) {
            return '';
        }
        return this.firstTel + '-' + this.secondTel + '-' + this.thirdTel;
    }

    public getHolderZipCode(): string {
        return this.firstZipCode + this.lastZipCode;
    }

    public getHolderAddressStreetNameFuriKana(): string {
        if (this.holderAddressStreetNameFuriKanaSelect || this.holderAddressStreetNameFuriKanaInput) {
            return this.holderAddressStreetNameFuriKanaSelect
                ? this.holderAddressStreetNameFuriKanaSelect : this.holderAddressStreetNameFuriKanaInput;
        }

        return '';
    }

    public getHolderAddressStreetName(): string {
        if (this.holderAddressStreetNameSelect || this.holderAddressStreetNameInput) {
            return this.holderAddressStreetNameSelect
                ? this.holderAddressStreetNameSelect : this.holderAddressStreetNameInput;
        }

        return '';
    }
}

export class DropDownListEntity {
    public key: string;
    public value: string;
    public filler1: string;
    public filler2: string;
    public filler3: string;
    public filler5: string;
}
