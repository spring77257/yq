export class CheckboxStatusChangeEntity {
    public isAllMaskingStatus: boolean; // 写真マスキング
}
