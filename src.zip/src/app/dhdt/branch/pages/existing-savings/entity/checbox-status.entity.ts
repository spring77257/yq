export class CheckboxStatusEntity {
    public receiptMethodStatus: boolean;  // カードお受取方法 checkbox
    public confirmationStatus: boolean;  // 契約状況確認
    public isAntisocialStatus: boolean;  // 反社会的勢力
    public isForeignPulicFiguresSatus: boolean;  // 外国の重要な公的地位にある者
    public isJapaneseResidentStatus: boolean;  // 日本居住者です
    public isRegulationStatus: boolean;
    public isAllMaskingStatus: boolean; // 写真マスキング
    public isCheckBranchStatus: boolean; // 開設店舗確認
}
