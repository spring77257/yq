import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import {
    ApplyBC, ApplyDate, ClearSavingImagesClickRecordType, CodeCategory, COMMON_CONSTANTS
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import {
    ExistingSavingsConfirmPageChatComponent
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-confirmpage-chat.component';
import { ExistingSavingsSubmitEntity } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { BussinessCode } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import {
    ExistingSavingsComponentParamName, ExistingSavingsConfirmPageCommonService
} from 'dhdt/branch/pages/existing-savings/service/existing-savings-confirmpage.common.service';
import {
    ExistingSavingsState, ExistingSavingsStore
} from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import {
    ExistingSavingsConfirmComponent
} from 'dhdt/branch/pages/existing-savings/view/existing-savings-confirm.component';
import {
    ExistingSavingsContentConfirmComponent
} from 'dhdt/branch/pages/existing-savings/view/existing-savings-content-confirm.component';
import {
    AddCheckConfirmationChangeComponent
} from 'dhdt/branch/shared/components/confirmpage-common/change/add-check-confirmation-change.component';
import { ChangeConfirmMethodComponent } from 'dhdt/branch/shared/components/confirmpage-common/change/change-confirm-method.component';
import { ModalDigitalStore } from 'dhdt/branch/shared/components/modal/modal-digital/store/modal-digital.store';
import { FilteringParameterEntity } from 'dhdt/branch/shared/entity/filtering-parameter.entity';
import { DocumentCategoryService } from 'dhdt/branch/shared/modules/document-category/service/document-category.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { ConfirmUtil } from 'dhdt/branch/shared/utils/confirm-util';
import { ModalController, NavController } from 'ionic-angular';
import { NavParams } from 'ionic-angular/navigation/nav-params';
import { ViewController } from 'ionic-angular/navigation/view-controller';
import { CreditCardAction } from '../../creditcard/action/creditcard.action';

@Component({
    selector: 'existing-savings-change-confirm-component',
    templateUrl: 'existing-savings-change-confirm.component.html'
})
export class ExistingSavingsChangeConfirmComponent extends BaseComponent implements OnInit {
    public state: ExistingSavingsState;
    public processType;
    public nameChanged = false;
    public type: COMMON_CONSTANTS.BusinessFlowType;
    public callBack: any;       // 呼び出す箇所のコールバック関数
    public editedList: any = {};    // 変更項目リスト
    public isFromChange: boolean = true;
    // 届出変更
    public title: string = this.labels.change.completion.headerTitle;
    // #22427: 氏名変更の場合に、チェックボックスをチェックされていないと「認証する」ボタンが活性化されない
    public selected = false;
    public receptionNumber: string = '';
    public saveShowChats: any = {};
    public businessCode: string = BussinessCode.EXISTING_SAVINGS;

    @ViewChild(ChangeConfirmMethodComponent)
    private changeConfirmMethodComponent: ChangeConfirmMethodComponent;
    @ViewChild(AddCheckConfirmationChangeComponent)
    private insertImageType: string = COMMON_CONSTANTS.InsertImageType.image;
    private readonly MASKING_CHECKBOX_NAME = 'isAllMaskingStatus';
    private originSubmitData: any;

    constructor(
        private action: ExistingSavingsAction,
        private navCtrl: NavController,
        private navParams: NavParams,
        private modalService: ModalService,
        private savingsAction: SavingsAction,
        private logging: LoggingService,
        private categoryService: DocumentCategoryService,
        private viewCtrl: ViewController,
        private modalCtrl: ModalController,
        private loginStore: LoginStore,
        private modalDigitalStore: ModalDigitalStore,
        private store: ExistingSavingsStore,
        private changeConfirmPageCommonService: ExistingSavingsConfirmPageCommonService,
        public confirmUtil: ConfirmUtil,
        private creditCardAction: CreditCardAction,
        private changeUtils: ChangeUtils,
    ) {
        super();
        this.state = this.store.getState();
        this.type = navParams.data.type || COMMON_CONSTANTS.BusinessFlowType.Change;
        this.callBack = navParams.get('callBack');
        this.processType = 3;
        this.action.setAsSystemTime(ApplyDate.BANKCLERK_AUTHENTICATION_START_DATE);
        this.viewCtrl.willEnter.subscribe(() => this.categoryService.addObserver((data) => {
            this.action.setDocumentCategory(data, false, false);
        }, this));
        this.viewCtrl.willLeave.subscribe(() => this.categoryService.removeObserver(this));
        this.originSubmitData = Object.assign(new ExistingSavingsSubmitEntity(), this.state.submitData);
    }

    public ngOnInit() {
        this.saveShowChatsData();
        this.setPageInitialData();
        // 本人確認書類聴取前のsubmitDataをバックアップ
        this.action.submitDataBackup();

        // 氏名・住所・電話番号で変更がある項目は青色背景
        // それ以外の項目は白背景とする
        this.editedList = {
            holderName: this.state.submitData.editedListModify.holderName,
            holderAddress: this.state.submitData.editedListModify.holderAddress,
            existingChangeHolderMobileNo: this.state.submitData.editedListModify.existingChangeHolderMobileNo,
            existingChangeHolderTelephoneNo: this.state.submitData.editedListModify.existingChangeHolderTelephoneNo,
            isSmsPhone: false,
        };
        this.nameChanged = this.editedList.holderName || this.state.isNameDifference ? true : false;

        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.action.clearIdentificationDocument();
            this.action.backupOCRDueDate();
        }
    }

    public saveShowChatsData() {
        this.state.showChats.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
    }

    public get changeDocumentImages() {
        if (Object.keys(this.state.changeDocumentImages).length > 0) {
            return this.state.changeDocumentImages;
        } else {
            return undefined;
        }
    }

    public onMaskingConfirmEmmiterHandler(maskingConfirmImgStatus) {
        this.action.removeNotMaskingConfirmImages(maskingConfirmImgStatus);
    }

    public get showImages() {
        if (this.state.changeDocumentImages && Object.keys(this.state.changeDocumentImages).length > 0) {
            return true;
        } else {
            return false;
        }
    }

    // 本人確認チャットでの撮影順
    public get orderChangeDocument() {
        return this.state.orderChangeDocument;
    }

    // 本人確認チャットでの撮影順とマッピング名前順
    public get orderChangeDocumentName() {
        return this.state.orderChangeDocumentName;
    }

    /**
     * Back action
     */
    public back() {
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    // マスキングがチェックされるときに、値にfalseをセット
                    if (this.state.checkboxStatusForChange.isAllMaskingStatus) {
                        this.checkboxStatusEmmiterHandler(this.MASKING_CHECKBOX_NAME);
                    }
                    this.clearConfirmPageInfo();
                    this.navCtrl.setRoot(ExistingSavingsContentConfirmComponent).then(() => {
                        this.action.resetSubmitData();
                    });

                    this.logging.saveCustomOperationLog(
                        this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
                        this.labels.logging.AccountConfirm.backConfirmButton,
                    );
                }
            }
        );
    }

    /**
     * 認証ボタンが押される
     *
     * @memberof ChangeFinishComponent
     */
    public submit() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.AccountConfirm.confirmButton,
        );
        // 行員認証画面（口座開設）遷移する
        this.naviNextFlow();
    }

    /**
     * 「認証する」ボタン活性化
     */
    public disableNextButton() {
        if (this.state.submitData.holderIdentityDocumentType) {
            return false;
        }
        return true;
    }

    /**
     * 認証ボタンを活性化・非活性
     * 以下条件を満足
     * * 受付番号入力済かつ追加確認チャット終了
     * * マスキングチェックボックスが存在する場合はチェックする
     *
     * @returns false:非活性 true:活性
     * @memberof ChangeFinishComponent
     */
    public checkInputValidation() {
        this.receptionNumber = this.state.submitData.receptionNumber;
        return this.receptionNumber && this.receptionNumber.match(/^[0-9]{3}$/g) !== null
            && (!this.changeConfirmMethodComponent || this.state.checkboxStatusForChange.isAllMaskingStatus);
    }

    /**
     * 顔写真のある本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedEmitter(event?: any) {
        this.insertImageType = event || this.insertImageType;
    }

    /**
     * eyecube番号を記録
     *
     * @param {*} data
     * @memberof ChangeFinishComponent
     */
    public onChangeReceptionNumber(data) {
        this.action.setStateSubmitDataValue(data);
        this.action.updateSubmitDataBackup(data);
    }

    /**
     * 修正ボタン Emitハンドラー
     */
    public onEdit() {
        const backup = Object.assign(new ExistingSavingsSubmitEntity(), this.state.submitData);
        const changeDocumentImagesBackup = this.state.changeDocumentImages;
        const orderChangeDocumentBackup = this.state.orderChangeDocument;
        const orderChangeDocumentNameBackup = this.state.orderChangeDocumentName;

        this.action.clearShowChats();
        this.action.clearChangeIdentificationDocument();

        const params = this.changeConfirmPageCommonService.getShowChatParams()
            .get(ExistingSavingsComponentParamName.CHANGE_CONFIRM_DOCUMENT);

        params.isCurrentPage = true;

        const modalSub = this.modalCtrl.create(ExistingSavingsConfirmPageChatComponent,
            { params: { ...params } },
            { cssClass: 'full-modal', enableBackdropDismiss: false });

        modalSub.onDidDismiss((chatData) => {

            if (chatData === 'backToTop') {
                this.state.submitData = backup;
                this.state.changeDocumentImages = changeDocumentImagesBackup;
                this.state.orderChangeDocument = orderChangeDocumentBackup;
                this.state.orderChangeDocumentName = orderChangeDocumentNameBackup;
            } else if (chatData === 'close') {
                this.state.submitData = backup;
                this.state.changeDocumentImages = changeDocumentImagesBackup;
                this.state.orderChangeDocument = orderChangeDocumentBackup;
                this.state.orderChangeDocumentName = orderChangeDocumentNameBackup;
            } else if (chatData) {
                // マスキングがチェックされるときに、値にfalseをセット
                if (this.state.checkboxStatusForChange.isAllMaskingStatus) {
                    this.checkboxStatusEmmiterHandler(this.MASKING_CHECKBOX_NAME);
                }
                // 写真をStateに保存
                this.action.saveDocumentImages(chatData.documentImages, chatData.photoOrder, chatData.name);
                // 書類パターン(A/B)ごとのスキップボタン押下有無を保存
                this.action.saveSkippedDocumentPattern(chatData.identificationDocument3A, chatData.identificationDocument3B);
                // 最新の写真によってマスキング未確認データをセットする
                this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.DOCUMENT);
            }
        });
        modalSub.present();
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.action.modifyCheckboxStatusForChange(checboxItem);
    }

    /**
     * 画像マスキング修正を反映する
     *
     * @param {{ index: number, fieldName: string, value: string }} data
     * @memberof AccountComponent
     */
    public onImageMaskingComplete(data: { index: number, fieldName: string, code?: string, value: string }) {
        // 書類種別が指定されている場合、入れ子構造として画像を登録する
        if (data.code !== null) {
            this.action.editSubmitDataNested(data.index, data.fieldName, data.code, data.value);
        } else {
            this.action.editSomeDataInSubmitData(data.index, data.fieldName, data.value);
        }
    }

    public filterInquiry() {
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                nameKanji: this.state.submitData.existingChangeFirstName ?
                    this.state.submitData.existingChangeFirstName + '　' + this.state.submitData.existingChangeLastName :
                    this.state.submitData.nameKanji,
                nameKana: this.state.submitData.existingChangeFirstNameKana ?
                    this.state.submitData.existingChangeFirstNameKana + '　' + this.state.submitData.existingChangeLastNameKana :
                    this.state.submitData.nameKana,
                nameAlphabet: this.state.submitData.holderNameAlphabet ? this.state.submitData.holderNameAlphabet :
                    this.state.submitData.nameEnglish,
                birthdate: this.state.submitData.birthdate,
                address: this.state.submitData.holderAddressPrefecture ? (this.state.submitData.holderAddressPrefecture
                    + this.state.submitData.holderAddressCountyUrbanVillage + this.state.submitData.holderAddressStreetNameSelect
                    + this.state.submitData.holderAddressHouseNumber)
                    : this.state.submitData.address,
                bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
            }
        };
        const curFilteringParamters = new FilteringParameterEntity();
        curFilteringParamters.nameKanji = param.params.nameKanji;
        curFilteringParamters.nameKana = param.params.nameKana;
        curFilteringParamters.nameAlphabet = param.params.nameAlphabet;

        // 前回のパラメータと比較
        const isChanged = this.confirmUtil.isFilteringParameterChanged(this.state.lastFilteringParameter, curFilteringParamters);
        if (isChanged) {
            this.action.filterInquiry(param);
            // 今回のパラメータを保存
            this.action.setLastFilteringParameters(curFilteringParamters);
        } else {
            // 前回のフィルタリング照会結果を表示変数に渡す
            this.action.setLastFilteringResult(this.state.lastFilteringResult);
        }
    }

    get addCheckData() {
        return {
            receiptMethod: this.getReceiptMethod(),
            bcSuicaResult: this.state.submitData.bcSuicaResult,
            americanSuggestionInformationStatus: this.state.submitData.americanSuggestionInformationStatus,
            firstNameRoma: this.state.submitData.firstNameRoma,
            lastNameRoma: this.state.submitData.lastNameRoma
        };
    }

    private getReceiptMethod() {
        return this.changeUtils.isNeedIssueCashCard(this.state.isNameDifference, this.state.submitData) ?
            this.state.submitData.receiptMethod === CodeCategory.RECEIPT_METHOD_ISSUE ?
                CodeCategory.RECEIPT_METHOD_ISSUE : CodeCategory.RECEIPT_METHOD_MAIL : null;
    }

    private setPageInitialData() {
        // 行員登録画面に遷移するとき、入力する行員IDを記録する
        this.action.setBankclerkId(this.modalDigitalStore.getState().bankclerkId);
    }

    private naviNextFlow() {
        this.navCtrl.push(ExistingSavingsConfirmComponent,
            {
                type: this.type,
                title: this.labels.change.confirm.headerTitle,
                editedList: this.editedList,
                callBack: this.callBack
            });
    }

    /**
     * 申込内容確認へ戻る
     */
    private clearConfirmPageInfo() {
        this.action.setStateData({ submitData: this.originSubmitData });
        this.action.clearConfirmPageInfo();
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.creditCardAction.clearConfirmPageInfo();
            // バックアップした運転免許証番号、学生証、連絡事項をクリア
            this.creditCardAction.clearCopyComplexTransConfirmInfos();
        }
    }
}
