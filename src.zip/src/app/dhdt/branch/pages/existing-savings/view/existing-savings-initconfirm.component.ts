import { Component, NgZone, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { CompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/completion.component';
import { ChangeConfirmPageCommonService } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import {
    AccountType, ApplyBC, ApplyBusinessType, DirectApplyExpectation,
    IdentificationCode, ReferenceFlg, SsnHave, SsnWrite
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardInitConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-initconfirm.component';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { BussinessCode } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import {
    ExistingSavingsConfirmPageCommonService
} from 'dhdt/branch/pages/existing-savings/service/existing-savings-confirmpage.common.service';
import { ExistingSavingsState, ExistingSavingsStore } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { NameBasedAggregationService } from 'dhdt/branch/shared/services/name-based-aggregation.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { ModalController, NavController, NavParams } from 'ionic-angular';
import { CreditCardChatComponent } from '../../creditcard/chat-flow/creditcard-chat.component';

/**
 * 申込内容確認
 */
@Component({
    selector: 'existing-savings-initconfirm-component',
    templateUrl: 'existing-savings-initconfirm.component.html'
})
export class ExistingSavingsInitConfirmComponent extends BaseComponent implements OnInit {
    // 子componentに渡す、表示制御用のeditedList
    public editedList: any = {};
    // 修正済項目を保存しておくeditedList（諸届項目の変更有無も含む）
    public editedListModify: any = {};
    public state: ExistingSavingsState;
    public saveShowChats: any = {};
    public confirmPageCommonParams: Map<string, any> = null;
    public changeConfirmPageParams: Map<string, any> = null;
    public passwordValid: boolean = true;
    public changeHolderMobileNoFlag: boolean = false;
    public isCareerShow: boolean = false;
    public isSignShow: boolean = false;
    public businessCode: string = BussinessCode.EXISTING_SAVINGS;
    public needCheck: boolean;
    public savingDepositPasswordChangeRequiredFlag: boolean = false;

    constructor(
        private action: ExistingSavingsAction,
        private store: ExistingSavingsStore,
        private confirmPageCommonService: ExistingSavingsConfirmPageCommonService,
        private changeConfirmPageService: ChangeConfirmPageCommonService,
        private navCtrl: NavController,
        private logging: LoggingService,
        private zone: NgZone,
        private params: NavParams,
        private modalCtrl: ModalController,
        private loginStore: LoginStore,
        private savingStore: SavingsStore,
        private rsaEncryptService: RsaEncryptService,
        private nameBasedAggregationService: NameBasedAggregationService
    ) {
        super();
        this.state = this.store.getState();
        // stateのsubmitDataをバックアップする
        this.action.submitDataBackup();
    }

    public ngOnInit() {
        this.confirmPageCommonService.loadConfirmTemplate();
        this.confirmPageCommonParams = this.confirmPageCommonService.getShowChatParams();
        this.changeConfirmPageService.loadConfirmTemplate();
        this.changeConfirmPageParams = this.changeConfirmPageService.getChangeConfirmPageComponentParams();
        this.state.showConfirm.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
        this.action.setEditNameKanji();
        this.isCareerShow = this.getCareerShow;
        this.isSignShow = this.getSignShow;
        // 諸届申込内容確認画面より遷移する場合
        this.editedListModify = this.params.get('editedList');
        if (!this.editedListModify) {
            // それ以外の場合
            this.editedListModify = this.state.submitData.editedListModify;
        }
        // 諸届および口座開設およびバンクカードのいずれかの画面から申込内容確認画面へ戻る場合、editedList取得
        this.editedList = this.state.submitData.editedList;
        // 口座開設画面に編集済み表示させない(白背景とする)
        if (this.editedList) {
            this.editedList.holderName = false;
            this.editedList.holderAddress = false;
            this.editedList.existingChangeHolderMobileNo = false;
            this.editedList.existingChangeHolderTelephoneNo = false;
            // BC複合申込&CD発行有無
            this.editedList.bcApply = false;
        } else {
            this.editedList = {
                holderName: false,
                holderAddress: false,
                existingChangeHolderMobileNo: false,
                existingChangeHolderTelephoneNo: false,
                // BC複合申込&CD発行有無
                bcApply: false,
            };
        }
        // SMS受信欄の背景色を諸届の申込内容確認画面と同じにする
        this.editedList.isSmsPhone = this.editedListModify ? this.editedListModify.isSmsPhone : false;

        this.needCheck = this.editedListModify ?
            this.editedListModify.existingChangeHolderMobileNo || this.editedListModify.existingChangeHolderTelephoneNo : false;

        // bc申込状態を保存する
        this.saveApplyBCAndBCBak(this.params.get('ifApplyBC'), this.params.get('ifApplyBCBak'));
    }

    /**
     * ・BC修正ボタンによってBC申込チャットが完了時にBC申込Viewから呼ばれる
     *
     * @param {*} data
     * @memberof ExistingSavingsInitConfirmComponent
     */
    public receiveBCParamByModify(data: any) {
        // bc申込状態を保存する
        this.saveApplyBCAndBCBak(data.ifApplyBC, data.ifApplyBCBak);
    }

    public onModifying(data) {
        this.action.setStateSubmitDataValue(Object.keys(data).map((key) => {
            return {
                key,
                value: data[key]
            };
        }));
    }

    public onModifyingBcApply(data) {
        // BC複合申込を変更した場合、キャッシュカード申込欄も編集済み表示にするため
        // 確認画面の子componentで共通のeditedListをtrueに設定
        this.editedList.bcApply = true;
        // 修正チャットで「申込する」を選んで、かつBCの申込内容がなければ、BC申込チャットに遷移
        // 申込チャットで「申し込まない」を選び、修正によって「申し込む」を選んだ場合
        if (data.ifApplyBC === ApplyBC.YES
            && (this.state.submitData.ifApplyBCBak === ApplyBC.NO)) {
            this.onModifying(data);

            this.navCtrl.push(CreditCardChatComponent,
                {
                    // 住所変更ありの場合は、変更後の住所情報を送信する(親権者住所のため)
                    submitData: this.state.submitData.isAddressChange ? {
                        ...this.state.submitData,
                        zipCode: this.state.submitData.firstZipCode + '-' + this.state.submitData.lastZipCode,
                        address: this.state.submitData.holderAddressPrefecture
                            + this.state.submitData.holderAddressCountyUrbanVillage
                            + this.state.submitData.getHolderAddressStreetName() + this.state.submitData.holderAddressHouseNumber,
                        addressKana: this.state.submitData.holderAddressPrefectureFuriKana
                            + this.state.submitData.holderAddressCountyUrbanVillageFuriKana
                            + this.state.submitData.getHolderAddressStreetNameFuriKana()
                            + this.state.submitData.holderAddressHouseNumberFuriKana,
                        referenceFlg: ReferenceFlg.Confrim
                    } : {
                        ...this.state.submitData,
                        referenceFlg: ReferenceFlg.Confrim
                    },
                    tabletApplyId: this.loginStore.getState().tabletApplyId,
                    pageIndex: 0,
                    accountType: this.state.submitData.accountType,
                    customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                    cardInfo: this.state.submitData.cardInfo,
                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                });
        } else {
            this.onModifying(data);
        }
    }

    public savingDepositPasswordChangeRequiredEmitter(value: boolean) {
        this.savingDepositPasswordChangeRequiredFlag = value;
    }

    // BCを申し込めるお客さんの場合は、BC申込欄を表示
    public get isBcShow() {
        return this.state.submitData.ifApplyBCBak ? true : false;
    }

    public get bottonTitle(): string {
        return this.state.submitData.ifApplyBC === ApplyBC.YES ?
            this.labels.change.confirm.button : this.labels.confirm.confirmButton;
    }

    public get topMessage(): string {
        return this.state.submitData.ifApplyBC === ApplyBC.YES ?
            this.labels.confirm.subtitle.topMessageBc : this.labels.confirm.subtitle.topMessage;
    }

    public get isFatcaShow(): boolean {
        return this.state.submitData.isSsnHave === SsnHave.NO || this.state.submitData.isTaxForAmerican === SsnHave.NO;
    }

    public get isW9Show(): boolean {
        return this.state.submitData.isSsnWrite === SsnWrite.YES;
    }

    public get getCareerShow(): boolean {
        let result = false;
        const identificationCodeWithChange = InputUtils.getIdentificationCodeWithChange(this.state.submitData);
        if (identificationCodeWithChange !== IdentificationCode.CODE_80) {
            result = true;
        }
        return result;
    }

    public get getSignShow(): boolean {
        let result = false;
        const identificationCodeWithChange = InputUtils.getIdentificationCodeWithChange(this.state.submitData);
        if (identificationCodeWithChange !== IdentificationCode.CODE_80
            && identificationCodeWithChange !== IdentificationCode.CODE_90) {
            result = true;
        }

        return result;
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.zone.run(() => this.action.modifyCheckboxStatus(checboxItem));
    }

    /**
     * footer button disable
     */
    public get disableFooterButton() {
        const checkboxTotalValid = this.checkboxValid();
        const passwordValid = this.passwordValid;
        if (this.savingDepositPasswordChangeRequiredFlag) {
            // キャッシュカードの暗証番号が要修正でない場合、フッターボタン活性化
            return false;
        }
        return checkboxTotalValid && passwordValid && !this.changeHolderMobileNoFlag;
    }

    /**
     * footer button disable
     */
    public disableChangFooterButton() {
        if (this.state.submitData.isNameChange || this.state.submitData.isAddressChange
            || this.state.submitData.isTelphoneChange || this.state.isNameDifference
            || this.state.isAddressDifference || this.state.isTelphoneDifference) {
            return false;
        } else {
            return true;
        }
    }
    /**
     * ページのタイトル
     */
    public get headerTitle(): string {
        if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
            return this.labels.existingSavings.title;
        } else if (this.state.submitData.accountType === AccountType.EXISTING_STORAGE) {
            return this.labels.existingStorage.title;
        }
    }

    /**
     * click 'お申込み' button
     */
    public moveToNextPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.InfoComfirm.ApplyButton,
        );

        // 認証の場合
        this.action.setStateSubmitDataValue([{
            key: 'isModify',
            value: '2'
        }]);

        this.action.setStateSubmitDataValue([{ key: 'editedList', value: this.editedList }]);
        // editedListModify=undefinedの場合、editedListの方に修正有無が保存されているためそちらを保存させる
        this.action.setStateSubmitDataValue([{
            key: 'editedListModify',
            value: this.editedListModify ? this.editedListModify : this.editedList
        }]);

        this.action.setCustomerApplyEndDate();
        this.action.clearIdentificationDocument();
        let info: {
            applyBusinessCategory: string;
            tabletApplyId: string;
        };
        const isChanged =
            this.state.submitData.isNameChange || this.state.submitData.isAddressChange || this.state.submitData.isTelphoneChange;
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.navCtrl.push(CreditCardInitConfirmComponent,
                {
                    // 住所変更ありの場合は、変更後の住所情報を送信する(親権者住所のため)
                    submitData: this.state.submitData.isAddressChange ? {
                        ...this.state.submitData,
                        zipCode: this.state.submitData.firstZipCode + '-' + this.state.submitData.lastZipCode,
                        address: this.state.submitData.holderAddressPrefecture
                            + this.state.submitData.holderAddressCountyUrbanVillage
                            + this.state.submitData.getHolderAddressStreetName() + this.state.submitData.holderAddressHouseNumber,
                        addressKana: this.state.submitData.holderAddressPrefectureFuriKana
                            + this.state.submitData.holderAddressCountyUrbanVillageFuriKana
                            + this.state.submitData.getHolderAddressStreetNameFuriKana()
                            + this.state.submitData.holderAddressHouseNumberFuriKana,
                    } : this.state.submitData,
                    editedList: this.editedList
                });
            if (this.state.submitData.existingChangeFlag === '1' || isChanged) {
                info = {
                    applyBusinessCategory: ApplyBusinessType.BANKCARD_CHANGE_COMPOSIT, // 普通預金口座開設（BC＋諸届複合）
                    tabletApplyId: this.loginStore.getState().tabletApplyId
                };
            } else {
                info = {
                    applyBusinessCategory: ApplyBusinessType.BANKCARD_COMPOSIT, // 普通預金口座開設（BC複合）
                    tabletApplyId: this.loginStore.getState().tabletApplyId
                };
            }
            this.action.updateApplyBizCategory(info);
        } else {
            let modal;
            if (this.state.submitData.cardInfo) {
                // SWありの場合、カード認証
                modal = this.modalCtrl.create(ModalPasswordComponent,
                    {
                        data: {
                            text: this.labels.password.inputPasswordAgainText,
                            subText: this.labels.password.inputPasswordAgainSubText,
                            units: 4,
                            needConfirm: false,
                            validation: (password) => this.action.cardIinfoCheck({
                                tabletApplyId: this.state.submitData.tabletApplyId, // タブレット申込管理ID
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                                    tenban: this.state.submitData.cardInfo.branchNo, // 店番
                                    accountType: this.state.submitData.cardInfo.accountType, // 科目
                                    accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                                    icCardInfo: this.savingStore.getState().icData,  // カード情報を入れる
                                    passcode: this.rsaEncryptService.encrypt(password)  // 暗証番号
                                }
                            })
                        }
                    },
                    { cssClass: 'settings-modal', enableBackdropDismiss: false });
            } else {
                // SWなしの場合、入力した暗証番号を検証
                modal = this.modalCtrl.create(ModalPasswordComponent,
                    {
                        data: {
                            text: this.labels.confirm.passwordModal.text,
                            subText: this.labels.confirm.passwordModal.subText,
                            units: 4,
                            errorMessage: this.labels.confirm.passwordModal.errorMessage,
                            needConfirm: true,
                            inputPassword: this.state.submitData.firstPwd4bits
                        }
                    },
                    { cssClass: 'settings-modal', enableBackdropDismiss: false });
            }

            modal.onDidDismiss((value) => {
                if (typeof value === 'boolean' && value) {
                    // SWなしの場合
                    this.navCtrl.push(CompletionComponent);
                } else if (value && value.result) {
                    // SWありの場合
                    this.navCtrl.push(CompletionComponent);
                }
            });
            modal.present();
            if (this.state.submitData.existingChangeFlag === '1' || isChanged) {
                info = {
                    applyBusinessCategory: ApplyBusinessType.CHANGE_COMPOSIT, // 普通預金口座開設（諸届複合）
                    tabletApplyId: this.loginStore.getState().tabletApplyId
                };
                this.action.updateApplyBizCategory(info);
            }
        }
    }

    // 暗証番号 emitter
    public passwordOKEmitterHandler(flag: boolean) {
        // this.passwordOK = !this.getCardPwdAndConfirmPwdError();
    }

    /**
     * password valid
     * @param passwordValid  password valid result
     */
    public passwordEmmiterHandler(passwordValid: boolean) {
        this.passwordValid = passwordValid;
    }

    /**
     * set password value
     * @param value {name: passwordName, value: password}
     */
    public passwordValueEmmiterHandler(value) {
        const passwordValue = [{
            key: value.name,
            value: value.value
        }];
        this.action.setStateSubmitDataValue(passwordValue);
    }

    /**
     * 変更項目を設定
     * @param data 変更項目
     */
    public handleItemChangedEmitter(data) {
        // 当画面で修正チャットで修正した項目(true)について
        // editedListModifyに格納されていなければ格納する
        Object.keys(data.editList).forEach((item) => {
            if (this.editedListModify && !this.editedListModify[item] && data.editList[item]) {
                this.editedListModify[item] = data.editList[item];
            }
        });
    }

    public get isNoteMessageHide(): boolean {
        return !this.state.checkboxStatus.isAntisocialStatus &&
            this.state.checkboxStatus.isJapaneseResidentStatus &&
            this.state.checkboxStatus.isRegulationStatus &&
            (this.getCareerShow ? !this.state.checkboxStatus.isForeignPulicFiguresSatus : true);
    }

    public changeHolderMobileNoEmitter(value) {
        this.changeHolderMobileNoFlag = value;
    }

    // click 戻る button
    public backConfirmClick() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.existingSavings.clerk.changeBack
        );
        // 口座開設側のeditedListを諸届の申込内容確認画面へ連携
        this.action.setStateSubmitDataValue([{ key: 'editedList', value: this.editedList }]);
        this.action.setStateSubmitDataValue([{ key: 'editedListModify', value: this.editedListModify }]);
        this.navCtrl.pop();
    }

    /**
     * CD暗証番号を修正した場合、その更新をBC暗証番号に反映させる
     * @param data 変更項目
     */
    public setPwdForCashCardFirstPwd4bitsEmitter(data) {
        // 口座開設側のstate.submitDataの暗証番号に修正後の値を格納
        this.action.setStateSubmitDataValue([{ key: 'firstPwd4bits', value: data.value }]);
        this.action.setStateSubmitDataValue([{ key: 'cashCardFirstPwd4bits', value: data.value }]);
    }

    /**
     * show checkbox valid
     */
    private checkboxValid(): boolean {
        const preconditionsOK = this.isNoteMessageHide;

        const confirmationCheckedOK = this.state.submitData.directApplyExpectation === DirectApplyExpectation.APPLY
            && this.state.submitData.showDirectApply ?
            this.state.checkboxStatus.confirmationStatus : true;
        const checkboxTotalValid = confirmationCheckedOK && preconditionsOK;
        return checkboxTotalValid;
    }

    /**
     * 複数箇所に使われるので、共通化する
     *
     * @private
     * @param {string} ifApplyBC
     * @param {string} ifApplyBCBak
     * @memberof ExistingSavingsInitConfirmComponent
     */
    private saveApplyBCAndBCBak(ifApplyBC: string, ifApplyBCBak: string) {
        if (ifApplyBC) {
            this.action.setStateSubmitDataValue([{
                key: 'ifApplyBC',
                value: ifApplyBC
            }]);
        }
        if (ifApplyBCBak) {
            this.action.setStateSubmitDataValue([{
                key: 'ifApplyBCBak',
                value: ifApplyBCBak
            }]);
        }
    }
}
