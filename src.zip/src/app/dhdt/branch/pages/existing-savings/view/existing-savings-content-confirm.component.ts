import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { BussinessCode } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import {
    ExistingSavingsConfirmPageCommonService
} from 'dhdt/branch/pages/existing-savings/service/existing-savings-confirmpage.common.service';
import { ExistingSavingsState, ExistingSavingsStore } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import {
    ExistingSavingsInitConfirmComponent
} from 'dhdt/branch/pages/existing-savings/view/existing-savings-initconfirm.component';
import { LoadingService } from 'dhdt/branch/shared/services/loading.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { NavController, NavParams } from 'ionic-angular';

@Component({
    selector: 'existing-savings-content-confirm-component',
    templateUrl: 'existing-savings-content-confirm.component.html'
})

export class ExistingSavingsContentConfirmComponent extends BaseComponent implements OnInit {
    public state: ExistingSavingsState;

    public editedList: any = {};
    public saveShowChats: any = {};

    public showChats: ExistingSavingsQuestionsModel[];

    public confirmPageCommonParams: Map<string, any> = null;

    public processType: number = 2;
    public businessCode: string = BussinessCode.EXISTING_SAVINGS;

    public type: COMMON_CONSTANTS.BusinessFlowType.ExistingSavings;
    // 届出内容の変更
    public title: string = this.labels.change.confirm.headerTitle;
    public callBack: any;       // 呼び出す箇所のコールバック関数
    public pageTitle = this.labels.change.confirm.titleForCompoundTransaction; // お客さま情報確認
    public accountShopShow: boolean = false;
    public inheritChanged: boolean = false;
    public isTelErrorShow = false;
    public savingsPasswordChangeRequiredFlag: boolean = false;
    public savingDepositPasswordChangeRequiredFlag: boolean = false;
    protected ChangeUtils: ChangeUtils;

    constructor(
        private action: ExistingSavingsAction,
        private store: ExistingSavingsStore,
        private navCtrl: NavController,
        private changeConfirmPageCommonService: ExistingSavingsConfirmPageCommonService,
        private navParams: NavParams,
        private logging: LoggingService,
        private loadingService: LoadingService,

    ) {
        super();
        this.callBack = navParams.get('callBack');
        this.state = this.store.getState();

        // stateのsubmitDataをバックアップする
        this.action.submitDataBackup();
    }

    /**
     * 初期化の時、CIF情報取得処理を行う、ページ内容を更新する
     */
    public ngOnInit(): void {
        if (this.navParams.get('ifApplyBC')) {
            this.action.setStateSubmitDataValue([{
                key: 'ifApplyBC',
                value: this.navParams.get('ifApplyBC')
            }]);
        }
        if (this.navParams.get('ifApplyBCBak')) {
            this.action.setStateSubmitDataValue([{
                key: 'ifApplyBCBak',
                value: this.navParams.get('ifApplyBCBak')
            }]);
        }

        this.changeConfirmPageCommonService.loadConfirmTemplate();

        // get 修正 detail
        this.confirmPageCommonParams = this.changeConfirmPageCommonService.getShowChatParams();
        this.state.showChats.forEach((item) => {
            if (item.type !== 'judge') {
                this.saveShowChats[item.name] = item;
            }
        });
        this.loadingService.dismissAllLoading();

        if (this.state.submitData.editedListModify) {
            // 行員認証より遷移してきた場合
            this.editedList = this.state.submitData.editedListModify;
        } else {
            // 本チャットより遷移してきた場合
            this.editedList = {
                holderName: this.state.submitData.isNameChange,
                holderAddress: this.state.submitData.isAddressChange,
                existingChangeHolderMobileNo: this.state.submitData.isTelphoneChange,
                existingChangeHolderTelephoneNo: this.state.submitData.isTelphoneChange,
                isSmsPhone: false,
            };
        }
    }

    /**
     * カナ住所に漢字が混在した状態をチェック
     */
    public get checkContainKanjiValidation(): boolean {
        if (!StringUtils.validateKana(this.state.submitData.holderAddressPrefectureFuriKana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressCountyUrbanVillageFuriKana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressStreetNameFuriKanaInput ||
            this.state.submitData.holderAddressStreetNameFuriKanaSelect)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressHouseNumberFuriKana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressPrefectureFurigana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressCountyUrbanVillageFurigana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressStreetFurigana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressHouseNumberFurigana)) {
            return false;
        }

        return true;
    }

    public getShowText(name: string): string {
        if (!this.saveShowChats || !this.saveShowChats[name] || !this.saveShowChats[name].answer) {
            return '';
        }
        return this.saveShowChats[name].answer.text;
    }

    /**
     * click 行員認証ページへ
     */
    public pushCompletionPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.ChangeInformation.nextButton,
        );
        this.action.setCustomerApplyEndDate();
        this.naviNextFlow();

    }

    /**
     * 変更項目を設定
     * @param data 変更項目
     */
    public handleItemChangedEmitter(data) {
        this.editedList = data.editList;
    }

    public savingsPasswordChangeRequiredEmitter(value: boolean) {
        this.savingsPasswordChangeRequiredFlag = value;
    }

    public savingDepositPasswordChangeRequiredEmitter(value: boolean) {
        this.savingDepositPasswordChangeRequiredFlag = value;
    }

    // footer button disable
    public get footerBtnDisable() {
        let totalValid = false;
        if (!this.savingsPasswordChangeRequiredFlag && !this.savingDepositPasswordChangeRequiredFlag) {
            // キャッシュカードの暗証番号が要修正でない場合、フッターボタン活性化
            totalValid = true;
        }
        return totalValid;
    }

    /**
     * 子componentへ渡すeditedListを判定
     */
    public getEditedList() {
        if (this.state.submitData.editedListModify) {
            // 口座開設申込内容確認または行員認証より「戻る」で遷移してきた場合
            this.editedList = this.state.submitData.editedListModify;
        }
        return this.editedList;
    }

    private naviNextFlow() {
        this.navCtrl.push(ExistingSavingsInitConfirmComponent,
            {
                type: this.type,
                title: this.labels.change.confirm.headerTitle,
                editedList: this.editedList,
                callBack: this.callBack
            });
    }
}
