import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CommonBusinessType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessChatComponent } from 'dhdt/branch/pages/common-business/view/common-business-chat.component';
import {
    AccountCategory,
    AccountType, ApplyBC, ApplyBusinessType,
    CHANGECATEGORY,
    ClearSavingImagesClickRecordType, CodeCategory, COMMON_CONSTANTS, Constants, CountryCode,
    CssConsts, HasDriversCareerLicense, HasLicense, HostResultCode, IdentificationCode,
    IdentificationDocumentCode,
    IdentificationDocumentMethod, LicensePhotoType, MaskingCheckboxName, ServiceCategory, SsnHave, SsnWrite, StoreChanged
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardChatComponent } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat.component';
import {
    IsBankCardGoldSelected, IsBankCardSelected, IsBankCardSuicaGoldSelected,
    IsBankCardSuicaSelected
} from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-confirm.component';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatComponent } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat.component';
import {
    ExistingSavingsConfirmPageChatComponent
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-confirmpage-chat.component';
import { ExistingSavingsSubmitEntity } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { BussinessCode } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import {
    ExistingSavingsConfirmPageCommonService
} from 'dhdt/branch/pages/existing-savings/service/existing-savings-confirmpage.common.service';
import {
    ExistingSavingsSignal, ExistingSavingsState, ExistingSavingsStore
} from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ExistingSavingsContentConfirmComponent } from 'dhdt/branch/pages/existing-savings/view/existing-savings-content-confirm.component';
import { ExistingSavingsInitConfirmComponent } from 'dhdt/branch/pages/existing-savings/view/existing-savings-initconfirm.component';
import { IdentityDocumentConfirmComponent } from 'dhdt/branch/shared/components/confirmpage-common/identity-document-confirm.component';
import { ShowChartParam } from 'dhdt/branch/shared/components/confirmpage-common/showchart.param';
import { ModalDigitalStore } from 'dhdt/branch/shared/components/modal/modal-digital/store/modal-digital.store';
import { FilteringParameterEntity } from 'dhdt/branch/shared/entity/filtering-parameter.entity';
import { SameHolderInquiryEntity } from 'dhdt/branch/shared/entity/same-holder-inquiry.entity';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { NameBasedAggregationService } from 'dhdt/branch/shared/services/name-based-aggregation.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { ConfirmUtil } from 'dhdt/branch/shared/utils/confirm-util';
import { CreditCardUtil } from 'dhdt/branch/shared/utils/creditcard-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController, NavParams } from 'ionic-angular';

/**
 * 行員確認画面（既存普通預金）
 */
@Component({
    selector: 'existing-savings-confirm.component',
    templateUrl: 'existing-savings-confirm.component.html'
})
export class ExistingSavingsConfirmComponent extends BaseComponent implements OnInit, OnDestroy {
    public state: ExistingSavingsState;
    public confirmPageCommonParams: Map<string, any> = null;
    public saveShowChats: any = {};
    public isSelfApplyConfirm: boolean = true;
    public loginStore: LoginStore;
    public submitted: boolean = false;
    public isClerkConfirm: boolean = true;
    // 二度押下を回避するフラグ
    public isBackToCustomerConfirmPage = false;
    public editedList = {};

    // 同一名義人照会結果
    public sameHolderList: SameHolderInquiryEntity[];
    public accountSelected: boolean = false;    // 既存CIF・口座確認 has been selected
    public duplicateAccountValid: boolean = true;

    public isCareerShow: boolean = false;
    public isSignShow: boolean = false;
    public isW9Show: boolean = false;
    public isFatcaShow: boolean = false;
    public isBcShow: boolean = false;
    public isReceptionNoShow: boolean = true;

    public mailing = false;
    public businessCode: string = BussinessCode.EXISTING_SAVINGS;
    public bottonTitle: string;
    public topMessage: string;
    public nameChanged = false;

    private insertImageType: string = COMMON_CONSTANTS.InsertImageType.image;
    private insertImageTypeNoFace: string = COMMON_CONSTANTS.InsertImageType.image;
    private originSubmitData: any;

    @ViewChild(IdentityDocumentConfirmComponent)
    private identityDocumentConfirmComponent: IdentityDocumentConfirmComponent;

    constructor(
        private action: ExistingSavingsAction,
        private navCtrl: NavController,
        private store: ExistingSavingsStore,
        private confirmPageCommonService: ExistingSavingsConfirmPageCommonService,
        private modalDigitalStore: ModalDigitalStore,
        private modalCtrl: ModalController,
        private modalService: ModalService,
        private savingsAction: SavingsAction,
        private cancelAction: CancelAction,
        private logging: LoggingService,
        private rsaEncryptService: RsaEncryptService,
        private navParam: NavParams,
        private confirmUtil: ConfirmUtil,
        private changeUtils: ChangeUtils,
        private creditCardUtil: CreditCardUtil,
        private creditCardAction: CreditCardAction,
        private labelService: LabelService,
        private errorMessageService: ErrorMessageService,
        private savingStore: SavingsStore
    ) {
        super();
        this.state = this.store.getState();
        this.sameHolderList = this.navParam.get('sameHolderList');
        this.isSignShow = this.getSignShow();
        this.isW9Show = this.state.submitData.isSsnWrite === SsnWrite.YES;
        this.isFatcaShow = this.state.submitData.isSsnHave === SsnHave.NO || this.state.submitData.isTaxForAmerican === SsnHave.NO;
        this.originSubmitData = Object.assign(new ExistingSavingsSubmitEntity(), this.state.submitData);
    }

    public getSignShow(): boolean {
        const identificationCodeWithChange = InputUtils.getIdentificationCodeWithChange(this.state.submitData);
        let result = false;
        if (this.businessCode === BussinessCode.EXISTING_SAVINGS) {
            // 顧客コードは９９番　また　店舗切り替えによって純新規の場合、CRSを表示
            if (identificationCodeWithChange === IdentificationCode.CODE_99 || !identificationCodeWithChange) {
                result = true;
            }
        } else if (this.businessCode === BussinessCode.OPEN_ACCOUNT) {
            result = identificationCodeWithChange === IdentificationCode.CODE_99;
        }
        return result;
    }

    /**
     * 画面初期化
     */
    public ngOnInit() {
        this.initShowData();
        if (this.state.submitData.accountType === AccountType.EXISTING_STORAGE) {
            // #22736: 貯蓄預金口座開設
            this.action.setStateSubmitDataValue([
                { key: 'applyBusinessType', value: ApplyBusinessType.EXISTING_ORDINARY_DEPOSIT_SAVINGS_DIPOSIT }
            ]);
        } else {
            this.action.setStateSubmitDataValue([{ key: 'applyBusinessType', value: ApplyBusinessType.EXISTING_ORDINARY_DEPOSIT }]);
        }
        this.bottonTitle = this.labels.existingSavings.clerk.nextButton; // 認証する
        this.topMessage = this.labels.existingSavings.clerk.description3; // 申し込み
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.bottonTitle = this.labels.change.confirm.button; // 次へ
            this.topMessage = this.labels.existingSavings.clerk.description4; // 次へ
        }
        // BC申し込めるお客さんの場合は、表示する
        if (this.state.submitData.ifApplyBCBak) {
            this.isBcShow = true;
        }
        if (this.state.submitData.receptionNumber) {
            this.isReceptionNoShow = false;
        }

        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.nameChanged = this.state.submitData.isNameChange || this.state.isNameDifference ? true : false;

        this.confirmPageCommonParams = this.confirmPageCommonService.getShowChatParams();
        // this.isCareerShow = this.state.submitData.identificationCode !== '80';
        this.isCareerShow = this.getCareerShow();
        this.initPageData();
        // 本人確認書類聴取前のsubmitDataをバックアップ
        // 諸届ありの場合、諸届行員認証画面の初期化処理でバックアップ
        // 諸届なしの場合、口座開設行員認証画面の初期化処理でバックアップ
        if (this.state.submitData.isNameAddressTelDiff !== '1') {
            this.action.submitDataBackup();
        }
        this.action.submitDataBackup();
        this.editedList = this.state.submitData.editedList;

        const isChanged = this.state.submitData.isNameChange || this.state.submitData.isAddressChange;
        if (this.state.submitData.existingChangeFlag !== '1' && !isChanged) {
            this.action.clearIdentificationDocument();
            this.action.backupOCRDueDate();
        }
    }

    public getCareerShow(): boolean {
        let result = false;
        const identificationCodeWithChange = InputUtils.getIdentificationCodeWithChange(this.state.submitData);
        if (identificationCodeWithChange !== IdentificationCode.CODE_80) {
            result = true;
        }
        return result;
    }
    /**
     * 画面破壊
     */
    public ngOnDestroy(): void {
        this.unregisterSignalHandlers();
    }

    /**
     * データをサブミットする
     */
    public submit() {
        this.saveSubmit();
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.AccountConfirm.confirmButton,
        );
    }

    /**
     * ボタンを押下するとAPI呼び出しを行う。
     */
    public saveSubmit() {
        this.submitted = true;
        this.store.registerSignalHandler(ExistingSavingsSignal.SUCCESS_INSERT_INFO, (result) => {
            this.store.unregisterSignalHandler(ExistingSavingsSignal.SUCCESS_INSERT_INFO);
            if (result.resultCode === HostResultCode.SUCCESS) {
                this.modalService.showCompleteModal().subscribe({
                    next: (event) => {
                        switch (event) {
                            case COMMON_CONSTANTS.BACK_TYPE_REAPPLY_MENU:
                                this.navCtrl.setRoot(ChatComponent, { reapplyFlg: true });
                                break;
                            default:
                                this.navCtrl.setRoot(TopComponent);
                        }
                    },
                    complete: () => {
                        this.action.clearStore();
                        this.savingsAction.clearStore();
                        this.cancelAction.clearStore();
                    }
                });
            } else {
                this.errorMessageService.showMessageModal(this.labelService.labels.common.error.host.applyErrorMessage, () => {
                    this.navCtrl.setRoot(TopComponent);
                    this.action.clearStore();
                    this.savingsAction.clearStore();
                    this.cancelAction.clearStore();
                });
            }
        });
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.navCtrl.push(CreditCardConfirmComponent,
                {
                    submitData: {
                        ...this.state.submitData,
                        idInfoMethod: this.idInfoMethod(),
                        identificationDocument1: this.idInfoDoc1(),
                        identificationDocument1Images: this.imageDoc1(),
                        nameKanji: this.state.submitData.existingChangeFirstName + COMMON_CONSTANTS.FULL_SPACE
                            + this.state.submitData.existingChangeLastName,
                        nameKana: this.state.submitData.existingChangeFirstNameKana + COMMON_CONSTANTS.FULL_SPACE
                            + this.state.submitData.existingChangeLastNameKana
                    },
                    tabletApplyId: this.loginStore.getState().tabletApplyId,
                    pageIndex: 0,
                    accountType: this.state.submitData.accountType,
                    customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                    cardInfo: this.state.submitData.cardInfo,
                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                    registerParams: this.processSubmitData()
                });
        } else {
            this.action.submitExistSavingsData(this.processSubmitData());
        }
    }

    /**
     * リスナーをアンインストールする
     */
    public unregisterSignalHandlers() {
        this.store.unregisterSignalHandler(ExistingSavingsSignal.SUCCESS_INSERT_INFO);
        this.store.unregisterSignalHandler(ExistingSavingsSignal.TABLET_APPLY_INSERT_SUCCESS);
        this.store.unregisterSignalHandler(ExistingSavingsSignal.SET_DUPLICATE_ACCOUNT_INFO);
    }

    /**
     * 前遷移画面を設定する
     */
    public backToInfoConfirmPage() {
        this.isBackToCustomerConfirmPage = true;
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    this.clearConfirmPageInfo();
                    this.action.setStateSubmitDataValue([{
                        key: 'isModify',
                        value: '2'
                    }]);
                    // 申込画面に戻るので、マスキング未確認オブジェクトをクリア
                    this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.CLEAR);
                    this.navCtrl.setRoot(ExistingSavingsContentConfirmComponent).then(() => {
                        this.navCtrl.push(ExistingSavingsInitConfirmComponent);
                        this.action.resetSubmitData();
                    });
                    this.logging.saveCustomOperationLog(
                        this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
                        this.labels.logging.AccountConfirm.backConfirmButton,
                    );
                } else {
                    this.isBackToCustomerConfirmPage = false;
                }
            }
        );
    }

    /**
     * 登録データを加工する
     */
    public processSubmitData(): any {
        const registerParams: any = {};
        // EQ番号
        const eyeCueNo = this.state.submitData.receptionNumber;

        // base部分を作成
        // タブレット申込管理ID
        registerParams.tabletApplyId = this.state.tabletApplyId;

        // 変更後の情報
        const afterChangeInfo: any = {};
        afterChangeInfo.holderZipCode = this.state.submitData.firstZipCode ?
            this.state.submitData.firstZipCode + COMMON_CONSTANTS.HALF_HYPHEN
            + this.state.submitData.lastZipCode : undefined;
        afterChangeInfo.holderName = this.state.submitData.existingChangeFirstName ?
            this.state.submitData.existingChangeFirstName + '　' + this.state.submitData.existingChangeLastName : undefined;
        afterChangeInfo.holderNameFurigana = this.state.submitData.existingChangeFirstNameKana ?
            this.state.submitData.existingChangeFirstNameKana + '　' + this.state.submitData.existingChangeLastNameKana
            : undefined;
        afterChangeInfo.holderNameAlphabet = this.state.submitData.existingChangeFirstNameAlphabet ?
            this.state.submitData.existingChangeFirstNameAlphabet + + '　'
            + this.state.submitData.existingChangeLastNameAlphabet : undefined;
        afterChangeInfo.holderKanaAddress = this.state.submitData.holderAddressPrefectureFuriKana ?
            this.state.submitData.holderAddressPrefectureFuriKana
            + this.state.submitData.holderAddressCountyUrbanVillageFuriKana
            + (this.state.submitData.getHolderAddressStreetNameFuriKana() ?
                this.state.submitData.getHolderAddressStreetNameFuriKana() : '')
            : undefined;
        afterChangeInfo.holderKanaAuxiliaryAddress = this.state.submitData.holderAddressHouseNumberFuriKana;
        afterChangeInfo.holderPrefectureKana = this.state.submitData.holderAddressPrefectureFuriKana;
        afterChangeInfo.holderCountyUrbanVillageKana = this.state.submitData.holderAddressCountyUrbanVillageFuriKana;
        afterChangeInfo.holderStreetKana = this.state.submitData.getHolderAddressStreetNameFuriKana();
        afterChangeInfo.holderSubAddressKana = this.state.submitData.holderAddressHouseNumberFuriKana;
        afterChangeInfo.holderPrefecture = this.state.submitData.holderAddressPrefecture;
        afterChangeInfo.holderCountyUrbanVillage = this.state.submitData.holderAddressCountyUrbanVillage;
        afterChangeInfo.holderStreet = this.state.submitData.getHolderAddressStreetName() ?
            this.state.submitData.getHolderAddressStreetName() : undefined;
        afterChangeInfo.holderSubAddress = this.state.submitData.holderAddressHouseNumber;
        afterChangeInfo.holderAddressCode = this.state.submitData.holderAddressCode;
        afterChangeInfo.holderMobileNo = this.state.submitData.existingChangeFirstMobileNo ?
            this.state.submitData.existingChangeFirstMobileNo + COMMON_CONSTANTS.HALF_HYPHEN
            + this.state.submitData.existingChangeSecondMobileNo + COMMON_CONSTANTS.HALF_HYPHEN
            + this.state.submitData.existingChangeThirdMobileNo : undefined;
        afterChangeInfo.holderTelephoneNo = this.state.submitData.existingChangeFirstTel ?
            this.state.submitData.existingChangeFirstTel + COMMON_CONSTANTS.HALF_HYPHEN
            + this.state.submitData.existingChangeSecondTel + COMMON_CONSTANTS.HALF_HYPHEN
            + this.state.submitData.existingChangeThirdTel : undefined;

        // 自動的に「郵送」となる場合、receiptMethodを'1'に設定
        if (!this.state.submitData.receiptMethod) {
            this.action.setMailDelivery();
        }

        // 諸届更新APIへの送信リクエストパラメータを作成
        // 変更ありの場合、諸届メソッドに取得されたスワイプCIFをリストに削除
        // SWなしの場合、mediumInfosがundefined
        const mediumInfo = this.state.submitData.mediumInfos ? this.state.submitData.mediumInfos.mediumInfo : [];
        registerParams.changeParams = this.changeUtils.makeRequestParamsForUpdateNameAddressTel(eyeCueNo,
            this.loginStore.getState(), this.state.submitData, afterChangeInfo, this.state.changeDocumentImages,
            this.state.orderChangeDocument, mediumInfo, this.state.isNameDifference,
            this.state.isAddressDifference, this.state.isTelphoneDifference);

        let isChange: boolean = false;

        if (registerParams.changeParams.customerInfos.length === 1 &&
            registerParams.changeParams.customerInfos[0].changeCategory === CHANGECATEGORY.CHANGE) {
            isChange = true;
        } else if (registerParams.changeParams.customerInfos.length > 1) {
            isChange = true;
        }

        // 普通預金口座開設APIへの送信リクエストパラメータを作成
        registerParams.openAccountParams = this.makeOpeningAccountParams(
            this.loginStore.getState(), this.state.submitData, afterChangeInfo, isChange);

        return registerParams;
    }

    /**
     * 入力チェック結果を返す
     */
    public get disableFooterButton(): boolean {
        // 受付番号未入力　また　マスキングチェックボックスは存在かつ未チェック
        // もしくは　口座開設店舗確認がチェックされてない
        // もしくは　本人確認コードが99で有効期限が空欄の場合、押下不可とする。
        return !this.state.submitData.receptionNumber
            || (this.identityDocumentConfirmComponent.isShowCheckboxBlock() &&
                !this.state.checkboxStatus.isAllMaskingStatus) || !this.state.checkboxStatus.isCheckBranchStatus
            || (InputUtils.getIdentificationCodeWithChange(this.state.submitData) !== IdentificationCode.CODE_80 &&
                InputUtils.getIdentificationCodeWithChange(this.state.submitData) !== IdentificationCode.CODE_90 &&
                (!this.state.submitData.identificationDocument1ExpiryDate
                    || !this.state.submitData.identificationDocument1ExpiryDateText));
    }

    /**
     * footer button disable
     */
    public disableChangFooterButton() {
        if (this.state.submitData.isNameChange || this.state.submitData.isAddressChange
            || this.state.submitData.isTelphoneChange || this.state.isNameDifference
            || this.state.isAddressDifference || this.state.isTelphoneDifference) {
            return false;
        } else {
            return true;
        }
    }
    /**
     * 申込内容確認へ戻る
     */
    public clearConfirmPageInfo() {
        this.action.setStateData({ submitData: this.originSubmitData });
        this.action.clearConfirmPageInfo();
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.creditCardAction.clearConfirmPageInfo();
            // バックアップした運転免許証番号、学生証、連絡事項をクリア
            this.creditCardAction.clearCopyComplexTransConfirmInfos();
            this.clearStudentMaskingCheckBox();
        }
    }

    /**
     * 修正ボタン Emitハンドラー
     * @param params params
     */
    public showChatComponentHandler(params: ShowChartParam) {
        const modal = this.modalCtrl.create(ExistingSavingsConfirmPageChatComponent,
            {
                startOrder: params.startOrder, endOrder: params.endOrder, pageIndex: params.pageIndex,
                isCurrentPage: true, currentTitle: params.currentTitle
            },
            { cssClass: CssConsts.CSS_CLASS_FULL_MODAL, enableBackdropDismiss: false });
        modal.onDidDismiss((value) => {
            if (value !== undefined) {
                return;
            }
            this.editedList[params.name] = true;
            this.state.showConfirm.forEach((item) => {
                this.saveShowChats[item.name] = item;
            });
        });
        modal.present();
    }

    /**
     * 重複口座情報をセットする
     * @param event 重複口座情報
     */
    public getDuplicateAccountInfo(event: any) {
        this.store.registerSignalHandler(ExistingSavingsSignal.SET_DUPLICATE_ACCOUNT_INFO, () => {
            if (this.accountSelected) {
                this.getDuplicateAccountValid();
            }
        });
        this.action.setDuplicateAccountInfo(event);
    }

    /**
     * 顔写真のある本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedEmitter(event?: any) {
        this.insertImageType = event || this.insertImageType;
    }

    /**
     * 顔写真のない本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedNoFaceEmitter(event?: any) {
        this.insertImageTypeNoFace = event || this.insertImageTypeNoFace;
    }

    /**
     * handle accountSelectedEmitter
     */
    public handleAccountSelectedEmitter(accountSelected: boolean) {
        this.accountSelected = accountSelected;
        this.accountSelected ? this.getDuplicateAccountValid() : this.duplicateAccountValid = true;
    }

    /**
     * 重複口座情報の有効性をチェックする
     */
    public getDuplicateAccountValid() {
        this.duplicateAccountValid = this.state.submitData.redundantReason ? true : false;
    }

    /**
     * 総合口座文言表示フラグ設定
     */
    public hasComprehensiveDisplay(): boolean {
        if (this.duplicateAccountValid && this.state.submitData.hasComprehensive &&
            (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS)) {
            return true;
        }
        return false;
    }

    /**
     * update branch name
     */
    public updateBranchInfo(info) {
        this.action.updateBranchInfo(info);
    }

    public onChangeReceptionNumber(data) {
        this.action.setStateSubmitDataValue(data);
        this.action.updateSubmitDataBackup(data);
    }

    public onEditIdentityDocument() {
        const backup = Object.assign(new ExistingSavingsSubmitEntity(), this.state.submitData);

        this.action.setStateSubmitDataValue([{
            key: 'isModify',
            value: '1'
        }]);

        // 行員確認画面で本人確認書類１の有効期限が空欄のとき、
        // 修正チャットで必ず有効期限を聴取するために、
        // クリア状態を判別するためのフラグを設ける。
        if (!this.state.submitData.identificationDocument1ExpiryDate
            || !this.state.submitData.identificationDocument1ExpiryDateText) {
            // 有効期限のクリア判別フラグをtrueに更新する。
            this.action.setModifyExpiryDateExists(true);
        } else {
            // 有効期限のクリア判別フラグをfalseに更新する。
            this.action.setModifyExpiryDateExists(false);
        }
        // 再撮影した画像データでバックアップデータを更新させる
        const ocrImagesBackup = {
            // 本チャットで「運転経歴証明書」を選択し再撮影後
            // 「運転免許証」に変更した場合、holderCardImageFront,Backがクリアされundefinedとなるため
            // savingStoreから値を取得する
            holderCardImageFront: this.state.submitData.holderCardImageFront ?
                this.state.submitData.holderCardImageFront : this.savingStore.getState().submitData.holderCardImageFront,
            holderCardImageBack: this.state.submitData.holderCardImageBack ?
                this.state.submitData.holderCardImageBack : this.savingStore.getState().submitData.holderCardImageBack
        };
        // 有効期限バックアップ
        const ocrExpiry = {
            identificationDocument1ExpiryDate: this.state.submitData.identificationDocument1ExpiryDate,
            identificationDocument1ExpiryDateText: this.state.submitData.identificationDocument1ExpiryDateText
        };
        const identificationDocument1ImagesBackUp = {
            identificationDocument1Images: this.state.submitData.hasLicense === HasLicense.HAS_NOT_LICENSE
                && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES ?
                this.state.submitData.identificationDocument1Images : undefined
        };
        // 運転免許証・運転経歴証明書を持っているかをバックアップ
        const hasLicenseBackup = {
            hasLicense: this.state.submitData.hasLicense,
            hasDriversCareerLicense: this.state.submitData.hasDriversCareerLicense
        };
        const copyIsModify = this.state.submitData.isModify;
        const copyContactNote = this.state.submitData.contactNote;
        const copyIdentificationStudentImages = this.state.submitData.identificationStudentImages;
        // submitDataを画面初期のバックアップの状態にする
        this.action.setStateData({ submitData: this.state.copySubmitData });
        // 確認書類のクリア処理
        this.action.clearPartIdentificationDocument();

        // 修正チャットに送るのは修正された画像・有効期限
        const options = {
            component: 'SelfCheckApplyComponent',
            process: -1,
            submitData: {
                ...this.state.submitData,
                ...this.state.confirmPageChanges,
                ...ocrImagesBackup,
                ...ocrExpiry,
                ...identificationDocument1ImagesBackUp,
                ...hasLicenseBackup,
                isModify: copyIsModify,
                contactNote: copyContactNote,
                identificationStudentImages: copyIdentificationStudentImages
            }
        };
        const modal = this.modalCtrl.create(ExistingSavingsChatComponent, {
            options,
            isCurrentPage: true,
            currentTitle: '本人確認書類'
        }, {
            cssClass: 'full-modal'
        });

        modal.onDidDismiss((state: any) => {
            // 戻るボタン及び修正チャット完了時、有効期限のクリア判別フラグを初期化する。
            this.action.setModifyExpiryDateExists(false);
            if (state && state !== COMMON_CONSTANTS.DIMISS_CLOSE_VALUE) {
                // 本人確認画面が終わったら、maskingチェックボックスをリセット
                this.clearMaskingCheckBox();
                this.action.setStateData(state);
                // 運転経歴証明書の場合のクリア処理
                this.action.setStateDataForHasDriversCareerLicense();
                // 運転免許証の場合のクリア処理
                if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE
                    && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.NO) {
                    this.action.setStateSubmitDataValue([{ key: 'identificationDocument1Images', value: undefined }]);
                }
                // 最新の写真によってマスキング未確認データをセットする
                this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.DOCUMENT);
            } else {
                this.state.submitData = backup;
            }
        });

        return modal.present();
    }

    /**
     * 確認書類の写真だけを撮り直す
     *
     * @param {string} type
     * @memberof AccountComponent
     */
    public onReTakeIdentityDocument(params: { type: string, imgDocumentName: string }) {
        const config: any = {
            name: 'reimg',
            currentTitle: this._labels.confirm.reTakeDocument,
            pageIndex: 0,
            isCurrentPage: true
        };

        // OCR2枚
        if (params.type === LicensePhotoType.CARD_FRONT_AND_BACK) {
            config.startOrder = 60;
        }

        // OCR1枚
        if (params.type === LicensePhotoType.CARD_FRONT) {
            config.startOrder = 60;
            config.endOrder = 80;
        }

        const modal = this.modalCtrl.create(CommonBusinessChatComponent, {
            businessType: CommonBusinessType.ReImg,
            ...config
        }, {
            cssClass: 'full-modal'
        });
        modal.present();
        modal.onDidDismiss((data) => {
            // 「戻る」以外によってダイアログを閉じる場合
            if (data !== 'close') {
                if (params.type === LicensePhotoType.CARD_FRONT_AND_BACK) {
                    // OCR2枚。免許
                    this.action.editSomeDataInSubmitData(undefined,
                        'holderCardImageFront',
                        data.identityDocument[0]);
                    this.action.editSomeDataInSubmitData(undefined,
                        'holderCardImageBack',
                        data.identityDocument[1]);
                    this.action.resetSpecialNotMaskingConfirmImages('holderCardImageFront');
                    this.action.resetSpecialNotMaskingConfirmImages('holderCardImageBack');
                } else if (params.type === LicensePhotoType.CARD_FRONT) {
                    // OCR1枚
                    this.action.editSomeDataInSubmitData(undefined,
                        'holderCardImageFront',
                        data.identityDocument[0]);
                    this.action.resetSpecialNotMaskingConfirmImages('holderCardImageFront');
                } else {
                    // OCR以外の書類
                    // imgDocumentNameによって特定な写真を入れ替わる
                    this.action.editSomeDataInSubmitData(undefined,
                        params.imgDocumentName,
                        data.identityDocument);
                    this.action.resetSpecialNotMaskingConfirmImages(params.imgDocumentName);
                }
                this.clearMaskingCheckBox();
            }
        });
    }

    /**
     * 画像をクリックしたら画像修正モーダル開き
     *
     * @param {{ index: number, fieldName: string, value: string }} data
     * @memberof AccountComponent
     */
    public onImageMaskingComplete(data: { index: number, fieldName: string, value: string }) {
        this.action.editSomeDataInSubmitData(data.index, data.fieldName, data.value);
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.action.modifyCheckboxStatus(checboxItem);
    }

    public onMaskingConfirmEmmiterHandler(imageInfo: { documentName: string, index: number }) {
        this.action.removeNotMaskingConfirmImages(imageInfo);
    }

    // click 戻る button
    public backConfirmClick() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.existingSavings.clerk.changeBack
        );
        this.navCtrl.pop();
    }

    public filterInquiry() {
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                nameKanji: this.state.submitData.nameKanji,
                nameKana: this.state.submitData.nameKana,
                nameAlphabet: this.state.submitData.nameEnglish,
                birthdate: this.state.submitData.birthdate,
                address: this.state.submitData.address,
                bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
            }
        };

        const curFilteringParamters = new FilteringParameterEntity();
        curFilteringParamters.nameKanji = param.params.nameKanji;
        curFilteringParamters.nameKana = param.params.nameKana;
        curFilteringParamters.birthdate = param.params.birthdate;

        // 前回のパラメータと比較
        const isChanged = this.confirmUtil.isFilteringParameterChanged(this.state.lastFilteringParameter, curFilteringParamters);
        this.store.registerSignalHandler(ExistingSavingsSignal.FILTERING_INQUIRY, (data) => {
            this.store.unregisterSignalHandler(ExistingSavingsSignal.FILTERING_INQUIRY);
            this.action.updateSubmitDataBackup(data);
        });
        if (isChanged) {
            this.action.filterInquiry(param);
            // 今回のパラメータを保存
            this.action.setLastFilteringParameters(curFilteringParamters);
        } else {
            // 前回のフィルタリング照会結果を表示変数に渡す
            this.action.setLastFilteringResult(this.state.lastFilteringResult);
        }
    }

    /**
     * 画面の表示データを初期化する
     */
    private initShowData() {
        // 画面の表示データを初期化する
        this.state.showConfirm.forEach((item) => {
            if (item.type !== COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE) {
                this.saveShowChats[item.name] = item;
            }
        });
    }

    /**
     * 画面データ初期化する
     */
    private initPageData() {
        // 行員登録画面に遷移するとき、入力する行員IDを記録する
        this.action.setBankclerkId(this.modalDigitalStore.getState().bankclerkId);
        // 取次店番を記録する
        this.action.setAgencyBranchInfo(this.loginStore.getState().belongToBranchNo);
        // 受付店を口座開設店として記録する
        this.action.setBranchInfo(this.loginStore.getState().belongToBranchName, this.loginStore.getState().belongToBranchNo);
        // 行員認証開始時間を記録する
        this.action.setBankclerkAuthenticationStartDate();

        // 行員登録画面に遷移するとき、入力する行員IDを記録する
        this.action.setBankclerkId(this.modalDigitalStore.getState().bankclerkId);
    }

    /**
     * ページのタイトル
     */
    public get headerTitle(): string {
        if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
            return this.labels.existingSavings.title;
        } else if (this.state.submitData.accountType === AccountType.EXISTING_STORAGE) {
            return this.labels.existingStorage.title;
        }
    }

    /**
     * BC申込(複合取引)のパラメーター作成
     */
    private makeSubmitDataForBc(result?: any) {
        let submitData: any;
        submitData = this.processSubmitDataForBc();
        submitData.address = this.state.submitData.address;
        submitData.addressKana = this.state.submitData.addressKana;
        submitData.cardInfo = this.state.submitData.cardInfo;
        if (result.accountInfos && result.accountInfos.tenban && result.accountInfos.accountType && result.accountInfos.accountNo) {
            const complexAccountInfo = {
                branchNo: result.accountInfos.tenban,
                accountType: result.accountInfos.accountType,
                accountNo: result.accountInfos.accountNo,
            };
            submitData.complexAccountInfo = complexAccountInfo;
        }
        return submitData;
    }

    private processSubmitDataForBc(): any {
        // dataの加工処理を実行する
        return {
            tabletApplyId: this.state.submitData.tabletApplyId,
            receptionTenban: this.loginStore.getState().belongToBranchNo,
            nameKanji: this.state.submitData.nameKanji,
            nameKana: this.state.submitData.nameKana,
            nameNonConvert: this.state.submitData.nameNonConvert,
            gender: this.state.submitData.gender,
            genderText: this.state.submitData.genderText,
            birthdate: this.state.submitData.birthdate,
            customerId: this.state.submitData.customerId,
            zipCode: this.state.submitData.zipCode,
            holderTelNo1: this.state.submitData.holderTelNo1,
            holderTelNo2: this.state.submitData.holderTelNo2,
            occBusiness: this.state.submitData.holderCareer ? this.state.submitData.holderCareer.split('、') : undefined,
            workPlace: this.state.submitData.holderWorkPlace,
            accountOpeningPurpose:
                this.state.submitData.accountOpeningPurpose ? this.state.submitData.accountOpeningPurpose.split('、') : undefined,
            nationalityCode: this.state.submitData.nationalityCode,
            residenceFlagJapanOnly: this.state.submitData.isJapanLive,
            principalAgentCategory: this.state.submitData.isAgent,
            nameDifferenceFlag: this.state.submitData.isDifferenceKanji === '1' ? '1' : '0',
            addressDifferenceFlag: this.state.submitData.addressDifferenceFlag,
            bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
            operatorName: this.loginStore.getState().clerkInfo.operatorName,
            // 「フィルタリングシステム検索」APIから取得した「フィルタリングシステムの案件番号」
            outIssueNo: this.state.submitData.outIssueNo,
            // 「フィルタリングシステム検索」APIから取得した「照会結果」を設定
            outStatus: this.state.submitData.outStatus,
            passcode: this.rsaEncryptService.encrypt(this.state.submitData.firstPwd4bits),
            otherResidenceAddress: this.state.submitData.otherCountry,
            menuCode: '01',
            w9NameAlphabet: this.state.submitData.nameEnglish,
            nameAlphabet: this.state.submitData.nationalityCode === CountryCode.Japan ? undefined : this.state.submitData.nameAlphabet,
            w9AddressAlphabet: this.state.submitData.addressEnglish,
            w9CityNameAlphabet: this.state.submitData.cityOrTown,
            w9PrefecturesAlphabet: this.state.submitData.province,
            w9CountryNameAlphabet: this.state.submitData.agentCountryEnglish,
            w9SocialSecurityNo:
                this.state.submitData.socialSecurityNumber ? this.state.submitData.socialSecurityNumber.replace(/\-/g, '') : undefined,
            birthCountry: this.state.submitData.fatcaCountry,
            residenceCountryName: '0100',
            otherResidenceCountryName: this.state.submitData.agentCountry,
            accountOpeningBranchCode: this.state.submitData.cardInfo.branchNo,
            receiptMethod: this.state.submitData.receiptMethod || CodeCategory.RECEIPT_METHOD_MAIL,
            idInfoMethod: this.state.submitData.idInfoMethod,
            identificationDocument1: this.state.submitData.identificationDocument1,
            identificationDocument2: this.state.submitData.identificationDocument2,
            identificationDocument1Text: this.state.submitData.identificationDocument1Text,
            identificationDocument2Text: this.state.submitData.identificationDocument2Text,
            identificationDocument1ExpiryDate: this.state.submitData.identificationDocument1ExpiryDate,
            identificationDocument1ExpiryDateText: this.state.submitData.identificationDocument1ExpiryDateText,
            documentListName: this.state.submitData.documentListName,
            identificationDocument2ExpiryDate: this.state.submitData.identificationDocument2ExpiryDate,
            identificationDocument2ExpiryDateText: this.state.submitData.identificationDocument2ExpiryDateText,
            documentListName2: this.state.submitData.documentListName2,
            addressConfirmationDocumentName: this.state.submitData.addressConfirmationDocumentName,
            identificationAddressExpiryDate: this.state.submitData.identificationAddressExpiryDate,
            identificationAddressExpiryDateText: this.state.submitData.identificationAddressExpiryDateText,
            identificationCode: IdentificationCode.CODE_80,
            bankCardFlag: this.state.submitData.bankCardFlag,
            bankCardGoldFlag: this.state.submitData.bankCardGoldFlag,
            bankCardSuicaFlag: this.state.submitData.bankCardSuicaFlag,
            bankCardSuicaGoldFlag: this.state.submitData.bankCardSuicaGoldFlag,
            identificationDocument1Images: this.state.submitData.identificationDocument1Images,
            identificationDocument2Images: this.state.submitData.identificationDocument2Images,
            identificationAddressImages: this.state.submitData.identificationAddressImages,
            signatureCrs: this.state.submitData.sign,
            signatureFatca: this.state.submitData.signFatca,
            signatureOath: this.state.submitData.signOath,
            signatureAgree: this.state.submitData.signAgree,
            notAntisocialForceConsent: '1',
            agentLetterType: this.state.submitData.agentLetterType,
            ageClassification: this.state.submitData.ageClassification,
            birthdateWithAge: this.state.submitData.birthdateWithAge,
            receptionNumber: undefined,
        };
    }

    private clearMaskingCheckBox() {
        // 本人確認画面が終わったら、maskingチェックボックスをリセット
        if (this.state.checkboxStatus.isAllMaskingStatus) {
            this.action.modifyCheckboxStatus(MaskingCheckboxName.MASKING_CHECKBOX_NAME);
        }
    }

    private clearStudentMaskingCheckBox() {
        // 本人確認画面が終わったら、学生証のmaskingチェックボックスをリセット
        this.creditCardAction.callModifyCheckboxStatus(MaskingCheckboxName.STUDENT_CHECKBOX_NAME);
    }

    /**
     * 書類１はパスポート（所持欄記載なし）かどうかを判断
     *
     * @private
     * @param {string} identificationDocument1
     * @return {*}  {boolean}　true：パスポート（所持欄記載なし）　false：パスポート（所持欄記載なし）以外
     */
    private isDocumentOneNewPassport(identificationDocument1: string): boolean {
        return !StringUtils.isEmpty(identificationDocument1) && identificationDocument1
            === IdentificationDocumentCode.PASSPORT_WITHOUT_SELF_INPUT;
    }

    /**
     * 書類２はその他官公庁から発行された書類（顔写真なし）かどうかを判断
     *
     * @private
     * @param {string} identificationDocument2
     * @return {*}  {boolean}　true：他官公庁から発行された書類（顔写真なし）　false：他官公庁から発行された書類（顔写真なし）以外
     */
    private isDocumentTwoOther(identificationDocument2: string): boolean {
        return !StringUtils.isEmpty(identificationDocument2) && identificationDocument2
            === IdentificationDocumentCode.OTHER_IDENTIFICATION_NO_PHOTO_DOCUMENT;
    }

    /**
     * SMS受信可能で携帯保有有無
     *
     * @returns
     */
    private hasExistingSmsMobilePhoneNumber(): string {

        const {
            holderTelNo1, holderTelNo2, holderTelNo3,
            holderMobileNo, holderTelephoneNo, isSmsPhone, existingChangeHolderMobileNo,
            existingChangeHolderTelephoneNo } = this.state.submitData;

        if (holderMobileNo && Constants.REGEXP_MOBILE_WITH_DASH.test(holderMobileNo) && isSmsPhone === '1') {
            return Constants.HAS_EXISTS_MOBILE_NO;
        } else if (existingChangeHolderMobileNo
            && Constants.REGEXP_MOBILE_WITH_DASH.test(existingChangeHolderMobileNo) && isSmsPhone === '1') {
            return Constants.HAS_EXISTS_MOBILE_NO;
        } else if (
            // 既存顧客かつ、携帯登録ありかつ、SMS受信あり
            (holderMobileNo === undefined && holderTelephoneNo === undefined && isSmsPhone === '1')
            && (existingChangeHolderMobileNo === undefined && existingChangeHolderTelephoneNo === undefined && isSmsPhone === '1')
            && (holderTelNo1 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo1)
                || holderTelNo2 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo2)
                || holderTelNo3 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo3)
            )) {
            return Constants.HAS_EXISTS_MOBILE_NO;
        }

        return Constants.NO_EXISTS_MOBILE_NO;
    }

    /* 普通預金口座開設APIへ送信する顧客情報リストを作成
    *
    * @param submitData
    * @param afterChangeInfo 変更後の情報
    * @param changeDocumentImages 本人確認書類（画像ファイル）
    * @param _orderChangeDocument 本人確認書類コードリスト
    * @param mediumInfo 口座解約情報
    * @param isNameDifference
    * @param isAddressDifference
    * @param isTelphoneDifference
    * @returns
    */
    private makeOpeningAccountParams(loginState: LoginState, submitData: any, afterChangeInfo: any, isChange: boolean): any[] {
        const openAccountParams: any = {};
        // 取次店番
        openAccountParams.receptionTenban = loginState.belongToBranchNo;
        // EQ番号
        openAccountParams.eyeCueNo = submitData.receptionNumber;
        // 行員ID
        openAccountParams.bankClerkId = loginState.clerkInfo.bankClerkId;
        // オペレータ氏名
        openAccountParams.operatorName = loginState.clerkInfo.operatorName;
        // 届出変更有無
        openAccountParams.hasChange = isChange ? '1' : '0';
        // BC申込有無
        openAccountParams.ifApplyBc = '0';

        // BC申込パラメータ
        // TODO
        const customerInfos = [];
        let customerInfo: any; // swipeCif

        // 新規口座扱い場合
        if (this.state.submitData.isNewCustomerFlg) {
            const customerSelfInfo = submitData.allCifInfos.find((cifInfo) => cifInfo.customerId === submitData.customerId);
            customerInfo = this.makeOpenAccountParamNew(afterChangeInfo, loginState, submitData, customerSelfInfo);
            customerInfos.push(customerInfo);
        } else {
            const customerSelfInfo = submitData.allCifInfos.find(
                (cifInfo) => cifInfo.customerId === InputUtils.getCustomerIdWithChange(this.state.submitData));
            // スワイプ先のパラメータ生成
            customerSelfInfo.customerId = InputUtils.getCustomerIdWithChange(this.state.submitData);
            customerSelfInfo.identificationCode = InputUtils.getIdentificationCodeWithChange(this.state.submitData);
            customerInfo = this.makeOpenAccountParam(afterChangeInfo, loginState, submitData, customerSelfInfo, AccountCategory.YES);
            customerInfos.push(customerInfo);

            // 名寄せ先のパラメータ生成
            submitData.allCifInfos.forEach((cifInfo) => {
                if (cifInfo.customerId !== customerSelfInfo.customerId) {
                    customerInfo = this.makeOpenAccountParam(afterChangeInfo, loginState, submitData, cifInfo, AccountCategory.NO);
                    customerInfos.push(customerInfo);
                }
            });
        }

        openAccountParams.customerInfos = customerInfos;

        return openAccountParams;
    }

    /**
     * 口座開設のパラメータ作成
     *
     * @param afterChangeInfo
     * @param loginState
     * @param submitData
     * @param cifInfo
     */
    private makeOpenAccountParam(afterChangeInfo: any, loginState: LoginState, submitData: any, cifInfo: any, accountCategory: string) {
        const customerInfo: any = {};
        // EQ番号
        customerInfo.eyeCueNo = submitData.receptionNumber;
        // 行員ID
        customerInfo.bankClerkId = loginState.clerkInfo.bankClerkId;
        // オペレータ氏名
        customerInfo.operatorName = loginState.clerkInfo.operatorName;
        // 顧客番号
        customerInfo.customerId = cifInfo.customerId;
        // 本人確認コード
        customerInfo.identificationCode = cifInfo.identificationCode;
        // 普通口座開設区分
        customerInfo.accountCategory = accountCategory;
        // 名義人ー氏名（フリガナ）
        customerInfo.nameKana = this.changeUtils.returnDefValByFlg(submitData.isNameChange,
            afterChangeInfo.holderNameFurigana, submitData.nameKana);
        // 名義人ー氏名
        customerInfo.nameKanji = this.changeUtils.returnDefValByFlg(submitData.isNameChange,
            afterChangeInfo.holderName, submitData.nameKanji);
        // 英文氏名
        customerInfo.nameAlphabet = this.changeUtils.returnDefValByFlg(submitData.isNameChange,
            afterChangeInfo.holderNameAlphabet, submitData.nameAlphabet);
        // 名義人ー生（設立）年月日（西暦）
        customerInfo.birthdate = submitData.birthdate;
        // 郵便番号
        customerInfo.zipCode = this.changeUtils.returnDefValByFlg(submitData.isAddressChange,
            afterChangeInfo.holderZipCode ? afterChangeInfo.holderZipCode.replace(/\-/g, '') : undefined);
        // 名義人ー住所・都道府県
        customerInfo.prefecture = this.changeUtils.returnDefValByFlg(submitData.isAddressChange, afterChangeInfo.holderAddressPrefecture);
        // 名義人ー住所・市区町村
        customerInfo.countyUrbanVillage = this.changeUtils.returnDefValByFlg(
            submitData.isAddressChange, afterChangeInfo.holderAddressCountyUrbanVillage);
        // 名義人ー住所・町丁名
        customerInfo.street = this.changeUtils.returnDefValByFlg(submitData.isAddressChange, afterChangeInfo.holderAddressStreetName);
        // 名義人ー住所・都道府県（フリカナ）
        customerInfo.prefectureKana = this.changeUtils.returnDefValByFlg(
            submitData.isAddressChange, afterChangeInfo.holderAddressPrefectureFuriKana);
        // 名義人ー住所・市区町村（フリカナ）
        customerInfo.countyUrbanVillageKana = this.changeUtils.returnDefValByFlg(
            submitData.isAddressChange, afterChangeInfo.holderAddressCountyUrbanVillageFuriKana);
        // 名義人ー住所・町丁名（フリカナ）
        customerInfo.streetKana = this.changeUtils.returnDefValByFlg(
            submitData.isAddressChange, afterChangeInfo.holderAddressStreetNameFuriKana);
        // 名義人ー住所・番地以降（フリカナ）
        customerInfo.subAddressKana = this.changeUtils.returnDefValByFlg(
            submitData.isAddressChange, afterChangeInfo.holderAddressHouseNumberFuriKana);
        // 名義人ー住所・番地以降
        customerInfo.subAddress = this.changeUtils.returnDefValByFlg(submitData.isAddressChange, afterChangeInfo.holderAddressHouseNumber);
        // 名義人ー携帯電話番号
        customerInfo.mobilePhoneNo = this.changeUtils.returnDefValByFlg(submitData.isTelphoneChange, afterChangeInfo.holderMobileNo ?
            afterChangeInfo.holderMobileNo : undefined);
        // 名義人ーその他電話番号
        customerInfo.otherPhoneNo = this.changeUtils.returnDefValByFlg(submitData.isTelphoneChange, afterChangeInfo.holderTelephoneNo ?
            afterChangeInfo.holderTelephoneNo : undefined);
        customerInfo.occBusiness = submitData.holderCareer ? submitData.holderCareer.split('、') : undefined;
        // 名義人ー勤め先名称
        customerInfo.workPlace = submitData.holderWorkPlace;
        // 口座開設の取引目的
        customerInfo.accountOpeningPurpose =
            submitData.accountOpeningPurpose ? submitData.accountOpeningPurpose.split('、') : undefined;
        // 国籍コード
        customerInfo.nationalityCode = cifInfo.nationality;
        // 日本のみ居住フラグ
        customerInfo.residenceFlagJapanOnly = submitData.isJapanLive;
        // 本人代理人区分
        customerInfo.principalAgentCategory = submitData.isAgent;
        // 氏名の漢字相違チェック
        customerInfo.nameDifferenceFlag = submitData.isDifferenceKanji;
        // 住所相違フラグ
        customerInfo.addressDifferenceFlag = submitData.isDifferenceAddress;
        // フィルタリング案件番号
        customerInfo.outIssueNo = submitData.outIssueNo;
        // フィルタリング該当有無
        customerInfo.outStatus = submitData.outStatus;
        // 暗証番号
        customerInfo.passcode = this.rsaEncryptService.encrypt(submitData.firstPwd4bits);
        // 第2の居住地住所
        customerInfo.otherResidenceAddress = submitData.otherCountry;
        // メニューコード
        customerInfo.menuCode = '01';
        // W9情報
        customerInfo.w9NameAlphabet = submitData.nameEnglish;
        customerInfo.w9AddressAlphabet = submitData.addressEnglish;
        customerInfo.w9CityNameAlphabet = submitData.cityOrTown;
        customerInfo.w9PrefecturesAlphabet = submitData.province;
        customerInfo.w9CountryNameAlphabet = submitData.agentCountryEnglish;
        customerInfo.w9SocialSecurityNo =
            submitData.socialSecurityNumber ? submitData.socialSecurityNumber.replace(/\-/g, '') : undefined;
        // 米国人示唆情報
        const fatcaStasus = this.confirmUtil.getFatcaStatusTextJp(
            this.state.submitData.isGreenCardHave, this.state.submitData.fatcaStatus);
        // 米国人示唆情報、　this.state.submitData.w9AmericanSuggestionInfo,の利用は廃止する。
        customerInfo.w9AmericanSuggestionInfo = fatcaStasus.americanSuggestionInfo;
        // 出生国
        customerInfo.birthCountry = submitData.fatcaCountry;
        // 居住地国
        customerInfo.residenceCountryName = CountryCode.Japan;
        // 居住地国（その他）
        customerInfo.otherResidenceCountryName = submitData.agentCountry;
        // 口座開設店番号
        customerInfo.accountOpeningBranchCode = InputUtils.getTenbanWithChange(submitData);
        // カード交付方法
        customerInfo.receiptMethod = submitData.receiptMethod || CodeCategory.RECEIPT_METHOD_MAIL;
        // 本人確認方法
        // 本人確認書類１がパスポート（所持欄記載なし）場合「04」を設定、以外の場合は既存通り
        customerInfo.idInfoMethod = this.isDocumentOneNewPassport(submitData.identificationDocument1) ?
            IdentificationDocumentMethod.PRESENT_ONE_ADDRESS_TYPE : this.idInfoMethod();
        // 本人確認資料1
        customerInfo.idInfoDoc1 = this.idInfoDoc1();
        // 本人確認資料2
        // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
        customerInfo.idInfoDoc2 = this.isDocumentOneNewPassport(submitData.identificationDocument1) ?
            undefined : submitData.identificationDocument2;
        // 本人確認書類1有効期限
        customerInfo.identityDocument1ExpirationDate = submitData.identificationDocument1ExpiryDate;
        // 本人確認書類2有効期限
        // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
        customerInfo.identityDocument2ExpirationDate = this.isDocumentOneNewPassport(submitData.identificationDocument1) ?
            undefined : submitData.identificationDocument2ExpiryDate;
        // 本人確認書類１その他の場合の具体的書類名等
        customerInfo.identityDocument1Name = submitData.documentListName;
        // 本人確認書類２その他の場合の具体的書類名等-
        // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
        customerInfo.identityDocument2Name = this.isDocumentOneNewPassport(submitData.identificationDocument1) ?
            undefined : submitData.documentListName2;
        // 現住所確認書類具体的書類名等
        // 本人確認書類１がパスポート（所持欄記載なし）場合 かつ　書類２がその他場合、入力書類名を設定。書類２が以外の場合、ボタン名を設定
        // 本人確認書類１がパスポート（所持欄記載なし）以外場合既存通り
        customerInfo.addressConfirmationDocumentName =
            (this.isDocumentOneNewPassport(submitData.identificationDocument1)
                && !StringUtils.isEmpty(submitData.identificationDocument2)) ?
                (this.isDocumentTwoOther(submitData.identificationDocument2) ?
                    submitData.documentListName2 :
                    submitData.identificationDocument2Text) :
                submitData.addressConfirmationDocumentName;
        // 現住所確認書類有効期限
        // 本人確認書類１がパスポート（所持欄記載なし）場合「本人確認書類２の有効期間」を設定、以外の場合は既存通り
        customerInfo.addressConfirmationDocumentExpirationDate = (this.isDocumentOneNewPassport(submitData.identificationDocument1)
            && !StringUtils.isEmpty(submitData.identificationDocument2)) ?
            submitData.identificationDocument2ExpiryDate :
            submitData.identificationAddressExpiryDate;
        // 本人確認書類1（画像ファイル）
        customerInfo.imageDoc1 = this.imageDoc1();
        // 本人確認書類2（画像ファイル）
        // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
        customerInfo.imageDoc2 = this.isDocumentOneNewPassport(submitData.identificationDocument1) ?
            undefined : submitData.identificationDocument2Images;
        // 本人現住所確認書類（画像ファイル）
        // 本人確認書類１がパスポート（所持欄記載なし）場合「本人確認書類２の画像」を設定、以外の場合は既存通り
        customerInfo.imageAddressDoc = (this.isDocumentOneNewPassport(submitData.identificationDocument1)
            && !StringUtils.isEmpty(submitData.identificationDocument2)) ?
            submitData.identificationDocument2Images :
            submitData.identificationAddressImages;
        // CRSのサイン
        customerInfo.signatureCrs = submitData.sign;
        // FATCAのサイン
        customerInfo.signatureFatca = submitData.signFatca;
        // W9の宣誓サイン
        customerInfo.signatureOath = submitData.signOath;
        // W9の同意サイン
        customerInfo.signatureAgree = submitData.signAgree;
        // 店番号(代表口座）
        const ibInfo = this.creditCardUtil.getIbInfo(submitData);
        customerInfo.ibBranchCode = ibInfo ? ibInfo.branchCode : undefined;
        // 科目コード(代表口座）
        customerInfo.ibSubjectCode = ibInfo ? ibInfo.subjectCode : undefined;
        // 口座番号(代表口座）
        customerInfo.ibBankAccountId = ibInfo ? ibInfo.bankAccountId : undefined;
        // サービス利用区分
        customerInfo.serviceCategory =
            ibInfo && ibInfo.ibContractInfo.serviceCategory === ServiceCategory.TB_ONLY ? ServiceCategory.IB : undefined;
        // バンクカード申込フラグ
        customerInfo.bankCardFlag = this.state.submitData.bankCardFlag;
        // バンクカードゴールド申込フラグ
        customerInfo.bankCardGoldFlag = this.state.submitData.bankCardGoldFlag;
        // バンクカードSuicaゴールド申込フラグ
        customerInfo.bankCardSuicaFlag = this.state.submitData.bankCardSuicaFlag === IsBankCardSuicaSelected.IS_SELECTED ||
            this.state.submitData.bankCardSuicaGoldFlag === IsBankCardSuicaGoldSelected.IS_SELECTED ?
            IsBankCardSuicaSelected.IS_SELECTED : IsBankCardSuicaSelected.IS_NOT_SELECTED;
        customerInfo.existsSmsMobileNoFlg = this.hasExistingSmsMobilePhoneNumber();
        customerInfo.isNeedPassbook = this.state.submitData.isNeedPassbook; // 通帳発行するかどうか　１：発行　０：発行しない

        // 基準特例
        customerInfo.confirmPurpose = submitData.confirmPurpose;

        return customerInfo;
    }

    // 純新規、開設店舗に顧客CIFがないです
    private makeOpenAccountParamNew(afterChangeInfo: any, loginState: LoginState, submitData: any, cifInfo: any) {
        const customerInfo: any = {};

        // 名義人ー氏名
        customerInfo.nameKanji = this.changeUtils.returnDefValByFlg(submitData.isNameChange,
            afterChangeInfo.holderName, submitData.nameKanji);
        // 名義人ー氏名（フリガナ）
        customerInfo.nameKana = this.changeUtils.returnDefValByFlg(submitData.isNameChange,
            afterChangeInfo.holderNameFurigana, submitData.nameKana);
        // 性別
        customerInfo.gender = submitData.gender;
        // 生年月日
        customerInfo.birthdate = submitData.birthdate;
        // 顧客ID
        customerInfo.customerId = undefined;
        // 顧客番号
        customerInfo.identificationCode = undefined;
        // 郵便番号
        customerInfo.zipCode = this.changeUtils.returnDefValByFlg(submitData.isAddressChange,
            afterChangeInfo.holderZipCode ? afterChangeInfo.holderZipCode.replace(/\-/g, '') : undefined,
            cifInfo.addressInfo.postCode ? cifInfo.addressInfo.postCode.replace(/\-/g, '') : undefined);

        // 住所変更あり場合、純新規口座として変更後の住所を使って口座開設する
        if (submitData.isAddressChange) {
            // 名義人ー住所・都道府県
            customerInfo.prefecture = submitData.holderAddressPrefecture;
            // 名義人ー住所・市区町村
            customerInfo.countyUrbanVillage = submitData.holderAddressCountyUrbanVillage;
            // 名義人ー住所・町丁名
            customerInfo.street = submitData.getHolderAddressStreetName();
            // 名義人ー住所・番地以降
            customerInfo.subAddress = submitData.holderAddressHouseNumber;
            // 名義人ー住所・都道府県（フリカナ）
            customerInfo.prefectureKana = submitData.holderAddressPrefectureFuriKana;
            // 名義人ー住所・市区町村（フリカナ）
            customerInfo.countyUrbanVillageKana = submitData.holderAddressCountyUrbanVillageFuriKana;
            // 名義人ー住所・町丁名（フリカナ）
            customerInfo.streetKana = submitData.getHolderAddressStreetNameFuriKana();
            // 名義人ー住所・番地以降（フリカナ）
            customerInfo.subAddressKana = submitData.holderAddressHouseNumberFuriKana;
        } else {
            customerInfo.addressCode = cifInfo.addressInfo.addressCode;
            customerInfo.kanjiAddress = cifInfo.addressInfo.kanjiAddress;
            customerInfo.kanaAddress = cifInfo.addressInfo.kanaAddress;
        }

        const mixTels = InputUtils.getHolderTelKindsNo(submitData);
        // 携帯電話
        customerInfo.mobilePhoneNo = this.changeUtils.returnDefValByFlg(
            submitData.isTelphoneChange,
            afterChangeInfo.holderMobileNo ? afterChangeInfo.holderMobileNo : undefined,
            mixTels.phoneTels.length > 0 ? mixTels.phoneTels[0] : undefined);
        // 固定電話
        customerInfo.otherPhoneNo = this.changeUtils.returnDefValByFlg(
            submitData.isTelphoneChange,
            afterChangeInfo.holderTelephoneNo ? afterChangeInfo.holderTelephoneNo : undefined,
            mixTels.others.length > 0 ? mixTels.others[0] : undefined);
        // 職業
        customerInfo.occBusiness = submitData.holderCareer ? submitData.holderCareer.split('、') : undefined;
        // 勤務場所
        customerInfo.workPlace = submitData.holderWorkPlace;
        // 口座開設目的
        customerInfo.accountOpeningPurpose = submitData.accountOpeningPurpose ?
            submitData.accountOpeningPurpose.split('、') : undefined;
        // 国籍コード
        customerInfo.nationalityCode = submitData.nationalityCode;
        // 日本のみ居住フラグ
        customerInfo.residenceFlagJapanOnly = submitData.isJapanLive;
        // 本人代理人区分
        customerInfo.principalAgentCategory = submitData.isAgent;
        // 氏名の漢字相違チェック
        customerInfo.nameDifferenceFlag = submitData.isDifferenceKanji;
        // 住所相違フラグ
        customerInfo.addressDifferenceFlag = submitData.isDifferenceAddress;
        // フィルタリング案件番号
        customerInfo.outIssueNo = submitData.outIssueNo;
        // フィルタリング該当有無
        customerInfo.outStatus = submitData.outStatus;
        // 暗証番号
        customerInfo.passcode = this.rsaEncryptService.encrypt(submitData.firstPwd4bits);
        // 第2の居住地住所
        customerInfo.otherResidenceAddress = submitData.otherCountry;
        // メニューコード
        customerInfo.menuCode = '01';
        // W9情報
        customerInfo.w9NameAlphabet = submitData.nameEnglish;
        customerInfo.w9AddressAlphabet = submitData.addressEnglish;
        customerInfo.w9CityNameAlphabet = submitData.cityOrTown;
        customerInfo.w9PrefecturesAlphabet = submitData.province;
        customerInfo.w9CountryNameAlphabet = submitData.agentCountryEnglish;
        customerInfo.w9SocialSecurityNo =
            submitData.socialSecurityNumber ? submitData.socialSecurityNumber.replace(/\-/g, '') : undefined;
        // 米国人示唆情報
        const fatcaStasus = this.confirmUtil.getFatcaStatusTextJp(
            this.state.submitData.isGreenCardHave, this.state.submitData.fatcaStatus);
        // 米国人示唆情報、　this.state.submitData.w9AmericanSuggestionInfo,の利用は廃止する。
        customerInfo.w9AmericanSuggestionInfo = fatcaStasus.americanSuggestionInfo;
        // 店番号(代表口座）
        const ibInfo = this.creditCardUtil.getIbInfo(submitData);
        customerInfo.ibBranchCode = ibInfo ? ibInfo.branchCode : undefined;
        // 科目コード(代表口座）
        customerInfo.ibSubjectCode = ibInfo ? ibInfo.subjectCode : undefined;
        // 口座番号(代表口座）
        customerInfo.ibBankAccountId = ibInfo ? ibInfo.bankAccountId : undefined;
        // サービス利用区分
        customerInfo.serviceCategory =
            ibInfo && ibInfo.ibContractInfo.serviceCategory === ServiceCategory.TB_ONLY ? ServiceCategory.IB : undefined;
        // remainingPeriod 外人だけ
        // 出生国
        customerInfo.birthCountry = submitData.fatcaCountry;
        // 居住地国
        customerInfo.residenceCountryName = CountryCode.Japan;
        // 居住地国（その他）
        customerInfo.otherResidenceCountryName = submitData.agentCountry;
        // 口座開設店番号
        customerInfo.accountOpeningBranchCode = InputUtils.getTenbanWithChange(submitData);
        // カード交付方法
        customerInfo.receiptMethod = submitData.receiptMethod || CodeCategory.RECEIPT_METHOD_MAIL;
        // 本人確認方法
        // 本人確認書類１がパスポート（所持欄記載なし）場合「04」を設定、以外の場合は既存通り
        customerInfo.idInfoMethod = this.isDocumentOneNewPassport(submitData.identificationDocument1) ?
            IdentificationDocumentMethod.PRESENT_ONE_ADDRESS_TYPE : this.idInfoMethod();
        // 本人確認資料1
        customerInfo.idInfoDoc1 = this.idInfoDoc1();
        // 本人確認資料2
        // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
        customerInfo.idInfoDoc2 = this.isDocumentOneNewPassport(submitData.identificationDocument1) ?
            undefined : submitData.identificationDocument2;
        // 本人確認書類1有効期限
        customerInfo.identityDocument1ExpirationDate = submitData.identificationDocument1ExpiryDate;
        // 本人確認書類１その他の場合の具体的書類名等
        customerInfo.identityDocument1Name = submitData.documentListName;
        // 本人確認書類2有効期限
        // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
        customerInfo.identityDocument2ExpirationDate = this.isDocumentOneNewPassport(submitData.identificationDocument1) ?
            undefined : submitData.identificationDocument2ExpiryDate;
        // 本人確認書類２その他の場合の具体的書類名等-
        // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
        customerInfo.identityDocument2Name = this.isDocumentOneNewPassport(submitData.identificationDocument1) ?
            undefined : submitData.documentListName2;
        // 現住所確認書類具体的書類名等
        // 本人確認書類１がパスポート（所持欄記載なし）場合 かつ　書類２がその他場合、入力書類名を設定。書類２が以外の場合、ボタン名を設定
        // 本人確認書類１がパスポート（所持欄記載なし）以外場合既存通り
        customerInfo.addressConfirmationDocumentName =
            (this.isDocumentOneNewPassport(submitData.identificationDocument1)
                && !StringUtils.isEmpty(submitData.identificationDocument2)) ?
                (this.isDocumentTwoOther(submitData.identificationDocument2) ?
                    submitData.documentListName2 :
                    submitData.identificationDocument2Text) :
                submitData.addressConfirmationDocumentName;
        // 現住所確認書類有効期限
        // 本人確認書類１がパスポート（所持欄記載なし）場合「本人確認書類２の有効期間」を設定、以外の場合は既存通り
        customerInfo.addressConfirmationDocumentExpirationDate = (this.isDocumentOneNewPassport(submitData.identificationDocument1)
            && !StringUtils.isEmpty(submitData.identificationDocument2)) ?
            submitData.identificationDocument2ExpiryDate :
            submitData.identificationAddressExpiryDate;
        // 本人確認書類1（画像ファイル）
        customerInfo.imageDoc1 = this.imageDoc1();
        // 本人確認書類2（画像ファイル）
        // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
        customerInfo.imageDoc2 = this.isDocumentOneNewPassport(submitData.identificationDocument1) ?
            undefined : submitData.identificationDocument2Images;
        // 本人現住所確認書類（画像ファイル）
        // 本人確認書類１がパスポート（所持欄記載なし）場合「本人確認書類２の画像」を設定、以外の場合は既存通り
        customerInfo.imageAddressDoc = (this.isDocumentOneNewPassport(submitData.identificationDocument1)
            && !StringUtils.isEmpty(submitData.identificationDocument2)) ?
            submitData.identificationDocument2Images :
            submitData.identificationAddressImages;
        // CRSのサイン
        customerInfo.signatureCrs = submitData.sign;
        // FATCAのサイン
        customerInfo.signatureFatca = submitData.signFatca;
        // W9の宣誓サイン
        customerInfo.signatureOath = submitData.signOath;
        // W9の同意サイン
        customerInfo.signatureAgree = submitData.signAgree;
        // customerInfo.existsSmsMobileNoFlg = this.hasExistingSmsMobilePhoneNumber();
        customerInfo.isSmsPhone = submitData.isSmsPhone;
        customerInfo.isNeedPassbook = submitData.isNeedPassbook; // 通帳発行するかどうか　１：発行　０：発行しない

        // 基準特例
        customerInfo.confirmPurpose = submitData.confirmPurpose;

        return customerInfo;
    }

    /**
     * 本人確認書類１
     */
    private idInfoDoc1() {
        if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
            // OCR読み取りの場合、画面で選択した本人確認資料　01：運転免許証 or 08：個人番号カード
            return this.state.submitData.hasLicense;
        }
        return this.state.submitData.identificationDocument1;
    }

    /**
     * 本人確認書類1（画像ファイル）
     */
    private imageDoc1() {
        if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
            // OCR読み取りの場合、OCRから取得した画像ファイル
            if (this.state.submitData.hasLicense === Constants.DriveCard) {
                return this.state.submitData.holderCardImageFront && this.state.submitData.holderCardImageBack ?
                    [this.state.submitData.holderCardImageFront, this.state.submitData.holderCardImageBack] : undefined;
            } else if (this.state.submitData.hasLicense === Constants.MyNumberCard) {
                return this.state.submitData.holderCardImageFront ? [this.state.submitData.holderCardImageFront] : undefined;
            } else {
                return undefined;
            }
        }
        return this.state.submitData.identificationDocument1Images;
    }

    /**
     * 本人確認方法
     */
    private idInfoMethod() {
        if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
            // OCR読み取りの場合、01：1種類提示
            return '01';
        }
        return this.state.submitData.idInfoMethod;
    }

}
