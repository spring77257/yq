import { Injectable, NgZone } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { LabelService } from 'adep/services/label.service';
import { AppProperties } from 'app.properties';
import { OCREntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/ocr.entity';
import { BranchNameListEntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { BcSuicaResult, CashCardDeliveryType } from 'dhdt/branch/pages/change/change-consts';
import { ChangeDifferenceEntity } from 'dhdt/branch/pages/change/entity/change-questions.model';
import {
    AcceptCheckKeyType, AccountType, AddressMaxLengthArr,
    Age,
    ClearSavingImagesClickRecordType, ClearWorkOrCrs, CodeCategory, COMMON_CONSTANTS, Constants, CountryCode,
    DirectApplyExpectationType, HasDriversCareerLicense, HasLicense, HolderAgeRange, HostErrorCodeReceptionNG, IdentificationDocumentCode,
    IdentificationDocumentMethod,
    NameNonConvert, OutStatus, OutStatusText,
    PointServiceExpectation, PointServiceType, StoreChanged, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { MediumInfosResponse } from 'dhdt/branch/pages/common/entity/medium-infos-response.entity';
import { ExistingSavingsActionType } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { CheckboxStatusChangeEntity } from 'dhdt/branch/pages/existing-savings/entity/checbox-status-change.entity';
import { CheckboxStatusEntity } from 'dhdt/branch/pages/existing-savings/entity/checbox-status.entity';
import {
    AllCiftradingConditions,
    DropDownListEntity, ExistingSavingsQuestionsModel, ExistingSavingsSubmitEntity, PageQuestionsModel, TradingConditionCode
} from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { DBConsts, RenderType } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import {
    ReceptionLossCorruptionCheckRequest
} from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-request.entity';
import {
    ReceptionCheckAccountInfo, ReceptionLossCorruptionCheckResponse
} from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-response.entity';
import {
    AcceptionResult, AcceptionResultAccount, AcceptionResultTradingCondition
} from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { CifInfoInquiryResponseEntity } from 'dhdt/branch/shared/entity/cif-info-inquiry-response.entity';
import { DuplicateAccountEntity } from 'dhdt/branch/shared/entity/duplicate-account.entity';
import { FilteringParameterEntity } from 'dhdt/branch/shared/entity/filtering-parameter.entity';
import { RegionCodeEntity } from 'dhdt/branch/shared/entity/region-code.entity';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { CifInformationUtils } from 'dhdt/branch/shared/utils/cif-information-utils';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';
import { Observable } from 'rxjs/Observable';

export interface ExistingSavingsState extends State {
    questions: ExistingSavingsQuestionsModel[][];
    showChats: PageQuestionsModel[];
    showConfirm: PageQuestionsModel[];
    submitData: ExistingSavingsSubmitEntity;
    tabletStartDate: string;
    tabletApplyId: number;
    copySubmitData: ExistingSavingsSubmitEntity;
    dropDownList: DropDownListEntity[];
    checkboxStatus: CheckboxStatusEntity;
    cifInfoInquiryList: CifInfoInquiryResponseEntity[];
    currentFileInfo: any;
    identityDocuments: string[];
    additionalInfoDocuments: string[];
    duplicateAccountInfos: any[];
    confirmPageChanges: any;
    lastFilteringParameter: FilteringParameterEntity;
    lastFilteringResult: any;
    acceptCheckResult: Array<{ keyType: string, key: string, value: AcceptionResultAccount }>;
    transactionList: AcceptionResultTradingCondition[]; // 取引ぶりリストを格納
    isNameChanged: boolean;
    isAddressChanged: boolean;
    isTelphoneChanged: boolean;
    isAddressDifference: boolean; // 住所差分あるかどうか
    isNameDifference: boolean; // 名前差分あるかどうか
    isTelphoneDifference: boolean; // 電話番号差分あるかどうか
    isAddressDifferenceBackup: boolean; // 住所差分バックアップ
    isNameDifferenceBackup: boolean; // 名前差分バックアップ
    isTelphoneDifferenceBackup: boolean; // 電話番号差分バックアップ
    isSelectedSkipButtonA: boolean; // 本人確認チャットで書類パターンA聴取時、スキップボタンが押下されたか
    isSelectedSkipButtonB: boolean; // 本人確認チャットで書類パターンB聴取時、スキップボタンが押下されたか
    changeDocumentImages: any; // 本人確認チャットのでの撮影写真（パターンXABC）
    orderChangeDocument: string[]; // 書類の撮影順の格納
    orderChangeDocumentName: string[]; // 書類の撮影順の書類名格納
    checkboxStatusForChange: CheckboxStatusChangeEntity;
    nameIdentiAddressImage: any; // 名寄せ処理中に撮影した住所資料
    // 各書類の画像について、masking確認完了されたない画像のIndexを格納するオブジェクト
    notMaskingConfirmImages: {
        holderCardImageFront: boolean,
        holderCardImageBack: boolean,
        identificationDocument1Images: number[],    // 本人確認書類１
        identificationDocument2Images: number[],    // 本人確認書類２
        identificationAddressImages: number[],   // 住所確認書類
        changeDocumentImages: number[]   // 届出変更本人確認チャットのでの撮影写真（パターンXABC）
        nameIdentiAddressImage: number[],
        identificationStudentImages: number[] // 学生証
    };
    regionCodeInfo: RegionCodeEntity;
    icData: string;
    ocrEntity: OCREntity;
    modifyExpiryDateExists: boolean;
}

export const ExistingSavingsSignal = {
    SEND_ANSWER: 'ExistingSavingsSignal_SEND_ANSWER',
    GET_QUESTION: 'ExistingSavingsSignal_GET_QUESTION',
    SUCCESS_VALIDATION: 'ExistingSavingsSignal_SUCCESS_VALIDATION',
    FAILED_VALIDATION: 'ExistingSavingsSignal_FAILED_VALIDATION',
    SUCCESS_INSERT_INFO: 'ExistingSavingsSignal_SUCCESS_INSERT_INFO',
    CHAT_FLOW_COMPELETE: 'ExistingSavingsSignal_CHAT_FLOW_COMPELETE',
    CHAT_FLOW_RETURN: 'ExistingSavingsSignal_CHAT_FLOW_RETURN',
    TABLET_APPLY_INSERT_SUCCESS: 'ExistingSavingsSignal_TABLET_APPLY_INSERT_SUCCESS',
    SUCCESS_SET_CUST_START_TIME: 'ExistingSavingsSignal_SUCCESS_SET_CUST_START_TIME',
    SET_CIF_ACCOUNT_INFO: 'ExistingSavingsSignal_SET_CIF_ACCOUNT_INFO',
    SET_ACCOUNT_BALANCE: 'ExistingSavingsSignal_SET_ACCOUNT_BALANCE',
    GET_PASSWORD_RULE: 'GET_NEW_PASSWORD_RULE',  // 暗証番号ルール適合性チェック結果
    GET_ACCOUNT_INFO_COMPLETE: 'ExistingSavingsSignal_GET_ACCOUNT_INFO_COMPLETE',
    SET_DUPLICATE_ACCOUNT_INFO: 'ExistingSavingsSignal_SET_DUPLICATE_ACCOUNT_INFO',
    CHARACTER_CHECK: 'ExistingSavingsSignal_CHARACTER_CHECK',
    WILL_PUSH_FOOTER: 'ExistingSavingsSignal_WILL_PUSH_FOOTER',
    SET_ANSWER: 'ExistingSavingsSignal_SET_ANSWER',
    WILL_DISMISS_FOOTER: 'ExistingSavingsSignal_WILL_DISMISS_FOOTER',
    FILTERING_INQUIRY: 'ExistingSavingsSignal_FILTERING_INQUIRY',
    REQUEST_CUSTOMER_STATUS: 'ExistingSavingsSignal_REQUEST_CUSTOMER_STATUS',
    BC_APPLY: 'BC_APPLY',
    ACCEPT_TARGET: 'ACCEPT_TARGET',
    GET_MEDIUM_INFO: 'GET_MEDIUM_INFO',
    UPDATE_CHANGE_SUCCESS: 'ExistingSavingsSignal_UPDATE_CHANGE_SUCCESS',
    ACCEPT_CHECK_SWIPE_CIF: 'ExistingSavingsSignal_ACCEPT_CHECK_SWIPE_CIF', // スワイプCifの受付可否チェック
    UNACCEPTABLES_NG: 'ExistingSavingsSignal_UNACCEPTABLES_NG',
    ACCEPT_TARGET_FOR_NAME_DIF_CIF: 'ExistingSavingsSignal_ACCEPT_TARGET_FOR_NAME_DIF_CIF',
    ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF: 'ExistingSavingsSignal_ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF',
    GET_HOLDER_ZIP_CODE: 'ExistingSavingsSignal_GET_HOLDER_ZIP_CODE',
    GET_ADDRESS_CODE: 'ExistingSavingsSignal_GET_ADDRESS_CODE',
    CUSTOMER_INFOS_LIST: 'ExistingSavingsSignal_CUSTOMER_INFOS_LIST',
    ACCEPT_TARGET_FOR_TEL_DIF_CIF: 'ExistingSavingsSignal_ACCEPT_TARGET_FOR_TEL_DIF_CIF',
    SEARCH_REGION_CODE_COMPLETE: 'ExistingSavingsSignal_SEARCH_REGION_CODE_COMPLETE',
    //
    GET_NAME_AGGREGATION_INQUIRY: 'ExistingSavingsSignal_GET_NAME_AGGREGATION_INQUIRY',
    RECEPTION_LOSS_CORRUPTION_CHECK: 'ExistingSavingsSignal_RECEPTION_LOSS_CORRUPTION_CHECK',
    RECEPTION_LOSS_CORRUPTION_CHECK_ACCOUNT: 'ExistingSavingsSignal_RECEPTION_LOSS_CORRUPTION_CHECK_ACCOUNT',
    GET_CUSTOMER_INFO: 'ExistingSavingsSignal_GET_CUSTOMER_INFO',
};

@Injectable()
export class ExistingSavingsStore extends Store<ExistingSavingsState> {
    public documentMap: Map<number, string>;
    private keysArr: any[] = [];
    private replaceValues: Array<{ key: string, value: string }>;
    private tempPayload: string[];
    private changeDocArr: any[] = [];
    private orderChangeDocArr: any[] = [];
    private orderChangeDocNameArr: any[] = [];

    constructor(
        private ngZone: NgZone,
        private editService: EditService,
        private labelService: LabelService,
        private changeUtils: ChangeUtils,
        private savingsStore: SavingsStore) {
        super();
        this.state = {
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new ExistingSavingsSubmitEntity(),
            tabletStartDate: '',
            tabletApplyId: -1,
            copySubmitData: null,
            dropDownList: [],
            checkboxStatus: {
                receiptMethodStatus: false,  // カードお受取方法 checkbox
                confirmationStatus: false,  // 契約状況確認
                isAntisocialStatus: true, // 反社会的勢力
                isForeignPulicFiguresSatus: true,  // 外国の重要な公的地位にある者
                isJapaneseResidentStatus: false,  // 日本居住者です
                isRegulationStatus: false,
                isAllMaskingStatus: false, // 写真マスキング
                isCheckBranchStatus: false // 開設店舗確認
            },
            cifInfoInquiryList: new Array<CifInfoInquiryResponseEntity>(),
            currentFileInfo: {},
            identityDocuments: [],
            additionalInfoDocuments: [],
            duplicateAccountInfos: null,
            confirmPageChanges: {},
            lastFilteringParameter: new FilteringParameterEntity(),  // 前回フィルタリング照会のパラメータ
            lastFilteringResult: {},  // 前回フィルタリング照会の結果
            acceptCheckResult: [],
            transactionList: [],
            isNameChanged: false,
            isAddressChanged: false,
            isTelphoneChanged: false,
            isAddressDifference: false, // false: 差分なし　true:差分ある
            isNameDifference: false, // false: 差分なし　true:差分ある
            isTelphoneDifference: false, // false: 差分なし　true:差分ある
            isAddressDifferenceBackup: false, // false: 差分なし　true:差分ある
            isNameDifferenceBackup: false, // false: 差分なし　true:差分ある
            isTelphoneDifferenceBackup: false, // false: 差分なし　true:差分ある
            isSelectedSkipButtonA: false,
            isSelectedSkipButtonB: false,
            changeDocumentImages: {},
            orderChangeDocument: [],
            orderChangeDocumentName: [],
            nameIdentiAddressImage: {},
            checkboxStatusForChange: {
                isAllMaskingStatus: false, // 写真マスキング
            },
            notMaskingConfirmImages: {
                holderCardImageFront: false,
                holderCardImageBack: false,
                identificationDocument1Images: [],
                identificationDocument2Images: [],
                identificationAddressImages: [],
                changeDocumentImages: [],
                nameIdentiAddressImage: [],
                identificationStudentImages: [] // 学生証
            },
            regionCodeInfo: new RegionCodeEntity(),
            icData: null,
            ocrEntity: new OCREntity(),
            modifyExpiryDateExists: false
        };
        this.setDocumentMap();
    }

    /**
     * 本人確認書類画像を保存
     */
    @ActionBind(ExistingSavingsActionType.SAVE_DOCUMENT_IMAGE)
    private saveIdentityDocumentImage(document: any) {
        const { image, category } = document;
        const submitKey = this.documentMap.get(category);
        this.setSubmitData(
            submitKey,
            this.state.submitData[submitKey] ?
                [...this.state.submitData[submitKey], image] : [image]
        );
    }

    /**
     * cif情報をセット
     * @param cifInfo cif情報
     */
    @ActionBind(ExistingSavingsActionType.SET_CIF_INFO)
    private setCifInfo(cifInfo: any) {
        Object.keys(cifInfo).forEach((key) => {
            this.setSubmitData(key, cifInfo[key]);
        });
    }

    @ActionBind(ExistingSavingsActionType.SET_IDENTIFICATION_DOCUMENT)
    private setIdentificationDocument(data) {
        const { submitData } = data;
        this.state.submitData = submitData;
        this.setStateDataForHasDriversCareerLicense();
    }

    /**
     * 本人確認書類画像をクリア
     */
    @ActionBind(ExistingSavingsActionType.CLEAN_DOCUMENT_IMAGE)
    private cleanIdentityDocumentImage(category: Constants.IdentityDocumentCategory) {
        const submitKey = this.documentMap.get(category);
        this.setSubmitData(submitKey, undefined);
    }

    @ActionBind(ExistingSavingsActionType.SET_STATE_DATA)
    private setStateData(data) {
        this.state.submitData = Object.assign(new ExistingSavingsSubmitEntity(), data.submitData);
    }

    /**
     * データ設定
     *
     * @param data 回答
     */
    @ActionBind(ExistingSavingsActionType.SET_STATE_DATA_FOR_CHANGE)
    private setData(submitData: any) {
        Object.keys(submitData).forEach((key) => {
            this.setSubmitData(key, submitData[key]);
        });
    }

    @ActionBind(ExistingSavingsActionType.UPDATE_SAME_HOLDER_INQUIRY)
    private updateDuplicateAccountInfos(data: any) {
        this.state.duplicateAccountInfos = data;
    }

    /**
     * 支店情報を取得する
     * @param params 支店情報
     */
    @ActionBind(ExistingSavingsActionType.SET_BRANCH_INFO)
    private setBranchInfo(params: any) {
        this.setSubmitData('branchNo', params.branchNo);
        this.setSubmitData('branchNameKanji', params.branchNameKanji);
    }

    /**
     * チャットテンプレートをロードする
     * @param params yamlファイルにかんする情報
     */
    @ActionBind(ExistingSavingsActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.saveCurrentYamlInfo(params.fileInfo[0]);

            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(ExistingSavingsSignal.GET_QUESTION, params.pageIndex);

        }
    }

    /**
     * タブレット申し込み情報にデータをインサートする
     * @param data タブレット申し込み情報
     */
    @ActionBind(ExistingSavingsActionType.BRANCH_STATUS_INSERT)
    private branchStatusInsert(data: any) {
        if (data) {
            this.state.tabletApplyId = data;
            this.setSubmitData('tabletApplyId', data);
            this.sendSignal(ExistingSavingsSignal.TABLET_APPLY_INSERT_SUCCESS);
        }
    }

    /**
     * ストアをクリアする
     */
    @ActionBind(ExistingSavingsActionType.CLEAR)
    private clearStore() {
        this.state = {
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new ExistingSavingsSubmitEntity(),
            tabletStartDate: '',
            tabletApplyId: -1,
            copySubmitData: null,
            dropDownList: [],
            checkboxStatus: {
                receiptMethodStatus: false,  // カードお受取方法 checkbox
                confirmationStatus: false,  // 契約状況確認
                isAntisocialStatus: true, // 反社会的勢力
                isForeignPulicFiguresSatus: true,  // 外国の重要な公的地位にある者
                isJapaneseResidentStatus: false,  // 日本居住者です
                isRegulationStatus: false,
                isAllMaskingStatus: false, // 写真マスキング
                isCheckBranchStatus: false // 開設店舗確認
            },
            cifInfoInquiryList: new Array<CifInfoInquiryResponseEntity>(),
            currentFileInfo: {},
            identityDocuments: [],
            additionalInfoDocuments: [],
            duplicateAccountInfos: null,
            confirmPageChanges: {},
            lastFilteringParameter: new FilteringParameterEntity(),
            lastFilteringResult: {},
            acceptCheckResult: [],
            transactionList: [],
            isNameChanged: false,
            isAddressChanged: false,
            isTelphoneChanged: false,
            isAddressDifference: false, // false: 差分なし　true:差分ある
            isNameDifference: false, // false: 差分なし　true:差分ある
            isTelphoneDifference: false, // false: 差分なし　true:差分ある
            isAddressDifferenceBackup: false, // false: 差分なし　true:差分ある
            isNameDifferenceBackup: false, // false: 差分なし　true:差分ある
            isTelphoneDifferenceBackup: false, // false: 差分なし　true:差分ある
            isSelectedSkipButtonA: false,
            isSelectedSkipButtonB: false,
            changeDocumentImages: {},
            orderChangeDocument: [],
            orderChangeDocumentName: [],
            nameIdentiAddressImage: {},
            checkboxStatusForChange: {
                isAllMaskingStatus: false, // 写真マスキング
            },
            notMaskingConfirmImages: {
                holderCardImageFront: false,
                holderCardImageBack: false,
                identificationDocument1Images: [],
                identificationDocument2Images: [],
                identificationAddressImages: [],
                changeDocumentImages: [],
                nameIdentiAddressImage: [],
                identificationStudentImages: [] // 学生証
            },
            regionCodeInfo: new RegionCodeEntity(),
            icData: null,
            ocrEntity: new OCREntity(),
            modifyExpiryDateExists: false
        };
        this.keysArr = [];
        this.changeDocArr = [];
        this.orderChangeDocArr = [];
        this.orderChangeDocNameArr = [];
    }

    /**
     * Save yaml file Information
     */
    private saveCurrentYamlInfo(params: any) {
        this.state.currentFileInfo.yamlId = params.id;
        this.state.currentFileInfo.screenId = params.screenId;
        this.state.currentFileInfo.screenName = params.screenName;
    }

    /**
     * 次のステップを取得する
     * @param params 当ステップ情報
     */
    @ActionBind(ExistingSavingsActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: { order: number, pageIndex: number }, options?) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<ExistingSavingsQuestionsModel>(this.state.questions[pageIndex])
                    .min<ExistingSavingsQuestionsModel>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus = new PageQuestionsModel();
                        qus.order = item.order;
                        qus.next = item.next;
                        qus.type = item.type;
                        qus.question = this.replaceParams(item.question);
                        qus.name = item.name;
                        qus.skip = item.skip;
                        qus.pageIndex = pageIndex;
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        this.sendSignal(ExistingSavingsSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<ExistingSavingsQuestionsModel>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        const qus = new PageQuestionsModel();
                        qus.order = item.order;
                        qus.next = item.next;
                        qus.type = item.type;
                        qus.question = this.replaceParams(item.question);
                        qus.name = item.name;
                        qus.skip = item.skip;
                        qus.pageIndex = pageIndex;
                        qus.options = item.options;
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        if (item.type === RenderType.ITEM_LIST) {
                            this.tradingCondition(item.name);
                            qus.payload = [...this.tempPayload];
                        }
                        const repeatOrderArr = this.state.showChats.filter((filterItem) => filterItem.order === order);
                        // orderは繰り返しの場合、orderIndexを追加する。
                        (repeatOrderArr && repeatOrderArr.length > 0) ? qus.orderIndex = repeatOrderArr.length : qus.orderIndex = 0;
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        this.sendSignal(ExistingSavingsSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => { console.log('Outside Done!'); });
        });
    }

    /**
     * 質問文言をリプレースする
     * @param str 文言
     */
    private replaceParams(str: string): string {
        if (str.indexOf('@') === -1) {
            return str;
        }

        this.replaceValues = [
            {
                key: '@Name',
                value: this.state.submitData.existingChangeFirstName ?
                    this.state.submitData.existingChangeFirstName + '　' + this.state.submitData.existingChangeLastName :
                    this.state.submitData.nameKanjiBackup ? this.state.submitData.nameKanjiBackup : this.state.submitData.nameKanji
            },
            {
                key: '@Doc2SkipLabel',
                value: this.state.submitData.identificationDocument1 === IdentificationDocumentCode.PASSPORT_WITHOUT_SELF_INPUT ?
                    '' : this.labelService.labels.confirm.identityDocumentConfirm.doc2SkipLabel
            },
            { key: '@HolderNameFurigana', value: this.state.submitData.nameKana },
            {
                key: '@agentCountry',
                value: this.state.submitData.agentCountryText
            }, {
                key: '@idInfoDoc1', value: this.state.submitData.idInfoDoc1Text || this.state.submitData.identificationDocument1Text
            },
            {
                key: '@idInfoDoc2', value: this.state.submitData.idInfoDoc2Text || this.state.submitData.identificationDocument2Text
            },
            {
                key: '@identificationDocument1', value: this.state.submitData.identificationDocument1Text
            },
            {
                key: '@identificationDocument2', value: this.state.submitData.identificationDocument2Text
            },
            {
                key: '@AddressCountyUrbanVillage', value: this.state.submitData.holderAddressPrefecture +
                    this.state.submitData.holderAddressCountyUrbanVillage
            },
            {
                key: '@AddressWithoutHouseKanji', value: (this.state.submitData.holderAddressPrefecture +
                    this.state.submitData.holderAddressCountyUrbanVillage +
                    (this.state.submitData.getHolderAddressStreetName ? this.state.submitData.getHolderAddressStreetName() : ''))
            },
            {
                key: '@AddressKana', value: this.state.submitData.holderAddressPrefectureFuriKana +
                    this.state.submitData.holderAddressCountyUrbanVillageFuriKana +
                    (this.state.submitData.getHolderAddressStreetNameFuriKana ?
                        this.state.submitData.getHolderAddressStreetNameFuriKana() : '') +
                    this.state.submitData.holderAddressHouseNumberFuriKana
            },
            {
                key: '@Address', value: this.state.submitData.holderAddressPrefecture ? (this.state.submitData.holderAddressPrefecture +
                    this.state.submitData.holderAddressCountyUrbanVillage +
                    (this.state.submitData.getHolderAddressStreetName ? this.state.submitData.getHolderAddressStreetName() : '') +
                    this.state.submitData.holderAddressHouseNumber) : this.state.submitData.address
            },
            {
                key: '@branchName', value:
                    this.state.submitData.changeStoreFlg === StoreChanged.YES ?
                        this.state.submitData.branchNameChanged : this.state.submitData.branchName
            },
            {
                key: '@ExistingChangeHolderName',
                value: this.state.submitData.existingChangeFirstName !== undefined ?
                    this.state.submitData.existingChangeFirstName
                    + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.existingChangeLastName :
                    this.state.submitData.existingChangeFirstNameKana !== undefined ?
                        this.state.submitData.existingChangeFirstNameKana + COMMON_CONSTANTS.FULL_SPACE
                        + this.state.submitData.existingChangeLastNameKana :
                        this.state.submitData.existingChangeFirstNameKana !== undefined ?
                            this.state.submitData.existingChangeFirstNameKana + COMMON_CONSTANTS.FULL_SPACE
                            + this.state.submitData.existingChangeLastNameKana :
                            this.labelService.labels.change.chat.customer
            },
            {
                key: '@identificationDocument3B',
                value: this.changeUtils.getIdentificationDocument3(this.state.submitData.identificationDocument3B)
            },
            {
                key: '@identificationDocument3C',
                value: this.changeUtils.getIdentificationDocument3(this.state.submitData.identificationDocument3C)
            },
            {
                key: '@identificationDocument3X',
                value: this.changeUtils.getIdentificationDocument3(this.state.submitData.identificationDocument3X)
            },
            {
                key: '@inputOtherDocument3X',
                value: this.state.submitData.documentListNameX
            },
            {
                key: '@nameIdentityDocumentImg',
                value: this.state.submitData.nameIdentityDocumentImg
            },
            {
                key: '@changeIdentityDocumentImg',
                value: this.state.submitData.changeIdentityDocumentImg
            },
            {
                key: '@addressDocumentImg',
                value: this.state.submitData.addressDocumentImg
            },
            {
                key: '@receptionSelectedSwipCard',
                value: this.state.submitData.selectTenpoName
            },
            {
                key: '@OCRValidPeriod', value: this.state.submitData.identificationDocument1ExpiryDateText ?
                    this.state.submitData.identificationDocument1ExpiryDateText : this.savingsStore.getState().ocrEntity.dueDateWareki
            }

        ];

        let result = str;
        const documentNameKeyArr = ['@identificationDocument1', '@identificationDocument2'];
        this.replaceValues.forEach((element) => {
            if (result.indexOf(element.key) !== -1) {
                let identificationDocumentName;
                const propertyName = documentNameKeyArr[documentNameKeyArr.indexOf(element.key)];
                if ((this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) &&
                    element.key === propertyName) {
                    // 普通預金口座開設（スワイプあり）, 普通預金口座開設（スワイプなし）の場合
                    // 本人確認書類１/２ && 記載ありの場合、chatFlowのorder繰り返し運用する、バグ修正する。
                    const qus = this.state.showChats.forEach((item, index) => {
                        if (propertyName.replace('@', '') === item.name) {
                            // 文言のパラメータはshowChatsからです
                            identificationDocumentName = (item.answer && item.answer.text) ? item.answer.text : null;
                        }
                    });

                    /**
                     * 「本人確認書類１/２選択 && 本人確認書類１/２名はブランク」 or
                     * if   「submitDataの本人確認書類１/２名」は「showChatsの本人確認書類１/２名」と違う の場合、表示の文言のパラメータはshowChatsからです、
                     * else 表示の文言のパラメータはsubmitDataからです
                     */
                    result = ((element.value === undefined || identificationDocumentName !== element.value)
                        && identificationDocumentName !== null) ?
                        result.replace(element.key, identificationDocumentName) :
                        result.replace(element.key, element.value);
                } else {
                    result = result.replace(element.key, element.value);
                }
            }
        });

        return result;
    }

    /**
     * バンクカード申込フラグを設定
     * @param value value
     */
    @ActionBind(ExistingSavingsActionType.SET_BANK_CARD_FLAG)
    private setBankCardFlag(data: any[]) {
        data.forEach((element) => {
            this.setSubmitData(element.key, element.flag);
        });
        if (data && data.length > 0) {
            data.forEach((item) => {
                this.state.confirmPageChanges[item.key] = item.flag;
            });
        }
    }

    /**
     * チャット内容を編集する
     */
    @ActionBind(ExistingSavingsActionType.EDIT_CHAT)
    private editChat(params: any) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;
        const orderIndex = params.orderIndex;

        let i = -1;
        let index = -1;
        if (orderIndex !== null && orderIndex !== undefined) {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order && message.orderIndex === orderIndex) {
                    index = i;
                }
            });
        } else {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order) {
                    index = i;
                }
            });
        }

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }
        this.cleanSubmitData(answerOrder);
        this.resetIdentificationDocument(order, pageIndex);
    }

    /**
     * clean submitData
     * @param remain answerOrder
     */
    private cleanSubmitData(remain: number) {
        this.keysArr = this.keysArr.slice(0, remain);

        this.changeDocArr = this.changeDocArr.slice(0, remain);
        this.state.changeDocumentImages = this.changeDocArr[remain - 1] ?
            JSON.parse(JSON.stringify(this.changeDocArr[remain - 1])) : {};
        this.orderChangeDocArr = this.orderChangeDocArr.slice(0, remain);
        this.state.orderChangeDocument = this.orderChangeDocArr[remain - 1] ?
            JSON.parse(JSON.stringify(this.orderChangeDocArr[remain - 1])) : [];

        this.orderChangeDocNameArr = this.orderChangeDocNameArr.slice(0, remain);
        this.state.orderChangeDocumentName = this.orderChangeDocNameArr[remain - 1] ?
            JSON.parse(JSON.stringify(this.orderChangeDocNameArr[remain - 1])) : [];

        for (const item in this.state.submitData) {
            if (item.startsWith('get')) {
                continue;
            }
            if (this.keysArr.indexOf(item) < 0 && item !== SubmitDataKey.LOG_FILE_INFO) {
                this.setSubmitData(item, undefined);
            }
        }

        // 町長名手入力があり、フリガナがないとき、フリガナを作る、最大半角８３までトリムして、
        if (this.state.submitData.holderAddressStreetNameInput && !this.state.submitData.holderAddressStreetNameFuriKanaInput) {
            InputUtils.getKanjiToKana([{
                key: 'holderAddressStreetNameInput',
                value: this.state.submitData.holderAddressStreetNameInput
            }], AddressMaxLengthArr.holderAddressStreetNameInput).subscribe((result) => {
                result.map((item) => {
                    return {
                        name: item.key,
                        value: item.value
                    };
                }).filter((item) => item.name !== 'holderAddressStreetNameInput'
                ).forEach((data) => {
                    this.setStateSubmitDataValues([
                        {
                            key: data.name,
                            value: data.value
                        }
                    ]);
                });
            });
        }

        // 番地以降が入力された場合、番地以降フリガナをセット
        if (this.state.submitData.holderAddressHouseNumber && !this.state.submitData.holderAddressHouseNumberFuriKana) {
            InputUtils.getKanjiToKana([{
                key: 'holderAddressHouseNumber',  // 番地以降
                value: this.state.submitData.holderAddressHouseNumber
            }]).subscribe((resultHouseNumber) => {
                resultHouseNumber.map((item) => {
                    return {
                        name: item.key,
                        value: item.value
                    };
                }).filter((item) => item.name !== 'holderAddressHouseNumber'
                ).forEach((dataHouseNumber) => {
                    if (this.state.submitData.holderAddressStreetNameInput) {
                        // 町長名手入力があるときに
                        // 番地以降は８４から半角の町長名長さ引いた値までトリムする
                        InputUtils.getKanjiToKana([{
                            key: 'holderAddressStreetNameInput',　 // 町長名手入力
                            value: this.state.submitData.holderAddressStreetNameInput
                        }], AddressMaxLengthArr.holderAddressStreetNameInput).subscribe((resultStreetName) => {
                            resultStreetName.map((item) => {
                                return {
                                    name: item.key,
                                    value: item.value
                                };
                            }).filter((item) => item.name !== 'holderAddressStreetNameInput'
                            ).forEach((dataStreetName) => {
                                // 番地以降の半角長さをけんさんする
                                const maxlengthHouseNumber =
                                    InputUtils.calculateMaxLength('holderAddressHouseNumber', dataStreetName.value, undefined);
                                // 番地以降のを半角で計算済の長さでトリムする
                                dataHouseNumber.value =
                                    InputUtils.getStringByMaxLength(dataHouseNumber.value, maxlengthHouseNumber);
                                // 番地以降の全角フリガナをセットする
                                this.setStateSubmitDataValues([
                                    {
                                        key: dataHouseNumber.name,
                                        value: dataHouseNumber.value
                                    }
                                ]);
                            });
                        });
                    } else {
                        // 町長名手入力がないときに、番地以降を半角８４けたまでトリム
                        dataHouseNumber.value =
                            InputUtils.getStringByMaxLength(dataHouseNumber.value, AddressMaxLengthArr.holderAddressHouseNumber);
                        // 番地以降の全角フリガナをセットする
                        this.setStateSubmitDataValues([
                            {
                                key: dataHouseNumber.name,
                                value: dataHouseNumber.value
                            }
                        ]);
                    }
                });
            });
        }

    }

    /**
     * set SubmitData
     * @param key key
     * @param value value
     */
    private setSubmitData(key, value) {
        if (key !== undefined) {
            this.state.submitData[key] = value;
            this.keyPush(key, value);
        }
    }

    /**
     * keyPush
     * @param key key
     * @param value value
     */
    private keyPush(key: any, value: any) {
        if (value === null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                // keysArr, changeDocArr, orderChangeDocArr, orderChangeDocNameArrに
                // keyにあたるindexを削除し、lengthを揃うようにする（鉛筆修正時lengthがずれるバグの対応）
                this.keysArr.splice(index, 1);
                this.changeDocArr.splice(index, 1);
                this.orderChangeDocArr.splice(index, 1);
                this.orderChangeDocNameArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1) {
            this.keysArr.push(key);
            this.backupData();
        } else {
            const index = this.keysArr.indexOf(key);
            this.keysArr[index] = moment().format('YYYYMMDDHHmmss');
            this.keysArr.push(key);
            this.backupData();
        }
    }

    /**
     * 写真、撮影順序をバックアップする。
     */
    private backupData() {
        const backupChangeDocImage = this.state.changeDocumentImages ?
            JSON.parse(JSON.stringify(this.state.changeDocumentImages)) : {};
        this.changeDocArr.push(backupChangeDocImage);
        const backupOrderChangeDoc = this.state.orderChangeDocument ?
            JSON.parse(JSON.stringify(this.state.orderChangeDocument)) : [];
        this.orderChangeDocArr.push(backupOrderChangeDoc);

        const backupOrderChangeDocName = this.state.orderChangeDocumentName ?
            JSON.parse(JSON.stringify(this.state.orderChangeDocumentName)) : [];
        this.orderChangeDocNameArr.push(backupOrderChangeDocName);
    }

    private setStateSubmitDataValuesSpecial(datas: Array<{ key: string, value: any }>) {
        if (datas && datas.length > 0) {
            datas.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    /**
     * 回答を設定する
     * @param answer 回答
     */
    @ActionBind(ExistingSavingsActionType.SET_ANSWER)
    private setAnswer(answer: { order: number, text: string, value: Array<{ key: string, value: string }> }) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        answer.order = this.getTopOrder();
        chat.answer = answer;
        if (answer.value) {
            answer.value.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
        this.sendSignal(ExistingSavingsSignal.SET_ANSWER);
    }

    /**
     * get top order
     */
    private getTopOrder() {
        return this.keysArr.length;
    }

    /**
     * Submitデータ設定
     * @param datas 回答
     */
    @ActionBind(ExistingSavingsActionType.SET_STATE_SUBMIT_DATA_VALUE)
    private setStateSubmitDataValues(datas: Array<{ key: string, value: string }>) {
        if (datas && datas.length > 0) {
            datas.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    /**
     * チャットの表示内容をクリアする
     */
    @ActionBind(ExistingSavingsActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    /**
     * 郵便番号を取得する
     * @param data 郵便番号
     */
    @ActionBind(ExistingSavingsActionType.GET_HOLDER_ZIP_CODE)
    private getHolderZipCode(data: any) {
        this.setSubmitData('firstZipCode', data.substring(0, 3));
        this.setSubmitData('lastZipCode', data.substring(3, 7));
        this.sendSignal(ExistingSavingsSignal.GET_HOLDER_ZIP_CODE);
    }

    /**
     * パスワードを検証する
     * @param params 検証項目
     */
    @ActionBind(ExistingSavingsActionType.VALIDATION_PASSWORD)
    private validationPassword(params: any) {
        if (params.type === 'SUCCESS') {
            this.sendSignal(ExistingSavingsSignal.SUCCESS_VALIDATION);
        } else {
            this.sendSignal(ExistingSavingsSignal.FAILED_VALIDATION);
        }
    }

    /**
     * submit dataをバックアップする
     */
    @ActionBind(ExistingSavingsActionType.SUBMIT_DATA_BACKUP)
    private submitDataBackup() {
        this.state.copySubmitData = Object.assign(new ExistingSavingsSubmitEntity(), this.state.submitData);
        this.state.confirmPageChanges = {};
    }

    @ActionBind(ExistingSavingsActionType.UPDATA_SUBMIT_DATA_BACKUP)
    private updateSubmitDataBackup(datas: Array<{ key: string, value: string }>) {
        if (datas && datas.length > 0) {
            datas.forEach((item) => {
                this.state.confirmPageChanges[item.key] = item.value;
            });
        }
    }

    @ActionBind(ExistingSavingsActionType.RESET_SUBMIT_DATA)
    private resetSubmitData() {
        this.state.submitData = this.state.copySubmitData;
        this.state.copySubmitData = null;
    }

    /**
     * コードマスタの情報を取得する
     */
    @ActionBind(ExistingSavingsActionType.RETRIEVE_DROP_LIST)
    private retrieveDropList(data) {
        this.state.dropDownList = data;
    }

    /**
     * チャットが完了
     * @param nextChatName 次のチャットの名
     */
    @ActionBind(ExistingSavingsActionType.CHAT_FLOW_COMPELETE)
    private chatFlowCompelete(next: any) {
        this.sendSignal(ExistingSavingsSignal.CHAT_FLOW_COMPELETE, next);
    }

    @ActionBind(ExistingSavingsActionType.CHAT_FLOW_RETURN)
    private chatFlowReturn(next: any) {
        this.sendSignal(ExistingSavingsSignal.CHAT_FLOW_RETURN, next);
    }

    /**
     * 最後のノードをチェックする
     * @param params パラメーター
     */
    @ActionBind(ExistingSavingsActionType.RESET_LAST_NODE)
    private resetLastNode(params: { order: number, pageIndex: number }) {
        this.getState().showChats.pop();
        this.getNextChatByAnswer(params);
    }

    /**
     * Submit result
     */
    @ActionBind(ExistingSavingsActionType.SUBMIT_EXIST_SAVING_APPLY_INFO)
    private existSavingApplyInfoInsert(data) {
        this.sendSignal(ExistingSavingsSignal.SUCCESS_INSERT_INFO, data);
    }

    /**
     * 行員IDを設定する
     * @param params 行員ID
     */
    @ActionBind(ExistingSavingsActionType.SET_BANKCLERK_ID)
    private setBankclerkId(params: any) {
        this.setSubmitData('userMngNo', params.bankclerkId);
    }

    /**
     * 修正用テンプレートをロードする
     * @param params パラメーター
     */
    @ActionBind(ExistingSavingsActionType.GET_CONFIRM_PAGE_TEMPLATE)
    private loadConfirmTemplate(params: any) {
        if (params) {
            this.state.questions[params.pageIndex] = params.data;
            this.state.submitData.fileInfo = params.fileInfo;
        }
    }

    /**
     * Reset showChats
     * @param data origin showChats
     */
    @ActionBind(ExistingSavingsActionType.RESET_SHOWCHATS)
    private resetShowChats(data: any) {
        this.state.showChats = data;
    }

    /**
     * modify checkbox status
     * @param name the checbox item need to modify status
     */
    @ActionBind(ExistingSavingsActionType.MODIFY_CHECKBOX_STATUS)
    private modifyCheckboxStatus(name: string) {
        this.state.checkboxStatus[name] = !this.state.checkboxStatus[name];
    }

    /**
     * modify checkbox status for change
     * @param name the checbox item need to modify status
     */
    @ActionBind(ExistingSavingsActionType.MODIFY_CHECKBOX_STATUS_CHANGE)
    private modifyCheckboxStatusForChange(name: string) {
        this.state.checkboxStatusForChange[name] = !this.state.checkboxStatusForChange[name];
    }

    /**
     * Set the item as the current time of server
     * @param data system time and the key of item
     */
    @ActionBind(ExistingSavingsActionType.SET_SYSTEM_TIME)
    private setAsSystemTime(data: any) {
        this.setSubmitData(data.key, data.systemTime);
    }

    /**
     * Set the images info
     * @param images key and images string data
     */
    @ActionBind(ExistingSavingsActionType.SET_IMAGES)
    private setImages(data: any) {
        this.setSubmitData(data.key, data.values);
    }

    /**
     * 取次店番を設定する
     * @param params 支店番号
     */
    @ActionBind(ExistingSavingsActionType.SET_AGENCY_BRANCH_INFO)
    private setAgencyBranchInfo(params: any) {
        this.setSubmitData('agencyBranchNo', params.branchNo);
    }

    /**
     * 暗証番号ルール適合性チェック(初めて発行)結果設定
     * @param data response data
     */
    @ActionBind(ExistingSavingsActionType.GET_EXISTING_PASSWORD_RULE)
    private signalExistingCustomerPasswordCheckResult(data: any) {
        // 暗証番号ルール適合性チェック結果を発送する
        this.sendSignal(ExistingSavingsSignal.GET_PASSWORD_RULE, data);
    }

    /**
     * CIF情報と口座情報の設定
     * @param results response data
     */
    @ActionBind(ExistingSavingsActionType.SET_CIF_ACCOUNT_INFO)
    private setCifAccountInfo(results: any) {
        // CIF情報照会
        const cifInfo = results.data[0];
        // 口座情報照会
        const accountInfo = results.data[1];

        this.state.cifInfoInquiryList = cifInfo.result.cifInfoInquiryResponseList;
        this.settingCifInformation(cifInfo.result.cifInfoInquiryResponse, this.state.cifInfoInquiryList);
        this.setSubmitData('accountInfo', accountInfo.result.accountInfo);

        this.sendSignal(ExistingSavingsSignal.SET_CIF_ACCOUNT_INFO,
            { nextOrder: results.nextOrder, pageIndex: results.pageIndex });
    }

    /**
     * SubmitDataに本人基本情報設定を行う
     * @param entity CIF情報エンティティ
     * @param entity CIF情報配列
     */
    private settingCifInformation(entity: CifInfoInquiryResponseEntity, cifInfoList: CifInfoInquiryResponseEntity[]) {
        // 基本情報を設定する
        CifInformationUtils.setCifBasicInfoForExistings(this.state.submitData, this.keysArr, entity);
        // 諸届書類の撮影バックアップ配列とkeysArrの要素の同期を行う(keysArrの要素分、空データを格納する)
        this.keysArr.forEach(() => (this.backupData()));

        let showPointServiceApply: boolean = true;
        if (entity.pointServiceType !== PointServiceType.NOJOIN) {
            const pointServiceExpectation = PointServiceExpectation.NOT_APPLY;
            this.setSubmitData('pointServiceExpectation', pointServiceExpectation);
            showPointServiceApply = false;
        }
        this.setSubmitData('showPointServiceApply', showPointServiceApply);

        let directApplyExpectation = DirectApplyExpectationType.NO_APPLY;
        let showDirectApply: boolean = true;
        cifInfoList.forEach((cifInfo) => {
            if (cifInfo.iyoginDirectType === DirectApplyExpectationType.APPLY) {
                directApplyExpectation = DirectApplyExpectationType.NO_APPLY;
                showDirectApply = false;
                this.setSubmitData('directApplyExpectation', directApplyExpectation);
                return false;
            }
        });
        this.setSubmitData('showDirectApply', showDirectApply);

        // regionCode
        this.setSubmitData('regionCode', entity.regionCode);
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param data QRコード受付情報
     */
    @ActionBind(ExistingSavingsActionType.SET_SWIPE_INFO)
    private setSwipeInfo(data: any) {
        if (data.swipeInfo) {
            this.setSubmitData('swipeCif', data.swipeInfo.branchCif);
            this.setSubmitData('swipeBranchNo', data.swipeInfo.cardBranchNo);
            this.setSubmitData('swipeAccountNo', data.swipeInfo.cardAccountNo);
            this.setSubmitData('swipeAccountType', data.swipeInfo.cardAccountType);

            this.setSubmitData('receptionBranchNo', data.swipeInfo.receptionBranchNo);
            this.setSubmitData('receptionNo', data.swipeInfo.receptionNo);
            this.setSubmitData('receptionTime', data.swipeInfo.receptionTime);
        }

        this.state.tabletApplyId = data.tabletApplyId;
        this.setSubmitData('tabletApplyId', data.tabletApplyId);
        this.setSubmitData('accountType', data.accountType);
    }

    /**
     *  行員確認の入力データをクリアする
     */
    @ActionBind(ExistingSavingsActionType.CLEAR_CONFIRM_PAGE_INFO)
    private clearConfirmPageInfo() {
        // 本人確認書類
        this.setSubmitData('holderIdentityDocumentType', undefined);
        // 本人確認書類をクリアする
        this.state.identityDocuments = [];
        // 本人確認補完書類をクリアする
        this.state.additionalInfoDocuments = [];
        // 遠隔地等住所等の場合の理由
        this.setSubmitData('holderRemoteAddressReason', undefined);
        // 住所が相違する理由
        this.setSubmitData('holderIdentityDocumentAddressReason', undefined);
        // コピー徴求ができない理由
        this.setSubmitData('holderIdentityDocumentNoCopyReason', undefined);
        // 発行元
        this.setSubmitData('holderIdentityDocumentPublisher', undefined);
        // 発行日
        this.setSubmitData('holderIdentityDocumentPublishDate', undefined);
        // 記号番号
        this.setSubmitData('holderIdentityDocumentSignNo', undefined);
        // コピー徴求ができない理由
        this.setSubmitData('holderNoCopyReason', undefined);
        // 発行元
        this.setSubmitData('holderPublisher', undefined);
        // 発行日
        this.setSubmitData('holderPublishDate', undefined);
        // 記号番号
        this.setSubmitData('holderSignNo', undefined);
        // 顔写真のない本人確認書類の場合の補完書類
        this.setSubmitData('holderIdentityDocumentPhotographType', undefined);
        // 本人確認書類の住所と現住所が異なる場合の補完書類
        this.setSubmitData('holderIdentityDocumentAddressType', undefined);

        // maskingのチェックボックをリセット
        this.state.checkboxStatus.isAllMaskingStatus = false;
        this.state.checkboxStatusForChange.isAllMaskingStatus = false;
        // 開設店舗確認
        this.state.checkboxStatus.isCheckBranchStatus = false;

        // 届出変更本人確認書類
        this.state.changeDocumentImages = {};
        this.state.orderChangeDocument = [];
        this.state.orderChangeDocumentName = [];
    }

    @ActionBind(ExistingSavingsActionType.CLEAR_CREDIT_CARD_CONFIRM_PAGE_INFO)
    private clearCreditCardConfirmPageInfo() {
        // 届出変更本人確認書類
        this.state.changeDocumentImages = {};
        this.state.orderChangeDocument = [];
        this.state.orderChangeDocumentName = [];
        // マスキング確認
        this.state.checkboxStatus.isAllMaskingStatus = false;
        this.state.checkboxStatusForChange.isAllMaskingStatus = false;
        // 開設店舗確認
        this.state.checkboxStatus.isCheckBranchStatus = false;
        // 口座開設申込内容確認画面チェックボックス
        this.state.checkboxStatus.isAntisocialStatus = false;      // 反社会的勢力に該当しない
        this.state.checkboxStatus.isForeignPulicFiguresSatus = false;  // 外国の重要な公的地位にある者に該当しない
        this.state.checkboxStatus.isJapaneseResidentStatus = true; // 個人情報利用同意
        this.state.checkboxStatus.isRegulationStatus = true;   // 規定を承認
        // 本人確認書類１の名称、画像、書類コード、有効期限
        this.setSubmitData('identificationDocument1', undefined);
        this.setSubmitData('identificationDocument1Images', undefined);
        this.setSubmitData('identificationDocument1ExpiryDate', undefined);
        this.setSubmitData('identificationDocument1ExpiryDateText', undefined);
        this.setSubmitData('identificationDocument1Text', undefined);
        this.setSubmitData('documentListName', undefined);
        // 本人確認書類２の名称、画像、書類コード、有効期限
        this.setSubmitData('identificationDocument2', undefined);
        this.setSubmitData('identificationDocument2Images', undefined);
        this.setSubmitData('identificationDocument2ExpiryDate', undefined);
        this.setSubmitData('identificationDocument2ExpiryDateText', undefined);
        this.setSubmitData('identificationDocument2Text', undefined);
        this.setSubmitData('documentListName2', undefined);
        // 免許証番号
        this.setSubmitData('identificationDocumentLicenseNo', undefined);
        // 現住所確認書類の名称、画像、有効期限
        this.setSubmitData('addressConfirmationDocumentName', undefined);
        this.setSubmitData('identificationAddressImages', undefined);
        this.setSubmitData('identificationAddressExpiryDate', undefined);
        this.setSubmitData('identificationAddressExpiryDateText', undefined);
        // 学生証
        this.setSubmitData('identificationStudentImages', undefined);
        // 連絡事項
        this.setSubmitData('contactNote', undefined);
    }

    /**
     * Reset showConfirm
     * @param showConfirm showConfirm
     */
    @ActionBind(ExistingSavingsActionType.RESET_SHOW_CONFIRM)
    private resetShowConfirm(showConfirm) {
        this.state.showConfirm = showConfirm;
    }

    /**
     * Request default address
     * @param result default address
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @ActionBind(ExistingSavingsActionType.GET_DEFAULT_ADDRESS)
    private requestDefaultAddress({ result, entity, pageIndex }) {
        const order = (result.branchNameKanji && result.branchNo) ? entity.next : entity.skip;
        this.getNextChatByAnswer({ order: order, pageIndex: pageIndex }, result);
    }

    /*
     * 口座残高照会
     * @param data 口座残高照会のリスポンス
     */
    @ActionBind(ExistingSavingsActionType.INQUIRE_ACCOUNT_BALANCE)
    private inquireAccountBalance(data: any) {
        this.setSubmitData('swipeCardType', data.result.responseList[0].holderCardType);
        this.sendSignal(ExistingSavingsSignal.SET_ACCOUNT_BALANCE, { nextOrder: data.nextOrder, pageIndex: data.pageIndex });
    }

    /**
     * 重複口座情報をセット
     * @param data 重複口座情報
     */
    @ActionBind(ExistingSavingsActionType.SET_DUPLICATE_ACCOUNT_INFO)
    private settingDuplicateAccount(data: DuplicateAccountEntity) {
        this.setSubmitData('redundantReason', data.reason.value);
        this.setSubmitData('redundantReasonText',
            data.reason.value === CodeCategory.CODE_CATEGORY_DUPLICATION_REASON_OTHER ? data.reason.text : null);
        this.setSubmitData('redundantCif', data.branchCif);
        this.setSubmitData('redundantBranchNo', data.branchNo);
        this.setSubmitData('interviewFlag', data.interview);

        // 本人確認資料確認
        this.setSubmitData('redundantIdentityVerifiedFlag', data.identityVerified);
        // 取引時確認記録状況
        this.setSubmitData('redundantStartUpVerifiedFlag', data.startUpVerified);
        // 共通印登録状況
        this.setSubmitData('redundantCommonSealStatus', data.sharedSignetType);
        // 総合口座を持っているフラグ
        this.setSubmitData('hasComprehensive', data.hasComprehensive);

        this.sendSignal(ExistingSavingsSignal.SET_DUPLICATE_ACCOUNT_INFO);
    }

    /**
     * 漢字名修正フラグ
     */
    @ActionBind(ExistingSavingsActionType.SET_ONLY_NAME_KANJI_EDIT_FLG)
    private setEditNameKanji() {
        this.setSubmitData('editNameKanji', this.state.submitData.nameNonConvert === NameNonConvert.ON);
    }

    /**
     * 文字チェック。
     */
    @ActionBind(ExistingSavingsActionType.CHARACTER_CHECK)
    private characteCheck(data: any) {
        this.sendSignal(ExistingSavingsSignal.CHARACTER_CHECK);
    }

    /**
     * フィルタリングシステム検索。
     */
    @ActionBind(ExistingSavingsActionType.FILTERING_INQUIRY)
    private filterInquiry(data: any) {
        Object.keys(data).forEach((key) => {
            this.setSubmitData(key, data[key]);
        });
        this.setSubmitData('outStatusText', data.outStatus === OutStatus.OFF ? OutStatusText.OFF : OutStatusText.ON);
        this.sendSignal(ExistingSavingsSignal.FILTERING_INQUIRY, [{
            key: 'outStatusText',
            value: data.outStatus === OutStatus.OFF ? OutStatusText.OFF : OutStatusText.ON
        }, ...Object.keys(data).map((key) => {
            return {
                key: key,
                value: data[key]
            };
        })]);

        // filtering結果を前回フィルタリング結果対象に保存
        this.state.lastFilteringResult = data;
    }

    /**
     * フィルタリングシステムのパラメタを保存。
     */
    @ActionBind(ExistingSavingsActionType.SET_LAST_FILTERING_PARAMS)
    private setLastFilteringParams(data: FilteringParameterEntity) {
        this.state.lastFilteringParameter = data;
    }

    @ActionBind(ExistingSavingsActionType.SET_SUBMIT_DATA)
    private editSubmitData(data: { index, key, val }) {
        if (data.key) {
            // indexが存在するときに、配列のフィルドに値を入れる。
            // indexが存在しないときに、配列ではないフィルドに値を入れる
            (data.index !== undefined && data.index !== null) ?
                this.state.submitData[data.key][data.index] = data.val :
                this.state.submitData[data.key] = data.val;
        }
    }

    @ActionBind(ExistingSavingsActionType.EDIT_SUBMIT_DATA_NESTED)
    private editSubmitDataNested(data: { index, key, nestKey, val }) {
        if (data.key) {
            // indexが存在するときに、入れ子のキーに紐づく配列の中のフィールドに画像を設定する。
            // indexが存在しないときに、入れ子のキーに紐づく配列ではないフィールドに画像を設定する。
            (data.index !== undefined && data.index !== null) ?
                this.state[data.key][data.nestKey][data.index] = data.val :
                this.state[data.key][data.nestKey] = data.val;
        }
    }

    private setDocumentMap() {
        this.documentMap = new Map<number, string>();
        this.documentMap.set(Constants.IdentityDocumentCategory.Document1, 'identificationDocument1Images');
        this.documentMap.set(Constants.IdentityDocumentCategory.Document2, 'identificationDocument2Images');
        this.documentMap.set(Constants.IdentityDocumentCategory.Address, 'identificationAddressImages');
        this.documentMap.set(Constants.IdentityDocumentCategory.AgentDocument1, 'identificationDocument1AgentImages');
        this.documentMap.set(Constants.IdentityDocumentCategory.AgentDocument2, 'identificationDocument2AgentImages');
        this.documentMap.set(Constants.IdentityDocumentCategory.AgentAddress, 'identificationAddressAgentImages');
        // 在籍確認書類
        this.documentMap.set(Constants.IdentityDocumentCategory.EnrollmentCertificate, 'imageEnrollmentCertificate');
        // 学生確認
        this.documentMap.set(Constants.IdentityDocumentCategory.StudentId, 'identificationStudentImages');
    }

    private resetIdentificationDocument(order, pageIndex) {
        const chat = this.state.questions[pageIndex].find((item) => item.order === order);
        // 本人確認書類が「住民票の写し（原本）」を選択された場合、「記載あり」→「記載なし」変更された時に、本人確認書類が「null」になることを対応
        if (chat && /@\S+にマイナンバーは記載されていますか？/.test(chat.question)) {
            const name = chat.question.slice(1, chat.question.indexOf('に'));
            const filter = this.state.showChats.filter((show) => show.name === name);
            if (filter && filter.length > 0) {
                const answer = filter[filter.length - 1].answer;
                answer.value.forEach((element) => {
                    this.setSubmitData(element.key, element.value);
                });
                this.setSubmitData(name + 'Text', answer.text);
            }
        }
    }

    /**
     * 住所変更ボタンが押されるときの処理
     * 取引ぶりあるかどうかを判断
     *
     * Request customer info
     * @param item result of the request
     */
    @ActionBind(ExistingSavingsActionType.ACCEPT_CHECK)
    private onAcceptCheck(res: AcceptionResult) {

        // Stateに登録,送信レコードと受信レコードをマッピングする
        const sendedAccount: CifInfo[] = this.state.submitData.allCifInfos;
        sendedAccount.forEach((item, index) => {
            // 受付チェックの結果acceptCheckResultに格納
            // フォーマットは key:value
            // (口座番号また顧客番号): 受付可否チェック結果
            let key: string = this.changeUtils.getFirstFullAccount(item.domesticAccountInfo);
            // 口座番号存在しないときに、顧客番号をキーに設定
            const keyType: AcceptCheckKeyType = key ? AcceptCheckKeyType.ACCOUNT : AcceptCheckKeyType.CUSTOMERID;
            key = item.customerId;
            this.state.acceptCheckResult
                .push({ keyType: keyType, key: key, value: res.accounts[index] });
        });

        this.sendSignal(ExistingSavingsSignal.ACCEPT_TARGET, res);
    }

    /**
     * 取引ぶりをtempPayloadに保存
     */
    private tradingCondition(name: string) {
        let tempPayload: string[] = [];

        switch (name) {
            case 'swipeCif':
                this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions.forEach((tradingCondition) => {
                    if (tradingCondition.tradingConditionCode !== DBConsts.SpecTransactionCode.houseLoan &&
                        tradingCondition.tradingConditionCode !== DBConsts.SpecTransactionCode.bondCustomers &&
                        tradingCondition.tradingConditionCode !== DBConsts.SpecTransactionCode.goldBullion &&
                        tradingCondition.tradingConditionCode !== DBConsts.SpecTransactionCode.safeDepositBox) {
                        tempPayload.push(this.getTradingConditionName(
                            this.state.submitData.birthdate, tradingCondition));
                    }
                });
                break;
            case 'nameUpdateCif':
                tempPayload = this.getTempPayload(this.state.submitData.nameidentiNameDifCifAcceptCheckResult);
                break;
            case 'addressUpdateCif':
                tempPayload = this.getTempPayload(this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt);
                break;
            case 'telUpdateCif':
                tempPayload = this.getTempPayload(this.state.submitData.nameidentiTelDifCifAcceptCheckResult);
                break;
            case 'allCif':
                if (this.state.submitData.isNameChange) {
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions.forEach((tradingCondition) => {
                        if ((tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.loanCreditOwned
                            || tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.Investment
                            || tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.specialDeposit)
                            && tempPayload.indexOf(tradingCondition.tradingConditionName) === -1) {
                            tempPayload.push(tradingCondition.tradingConditionName);
                        }
                    });
                }
                if (this.state.submitData.isAddressChange) {
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions.forEach((tradingCondition) => {
                        if ((tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.other
                            || tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.Investment
                            || tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.specialDeposit)
                            && tempPayload.indexOf(tradingCondition.tradingConditionName) === -1) {
                            tempPayload.push(tradingCondition.tradingConditionName);
                        }
                    });
                }
                if (this.state.isNameDifference) {
                    this.state.submitData.nameidentiNameDifCifAcceptCheckResult.forEach((item) => {
                        item.accounts.tradingConditions.forEach((tradingCondition) => {
                            if ((tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.loanCreditOwned
                                || tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.Investment
                                || tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.specialDeposit)
                                && tempPayload.indexOf(tradingCondition.tradingConditionName) === -1) {
                                tempPayload.push(tradingCondition.tradingConditionName);
                            }
                        });
                    });
                }
                if (this.state.isAddressDifference) {
                    this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt.forEach((item) => {
                        item.accounts.tradingConditions.forEach((tradingCondition) => {
                            if ((tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.other
                                || tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.Investment
                                || tradingCondition.tradingConditionCode === DBConsts.SpecTransactionCode.specialDeposit)
                                && tempPayload.indexOf(tradingCondition.tradingConditionName) === -1) {
                                tempPayload.push(tradingCondition.tradingConditionName);
                            }
                        });
                    });
                }
                break;
        }

        this.tempPayload = tempPayload;
    }

    private getTradingConditionName(birthdate, tradingCondition) {
        return this.changeUtils.juniorNisaCheck(birthdate, tradingCondition) ?
            tradingCondition.tradingConditionName + COMMON_CONSTANTS.JPN_ERAS_UNDER_18_AGE :
            tradingCondition.tradingConditionName;
    }

    @ActionBind(ExistingSavingsActionType.NEED_INPUT_PHONE_NO)
    private needInputPhoenNo() {
        const chats = this.state.showChats.splice(-4, 4);
        if (chats && chats.length > 0) {
            const chat = chats[0];

            this.getNextChatByAnswer({
                order: chat.order,
                pageIndex: chat.pageIndex
            });
        }
    }

    /**
     * 電話番号差分あることを登録
     *
     */
    @ActionBind(ExistingSavingsActionType.SET_TELPHONE_DIFFERENCE_FLG)
    private setTelphoneDifferenceFlg(result: boolean) {
        this.state.isTelphoneDifference = result;
    }

    @ActionBind(ExistingSavingsActionType.BC_APPLY_CHECK)
    private bcApplyCheck(result: any) {
        let tmpAcceptionResult: AcceptionResult;
        const initAcceptionResult: AcceptionResult[] = new Array();

        tmpAcceptionResult = result.data;
        initAcceptionResult.push(tmpAcceptionResult);
        this.setStateSubmitDataValuesSpecial([{
            key: 'bcHoldingStatusAllCustomer',
            value: initAcceptionResult
        }]);

        this.sendSignal(ExistingSavingsSignal.BC_APPLY, this.state.submitData.bcHoldingStatusAllCustomer);

    }

    /**
     * 本人情報更新結果を発送。
     * @param data 本人情報更新結果
     */
    @ActionBind(ExistingSavingsActionType.GET_UPDATE_HOLDER_INFO)
    private sendUpdateHolderInfoResult(data: any) {
        this.sendSignal(ExistingSavingsSignal.UPDATE_CHANGE_SUCCESS, data);
    }

    /**
     * 本人書類確認処理中に撮影した写真をchange stateに格納
     *
     * @private
     * @param {string[]}
     */
    @ActionBind(ExistingSavingsActionType.SAVE_DOCUMENT_IMAGES)
    private saveDocumentImages(param: any) {
        if (!this.state.changeDocumentImages) {
            this.state.changeDocumentImages = {};
        }
        if (!this.state.orderChangeDocument) {
            this.state.orderChangeDocument = [];
        }
        if (!this.state.orderChangeDocumentName) {
            this.state.orderChangeDocumentName = [];
        }
        if (param.image) {
            this.state.changeDocumentImages[param.code] = this.state.changeDocumentImages[param.code] ?
                [...this.state.changeDocumentImages[param.code], param.image] : [param.image];
            this.state.orderChangeDocument.push(param.code);
            this.state.orderChangeDocumentName.push(param.name);
        }

        // バックアップの最新要素を上書き(撮影時は回答チャットの表示がないため、書類種類のチャット時点としてバックアップする)
        this.changeDocArr.pop();
        this.changeDocArr.push(JSON.parse(JSON.stringify(this.state.changeDocumentImages)));
        this.orderChangeDocArr.pop();
        this.orderChangeDocArr.push(JSON.parse(JSON.stringify(this.state.orderChangeDocument)));

        this.orderChangeDocNameArr.pop();
        this.orderChangeDocNameArr.push(JSON.parse(JSON.stringify(this.state.orderChangeDocumentName)));
    }

    /**
     * 本人書類確認修正の場合、写真更新
     *
     * @private
     * @param {string[]}
     */
    @ActionBind(ExistingSavingsActionType.SAVE_DOCUMENT_IMAGES_CONFIRM)
    private saveDocumentImagesConfirm(param: any) {
        // 写真をクリアする
        this.state.changeDocumentImages = {};
        // 撮影順のクリア
        this.state.orderChangeDocument = [];
        this.state.orderChangeDocumentName = [];

        // 住変にとった写真を入れる
        if (param.images) {
            this.state.changeDocumentImages = param.images;
        }

        // 撮影順序を格納する
        if (param.orderChangeDocument) {
            this.state.orderChangeDocument = param.orderChangeDocument;
        }
        if (param.orderChangeDocumentName) {
            this.state.orderChangeDocumentName = param.orderChangeDocumentName;
        }
    }

    /**
     * 本人確認チャットでの書類パターン(A/B)ごとのスキップボタン押下有無を格納
     *
     * @private
     * @param param 書類パターンA/Bの撮影書類
     */
    @ActionBind(ExistingSavingsActionType.SAVE_SKIPPED_DOCUMENT_PATTERN)
    private saveSkippedDocumentPattern(param: { identificationDocument3A: string; identificationDocument3B: string; }) {
        this.state.isSelectedSkipButtonA = false;
        this.state.isSelectedSkipButtonB = false;
        if (param.identificationDocument3A === COMMON_CONSTANTS.SKIP_TEXT) {
            this.state.isSelectedSkipButtonA = true;
        }
        if (param.identificationDocument3B === COMMON_CONSTANTS.SKIP_TEXT) {
            this.state.isSelectedSkipButtonB = true;
        }
    }

    /**
     * マスキング未確認データから確認済の写真を削除する
     *
     * @private
     * @param {*} data
     * @memberof SavingsStore
     */
    @ActionBind(ExistingSavingsActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES)
    private removeNotMaskingConfirmImages(data: any) {
        const { documentName, index } = data;
        // indexパラメータが存在する時に、documentNameの属性が配列と認識して
        if (index !== undefined) {
            this.state.notMaskingConfirmImages[documentName].splice(index, 1);
        } else if (this.state.notMaskingConfirmImages[documentName] !== undefined
            && typeof this.state.notMaskingConfirmImages[documentName] === 'boolean') {
            // documentNameの属性は存在かつbooleanの場合、値をfalseにする
            this.state.notMaskingConfirmImages[documentName] = false;
        }
    }

    @ActionBind(ExistingSavingsActionType.RESET_NOT_MASKING_CONFIRM_IMAGES)
    private resetNotMaskingConfirmImages(type: ClearSavingImagesClickRecordType) {
        const _documentResetFn = (documentName: string) => {
            // 書類の保存タイプはboolean
            if (typeof this.state.notMaskingConfirmImages[documentName] === 'boolean') {
                this.state.notMaskingConfirmImages[documentName] = false;

                if (this.state.submitData[documentName]) {
                    this.state.notMaskingConfirmImages[documentName] = true;
                }
            } else {
                // 書類の保存タイプは配列
                this.state.notMaskingConfirmImages[documentName] = [];

                if (this.state.submitData[documentName]) {
                    this.state.submitData[documentName].forEach(
                        (item, index) => {
                            this.state.notMaskingConfirmImages[documentName].push(index);
                        }
                    );
                }

                let indexChange = 0;
                this.state.notMaskingConfirmImages.changeDocumentImages = [];
                Object.keys(this.state.changeDocumentImages).forEach(
                    (item) => {
                        this.state.changeDocumentImages[item].forEach(() => {
                            this.state.notMaskingConfirmImages.changeDocumentImages.push(indexChange);
                            indexChange++;
                        });
                    });
            }
        };

        switch (type) {
            case ClearSavingImagesClickRecordType.DOCUMENT:
                // 既存写真によって、マスキング未確認データをリセット
                Object.keys(this.state.notMaskingConfirmImages).forEach(
                    (atrribute) => {
                        _documentResetFn(atrribute);
                    }
                );
                break;
            case ClearSavingImagesClickRecordType.CLEAR:
                // 在籍確認書類、本人確認書類１、本人確認書類２、住所確認書類をクリア
                Object.keys(this.state.notMaskingConfirmImages).forEach(
                    (atrribute) => {
                        this.state.notMaskingConfirmImages[atrribute] =
                            typeof this.state.notMaskingConfirmImages[atrribute] === 'boolean' ? false : [];
                    }
                );
                break;
            default:
                break;
        }
    }

    /**
     * 住所差分あることを登録
     *
     * @private
     * @param {boolean} result
     * @memberof ChangeStore
     */
    @ActionBind(ExistingSavingsActionType.SET_ADDRESS_DIFFERENCE_FLG)
    private setAddressDifferenceFlg(result: boolean) {
        this.state.isAddressDifference = result;
    }

    /**
     * 氏名差分あることを登録
     *
     * @private
     * @param {boolean} result
     * @memberof ChangeStore
     */
    @ActionBind(ExistingSavingsActionType.SET_NAME_DIFFERENCE_FLG)
    private setNameDifferenceFlg(result: boolean) {
        this.state.isNameDifference = result;
    }

    @ActionBind(ExistingSavingsActionType.UNACCEPTABLES_NG)
    private signalUnacceptablesNg(data: any) {
        this.sendSignal(ExistingSavingsSignal.UNACCEPTABLES_NG, data);
    }

    /**
     * Deal with customer status
     * @param params info in chat flow
     */
    @ActionBind(ExistingSavingsActionType.ACCEPT_CHECK_SWIPE_CIF)
    private requestCustomerStatus(params: any) {

        // レスポンスをsubmitDataに格納
        this.setSubmitData('swipeCifAcceptCheckResult',
            { customerId: this.state.submitData.customerId, account: params.response.accounts[0] });

        this.sendSignal(ExistingSavingsSignal.ACCEPT_CHECK_SWIPE_CIF);
    }

    @ActionBind(ExistingSavingsActionType.ACCEPT_CHECK_FOR_NAME_DIF_CIF)
    private onAcceptCheckForNameDifCif(data: { res: AcceptionResult, difItems: ChangeDifferenceEntity[] }) {

        // Stateに登録,送信レコードと受信レコードをマッピングする
        const sendedAccount: CifInfo[] = this.getSendedAccount(data.difItems);

        const acceptResult: Array<{ customerId: string, accounts: AcceptionResultAccount }> =
            this.getAcceptCheckResult(sendedAccount, data);

        this.setSubmitData('nameidentiNameDifCifAcceptCheckResult', acceptResult);

        this.sendSignal(ExistingSavingsSignal.ACCEPT_TARGET_FOR_NAME_DIF_CIF, data.res);
    }

    @ActionBind(ExistingSavingsActionType.ACCEPT_CHECK_FOR_ADDRESS_DIF_CIF)
    private onAcceptCheckForAddressDifCif(data: { res: AcceptionResult, difItems: ChangeDifferenceEntity[] }) {
        // Stateに登録,送信レコードと受信レコードをマッピングする
        const sendedAccount: CifInfo[] = this.getSendedAccount(data.difItems);

        const acceptResult: Array<{ customerId: string, accounts: AcceptionResultAccount }> =
            this.getAcceptCheckResult(sendedAccount, data);

        this.setSubmitData('nameidentiAddressDifCifAcceptCheckRestlt', acceptResult);

        this.sendSignal(ExistingSavingsSignal.ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF, data.res);
    }

    @ActionBind(ExistingSavingsActionType.ACCEPT_CHECK_FOR_TEL_DIF_CIF)
    private onAcceptCheckForTelDifCif(data: { res: AcceptionResult, difItems: ChangeDifferenceEntity[] }) {

        // Stateに登録,送信レコードと受信レコードをマッピングする
        const sendedAccount: CifInfo[] = this.getSendedAccount(data.difItems);

        const acceptResult: Array<{ customerId: string, accounts: AcceptionResultAccount }> =
            this.getAcceptCheckResult(sendedAccount, data);

        this.setSubmitData('nameidentiTelDifCifAcceptCheckResult', acceptResult);

        this.sendSignal(ExistingSavingsSignal.ACCEPT_TARGET_FOR_TEL_DIF_CIF, data.res);
    }

    // カード交付方法に郵送をセット
    @ActionBind(ExistingSavingsActionType.SET_DATA)
    private setMailDelivery() {
        this.setSubmitData('receiptMethod', CashCardDeliveryType.MAIL_CODE);
    }

    /**
     * 内部API: 保有通帳・カード・印鑑情報照会のレスポンスをstateにセットする
     * @param data APIのレスポンス
     */
    @ActionBind(ExistingSavingsActionType.SET_MEDIUM_INFO)
    private setMediumInfo(data: MediumInfosResponse) {
        this.setSubmitData('mediumInfos', data);
        this.sendSignal(ExistingSavingsSignal.GET_MEDIUM_INFO);
    }

    /**
     * ワンセットカードの暗証番号をクリア
     */
    @ActionBind(ExistingSavingsActionType.CLEAR_ONE_SET_CARD_PASSWORD)
    private clearOneSetCardPassword() {
        this.state.submitData.savingAccountFirstPwd4bits = undefined;
        this.state.submitData.savingsDepositAccountFirstPwd4bits = undefined;
    }

    /**
     * 本人確認書類をクリア
     */
    @ActionBind(ExistingSavingsActionType.CLEAR_PART_ALL_DOCUMENT)
    private clearPartIdentificationDocument() {
        // 本人確認書類１の名称、画像、書類コード、有効期限
        this.setSubmitData('identificationDocument1', undefined);
        this.setSubmitData('identificationDocument1Images', undefined);
        this.setSubmitData('identificationDocument1ExpiryDate', undefined);
        this.setSubmitData('identificationDocument1ExpiryDateText', undefined);
        this.setSubmitData('identificationDocument1Text', undefined);
        this.setSubmitData('documentListName', undefined);
        // 本人確認書類２の名称、画像、書類コード、有効期限
        this.setSubmitData('identificationDocument2', undefined);
        this.setSubmitData('identificationDocument2Images', undefined);
        this.setSubmitData('identificationDocument2ExpiryDate', undefined);
        this.setSubmitData('identificationDocument2ExpiryDateText', undefined);
        this.setSubmitData('identificationDocument2Text', undefined);
        this.setSubmitData('documentListName2', undefined);
        // 免許証番号
        this.setSubmitData('identificationDocumentLicenseNo', undefined);
        // 現住所確認書類の名称、画像、有効期限
        this.setSubmitData('addressConfirmationDocumentName', undefined);
        this.setSubmitData('identificationAddressImages', undefined);
        this.setSubmitData('identificationAddressExpiryDate', undefined);
        this.setSubmitData('identificationAddressExpiryDateText', undefined);

    }

    /**
     * 諸届側の本人確認書類をクリア
     */
    @ActionBind(ExistingSavingsActionType.CLEAR_CHANGE_DOCUMENT)
    private clearChangeIdentificationDocument() {
        this.setSubmitData('identificationDocument3X', undefined);
        this.setSubmitData('identificationDocument3XName', undefined);
        this.setSubmitData('documentListNameX', undefined);
        this.setSubmitData('identificationDocument3A', undefined);
        this.setSubmitData('identificationDocument3AName', undefined);
        this.setSubmitData('identificationDocument3B', undefined);
        this.setSubmitData('identificationDocument3BName', undefined);
        this.setSubmitData('identificationDocument3C', undefined);
        this.setSubmitData('identificationDocument3CName', undefined);
        this.setSubmitData('documentListNameC', undefined);
        this.state.changeDocumentImages = {};
        this.state.orderChangeDocument = [];
        this.state.orderChangeDocumentName = [];
    }
    /**
     * 本人確認書類をクリア
     */
    @ActionBind(ExistingSavingsActionType.CLEAR_ALL_DOCUMENT)
    private clearIdentificationDocument() {
        // 本人確認書類１の名称、画像、書類コード、有効期限
        this.setSubmitData('identificationDocument1', undefined);
        this.setSubmitData('identificationDocument1Images', undefined);
        this.setSubmitData('identificationDocument1ExpiryDate', undefined);
        this.setSubmitData('identificationDocument1ExpiryDateText', undefined);
        this.setSubmitData('identificationDocument1Text', undefined);
        this.setSubmitData('documentListName', undefined);
        // 本人確認書類２の名称、画像、書類コード、有効期限
        this.setSubmitData('identificationDocument2', undefined);
        this.setSubmitData('identificationDocument2Images', undefined);
        this.setSubmitData('identificationDocument2ExpiryDate', undefined);
        this.setSubmitData('identificationDocument2ExpiryDateText', undefined);
        this.setSubmitData('identificationDocument2Text', undefined);
        this.setSubmitData('documentListName2', undefined);
        // 免許証番号
        this.setSubmitData('identificationDocumentLicenseNo', undefined);
        // 現住所確認書類の名称、画像、有効期限
        this.setSubmitData('addressConfirmationDocumentName', undefined);
        this.setSubmitData('identificationAddressImages', undefined);
        this.setSubmitData('identificationAddressExpiryDate', undefined);
        this.setSubmitData('identificationAddressExpiryDateText', undefined);

        // 届出変更
        this.setSubmitData('identificationDocument3X', undefined);
        this.setSubmitData('identificationDocument3XName', undefined);
        this.setSubmitData('documentListNameX', undefined);
        this.setSubmitData('identificationDocument3A', undefined);
        this.setSubmitData('identificationDocument3AName', undefined);
        this.setSubmitData('identificationDocument3B', undefined);
        this.setSubmitData('identificationDocument3BName', undefined);
        this.setSubmitData('identificationDocument3C', undefined);
        this.setSubmitData('identificationDocument3CName', undefined);
        this.setSubmitData('documentListNameC', undefined);
        this.setSubmitData('bcSuicaResult', undefined);
        this.setSubmitData('americanSuggestionInformationStatus', undefined);
        this.setSubmitData('firstNameRoma', undefined);
        this.setSubmitData('lastNameRoma', undefined);
        this.state.changeDocumentImages = {};
        this.state.orderChangeDocument = [];
        this.state.orderChangeDocumentName = [];

        // 学生証
        this.setSubmitData('identificationStudentImages', undefined);
        // 連絡事項
        this.setSubmitData('contactNote', undefined);

        // マスキングチェックボックス初期化
        this.state.checkboxStatusForChange = {
            isAllMaskingStatus: false
        };
        this.state.checkboxStatus = {
            receiptMethodStatus: false,
            confirmationStatus: false,
            isAntisocialStatus: false,
            isForeignPulicFiguresSatus: false,
            isJapaneseResidentStatus: true,
            isRegulationStatus: true,
            isAllMaskingStatus: false,
            isCheckBranchStatus: false
        };
    }

    // BCバンクカードSuica喪失届出済をセット
    @ActionBind(ExistingSavingsActionType.SET_BC_SUICA_LOST)
    private setBcSuicaLost() {
        this.setSubmitData('bcSuicaResult', BcSuicaResult.LOST);
    }

    /**
     * itemListにて表示する取引ぶりリストの作成
     */
    private getTempPayload(acceptCheckResult: Array<{ customerId: string, accounts: AcceptionResultAccount }>) {
        const tempPayload: string[] = [];
        acceptCheckResult.forEach((item) => {
            item.accounts.tradingConditions.forEach((tradingCondition) => {
                if ((tradingCondition.tradingConditionCode !== DBConsts.SpecTransactionCode.houseLoan &&
                    tradingCondition.tradingConditionCode !== DBConsts.SpecTransactionCode.bondCustomers &&
                    tradingCondition.tradingConditionCode !== DBConsts.SpecTransactionCode.goldBullion &&
                    tradingCondition.tradingConditionCode !== DBConsts.SpecTransactionCode.safeDepositBox) &&
                    tempPayload.indexOf(tradingCondition.tradingConditionName) === -1) {
                    const cifInfo = this.state.submitData.allCifInfos.filter(
                        (element) => element.customerId === item.customerId
                    );
                    tempPayload.push(this.getTradingConditionName(
                        cifInfo[0].birthDate, tradingCondition));
                }
            });
        });

        return tempPayload;
    }

    /**
     * 住所コードを格納する
     * @param data APIのレスポンス
     */
    @ActionBind(ExistingSavingsActionType.SET_ADDRESS_CODE)
    private setAddressCode(data: any) {
        this.setSubmitData('holderAddressCode', data.addressCode);
        this.sendSignal(ExistingSavingsSignal.GET_ADDRESS_CODE);
    }

    /**
     * 郵便番号をクリア
     */
    @ActionBind(ExistingSavingsActionType.CLEAR_ZIP_CODE)
    private clearZipCode() {
        this.state.submitData.firstZipCode = undefined;
        this.state.submitData.lastZipCode = undefined;
    }
    @ActionBind(ExistingSavingsActionType.RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES)
    private resetSpecialNotMaskingConfirmImages(specalDocumentName: string) {
        const _documentResetFn = (documentName: string) => {
            // 書類の保存タイプはboolean
            if (typeof this.state.notMaskingConfirmImages[documentName] === 'boolean') {
                this.state.notMaskingConfirmImages[documentName] = false;

                if (this.state.submitData[documentName]) {
                    this.state.notMaskingConfirmImages[documentName] = true;
                }
            } else {
                // 書類の保存タイプは配列
                this.state.notMaskingConfirmImages[documentName] = [];

                if (this.state.submitData[documentName]) {
                    this.state.submitData[documentName].forEach(
                        (item, index) => {
                            this.state.notMaskingConfirmImages[documentName].push(index);
                        }
                    );
                }
            }
        };

        _documentResetFn(specalDocumentName);
    }

    /**
     * 撮影した書類名称を保存
     * @param params
     */
    @ActionBind(ExistingSavingsActionType.SAVE_DOCUMENT_NAME)
    private saveDocumentName(params: { key: string, value: string }) {
        this.setSubmitData(params.key, params.value);
    }

    /**
     * 名寄せリストを格納
     * @param data
     */
    @ActionBind(ExistingSavingsActionType.CUSTOMER_INFOS_LIST)
    private customerInfosList(data) {
        const allCiftradingConditions: AllCiftradingConditions = new AllCiftradingConditions();
        allCiftradingConditions.tradingConditons = [];
        const customerInfos = data.res.customerInfo;
        customerInfos.forEach((customerInfo) => {
            customerInfo.tradingConditions.forEach((tradingCondition) => {
                const tradingConditons: TradingConditionCode = new TradingConditionCode();
                tradingConditons.tradingConditionCode = tradingCondition;
                allCiftradingConditions.tradingConditons.push(tradingConditons);

            });
        });
        this.setSubmitData('allCifTradingConditions', allCiftradingConditions);
        this.sendSignal(ExistingSavingsSignal.CUSTOMER_INFOS_LIST);
    }

    /**
     * 受付可否チェックにかけたCIFの配列の作成
     */
    private getSendedAccount(difItems: ChangeDifferenceEntity[]) {
        const sendedAccount: CifInfo[] = [];

        this.state.submitData.allCifInfos.forEach((element) => {
            if (element.customerId !== this.state.submitData.customerId) {
                difItems.forEach((difItem) => {
                    if (element.customerId === difItem.customerId && difItem.isDifference) {
                        sendedAccount.push(element);
                    }
                });
            }
        });

        return sendedAccount;
    }

    private getAcceptCheckResult(sendedAccount: CifInfo[], data: { res: AcceptionResult, difItems: ChangeDifferenceEntity[] }) {
        const acceptResult: Array<{ customerId: string, accounts: AcceptionResultAccount }> = [];

        sendedAccount.forEach((item, index) => {
            data.difItems.forEach((difItem) => {
                if (item.customerId === difItem.customerId && difItem.isDifference) {
                    acceptResult.push({ customerId: item.customerId, accounts: data.res.accounts[index] });
                }
            });
        });

        return acceptResult;
    }

    /**
     * Skip node
     * @param nextOrder the order skip to
     */
    @ActionBind(ExistingSavingsActionType.SKIP)
    private skip() {
        this.state.showChats.pop();
    }

    /**
     * set 地域コード情報（地域コード と 地域コード判定方法)
     * @param data データ
     */
    @ActionBind(ExistingSavingsActionType.SEARCH_REGION_CODE)
    private setRegionCode(data: any) {
        this.state.regionCodeInfo.regionCode = data.regionCode;
        this.state.regionCodeInfo.regionCodeDeterminationMethod = data.regionCodeDeterminationMethod;
        this.sendSignal(ExistingSavingsSignal.SEARCH_REGION_CODE_COMPLETE, data);
    }

    @ActionBind(ExistingSavingsActionType.DIFFERENCE_FLG_BACKUP)
    private differenceFlgBackup() {
        this.state.isNameDifferenceBackup = this.state.isNameDifference;
        this.state.isAddressDifferenceBackup = this.state.isAddressDifference;
        this.state.isTelphoneDifferenceBackup = this.state.isTelphoneDifference;
    }

    @ActionBind(ExistingSavingsActionType.CLEAR_HOLDER_NAME)
    private clearHolderName() {
        if (this.state.submitData.nationalityCode === CountryCode.Japan) {
            this.setSubmitData('existingChangeHolderName', undefined);
            this.setSubmitData('existingChangeFirstName', undefined);
            this.setSubmitData('existingChangeLastName', undefined);
            this.setSubmitData('existingChangeHolderNameFurigana', undefined);
            this.setSubmitData('existingChangeFirstNameKana', undefined);
            this.setSubmitData('existingChangeLastNameKana', undefined);
        } else {
            this.setSubmitData('existingChangeHolderName', undefined);
            this.setSubmitData('existingChangeFirstName', undefined);
            this.setSubmitData('existingChangeLastName', undefined);
            this.setSubmitData('existingChangeHolderNameFurigana', undefined);
            this.setSubmitData('existingChangeFirstNameKana', undefined);
            this.setSubmitData('existingChangeLastNameKana', undefined);
            this.setSubmitData('existingChangeHolderNameAlphabet', undefined);
            this.setSubmitData('existingChangeFirstNameAlphabet', undefined);
            this.setSubmitData('existingChangeLastNameAlphabet', undefined);
        }
    }

    @ActionBind(ExistingSavingsActionType.CLEAR_HOLDER_ADDRESS)
    private clearHolderAddress() {
        this.setSubmitData('holderZipCode', undefined);
        this.setSubmitData('firstZipCode', undefined);
        this.setSubmitData('lastZipCode', undefined);
        this.setSubmitData('holderAddressPrefecture', undefined);
        this.setSubmitData('holderAddressPrefectureFurigana', undefined);
        this.setSubmitData('holderAddressPrefectureFuriKana', undefined);
        this.setSubmitData('holderAddressCountyUrbanVillage', undefined);
        this.setSubmitData('holderAddressCountyUrbanVillageFurigana', undefined);
        this.setSubmitData('holderAddressCountyUrbanVillageFuriKana', undefined);
        this.setSubmitData('holderAddressStreetNameSelect', undefined);
        this.setSubmitData('holderAddressStreetNameFuriganaSelect', undefined);
        this.setSubmitData('holderAddressStreetNameFuriKanaSelect', undefined);
        this.setSubmitData('holderAddressStreetNameInput', undefined);
        this.setSubmitData('holderAddressStreetNameFuriganaInput', undefined);
        this.setSubmitData('holderAddressStreetNameFuriKanaInput', undefined);
        this.setSubmitData('holderAddressStreet', undefined);
        this.setSubmitData('holderAddressStreetFurigana', undefined);
        this.setSubmitData('showStreet', undefined);
        this.setSubmitData('streetWork', undefined);
        this.setSubmitData('holderAddressHouseNumber', undefined);
        this.setSubmitData('holderAddressHouseNumberFurigana', undefined);
        this.setSubmitData('holderAddressHouseNumberFuriKana', undefined);
    }

    @ActionBind(ExistingSavingsActionType.CLEAR_HOLDER_PHONE_NO)
    private clearHolderPhoneNo() {
        this.setSubmitData('existingChangeHolderMobileNo', undefined);
        this.setSubmitData('existingChangeFirstMobileNo', undefined);
        this.setSubmitData('existingChangeSecondMobileNo', undefined);
        this.setSubmitData('existingChangeThirdMobileNo', undefined);
        this.setSubmitData('existingChangeHolderTelephoneNo', undefined);
        this.setSubmitData('existingChangeFirstTel', undefined);
        this.setSubmitData('existingChangeSecondTel', undefined);
        this.setSubmitData('existingChangeThirdTel', undefined);
        this.setSubmitData('holderMobileNo', undefined);
        this.setSubmitData('holderTelephoneNo', undefined);
    }

    @ActionBind(ExistingSavingsActionType.CLEAR_ADD_CHECK_DATA)
    private clearAddCheckData() {
        this.setStateSubmitDataValues([{ key: 'bcSuicaResult', value: undefined }]);
        this.setStateSubmitDataValues([{ key: 'americanSuggestionInformationStatus', value: undefined }]);
        this.setStateSubmitDataValues([{ key: 'firstNameRoma', value: undefined }]);
        this.setStateSubmitDataValues([{ key: 'lastNameRoma', value: undefined }]);
    }

    /**
     * BC複合取引情報を保存する。
     */
    @ActionBind(ExistingSavingsActionType.SAVE_CREDIT_CARD_DATA)
    private saveCreditCardData(creditCardSubmitData: any) {
        // 職業
        this.setSubmitData('career', creditCardSubmitData.career);
        // 卒業90日以内のフラグ
        this.setSubmitData('isNearGraduate', creditCardSubmitData.isNearGraduate);
        this.setSubmitData('identificationStudentImages', creditCardSubmitData.identificationStudentImages);
    }

    @ActionBind(ExistingSavingsActionType.CLEAR_WORK_OR_CRS)
    private clearWorkAndCrs(data: ClearWorkOrCrs) {
        if (data === ClearWorkOrCrs.WORK) {
            this.state.submitData.holderCareer = undefined;  // 職業
            this.state.submitData.holderWorkPlace = undefined; // 勤務先
            this.state.submitData.accountOpeningPurpose = undefined; // 目的
        }

        if (data === ClearWorkOrCrs.CRS) {
            this.state.submitData.agentCountryJapanText = undefined;
            this.state.submitData.isJapanLive = undefined; // 税法上が日本ですか
            this.state.submitData.agentCountry = undefined; // 日本以外の住む国
            this.state.submitData.w9AmericanSuggestionInfo = undefined;
            this.state.submitData.otherCountry = undefined; // 他の国名
            this.state.submitData.sign = undefined; // 署名
            this.state.submitData.isSsnHave = undefined; // ssn持っているかどうか
            this.state.submitData.isTaxForAmerican = undefined;
            this.state.submitData.fatcaCountry = undefined;
            this.state.submitData.signFatca = undefined;
            this.state.submitData.isSsnWrite = undefined;
            this.state.submitData.socialSecurityNumber = undefined;
            this.state.submitData.nameEnglish = undefined;
            this.state.submitData.addressEnglish = undefined;
            this.state.submitData.cityOrTown = undefined;
            this.state.submitData.province = undefined;
            this.state.submitData.agentCountryEnglish = undefined;
            this.state.submitData.signOath = undefined;
            this.state.submitData.signAgree = undefined;
            this.state.submitData.isGreenCardHave = undefined;
            this.state.submitData.fatcaStatus = undefined;
        }
    }

    @ActionBind(ExistingSavingsActionType.RESTORE_WORK_OR_CRS)
    private restoreWorkAndCrs(data: ClearWorkOrCrs) {
        this.state.submitData = Object.assign(new ExistingSavingsSubmitEntity(), this.state.copySubmitData);
    }

    /**
     * ICカードの情報をstateに登録
     *
     * @private
     * @param {string} data
     * @memberof SavingsStore
     */
    @ActionBind(ExistingSavingsActionType.SET_IC_DATA)
    private setIcData(data: string) {
        this.state.icData = data;
    }

    /**
     * ユーザーカード番号を保存
     */
    @ActionBind(ExistingSavingsActionType.SET_USER_CARD_PAN)
    private setPanApd(code: any) {
        Object.keys(code).forEach((key) => {
            this.setSubmitData(key, code[key]);
        });
    }

    /**
     * 全店名寄せ情報をセット
     */
    @ActionBind(ExistingSavingsActionType.NAME_AGGREGATION)
    private setAllCifInfos(data: { customerInfo: CifInfo[], customerSearchStatus: string }) {
        if (data) {
            this.setSubmitData('allCifInfos', data.customerInfo);
            this.setSubmitData('customerSearchStatus', data.customerSearchStatus);
            this.state.submitData.allCifInfos.forEach((cifInfo) => {
                cifInfo.kanaName = StringUtils.convertHankaku2Zankaku(cifInfo.kanaName);
                if (cifInfo.addressInfo) {
                    cifInfo.addressInfo.kanaAddress = StringUtils.convertHankaku2Zankaku(cifInfo.addressInfo.kanaAddress);
                    cifInfo.addressInfo.kanaAuxiliaryAddress = StringUtils.convertHankaku2Zankaku(cifInfo.addressInfo.kanaAuxiliaryAddress);
                }
                if (cifInfo.address2Info) {
                    cifInfo.address2Info.kanaAddress2 = StringUtils.convertHankaku2Zankaku(cifInfo.address2Info.kanaAddress2);
                }
            });
            this.makeBranchList();
        }
        this.sendSignal(ExistingSavingsSignal.GET_NAME_AGGREGATION_INQUIRY);
    }

    private makeBranchList() {
        const allBranchNameList: string[] = [];
        const customerIdList: string[] = [];
        const branchNameList: string[] = [];
        const firstIndex: string = '１';
        this.state.submitData.allCifInfos.forEach((cifInfo) => {
            let branchName = cifInfo.customerManagementBranchName;
            // 支店名が重複した場合、同一支店名リスト作成（初回ループは作成なし）
            const sameBranchNameList = allBranchNameList.filter((item) => item === branchName);
            allBranchNameList.push(branchName);
            // 同一支店名編集
            if (sameBranchNameList.length > 0) {
                if (sameBranchNameList.length === 1) {
                    // 先頭の支店名に”１”を付与
                    const editIndex = branchNameList.findIndex((item) => item === branchName);
                    branchNameList[editIndex] += firstIndex;
                }
                // 同一支店名に数字を付与
                branchName += (sameBranchNameList.length + 1);
                branchName = StringUtils.convertHankaku2Zankaku(branchName);
            }
            branchNameList.push(branchName);
            customerIdList.push(cifInfo.customerId);
        });
        this.setSubmitData('branchNameList', branchNameList);
        // 後続業務で利用するためEntity型の情報も保存する
        const branchNameListEntity: BranchNameListEntity[] = [];
        for (let i = 0; i < this.state.submitData.allCifInfos.length; i++) {
            branchNameListEntity.push({ branchName: branchNameList[i], customerId: customerIdList[i] });
        }
        this.setSubmitData('branchNameListEntity', branchNameListEntity);

    }

    /**
     * 受付可否チェック(喪失・破損)のレスポンスをstateにセットする
     * @param data APIのレスポンス
     */
    @ActionBind(ExistingSavingsActionType.RECEPTION_LOSS_CORRUPTION_CHECK)
    private onAcceptCheck2(param: {
        name?: string, data: ReceptionLossCorruptionCheckResponse,
        requestParams: ReceptionLossCorruptionCheckRequest
    }) {
        // 受付可否チェックの実行結果を保存する
        if (param.name) {
            this.setSubmitData(param.name, param.data);
        } else {
            // 内部API:受付可否チェック（喪失・破損）と内部API:受付可否チェックのレスポンス構造差分吸収
            // MVP3向けAPIレスポンスを、MVP2向けAPIレスポンスの型に合わせ、後続処理への影響を軽減。
            const response = param.data instanceof HttpStatusError ? param.data : {
                errorCode: param.data.errorCode,
                errorType: param.data.errorType,
                resultCode: param.data.resultCode,
                unacceptables: param.data.accounts[0].unacceptables
            };
            Object.keys(response).forEach((key) => {
                this.setSubmitData(key, response[key]);
            });
        }

        // エラーモーダル表示用データを作成する
        let responseForModal: Array<{
            customerId?: string, branchCode?: string, subjectCode?: string, bankAccountId?: string,
            accounts: ReceptionCheckAccountInfo
        }> = [];

        if (param.data && (this.isHostError(param.data.errorCode) ||
            param.data.accounts.some((accountInfo) => this.isHostError(accountInfo.errorCode)))) {
            if (param.data.accounts) {
                for (let i = 0; i < param.data.accounts.length; i++) {
                    if (param.requestParams.params.accounts[i].customerId) {
                        responseForModal.push(
                            {
                                customerId: param.requestParams.params.accounts[i].customerId,
                                accounts: param.data.accounts[i]
                            }
                        );
                    } else {
                        responseForModal.push(
                            {
                                branchCode: param.requestParams.params.accounts[i].tenban,
                                subjectCode: param.requestParams.params.accounts[i].accountType,
                                bankAccountId: param.requestParams.params.accounts[i].accountNo,
                                accounts: param.data.accounts[i]
                            }
                        );
                    }
                }
            }
        } else {
            // エラーがない場合はresponseForModalにundefinedを設定
            responseForModal = undefined;
        }
        // 後続処理にてモーダル表示のため、stateに格納
        this.setSubmitData('responseForModal', responseForModal);

        this.sendSignal(ExistingSavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK);
    }

    /**
     * 返却されたエラーコードが、受付可否チェック検出対象かを確認する。
     */
    private isHostError(errorCode: string): boolean {
        return (Object.keys(HostErrorCodeReceptionNG).some((key) => HostErrorCodeReceptionNG[key] === errorCode));
    }

    /**
     * 受付可否チェック(喪失・破損)のレスポンスをstateにセットする。
     * エラー情報が存在する場合、追加する。
     * @param data APIのレスポンス
     */
    @ActionBind(ExistingSavingsActionType.RECEPTION_LOSS_CORRUPTION_CHECK_ADD)
    private onAcceptCheckAndResponseAdd(param: {
        name?: string, data: ReceptionLossCorruptionCheckResponse,
        requestParams: ReceptionLossCorruptionCheckRequest
    }) {
        // 受付可否チェックの実行結果を保存する
        if (param.name) {
            this.setSubmitData(param.name, param.data);
        } else {
            // 内部API:受付可否チェック（喪失・破損）と内部API:受付可否チェックのレスポンス構造差分吸収
            // MVP3向けAPIレスポンスを、MVP2向けAPIレスポンスの型に合わせ、後続処理への影響を軽減。
            const response = param.data instanceof HttpStatusError ? param.data : {
                errorCode: param.data.errorCode,
                errorType: param.data.errorType,
                resultCode: param.data.resultCode,
                unacceptables: param.data.accounts[0].unacceptables
            };
            Object.keys(response).forEach((key) => {
                this.setSubmitData(key, response[key]);
            });
        }

        // エラーモーダル表示用データを作成する(前回チェック時のエラーデータが存在する場合は追記する)
        let responseForModal: Array<{
            customerId?: string, branchCode?: string, subjectCode?: string, bankAccountId?: string,
            accounts: ReceptionCheckAccountInfo
        }> = this.state.submitData.responseForModal ? this.state.submitData.responseForModal : [];

        if (param.data && (this.isHostError(param.data.errorCode) ||
            param.data.accounts.some((accountInfo) => this.isHostError(accountInfo.errorCode)))) {
            if (param.data.accounts) {
                for (let i = 0; i < param.data.accounts.length; i++) {
                    if (param.requestParams.params.accounts[i].customerId) {
                        responseForModal.push(
                            {
                                customerId: param.requestParams.params.accounts[i].customerId,
                                accounts: param.data.accounts[i]
                            }
                        );
                    } else {
                        responseForModal.push(
                            {
                                branchCode: param.requestParams.params.accounts[i].tenban,
                                subjectCode: param.requestParams.params.accounts[i].accountType,
                                bankAccountId: param.requestParams.params.accounts[i].accountNo,
                                accounts: param.data.accounts[i]
                            }
                        );
                    }
                }
            }
        }

        // エラーがない場合はresponseForModalにundefinedを設定
        if (!responseForModal.length) {
            responseForModal = undefined;
        }

        // 後続処理にてモーダル表示のため、stateに格納
        this.setSubmitData('responseForModal', responseForModal);

        this.sendSignal(ExistingSavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK_ACCOUNT);
    }

    /**
     * cif情報をセット
     */
    @ActionBind(ExistingSavingsActionType.SET_CIF_INFO_BY_CARD_SWIP)
    private setCifInfoByCardSwip(data: any) {
        const info = data.errors && data.errors.data ? data.errors.data.cifInfoInquiryResponse
            : data.result.cifInfoInquiryResponse;
        if (!info) {
            return;
        }
        Object.keys(info).forEach((key) => {
            // SWなしの場合、店番と店舗名をnullで上書きされない
            if (!this.state.submitData.selectTenpoCustomerId && (key === 'tenban' || key === 'branchName')) {
                return;
            }
            this.setSubmitData(key, info[key]);
        });

        this.setSubmitData('addressKana', StringUtils.convertHankaku2Zankaku(info.addressKana));
        this.setSubmitData('nameKana', StringUtils.convertHankaku2Zankaku(info.nameKana));

        // 漢字変換不可フラグがtrueの場合、かな名を設定する。
        if (this.state.submitData.nameNonConvert === NameNonConvert.OFF) {
            this.setSubmitData('nameKanjiBackup', this.state.submitData.nameKanjiBackup || this.state.submitData.nameKanji);
            this.setSubmitData('nameKanji', this.state.submitData.nameKana);
        }

        // 16歳以上年齢フラグ設定
        this.setHolderAgeFlag({
            birthdate: info.birthdate,
            agentBirthdate: info.agentBirthdate,
            today: info.tabletStartDate
        });

        if (data.errors && data.errors.data && this.isHostError(data.errors.data.errorCode)) {
            this.setSubmitData('resultCode', data.errors.data.resultCode);
            this.setSubmitData('errorCode', data.errors.data.errorCode);
            this.setSubmitData('errorType', data.errors.data.errorType);
            this.setSubmitData('unacceptables', data.errors.data.unacceptables);

            const unacceptableCode = data.errors.data.unacceptables.map((unacceptable: any) => {
                return unacceptable.unacceptableCode;
            }).join('/');
            this.setSubmitData('unacceptableCode', unacceptableCode);

            // 受付可否チェック、エラーモーダル表示用データを作成する
            const responseForModal: Array<{ customerId: string, accounts: ReceptionCheckAccountInfo }> = [
                {
                    customerId: info.customerId,
                    accounts: {
                        resultCode: data.errors.data.resultCode,
                        errorType: data.errors.data.errorType,
                        errorCode: data.errors.data.errorCode,
                        customerId: info.customerId,
                        unacceptables: data.errors.data.unacceptables,
                        tradingConditions: null,
                        unprintableKanji: null,
                        hasLoanAccountHoldingDetails: null,
                    }
                }
            ];
            // 後続処理にてモーダル表示のため、stateに格納
            this.setSubmitData('responseForModal', responseForModal);

        }
        if (info.nextTabletApplyId) {
            this.setSubmitData('tabletApplyId', info.nextTabletApplyId);
        }
    }

    /**
     * 16歳以上年齢フラグ設定
     * @param params birthdate: 生年月日, today: システム日付
     */
    private setHolderAgeFlag(params: any) {
        this.setSubmitData(
            'holderAgeFlag',
            !InputUtils.validateAge(params.birthdate, Age.Age_16,
                params.today) ? HolderAgeRange.BELOW_16 : HolderAgeRange.ABOVE_16
        );
        if (params.agentBirthdate) {
            this.setSubmitData(
                'agentAgeFlag',
                !InputUtils.validateAge(params.agentBirthdate, Age.Age_16,
                    params.today) ? HolderAgeRange.BELOW_16 : HolderAgeRange.ABOVE_16
            );
        }
    }

    /**
     *  OCR読取した免許証が運転経歴証明書だった場合のstate更新処理
     *
     * @private
     * @memberof SavingsStore
     */
    @ActionBind(ExistingSavingsActionType.SET_STATE_DATA_FOR_HAS_DRIVERS_CAREER_LICENSE)
    private setStateDataForHasDriversCareerLicense() {
        // OCR読取した免許証が運転経歴証明書だった場合に処理を実行
        if (this.state.submitData.hasLicense === Constants.DriveCard
            && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES) {
            // 免許証を持っていないステータスに変更
            this.setSubmitData('hasLicense', HasLicense.HAS_NOT_LICENSE);

            // 本人の場合の本人確認書類情報をstateにセット
            this.setSubmitData('identificationDocument1', IdentificationDocumentCode.OTHER_IDENTIFICATION_DOCUMENT);
            this.setSubmitData(
                'identificationDocument1Text', this.labelService.labels.confirm.identityDocumentConfirm.otherIdentificationDocument
            );
            this.setSubmitData('documentListName', this.labelService.labels.confirm.identityDocumentConfirm.driversCareerLicense);
            // 運転経歴証明書を再撮影した場合、再撮影後の画像データは
            // identificationDocument1Imagesに格納されているので最初にOCR撮影した画像で書き換わらないようにする
            if (this.state.submitData.identificationDocument1Images === undefined) {
                // identificationDocument1Imagesがundefinedの場合、OCR撮影した画像データを格納する
                this.setSubmitData(
                    'identificationDocument1Images', [this.state.submitData.holderCardImageFront, this.state.submitData.holderCardImageBack]
                );
            }
            this.setSubmitData('identificationDocument1ExpiryDate', COMMON_CONSTANTS.DEFAULT_EXPIRY_DATE);
            this.setSubmitData('identificationDocument1ExpiryDateText', this.labelService.labels.picker.skipExpiryDate);
            this.setSubmitData('idInfoMethod', IdentificationDocumentMethod.PRESENT_ONE_TYPE);

            // OCR読取ありの場合の画像保存変数を初期化
            // 撮影した画像はOCR読取なしの場合の画像保存変数に移行済みのため重複を防ぐ
            this.state.submitData.holderCardImageFront = undefined;
            this.state.submitData.holderCardImageBack = undefined;

        }
    }

    /**
     * ORC聴取の場合、有効期限をバックアップ
     */
    @ActionBind(ExistingSavingsActionType.BACKUP_OCR_DUE_DATE)
    private backupOCRDueDate() {
        if (this.state.submitData.hasLicense === HasLicense.HAS_NOT_LICENSE
            && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES
            || this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
            this.setStateSubmitDataValues([
                {
                    key: 'identificationDocument1ExpiryDate',
                    value: this.savingsStore.getState().ocrEntity.dueDate
                },
                {
                    key: 'identificationDocument1ExpiryDateText',
                    value: this.savingsStore.getState().ocrEntity.dueDateWareki
                }
            ]);
        }
    }

    /**
     * 内部API: 顧客情報照会のレスポンスをstateにセットする
     * @param data APIのレスポンス
     */
    @ActionBind(ExistingSavingsActionType.SET_CUSTOMER_INFO)
    private setCustomerInfo(data: any) {
        // 複数件の顧客情報をそのままsubmitData.cifInfosListへ設定する
        if (data && data.cifInfoInquiryResponses && data.cifInfoInquiryResponses.length > 0) {
            this.setSubmitData('cifInfosList', data.cifInfoInquiryResponses);
        }
        this.sendSignal(ExistingSavingsSignal.GET_CUSTOMER_INFO);
    }

    @ActionBind(ExistingSavingsActionType.GO_BACK_RELATE_CHAT)
    private gobackRelateChat() {
        this.getState().showChats.splice(this.state.showChats.length - 2, 2);
    }

    /**
     * 修正チャットで有効期限がクリア状態か判別するフラグを保存する。
     */
    @ActionBind(ExistingSavingsActionType.MODIFY_EXPIRY_DATE_EXISTS)
    private setModifyExpiryDateExists(value) {
        this.state.modifyExpiryDateExists = value;
    }
}
