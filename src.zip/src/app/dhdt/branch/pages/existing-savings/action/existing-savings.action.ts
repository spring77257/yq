import { Injectable, NgZone } from '@angular/core';
import { Action } from 'adep/flux';
import { AppProperties } from 'app.properties';
import { ChangeDifferenceEntity } from 'dhdt/branch/pages/change/entity/change-questions.model';
import {
    API_URL, ApplyDate, ClearSavingImagesClickRecordType, ClearWorkOrCrs, CodeCategory, Constants,
    HostResultCode, RegionCodeDeterminationMethod, StoreChanged, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import {
    ExistingSavingsQuestionsModel, ExistingSavingsSubmitEntity
} from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import {
    ReceptionLossCorruptionCheckRequest
} from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-request.entity';
import { AcceptionResult } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { FilteringParameterEntity } from 'dhdt/branch/shared/entity/filtering-parameter.entity';
import { RegionCodeEntity, RegionCodeSearchRequestEntity } from 'dhdt/branch/shared/entity/region-code.entity';
import { AccountBalanceInquiryInterface } from 'dhdt/branch/shared/interface/account-balance-inquiry.interface';
import { AccountInfoInquiryInterface } from 'dhdt/branch/shared/interface/account-info-inquiry.interface';
import { ExistingPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/existing-password-rule-check.interface';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { DocumentCategorySubjectData } from 'dhdt/branch/shared/modules/document-category/entity/document-category.entity';
import { DocumentCategoryObserverAction } from 'dhdt/branch/shared/modules/document-category/service/document-category.service';
import { HostErrorService } from 'dhdt/branch/shared/services/host-error.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { HttpService, HttpStatus } from 'dhdt/branch/shared/services/http.service';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { NameBasedAggregationService } from 'dhdt/branch/shared/services/name-based-aggregation.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { Observable } from 'rxjs/Observable';
import { map, tap } from 'rxjs/operators';

export namespace ExistingSavingsActionType {
    export const GET_SAVING_QUESTION_TEMPLATE: string = 'ExistingSavingsActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const NEXT_CHAT: string = 'ExistingSavingsActionType_NEXT_CHAT';
    export const CLEAR: string = 'ExistingSavingsActionType_LOAD_TEMPLATE_CLEAR';
    export const CLEAR_SHOW_CHATS: string = 'ExistingSavingsActionType_CLEAR_SHOW_CHATS';
    export const BRANCH_STATUS_INSERT: string = 'ExistingSavingsActionType_BRANCH_STATUS_INSERT';
    export const BRANCH_STATUS_UPDATE: string = 'ExistingSavingsActionType_BRANCH_STATUS_UPDATE';
    export const SET_CUSTOMER_APPLY_START_DATE: string = 'ExistingSavingsActionType_SET_CUSTOMER_APPLY_START_DATE';
    export const SET_ANSWER: string = 'ExistingSavingsActionType_SET_ANSWER';
    export const EDIT_CHAT: string = 'ExistingSavingsActionType_EDIT_CHAT';
    export const SET_STATE_SUBMIT_DATA_VALUE: string = 'ExistingSavingsActionType_SET_STATE_SUBMIT_DATA_VALUE';
    export const VALIDATION_PASSWORD: string = 'ExistingSavingsActionType_VALIDATION_PASSWORD';
    export const SUBMIT_DATA_BACKUP: string = 'ExistingSavingsActionType_SUBMIT_DATA_BACKUP';
    export const UPDATA_SUBMIT_DATA_BACKUP = 'ExistingSavingsActionType_UPDATA_SUBMIT_DATA_BACKUP';
    export const RESET_SUBMIT_DATA: string = 'ExistingSavingsActionType_RESET_SUBMIT_DATA';
    export const RETRIEVE_DROP_LIST: string = 'ExistingSavingsActionType_RETRIEVE_DROP_LIST';
    export const GET_HOLDER_ZIP_CODE = 'ExistingSavingsActionType_GET_HOLDER_ZIP_CODE';
    export const CHAT_FLOW_COMPELETE = 'ExistingSavingsActionType_CHAT_FLOW_COMPELETE';
    export const CHAT_FLOW_RETURN = 'ExistingSavingsActionType_CHAT_FLOW_RETURN';
    export const RESET_LAST_NODE = 'ExistingSavingsActionType_RESET_LAST_NODE';
    export const SET_BANKCLERK_ID: string = 'ExistingSavingsActionType_SET_BANKCLERK_ID';
    export const SET_BRANCH_INFO: string = 'ExistingSavingsActionType_SET_BRANCH_INFO';
    export const SET_AGENCY_BRANCH_INFO: string = 'ExistingSavingsActionType_SET_AGENCY_BRANCH_INFO';
    export const GET_CONFIRM_PAGE_TEMPLATE: string = 'ExistingSavingsActionType_GET_CONFIRM_PAGE_TEMPLATE';
    export const RESET_SHOWCHATS = 'ExistingSavingsActionType_RESET_SHOWCHATS';
    export const MODIFY_CHECKBOX_STATUS: string = 'ExistingSavingsActionType_MODIFY_CHECKBOX_STATUS';
    export const SET_SYSTEM_TIME: string = 'ExistingSavingsActionType_SET_SYSTEM_TIME';
    export const SUBMIT_EXIST_SAVING_APPLY_INFO: string = 'ExistingSavingsActionType_SUBMIT_EXIST_SAVING_APPLY_INFO';
    export const SET_IMAGES: string = 'ExistingSavingsActionType_SET_IMAGES';
    export const SET_CIF_ACCOUNT_INFO: string = 'ExistingSavingsActionType_SET_CIF_ACCOUNT_INFO';  // CIF情報照会
    export const SET_SWIPE_INFO: string = 'ExistingSavingsActionType_SET_SWIPE_INFO';
    export const CLEAR_CONFIRM_PAGE_INFO: string = 'ExistingSavingsActionType_CLEAR_CONFIRM_PAGE_INFO';
    export const CLEAR_CREDIT_CARD_CONFIRM_PAGE_INFO: string = 'ExistingSavingsActionType_CLEAR_CREDIT_CARD_CONFIRM_PAGE_INFO';
    export const GET_EXISTING_PASSWORD_RULE = 'ExistingSavingsActionType_GET_EXISTING_PASSWORD_RULE';  // 暗証番号ルール適合性チェック(初めて発行)
    export const RESET_SHOW_CONFIRM: string = 'ExistingSavingsActionType_RESET_SHOW_CONFIRM';
    export const GET_DEFAULT_ADDRESS: string = 'ExistingSavingsActionType_GET_DEFAULT_ADDRESS';
    export const INQUIRE_ACCOUNT_BALANCE: string = 'ExistingSavingsActionType_INQUIRE_ACCOUNT_BALANCE';
    export const SET_ACCOUNT_TYPE = 'ExistingSavingsActionType_SET_ACCOUNT_TYPE';
    export const SET_PURPOSE = 'ExistingSavingsActionType_SET_PURPOSE';
    export const SET_DUPLICATE_ACCOUNT_INFO = 'ExistingSavingsActionType_SET_DUPLICATE_ACCOUNT_INFO';
    export const SET_ONLY_NAME_KANJI_EDIT_FLG: string = 'ExistingSavingsActionType_SET_ONLY_NAME_KANJI_EDIT_FLG';
    export const SET_CIF_INFO = 'ExistingSavingsActionType_SET_CIF_INFO';
    export const SET_CUSTOMER_INFO = 'ExistingSavingsActionType_SET_CUSTOMER_INFO';

    export const SET_IDENTIFICATION_DOCUMENT = 'ExistingSavingsActionType_SET_IDENTIFICATION_DOCUMENT';
    export const UPDATE_SAME_HOLDER_INQUIRY = 'ExistingSavingsActionType_UPDATE_SAME_HOLDER_INQUIRY';
    export const CHARACTER_CHECK = 'ExistingSavingsActionType_CHARACTER_CHECK';
    export const FILTERING_INQUIRY = 'ExistingSavingsActionType_FILTERING_INQUIRY';

    export const SET_BANK_CARD_FLAG = 'ExistingSavingsActionType_SET_BANK_CARD_FLAG';

    export const SET_STATE_DATA = 'ExistingSavingsActionType_SET_STATE_SUBMIT_DATA';
    export const SET_STATE_DATA_FOR_CHANGE = 'ExistingSavingsActionType_SET_STATE_DATA_FOR_CHANGE';

    export const SAVE_DOCUMENT_IMAGE = 'ExistingSavingsActionType_SAVE_DOCUMENT_IMAGE';
    export const CLEAN_DOCUMENT_IMAGE = 'ExistingSavingsActionType_CLEAN_DOCUMENT_IMAGE';

    export const SET_SUBMIT_DATA = 'ExistingSavingsActionType_SET_SUBMIT_DATA';

    export const SET_LAST_FILTERING_PARAMS = 'ExistingSavingsActionType_SET_LAST_FILTERING_PARAMS';
    export const REQUEST_CUSTOMER_STATUS = 'ExistingSavingsActionType_REQUEST_CUSTOMER_STATUS';
    export const NEED_INPUT_PHONE_NO = 'ExistingSavingsActionType_NEED_INPUT_PHONE_NO';
    export const BC_APPLY_CHECK = 'ExistingSavingsActionType_BC_APPLY_CHECK';
    export const ACCEPT_CHECK = 'ExistingSavingsActionType_ACCEPT_CHECK';
    export const ACCEPT_CHECK_SWIPE_CIF = 'ExistingSavingsActionType_ACCEPT_CHECK_SWIPE_CIF';
    export const SET_TELPHONE_DIFFERENCE_FLG = 'ExistingSavingsActionType_SET_TELPHONE_DIFFERENCE_FLG';
    export const SET_ADDRESS_DIFFERENCE_FLG = 'ExistingSavingsActionType_SET_ADDRESS_DIFFERENCE_FLG';
    export const SET_NAME_DIFFERENCE_FLG = 'ExistingSavingsActionType_SET_NAME_DIFFERENCE_FLG';
    export const UNACCEPTABLES_NG = 'ExistingSavingsActionType_UNACCEPTABLES_NG';
    export const ACCEPT_CHECK_FOR_NAME_DIF_CIF = 'ExistingSavingsActionType_ACCEPT_CHECK_FOR_NAME_DIF_CIF';
    export const ACCEPT_CHECK_FOR_ADDRESS_DIF_CIF = 'ExistingSavingsActionType_ACCEPT_CHECK_FOR_ADDRESS_DIF_CIF';
    export const GET_UPDATE_HOLDER_INFO: string = 'ChangeActionType_GET_UPDATE_HOLDER_INFO';
    export const SAVE_DOCUMENT_IMAGES = 'ExistingSavingsActionType_SAVE_DOCUMENT_IMAGES'; // 撮影した写真を保存
    export const SAVE_SKIPPED_DOCUMENT_PATTERN = 'ExistingSavingsActionType_SAVE_SKIPPED_DOCUMENT_PATTERN'; // 書類パターン(A/B)ごとのスキップボタン押下有無を保存
    export const EDIT_SUBMIT_DATA_NESTED = 'ExistingSavingsActionType_EDIT_SUBMIT_DATA_NESTED';
    export const MODIFY_CHECKBOX_STATUS_CHANGE: string = 'ExistingSavingsActionType_MODIFY_CHECKBOX_STATUS_CHANGE';
    export const SAVE_DOCUMENT_IMAGES_CONFIRM: string = 'ExistingSavingsActionType_SAVE_DOCUMENT_IMAGES_CONFIRM';

    export const REMOVE_NOT_MASKING_CONFIRM_IMAGES = 'ExistingSavingsActionType_REMOVE_NOT_MASKING_CONFIRM_IMAGES';
    export const RESET_NOT_MASKING_CONFIRM_IMAGES = 'ExistingSavingsActionType_RESET_NOT_MASKING_CONFIRM_IMAGES';
    export const SET_DATA = 'ExistingSavingsActionType_SET_DATA';
    export const SET_MEDIUM_INFO = 'ExistingSavingsActionType_SET_MEDIUM_INFO';
    export const CLEAR_ONE_SET_CARD_PASSWORD = 'ExistingSavingsActionType_CLEAR_ONE_SET_CARD_PASSWORD';
    export const CLEAR_ALL_DOCUMENT = 'ExistingSavingsActionType_CLEAR_ALL_DOCUMENT';
    export const CLEAR_PART_ALL_DOCUMENT = 'ExistingSavingsActionType_CLEAR_PRAT_ALL_DOCUMENT';
    export const CLEAR_CHANGE_DOCUMENT = 'ExistingSavingsActionType_CLEAR_CHANGE_DOCUMENT';
    export const SET_BC_SUICA_LOST = 'ExistingSavingsActionType_SET_BC_SUICA_LOST';
    export const SET_ADDRESS_CODE = 'ExistingSavingsActionType_SET_ADDRESS_CODE';
    export const CLEAR_ZIP_CODE = 'ExistingSavingsActionType_CLEAR_ZIP_CODE';
    export const SAVE_DOCUMENT_NAME = 'ExistingSavingsActionType_SAVE_DOCUMENT_NAME';
    export const CUSTOMER_INFOS_LIST = 'ExistingSavingsActionType_CUSTOMER_INFOS_LIST';
    export const ACCEPT_CHECK_FOR_TEL_DIF_CIF = 'ExistingSavingsActionType_ACCEPT_CHECK_FOR_TEL_DIF_CIF';
    export const SKIP = 'ExistingSavingsActionType_SKIP';
    export const SEARCH_REGION_CODE = 'ExistingSavingsActionType_SEARCH_REGION_CODE';
    export const DIFFERENCE_FLG_BACKUP = 'ExistingSavingsActionType_DIFFERENCE_FLG_BACKUP';
    export const CLEAR_HOLDER_NAME = 'ExistingSavingsActionType_CLEAR_HOLDER_NAME';
    export const CLEAR_HOLDER_ADDRESS = 'ExistingSavingsActionType_CLEAR_HOLDER_ADDRESS';
    export const CLEAR_HOLDER_PHONE_NO = 'ExistingSavingsActionType_CLEAR_HOLDER_PHONE_NO';
    export const CLEAR_ADD_CHECK_DATA = 'ExistingSavingsActionType_CLEAR_ADD_CHECK_DATA';
    export const SAVE_CREDIT_CARD_DATA = 'ExistingSavingsActionType.SAVE_CREDIT_CARD_DATA';
    export const RESET_CUS_ID_CODE = 'ExistingSavingsActionType_RESET_CUS_ID_CODE';
    export const BAK_RESET_CUS_ID_CODE = 'ExistingSavingsActionType_BAK_RESET_CUS_ID_CODE';
    export const CLEAR_WORK_OR_CRS = 'ExistingSavingsActionType_CLEAR_WORK_OR_CRS';
    export const CHANGE_OPEN_STORE = 'ExistingSavingsActionType_CHANGE_OPEN_STORE';
    export const RESTORE_WORK_OR_CRS = 'ExistingSavingsActionType_RESTORE_WORK_OR_CRS';

    export const SET_IC_DATA = 'ExistingSavingsActionType_SET_IC_DATA';
    export const SET_USER_CARD_PAN = 'ExistingSavingsActionType_SET_USER_CARD_PAN';
    export const NAME_AGGREGATION = 'ExistingSavingsActionType_NAME_AGGREGATION';
    export const RECEPTION_LOSS_CORRUPTION_CHECK = 'ExistingSavingsActionType_RECEPTION_LOSS_CORRUPTION_CHECK';
    export const RECEPTION_LOSS_CORRUPTION_CHECK_ADD = 'ExistingSavingsActionType_RECEPTION_LOSS_CORRUPTION_CHECK_ADD';
    export const SET_CIF_INFO_BY_CARD_SWIP = 'ExistingSavingsActionType_SET_CIF_INFO_BY_CARD_SWIP';

    export const RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES = 'ExistingSavingsActionType_RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES';
    export const SET_STATE_DATA_FOR_HAS_DRIVERS_CAREER_LICENSE = 'ExistingSavingsActionType_SET_STATE_DATA_FOR_HAS_DRIVERS_CAREER_LICENSE';
    export const BACKUP_OCR_DUE_DATE = 'ExistingSavingsActionType_BACKUP_OCR_DUE_DATE';

    export const GO_BACK_RELATE_CHAT = 'ExistingSavingsActionType_GO_BACK_RELATE_CHAT';
    export const MODIFY_EXPIRY_DATE_EXISTS = 'ExistingSavingsActionType_MODIFY_EXPIRY_DATE_EXISTS';

}

@Injectable()
export class ExistingSavingsAction extends Action implements DocumentCategoryObserverAction {
    public params: any;
    constructor(
        private httpService: HttpService,
        private hostErrorService: HostErrorService,
        private ngZone: NgZone,
        private changeUtils: ChangeUtils,
        private nameBasedAggregationService: NameBasedAggregationService,
        private loginStore: LoginStore,
        private logging: LoggingService,
    ) {
        super();
    }

    /**
     * 写真未確認状態管理オブジェクトから確認済内容を削除
     *
     * @param {{documentName: string, index: number}} maskingConfirmImgStatus
     * @memberof SavingsAction
     */
    public removeNotMaskingConfirmImages(maskingConfirmImgStatus: { documentName: string, index: number }) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES,
            data: maskingConfirmImgStatus
        });
    }

    /**
     * マスキング確認完了しないオブジェクトをリセット。
     *
     * @param {ClearSavingImagesClickRecordType} type リセットタイプ
     * @memberof SavingsAction
     */
    public resetNotMaskingConfirmImages(type: ClearSavingImagesClickRecordType) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.RESET_NOT_MASKING_CONFIRM_IMAGES,
            data: type
        });
    }

    /**
     * マスキング確認完了しないオブジェクトをリセット。
     *
     * @param {ClearSavingImagesClickRecordType} type リセットタイプ
     * @memberof
     */
    public resetSpecialNotMaskingConfirmImages(specalDocumentName: string) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES,
            data: specalDocumentName
        });
    }

    /**
     * バンクカード申込フラグを設定
     * @param value value
     */
    public setBankCardFlag(value: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_BANK_CARD_FLAG,
            data: value
        });
    }

    public getCategoryNameLogic() {
        return this.httpService.get('/categoryCodes/retrieve', { params: { categoryCode: '049' } })
            .pipe(map((res) => res.result));
    }

    public updateBranchInfo(info: { branchName: string; tenban: string; }) {
        this.setStateSubmitDataValue([
            {
                key: 'branchName',
                value: info.branchName
            }
        ]);
    }

    public setIdentificationDocument(data) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_IDENTIFICATION_DOCUMENT,
            data: data
        });
    }

    public setStateData(data) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_STATE_DATA,
            data: data
        });
    }

    public setData(submitData: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_STATE_DATA_FOR_CHANGE,
            data: submitData
        });
    }

    public updateDuplicateAccountInfos(data: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.UPDATE_SAME_HOLDER_INQUIRY,
            data: data
        });
    }

    /**
     * ICカードの認証処理を行う。
     * @param params ICカード情報
     */
    public cardIinfoCheck(params: any) {
        return new Promise((resolve, reject) => {
            this.httpService.post('/card-info/check', params, null, SpinnerType.SHOW_TRANSPARENT, true)
                .subscribe((result) => {
                    if (result.status === HttpStatus.SUCCESS) {
                        resolve(true);
                    } else if (result.status === HttpStatus.HOST_ERROR) {
                        this.hostErrorService.push({
                            resultCode: result.errors.data.resultCode,
                            errorCode: result.errors.data.errorCode,
                            message: result.errors.message,
                            handel: () => {
                                resolve(false);
                            }
                        });
                    } else {
                        throw new HttpStatusError('/card-info/check', result.status, result.errors);
                    }
                }, (error) => {
                    reject(error);
                });
        });
    }

    /**
     * cif情報をセット
     * @param cifInfo cif情報
     */
    public setCifInfo(cifInfo: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_CIF_INFO,
            data: cifInfo
        });
    }

    /**
     * submit dataを更新
     *
     * @param data 書類カテゴリと選択された書類
     * @param isHolderPage 本人確認画面フラグ
     * @param isHolder 本人フラグ
     */
    public setDocumentCategory(data: DocumentCategorySubjectData,
        isHolderPage: boolean, isHolder: boolean) {
        switch (data.code) {
            // 本人確認情報
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_TYPE:
                const infos = isHolder ? [{
                    key: isHolderPage ? SubmitDataKey.HOLDER_ID_DOC_TYPE : SubmitDataKey.AGENT_ID_DOC_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                }, {
                    key: SubmitDataKey.RECEIPT_METHOD,
                    value: data.entity ? (data.entity.filler6 === CodeCategory.FACEID ?
                        CodeCategory.RECEIPT_METHOD_ISSUE : CodeCategory.RECEIPT_METHOD_MAIL) :
                        CodeCategory.RECEIPT_METHOD_MAIL
                }] : [{
                    key: isHolderPage ? SubmitDataKey.HOLDER_ID_DOC_TYPE : SubmitDataKey.AGENT_ID_DOC_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                }];
                this.setStateSubmitDataValue(infos);
                break;
            // 本人確認書類（顔写真ない）の補完書類の種類
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_PHOTOGRAPH_TYPE:
                this.setStateSubmitDataValue([{
                    key: isHolderPage ? SubmitDataKey.HOLDER_ID_DOC_PHOTO_TYPE : SubmitDataKey.AGENT_ID_DOC_PHOTO_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                }]);
                break;
            // 本人確認書類（住所異なる）の補完書類の種類
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_ADDRESS_TYPE:
                this.setStateSubmitDataValue([{
                    key: isHolderPage ? SubmitDataKey.HOLDER_ID_DOC_ADDRESS_TYPE : SubmitDataKey.AGENT_ID_DOC_ADDRESS_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                }]);
                break;
            // コピー徴求ができない理由
            case CodeCategory.CODE_CATEGORY_NO_COPY_REASON:
            // 住所が相違する理由
            case CodeCategory.CODE_CATEGORY_DIFFERENT_ADDRESS_REASON:
            // 遠隔地等住所等の場合の理由
            case CodeCategory.CODE_CATEGORY_FAR_ADDRESS_REASON:
                this.setStateSubmitDataValue([{
                    key: data.key,
                    value: data.entity ? data.entity.data : null
                }]);
                break;
        }
    }

    /**
     * 取次店番を設定する
     * @param branchNo 支店番号
     */
    public setAgencyBranchInfo(branchNo: string) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_AGENCY_BRANCH_INFO,
            data: { branchNo: branchNo }
        });
    }

    /**
     * 支店情報設定
     * @param branchNameKanji 支店名
     * @param branchNo 支店番号
     */
    public setBranchInfo(branchNameKanji, branchNo: string) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_BRANCH_INFO,
            data: {
                branchNameKanji: branchNameKanji,
                branchNo: branchNo
            }
        });
    }

    /**
     * 行員IDを設定する
     * @param bankclerkId 行員ID
     */
    public setBankclerkId(bankclerkId: string) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_BANKCLERK_ID,
            data: { bankclerkId: bankclerkId }
        });
    }

    /**
     * チャットテンプレートをロードする
     * @param file yamlファイル名
     * @param pageIndex ページインデックス
     */
    public loadTemplate(file: string, pageIndex: number) {

        this.httpService.get(API_URL.CHATFLOW_DEFINITION + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    fileInfo: response.result.fileInfos,
                    pageIndex: pageIndex
                }
            });
        });
    }

    /**
     * タブレット申し込み情報にデータをインサートする
     * @param params タブレット申し込み情報
     */
    public branchStatusInsert(params: any) {
        this.httpService.post(API_URL.BRANCH_STATUS_INSERT, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.BRANCH_STATUS_INSERT,
                data: response.result
            });
        });
    }

    /**
     * 郵便番号を取得する
     * @param prefectureKanji 県名漢字
     * @param countyUrbanVillageKanji 市区町村漢字
     * @param streetKanji 町丁名漢字
     */
    public getHolderZipCode(prefectureKanji: string, countyUrbanVillageKanji: string, streetKanji: string) {
        const params = {
            prefectureKanji: prefectureKanji,
            countyUrbanVillageKanji: countyUrbanVillageKanji,
            streetKanji: streetKanji
        };
        this.httpService.get(API_URL.ADDRESS_ZIPCODE_SEARCH, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.GET_HOLDER_ZIP_CODE,
                data: response.result.zipCode
            });
        }
        );
    }

    /**
     * タブレット申し込み情報にデータを更新する
     * @param params タブレット申し込み情報
     */
    public branchStatusUpdate(params: any) {
        this.httpService.post(API_URL.BRANCH_STATUS_UPDATE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.BRANCH_STATUS_UPDATE,
                data: response.result
            });
        });
    }

    /**
     * タブレット申込管理テーブルの申込業務区分・ステータスを更新する
     * @param params 申込業務区分、タブレット申込管理ID
     */
    public updateApplyBizCategory(params: { applyBusinessCategory: string, tabletApplyId: string }) {
        this.httpService.post(API_URL.UPDATE_APPLY_BUSINESS_CATEGORY, params).subscribe((response) => {
            // do-nothing
        });
    }

    /**
     * 次のステップを取得する
     * @param order オーダー
     * @param pageIndex ページインデックス
     */
    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    /**
     * ストアをクリアする
     */
    public clearStore() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR
        });
    }

    /**
     * チャットの表示内容をクリアする
     */
    public clearShowChats() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_SHOW_CHATS
        });
    }

    /**
     * 顧客申し込み完了時間を設定する
     */
    public setCustomerApplyEndDate() {
        this.setAsSystemTime(ApplyDate.CUSTOMER_APPLY_END_DATE);
    }

    /**
     * 行員認証開始時間を設定する
     */
    public setBankclerkAuthenticationStartDate() {
        this.setAsSystemTime(ApplyDate.BANKCLERK_AUTHENTICATION_START_DATE);
    }

    /**
     *
     *
     * @param order オーダー
     * @param pageIndex ページインデックス
     */

    /**
     * チャット内容を編集する
     * @param order オーダー
     * @param pageIndex ページインデックス
     * @param answerOrder 応答順
     */
    public editChart(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.EDIT_CHAT,
            data: { order: order, pageIndex: pageIndex, answerOrder: answerOrder, orderIndex: orderIndex }
        });
    }

    /**
     * 回答を設定する
     *
     * @param answer 回答
     */
    public setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_ANSWER,
            data: answer
        });
    }

    /**
     * サブミットデータに値を設定する
     *
     * @param param 項目値
     */
    public setStateSubmitDataValue(param: Array<{ key: string, value: any }>) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_STATE_SUBMIT_DATA_VALUE,
            data: param
        });
    }

    /**
     * 本人確認書類画像をクリア
     */
    public cleanIdentityDocumentImage(category: Constants.IdentityDocumentCategory) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAN_DOCUMENT_IMAGE,
            data: category
        });
    }

    /**
     * 本人確認書類画像を保存
     */
    public saveIdentityDocumentImage(document: { image: string, category: Constants.IdentityDocumentCategory }) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SAVE_DOCUMENT_IMAGE,
            data: document
        });
    }

    /**
     * 行員認証情報をサブミットする
     *
     * @param params データ
     */
    public submitExistSavingsData(params: any) {
        this.httpService.post(
            API_URL.ORDINARILY_ACCOUNT_INFO,
            params, {},
            SpinnerType.SHOW
        ).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.SUBMIT_EXIST_SAVING_APPLY_INFO,
                data: response.result
            });
        });
    }

    /**
     * コードマスタの情報を取得する
     *
     * @param params
     */
    public retrieveDropList(params: any) {
        this.httpService.get(API_URL.CATEGORY_CODES_RETRIEVE, params).subscribe((response: any) => {
            // this.httpClient.get('./assets/datas/drop-down-list-account.json', params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.RETRIEVE_DROP_LIST,
                data: response.result
            });
        });
    }

    /**
     * チャットが完了
     * @param nextChatName 次のチャットの名
     */
    public chatFlowCompelete(nextChatName: string, options: any = null) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CHAT_FLOW_COMPELETE,
            data: {
                name: nextChatName,
                options: options
            }
        });
    }

    public chatFlowReturn(nextChatName: string, options: any = null) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CHAT_FLOW_RETURN,
            data: {
                name: nextChatName,
                options: options
            }
        });
    }

    /**
     * 最後のノードをチェックする
     * @param params パラメーター
     */
    public resetLastNode(params: { order: number, pageIndex: number }) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.RESET_LAST_NODE,
            data: params
        });
    }

    /**
     * 修正用テンプレートをロードする
     * @param params パラメーター
     */
    public loadConfirmPageTemplate(file: string, pageIndex: number) {

        this.httpService.get(API_URL.CHATFLOW_DEFINITION + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.GET_CONFIRM_PAGE_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos,
                }
            });
        });
    }

    /**
     * Reset showChats to origin
     * @param originShowChats originShowChats
     */
    public resetShowChats(originShowChats: any[]) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.RESET_SHOWCHATS,
            data: originShowChats
        });
    }

    /**
     * modify checkbox status
     * @param name the checbox item need to modify status
     */
    public modifyCheckboxStatus(name: string) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.MODIFY_CHECKBOX_STATUS,
            data: name
        });
    }

    /**
     * modify checkbox status for change
     * @param name the checbox item need to modify status
     */
    public modifyCheckboxStatusForChange(name: string) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.MODIFY_CHECKBOX_STATUS_CHANGE,
            data: name
        });
    }

    /**
     * set the item value as the current time of server
     * @param key the checbox item need to modify status
     */
    public setAsSystemTime(key: string) {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.SET_SYSTEM_TIME,
                data: {
                    key: key,
                    systemTime: response.result.value
                }
            });
        });
    }

    /**
     * set the images
     * @param datas
     */
    public setImages(datas: { key: string, values: string[] }) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_IMAGES,
            data: datas
        });
    }

    /**
     * CIF情報照会と口座情報照会を行う
     * @param cifParams CIF情報照会用パラメータ
     * @param accountParam 口座情報照会用パラメータ
     * @param nextOrder 次のオーダー
     * @param pageIndex ページインデックス
     */
    public getCifAccountInfo(cifParams: SimpleCifInfoInquiryInterface, accountParam: AccountInfoInquiryInterface,
        nextOrder: number, pageIndex: number) {
        const cifRequest: Observable<any> = this.httpService.post(API_URL.CB_GET_CIF_INFORMATION, cifParams);
        const accountRequest: Observable<any> = this.httpService.post(API_URL.CB_GET_ACCOUNT_INFORMATION, accountParam);

        Observable.forkJoin(cifRequest, accountRequest).subscribe((data) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.SET_CIF_ACCOUNT_INFO,
                data: { data: data, nextOrder: nextOrder, pageIndex: pageIndex }
            });
        });
    }

    /**
     * 暗証番号ルール適合性チェック(初めて発行場合)
     * @param params params 暗証番号ルール適合性チェック用パラメータ
     */
    public checkExistingCustomerPasswordRule(params: ExistingPasswordRuleCheckInterface) {
        this.httpService.post(API_URL.CB_CHECK_EXISTING_PASSWORD_RULE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.GET_EXISTING_PASSWORD_RULE,
                data: response.result
            });
        });
    }

    /**
     *  SubmitDataBackup
     */
    public submitDataBackup() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SUBMIT_DATA_BACKUP
        });
    }

    public updateSubmitDataBackup(data) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.UPDATA_SUBMIT_DATA_BACKUP,
            data: data
        });
    }

    public resetSubmitData() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.RESET_SUBMIT_DATA
        });
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param params QRコード受付情報
     */
    public setSwipeInfo(params: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_SWIPE_INFO,
            data: params
        });
    }

    /**
     *  行員確認の入力データをクリアする
     */
    public clearConfirmPageInfo() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_CONFIRM_PAGE_INFO
        });
    }

    public clearCreditCardConfirmPageInfo() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_CREDIT_CARD_CONFIRM_PAGE_INFO
        });
    }

    /**
     * 口座残高照会
     * @param params 口座残高照会用パラメータ
     * @param nextOrder 次のオーダー
     * @param pageIndex ページインデックス
     */
    public inquireAccountBalance(params: AccountBalanceInquiryInterface, nextOrder: number, pageIndex: number) {
        this.httpService.post(API_URL.CB_GET_ACCOUNT_BALANCE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.INQUIRE_ACCOUNT_BALANCE,
                data: { result: response.result, nextOrder: nextOrder, pageIndex: pageIndex }
            });
        });
    }

    /**
     * Reset showConfirm
     * @param showConfirm showConfirm
     */
    public resetShowConfirm(showConfirm: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.RESET_SHOW_CONFIRM,
            data: showConfirm
        });
    }

    /**
     * Request default address
     * @param params params
     * @param entity entity
     * @param pageIndex pageIndex
     */
    public requestDefaultAddress(params, entity, pageIndex) {
        this.httpService.get(API_URL.DEFAULT_ADDRESS, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.GET_DEFAULT_ADDRESS,
                data: {
                    result: response.result,
                    entity: entity,
                    pageIndex: pageIndex
                }
            });
        });
    }

    /**
     * 重複口座情報をセット
     * @param data 重複口座情報
     */
    public setDuplicateAccountInfo(data: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_DUPLICATE_ACCOUNT_INFO,
            data: data
        });
    }

    /**
     * 登録不可漢字先が漢字氏名を入力した際、申込内容確認画面で修正ボタンが表示する
     */
    public setEditNameKanji() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_ONLY_NAME_KANJI_EDIT_FLG,
        });
    }

    /**
     * 文字チェック
     * @param params 文字チェックパラメータ
     */
    public characteCheck(params: any, handel?: any) {
        this.httpService.post(API_URL.CHARACTER_CHECK, params, null, SpinnerType.SHOW_TRANSPARENT, true)
            .subscribe((result) => {
                if (result.status === HttpStatus.SUCCESS) {
                    this.dispatcher.dispatch({
                        actionType: ExistingSavingsActionType.CHARACTER_CHECK,
                        data: result.result
                    });
                } else if (result.status === HttpStatus.HOST_ERROR) {
                    if (result.errors.data &&
                        result.errors.data.resultCode &&
                        result.errors.data.resultCode === HostResultCode.REENTER) {
                        this.hostErrorService.push({
                            resultCode: result.errors.data.resultCode,
                            errorCode: result.errors.data.errorCode,
                            message: result.errors.message,
                            handel: handel
                        });
                    }
                } else {
                    throw new HttpStatusError(API_URL.CHARACTER_CHECK, result.status, result.errors);
                }
            });
    }

    /**
     * フィルタリングシステム検索
     * @param params フィルタリングシステム検索パラメーター
     */
    public filterInquiry(params: any) {
        this.httpService.post(API_URL.FILTERING_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.FILTERING_INQUIRY,
                data: response.result
            });
        });
    }

    /**
     * submitDataの値を変更する
     *
     * @param {*} data
     * @memberof SavingsAction
     */
    public editSomeDataInSubmitData(index: number, key: string, val: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_SUBMIT_DATA,
            data: {
                index: index,
                key: key,
                val: val
            }
        });
    }

    /**
     * フィルタリングシステムへの照会パラメータを保存
     *
     * @param {FilteringParameterEntity} curFilteringParamters
     * @memberof SavingsAction
     */
    public setLastFilteringParameters(curFilteringParamters: FilteringParameterEntity) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_LAST_FILTERING_PARAMS,
            data: curFilteringParamters
        });
    }

    /**
     * フィルタリングシステムへの照会結果を保存
     *
     * @param {*} data
     * @memberof SavingsAction
     */
    public setLastFilteringResult(data: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.FILTERING_INQUIRY,
            data: data
        });
    }

    /**
     * 住所変更受付可否チェックAPIを実行
     *
     * Request customer info
     * @param item model
     * @param dict params
     */
    public acceptCheck(params: any) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, params, undefined, undefined, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.ADDRESS_CHANGE_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: ExistingSavingsActionType.ACCEPT_CHECK,
                        data: response instanceof HttpStatusError ? response.errors.data : response.result
                    });
                }
            }
        );
    }

    public needInputPhoenNo() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.NEED_INPUT_PHONE_NO,
        });
    }

    /**
     * BC受付可否チェックAPI
     * @param {*} params
     */
    public bankCardApplyCheck(params: any) {
        this.httpService.post(API_URL.BC_APPLY_CHECK, params, undefined, undefined, true).subscribe(
            (response) => {
                this.dispatcher.dispatch({
                    actionType: ExistingSavingsActionType.BC_APPLY_CHECK,
                    data: {
                        data: response instanceof HttpStatusError ? response.errors.data : response.result,
                    }
                });
            }
        );
    }

    public setTelphoneDifferenceFlg(isDifference: boolean) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_TELPHONE_DIFFERENCE_FLG,
            data: isDifference
        });
    }

    /**
     * 住所、電話番号の変更に対しての更新系APIを呼び出す
     * @param data 送信内容
     */
    public updateChangedInfo(data: any) {
        this.httpService.post(API_URL.CB_UPDATE_ADDRESS_TEL, data, undefined, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.GET_UPDATE_HOLDER_INFO,
                data: response.result
            });
        });
    }

    /**
     * ドキュメントを保存
     *
     * @param {string[]} images
     */
    public saveDocumentImages(image: any, order: any, name: string) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SAVE_DOCUMENT_IMAGES,
            data: {
                image: image,
                code: order,
                name: name
            }
        });
    }

    /**
     * 本人確認書類修正の場合、写真更新
     *
     * @param {string[]} images
     */
    public saveDocumentImagesConfirm(images: any, orderChangeDocument: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SAVE_DOCUMENT_IMAGES_CONFIRM,
            data: {
                images: images,
                orderChangeDocument: orderChangeDocument,
            }
        });
    }

    /**
     * 書類パターン(A/B)ごとのスキップボタン押下有無を保存
     *
     * @param identificationDocument3A 書類パターンAの撮影書類
     * @param identificationDocument3B 書類パターンBの撮影書類
     */
    public saveSkippedDocumentPattern(identificationDocument3A: string, identificationDocument3B: string) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SAVE_SKIPPED_DOCUMENT_PATTERN,
            data: {
                identificationDocument3A: identificationDocument3A,
                identificationDocument3B: identificationDocument3B,
            }
        });
    }

    /**
     * 入れ子構造のsubmitDataを編集する
     *
     * @param {*} data
     * @memberof SavingsAction
     */
    public editSubmitDataNested(index: number, key: string, nestKey: string, val: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.EDIT_SUBMIT_DATA_NESTED,
            data: {
                index: index,
                key: key,
                nestKey: nestKey,
                val: val
            }
        });
    }

    public setAddressDifferenceFlg(isDifference: boolean) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_ADDRESS_DIFFERENCE_FLG,
            data: isDifference
        });
    }

    public setNameDifferenceFlg(isDifference: boolean) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_NAME_DIFFERENCE_FLG,
            data: isDifference
        });
    }

    /**
     * Request customer status
     * @param questions ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public acceptCheckForSwipeCif(questions: ExistingSavingsQuestionsModel, dict: any) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, dict, undefined, SpinnerType.SHOW, true).subscribe((response: any) => {

            // エラー発生時
            if (response instanceof HttpStatusError) {
                // 事故取引禁止注意コードエラーの場合、受付可否チェック（住変）NGとしてSignalを送信する
                if (response.errors && response.errors.data && this.changeUtils.isHostError(response.errors.data.errorCode)) {
                    this.dispatcher.dispatch({
                        actionType: ExistingSavingsActionType.UNACCEPTABLES_NG,
                        data: response
                    });
                    return;
                } else {
                    // 上記以外のエラーの場合、共通エラーハンドリング処理にて処理する
                    throw response;
                }
            }

            const result: AcceptionResult = response.result || {};
            // 次の業務に移動する
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.ACCEPT_CHECK_SWIPE_CIF,
                data: {
                    item: questions,
                    response: result || {}
                }
            });
        });
    }

    public acceptCheckForNameDifCif(params: any, difInfos: ChangeDifferenceEntity[]) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, params, undefined, SpinnerType.SHOW, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.ADDRESS_CHANGE_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: ExistingSavingsActionType.ACCEPT_CHECK_FOR_NAME_DIF_CIF,
                        data: {
                            res: response instanceof HttpStatusError ? response.errors.data : response.result,
                            difItems: difInfos
                        }
                    });
                }
            }
        );
    }

    public acceptCheckForAddressDifCif(params: any, difInfos: ChangeDifferenceEntity[]) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, params, undefined, SpinnerType.SHOW, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.ADDRESS_CHANGE_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: ExistingSavingsActionType.ACCEPT_CHECK_FOR_ADDRESS_DIF_CIF,
                        data: {
                            res: response instanceof HttpStatusError ? response.errors.data : response.result,
                            difItems: difInfos
                        }
                    });
                }
            }
        );
    }

    /**
     *  カード交付方法に郵送をセット
     */
    public setMailDelivery() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_DATA,
        });
    }

    /**
     * 内部API: 保有通帳・カード・印鑑情報照会
     * @param params
     */
    public getMediumInfo(params: any) {
        this.httpService.post(API_URL.MEDIUM_INFO_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.SET_MEDIUM_INFO,
                data: response.result
            });
        });
    }

    /**
     * ワンセットカードの暗証番号をクリア
     */
    public clearOneSetCardPassword() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_ONE_SET_CARD_PASSWORD,
        });
    }

    /**
     * 確認書類をクリア
     */
    public clearIdentificationDocument() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_ALL_DOCUMENT,
        });
    }

    /**
     * 確認書類をクリア
     */
    public clearPartIdentificationDocument() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_PART_ALL_DOCUMENT,
        });
    }

    /**
     * 諸届側の本人確認書類をクリア
     */
    public clearChangeIdentificationDocument() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_CHANGE_DOCUMENT,
        });
    }

    /**
     * BCバンクカードSuica喪失届出済をセット
     */
    public setBcSuicaLost() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_BC_SUICA_LOST,
        });
    }

    /**
     * 内部API：住所コード取得
     * @param params
     */
    public getAddressCode(params: any) {
        this.httpService.get(API_URL.GET_ADDRESS_CODE, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.SET_ADDRESS_CODE,
                data: response.result
            });
        });
    }

    /**
     * 郵便番号をクリア
     */
    public clearZipCode() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_ZIP_CODE,
        });
    }

    /**
     * 選択した撮影書類名を保存
     * @param param
     */
    public saveDocumentName(param) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SAVE_DOCUMENT_NAME,
            data: param
        });
    }

    /**
     * 名寄せリスト作成APIを実行
     * @param params
     */
    public cutomerInfosList(params: any) {
        this.httpService.post(API_URL.CUSTOMER_INFOS_LIST, params, undefined, SpinnerType.SHOW, true).subscribe(
            (response) => {
                this.dispatcher.dispatch({
                    actionType: ExistingSavingsActionType.CUSTOMER_INFOS_LIST,
                    data: {
                        res: response instanceof HttpStatusError ? response.errors.data : response.result,
                    }
                });
            }
        );
    }

    public acceptCheckForTelDifCif(params: any, difInfos: ChangeDifferenceEntity[]) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, params, undefined, SpinnerType.SHOW, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.ADDRESS_CHANGE_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: ExistingSavingsActionType.ACCEPT_CHECK_FOR_TEL_DIF_CIF,
                        data: {
                            res: response instanceof HttpStatusError ? response.errors.data : response.result,
                            difItems: difInfos
                        }
                    });
                }
            }
        );
    }

    /**
     * Skip node
     * @param nextOrder the order skip to
     */
    public skip() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SKIP,
        });
    }

    /**
     * 地域コードを検索する(WebAPI呼び出し)
     * @param params 地域コード検索条件
     */
    public searchRegionCode(params: RegionCodeSearchRequestEntity) {
        // 検索条件不足の場合はWebAPI呼ばない
        if (StringUtils.isEmpty(params.streetKanji)) {
            const regionCode = new RegionCodeEntity();
            regionCode.regionCodeDeterminationMethod = RegionCodeDeterminationMethod.WITHOUT_STREET;
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.SEARCH_REGION_CODE,
                data: regionCode
            });
        } else {
            this.httpService.get(API_URL.REGION_CODE_SEARCH, { params: params }).subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: ExistingSavingsActionType.SEARCH_REGION_CODE,
                    data: response.result
                });
            });
        }
    }

    /**
     * 差分のフラグをバックアップする
     */
    public differenceFlgBackup() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.DIFFERENCE_FLG_BACKUP,
        });
    }

    /**
     * 修正チャットモーダルを開く際、変更後の氏名をクリア
     */
    public clearHolderName() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_HOLDER_NAME,
        });
    }

    /**
     * 修正チャットモーダルを開く際、変更後の住所をクリア
     */
    public clearHolderAddress() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_HOLDER_ADDRESS,
        });
    }

    /**
     * 修正チャットモーダルを開く際、変更後の電話番号をクリア
     */
    public clearHolderPhoneNo() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_HOLDER_PHONE_NO,
        });
    }

    public clearAddCheckData() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_ADD_CHECK_DATA,
        });
    }

    /**
     * BC複合取引情報を保存
     * @param params creditCardSubmitData
     */
    public saveCreditCardData(creditCardSubmitData: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SAVE_CREDIT_CARD_DATA,
            data: creditCardSubmitData
        });
    }

    /**
     * 開設店舗変更後に呼ばれる,
     * 呼ばれる箇所→１。既存新規の申込チャット　２。既存新規の確認画面
     * パターン１：他の店舗に変わる
     * パターン２：カード所属店舗に変わる
     *
     * @param {*} data
     * @param {ExistingSavingsSubmitEntity} submitData
     * @memberof ExistingSavingsAction
     */
    public changeOpenStore(data: any, submitData: ExistingSavingsSubmitEntity) {

        this.setStateSubmitDataValue([
            { key: 'tenbanChanged', value: data.tenban || data.branchNo },
            { key: 'branchNameChanged', value: data.branchName || data.branchNameKanji },
            {
                key: 'identificationCodeChanged', value:
                    this.nameBasedAggregationService.getIdentificationCodeAfterChangeStore(
                        submitData.customerId, // カードのcustomerId
                        data.branchNo, // 変更後の店舗番号
                        submitData.cardInfo, // カード情報
                        submitData.allCifInfos)
            }, // 全店名寄せ
            {
                key: 'customerIdChanged', value:
                    this.nameBasedAggregationService.getCustomerIdAfterChangeStore(
                        submitData.customerId, // カードのcustomerId
                        data.branchNo, // 変更後の店舗番号
                        submitData.cardInfo, // カード情報
                        submitData.allCifInfos)
            },
            {
                key: 'changeStoreFlg', value:
                    data.branchNo !== submitData.cardInfo.branchNo ? StoreChanged.YES : undefined
            },
        ]);

        if (data.branchNo === submitData.cardInfo.branchNo) {
            // カードスワープ店舗に変更する場合は、理由が要らないので、理由をクリアする.(存在する場合はクリアする)
            this.setStateSubmitDataValue([
                { key: 'savingBranchReason', value: undefined },
                { key: 'holderSavingOtherShopReason', value: undefined },
            ]);
        }
    }

    public clearWorkAndCrs(flg: ClearWorkOrCrs) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.CLEAR_WORK_OR_CRS,
            data: flg
        });
    }

    public restoreWorkAndCrs() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.RESTORE_WORK_OR_CRS
        });
    }

    /**
     * ICカードの情報をstateに保存
     *
     * @param {string} data
     * @memberof SavingsAction
     */
    public setIcData(data: string) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_IC_DATA,
            data: data
        });
    }

    /**
     * ユーザーカード番号を保存
     */
    public setPanApd(code: string) {
        if (AppProperties.DEV_MODE === String(false)
            && !InputUtils.isTrngEnvNoCard(this.loginStore.getState().cardReaderDeviceId)) {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.SET_USER_CARD_PAN,
                data: {
                    cardInfo: {
                        bankNo: code.substr(0, 4),                                  // 金融機関
                        // 店番号 左の'0'を外す ３桁足りない場合０を埋める
                        branchNo: StringUtils.padLeft(code.substr(4, 5).replace(/0+([1-9]+)/, '$1'), 3, '0'),
                        accountType: code.substr(9, 1) === '1' ? '12' : '99',       // 種目 （1）普通預金=(12)普通預金 上記以外 = (99)その他
                        // 口座番号 左の'0'を外す　７桁足りない場合０を埋める
                        accountNo: StringUtils.padLeft(code.substr(10, 8).replace(/0+([1-9]+)/, '$1'), 7, '0')
                    }
                }
            });
        } else {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.SET_USER_CARD_PAN,
                data: {
                    cardInfo: {
                        bankNo: '0138',      // 金融機関
                        branchNo: code.substr(0, 3),    // 店番号
                        accountType: '12',       // 種目 （1）普通預金=(12)普通預金 上記以外 = (99)その他
                        accountNo: code.substr(3)       // 口座番号
                    }
                }
            });
        }
    }

    public async validatePassword(params: any) {

        // ICログ
        try {
            this.logging.saveCustomOperationLog(
                'reception-password',
                'ic-data:' + (params.params.icCardInfo ? params.params.icCardInfo.length : 'null')
            );
        } catch (ex) {
            this.logging.saveCustomOperationLog('reception-password', 'Exception');
        }

        return new Promise((resolve, reject) => {
            this.httpService.post('/reception/get', params, null, SpinnerType.SHOW_TRANSPARENT, true)
                .pipe(tap((res) => this.setCifInfoByCardSwip(res)))
                .subscribe((result) => {
                    if (result.status === HttpStatus.SUCCESS) {
                        resolve(true);
                    } else if (result.status === HttpStatus.HOST_ERROR) {
                        if (result.errors.data &&
                            result.errors.data.resultCode &&
                            result.errors.data.resultCode === HostResultCode.RECEPTION_GET_ERROR) {
                            resolve(true);
                        } else {
                            this.hostErrorService.push({
                                resultCode: result.errors.data.resultCode,
                                errorCode: result.errors.data.errorCode,
                                message: result.errors.message,
                                handel: () => {
                                    resolve(false);
                                }
                            });
                        }
                    } else {
                        throw new HttpStatusError('/reception/get', result.status, result.errors);
                    }
                }, (error) => {
                    reject(error);
                });
        });
    }

    /**
     * カードスワイプなしで既存新規に入るときに、顧客情報を取得する。
     * 注意：カード認証、カード受付可否チェック（22）実施しない
     * @param params
     */
    public receptionGetWithOutCard(params: any) {

        this.httpService.post('/reception/get', params, null, SpinnerType.SHOW_TRANSPARENT, true)
            .pipe(tap((res) => this.setCifInfoByCardSwip(res)))
            .subscribe((result) => {
                if (result.status === HttpStatus.SUCCESS) {
                    // resolve(true);
                } else if (result.status === HttpStatus.HOST_ERROR) {
                    if (result.errors.data &&
                        result.errors.data.resultCode &&
                        result.errors.data.resultCode === HostResultCode.RECEPTION_GET_ERROR) {
                        // resolve(true);
                    } else {
                        this.hostErrorService.push({
                            resultCode: result.errors.data.resultCode,
                            errorCode: result.errors.data.errorCode,
                            message: result.errors.message,
                            // handel: () => {
                            //     resolve(false);
                            // }
                        });
                    }
                } else {
                    throw new HttpStatusError('/reception/get', result.status, result.errors);
                }
            }, (error) => {
                // reject(error);
            });
    }

    /**
     * cif情報をセット
     * @param info cif情報
     */
    public setCifInfoByCardSwip(info: any) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_CIF_INFO_BY_CARD_SWIP,
            data: info
        });
    }

    /**
     * 全店名寄せ照会
     * @param params パラメータ
     */
    public nameAggregationInquiry(params: any) {
        this.httpService.post(API_URL.NAME_AGGREGATION, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.NAME_AGGREGATION,
                data: {
                    customerInfo: response.result.customerInfo,
                    customerSearchStatus: response.result.customerSearchStatus
                }
            });
        });
    }

    /**
     * 受付可否チェック(喪失・破損)APIを実行する
     * @param params 受付可否チェックパラメータ
     */
    public receptionLossCorruptionCheck(params: ReceptionLossCorruptionCheckRequest, name?: string) {
        this.receptionLossCorruptionCheckApi(params, name, ExistingSavingsActionType.RECEPTION_LOSS_CORRUPTION_CHECK);
    }

    /**
     * 受付可否チェック(喪失・破損)APIを実行する。エラー情報が存在した場合、前回実行時の結果に追記する。
     * @param params 受付可否チェックパラメータ
     */
    public receptionLossCorruptionCheckAdd(params: ReceptionLossCorruptionCheckRequest, name?: string) {
        this.receptionLossCorruptionCheckApi(params, name, ExistingSavingsActionType.RECEPTION_LOSS_CORRUPTION_CHECK_ADD);
    }

    /**
     * 受付可否チェック(喪失・破損)APIを実行する。実行後処理は呼び出し元に委任する。
     * @param params 受付可否チェックパラメータ
     */
    public receptionLossCorruptionCheckApi(params: ReceptionLossCorruptionCheckRequest, name: string, actionType: string) {
        this.httpService.post(API_URL.RECEPTION_LOSS_CORRUPTION_CHECK, params, undefined, undefined, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.RECEPTION_LOSS_CORRUPTION_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: actionType,
                        data: {
                            name: name,
                            data: response instanceof HttpStatusError ? response.errors.data : response.result,
                            requestParams: params
                        }
                    });
                }
            }
        );
    }

    /**
     *  OCR読取した免許証が運転経歴証明書だった場合のstate更新処理
     *
     */
    public setStateDataForHasDriversCareerLicense() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.SET_STATE_DATA_FOR_HAS_DRIVERS_CAREER_LICENSE
        });
    }

    /**
     * ORC聴取の場合、有効期限をバックアップ
     */
    public backupOCRDueDate() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.BACKUP_OCR_DUE_DATE
        });
    }

    /**
     * 内部API: 顧客情報照会（複数件取得）
     * @param params
     */
    public getCustomerInfo(params: any) {
        this.httpService.post(API_URL.CB_CIF_INFOS_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingSavingsActionType.SET_CUSTOMER_INFO,
                data: response.result
            });
        });
    }
    /**
     * OCR読取（運転免許証）の場合、本人確認チャットで
     * 運転経歴証明書を選択した際の確認チャットで「いいえ」回答時
     * 免許証or経歴証明書を選択させるため回答済チャットを削除する
     */
    public gobackRelateChat() {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.GO_BACK_RELATE_CHAT
        });
    }

    /**
     * 修正チャットで有効期限がクリア状態か判別するフラグを保存する。
     */
    public setModifyExpiryDateExists(value: boolean) {
        this.dispatcher.dispatch({
            actionType: ExistingSavingsActionType.MODIFY_EXPIRY_DATE_EXISTS,
            data: value
        });
    }
}
