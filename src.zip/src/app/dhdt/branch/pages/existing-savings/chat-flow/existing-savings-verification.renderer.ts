import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import { ChangeConfirmComponent } from 'dhdt/branch/pages/change/view/change-confirm.component';
import {
    AccountType, AgentInternalError, BusinessCode, ClearWorkOrCrs, COMMON_CONSTANTS, Constants, ContractCategory,
    CoreBankingConst, CountryCode, IdentificationCode, JudgeResultStatus, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import {
    ExistingSavingsSignal, ExistingSavingsState, ExistingSavingsStore
} from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { DialogComponent } from 'dhdt/branch/shared/components/dialog/dialog.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { MultiButtonGroupComponent } from 'dhdt/branch/shared/components/multi-button-group/multi-button-group.component';
import { AccountInfoInputComponent } from 'dhdt/branch/shared/components/number-input/account-info-input.component';
import { CardInfoEntity } from 'dhdt/branch/shared/entity/card-info.entity';
import { AccountInfoInquiryInterface } from 'dhdt/branch/shared/interface/account-info-inquiry.interface';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { CardService } from 'dhdt/branch/shared/services/card.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ErrorUtils } from 'dhdt/branch/shared/utils/error-utils';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { NavController } from 'ionic-angular';
import { ModalController } from 'ionic-angular/components/modal/modal-controller';
import { switchMap } from 'rxjs/operators';
import { CifInfo } from '../../common/entity/all-customer-infos-response.entity';

/**
 * 普通預金 既存_普通預金口座開設_入力画面
 */
export class ExistingSavingsVerificationRenderer extends ExistingSavingsChatFlowRenderer {

    public processType = 1;

    private loginStore: LoginStore;
    private state: ExistingSavingsState;
    private modalService: ModalService;
    // 送信電文
    private icCardTeleGram: string = null;
    private modalCtrl: ModalController;

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: ExistingSavingsStore,
        private deviceService: DeviceService,
        private audioService: AudioService,
        private navCtrl: NavController,
        private cardService: CardService,
        private logging: LoggingService,
        private rsaEncryptService: RsaEncryptService,
        private action: ExistingSavingsAction
    ) {
        super();
        this.state = this.store.getState();
        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.modalService = InjectionUtils.injector.get(ModalService);
        this.modalCtrl = InjectionUtils.injector.get(ModalController);
    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(COMMON_CONSTANTS.YML_CHAT_FLOW_EXISTING_SAVINGS_VARIFICATION, pageIndex);
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_NAME_AGGREGATION: {
                this.onNameAggregationInquiry(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_REQUEST: {
                this.onRequest(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_CIF_INFOS_INQUIRY: {
                this.onCifInfosInquiry(question, pageIndex);
                break;
            }
            case 'mulitButton': {
                this.onMulitButton(question, pageIndex);
                break;
            }
        }
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                if (!answer.action ||
                    (answer.action.value !== 'noticeButtonModal' &&
                    answer.action.type !== COMMON_CONSTANTS.ACTION_TYPE_MODAL)) {
                    if (entity.name !== 'nextButton') {
                        this.setAnswer({
                            text: answer.text,
                            value: [
                                { key: entity.name, value: answer.value },
                                { key: answer.name, value: answer.value }
                            ]
                        });
                    }
                }
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                if (entity.name !== 'nextButton') {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.text }
                        ]
                    });
                }
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onMulitButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxLength: entity.validationRules.max
        };
        this.chatFlowAccessor.addComponent(entity.choices, MultiButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
            }

            this.chatFlowAccessor.clearComponent();

            let next = answer.next.split(COMMON_CONSTANTS.FULL_PAUSE)[0];
            if (entity.name === COMMON_CONSTANTS.HOLDER_CAREER) {
                answer.next.split(COMMON_CONSTANTS.FULL_PAUSE).forEach((order) => {
                    if (order === entity.next) {
                        next = order;
                    }
                });
            }
            this.getNextChat(Number.parseInt(next), pageIndex);
        });
    }

    /**
     * パスワードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onPassword(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        let modal;
        modal = this.modalCtrl.create(ModalPasswordComponent, {
            data: {
                subText: this.labels.password.inputPasswordSubText,
                units: COMMON_CONSTANTS.PASSWORD_MODAL_UNITS,
                needConfirm: false,
                validation: (password) => this._action.validatePassword({
                    tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                    params: {
                        receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                        tenban: this.state.submitData.cardInfo.branchNo, // 店番
                        accountType: this.state.submitData.cardInfo.accountType, // 科目
                        accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                        icCardInfo: this.icCardTeleGram,  // カードのIC情報（INQ電文用データ）
                        passcode: this.rsaEncryptService.encrypt(password)  // 暗証番号
                    }
                })
            }
        }, { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.present();
        modal.onDidDismiss((params) => {
            if (params) {
                this.getNextChat(entity.next, pageIndex);
            }
        });
    }
    /**
     * キーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });

                        const resetResultList = InputUtils.holderNameReset(entity.name, this.state.submitData);
                        if (resetResultList) {
                            this._action.setStateSubmitDataValue(resetResultList);
                        }
                        this.getNextChat(entity.next, pageIndex);
                    });
                }
            });
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        if (entity.choices && entity.name === 'checkMobilePhone') {
            const submitData = this.state.submitData;
            let isMobilePhone = '0';

            // 諸届変更で携帯番号登録時
            if (submitData.holderMobileNo && Constants.REGEXP_MOBILE_WITH_DASH.test(submitData.holderMobileNo)) {
                isMobilePhone = '1';
            } else if (
                submitData.holderMobileNo === undefined
                && submitData.holderTelephoneNo === undefined
                && (submitData.holderTelNo1 && Constants.REGEXP_MOBILE_WITH_DASH.test(submitData.holderTelNo1)
                    || submitData.holderTelNo2 && Constants.REGEXP_MOBILE_WITH_DASH.test(submitData.holderTelNo2)
                    || submitData.holderTelNo3 && Constants.REGEXP_MOBILE_WITH_DASH.test(submitData.holderTelNo3)
                )) {
                isMobilePhone = '1';
            }

            entity.choices.forEach((choice) => {
                if (isMobilePhone === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });

        } else if (entity.name === 'cardReader') {
            // 開発環境では無い場合 かつ　研修環境でカードIDがNOTではない場合　カードリーダを使用
            if (AppProperties.DEV_MODE === String(false)
                && !InputUtils.isTrngEnvNoCard(this.loginStore.getState().cardReaderDeviceId)) {

                const subscribeOnCard = this.cardService.onCardPresent().pipe(
                    switchMap(() => {
                        return this.cardService.readCardInfoWapper();
                    })
                ).subscribe((info: CardInfoEntity) => {
                    this.cardService.reset();
                    // 送信電文を得る
                    this.icCardTeleGram = info.getTelegramInfo();
                    // ICログ
                    try {
                        this.logging.saveCustomOperationLog(
                            'reception',
                            'ic-data:' + (this.icCardTeleGram ? this.icCardTeleGram.length : 'null')
                        );
                        this.logging.saveSpecialCustomOperationLog(
                            'reception',
                            info.checkTelegramInfoItemLength()
                        );
                    } catch (ex) {
                        this.logging.saveCustomOperationLog('reception', 'Exception');
                    }
                    // 送信電文をstateに保存
                    this._action.setIcData(this.icCardTeleGram);
                    this._action.setPanApd(info.pan);
                    this.getNextChat(entity.next, pageIndex);
                },
                    (data) => {
                        subscribeOnCard.unsubscribe();
                        this._action.resetLastNode({ order: entity.order, pageIndex: pageIndex });
                    });
            } else {
                this.onAccountInfoInput(entity, pageIndex);
            }

        } else if (entity.name === 'primaryAccountCheck') {
            // 既存新規口座開設の場合、代表口座存在チェック
            if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
                let primaryCount: number = 0;  // 代表口座件数
                let relationCount: number = 0;  // 関連口座件数
                this.state.submitData.allCifInfos.forEach((cifInfo) => {
                    if (cifInfo.domesticAccountInfo) {
                        cifInfo.domesticAccountInfo.forEach((accountInfo) => {
                            if (accountInfo.ibContractInfo && accountInfo.ibContractInfo.contractCategory) {
                                accountInfo.ibContractInfo.contractCategory === ContractCategory.primary ?
                                    primaryCount++ : relationCount++;
                            }
                        });
                    }
                });
                // PID配下口座なし、または代表口座ありの場合、次のチャットへ進む
                if ((primaryCount === 0 && relationCount === 0) || primaryCount > 0) {
                    this.getNextChat(entity.next, pageIndex);
                } else {
                    // 代表口座なしかつ関連口座１件以上の場合、エラーモーダル
                    this.showErrorModal(AgentInternalError.ERROR_CODE_N_007);
                }
            } else {
                this.getNextChat(entity.next, pageIndex);
            }
        } else if (entity.name === 'checkForAllCustomerInfosResponse') {
            // 全店名寄せ照会APIの顧客情報リスト内で国籍相違が存在するか
            const isNationalityInconsistent = this.state.submitData.allCifInfos.some(
                (cifInfo) => cifInfo.nationality !== this.state.submitData.allCifInfos[0].nationality);
            const isForeignerKanjuNameNull = this.state.submitData.allCifInfos.some(
                (cifInfo) => cifInfo.nationality !== CountryCode.Japan && !cifInfo.englishName);
            if (this.state.submitData.customerSearchStatus === COMMON_CONSTANTS.CustomerSearchStatus.NOT_ALL_OUTPUT) {
                // 全店名寄せ照会APIの顧客検索結果が「1:未出力明細あり」の場合
                this.showErrorModal(AgentInternalError.ERROR_CODE_N_001);
            } else if (isNationalityInconsistent) {
                // 全店名寄せ照会APIの顧客情報リスト内で国籍相違が存在する場合
                this.showErrorModal(AgentInternalError.ERROR_CODE_N_002);
            } else if (isForeignerKanjuNameNull) {
                // 全店名寄せ照会APIの顧客情報リスト内で外国籍かつ英字氏名nullが存在する場合
                this.showErrorModal(AgentInternalError.ERROR_CODE_N_003);
            } else {
                // 上記エラー事由に該当しない場合
                this.getNextChat(entity.next, pageIndex);
            }
        } else if (entity.name === 'hasDoubleCif') {
            if (!InputUtils.isTrngEnv() && !this.businessCodeJudge()) {
                // 研修環境以外かつ特定業務以外の場合、二重CIF判定
                if (this.doubleCifJudge()) {
                    this.showErrorModal(AgentInternalError.ERROR_CODE_N_004);
                } else {
                    // 上記エラー事由に該当しない場合
                    this.getNextChat(entity.next, pageIndex);
                }
            } else {
                // 上記以外の場合
                this.getNextChat(entity.next, pageIndex);
            }
        } else if (entity.name === 'isSameCard') { // スワイプカード　と　受付チャットで選択カードのCIFが同じかどうか
            const judgeResult = this.state.submitData.selectTenpoCustomerId === this.state.submitData.customerId ?
                JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;

            entity.choices.forEach((choice) => {
                if (judgeResult === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        } else if (entity.name === 'selectTenpoCode') { // 受付チャットでスワイプカードの店舗番号あるかどうかをチェック
            const judgeResult = this.state.submitData.selectTenpoCode ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
            entity.choices.forEach((choice) => {
                if (judgeResult === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        } else if (entity.name === 'checkNotExistingAddressCodeStatus') {
            // 住所コードが存在するか
            const isNotExistingAddressCodeStatus = this.state.submitData.allCifInfos.some(
                (cifInfo) => cifInfo.addressInfo && cifInfo.customerId === this.state.submitData.customerId &&
                    cifInfo.addressInfo.notExistingAddressCodeStatus === COMMON_CONSTANTS.NotExistingAddressCodeStatus.NOT_APPLICABLE);
            // 全店名寄せ照会APIの住所コード該当有無を格納
            this._action.setStateSubmitDataValue([{ key: 'isNotExistingAddressCodeStatus', value: isNotExistingAddressCodeStatus }]);
            this.getNextChat(entity.next, pageIndex);
        } else if (entity.name === 'cardReader') {
            // 開発環境では無い場合 かつ　研修環境でカードIDがNOTではない場合　カードリーダを使用
            if (AppProperties.DEV_MODE === String(false)
                && !InputUtils.isTrngEnvNoCard(this.loginStore.getState().cardReaderDeviceId)) {

                const subscribeOnCard = this.cardService.onCardPresent().pipe(
                    switchMap(() => {
                        return this.cardService.readCardInfoWapper();
                    })
                ).subscribe((info: CardInfoEntity) => {
                    this.cardService.reset();
                    // 送信電文を得る
                    this.icCardTeleGram = info.getTelegramInfo();
                    // ICログ
                    try {
                        this.logging.saveCustomOperationLog(
                            'reception',
                            'ic-data:' + (this.icCardTeleGram ? this.icCardTeleGram.length : 'null')
                        );
                        this.logging.saveSpecialCustomOperationLog(
                            'reception',
                            info.checkTelegramInfoItemLength()
                        );
                    } catch (ex) {
                        this.logging.saveCustomOperationLog('reception', 'Exception');
                    }
                    // 送信電文をstateに保存
                    this._action.setIcData(this.icCardTeleGram);
                    this._action.setPanApd(info.pan);
                    this.getNextChat(entity.next, pageIndex);
                },
                    (data) => {
                        subscribeOnCard.unsubscribe();
                        this._action.resetLastNode({ order: entity.order, pageIndex: pageIndex });
                    });
            } else {
                this.onAccountInfoInput(entity, pageIndex);
            }
            // 店舗変更後、変更後の店舗によって職業を入れるかどうかを判断
        } else if (entity.name === 'ifAllIdentificationCode80') {
            // 0　は入力必要、１　は入力要らない
            let judgeResult = '1';
            const identificationCodeWithChange = InputUtils.getIdentificationCodeWithChange(this.state.submitData);
            if (!identificationCodeWithChange
                || identificationCodeWithChange !== IdentificationCode.CODE_80) {
                judgeResult = '0';
            }

            if (identificationCodeWithChange === IdentificationCode.CODE_80) {
                this.action.clearWorkAndCrs(ClearWorkOrCrs.WORK);
            }

            // 職業を入力必要（０の場合）、かつ　職業が既に存在する場合、１を設定して職業入力を省略する
            if (judgeResult === '0' && this.state.submitData.holderCareer) {
                judgeResult = '1';
            }
            entity.choices.forEach((choice) => {
                if (judgeResult === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        } else if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    public onAccountInfoInput(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        if (!InputUtils.isTrngEnv()) {
            // 研修環境以外の場合、店番号は任意の3桁が入力可能
            this.chatFlowAccessor.addComponent([{
                //     placeholder: '金融機関 4桁',
                //     validationRules: {
                //         required: true,
                //         regex: '^[0-9]{4}$'
                //     }
                // }, {
                placeholder: '店番号 3桁',
                value: '',
                validationRules: {
                    required: true,
                    regex: '^[0-9]{3}$',
                    max: 3
                }
            }, {
                //     placeholder: '種目 1桁',
                //     validationRules: {
                //         required: true,
                //         regex: '^[0-9]{1}$'
                //     }
                // }, {
                placeholder: '口座番号 7桁',
                value: '',
                validationRules: {
                    required: true,
                    regex: '^[0-9]{7}$',
                    max: 7
                }
            }], AccountInfoInputComponent,
                this.footerContent, options).subscribe((answer) => {
                    this._action.setPanApd(answer.map((item) => item.value).join(''));
                    this.getNextChat(entity.next, pageIndex);
                });
        } else {
            // 研修環境の場合、店番号は033固定
            this.chatFlowAccessor.addComponent([{
                placeholder: '店番号 3桁',
                value: '033',
                validationRules: {
                    required: true,
                    regex: '^(033)$',
                    max: 3
                }
            }, {
                placeholder: '口座番号 7桁',
                value: '',
                validationRules: {
                    required: true,
                    regex: '^[0-9]{7}$',
                    max: 7
                }
            }], AccountInfoInputComponent,
                this.footerContent, options).subscribe((answer) => {
                    this._action.setPanApd(answer.map((item) => item.value).join(''));
                    this.getNextChat(entity.next, pageIndex);
                });
        }
    }

    public onSaveSubmit(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((item: any) => {
                this._action.setStateSubmitDataValue([{key: item.name, value: item.value}]);
            });
            this.getNextChat(entity.next, pageIndex);
        }
    }
    /**
     * 全店名寄せ照会
     */
    private onNameAggregationInquiry(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                customerId: this.state.submitData.customerId, // 全店顧客番号
            }
        };
        this._store.unregisterSignalHandler(ExistingSavingsSignal.GET_NAME_AGGREGATION_INQUIRY);
        this._store.registerSignalHandler(ExistingSavingsSignal.GET_NAME_AGGREGATION_INQUIRY, () => {
            this._store.unregisterSignalHandler(ExistingSavingsSignal.GET_NAME_AGGREGATION_INQUIRY);

            // 内部API:受付 の業務受付可否チェックがNGの場合、エラーモーダルを表示。
            // モーダル表示に全店名寄せレスポンスを利用するため、ここに実装する。
            if (this.state.submitData.responseForModal) {
                ErrorUtils.errorHandling(
                    this.state.submitData.responseForModal,
                    this.state.submitData.allCifInfos,
                    this.modalService,
                    this.labels
                );
            } else {
                // 空CIFの場合、店番と店舗名を該当CIFの管理店舗による格納
                if (this.state.submitData.openingAccountPatternC) {
                    const cif = this.state.submitData.allCifInfos.find((cifInfo) =>
                        cifInfo.customerId === this.state.submitData.customerId);
                    this.action.setStateSubmitDataValue([
                        { key: 'tenban' , value: cif.customerManagementBranchCode },
                        { key: 'branchName' , value: cif.customerManagementBranchName }
                    ]);
                }
                this.getNextChat(entity.next, pageIndex);
            }

        });
        this._action.nameAggregationInquiry(param);
    }

    /**
     * APIリクエスト送信
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private onRequest(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        switch (entity.name) {
            case 'receptionCheckCommon': // 受付可否チェック【業務共通NGチェック】
                this.applyCheck(entity, pageIndex, BusinessCode.COMMON_NG);
                break;
            case 'receptionGet': // カードスワイプなしときに、顧客情報、受付チェックを実施
                this.receptionGet(entity, pageIndex);
                break;
            case 'receptionCheck': // 受付可否チェック【業務選択後（申込手続き前）】
                if (this.state.submitData.businessCode === BusinessCode.SAVING_ACCOUNT ||
                    this.state.submitData.businessCode === BusinessCode.BC_APPLY ||
                    this.state.submitData.businessCode === BusinessCode.INHERIT ||
                    this.state.submitData.businessCode === BusinessCode.EXISTING_REGULAR ||
                    this.state.submitData.businessCode === BusinessCode.EXISTING_CANCEL) {
                    this.receptionCheck(entity, pageIndex);
                } else {
                    this.getNextChat(entity.next, pageIndex);
                }
                break;
        }
    }

    private receptionGet(entity, pageIndex) {
        this._action.receptionGetWithOutCard({
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                customerId: this.state.submitData.customerId   // 顧客番号
            },
            swipCardExistFlg: '0' // スワイプカードが存在しない
        });
        // 次のチャットへ遷移
        this.getNextChat(entity.next, pageIndex);
    }

    /**
     * 受付可否チェック（業務共通NGチェック）を実行し、結果保存の上チェックOK/NGより次処理を行う。
     * 業務コードは呼び出し元にて設定する。
     *
     * @private
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof LossReissueProcessBranchRenderer
     */
    private applyCheck(entity, pageIndex, businessCode: string) {
        // 受付可否チェック（喪失・破損）の実行後処理を定義
        this._store.registerSignalHandler(ExistingSavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK, () => {
            this._store.unregisterSignalHandler(ExistingSavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK);
            // 情報取得後、チェックNGの場合はエラーモーダル、チェックOKの場合は次チャットへ遷移
            if (this.state.submitData.responseForModal) {
                ErrorUtils.errorHandling(
                    this.state.submitData.responseForModal,
                    this.state.submitData.allCifInfos,
                    this.modalService,
                    this.labels
                );
            } else {
                this.getNextChat(entity.next, pageIndex);
            }
        });

        // 受付可否チェック（喪失・破損）を実行(実行結果をPID以下の全CIFに対してのチェックとして保存する)
        this._action.receptionLossCorruptionCheck({
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                // PID以下全CIFを対象とする
                accounts: this.state.submitData.allCifInfos.map((cifInfo: CifInfo) => {
                    // 顧客番号をキーに受付可否チェックを行う
                    return {
                        tenban: null,
                        accountType: null,
                        accountNo: null,
                        customerId: cifInfo.customerId
                    };
                }),
                // 業務コード
                businessCode: businessCode
            }
        }, 'allCifReceptionCheckResult');
    }

    /**
     * 受付可否チェック（業務選択後（申込手続き前））を実行し、結果保存の上チェックOK/NGより次処理を行う。
     *
     * @private
     * @param {SavingQuestionsModel} entity
     * @param {number} pageIndex
     * @memberof ReceptionComponent
     */
    private receptionCheck(entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        // 受付可否チェック（喪失・破損）の実行後処理を定義
        this._store.registerSignalHandler(ExistingSavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK, () => {
            this._store.unregisterSignalHandler(ExistingSavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK);
            // BC申込の場合、スワイプ口座についても受付可否チェックを実行する
            if (this.state.submitData.businessCode === BusinessCode.BC_APPLY) {
                this.receptionCheckForAccount(entity, pageIndex, BusinessCode.BC_APPLY_ACCOUNT);
                return;
            }
            // 情報取得後、チェックNGの場合はエラーモーダル、チェックOKの場合は次チャットへ遷移
            if (this.state.submitData.responseForModal) {
                ErrorUtils.errorHandling(
                    this.state.submitData.responseForModal,
                    this.state.submitData.allCifInfos,
                    this.modalService,
                    this.labels
                );
            } else {
                this.getNextChat(entity.next, pageIndex);
            }
        });

        let account;
        if (this.state.submitData.businessCode === BusinessCode.EXISTING_REGULAR ||
            this.state.submitData.businessCode === BusinessCode.EXISTING_CANCEL) {
            // スワイプCIFの店科口をキーに受付可否チェックを行う
            account = {
                tenban: this.state.submitData.cardInfo.branchNo,
                accountType: this.state.submitData.cardInfo.accountType,
                accountNo: this.state.submitData.cardInfo.accountNo,
                customerId: null
            };
        } else {
            // スワイプCIFの顧客番号をキーに受付可否チェックを行う
            account = {
                tenban: null,
                accountType: null,
                accountNo: null,
                customerId: this.state.submitData.customerId
            };
        }

        // 受付可否チェック（喪失・破損）を実行
        this._action.receptionLossCorruptionCheck({
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                accounts: [
                    {
                        tenban: account.tenban,
                        accountType: account.accountType,
                        accountNo: account.accountNo,
                        customerId: account.customerId
                    }
                ],
                // 業務コード
                businessCode: this.state.submitData.businessCode
            }
        });
    }

    /**
     * スワイプ口座の受付可否チェック。（CIFの受付可否チェック実行後に、必要な業務のみ実行する）
     * 受付可否チェック（業務選択後（申込手続き前））を実行し、結果保存の上チェックOK/NGより次処理を行う。
     *
     * @private
     * @param {SavingQuestionsModel} entity
     * @param {number} pageIndex
     * @memberof ReceptionComponent
     */
    private receptionCheckForAccount(entity: ExistingSavingsQuestionsModel, pageIndex: number, businessCode: string) {

        // 受付可否チェック（喪失・破損）の実行後処理を定義
        this._store.registerSignalHandler(ExistingSavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK_ACCOUNT, () => {
            this._store.unregisterSignalHandler(ExistingSavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK_ACCOUNT);
            // 情報取得後、チェックNGの場合はエラーモーダル、チェックOKの場合は次チャットへ遷移
            if (this.state.submitData.responseForModal) {
                ErrorUtils.errorHandling(
                    this.state.submitData.responseForModal,
                    this.state.submitData.allCifInfos,
                    this.modalService,
                    this.labels
                );
            } else {
                this.getNextChat(entity.next, pageIndex);
            }
        });

        // 受付可否チェック（喪失・破損）を実行
        this._action.receptionLossCorruptionCheckAdd({
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                accounts: [
                    {
                        tenban: this.state.submitData.cardInfo.branchNo, // 店番
                        accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                        accountType: this.state.submitData.cardInfo.accountType, // 科目
                        customerId: null
                    }
                ],
                // 業務コード
                businessCode: businessCode
            }
        });
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            if (action.value === 'modalNextChat') {
                this.modalService.showModal('noticeButtonModal', { imgSrc: COMMON_CONSTANTS.LINE_OFFICIAL_ACCOUNT },
                    (result) => {
                        this.getNextChat(choice.next, pageIndex);
                });
            } else {
                this.modalService.showModal(action.value, { imgSrc: COMMON_CONSTANTS.REGULATIONS_KOUZA_TOKUCHOU });
            }
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);

        } else if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_RETURN_TO_CHAT) {
            this.chatFlowReturn(action.value);
        }
    }

    /**
     * エラーモーダルを表示する（受付可否チェック以外のエラー用）
     */
    private showErrorModal(errorCode: string) {
        const errorParams = {
            imgSrc: 'icon_hourgrass@2x.png',
            message: this.labels.common.error.host.support,
            subMessage: `<span class="font-color-red">${errorCode}</span>`,
            buttonList: [{ text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK }]
        };
        const errorModal = this.modalCtrl.create(
            DialogComponent, errorParams, { cssClass: 'settings-error-modal', enableBackdropDismiss: false }
        );
        this.audioService.subject.next(true);
        errorModal.present();
    }

    /**
     * 選択業務が特定業務（相続、定期預金）かどうか判定
     */
    private businessCodeJudge(): boolean {
        return this.state.submitData.businessCode === BusinessCode.INHERIT ||
            this.state.submitData.businessCode === BusinessCode.EXISTING_REGULAR ||
            this.state.submitData.businessCode === BusinessCode.EXISTING_CANCEL;
    }

    /**
     * 全店名寄せ照会APIの顧客リスト内で顧客管理店番号が重複するCIFが二件以上あるか判定
     */
    private doubleCifJudge(): boolean {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((cifInfo) => {
            accounts.push(cifInfo.customerManagementBranchCode);
        });
        const list = new Set(accounts);
        return accounts.length !== list.size;
    }

    /**
     * 顧客情報照会（PID配下全て）
     */
    private onCifInfosInquiry(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                accounts: this.makeAccountsList(), // 口座情報リスト
            }
        };
        this._store.unregisterSignalHandler(ExistingSavingsSignal.GET_CUSTOMER_INFO);
        this._store.registerSignalHandler(ExistingSavingsSignal.GET_CUSTOMER_INFO, () => {
            this._store.unregisterSignalHandler(ExistingSavingsSignal.GET_CUSTOMER_INFO);
            this.getNextChat(entity.next, pageIndex);
        });
        this._action.getCustomerInfo(param);
    }

    /**
     * 顧客情報照会APIのパラメータリスト作成
     */
    private makeAccountsList(): any {
        const accountsListArr = [];
        let account = {};
        for (const cifInfo of this.state.submitData.allCifInfos) {
            // 全店名寄せ照会結果から、国内口座情報の先頭の店科口がある場合、店科口を設定。
            // 国内口座情報の先頭の店科口がない場合、顧客番号を設定。
            account = cifInfo.domesticAccountInfo && cifInfo.domesticAccountInfo.length > 0 ?
                {
                    tenban: cifInfo.domesticAccountInfo[0].branchCode,
                    accountType: cifInfo.domesticAccountInfo[0].subjectCode,
                    accountNo: cifInfo.domesticAccountInfo[0].bankAccountId,
                    customerId: cifInfo.domesticAccountInfo[0].branchCode && cifInfo.domesticAccountInfo[0].subjectCode
                        && cifInfo.domesticAccountInfo[0].bankAccountId ? null : cifInfo.customerId,
                } :
                { customerId: cifInfo.customerId };
            accountsListArr.push(account);
        }
        return accountsListArr;
    }
}
