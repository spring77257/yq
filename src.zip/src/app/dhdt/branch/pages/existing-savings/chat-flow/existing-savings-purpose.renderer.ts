import { ViewContainerRef } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { DeviceService } from 'dhd/common/services/device.service';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { SavingsSignal, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    AccountType, Age, AgentInternalError, BusinessCode, ClearWorkOrCrs, COMMON_CONSTANTS, Constants,
    CoreBankingConst, HostErrorCodeReceptionNG,
    IdentificationCode, JudgeResultStatus, NameNonConvert, ReceptionStatus, StoreChanged
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import {
    CreditCardChatComponent
} from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat.component';
import { AcceptionResult } from 'dhdt/branch/pages/creditcard/entity/creditcard-bc-result';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import {
    ExistingSavingsQuestionsModel
} from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import {
    ExistingSavingsSignal, ExistingSavingsState, ExistingSavingsStore
} from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import {
    ExistingSavingsContentConfirmComponent
} from 'dhdt/branch/pages/existing-savings/view/existing-savings-content-confirm.component';
import {
    ExistingSavingsInitConfirmComponent
} from 'dhdt/branch/pages/existing-savings/view/existing-savings-initconfirm.component';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { CardListComponent } from 'dhdt/branch/shared/components/card-list/card-list.component';
import { DialogComponent } from 'dhdt/branch/shared/components/dialog/dialog.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { ModalBcnoticeScrollCheckComponent } from 'dhdt/branch/shared/components/modal/modal-pdf/modal-bcnotice-scroll-check.component';
import { MultiButtonGroupComponent } from 'dhdt/branch/shared/components/multi-button-group/multi-button-group.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { RadioButtonComponent } from 'dhdt/branch/shared/components/radio-button-group/radio-button.component';
import { SignatureComponent } from 'dhdt/branch/shared/components/signature/signature.component';
import { ExistingPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/existing-password-rule-check.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { NameBasedAggregationService } from 'dhdt/branch/shared/services/name-based-aggregation.service';
import { ErrorUtils } from 'dhdt/branch/shared/utils/error-utils';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController } from 'ionic-angular';

/**
 * 普通預金 既存_普通預金口座開設_入力画面
 */
export class ExistingSavingsPurposeRenderer extends ExistingSavingsChatFlowRenderer {
    public processType = 1;
    private state: ExistingSavingsState;
    private arrayPassword: string[]= [];

    constructor(private chatFlowAccessor: ExistingSavingsChatFlowAccessor, private footerContent: ViewContainerRef,
                private store: ExistingSavingsStore, private modalService: ModalService, private modalCtrl: ModalController,
                private deviceService: DeviceService, private loginStore: LoginStore, public navCtrl: NavController,
                private action: ExistingSavingsAction, private audioService: AudioService,
                private nameBasedAggregationService: NameBasedAggregationService) {
        super();
        this.state = this.store.getState();
    }

    /**
     * YMLファイル読み込み
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(COMMON_CONSTANTS.YML_CHAT_FLOW_EXISTING_SAVINGS_PURPOSE, pageIndex);
    }

    /**
     * チャットのtype属性についてハンドリング
     * @param question チャットの質問
     * @param pageIndex ページ番号
     */
    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);

        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS6:
            case COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4: {
                if (this.state.submitData.existingChangeFirstMobileNo != null) {
                    this.arrayPassword.push(this.state.submitData.existingChangeFirstMobileNo +
                   COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.existingChangeSecondMobileNo + COMMON_CONSTANTS.HALF_HYPHEN
                   + this.state.submitData.existingChangeThirdMobileNo);
                }
                if (this.state.submitData.existingChangeFirstTel != null) {
                   this.arrayPassword.push(this.state.submitData.existingChangeFirstTel +
                       COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.existingChangeSecondTel + COMMON_CONSTANTS.HALF_HYPHEN
                       + this.state.submitData.existingChangeThirdTel);
                }
                if (this.state.submitData.existingChangeFirstMobileNo == null && this.state.submitData.existingChangeFirstTel == null) {
                    this.arrayPassword.push(this.state.submitData.holderTelNo1);
                    this.arrayPassword.push(this.state.submitData.holderTelNo2);
                    this.arrayPassword.push(this.state.submitData.holderTelNo3);
                }

                this.onPasswordInput(question, pageIndex, this.arrayPassword);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_CARD: {
                this.onCard(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_MODAL_AGREED: {
                this.onModal(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_RADIO_BUTTON: {
                this.onRadioButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_TWOCOLS_BUTTON: {
                this.onButtonTwoCols(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECT_BRANCH: {
                this.onSelectBranch(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_REQUEST: {
                this.onRequest(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_TEMP: {
                this.onButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_MULIT_BUTTON: {
                this.onMulitButton(question, pageIndex);
                break;
            }
            case 'complete': {
                if (question.example === 'ExistingSavingsInitConfirmComponent') {
                    this.navCtrl.setRoot(ExistingSavingsInitConfirmComponent);
                }
                break;
            }
            case 'bankCard': {
                if (question.example === 'CreditCardCommonComponent') {
                    this.navCtrl.setRoot(CreditCardChatComponent,
                        {
                            // 住所変更ありの場合は、変更後の住所情報を送信する(親権者住所のため)
                            submitData: this.state.submitData.isAddressChange ? {
                                ...this.state.submitData,
                                zipCode: this.state.submitData.firstZipCode + '-' + this.state.submitData.lastZipCode,
                                address: this.state.submitData.holderAddressPrefecture
                                    + this.state.submitData.holderAddressCountyUrbanVillage
                                    + this.state.submitData.getHolderAddressStreetName() + this.state.submitData.holderAddressHouseNumber,
                                addressKana: this.state.submitData.holderAddressPrefectureFuriKana
                                    + this.state.submitData.holderAddressCountyUrbanVillageFuriKana
                                    + this.state.submitData.getHolderAddressStreetNameFuriKana()
                                    + this.state.submitData.holderAddressHouseNumberFuriKana,
                            } : this.state.submitData,
                            tabletApplyId: this.loginStore.getState().tabletApplyId,
                            pageIndex: 0,
                            accountType: this.state.submitData.accountType,
                            customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                            cardInfo: this.state.submitData.cardInfo,
                            receptionTenban: this.loginStore.getState().belongToBranchNo,
                        });
                }
                break;
            }
            case 'categoryNameLogicPicker': {
                this.onCategoryNameLogicPicker(question, pageIndex, 'data');
                break;
            }
            case 'categoryNamePhysicsPicker': {
                this.onCategoryNameLogicPicker(question, pageIndex, 'filler1');
                break;
            }
            case 'sign': {
                this.onSignature(question, pageIndex);
                break;
            }
            case 'change': {
                if (question.example === 'ExistingSavingsContentConfirmComponent') {
                    this.navCtrl.setRoot(ExistingSavingsContentConfirmComponent);
                }
                break;
            }
        }
    }

    /**
     * 固定値を保存する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSaveSubmit(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            this.action.setStateSubmitDataValue(entity.choices);
            this.getNextChat(entity.next, pageIndex);
        }
    }

    public onNumberKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.setAnswer({
                        text: answer.text,
                        value: [{
                            key: entity.name,
                            value: answer.text
                        }]
                    });
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    public onCategoryNameLogicPicker(entity: ExistingSavingsQuestionsModel, pageIndex: number, entryName?: any) {
        const options = {
            type: entity.type,
            validationRules: entity.validationRules,
            applyBizCategory: this.state.submitData.applyBizCategory,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
        };
        this.action.getCategoryNameLogic().subscribe((data) => {
            this.chatFlowAccessor.addComponent(
                data.map((item) => {
                    return {
                        text: item[entryName],
                        value: item.codeValue
                    };
                }),
                PickerCommonComponent,
                this.footerContent,
                options
            ).subscribe((answer) => {
                this.setAnswer({
                    text: answer.text,
                    value: [{
                        key: entity.name, value: answer.value[0].value
                    }, {
                        key: entity.name + 'Text', value: answer.text
                    }]
                });
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(entity.next, pageIndex);
            });
        });
    }

    public onSignature(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData
        };
        this.chatFlowAccessor.addComponent(entity.choices, SignatureComponent, this.footerContent, options).subscribe((answer) => {
            this.setAnswer({
                text: answer.text,
                value: [{
                    key: entity.name, value: answer.value
                }]
            });
            this.chatFlowAccessor.clearComponent();
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onMulitButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxLength: entity.validationRules.max
        };
        this.chatFlowAccessor.addComponent(entity.choices, MultiButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }                    ]
                });
            }

            this.chatFlowAccessor.clearComponent();

            let next = answer.next.split('、')[0];
            if (entity.name === COMMON_CONSTANTS.HOLDER_CAREER) {
                answer.next.split('、').forEach((order) => {
                    if (order === COMMON_CONSTANTS.ExistingSavings.CareerNextOrder) {
                        next = order;
                    }
                });
            }
            this.getNextChat(Number.parseInt(next), pageIndex);
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(
            entity.choices,
            ButtonGroupComponent,
            this.footerContent,
            options
        ).subscribe((answer) => {
            if (answer.action && answer.action.value && answer.action.value === 'pdfModal') {
                const title = answer.action.type === 'crs' ? this.labels.signature.crsExplanationTitle
                : this.labels.signature.fatcaTitle;
                this.modalService.showModal(answer.action.value, {pdfSrc: answer.action.imgSrc, title: title});
                return;
            }
            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else {
                this.chatFlowAccessor.clearComponent();
                if (entity.name.length > 0 && answer.value.length > 0) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.text }
                        ]
                    });

                    // BC申し込みボタンの場合はバックアップを取ります。
                    // 申し込み確認画面でifApplyBCの値が変更される可能性があるので、申し込みチャットの選択肢を記録する必要があります
                    if (entity.name === 'ifApplyBC') {
                        this._action.setStateSubmitDataValue([
                            {
                                key: 'ifApplyBCBak',
                                value: answer.value
                            }
                        ]);
                    }
                }
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        if (entity.fullwidthHalfwidthDivisionCode) {
                            this.store.registerSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK, (data) => {
                                this.store.unregisterSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK);
                                this.getNextChat(entity.next, pageIndex);
                            });
                            const params = {
                                tabletApplyId: this._store.getState().tabletApplyId,
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                                    checkStrings: [{
                                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                        checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                    }],
                                }
                            };
                            this.action.characteCheck(params, () => {
                                this._action.editChart(entity.order, pageIndex,
                                    this.state.showChats[this.state.showChats.length - 1].answer.order);
                                this.getNextChat(entity.order, pageIndex);
                            });
                        } else {
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });
                }
            });
    }

    /**
     * パスワードコンポーネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onPasswordInput(entity: ExistingSavingsQuestionsModel, pageIndex: number, arrayPassword: string[]): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            birthday: this.state.submitData.birthdate,
            birthdayText: this.state.submitData.birthdateWithAge,
            telephone: arrayPassword,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PasswordInputComponent,
            this.footerContent, options).subscribe((answer) => {

                // 暗証番号ルール適合性チェックハンドルを追加
                // this.store.registerSignalHandler(ExistingSavingsSignal.GET_PASSWORD_RULE, (data) => {
                //     this.store.unregisterSignalHandler(ExistingSavingsSignal.GET_PASSWORD_RULE);
                //     if (data.response.values.result === '1') {
                //         const buttonList = [
                //             { text: 'OK', buttonValue: 'ok' },
                //         ];
                //         this.modalService.showAlert(
                //             this.labels.error.passwordError,
                //             null, 'icon_alert@2x.png', buttonList, 'settings-alert-modal'
                //         );
                //     } else {
                //         this.chatFlowAccessor.clearComponent();
                //         this.setAnswer(answer);
                //         this.getNextChat(entity.next, pageIndex);
                //     }
                // });

                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);

                // 暗証番号ルール適合性チェックを行う
                const param: ExistingPasswordRuleCheckInterface = {
                    path: CoreBankingConstants.ApiPathConsts.PASSWORD_RULE_CHECK,
                    tabletApplyId: this.loginStore.getState().tabletApplyId,
                    userMngNo: this.loginStore.getState().bankclerkId,
                    params: {
                        bankNo: CoreBankingConst.bankNo,
                        receptionTenban: this.state.submitData.receptionBranchNo,
                        receptionNo: this.state.submitData.receptionNo,
                        terminalNo: this.deviceService.getDeviceId(),
                        passcodeType: entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4 ?
                            COMMON_CONSTANTS.PasscodeType.password4bits : COMMON_CONSTANTS.PasscodeType.password6bits,
                        passcode: answer.value[0].value,
                        tenban: this.state.submitData.swipeBranchNo,
                        accountNo: this.state.submitData.swipeAccountNo,
                        branchCif: this.state.submitData.swipeCif,
                    }
                };
                // this._action.checkExistingCustomerPasswordRule(param);
            });
    }

    /**
     * モードダイアログを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onModal(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const pdfSrc: string = this.state.submitData.accountType === AccountType.EXISTING_SAVINGS
            ? COMMON_CONSTANTS.REGULATIONS_KIZON_FUTSUU : COMMON_CONSTANTS.REGULATIONS_KIZON_CHOCHIKU;

        this.modalService.showModal(entity.type, { pdfSrc: pdfSrc }, () => {
            this.navCtrl.setRoot(ExistingSavingsInitConfirmComponent);
        });
    }

    /**
     * ラジオボタンコンポーネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onRadioButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, RadioButtonComponent, this.footerContent, options).subscribe((answer) => {
            if (answer.action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
                this.modalService.showModal(answer.action.value, { imgSrc: answer.imgSrc });
            } else if (answer.next !== COMMON_CONSTANTS.FLOW_TYPE_NUMBER_NEXT) {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * カードコンポーネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onCard(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, CardListComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: entity.name + COMMON_CONSTANTS.ELEMENT_TYPE_IMAGE_SRC, value: answer.imgSrc }
                ]
            });
            this.getNextChat(answer.next, pageIndex);
        });
    }

    /**
     * カードコンポーネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onButtonTwoCols(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            maxColNum: 2,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.text }
                    ]
                });
                this.getNextChat(answer.next, pageIndex);
            });
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        let tempResult: any;

        if (entity.choices) {
            switch (entity.name) {
                // 名前の聴取済かにより分岐
                case 'isChangeStore': {
                    // '00'理由入力なし　'01'理由入力必要
                    const cardBranchNo = this.state.submitData.cardInfo.branchNo;
                    // 受付店以外⇒受付店に口座開設店舗を修正した場合  受付店以外⇒受付店以外へ口座開設店舗を修正した場合
                    if (!this.state.submitData.changeStoreFlg
                        || (this.state.submitData.changeStoreFlg === StoreChanged.YES && this.state.submitData.savingBranchReason)) {
                        judgeResult = '00';
                    } else if (!this.state.submitData.savingBranchReason
                        && this.state.submitData.changeStoreFlg === StoreChanged.YES) {
                        judgeResult = '01';
                    }
                    // 確認画面の修正済みを表示するため
                    this._action.setStateSubmitDataValue([{ key: 'storeChangeFlg', value: judgeResult }]);
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                // 店舗変更後、変更後の店舗によって職業を入れるかどうかを判断
                case 'ifAllIdentificationCode80': {
                    // 0　は入力必要、１　は入力要らない
                    judgeResult = '1' ;
                    const identificationCodeWithChange = InputUtils.getIdentificationCodeWithChange(this.state.submitData);
                    if (!identificationCodeWithChange
                        || identificationCodeWithChange !== IdentificationCode.CODE_80) {
                        judgeResult = '0';
                    }

                    if (identificationCodeWithChange === IdentificationCode.CODE_80) {
                        this.action.clearWorkAndCrs(ClearWorkOrCrs.WORK);
                    }

                    // 職業を入力必要（０の場合）、かつ　職業が既に存在する場合、１を設定して職業入力を省略する
                    if (judgeResult === '0' && this.state.submitData.holderCareer) {
                        judgeResult = '1';
                    }

                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                // SWIP CIFに99の先であること
                case 'ifExistIdentificationCode99': {
                    // 0　は入力要らない、１　は入力必要
                    judgeResult = '0' ;
                    const identificationCodeWithChange = InputUtils.getIdentificationCodeWithChange(this.state.submitData);
                    if (!identificationCodeWithChange
                        || identificationCodeWithChange === IdentificationCode.CODE_99) {
                        judgeResult = '1';
                    }

                    if (identificationCodeWithChange === IdentificationCode.CODE_80
                        || identificationCodeWithChange === IdentificationCode.CODE_90) {
                        this.action.clearWorkAndCrs(ClearWorkOrCrs.CRS);
                    }

                    // CRSを入力必要（1の場合）、かつ　CRSが既に存在する場合、0を設定して職業入力を省略する
                    if (judgeResult === '1' && this.state.submitData.isJapanLive) {
                        judgeResult = '0';
                    }
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                // PID配下にMD契約有無判断
                case 'ifhasMDContract': {

                    judgeResult = '0' ;
                    this.state.submitData.allCifInfos.forEach((element) => {
                        element.domesticAccountInfo.forEach((elementDomesticAccountInfo) => {
                            if (elementDomesticAccountInfo.ibContractInfo !== null &&
                                elementDomesticAccountInfo.ibContractInfo.contractCategory !== ''  &&
                                elementDomesticAccountInfo.ibContractInfo.contractCategory !== undefined) {
                                judgeResult = '1';
                           }
                        });
                    });
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }

                // 申込顧客が18歳未満判断
                case 'below18YearExist': {
                    judgeResult = '0' ;
                    this.state.submitData.allCifInfos.forEach((element) => {
                        const isBlow18 = !InputUtils.validateAge(element.birthDate, Age.Age_18,
                            this.state.submitData.tabletStartDate);
                        if  (isBlow18 === true)  {
                            judgeResult = '1';
                            this._action.setStateSubmitDataValue([{ key: 'ifApplyBC', value: '00' }]);
                        }
                    });
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                // PID配下のCIF受付チェック
                case 'bankCardApplyCheck': {

                    this.store.registerSignalHandler(ExistingSavingsSignal.BC_APPLY, (data: AcceptionResult[]) => {
                        this.store.unregisterSignalHandler(ExistingSavingsSignal.BC_APPLY);
                        tempResult = this.checkAllAcceptionResult(data);
                        if (tempResult === ReceptionStatus.YES || tempResult === ReceptionStatus.NO) {
                            judgeResult = tempResult;
                            if (judgeResult === JudgeResultStatus.RESULT_1) {
                                this._action.setStateSubmitDataValue([{ key: 'ifApplyBC', value: '00' }]);
                            }
                            this.goToNextChat(entity, judgeResult, pageIndex);
                        } else {
                            // BC受付可否チェックエラーの場合、BC申込NGとして口座開設を進める
                            this._action.setStateSubmitDataValue([{ key: 'ifApplyBC', value: '00' }]);
                            this.goToNextChat(entity, ReceptionStatus.NO, pageIndex);
                        }
                    });
                    // BC受付可否チェック実施
                    this.action.bankCardApplyCheck(this.makeAcceptCheckApiParams(BusinessCode.BC_COMPLEX_APPLY));

                    break;
                }
                // PIDのCIF配下のBC保有有無判定
                case 'ifhasBCCard': {
                    this.store.registerSignalHandler(ExistingSavingsSignal.BC_APPLY, (data: AcceptionResult[]) => {
                        this.store.unregisterSignalHandler(ExistingSavingsSignal.BC_APPLY);
                        tempResult = this.checkAllAcceptionResult(data);
                        if (tempResult === ReceptionStatus.YES || tempResult === ReceptionStatus.NO) {
                            judgeResult = tempResult;
                            if (judgeResult === JudgeResultStatus.RESULT_1) {
                                this._action.setStateSubmitDataValue([{ key: 'ifApplyBC', value: '00' }]);
                            }
                            this.goToNextChat(entity, judgeResult, pageIndex);
                        } else {
                            // BC受付可否チェックエラーの場合、エラーモーダル表示
                            this.showErrorModal(tempResult);
                        }
                    });
                    // BC受付可否チェック実施
                    this.action.bankCardApplyCheck(this.makeAcceptCheckApiParams(BusinessCode.COMMON_NG));

                    break;
                }
                // 満18歳判定
                case 'is18YearsOld': {
                    judgeResult = InputUtils.calculateAge(this.state.submitData.holderBirthdate) === Age.Age_18 ?
                        JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                // 届出変更の有無により分岐
                // case 'hasChange': {
                //     const isChanged = this.state.submitData.isNameChange || this.state.submitData.isAddressChange
                //     || this.state.submitData.isTelphoneChange;
                //     judgeResult = this.state.submitData.existingChangeFlag === '1' || isChanged ? '1' : '0';
                //     this.goToNextChat(entity, judgeResult, pageIndex);
                //     break;
                // }
                default : {
                    const choice = entity.choices.find((item) => {
                        return item.value === this.state.submitData[entity.name];
                    });
                    this.getNextChat(choice ? choice.next : entity.next, pageIndex);
                }
            }
        }
    }

    /**
     * BC受付可否チェックAPI
     * @param {*} params
     */
    public checkAllAcceptionResult(params: AcceptionResult[]) {
        for (const data of params) {
            const errorInfo = this.checkErrorCode(data);
            if (!errorInfo) {
                if (this.getBcHoldingStatus(data) === ReceptionStatus.NO) {
                    return  ReceptionStatus.NO;
                }
            } else {
                    return errorInfo;
            }
        }
        return  ReceptionStatus.YES;
    }

    /**
     * Select branch
     * @param entity entity
     * @param pageIndex pageIndex
     */
    public onSelectBranch(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxColNum: 2
        };

        // 申込画面の修正ダイアログで鉛筆によって職業、CRSが消されるケースがあるので、ここでcopySubmitDataによって入れ直す
        if (entity.name === 'restoreWorkOrCrs') {
            this._action.restoreWorkAndCrs();
        }

        this.chatFlowAccessor.addComponent(entity.type, SelectBranchComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            // 選択された支店を設定
            this._action.changeOpenStore(answer, this.state.submitData);
            // 店舗変換後に純新規になる場合は、以下のチェックします。当てはまる場合はN-005エラーを表示
            // ・変換後のcustomerIdが存在しない
            // ・&& 氏名に漢字変換不可フラグある
            if (!InputUtils.getCustomerIdWithChange(this._store.getState().submitData)
                && this._store.getState().submitData.nameNonConvert === NameNonConvert.OFF) {
                this.showErrorModalNoAudio(AgentInternalError.ERROR_CODE_N_005);
            } else {
                this.getNextChat(entity.next, pageIndex);
            }
        });
    }

    /**
     * Send request
     * @param entity entity
     * @param pageIndex pageIndex
     */
    public onRequest(entity, pageIndex) {
        if (entity.name === 'receptionCheck') {
            // 受付チェックを実施
            this.recptionCheck(entity, pageIndex);
        } else {
            const regionCode = this.state.submitData.regionCode || '';
            const params = regionCode.length > 0 ?
                { regionCode: regionCode } : {
                    prefectureKanji: this.state.submitData.holderAddressPrefecture || '',
                    city: this.state.submitData.holderAddressCountyUrbanVillage || '',
                    local: this.state.submitData.holderAddressStreetNameSelect || ''
                };
            this._action.requestDefaultAddress(params, entity, pageIndex);
        }
    }

    public onDynamicButton(entity, pageIndex) {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        const choices = [];
        let phoneNos = [];
        if (entity.name === 'selectOnePhoneNo') {
            phoneNos = this.getTelsNo(this.state.submitData).tels;
        }
        if (entity.name === 'selectOneOtherNo') {
            phoneNos = this.getTelsNo(this.state.submitData).others;
        }

        phoneNos.forEach(
            (item) => {
                choices.push({
                    text: item,
                    type: 'general',
                    value: item,
                    next: entity.next
                });
            }
        );

        this.chatFlowAccessor.addComponent(
            choices,
            ButtonGroupComponent,
            this.footerContent,
            options
        ).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value }
                ]
            });
            this.getNextChat(answer.next, pageIndex);
        });
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        } else if (action.type === 'modal' && action.value === 'modalNextChat') {
            // BankCardの紹介モーダルを表示

            const modal = this.modalCtrl.create(
                ModalBcnoticeScrollCheckComponent,
                { title: this._labels.creditcard.introduce.title,
                  pdfSrc: this._labels.creditcard.introduce.imgSrc },
                { cssClass: 'settings-modal-bank-card-all', enableBackdropDismiss: false }
            );

            modal.onDidDismiss(() => {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(choice.next, pageIndex);
            });

            modal.present();
        }
    }

    private goToNextChat(entity: ExistingSavingsQuestionsModel, judgeResult: string, pageIndex: number) {
        entity.choices.forEach((choice) => {
            if (judgeResult === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }

    /**
     * 受付可否チェックAPIリクエストに使うパラメータ
     *
     * @private
     * @returns
     * @memberof ExistingAccountChangeRenderer
     */
    private makeAcceptCheckApiParams(businessCode: string) {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((cifInfo) => {
            accounts.push({
                customerId: cifInfo.customerId,
            });
        });

        const acceptCheckApiParams = {
            tabletApplyId: this.state.submitData.tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                accounts: accounts,
                businessCode: businessCode
            }
        };

        return acceptCheckApiParams;
    }

    private checkErrorCode(acceptCheckResult: AcceptionResult) {
        let errorInfo: any;

        // 返却されたエラーコードが、受付可否チェック検出対象かを確認する。
        function isHostError(errorCode: string): boolean {
            return (Object.keys(HostErrorCodeReceptionNG).some((key) => HostErrorCodeReceptionNG[key] === errorCode));
        }

        for (const account of acceptCheckResult.accounts) {
            if (isHostError(account.errorCode)) {
                let unacceptables = '';
                for (const unacceptable of account.unacceptables) {
                    unacceptables = unacceptables + '/' + unacceptable.unacceptableCode;
                }
                unacceptables = unacceptables.substr(0, 1) === '/' ? unacceptables.substr(1) : unacceptables;
                errorInfo = {
                    errorCode: account.errorCode,
                    unacceptableCode: unacceptables
                };
            }
        }
        return errorInfo;
    }

    private getBcHoldingStatus(acceptCheckResult: AcceptionResult): string {
        let result: boolean = false;
        console.log(acceptCheckResult);
        for (const account of acceptCheckResult.accounts) {
            account.tradingConditions.forEach((tradingCondition) => {
                if (tradingCondition.tradingConditionCode === '13') {
                    result = true;
                }
            });
        }
        return result ? ReceptionStatus.NO : ReceptionStatus.YES;
    }

    private showErrorModal(errorInfo: any) {
        const errorParams = {
            imgSrc: 'icon_hourgrass@2x.png',
            message: this.labels.common.error.host.support,
            subMessage: `<span class="font-color-red">（${errorInfo.errorCode} ${errorInfo.unacceptableCode}）</span>`,
            buttonList: [{ text: 'OK', buttonValue: 'ok' }]
        };
        const errorModal = this.modalCtrl.create(
            DialogComponent, errorParams, { cssClass: 'settings-error-modal', enableBackdropDismiss: false }
        );
        this.audioService.subject.next(true);
        errorModal.present();
    }

    private showErrorModalNoAudio(errorInfo: any, callback?: any) {
        const labels = InjectionUtils.injector.get(LabelService).labels;
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            labels.common.error.host.support,
            errorInfo, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }

    private getTelsNo(submitData: any): {tels: string[], others: string[]} {
        const { holderTelNo1, holderTelNo2, holderTelNo3} = submitData;
        const tels = [];
        const others = [];
        if (holderTelNo1) {
            Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo1) ? tels.push(holderTelNo1) : others.push(holderTelNo1);
        }
        if (holderTelNo2) {
            Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo2) ? tels.push(holderTelNo2) : others.push(holderTelNo2);
        }
        if (holderTelNo3) {
            Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo3) ? tels.push(holderTelNo3) : others.push(holderTelNo3);
        }

        return {tels: tels, others: others};
    }

    private recptionCheck(entity: any, pageIndex: any) {
        const existingSavingsState = this._store.getState();

        // 店舗変換した　かつ　変換先店舗にCIF情報がある場合
        // 新いcustomerIdを使って、受付チェックを実施します
        if (existingSavingsState.submitData.changeStoreFlg === StoreChanged.YES
            && existingSavingsState.submitData.customerIdChanged) {
            const savingsStore = InjectionUtils.injector.get(SavingsStore);
            const savingsState = savingsStore.getState();
            const savingsAction = InjectionUtils.injector.get(SavingsAction);
            const loginStore = InjectionUtils.injector.get(LoginStore);

            // 受付可否チェック（喪失・破損）の実行後処理を定義
            savingsStore.registerSignalHandler(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK, () => {
                savingsStore.unregisterSignalHandler(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK);

                // 情報取得後、チェックNGの場合はエラーモーダル、チェックOKの場合は次チャットへ遷移
                if (savingsState.submitData.responseForModal) {
                    ErrorUtils.errorHandling(
                        savingsState.submitData.responseForModal,
                        savingsState.submitData.allCifInfos,
                        this.modalService, this._labels);
                } else {
                    this.getNextChat(entity.next, pageIndex);
                }
            });

            // 店舗変換後のCIF情報の顧客番号をキーに受付可否チェックを行う
            const account = {
                tenban: null,
                accountType: null,
                accountNo: null,
                customerId: existingSavingsState.submitData.customerIdChanged
            };

            // 受付可否チェック（喪失・破損）を実行
            savingsAction.receptionLossCorruptionCheck({
                tabletApplyId: Number(loginStore.getState().tabletApplyId),
                params: {
                    receptionTenban: loginStore.getState().belongToBranchNo,
                    accounts: [
                        {
                            tenban: account.tenban,
                            accountType: account.accountType,
                            accountNo: account.accountNo,
                            customerId: account.customerId
                        }
                    ],
                    // 業務コード
                    businessCode: '01'
                }
            });
        } else {
            // 店舗変換していない　まだ　変換先店舗にCIF情報がない場合
            // 次のチャットに進む、何もしない
            this.getNextChat(entity.next, pageIndex);
        }
    }

}
