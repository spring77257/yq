import {
    ComponentFactory,
    ComponentFactoryResolver, ComponentRef,
    EventEmitter,
    NgZone
} from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { AppProperties } from 'app.properties';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsSignal, ExistingSavingsStore } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ComponentProvider } from 'dhdt/branch/shared/components/component-provider';
import { Content } from 'ionic-angular';
import { Observable } from 'rxjs';

/**
 * chat flow accessor.
 */
export class ExistingSavingsChatFlowAccessor {

    protected action: ExistingSavingsAction;
    protected store: ExistingSavingsStore;

    private _chatFlowRenderer: ExistingSavingsChatFlowRenderer;

    private factory: ComponentFactory<ComponentProvider>;
    private qf: ComponentRef<ComponentProvider>;
    private componentFactoryResolver: ComponentFactoryResolver;
    private ngZone: NgZone;

    constructor(public chatFlowRenderer?: ExistingSavingsChatFlowRenderer) {

        this.action = InjectionUtils.injector.get(ExistingSavingsAction);
        this.store = InjectionUtils.injector.get(ExistingSavingsStore);
        this.componentFactoryResolver = InjectionUtils.injector.get(ComponentFactoryResolver);
        this.ngZone = InjectionUtils.injector.get(NgZone);
        this._chatFlowRenderer = chatFlowRenderer;

        this.addListioner();
    }

    /**
     * コンポネントを作成する
     * @param datas データ
     * @param from コンポネント
     * @param to コンテナー
     * @param options オプション
     */
    public addComponent(datas: any, from: any, to: any, options: any = {}): EventEmitter<any> {
        this.factory = this.componentFactoryResolver.resolveComponentFactory(from);
        this.qf = to.createComponent(this.factory);
        this.qf.instance.datas = datas;
        this.qf.instance.options = options;
        this.qf.instance.content = this._chatFlowRenderer.content;
        this.store.sendSignal(ExistingSavingsSignal.WILL_PUSH_FOOTER);
        if (this.qf.instance.refresh) {
            this.qf.instance.refresh.subscribe(() => {
                this.resize();
            });
        }
        return this.qf.instance.launch;
    }

    /**
     * コンポネントをクリアする
     */
    public clearComponent() {
        if (this.qf) {
            this.qf.destroy();
            this.store.sendSignal(ExistingSavingsSignal.WILL_DISMISS_FOOTER);
        }
    }

    /**
     * Resize view
     * Called whenever view change
     */
    public resize() {
        this._chatFlowRenderer.content.resize();
        setTimeout(() => {
            if (this._chatFlowRenderer.content && this._chatFlowRenderer.content._scroll !== null) {
                this._chatFlowRenderer.content.scrollToBottom();
            }
        }, 400);
    }

    /**
     * 画面破壊
     */
    public destroy(): void {
        this.unregisterSignal();
    }

    /**
     * コンテントを設定する
     * @param content コンテント
     */
    public setContent(content: Content) {
        this._chatFlowRenderer.content = content;
    }

    /**
     * Rendererを設定する
     * @param chatFlowRenderer
     */
    public setRenderer(chatFlowRenderer?: ExistingSavingsChatFlowRenderer) {
        this._chatFlowRenderer = chatFlowRenderer;
        this.unregisterSignal();
        this.addListioner();
    }

    /**
     * リスナーを追加する
     */
    private addListioner() {
        this.store.registerSignalHandler(ExistingSavingsSignal.GET_QUESTION, (pageIndex: number) => {
            // show first message
            this.clearComponent();
            this.action.getNextChatByAnswer(0, pageIndex);
        });
        this.store.registerSignalHandler(ExistingSavingsSignal.SEND_ANSWER, (datas) => {
            const question = datas.question;
            const pageIndex = datas.pageIndex;
            this.clearComponent();
            switch (question.type) {
                case 'text':
                case 'judge':
                case 'route':
                case 'itemList':
                case 'image': {
                    this._chatFlowRenderer.rendererComponents(question, pageIndex);
                    break;
                }
                default: {
                    Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                        this.ngZone.run(() => {
                            this._chatFlowRenderer.rendererComponents(question, pageIndex);
                        });
                    });
                }
            }
        });
    }

    /**
     * Unregister signal
     */
    private unregisterSignal() {
        this.store.unregisterSignalHandler(ExistingSavingsSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(ExistingSavingsSignal.SEND_ANSWER);
    }
}
