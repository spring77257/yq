import { ViewContainerRef } from '@angular/core';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsState } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ButtonCameraComponent } from 'dhdt/branch/shared/components/button-group/button-camera.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';

/**
 * Self Imgapply component(情報入力画面（本人確認書類聴取）_写真撮影).
 */
export class SelfImgapplyComponent extends ExistingSavingsChatFlowRenderer {

    public processType = 1;
    public options: {
        category: number
    };

    private state: ExistingSavingsState;

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private footerContent: ViewContainerRef,
    ) {
        super();
        this.state = this._store.getState();
        // this._action.setCustomerApplyStartDate();

    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-self-imgapply.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'cameraButton': {
                this.onCameraButton(question, pageIndex);
                break;
            }
        }
    }

    public onCameraButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options: any = {
            saveFrontPhotoKey: 'holderCardImageFront',
            saveBackPhotoKey: 'holderCardImageBack',
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        // 写真を取ろうする書類の格納変数の値を取得
        const currentImg = this.state.submitData[this._store.documentMap.get(this.options.category)];
        // 書類に写真が存在する場合は、skipを渡す
        if (currentImg && currentImg.length > 0 && entity.skip) {
            options.skip = entity.skip;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonCameraComponent, this.footerContent, options
            ).subscribe((answer: any) => {
            if (answer === 'skip') {
                this.setAnswer({
                    text: 'スキップ',
                    value: undefined
                });

                this.chatFlowAccessor.clearComponent();
                this.getNextChat(entity.skip, pageIndex);
            } else {
                if (answer.image) {
                    this._action.saveIdentityDocumentImage({
                        image: answer.image,
                        category: this.options.category
                    });
                }

                if (answer.chatFlowChoice.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.chatFlowChoice.next, pageIndex);
                }
            }
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                if (entity.name === 'addIdentityDocumentImg' && answer.value === '1') {
                    const choice = entity.choices ? entity.choices.find((item) => item.value === answer.value) : undefined;
                    this._action.resetLastNode({
                        order: choice ? choice.next : entity.order,
                        pageIndex: pageIndex
                    });
                } else {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.name === 'checkDocumentCategory') {
            const choice = entity.choices.find((item) => item.value === this.options.category);
            if (choice) {
                this.getNextChat(choice.next, pageIndex);
            }
        } else if (entity.name === 'checkDocumentType') {
            const choice = entity.choices.find((item) => {
                if (this.options.category === Constants.IdentityDocumentCategory.Document1) {
                    if (this.state.submitData.identificationDocument1 === Constants.MyNumberCard) {
                        return item.value;
                    }
                }
                return !item.value;
            });
            if (choice) {
                this.getNextChat(choice.next, pageIndex);
            }
        }
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }
}
