import { ViewContainerRef } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { InterruptionOfTelephone, UnacceptableCode } from 'dhdt/branch/pages/change/change-consts';
import { ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { BussinessCode, isMobileNo, JudgeResultStatus} from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import { ExistingSavingsSignal, ExistingSavingsState, ExistingSavingsStore
} from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { AcceptionResult } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { DialogComponent } from 'dhdt/branch/shared/components/dialog/dialog.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { ModalController } from 'ionic-angular';
/**
 * 普通預金 既存_普通預金口座開設 電話番号
 */
export class ExistingSavingsChangeTelRenderer extends ExistingSavingsChatFlowRenderer {

    public processType = 1;

    private state: ExistingSavingsState;
    private modalService: ModalService;
    private isMobileSkiped: boolean = false;
    private isTelSkiped: boolean = false;
    private loginStore: LoginStore;
    private loginState: LoginState;

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: ExistingSavingsStore,
        private audioService: AudioService,
        private action: ExistingSavingsAction,
        private changeUtils: ChangeUtils
    ) {
        super();
        this.state = this.store.getState();
        this.modalService = InjectionUtils.injector.get(ModalService);
        this.changeUtils = InjectionUtils.injector.get(ChangeUtils);
        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.loginState = this.loginStore.getState();
    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(COMMON_CONSTANTS.YML_CHAT_FLOW_EXISTING_SAVINGS_CHANGE_TEL, pageIndex);
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'changeContent': {
                this.onChangeContent(question, pageIndex);
                break;
            }
            case 'requestSwipeCif': {
                this.requestSwipeCifStatus(question, pageIndex);
                break;
            }
        }
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        let level;
        const changeState = InjectionUtils.injector.get(ChangeStore).getState();
        if (entity.choices) {
            switch (entity.name) {
                case 'isTelChange': {
                    judgeResult = this.state.submitData.isTelphoneChange ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                    break;
                }
                case 'telDifferenceCheck': {
                    this.action.setTelphoneDifferenceFlg(false);
                    if (this.state.submitData.isTelphoneChange) {
                        let changedHolderMobileNo: string = '';
                        let changedHolderTelephoneNo: string = '';
                        if (this.state.submitData.existingChangeFirstMobileNo) {
                            changedHolderMobileNo = this.state.submitData.existingChangeFirstMobileNo + COMMON_CONSTANTS.HALF_HYPHEN
                                + this.state.submitData.existingChangeSecondMobileNo + COMMON_CONSTANTS.HALF_HYPHEN
                                + this.state.submitData.existingChangeThirdMobileNo;
                        }
                        if (this.state.submitData.existingChangeFirstTel) {
                            changedHolderTelephoneNo = this.state.submitData.existingChangeFirstTel + COMMON_CONSTANTS.HALF_HYPHEN
                                + this.state.submitData.existingChangeSecondTel + COMMON_CONSTANTS.HALF_HYPHEN
                                + this.state.submitData.existingChangeThirdTel;
                        }
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'telDifferenceInfos',
                                value: this.changeUtils.getTelDiffInfo(this.state.submitData.allCifInfos, this.state.submitData.customerId,
                                    this.makeHolderTelList(changedHolderMobileNo, changedHolderTelephoneNo))
                            }
                        ]);
                    } else {
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'telDifferenceInfos',
                                value: this.changeUtils.getTelDiffInfo(this.state.submitData.allCifInfos, this.state.submitData.customerId,
                                    this.makeHolderTelList(this.state.submitData.holderTelNo1, this.state.submitData.holderTelNo2,
                                        this.state.submitData.holderTelNo3))
                            }
                        ]);
                    }

                    judgeResult = JudgeResultStatus.RESULT_0;
                    for (const item of this.state.submitData.telDifferenceInfos) {
                        if (item.isDifference) {
                            judgeResult = JudgeResultStatus.RESULT_1;
                            this.action.setTelphoneDifferenceFlg(true);
                            break;
                        }
                    }
                    break;
                }
                // 名寄せ先の更新予定のCIFの取引ぶりを判定(電話番号)
                case 'acceptCheckForTelDifCif': {
                    this.acceptCheckForUpdateCif(entity, pageIndex);
                    break;
                }
                // 電話番号変更&差分の有無
                case 'hasTelChangeOrDifference': {
                    judgeResult = this.state.isTelphoneDifference || this.state.submitData.isTelphoneChange ?
                        JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                    break;
                }
                // 変更有無
                case 'hasChange': {
                    judgeResult = this.state.submitData.isNameChange || this.state.submitData.isAddressChange ||
                    this.state.submitData.isTelphoneChange || this.state.isAddressDifference ||
                    this.state.isNameDifference || this.state.isTelphoneDifference ?
                        JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                    break;
                }
                // スワイプCIFの携帯電話番号の登録有無により分岐
                case 'hasMobileNo': {
                    judgeResult = this.hasMobilePhoneNumber() ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                    break;
                }
                // スワイプCIFの受付可否実行判定
                case 'isAcceptCheckForSwipeCif': {
                    judgeResult = JudgeResultStatus.RESULT_0;
                    if (!this.state.submitData.isNameChange && !this.state.submitData.isAddressChange
                        && this.state.submitData.isMobileNo === isMobileNo.hasMobileNo) {
                        // 氏名・住所どちらも[変更なし]を選択（電話番号は[変更なし]の前提） かつ
                        // 携帯電話番号未登録先で携帯電話番号を登録する場合、スワイプCIFの受付可否を実施する
                        judgeResult = JudgeResultStatus.RESULT_1;
                    }
                    break;
                }
                // スワイプCIFの取引ぶりを判定
                case 'acceptCheckForSwipeCif': {
                    judgeResult = JudgeResultStatus.RESULT_02;
                    level = this.changeUtils.getTransactionLevel(
                        this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                    // ジュニアNISA対応
                    const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(this.state.submitData.birthdate,
                        this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                    if (level.levelOne || isHaveJuniorNisa) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                    }
                    break;
                }
                // 電話番号の修正ボタンを押下したとき
                case 'isModify': {
                    judgeResult = JudgeResultStatus.RESULT_0;
                    if (changeState.submitData.pressButtonType === 'existingChangeHolderMobileNo') {
                        // 電話番号の修正ボタンを押下したとき
                        // 無条件で受付可否チェックを実行する
                        judgeResult = JudgeResultStatus.RESULT_1;
                    }
                    break;
                }
                // 電話番号不通
                case 'isNonCall': {
                    judgeResult = this.state.submitData.interruptionOfTelephone === InterruptionOfTelephone.ON ?
                        JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                    break;
                }
                // 電話不通有先で電話番号変更する場合、スワイプCIFの受付可否チェック必要かないか
                // 氏名・住所変更なし（電話番号は[変更なし]の前提）の場合、受付可否チェックを実施
                case 'needAcceptCheckForSwipeCif': {
                    judgeResult = !this.state.submitData.isNameChange && !this.state.submitData.isAddressChange ?
                        JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                    break;
                }
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        }
    }

    public onNumberKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    const isShowModal = this.telSkip(entity.name, answer === COMMON_CONSTANTS.SIGN_SKIP);
                    if (!isShowModal) {
                        this.action.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                        if (entity.name === COMMON_CONSTANTS.EXISTING_HOLDER_MOBILE_NO) {
                            this.action.setStateSubmitDataValue([{key: 'existingChangeHolderMobileNo', value: '' }]);
                            this.action.setStateSubmitDataValue([{key: 'existingChangeFirstMobileNo', value: '' }]);
                            this.action.setStateSubmitDataValue([{key: 'existingChangeSecondMobileNo', value: '' }]);
                            this.action.setStateSubmitDataValue([{key: 'existingChangeThirdMobileNo', value: '' }]);
                            // 携帯電話番号をスキップするときに、「ショートメッセージ」受信フラグをクリアする
                            this.action.setStateSubmitDataValue([{key: 'isSmsPhone', value: undefined }]);
                        }
                        if (entity.name === COMMON_CONSTANTS.EXISTING_HOLDER_TEL_NO) {
                            this.action.setStateSubmitDataValue([{key: 'existingChangeHolderTelephoneNo', value: '' }]);
                            this.action.setStateSubmitDataValue([{key: 'existingChangeFirstTel', value: '' }]);
                            this.action.setStateSubmitDataValue([{key: 'existingChangeSecondTel', value: '' }]);
                            this.action.setStateSubmitDataValue([{key: 'existingChangeThirdTel', value: '' }]);
                        }
                        this.getNextChat(entity.skip, pageIndex);
                    }
                } else {
                    if (entity.name === COMMON_CONSTANTS.EXISTING_HOLDER_MOBILE_NO && this.isMobileSkiped) {
                        this.isMobileSkiped = false;
                    }
                    this.action.setAnswer({
                        text: answer.text,
                        value: answer.value
                    });
                    this.action.setStateSubmitDataValue([{key: entity.name, value: answer.text}]);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                if (entity.name !== 'nextButton' && answer.action.type !== 'modal') {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }
                if (entity.name === 'changeNonCallPhoneNumber') {
                    let telChangeFlg: boolean = false;
                    if (answer.name === 'doChange') {
                        // 電話不通有先で電話番号変更する場合、電話番号変更フラグをオンに更新する。
                        telChangeFlg = true;
                    }
                    this.action.setStateSubmitDataValue([{
                        key: 'isTelphoneChange',
                        value: telChangeFlg
                    }]);
                }
                if (entity.name === 'isMobileNo') {
                    let telphoneChangeFlg: boolean = false;
                    if (answer.value === isMobileNo.hasMobileNo) {
                        // 携帯電話番号未登録先で携帯電話番号登録する場合、電話番号変更フラグをオンに更新する。
                        telphoneChangeFlg = true;
                    }
                    this.action.setStateSubmitDataValue([{key: 'isTelphoneChange', value: telphoneChangeFlg }]);
                }
            }
            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else {
                this.chatFlowAccessor.clearComponent();
                if (entity.name !== 'nextButton' && answer.action.type !== 'modal') {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.text }
                        ]
                    });
                }
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * 固定値を保存する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSaveSubmit(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            this.action.setStateSubmitDataValue(entity.choices);
            this.getNextChat(entity.next, pageIndex);
        }
    }

    public onChangeContent(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        this.getNextChat(entity.next, pageIndex);
    }

    /**
     * Request customer status
     * @param entity entity
     */
    public requestSwipeCifStatus(entity: ExistingSavingsQuestionsModel, pageIndex: number) {

        // スワイプCIFの受付可否チェック
        const params = {
            receptionTenban: this.loginState.belongToBranchNo,    // 受付店番
            accounts: [{
                customerId: this.state.submitData.customerId    // 顧客番号
            }], // 口座情報
            businessCode: BussinessCode.ADDRESS_TEL_MENU_CHANGE, // 業務コード
        };
        const dict = {
            tabletApplyId: this.state.tabletApplyId,
            params: params,
        };

        this.store.registerSignalHandler(ExistingSavingsSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
            // 事故取引禁止注意エラーの場合、注意コードを取得の上エラーモーダルを表示する
            this.store.unregisterSignalHandler(ExistingSavingsSignal.UNACCEPTABLES_NG);
            const errorInfo = this.checkErrorCode(response.errors.data);
            this.showErrorModal(errorInfo);
        });

        this.store.registerSignalHandler(ExistingSavingsSignal.ACCEPT_CHECK_SWIPE_CIF, () => {
            this.store.unregisterSignalHandler(ExistingSavingsSignal.ACCEPT_CHECK_SWIPE_CIF);
            this.getNextChat(entity.next, pageIndex);
        });

        this.action.acceptCheckForSwipeCif(entity, dict);
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.chatFlowCompelete(action.value);
        } else if (action.type === 'modal' && action.value === 'noticeButtonModal') {
            // 印鑑レスの紹介モーダルを表示
            this.modalService.showModal('noticeButtonModal', { imgSrc: COMMON_CONSTANTS.REGULATIONS_KOUZA_TOKUCHOU });
        }
    }

    // if both mobile and tel are skiped , modal shows
    private telSkip(name: string, isSkip: boolean): boolean {
        if (name === COMMON_CONSTANTS.EXISTING_HOLDER_MOBILE_NO) {
            this.isMobileSkiped = isSkip;
            this.isTelSkiped = false;
        }
        if (name === COMMON_CONSTANTS.EXISTING_HOLDER_TEL_NO) {
            this.isTelSkiped = isSkip;
        }
        if (this.isMobileSkiped === true && this.isTelSkiped === true) {
            const buttonList = [
                { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
            ];
            const modalService = InjectionUtils.injector.get(ModalService);
            modalService.showWarnAlert(
                this.labels.alert.warnTelTitle,
                buttonList, () => {
                    this.action.needInputPhoenNo();
                }
            );
            return true;
        }
        return false;
    }

    private makeHolderTelList(telNo1: string, telNo2: string, telNo3?: string) {
        const holderTelList = [];
        if (telNo1) {
            holderTelList.push(telNo1);
        }
        if (telNo2) {
            holderTelList.push(telNo2);
        }
        if (telNo3) {
            holderTelList.push(telNo3);
        }
        return holderTelList;
    }

    /*
    * typeがjudgeの際に、分岐して次のチャットを開始させる
    *
    * @param entity
    * @param pageIndex
    * @param judgeResult
    */
    private nextChatByJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number, judgeResult: string) {
        entity.choices.forEach((choice) => {
            if (choice.value === judgeResult) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }

    private acceptCheckForUpdateCif(entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        // 名寄せの電話番号更新対象に対して受付可否チェック実施
        this.action.acceptCheckForTelDifCif(this.makeAcceptCheckApiParams(), this.state.submitData.telDifferenceInfos);

        let judgeResult;
        let level;

        this.store.registerSignalHandler(ExistingSavingsSignal.ACCEPT_TARGET_FOR_TEL_DIF_CIF, (acceptCheckResult: AcceptionResult) => {
            this.store.unregisterSignalHandler(ExistingSavingsSignal.ACCEPT_TARGET_FOR_TEL_DIF_CIF);
            const errMessageArr: Array<{customerId: string, message: string}> = [];
            // レスポンスパラメータの中に、受付可否チェック検出対象がいたら離脱
            for (const item of this.state.submitData.nameidentiTelDifCifAcceptCheckResult) {
                let branchCode: string = '';
                for (const cifInfo of this.state.submitData.allCifInfos) {
                    if (item.customerId === cifInfo.customerId && this.changeUtils.isHostError(item.accounts.errorCode)) {
                        branchCode = cifInfo.customerManagementBranchCode;
                        if (item.accounts.unacceptables && item.accounts.unacceptables.length > 0) {
                            // 受付不可情報がある場合、表示メッセージは「エラー理由 ＋ 事故・取引禁止・注意コード」。
                            for (const acceptItem of item.accounts.unacceptables) {
                                errMessageArr.push({customerId: cifInfo.customerId, message: branchCode + COMMON_CONSTANTS.FULL_COLON
                                    + item.accounts.errorCode + COMMON_CONSTANTS.SPACE + acceptItem.unacceptableCode});
                            }
                        } else {
                            // 受付不可情報がない場合、表示メッセージは「エラー理由」のみ。
                            errMessageArr.push({customerId: cifInfo.customerId, message: branchCode
                                + COMMON_CONSTANTS.FULL_COLON + item.accounts.errorCode});
                        }
                    }
                }
            }
            const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
            let index = 0;
            let isNeedBr = 1;
            let message: string = '';
            let messageBefore: {customerId: string, message: string} = {customerId: undefined, message: undefined};
            if (errMessageArr.length > 0) {
                for (const err of errMessageArr) {
                    if (index === 0) {
                        message = err.message;
                    } else if (messageBefore.customerId === err.customerId &&  maxArr > isNeedBr) {
                        isNeedBr++;
                        message = message + COMMON_CONSTANTS.SLASH + err.message.substring(err.message.length - 3);
                    } else {
                        isNeedBr = 1;
                        message = message + COMMON_CONSTANTS.NEW_LINE + err.message;
                    }
                    index++;
                    messageBefore = err;
                }
                this.showErrorModal(message);
                return;
            }
            judgeResult = JudgeResultStatus.RESULT_02;
            if (this.state.submitData.nameidentiTelDifCifAcceptCheckResult) {
                this.state.submitData.nameidentiTelDifCifAcceptCheckResult.forEach((acceptResult) => {
                    // ジュニアNISA対応
                    const cifInfo =
                        this.state.submitData.allCifInfos.filter((item) => item.customerId === acceptResult.customerId);
                    const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(cifInfo[0].birthDate,
                        acceptResult.accounts.tradingConditions);
                    level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                    if (level.levelOne || isHaveJuniorNisa) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                    }
                });
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        });
    }

    /**
     * 受付可否チェックパラメータ生成
     */
    private makeAcceptCheckApiParams() {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((element) => {
            this.state.submitData.telDifferenceInfos.forEach((difItem) => {
                if (element.customerId !== this.state.submitData.customerId &&
                    element.customerId === difItem.customerId && difItem.isDifference) {
                    accounts.push({
                        customerId: element.customerId
                    });
                }
            });
        });

        const acceptCheckApiParams = {
            tabletApplyId: this.state.tabletApplyId,
            params: {
                receptionTenban: this.loginState.belongToBranchNo,
                accounts: accounts,
                businessCode: BussinessCode.ADDRESS_TEL_MENU_CHANGE,
            }
        };

        return acceptCheckApiParams;
    }

    private showErrorModal(errorCode: string, callback?: any) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            this.labels.common.error.host.support,
            errorCode, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }

    private hasMobilePhoneNumber(): boolean {
        const { holderTelNo1, holderTelNo2, holderTelNo3,
                existingChangeFirstMobileNo, existingChangeSecondMobileNo, existingChangeThirdMobileNo } = this.state.submitData;

        if (existingChangeFirstMobileNo && existingChangeSecondMobileNo && existingChangeThirdMobileNo) {
            return true;
        }
        if (holderTelNo1 && /^(090|080|070)[0-9-]+/.test(holderTelNo1)) {
            return true;
        }
        if (holderTelNo2 && /^(090|080|070)[0-9-]+/.test(holderTelNo2)) {
            return true;
        }
        if (holderTelNo3 && /^(090|080|070)[0-9-]+/.test(holderTelNo3)) {
            return true;
        }

        return false;
    }

    /**
     * スワイプCIF専用のエラーメッセージ作成処理
     */
    private checkErrorCode(acceptCheckResult: AcceptionResult) {
        let errorInfo: any;
        let isNeedBr = 1;
        let index = 0;
        const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        for (const account of acceptCheckResult.accounts) {
            if (this.changeUtils.isHostError(account.errorCode)) {
                let unacceptables = '';
                const swipeCifInfo =
                    this.state.submitData.allCifInfos.filter((cifInfo: CifInfo) => cifInfo.customerId === this.state.submitData.customerId);
                errorInfo = swipeCifInfo[0].customerManagementBranchCode + COMMON_CONSTANTS.FULL_COLON + account.errorCode;

                for (const unacceptable of account.unacceptables) {
                    unacceptables = unacceptable.unacceptableCode;
                    if (index === 0) {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SPACE + unacceptables;
                    } else if (isNeedBr > maxArr) {
                        // 1行に最大3つの注意コードを表示する
                        // 超える場合は改行して店番＋エラー情報＋注意コードを表示する
                        errorInfo = errorInfo + COMMON_CONSTANTS.NEW_LINE + errorInfo.slice(0, 14) + unacceptables;
                        isNeedBr = 1;
                    } else {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SLASH + unacceptables;
                    }
                    index++;
                    isNeedBr++;
                }
            }
        }
        return errorInfo;
    }
}
