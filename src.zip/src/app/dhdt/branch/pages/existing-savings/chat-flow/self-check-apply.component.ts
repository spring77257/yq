import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import {
    AccountType, ApplyBC, ChatOption, COMMON_CONSTANTS, Constants, HasDriversCareerLicense,
    IdentificationCode, IdentityDocumentType, IsModifyJudge
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { ExistingSavingsState } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';

/**
 * Self Check apply component(情報入力画面（本人確認書類聴取）_OCR読取有無).
 */
export class SelfCheckApplyComponent extends ExistingSavingsChatFlowRenderer {

    public processType = 1;

    private state: ExistingSavingsState;

    private backupDataService: BackupDataService;
    private serverInfoService: ServerInfoService;
    private swipedCifKanaNameDiffFlg: boolean;
    private kanaNameDiffInfos: any[];

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private changeUtils: ChangeUtils,
    ) {
        super();
        this.state = this._store.getState();
        // this._action.setCustomerApplyStartDate();
        this.backupDataService = InjectionUtils.injector.get(BackupDataService);
        this.serverInfoService = InjectionUtils.injector.get(ServerInfoService);
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-self-checkapply.yml', pageIndex);
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'datepicker': {
                this.onPicker(question, pageIndex);
                break;
            }
        }
    }

    /**
     * ピッカーコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onPicker(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }
        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData,
            value: undefined
        };

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this._action.setStateSubmitDataValue([{
                    key: IdentityDocumentType.AGENT_IDENTITY_DOCUMENT_EXPIRY_DATE,
                    value: answer.value[0].value
                }]);
                this._action.setStateSubmitDataValue([{
                    key: IdentityDocumentType.AGENT_IDENTITY_DOCUMENT_EXPIRY_DATE + 'Text',
                    value: answer.text
                }]);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            options.furiganaOnly = ChatOption.VALIDATION_ON;
            options.kanaText = this.backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                    ]
                });

                if (/identificationDocument\d/.test(entity.name)) {
                    this._action.setStateSubmitDataValue([{
                        key: entity.name + 'Text',
                        value: answer.text
                    }]);
                }
            }
            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                if (answer.name === 'backToRelateChat') {
                    this._action.gobackRelateChat();
                }
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const choices = InputUtils.changeValidationRuleMax(entity, this.state.submitData);

        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    this.getNextChat(entity.next, pageIndex);
                });
            });
    }

    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        if (entity.option === 'url') {
            this.serverInfoService.getInfoFormServe(entity.name).subscribe((result) => {
                entity.choices.forEach((choice) => {
                    if (result === choice.value) {
                        this.getNextChat(choice.next, pageIndex);
                        return;
                    }
                });
            });
        } else if (entity.choices) {
            switch (entity.name) {
                case 'ifAllIdentificationCode80or90': {
                    judgeResult = '1';
                    if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
                        // 「BC申込なし」かつ「PID配下CIFの本人確認コードが全て"80or90"である」場合、'1'
                        // 「BC申込あり」または「PID配下CIFの本人確認コードに"80/90"以外が1件以上存在する」場合、'0'
                        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
                            judgeResult = '0';
                        } else {
                            const identificationCodeWithChange = InputUtils.getIdentificationCodeWithChange(this.state.submitData);
                            if (identificationCodeWithChange !== IdentificationCode.CODE_80 &&
                                identificationCodeWithChange !== IdentificationCode.CODE_90) {
                                judgeResult = '0';
                            }
                        }
                    } else if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT) {
                        judgeResult = '0';
                    }
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                case 'ifAllIdentificationCode99ForFontCheckAndExpiryDate': {
                    judgeResult = '0';
                    if (InputUtils.getIdentificationCodeWithChange(this.state.submitData) !== IdentificationCode.CODE_99) {
                        judgeResult = '1';
                    }
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                case 'HasDriversCareerLicenseChatControl': {
                    judgeResult = '0';
                    // 修正チャットかつ運転経歴証明書選択の場合、書類選択のチャットをスキップさせる
                    if (this.state.submitData.isModify === IsModifyJudge.IsModify
                        && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES) {
                        judgeResult = '1';
                    }
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                case 'isNeedIssueCashCard': {
                    judgeResult = this.changeUtils.isNeedIssueCashCard(this.state.isNameDifference, this.state.submitData) ?
                    '01' : '02';
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                case 'isExpiryDateExists': {
                    judgeResult = '0';
                    // 修正チャットかつ、書類1の有効期限なしのとき、有効期限確認チャットを表示せず必須入力させる
                    if (this.state.submitData.isModify === IsModifyJudge.IsModify
                        && this.state.modifyExpiryDateExists) {
                        judgeResult = '1';
                    }
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }

                default:
                    const choice = entity.choices.find((item) => this.state.submitData[entity.name] === item.value);
                    this.getNextChat(choice ? choice.next : entity.next, pageIndex);
                    break;
            }
        }
    }

    private goToNextChat(entity: ExistingSavingsQuestionsModel, judgeResult: string, pageIndex: number) {
        entity.choices.forEach((choice) => {
            if (judgeResult === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_RETURN_TO_CHAT) {
            this.chatFlowReturn(action.value);
        }
    }
}
