import {
    AfterViewChecked, animate, ChangeDetectorRef,
    Component, ElementRef, OnDestroy, OnInit,
    state, style, transition, trigger, ViewChild, ViewContainerRef
} from '@angular/core';
import { BaseComponent } from 'adep/components';
import { LabelService } from 'adep/services';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import { Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import {
    ExistingSavingsChangeAddCheckRenderer
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-change-add-check.render';
import {
    ExistingSavingsChangeAddressRenderer
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-change-address.renderer';
import {
    ExistingSavingsChangeDocumentConfirmRenderer
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-change-document-confirm.renderer';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsPurposeRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-purpose.renderer';
import {
    ExistingSavingsChangeModifyRenderer
} from 'dhdt/branch/pages/existing-savings/confirm/existing-savings-change-modify.renderer';
import {
    ExistingSavingsSignal, ExistingSavingsState, ExistingSavingsStore
} from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { NameBasedAggregationService } from 'dhdt/branch/shared/services/name-based-aggregation.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { App, Content, ModalController, NavController, NavParams, ViewController} from 'ionic-angular';
import { Observable } from 'rxjs/Observable';
import { ExistingSavingsChangeDifferencialConfirmationRenderer } from './existing-savings-change-diffierencial-confirmation.renderer';

@Component({
    selector: 'existing-savings-confirmpage-chat-component',
    templateUrl: 'existing-savings-chat.component.html',
    animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateY(0)' })),
            state('out', style({ transform: 'translateY(0)' })),
            transition('out => in', [
                style({ transform: 'translateY(100%)' }),
                animate('0.3s  ease-in')
            ]),
            transition('in => out', [
                style({ transform: 'translateY(-100%)' }),
                animate('0.3s  ease-in')
            ])
        ])
    ]
})

/**
 * control all chat page.
 */
export class ExistingSavingsConfirmPageChatComponent extends BaseComponent implements AfterViewChecked, OnInit, OnDestroy {
    @ViewChild(Content) public content: Content;
    @ViewChild('footerContent', { read: ViewContainerRef }) public footerContent: ViewContainerRef;
    @ViewChild('topBlockView', { read: ElementRef }) public topBlockView: ElementRef;
    @ViewChild('bottomBlockView', { read: ElementRef }) public bottomBlockView: ElementRef;

    public chatFlowAccessor: ExistingSavingsChatFlowAccessor;
    public state: ExistingSavingsState;
    // is current page
    public isCurrentPage: boolean;
    public currentTitle: string;
    public needPassword: boolean = true;
    public footerState = 'out';

    private currentPageComponent: ExistingSavingsChatFlowRenderer;
    private currentPageIndex: number;
    private pageComponentList: ExistingSavingsChatFlowRenderer[];

    private startOrder: number;
    private endOrder: number;
    private name: string = '';

    private originShowChats: any[];
    private originShowConfirm: any[];

    constructor(
        private store: ExistingSavingsStore,
        private action: ExistingSavingsAction,
        private modalService: ModalService,
        private audioService: AudioService,
        private navCtrl: NavController,
        public changeDetectorRef: ChangeDetectorRef,
        private params: NavParams,
        private loginStore: LoginStore,
        private deviceService: DeviceService,
        private modalCtrl: ModalController,
        private editService: EditService,
        private changeUtils: ChangeUtils,
        public viewCtrl: ViewController,
        private labelService: LabelService,
        private app: App,
        private nameBasedAggregationService: NameBasedAggregationService) {
        super();
        this.pageComponentList = [];
        this.state = this.store.getState();
        this.chatFlowAccessor = new ExistingSavingsChatFlowAccessor();
        this.originShowChats = [...this.state.showChats];
        this.originShowConfirm = [...this.state.showConfirm];

    }

    public ngOnInit() {

        let fromInitForm = false;
        Object.keys(this.params.data).forEach((element) => {
             if (element === 'isCurrentPage') {
                 fromInitForm = true;
             }
        });

        if (fromInitForm) {
            this.currentTitle = this.params.get('isCurrentPage') ? this.params.get('currentTitle') : '';
            this.startOrder = this.params.get('startOrder');
            this.endOrder = this.params.get('endOrder');
            this.currentPageIndex = this.params.get('pageIndex');
        }  else if (this.params.data.params.currentTitle) {
            this.currentTitle = this.params.data.params.currentTitle;
            this.startOrder = this.params.data.params.startOrder;
            this.endOrder = this.params.data.params.endOrder;
            this.currentPageIndex = this.params.data.params.pageIndex;
            this.name = this.params.data.params.name;
        }
        this.isCurrentPage = true;
        this.needPassword = this.params.get('needPassword') ? false : true;
        this.initializeChatComponent();
        this.action.differenceFlgBackup();
        this.setModifyFlg();
        this.initData();

        this.store.registerSignalHandler(ExistingSavingsSignal.CHAT_FLOW_COMPELETE, (next) => {
            const { name, options } = next;
            if (name === 'backToTopConfirm') {
                Observable.timer(Constants.ZERO).subscribe(() => {
                    this.app.getRootNav().setRoot(TopComponent).then(() => {
                        this.viewCtrl.dismiss(undefined, undefined, { animate: false });
                    });
                    this.chatFlowAccessor.clearComponent();
                });
            }
        });
    }

    public ngOnDestroy() {
        this.chatFlowAccessor.destroy();
        this.store.unregisterSignalHandler(ExistingSavingsSignal.CHAT_FLOW_COMPELETE);
        this.action.resetShowChats(this.originShowChats);
    }

    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    /**
     * Called when alert show
     */
    public beforeAlert() {
        this.chatFlowAccessor.clearComponent();
    }

    /**
     * Called when alert dismiss
     * deprecated
     */
    public afterAlert() {
        const lastNode = this.state.showChats[this.state.showChats.length - 1];
        this.action.resetLastNode({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    /**
     * button click CallBack
     * @param order messageのorder
     * @param pageIndex messageのpageIndex
     * @param answerOrder 応答順
     */
    public editCallBack(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.editService.startEdit();
        this.beforeAlert();
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.editBtn, buttonValue: 'edit' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.editTitle,
            buttonList,
            (item) => {
                const preventedItem = this.editService.endEdit();
                if (item.buttonValue === 'edit') {
                    this.action.editChart(order, pageIndex, answerOrder, orderIndex);
                    this.chatFlowAccessor.clearComponent();
                    this.currentPageIndex = pageIndex;
                    this.currentPageComponent = this.getPageComponent(pageIndex);
                    this.getNextAnswer(order, pageIndex);
                    const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
                    this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
                } else {
                    if (preventedItem) {
                        this.getNextAnswer(preventedItem.order, preventedItem.pageIndex);
                    } else {
                        this.afterAlert();
                    }
                }
            },
            this.labels.alert.editSubTitle
        );
    }

    /**
     * get headerTitle
     */
    public get headerTitle(): string {
        return this.labels.cashcard.title;
    }

    /**
     * get processType
     */
    public get processType(): number {
        return this.currentPageComponent.processType;
    }

    /**
     * header cancel button click
     */
    public handleCancelClickEmitter(value) {
        switch (this.name) {
            case 'existingChangeHolderName':
                this.action.setNameDifferenceFlg(this.state.isNameDifferenceBackup);
                break;
            case 'existingChangeHolderAddress':
                this.action.setAddressDifferenceFlg(this.state.isAddressDifferenceBackup);
                break;
            case 'existingChangeHolderMobileNo':
                this.action.setTelphoneDifferenceFlg(this.state.isTelphoneDifferenceBackup);
                break;
            default:
                break;
        }
        this.action.resetShowConfirm(this.originShowConfirm);
        this.action.resetSubmitData();
        this.viewCtrl.dismiss(value);
    }

    private initializeChatComponent() {
        this.action.submitDataBackup();
        this.action.clearShowChats();
        if (this.currentPageIndex === 99) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, 'CashCardConfirmPageComponent');
        } else if (this.currentPageIndex === 98 || this.currentPageIndex === 93) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex,
                'ExistingSavingsChangeDifferencialConfirmationComponent');
        } else if (this.currentPageIndex === 97) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, 'ExistingSavingsChangeDocumentConfirmComponent');
        } else if (this.currentPageIndex === 96) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, 'ExistingSavingsChangeAddCheckComponent');
        } else if (this.currentPageIndex === 95) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, 'ExistingSavingsChangeNameComponent');
        } else if (this.currentPageIndex === 94) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, 'ExistingSavingsChangeAddressComponent');
        }
        this.getNextAnswer(this.startOrder, this.currentPageIndex);
    }

    /**
     * 次のノードを取得する
     * @param order メッセージの番号
     * @param pageIndex ページ番号
     */
    private getNextAnswer(order: number, pageIndex: number) {
        if (this.startOrder != null && this.endOrder != null && (order > this.endOrder || order < 0)) {
            if (this.currentPageIndex === 99) {
                this.viewCtrl.dismiss();
                return;
            } else if (this.currentPageIndex === 97) {
                this.viewCtrl.dismiss(this.state);
                return;
            } else {
                this.viewCtrl.dismiss(this.state.submitData);
                return;
            }
        }

        Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
            this.action.getNextChatByAnswer(order, pageIndex);
        });
    }

    /**
     * コンポーネントタイプにより、各レンダラをマッピング
     * @param componentType コンポーネントタイプ
     */
    private mappingComponentList(componentType: string): ExistingSavingsChatFlowRenderer {
        let render: ExistingSavingsChatFlowRenderer;
        if (componentType === 'CashCardConfirmPageComponent' || componentType === undefined) {
            render = new ExistingSavingsPurposeRenderer(this.chatFlowAccessor, this.footerContent, this.store, this.modalService,
                this.modalCtrl, this.deviceService, this.loginStore, this.navCtrl, this.action, this.audioService,
                this.nameBasedAggregationService);
        } else if (componentType === 'ExistingSavingsChangeModifyComponent' || componentType === undefined) {
            render = new ExistingSavingsChangeModifyRenderer(this.chatFlowAccessor, this.footerContent,
                this.store, this.audioService, this.action);
        } else if (componentType === 'ExistingSavingsChangeDocumentConfirmComponent' || componentType === undefined) {
            render = new ExistingSavingsChangeDocumentConfirmRenderer(this.chatFlowAccessor, this.footerContent,
                this.store, this.audioService, this.action, this.changeUtils, this.navCtrl);
        } else if (componentType === 'ExistingSavingsChangeAddCheckComponent' || componentType === undefined) {
            render = new ExistingSavingsChangeAddCheckRenderer(this.chatFlowAccessor, this.action, this.store, this.footerContent);
        } else if (componentType === 'ExistingSavingsChangeAddressComponent' || componentType === undefined) {
            render = new ExistingSavingsChangeAddressRenderer(this.chatFlowAccessor, this.footerContent,
                this.store, this.audioService, this.action, this.changeUtils);
        } else if (componentType === 'ExistingSavingsChangeDifferencialConfirmationComponent' || componentType === undefined) {
            render = new ExistingSavingsChangeDifferencialConfirmationRenderer(this.chatFlowAccessor, this.footerContent,
                this.store, this.audioService, this.action, this.changeUtils);
        }
        return render;
    }

    /**
     * Get page component
     * @param pageIndex ページ番号
     * @param componentType コンポーネントタイプ
     */
    private getPageComponent(pageIndex: number, componentType?: string): ExistingSavingsChatFlowRenderer {
        if (this.pageComponentList[pageIndex] == null) {
            this.pageComponentList[pageIndex] = this.mappingComponentList(componentType);
            this.pageComponentList[pageIndex].nextChatEvent.subscribe((params) => {
                this.getNextAnswer(params.order, params.pageIndex);
            });
        }

        this.topBlockView.nativeElement.style.height = '0';

        if (this.chatFlowAccessor) {
            this.chatFlowAccessor.setRenderer(this.pageComponentList[pageIndex]);
            this.chatFlowAccessor.setContent(this.content);
        }
        return this.pageComponentList[pageIndex];
    }

    private setModifyFlg() {
        if (this.name === 'savingAccountPassword' || this.name === 'savingsDepositAccountPassword') {
            this.action.setStateSubmitDataValue([{ key: 'isOneSetCardModify', value: true }]);
        } else if (this.name === 'addCheckConfirmation') {
            this.action.setStateSubmitDataValue([{ key: 'isAddCheckModify', value: true }]);
        } else {
            this.action.setStateSubmitDataValue([{ key: 'isModify', value: true }]);
        }
    }

    /**
     * 変更後のデータをクリア、フラグを立てる
     */
    private initData() {
        switch (this.name) {
            case 'existingChangeHolderName':
                this.action.clearHolderName();
                this.action.setStateSubmitDataValue([{ key: 'isNameChange', value: true }]);
                this.action.setStateSubmitDataValue([{ key: 'nameDifferenceInfos', value: undefined }]);
                this.action.setStateSubmitDataValue([{ key: 'nameidentiNameDifCifAcceptCheckResult', value: undefined }]);
                this.action.setNameDifferenceFlg(false);
                break;
            case 'existingChangeHolderAddress':
                this.action.clearHolderAddress();
                this.action.setStateSubmitDataValue([{ key: 'isAddressChange', value: true }]);
                this.action.setStateSubmitDataValue([{ key: 'addressDifferenceInfos', value: undefined }]);
                this.action.setStateSubmitDataValue([{ key: 'nameidentiAddressDifCifAcceptCheckRestlt', value: undefined }]);
                this.action.setAddressDifferenceFlg(false);
                break;
            case 'existingChangeHolderMobileNo':
                this.action.clearHolderPhoneNo();
                this.action.setStateSubmitDataValue([{ key: 'isTelphoneChange', value: true }]);
                this.action.setStateSubmitDataValue([{ key: 'telDifferenceInfos', value: undefined }]);
                this.action.setStateSubmitDataValue([{ key: 'nameidentiTelDifCifAcceptCheckResult', value: undefined }]);
                this.action.setTelphoneDifferenceFlg(false);
                break;
            case 'addCheckConfirmation':
                this.action.clearAddCheckData();
                break;
            default:
                break;
        }
    }
}
