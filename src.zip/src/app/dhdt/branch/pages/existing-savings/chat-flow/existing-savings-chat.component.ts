import {
    AfterViewChecked, animate, ChangeDetectorRef,
    Component, ElementRef, OnDestroy, OnInit,
    state, style, transition, trigger, ViewChild, ViewContainerRef
} from '@angular/core';
import { BaseComponent } from 'adep/components';
import { LabelService } from 'adep/services';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    AccountType,
    ApplyBC, ChatFlowChoicesValue, COMMON_CONSTANTS,
    Constants,
    CoreBankingConst,
    HasDriversCareerLicense,
    HasLicense
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import {
    ExistingSavingsBranchConfirmRenderer
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-branch-confirm.renderer';
import {
    ExistingSavingsChangeAddCheckRenderer
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-change-add-check.render';
import {
    ExistingSavingsChangeAddressRenderer
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-change-address.renderer';
import {
    ExistingSavingsChangeDifferencialConfirmationRenderer
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-change-diffierencial-confirmation.renderer';
import {
    ExistingSavingsChangeDocumentConfirmRenderer
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-change-document-confirm.renderer';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import {
    ExistingSavingsCreditcardDocumentConfirmRenderer
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-creditcard-document-confirm.renderer';
import {
    ExistingSavingsCreditCardStuffConfirmRenderer
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-creditcard-stuff-confirm.renderer';
import { ExistingSavingsPurposeRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-purpose.renderer';
import {
    ExistingSavingsVerificationRenderer
} from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-verification.renderer';
import { SelfAddressIdentification } from 'dhdt/branch/pages/existing-savings/chat-flow/self-address-identification.component';
import { SelfCheckApplyComponent } from 'dhdt/branch/pages/existing-savings/chat-flow/self-check-apply.component';
import { SelfIdentificationDocumentOne } from 'dhdt/branch/pages/existing-savings/chat-flow/self-identification-documentOne.component';
import { SelfIdentificationDocumentTwo } from 'dhdt/branch/pages/existing-savings/chat-flow/self-identification-documentTwo.component';
import { SelfImgapplyComponent } from 'dhdt/branch/pages/existing-savings/chat-flow/self-imgapply.component';
import {
    ExistingSavingsSignal, ExistingSavingsState, ExistingSavingsStore
} from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import {
    AccountModalPasswordComponent
} from 'dhdt/branch/shared/components/modal/modal-password/view/account-modal-password.component';
import { AccountBalanceInquiryInterface } from 'dhdt/branch/shared/interface/account-balance-inquiry.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { CardService } from 'dhdt/branch/shared/services/card.service';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { LicenseService } from 'dhdt/branch/shared/services/license.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { NameBasedAggregationService } from 'dhdt/branch/shared/services/name-based-aggregation.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { App, Content, ModalController, NavController, NavParams, ViewController } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';

@Component({
    selector: 'existing-savings-chat-component',
    templateUrl: 'existing-savings-chat.component.html',
    animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateY(0)' })),
            state('out', style({ transform: 'translateY(0)' })),
            transition('out => in', [
                style({ transform: 'translateY(100%)' }),
                animate('0.3s  ease-in')
            ]),
            transition('in => out', [
                style({ transform: 'translateY(-100%)' }),
                animate('0.3s  ease-in')
            ])
        ])
    ]
})

/**
 * control all chat page.
 */
export class ExistingSavingsChatComponent extends BaseComponent implements AfterViewChecked, OnInit, OnDestroy {
    @ViewChild(Content) public content: Content;
    @ViewChild('footerContent', { read: ViewContainerRef }) public footerContent: ViewContainerRef;
    @ViewChild('topBlockView', { read: ElementRef }) public topBlockView: ElementRef;
    @ViewChild('bottomBlockView', { read: ElementRef }) public bottomBlockView: ElementRef;

    public chatFlowAccessor: ExistingSavingsChatFlowAccessor;
    public state: ExistingSavingsState;
    // is current page
    public isCurrentPage: boolean;
    public currentTitle: string;
    public needPassword: boolean = true;
    public footerState = 'out';

    private currentPageComponent: ExistingSavingsChatFlowRenderer;
    private currentPageIndex: number;
    private pageComponentList: ExistingSavingsChatFlowRenderer[];

    private startOrder: number;
    private endOrder: number;
    private cifInfo: any;
    private options?: {
        component: string;
        title: string;
        process: number;
        clear: boolean;
        submitData: any;
    };

    constructor(
        private store: ExistingSavingsStore, private action: ExistingSavingsAction,
        private modalService: ModalService, private audioService: AudioService,
        private navCtrl: NavController, public changeDetectorRef: ChangeDetectorRef,
        private params: NavParams, public viewCtrl: ViewController,
        private modalCtrl: ModalController, private licenseService: LicenseService,
        private loginStore: LoginStore, private deviceService: DeviceService,
        private savingsStore: SavingsStore, private editService: EditService,
        private changeUtils: ChangeUtils,
        private labelService: LabelService,
        private cardService: CardService,
        private logging: LoggingService,
        private rsaEncryptService: RsaEncryptService,
        private app: App,
        private nameBasedAggregationService: NameBasedAggregationService,
        private creditCardStore: CreditCardStore) {
        super();
        this.pageComponentList = [];
        this.state = this.store.getState();
        this.chatFlowAccessor = new ExistingSavingsChatFlowAccessor();
    }
    public ngOnInit() {
        this.startOrder = this.params.get('startOrder');
        this.endOrder = this.params.get('endOrder');
        this.currentPageIndex = this.params.get('pageIndex');
        this.isCurrentPage = this.params.get('isCurrentPage') ? true : false;
        this.currentTitle = this.params.get('isCurrentPage') ? this.params.get('currentTitle') : '';
        this.needPassword = this.params.get('needPassword') ? false : true;
        this.cifInfo = this.params.get('submitData');
        this.options = this.params.get('options');

        if (this.options && this.options.submitData) {
            this.action.clearShowChats();
            this.action.setStateData(this.options);
        }

        // 本人確認書類の修正チャットの場合、口座開設の書類情報をクリアする
        if (this.options && this.options.component === 'SelfCheckApplyComponent' && this.isCurrentPage) {
            // OCRが運転経歴証明書の場合、hasLicense、画像、有効期限を復元
            if (this.state.submitData.hasLicense === HasLicense.HAS_NOT_LICENSE
                && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES) {
                    this.action.setStateSubmitDataValue([
                        {
                            key: 'hasLicense',
                            value: Constants.DriveCard
                        },
                        {
                            key: 'holderCardImageFront',
                            value: this.savingsStore.getState().submitData.holderCardImageFront
                        },
                        {
                            key: 'holderCardImageBack',
                            value: this.savingsStore.getState().submitData.holderCardImageBack
                        }
                    ]);
            }
        }

        const cardInfo = this.params.get('cardInfo');
        if (cardInfo) {
            this.action.setStateSubmitDataValue([{
                key: 'cardInfo',
                value: cardInfo
            }]);
        }

        // cif情報をセット
        if (this.cifInfo) {
            this.action.setCifInfo(this.cifInfo);
        }

        // 読み込むQRコード情報をこのフローに設定する
        if (this.params.get('tabletApplyId') && this.params.get('accountType')) {
            this.action.setSwipeInfo({
                tabletApplyId: this.params.get('tabletApplyId'),
                accountType: this.params.get('accountType'),
            });
        }

        this.currentPageIndex = 0;
        this.currentPageComponent = this.getPageComponent(0, this.options ? this.options.component : undefined);
        this.currentPageComponent.loadTemplate(0);

        // ハンドラーを追加する
        this.registerHandler();
    }

    public ngOnDestroy() {
        this.chatFlowAccessor.destroy();
        this.store.unregisterSignalHandler(ExistingSavingsSignal.CHAT_FLOW_COMPELETE);
        this.store.unregisterSignalHandler(ExistingSavingsSignal.CHAT_FLOW_RETURN);
        this.store.unregisterSignalHandler(ExistingSavingsSignal.SET_ACCOUNT_BALANCE);
        this.store.unregisterSignalHandler(ExistingSavingsSignal.SET_CIF_ACCOUNT_INFO);
        this.store.unregisterSignalHandler(ExistingSavingsSignal.SET_ANSWER);
        this.store.unregisterSignalHandler(ExistingSavingsSignal.WILL_PUSH_FOOTER);
        this.store.unregisterSignalHandler(ExistingSavingsSignal.WILL_DISMISS_FOOTER);
    }

    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    public beforeAlert() {
        this.chatFlowAccessor.clearComponent();
    }
    public afterAlert() {
        const lastNode = this.state.showChats[this.state.showChats.length - 1];
        this.action.resetLastNode({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    /**
     * button click CallBack
     * @param order メッセージの番号
     * @param pageIndex ページ番号
     * @param answerOrder 応答順
     */
    public editCallBack(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.beforeAlert();
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.editBtn, buttonValue: 'edit' }
        ];
        this.editService.startEdit();
        this.modalService.showWarnAlert(
            this.labels.alert.editTitle,
            buttonList,
            (item) => {
                const preventedItem = this.editService.endEdit();
                if (item.buttonValue === 'edit') {
                    this.action.editChart(order, pageIndex, answerOrder, orderIndex);
                    this.chatFlowAccessor.clearComponent();
                    this.currentPageIndex = pageIndex;
                    this.currentPageComponent = this.getPageComponent(pageIndex);

                    // // 既存申込チャットで鉛筆の修正によって必要なデータがクリアなので
                    // // renderが使用される前に、消える可能性あるデータを戻す作業
                    // this.currentPageComponent.restoreDispItemByEdit();

                    this.getNextAnswer(order, pageIndex);
                    const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
                    this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
                } else {
                    if (preventedItem) {
                        this.getNextAnswer(preventedItem.order, preventedItem.pageIndex);
                    } else {
                        this.afterAlert();
                    }
                }
            },
            this.labels.alert.editSubTitle
        );
    }

    /**
     * ヘッダータイトル取得
     */
    public get headerTitle(): string {
        if (this.options && this.options.title) {
            return this.options.title;
        }
        if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
            return this.labels.existingSavings.title;
        } else if (this.state.submitData.accountType === AccountType.EXISTING_STORAGE) {
            return this.labels.existingStorage.title;
        }
    }

    /**
     * processType取得
     */
    public get processType(): number {
        return this.options ? this.options.process : this.currentPageComponent.processType;
    }

    /**
     * header cancel button click
     */
    public handleCancelClickEmitter(value) {
        // タイトルが「本人確認書類」の場合、ポップアップを表示。※本人確認チャット
        if (this.headerTitle === '本人確認書類') {
            const buttonList = [
                { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
                { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.backToConfirmTitle,
                buttonList,
                (item) => {
                    if (item.buttonValue === 'back') {
                        this.viewCtrl.dismiss(this.getBackType(value));
                    }
                }
            );
        } else {
            this.viewCtrl.dismiss(value);
        }
    }

    /**
     * 本人確認チャットの場合は、ボタン名を「申込確認へ戻る」以外の場合は「行員呼び出し」
     *
     * @readonly
     * @memberof ExistingSavingsChatComponent
     */
    public get leftHeadTitle() {
        return (this.headerTitle === '本人確認書類') ? this.labels.common.leftSubTitle.backConfirm : this.labels.header.leftSubTitle;
    }

    private getBackType(value: any) {
        const isChange = this.state.isAddressDifference || this.state.isNameDifference || this.state.isTelphoneDifference
            || this.state.submitData.isAddressChange || this.state.submitData.isNameChange
            || this.state.submitData.isTelphoneChange;
        const ifBc = this.state.submitData.ifApplyBC === ApplyBC.YES ? true : false;
        // 届出変更あり、BCなし または 届出変更なし、BCありの場合
        if (isChange && !ifBc || !isChange && ifBc) {
            return 'backConfirmTwoScn';
            // 届出変更あり かつ BCありの場合
        } else if (isChange && ifBc) {
            return 'backConfirmThreeScn';
            // 届出変更なし かつ BCなしの場合
        } else {
            return value;
        }
    }

    private toEditChat(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.beforeAlert();
        this.action.editChart(order, pageIndex, answerOrder, orderIndex);
        this.chatFlowAccessor.clearComponent();
        this.currentPageIndex = pageIndex;
        this.currentPageComponent = this.getPageComponent(pageIndex);
        this.getNextAnswer(order, pageIndex);
        const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
        this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
    }

    /**
     * 次のノードを取得する
     * @param order メッセージの番号
     * @param pageIndex ページ番号
     * @param nextChatDelay ディレイ時間
     */
    private getNextAnswer(order: number, pageIndex: number, nextChatDelay?: number) {
        if (this.startOrder != null && this.endOrder != null && order > this.endOrder) {
            if (this.needPassword) {
                const modal = this.modalCtrl.create(AccountModalPasswordComponent,
                    { data: this.labels.modal.passwordModalInfo },
                    { cssClass: 'settings-modal', enableBackdropDismiss: false });
                modal.onDidDismiss((value) => this.viewCtrl.dismiss(value));
                modal.present();
            } else {
                this.viewCtrl.dismiss();
            }
            return;
        }
        const chatSpeed = nextChatDelay !== undefined ? nextChatDelay : AppProperties.CHAT_SPEED;
        Observable.timer(Number(chatSpeed)).subscribe(() => {
            this.action.getNextChatByAnswer(order, pageIndex);
        });
    }

    /**
     * コンポーネントタイプにより、各レンダラをマッピング
     * @param componentType コンポーネントタイプ
     */
    private mappingComponentList(componentType: string, options: any = null): ExistingSavingsChatFlowRenderer {
        let render: ExistingSavingsChatFlowRenderer;
        if (componentType === 'ExistingSavingsVerificationComponent' || componentType === undefined) {
            render = new ExistingSavingsVerificationRenderer(
                this.chatFlowAccessor,
                this.footerContent,
                this.store,
                this.deviceService,
                this.audioService,
                this.navCtrl,
                this.cardService,
                this.logging,
                this.rsaEncryptService,
                this.action
            );
        } else if (componentType === 'ExistingSavingsPurposeComponent') {
            render = new ExistingSavingsPurposeRenderer(this.chatFlowAccessor, this.footerContent, this.store, this.modalService,
                this.modalCtrl, this.deviceService, this.loginStore, this.navCtrl, this.action, this.audioService,
                this.nameBasedAggregationService);
        } else if (componentType === 'SelfCheckApplyComponent') {
            render = new SelfCheckApplyComponent(this.chatFlowAccessor, this.footerContent, this.changeUtils);
        } else if (componentType === 'SelfImgapplyComponent') {
            render = new SelfImgapplyComponent(this.chatFlowAccessor, this.footerContent);
            Reflect.defineProperty(render, 'options', {
                value: options
            });
        } else if (componentType === 'SelfAddressIdentification') {
            render = new SelfAddressIdentification(this.chatFlowAccessor, this.footerContent, this.changeUtils);
        } else if (componentType === 'SelfIdentificationDocumentOne') {
            render = new SelfIdentificationDocumentOne(this.chatFlowAccessor, this.footerContent, this.changeUtils);
        } else if (componentType === 'SelfIdentificationDocumentTwo') {
            render = new SelfIdentificationDocumentTwo(this.chatFlowAccessor, this.footerContent, this.changeUtils);
        } else if (componentType === 'ExistingSavingsBranchConfirmComponent') {
            render = new ExistingSavingsBranchConfirmRenderer(this.chatFlowAccessor, this.footerContent,
                this.audioService, this.modalService);
        } else if (componentType === 'ExistingSavingsChangeDifferencialConfirmationComponent') {
            render = new ExistingSavingsChangeDifferencialConfirmationRenderer(this.chatFlowAccessor, this.footerContent,
                this.store, this.audioService, this.action, this.changeUtils);
        }  else if (componentType === 'ExistingSavingsChangeAddressRenderer') {
            render = new ExistingSavingsChangeAddressRenderer(this.chatFlowAccessor, this.footerContent,
                this.store, this.audioService, this.action, this.changeUtils);
        }  else if (componentType === 'ExistingSavingsChangeDocumentConfirmComponent') {
            render = new ExistingSavingsChangeDocumentConfirmRenderer(this.chatFlowAccessor, this.footerContent,
                this.store, this.audioService, this.action, this.changeUtils, this.navCtrl);
        } else if (componentType === 'CreditcardDocumentConfirmComponent') {
            render = new ExistingSavingsCreditcardDocumentConfirmRenderer(
                this.chatFlowAccessor, this.footerContent, this.store, this.loginStore, this.creditCardStore);
        } else if (componentType === 'CreditCardStuffConfirmComponent') {
            render = new ExistingSavingsCreditCardStuffConfirmRenderer(this.chatFlowAccessor, this.footerContent,
                this.store, this.action, this.loginStore);
        } else if (componentType === 'ExistingSavingsChangeAddCheckComponent') {
            render = new ExistingSavingsChangeAddCheckRenderer(this.chatFlowAccessor, this.action, this.store, this.footerContent);
        }
        return render;
    }

    /**
     * Get page component
     * @param componentType コンポーネントタイプ
     */
    private getPageComponent(pageIndex: number, componentType?: string, options: any = null): ExistingSavingsChatFlowRenderer {
        if (this.pageComponentList[pageIndex] == null) {
            this.pageComponentList[pageIndex] = this.mappingComponentList(componentType, options);
            this.pageComponentList[pageIndex].nextChatEvent.subscribe((params) => {
                this.getNextAnswer(params.order, params.pageIndex, params.nextChatDelay);
            });
        }

        if (this.chatFlowAccessor) {
            this.chatFlowAccessor.setRenderer(this.pageComponentList[pageIndex]);
            this.chatFlowAccessor.setContent(this.content);
        }
        return this.pageComponentList[pageIndex];
    }

    /**
     * branchの状態を更新する
     */
    private branchStatusUpdate() {
        let leaveReason = '';
        let status = '';

        switch (this.state.submitData.leaveType) {
            case 'corporation':
                leaveReason = Constants.DBConsts.leaveReason.corporation;
                status = Constants.DBConsts.updateStatus.corporation;
                break;
            case 'against':
                leaveReason = Constants.DBConsts.leaveReason.against;
                status = Constants.DBConsts.updateStatus.against;
                break;
            case 'importantForeigner':
                leaveReason = Constants.DBConsts.leaveReason.importantForeigner;
                status = Constants.DBConsts.updateStatus.importantForeigner;
                break;
            case 'notInJapan':
                leaveReason = Constants.DBConsts.leaveReason.notInJapan;
                status = Constants.DBConsts.updateStatus.corporation;
                break;
            case 'agentNoConfirmFile':
                leaveReason = Constants.DBConsts.leaveReason.agentNoConfirmFile;
                status = Constants.DBConsts.updateStatus.agentNoConfirmFile;
                break;
            case 'noCohabitation':
                leaveReason = Constants.DBConsts.leaveReason.noCohabitation;
                status = Constants.DBConsts.updateStatus.noCohabitation;
                break;
            case 'noConfirmFile':
                leaveReason = Constants.DBConsts.leaveReason.noConfirmFile;
                status = Constants.DBConsts.updateStatus.noConfirmFile;
                break;
        }

        const params = {
            tabletApplyId: this.store.getState().tabletApplyId,
            leaveReason: leaveReason,
            status: status,
            userMngNo: this.loginStore.getState().bankclerkId
        };

        this.action.branchStatusUpdate(params);
    }

    /**
     * ハンドラーを追加する
     */
    private registerHandler() {
        this.store.registerSignalHandler(ExistingSavingsSignal.CHAT_FLOW_COMPELETE, (next) => {
            const { name, options } = next;
            if (name === undefined) {
                this.branchStatusUpdate();
            } else if (name === 'top') {
                Observable.timer(Constants.PageConsts.backToTopStayTime).subscribe(() => {
                    this.navCtrl.setRoot(TopComponent);
                    this.chatFlowAccessor.clearComponent();
                });
            } else if (name === ChatFlowChoicesValue.BACK_TO_TOP) {
                Observable.timer(Constants.ZERO).subscribe(() => {
                    this.navCtrl.setRoot(TopComponent);
                    this.chatFlowAccessor.clearComponent();
                });
            } else if (name === 'backToTopConfirm') {
                Observable.timer(Constants.ZERO).subscribe(() => {
                    this.app.getRootNav().setRoot(TopComponent).then(() => {
                        this.viewCtrl.dismiss(undefined, undefined, { animate: false });
                    });
                    this.chatFlowAccessor.clearComponent();
                });
            } else if (name === 'ExistingSavingsConfirmComponent') {
                this.viewCtrl.dismiss({
                    ...this.state
                });
            } else if (name === 'ExistingSavingsChangeConfirmComponent') {
                this.viewCtrl.dismiss({
                    ...this.state
                });
            } else {
                this.currentPageIndex += 1;
                this.currentPageComponent = this.getPageComponent(this.currentPageIndex, name, options);
                Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                    this.currentPageComponent.loadTemplate(this.currentPageIndex);
                });
                this.chatFlowAccessor.clearComponent();
            }
        });

        // 口座残高情報取得が完了になる場合
        this.store.registerSignalHandler(ExistingSavingsSignal.SET_ACCOUNT_BALANCE, (params) => {
            this.getNextAnswer(params.nextOrder, params.pageIndex);
        });

        // CIF情報照会、口座情報照会が完了になる場合
        this.store.registerSignalHandler(ExistingSavingsSignal.SET_CIF_ACCOUNT_INFO, (results) => {

            // 口座残高情報照会を呼び出す
            const accountParam: AccountBalanceInquiryInterface = {
                path: CoreBankingConstants.ApiPathConsts.ACCOUNT_BALANCE_INQUIRY,
                tabletApplyId: this.loginStore.getState().tabletApplyId,
                userMngNo: this.loginStore.getState().bankclerkId,
                params: {
                    bankNo: CoreBankingConst.bankNo,                                 // 銀行番号
                    receptionTenban: this.state.submitData.receptionBranchNo,  // 受付店番
                    receptionNo: this.state.submitData.receptionNo,            // 受付番号
                    terminalNo: this.deviceService.getDeviceId(),            // 端末番号
                    accountInfoList: [{
                        tenban: this.state.submitData.swipeBranchNo,
                        accountNo: this.state.submitData.swipeAccountNo,
                        accountType: COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL
                    }]
                }
            };
            this.action.inquireAccountBalance(accountParam, results.nextOrder, results.pageIndex);
        });

        this.store.registerSignalHandler(ExistingSavingsSignal.CHAT_FLOW_RETURN, (next) => {
            const copyShowChats = Array.from(this.state.showChats);
            const item = copyShowChats.reverse().find(
                (qus) => {
                    return qus.name === next.name && qus.type !== 'judge';
                }
            );

            this.toEditChat(item.order, item.pageIndex, item.answer.order, item.orderIndex);
        });

        this.store.registerSignalHandler(ExistingSavingsSignal.SET_ANSWER, () => this.changeDetectorRef.detectChanges());
        this.store.registerSignalHandler(ExistingSavingsSignal.WILL_PUSH_FOOTER, () => this.footerState = 'in');
        this.store.registerSignalHandler(ExistingSavingsSignal.WILL_DISMISS_FOOTER, () => this.footerState = 'out');
    }
}
