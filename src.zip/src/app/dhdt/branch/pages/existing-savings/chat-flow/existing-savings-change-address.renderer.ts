import { ViewContainerRef } from '@angular/core';
import { InjectionUtils, ObjectUtils } from 'adep/utils';
import { UnacceptableCode } from 'dhdt/branch/pages/change/change-consts';
import { ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { ChatOption, COMMON_CONSTANTS, RegionCodeDeterminationMethod } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { BussinessCode, DeliveryStatus, JudgeResultStatus } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import { ExistingSavingsSignal, ExistingSavingsState, ExistingSavingsStore,
} from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { SelectAddressCommonComponent } from 'dhdt/branch/shared/components/address/view/select-address-common.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { AcceptionResult } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { RegionCodeSearchRequestEntity } from 'dhdt/branch/shared/entity/region-code.entity';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
/**
 * 普通預金 既存_普通預金口座開設 住所
 */
export class ExistingSavingsChangeAddressRenderer extends ExistingSavingsChatFlowRenderer {

    public processType = 1;

    private state: ExistingSavingsState;
    private modalService: ModalService;
    private loginStore: LoginStore;
    private loginState: LoginState;

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: ExistingSavingsStore,
        private audioService: AudioService,
        private action: ExistingSavingsAction,
        private changeUtils: ChangeUtils
    ) {
        super();
        this.state = this.store.getState();
        this.modalService = InjectionUtils.injector.get(ModalService);
        this.changeUtils = InjectionUtils.injector.get(ChangeUtils);
        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.loginState = this.loginStore.getState();
    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(COMMON_CONSTANTS.YML_CHAT_FLOW_EXISTING_SAVINGS_CHANGE_ADDRESS, pageIndex);
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'verificationDocumentImgJudge': {
                this.onVerificationDocumentImgJudge(question, pageIndex);
                break;
            }
            case 'selectAddress': {
                this.onSelectAddress(question, pageIndex);
                break;
            }
            case 'changeContent': {
                this.onChangeContent(question, pageIndex);
                break;
            }
            case 'requestSwipeCif': {
                this.requestSwipeCifStatus(question, pageIndex);
                break;
            }
        }
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        let params;
        let level;
        const changeState = InjectionUtils.injector.get(ChangeStore).getState();
        if (entity.choices) {
            switch (entity.name) {
                case 'isAddressChange': {
                    // 住所変更時に0設定
                    judgeResult = this.state.submitData.isAddressChange ? JudgeResultStatus.RESULT_0 : JudgeResultStatus.RESULT_1;
                    break;
                }
                case 'allCifTradingConditionsJudge': {
                    // PID配下全CIFの取引ぶりの判定
                    this.cifTradingConditionsJudge(true, entity, pageIndex);
                    return;
                }
                case 'isNonDelivery': {
                    judgeResult = JudgeResultStatus.RESULT_1;
                    // PID配下の全てCIF情報に「郵便不着」あれば、０ルートに行きます
                    this.state.submitData.allCifInfos.forEach(
                        (cifInfo: CifInfo) => {
                            if (cifInfo.nonDelivery === DeliveryStatus.NON_DELIVERY) {
                                judgeResult = JudgeResultStatus.RESULT_0;
                            }
                        }
                    );
                    break;
                }
                // 住所マスタ該当無しであれば,０ルートに行きます
                case 'isNotExistingAddressCodeStatus': {
                    judgeResult = this.state.submitData.isNotExistingAddressCodeStatus ?
                    JudgeResultStatus.RESULT_0 : JudgeResultStatus.RESULT_1;
                    break;
                }
                case 'getAddressFromZipcode': {
                    const serverInfoService = InjectionUtils.injector.get(ServerInfoService);
                    let firstZipCode;
                    let lastZipCode;
                    if (this.state.submitData.firstZipCode) {
                        firstZipCode = this.state.submitData.firstZipCode;
                    }
                    if (this.state.submitData.lastZipCode) {
                        lastZipCode = this.state.submitData.lastZipCode;
                    }
                    const zipCode = firstZipCode + lastZipCode + '';
                    params = { zipCode: zipCode };
                    serverInfoService.getInfoFormServe(entity.name, params).subscribe((result) => {
                        entity.choices.forEach((choice) => {
                            if (result === choice.value) {
                                this.getNextChat(choice.next, pageIndex);
                                return;
                            }
                        });
                    });
                    break;
                }
                case 'getStreetInitialsKana': {
                    const serverInfoService = InjectionUtils.injector.get(ServerInfoService);
                    let prefecture;
                    let village;
                    if (this.state.submitData.holderAddressPrefecture) {
                        prefecture = this.state.submitData.holderAddressPrefecture;
                    }
                    if (this.state.submitData.holderAddressCountyUrbanVillage) {
                        village = this.state.submitData.holderAddressCountyUrbanVillage;
                    }
                    params = {
                        prefectureKanji: prefecture,
                        countyUrbanVillageKanji: village
                    };
                    serverInfoService.getInfoFormServe(entity.name, params).subscribe((result) => {
                        entity.choices.forEach((choice) => {
                            if (result === choice.value) {
                                this.getNextChat(choice.next, pageIndex);
                                return;
                            }
                        });
                    });
                    break;
                }
                // 住所の差分チェック
                case 'addressDifferenceCheckResult': {
                    this.addressDifferenceCheck(entity, pageIndex);
                    return;
                }
                case 'addressDifferenceAddressChange': {
                    // 住所変更かつ、住所差分無しのとき1、それ以外0
                    judgeResult = this.state.isAddressDifference || this.state.submitData.isAddressChange ?
                    JudgeResultStatus.RESULT_0 : JudgeResultStatus.RESULT_1;
                    break;
                }
                // 名寄せ先の更新予定のCIFの取引ぶりを判定(住所)
                case 'doTabletCheck': {
                    this.acceptCheckForUpdateCif(entity, pageIndex);
                    return;
                }
                case 'updateCifTradingConditionsJudge': {
                    // スワイプCIFまたは住所差分のあるCIFに関連する取引ぶりの判定
                    this.cifTradingConditionsJudge(false, entity, pageIndex);
                    return;
                }
                // スワイプCIFの受付可否実行判定
                case 'isAcceptCheckForSwipeCif': {
                    judgeResult = JudgeResultStatus.RESULT_0;
                    if (!this.state.submitData.isNameChange && !this.state.submitData.isTelphoneChange
                        && (this.state.submitData.nonDelivery === DeliveryStatus.NON_DELIVERY
                            || this.state.submitData.isNotExistingAddressCodeStatus)) {
                        // 氏名・電話番号どちらも[変更なし]を選択（住所は[変更なし]の前提） かつ
                        // 郵便不着あり先、もしくは住所コード該当なし先で住所を変更する場合、スワイプCIFの受付可否を実施する
                        judgeResult = JudgeResultStatus.RESULT_1;
                    }
                    break;
                }
                // スワイプCIFの取引ぶりを判定
                case 'acceptCheckForSwipeCif': {
                    judgeResult = JudgeResultStatus.RESULT_02;
                    level = this.changeUtils.getTransactionLevel(
                        this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                    // ジュニアNISA対応
                    const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(this.state.submitData.birthdate,
                        this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                    if (level.levelOne || isHaveJuniorNisa) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                    }
                    break;
                }
                // 住所の修正ボタンを押下したとき
                case 'isModify': {
                    judgeResult = JudgeResultStatus.RESULT_0;
                    if (changeState.submitData.pressButtonType === 'existingChangeHolderAddress') {
                        // 住所の修正ボタンを押下したとき
                        // 無条件で受付可否チェックを実行する
                        judgeResult = JudgeResultStatus.RESULT_1;
                    }
                    break;
                }
                // スワイプCIFが住所変更後と変更前が同じかどうか、郵便不着フラグあるかどうかをチェックする
                case 'isSwCifAddressDifAndNoDelivery': {
                    // デフォルトが変更前と変更後が違う
                    let _judgeResult = JudgeResultStatus.RESULT_1;

                    if (this.state.submitData.isAddressChange) {
                        // 住所コードを取得
                        const postCode = '';
                        const prefectureKana = this.state.submitData.holderAddressPrefectureFuriKana;
                        const countyUrbanVillageKana = this.state.submitData.holderAddressCountyUrbanVillageFuriKana;
                        const streetKana = this.state.submitData.getHolderAddressStreetNameFuriKana();
                        const requestParams = {
                            postCode: postCode,
                            prefectureKana: prefectureKana,
                            countyUrbanVillageKana: countyUrbanVillageKana,
                            streetKana: streetKana
                        };
                        if (!this.state.submitData.firstZipCode) {
                            this.getHolderZipCode();
                            this.store.registerSignalHandler(ExistingSavingsSignal.GET_HOLDER_ZIP_CODE, () => {
                                this.store.unregisterSignalHandler(ExistingSavingsSignal.GET_HOLDER_ZIP_CODE);
                                requestParams.postCode = this.state.submitData.firstZipCode + this.state.submitData.lastZipCode;
                                this.action.getAddressCode(requestParams);
                            });
                        } else {
                            requestParams.postCode = this.state.submitData.firstZipCode + this.state.submitData.lastZipCode;
                            this.action.getAddressCode(requestParams);
                        }

                        this.store.registerSignalHandler(ExistingSavingsSignal.GET_ADDRESS_CODE, () => {
                            this.store.unregisterSignalHandler(ExistingSavingsSignal.GET_ADDRESS_CODE);
                            // スワイプCIFを取得
                            const swipeCifInfo =
                            this.state.submitData.allCifInfos.filter((cifInfo: CifInfo) =>
                            cifInfo.customerId === this.state.submitData.customerId);

                            const isDiff = this.changeUtils.isAddressDiference(swipeCifInfo[0], this.state.submitData.holderAddressCode,
                                this.state.submitData.holderAddressHouseNumberFuriKana);

                            // 変更後と変更前が差異がなし　かつ　郵便不着フラグが存在しません
                            if (!isDiff && swipeCifInfo[0].nonDelivery !== DeliveryStatus.NON_DELIVERY) {
                                _judgeResult = JudgeResultStatus.RESULT_0;
                            }
                            this.nextChatByJudge(entity, pageIndex, _judgeResult);
                        });

                    }
                    break;
                }
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        }
    }

    public onNumberKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent,
            options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();

            if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                // skip時はvalueは設定しない
                this.setAnswer({
                    text: COMMON_CONSTANTS.SKIP_TEXT,
                    value: [{ key: entity.name, value: undefined }]
                });
            } else {
                this.action.setAnswer({
                    text: answer.text,
                    value: answer.value
                });
            }
            this.getNextChat(entity.next, pageIndex);
        });
    }

    public onPicker(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            validationRules: entity.validationRules,
            submitData: this.state.submitData,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            fullwidthHalfwidthDivisionCode: entity.fullwidthHalfwidthDivisionCode
        };
        let choices = null;
        // 「番地以降（漢字）」の場合
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW) {
            this.store.registerSignalHandler(ExistingSavingsSignal.SEARCH_REGION_CODE_COMPLETE, (data) => {
                this.store.unregisterSignalHandler(ExistingSavingsSignal.SEARCH_REGION_CODE_COMPLETE);
                choices = ObjectUtils.clone(entity.choices);
                // 地域コードに町丁名含まれない場合のみ、「町丁名（漢字）」入力済桁数により「番地以降（漢字）」入力可能最大桁数を調整する
                if (RegionCodeDeterminationMethod.WITHOUT_STREET === data.regionCodeDeterminationMethod) {
                    console.log('[dhdt] RegionCode is without street');
                    choices = this.reviseMaxlengthOfHolderAddressHouseNumberKanji(this.state, choices, entity);
                }
                // 入力キーボード配置
                this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
                    this.footerContent, options).subscribe((answer) => {
                        this.chatFlowAccessor.clearComponent();

                        if (entity.fullwidthHalfwidthDivisionCode === 1 && answer !== COMMON_CONSTANTS.SIGN_SKIP) {
                            this.store.unregisterSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK);
                            // 文字チェックが失敗するときに、httpserviceの共通処理で処理するので、ここにこない。
                            this.store.registerSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK, () => {
                                // 文字チェック成功に来る場合
                                this.store.unregisterSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK);
                                // 処理の継続
                                this.dynamicMaxLength(entity, this.state, answer, this.action);
                                // 次のチャットへ
                                this.getNextChat(entity.next, pageIndex);
                            });
                            // 文字チェックを始まる
                            const paramsCheck = {
                                tabletApplyId: this.loginStore.getState().tabletApplyId,
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                                    checkStrings: [{
                                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                        checkString: answer.text
                                    }]
                                }
                            };
                            this.action.characteCheck(paramsCheck, () => {
                                const chats = this.state.showChats.splice(-1, 1);
                                if (chats && chats.length > 0) {
                                    const chat = chats[0];
                                    this.action.getNextChatByAnswer(chat.order, pageIndex);
                                }
                            });
                        } else {
                            // 処理の継続
                            this.dynamicMaxLength(entity, this.state, answer, this.action);
                            // 次のチャットへ
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });
            });
            const params = this.createRegionCodeSearchRequestParams(this.state);
            // change action へ実装
            this.action.searchRegionCode(params);
        } else {
            // 「番地以降（カナ）」の場合
            choices = ObjectUtils.clone(entity.choices);
            this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
                this.footerContent, options).subscribe((answer) => {
                    this.chatFlowAccessor.clearComponent();

                    if (entity.fullwidthHalfwidthDivisionCode === 1 && answer !== COMMON_CONSTANTS.SIGN_SKIP) {
                        this.store.unregisterSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK);
                        // 文字チェックが失敗するときに、httpserviceの共通処理で処理するので、ここにこない。
                        this.store.registerSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK, () => {
                            // 文字チェック成功に来る場合
                            this.store.unregisterSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK);
                            // 処理の継続
                            this.dynamicMaxLength(entity, this.state, answer, this.action);
                            // 次のチャットへ
                            this.getNextChat(entity.next, pageIndex);
                        });
                        // 文字チェックを始まる
                        const paramsCheck = {
                            tabletApplyId: this.loginStore.getState().tabletApplyId,
                            params: {
                                receptionTenban: this.loginStore.getState().belongToBranchNo,
                                checkStrings: [{
                                    checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                    checkString: answer.text
                                }]
                            }
                        };
                        this.action.characteCheck(paramsCheck, () => {
                            const chats = this.state.showChats.splice(-1, 1);
                            if (chats && chats.length > 0) {
                                const chat = chats[0];
                                this.action.getNextChatByAnswer(chat.order, pageIndex);
                            }
                        });
                    } else {
                        // 処理の継続
                        this.dynamicMaxLength(entity, this.state, answer, this.action);
                        // 次のチャットへ
                        this.getNextChat(entity.next, pageIndex);
                    }
                });
        }
    }

    public onChangeContent(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
                this.getNextChat(entity.next, pageIndex);
    }

    public onSelectAddress(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectAddressCommonComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();

            if (answer.value) {
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            } else {
                this.action.skip();
                this.getNextChat(entity.skip, pageIndex);
            }
        });
    }

    public onSelectStreet(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const params = {
            prefectureCode: this.state.submitData.holderAddressPrefectureCode,
            prefectureKanji: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillageCode: this.state.submitData.holderAddressCountyUrbanVillageCode,
            countyUrbanVillageKanji: this.state.submitData.holderAddressCountyUrbanVillage,
        };

        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(params, SelectStreetComponent, this.footerContent, options)
            .subscribe((result: { isSkip: boolean, text: string, value: any }) => {
                this.chatFlowAccessor.clearComponent();
                const answer = {
                    text: result.text,
                    value: [
                        { key: 'holderAddressStreetNameSelect', value: (
                            result.isSkip ? undefined : result.value.streetKanji) },
                        { key: 'holderAddressStreetNameFuriKanaSelect', value: (
                            result.isSkip ? undefined : result.value.streetKana) },
                    ]
                };
                this.action.clearZipCode();
                this.setAnswer(answer);
                this.getNextChat(result.isSkip ? entity.skip : entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationOn: null,
            kanaText: null,
            validationRules: null,
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            let address = this.buildAddress();
            address = StringUtils.convertHankaku2Zankaku(address);
            options.validationOn = ChatOption.VALIDATION_ON;
            options.kanaText = address;
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                this.getNextChat(answer.skip, pageIndex);
                return;
            }
            if (entity.name === 'addressChangeNoDelivery' || entity.name === 'addressChangeAddressCode') {
                let addressChangeFlg: boolean = false;
                if (answer.name === 'doChange') {
                    // 郵便不着有先で住所変更する場合、住所変更フラグをオンに更新する。
                    addressChangeFlg = true;
                }
                this.action.setStateSubmitDataValue([{key: 'isAddressChange', value: addressChangeFlg }]);
            }

            if (entity.name.length > 0 && answer.value.length > 0) {
                if (entity.name !== 'nextButton') {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else {
                this.chatFlowAccessor.clearComponent();
                if (entity.name !== 'nextButton') {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.text }
                        ]
                    });
                }
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onVerificationDocumentImgJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        let isAllCif: boolean;
        switch (entity.name) {
            case 'allCif': {
                isAllCif = true;
                break;
            }
            case 'difCif': {
                isAllCif = false;
                break;
            }
        }
        const params = {
            isAllCif: isAllCif,
            isChange: this.state.submitData.isAddressChange,
            isDifference: this.state.isAddressDifference,
            allCifTradingConditions: this.state.submitData.allCifTradingConditions,
            identiDifCifAcceptCheckResult: this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt
        };
        const addressDocumentImg = this.changeUtils.verificationAddressDocumentImgJudge(params);
        if (addressDocumentImg) {
            this.action.setStateSubmitDataValue([{key: 'addressDocumentImg', value: addressDocumentImg}]);
        }
        this.getNextChat(entity.next, pageIndex);
    }

    /**
     * Request customer status
     * @param entity entity
     */
    public requestSwipeCifStatus(entity: ExistingSavingsQuestionsModel, pageIndex: number) {

        // スワイプCIFの受付可否チェック
        const params = {
            receptionTenban: this.loginState.belongToBranchNo,    // 受付店番
            accounts: [{
                customerId: this.state.submitData.customerId    // 顧客番号
            }], // 口座情報
            businessCode: BussinessCode.ADDRESS_TEL_MENU_CHANGE, // 業務コード
        };
        const dict = {
            tabletApplyId: this.state.tabletApplyId,
            params: params,
        };

        this.store.registerSignalHandler(ExistingSavingsSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
            // 事故取引禁止注意エラーの場合、注意コードを取得の上エラーモーダルを表示する
            this.store.unregisterSignalHandler(ExistingSavingsSignal.UNACCEPTABLES_NG);
            const errorInfo = this.checkErrorCode(response.errors.data);
            this.showErrorModal(errorInfo);
        });

        this.store.registerSignalHandler(ExistingSavingsSignal.ACCEPT_CHECK_SWIPE_CIF, () => {
            this.store.unregisterSignalHandler(ExistingSavingsSignal.ACCEPT_CHECK_SWIPE_CIF);
            this.getNextChat(entity.next, pageIndex);
        });

        this.action.acceptCheckForSwipeCif(entity, dict);
    }

    private cifTradingConditionsJudge(isAllCif: boolean, entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        let judgeResult: string;
        const params = {
            isAllCif: isAllCif,
            isChange: this.state.submitData.isAddressChange,
            isDifference: this.state.isAddressDifference,
            allCifTradingConditions: this.state.submitData.allCifTradingConditions,
            identiDifCifAcceptCheckResult: this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt
        };
        judgeResult = (this.changeUtils.isNeed3B(params) || this.changeUtils.isNeed3C(params)) ?
            JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
        this.nextChatByJudge(entity, pageIndex, judgeResult);
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.chatFlowCompelete(action.value);
        }
    }

    private addressDifferenceCheck(entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        let judgeResult: string;
        if (this.state.submitData.isAddressChange) {
            this.action.setAddressDifferenceFlg(false);
            const postCode = '';
            const prefectureKana = this.state.submitData.holderAddressPrefectureFuriKana;
            const countyUrbanVillageKana = this.state.submitData.holderAddressCountyUrbanVillageFuriKana;
            const streetKana = this.state.submitData.getHolderAddressStreetNameFuriKana();
            const requestParams = {
                postCode: postCode,
                prefectureKana: prefectureKana,
                countyUrbanVillageKana: countyUrbanVillageKana,
                streetKana: streetKana
            };
            if (!this.state.submitData.firstZipCode) {
                this.getHolderZipCode();
                this.store.registerSignalHandler(ExistingSavingsSignal.GET_HOLDER_ZIP_CODE, () => {
                    this.store.unregisterSignalHandler(ExistingSavingsSignal.GET_HOLDER_ZIP_CODE);
                    requestParams.postCode = this.state.submitData.firstZipCode + this.state.submitData.lastZipCode;
                    this.action.getAddressCode(requestParams);
                });
            } else {
                requestParams.postCode = this.state.submitData.firstZipCode + this.state.submitData.lastZipCode;
                this.action.getAddressCode(requestParams);
            }
            this.store.registerSignalHandler(ExistingSavingsSignal.GET_ADDRESS_CODE, () => {
                this.store.unregisterSignalHandler(ExistingSavingsSignal.GET_ADDRESS_CODE);
                this.action.setStateSubmitDataValue([{
                    key: 'addressDifferenceInfos',
                    value: this.changeUtils.getAddressDifInfo(this.state.submitData.allCifInfos,
                        this.state.submitData.customerId, this.state.submitData.holderAddressCode,
                        this.state.submitData.holderAddressHouseNumberFuriKana)
                }]);
                // 住所変更ありかつ差分なし
                judgeResult = JudgeResultStatus.RESULT_1;
                for (const element of this.state.submitData.addressDifferenceInfos) {
                    // 住所変更ありかつ差分あり
                    if (element.isDifference) {
                        judgeResult = JudgeResultStatus.RESULT_0;
                        this.action.setAddressDifferenceFlg(true);
                        break;
                    }
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
            });
        } else if (this.state.submitData.addressDifferenceInfos && this.state.isAddressDifference) {
            judgeResult = JudgeResultStatus.RESULT_0;
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        } else {
            judgeResult = JudgeResultStatus.RESULT_1;
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        }
    }

    /*
    * typeがjudgeの際に、分岐して次のチャットを開始させる
    *
    * @param entity
    * @param pageIndex
    * @param judgeResult
    */
    private nextChatByJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number, judgeResult: string) {
        entity.choices.forEach((choice) => {
            if (choice.value === judgeResult) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }

    /**
     * 郵便番号を住所マスターから取得
     */
    private getHolderZipCode() {
        const holderAddressPrefecture = this.state.submitData.holderAddressPrefecture;
        const holderAddressCountyUrbanVillage = this.state.submitData.holderAddressCountyUrbanVillage;
        const holderAddressStreetNameSelect =
            this.state.submitData.holderAddressStreetNameInput ||
            this.state.submitData.holderAddressStreetNameSelect ||
            this.state.submitData.holderAddressStreet ||
            '';
        this.action.getHolderZipCode(
            holderAddressPrefecture,
            holderAddressCountyUrbanVillage,
            holderAddressStreetNameSelect
        );
    }

    private acceptCheckForUpdateCif(entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        // 名寄せの住所更新対象に対して受付可否チェック実施
        this.action.acceptCheckForAddressDifCif(this.makeAcceptCheckApiParams(), this.state.submitData.addressDifferenceInfos);

        let judgeResult;
        let level;

        this.store.registerSignalHandler(ExistingSavingsSignal.ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF, (acceptCheckResult: AcceptionResult) => {
            this.store.unregisterSignalHandler(ExistingSavingsSignal.ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF);
            const errMessageArr: Array<{customerId: string, message: string}> = [];
            // レスポンスパラメータの中に、受付可否チェック検出対象がいたら離脱
            for (const item of this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                let branchCode: string = '';
                for (const cifInfo of this.state.submitData.allCifInfos) {
                    if (item.customerId === cifInfo.customerId && this.changeUtils.isHostError(item.accounts.errorCode)) {
                        branchCode = cifInfo.customerManagementBranchCode;
                        if (item.accounts.unacceptables && item.accounts.unacceptables.length > 0) {
                            // 受付不可情報がある場合、表示メッセージは「エラー理由 ＋ 事故・取引禁止・注意コード」。
                            for (const acceptItem of item.accounts.unacceptables) {
                                errMessageArr.push({customerId: cifInfo.customerId, message: branchCode + COMMON_CONSTANTS.FULL_COLON
                                    + item.accounts.errorCode + COMMON_CONSTANTS.SPACE + acceptItem.unacceptableCode});
                            }
                        } else {
                            // 受付不可情報がない場合、表示メッセージは「エラー理由」のみ。
                            errMessageArr.push({customerId: cifInfo.customerId, message: branchCode
                                + COMMON_CONSTANTS.FULL_COLON + item.accounts.errorCode});
                        }
                    }
                }
            }
            const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
            let index = 0;
            let isNeedBr = 1;
            let message: string = '';
            let messageBefore: {customerId: string, message: string} = {customerId: undefined, message: undefined};
            if (errMessageArr.length > 0) {
                for (const err of errMessageArr) {
                    if (index === 0) {
                        message = err.message;
                    } else if (messageBefore.customerId === err.customerId &&  maxArr > isNeedBr) {
                        isNeedBr++;
                        message = message + COMMON_CONSTANTS.SLASH + err.message.substring(err.message.length - 3);
                    } else {
                        isNeedBr = 1;
                        message = message + COMMON_CONSTANTS.NEW_LINE + err.message;
                    }
                    index++;
                    messageBefore = err;
                }
                this.showErrorModal(message);
                return;
            }
            judgeResult = JudgeResultStatus.RESULT_02;
            if (this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt.forEach((acceptResult) => {
                    // ジュニアNISA対応
                    const cifInfo =
                        this.state.submitData.allCifInfos.filter((item) => item.customerId === acceptResult.customerId);
                    const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(cifInfo[0].birthDate,
                        acceptResult.accounts.tradingConditions);
                    level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                    if (level.levelOne || isHaveJuniorNisa) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                    }
                });
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        });
    }

    /**
     * 受付可否チェックパラメータ生成
     */
    private makeAcceptCheckApiParams() {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((element) => {
            this.state.submitData.addressDifferenceInfos.forEach((difItem) => {
                if (element.customerId !== this.state.submitData.customerId &&
                    element.customerId === difItem.customerId && difItem.isDifference) {
                    accounts.push({
                        customerId: element.customerId
                    });
                }
            });
        });

        const acceptCheckApiParams = {
            tabletApplyId: this.state.tabletApplyId,
            params: {
                receptionTenban: this.loginState.belongToBranchNo,
                accounts: accounts,
                businessCode: BussinessCode.ADDRESS_TEL_MENU_CHANGE,
            }
        };

        return acceptCheckApiParams;
    }

    private showErrorModal(errorCode: string, callback?: any) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            this.labels.common.error.host.support,
            errorCode, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }

    private dynamicMaxLength(entity: any, state: ExistingSavingsState, answer: any, action: ExistingSavingsAction) {
        let maxLength: number;
        if (entity.choices && entity.choices.length > 0) {
            maxLength = InputUtils.calculateMaxLength(entity.choices[0].name,
                this.state.submitData.holderAddressStreetNameFuriKanaInput, this.state.submitData.holderAddressStreetNameFuriganaSelect);
        }
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            action.setAnswer({ text: this.labels.common.skipjp, value: [] });
        } else {
            InputUtils.getKanjiToKana(answer.value, maxLength).subscribe((results) => {
                action.setAnswer({ text: answer.text, value: results });
            });
        }
    }

    private reviseMaxlengthOfHolderAddressHouseNumberKanji(state: ExistingSavingsState, choices: any, entity: any) {
        const holderAddressStreetLength = this.getStreetNameKanjiFromState(state).length;
        choices[0].validationRules.max = entity.choices[0].validationRules.max
            - holderAddressStreetLength;
        return choices;
    }

    private getStreetNameKanjiFromState(state: ExistingSavingsState): string {
        const holderAddressStreetNameInput = this.state.submitData.holderAddressStreetNameInput;
        const holderAddressStreetNameSelect = this.state.submitData.holderAddressStreetNameSelect;
        const holderAddressStreet = this.state.submitData.holderAddressStreet;

        let determinedHolderAddressStreet: string = '';
        if (holderAddressStreetNameInput) {
            // 町丁名漢字テキスト入力の場合
            determinedHolderAddressStreet = holderAddressStreetNameInput;
        } else if (holderAddressStreet) {
            // 町丁名単体の選択コンポネントで選択の場合
            determinedHolderAddressStreet = holderAddressStreet;
        } else if (holderAddressStreetNameSelect) {
            // 住所選択(都道府県～町丁名まで一括で選択)コンポネントで選択の場合
            determinedHolderAddressStreet = holderAddressStreetNameSelect;
        }
        return determinedHolderAddressStreet;
    }

    private createRegionCodeSearchRequestParams(state: ExistingSavingsState): RegionCodeSearchRequestEntity {
        const params = new RegionCodeSearchRequestEntity();
        params.prefectureKanji = this.state.submitData.holderAddressPrefecture || '';
        params.countyUrbanVillageKanji = this.state.submitData.holderAddressCountyUrbanVillage || '';
        params.streetKanji = this.getStreetNameKanjiFromState(state) || '';
        return params;
   }

    private buildAddress(): string {
        // 町丁名テキスト入力 / 住所・町丁名ボタン選択 / 住所選択で「町丁名無し住所」選択 の3パターン考慮する
        const streetNameFurigana = this.state.submitData.holderAddressStreetNameFuriKanaSelect ||
                this.state.submitData.holderAddressStreetNameFuriKanaInput || '';
        const address = (
            this.state.submitData.holderAddressPrefectureFuriKana +
            this.state.submitData.holderAddressCountyUrbanVillageFuriKana +
            streetNameFurigana +
            this.state.submitData.holderAddressHouseNumberFuriKana
        ) || '';
        return address;
    }

    /**
     * スワイプCIF専用のエラーメッセージ作成処理
     */
    private checkErrorCode(acceptCheckResult: AcceptionResult) {
        let errorInfo: any;
        let isNeedBr = 1;
        let index = 0;
        const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        for (const account of acceptCheckResult.accounts) {
            if (this.changeUtils.isHostError(account.errorCode)) {
                let unacceptables = '';
                const swipeCifInfo =
                    this.state.submitData.allCifInfos.filter((cifInfo: CifInfo) => cifInfo.customerId === this.state.submitData.customerId);
                errorInfo = swipeCifInfo[0].customerManagementBranchCode + COMMON_CONSTANTS.FULL_COLON + account.errorCode;

                for (const unacceptable of account.unacceptables) {
                    unacceptables = unacceptable.unacceptableCode;
                    if (index === 0) {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SPACE + unacceptables;
                    } else if (isNeedBr > maxArr) {
                        // 1行に最大3つの注意コードを表示する
                        // 超える場合は改行して店番＋エラー情報＋注意コードを表示する
                        errorInfo = errorInfo + COMMON_CONSTANTS.NEW_LINE + errorInfo.slice(0, 14) + unacceptables;
                        isNeedBr = 1;
                    } else {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SLASH + unacceptables;
                    }
                    index++;
                    isNeedBr++;
                }
            }
        }
        return errorInfo;
    }
}
