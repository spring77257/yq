import { ViewContainerRef } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { AccountInfo } from 'dhdt/branch/pages/change/entity/change-questions.model';
import { ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { AgentInternalError, COMMON_CONSTANTS, Constants, CountryCode,
    NameNonConvert } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { MediumInfosRequest } from 'dhdt/branch/pages/common/entity/medium-infos-request.entity';
import { LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import {
    BcHoldingStatus, BcStatus, BussinessCode,
    CdHoldingStatus, DoubleBcStatus, DoubleOsStatus, IcStatus, JudgeResultStatus, McStatus, OsStatus, UnacceptableCode
} from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import {
    ExistingSavingsSignal, ExistingSavingsState, ExistingSavingsStore
} from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { AcceptionResult } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
/**
 * 普通預金 既存_普通預金口座開設 氏名
 */
export class ExistingSavingsChangeNameRenderer extends ExistingSavingsChatFlowRenderer {

    public processType = 1;

    private state: ExistingSavingsState;
    private modalService: ModalService;
    private loginState: LoginState;
    private loginStore: LoginStore;

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: ExistingSavingsStore,
        private audioService: AudioService,
        private action: ExistingSavingsAction,
        private changeUtils: ChangeUtils,
        private labelService: LabelService
    ) {
        super();
        this.state = this.store.getState();
        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.modalService = InjectionUtils.injector.get(ModalService);
        this.changeUtils = InjectionUtils.injector.get(ChangeUtils);
        this.loginState = this.loginStore.getState();
    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(COMMON_CONSTANTS.YML_CHAT_FLOW_EXISTING_SAVINGS_CHANGE_NAME, pageIndex);
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'password4bits': {
                this.onPassword(question, pageIndex);
                break;
            }
            case 'requestMediumInfo': {
                this.onRequestMediumInfo(question, pageIndex);
                break;
            }
            case 'verificationDocumentImgJudge': {
                this.onVerificationDocumentImgJudge(question, pageIndex);
                break;
            }
            case 'changeContent': {
                this.onChangeContent(question, pageIndex);
                break;
            }
            case 'requestSwipeCif': {
                this.requestSwipeCifStatus(question, pageIndex);
                break;
            }
        }
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        let hasNameChangeTarget: boolean;
        let level;
        const changeState = InjectionUtils.injector.get(ChangeStore).getState();
        if (entity.choices) {
            switch (entity.name) {
                // 氏名変更有無判定
                case 'isNameChange': {
                    judgeResult = this.state.submitData.isNameChange ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                // 国籍判定(日本人 or 日本人以外)
                case 'nationalityCode': {
                    judgeResult = this.state.submitData.nationalityCode === CountryCode.Japan ?
                    JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                // 氏名の差分チェック
                case 'nameDifCheck': {
                    this.action.setNameDifferenceFlg(false);
                    // 差分チェックメソッドに渡すパラメータ生成
                    const data = {
                        customerId: this.state.submitData.customerId,
                        nationalityCode: this.state.submitData.nationalityCode,
                        nameKanji: this.state.submitData.existingChangeFirstName  ?
                        this.state.submitData.existingChangeFirstName + '　' + this.state.submitData.existingChangeLastName
                        : this.state.submitData.nameNonConvert === NameNonConvert.OFF ?
                        this.state.submitData.nameKanjiBackup : this.state.submitData.nameKanji,
                        nameKana: this.state.submitData.existingChangeFirstNameKana ?
                            this.state.submitData.existingChangeFirstNameKana + '　' + this.state.submitData.existingChangeLastNameKana
                            : this.state.submitData.nameKana,
                        nameAlphabet: this.state.submitData.existingChangeFirstNameAlphabet ?
                            this.state.submitData.existingChangeFirstNameAlphabet + + '　'
                            + this.state.submitData.existingChangeLastNameAlphabet
                             : this.state.submitData.nameAlphabet
                    };
                    this.action.setStateSubmitDataValue([
                        {
                            key: 'nameDifferenceInfos',
                            value: this.changeUtils.getNameDifInfo(this.state.submitData.allCifInfos, data)
                        }
                    ]);
                    judgeResult = JudgeResultStatus.RESULT_02;
                    this.state.submitData.nameDifferenceInfos.forEach((element) => {
                        if (element.isDifference) {
                            hasNameChangeTarget = true;
                            this.action.setNameDifferenceFlg(true);
                        }
                    });
                    // 氏名変更無しかつ氏名差分ありかつスワイプCIF側で氏名漢字変換不可文字ありの場合
                    if (!this.state.submitData.isNameChange && hasNameChangeTarget
                        && this.state.submitData.nameNonConvert === NameNonConvert.OFF) {
                            // 行員呼出
                            this.showErrorModal(AgentInternalError.ERROR_CODE_N_005);
                            return;
                    }
                    if (!hasNameChangeTarget && this.state.submitData.isNameChange) {
                        judgeResult = JudgeResultStatus.RESULT_02;
                    } else if (hasNameChangeTarget) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                    } else {
                        judgeResult = JudgeResultStatus.RESULT_03;
                    }
                    break;
                }
                // 更新対象の取引ぶり判定
                case 'acceptCheckForUpdateCif': {
                    this.acceptCheckForUpdateCif(entity, pageIndex);
                    break;
                }
                // カード発行の有無判定
                case 'isCardIssuance': {
                    judgeResult = JudgeResultStatus.RESULT_0;
                    // スワイプCIFに対する判定
                    if (this.state.submitData.isNameChange &&
                        (this.state.submitData.swipeCifAcceptCheckResult.account.cdHoldingStatus === CdHoldingStatus.HOLDING ||
                        this.state.submitData.swipeCifAcceptCheckResult.account.bcHoldingStatus === BcHoldingStatus.HOLDING)) {
                            judgeResult = JudgeResultStatus.RESULT_1;
                    }
                    // 氏名変更対象CIFに対する判定
                    if (this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                        this.state.submitData.nameidentiNameDifCifAcceptCheckResult.forEach((acceptResult) => {
                            if (acceptResult.accounts.cdHoldingStatus === CdHoldingStatus.HOLDING ||
                                    acceptResult.accounts.bcHoldingStatus === BcHoldingStatus.HOLDING) {
                                        judgeResult = JudgeResultStatus.RESULT_1;
                            }
                        });
                    }
                    break;
                }

                // 氏名変更のあるCIFにて、ワンセットカードを保有チェック
                case 'hasOneSetCardCheck': {
                    const accountInfos: AccountInfo[] = [];
                    let osCustomerId: String;
                    this.state.submitData.mediumInfos.mediumInfo.forEach((element) => {
                        // 氏名差分情報から、対象CIFを抽出
                        // customerIdは一意のため、抽出した配列の先頭になる
                        const difItem = this.state.submitData.nameDifferenceInfos.filter(
                            (item) => item.customerId === element.customerId)[0];
                        if (element.accountInfo) {
                            element.accountInfo.forEach((account) => {
                                if (!difItem) {
                                    if (account.osStatus === OsStatus.OS_STATUS_ON &&
                                        (this.state.submitData.isNameChange && this.state.submitData.customerId === element.customerId)) {
                                        // ワンセットカード保有口座情報を格納
                                        const accountInfo: AccountInfo = {
                                            branchName: account.branchName,
                                            branchNo: account.tenban,
                                            accountType: account.accountType,
                                            accountNo: account.accountNo
                                        };
                                        accountInfos.push(accountInfo);
                                    }
                                } else {
                                    if (account.osStatus === OsStatus.OS_STATUS_ON && difItem.isDifference) {
                                        // ワンセットカード保有口座情報を格納
                                        const accountInfo: AccountInfo = {
                                            branchName: account.branchName,
                                            branchNo: account.tenban,
                                            accountType: account.accountType,
                                            accountNo: account.accountNo
                                        };
                                        accountInfos.push(accountInfo);
                                    }
                                }
                            });
                            if (accountInfos.length > 0 && !osCustomerId) {
                                osCustomerId = element.customerId;
                                this.action.setStateSubmitDataValue([
                                    {
                                        key: 'oneSetAccountInfo',
                                        value: {
                                            customerId: element.customerId,
                                            accounts: accountInfos
                                        }
                                    }
                                ]);
                            }
                        }
                    });
                    if (accountInfos.length === 0) {
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'oneSetAccountInfo',
                                value: undefined
                            }
                        ]);
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'isOneSetCardModify',
                                value: false
                            }
                        ]);
                    }
                    judgeResult = this.state.submitData.oneSetAccountInfo ? JudgeResultStatus.HAVE : JudgeResultStatus.NOT_HAVE;
                    if (this.state.submitData.savingAccountFirstPwd4bits && judgeResult === JudgeResultStatus.NOT_HAVE) {
                        this.action.clearOneSetCardPassword();
                    }
                    break;
                }
                // 保有媒体のチェック
                case 'ownedMediaCheck': {
                    judgeResult = JudgeResultStatus.NOT_SECESSION;
                    if (this.state.submitData.mediumInfos.doubleBc === DoubleBcStatus.DOUBLE_BC_STATUS_ON ||
                        this.state.submitData.mediumInfos.doubleOs === DoubleOsStatus.DOUBLE_OS_STATUS_ON) {
                        // 複数CIFにバンクカード、または複数CIFにワンセットカード、または1CIFに複数ワンセットカードがある場合
                        judgeResult = JudgeResultStatus.SECESSION;
                        break;
                    }
                    this.state.submitData.mediumInfos.mediumInfo.forEach((mediumElement) => {
                        if (mediumElement.accountInfo) {
                            mediumElement.accountInfo.forEach((account) => {
                                if (account.mcStatus === McStatus.MC_STATUS_ON && account.icStatus === IcStatus.IC_STATUS_ON) {
                                    // 同じ口座にMCとICがある場合
                                    judgeResult = JudgeResultStatus.SECESSION;
                                } else if (account.mcStatus === McStatus.MC_STATUS_ON && account.bcStatus === BcStatus.BC_STATUS_ON) {
                                    // 同じ口座にMCとBCがある場合
                                    judgeResult = JudgeResultStatus.SECESSION;
                                } else if (account.icStatus === IcStatus.IC_STATUS_ON && account.bcStatus === BcStatus.BC_STATUS_ON) {
                                    // 同じ口座にICとBCがある場合
                                    judgeResult = JudgeResultStatus.SECESSION;
                                } else if (account.icStatus === IcStatus.IC_STATUS_ON && account.osStatus === OsStatus.OS_STATUS_ON) {
                                    // 同じ口座にICとワンセットカードがある場合
                                    judgeResult = JudgeResultStatus.SECESSION;
                                } else if (account.mcStatus === McStatus.MC_STATUS_ON && account.osStatus === OsStatus.OS_STATUS_ON) {
                                    // 同じ口座にMCとワンセットカードがある場合
                                    judgeResult = JudgeResultStatus.SECESSION;
                                }
                            });
                        }
                    });
                    break;
                }
                // ワンセットカードの暗証番号設定済みかないかの判定
                case 'isPasswordSet': {
                    judgeResult = this.state.submitData.savingAccountFirstPwd4bits ?
                    JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                // ワンセットカード修正チャットであるかの判定
                case 'isOneSetCardModify': {
                    judgeResult = this.state.submitData.isOneSetCardModify ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                // 氏名変更&差分の有無
                case 'hasNameChangeOrDifference': {
                    judgeResult = this.state.isNameDifference || this.state.submitData.isNameChange ?
                    JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                    break;
                }
                // 氏名の修正ボタンを押下したとき
                case 'isModify': {
                    judgeResult = JudgeResultStatus.RESULT_0;
                    if (changeState.submitData.pressButtonType === 'existingChangeHolderName') {
                        // 氏名の修正ボタンを押下したとき
                        // 無条件で受付可否チェックを実行する
                        judgeResult = JudgeResultStatus.RESULT_1;
                    }
                    break;
                }
                // スワイプCIFの取引ぶりを判定
                case 'acceptCheckForSwipeCif': {
                    judgeResult = JudgeResultStatus.RESULT_02;
                    level = this.changeUtils.getTransactionLevel(
                        this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                    // ジュニアNISA対応
                    const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(this.state.submitData.birthdate,
                        this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                    if (level.levelOne || isHaveJuniorNisa) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                    }
                    break;
                }
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        }
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                if (entity.name !== 'nextButton') {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }
            }

            if (answer.action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
                this.modalService.showModal(answer.action.value, { imgSrc: answer.action.imgSrc });
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else {
                this.chatFlowAccessor.clearComponent();
                if (entity.name !== 'nextButton') {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.text }
                        ]
                    });
                }
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {

        const choices = entity.choices;
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getExistingSavingChangeDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            fullwidthHalfwidthDivisionCode: entity.fullwidthHalfwidthDivisionCode
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (entity.fullwidthHalfwidthDivisionCode === 1 && answer !== COMMON_CONSTANTS.SIGN_SKIP) {
                    this.store.unregisterSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK);
                    // 文字チェックが失敗するときに、httpserviceの共通処理で処理するので、ここにこない。
                    this.store.registerSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK, () => {
                        // 文字チェック成功に来る場合
                        this.store.unregisterSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK);
                        // 処理の継続
                        this.getNextChatByKeyboard(entity, answer, pageIndex);
                    });

                    // 文字チェックを始まる
                    const loginStore = InjectionUtils.injector.get(LoginStore);
                    const params = {
                        tabletApplyId: loginStore.getState().tabletApplyId,
                        params: {
                            receptionTenban: loginStore.getState().belongToBranchNo,
                            checkStrings: [{
                                checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                checkString: answer.text
                            }]
                        }
                    };
                    this.action.characteCheck(params, () => {
                        const chats = this.state.showChats.splice(-1, 1);
                        if (chats && chats.length > 0) {
                            const chat = chats[0];
                            this.action.getNextChatByAnswer(chat.order, pageIndex);
                        }
                    });
                } else if (entity.name === 'existingChangeHolderNameAlphabet') {
                    // 英字氏名を大文字に固定する
                    answer.text = answer.text.toUpperCase();
                    answer.value[0].value = answer.value[0].value.toUpperCase();
                    answer.value[1].value = answer.value[1].value.toUpperCase();
                    this.getNextChatByKeyboard(entity, answer, pageIndex);
                } else {
                    // 処理の継続
                    this.getNextChatByKeyboard(entity, answer, pageIndex);
                }
            });
    }

    /**
     * 保有通帳・印鑑情報照会APIを実行
     * @param entity
     * @param pageIndex
     */
    public onRequestMediumInfo(entity: ExistingSavingsQuestionsModel, pageIndex: number) {

        // APIの入力パラメータ設置
        const param = new MediumInfosRequest(
            Number(this.loginState.tabletApplyId),
            this.loginState.belongToBranchNo,
            this.state.submitData.allCifInfos
        );
        this.store.registerSignalHandler(ExistingSavingsSignal.GET_MEDIUM_INFO, () => {
            this.store.unregisterSignalHandler(ExistingSavingsSignal.GET_MEDIUM_INFO);
            this.getNextChat(entity.next, pageIndex, Constants.NO_WAITING_TIME);
         });
        this.action.getMediumInfo(param);
    }

    public onPassword(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            birthday: this.state.submitData.birthdate,
            birthdayText: this.state.submitData.birthdateWithAge,
            telephone: [
                this.state.submitData.holderTelNo1,
                this.state.submitData.holderTelNo2,
                this.state.submitData.holderTelNo3,
                this.state.submitData.holderMobileNo,
                this.state.submitData.holderTelephoneNo
            ],
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PasswordInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onVerificationDocumentImgJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        let isAllCif: boolean;
        switch (entity.name) {
            case 'allCif': {
                isAllCif = true;
                break;
            }
            case 'difCif': {
                isAllCif = false;
                break;
            }
        }

        const params = {
            isAllCif: isAllCif,
            isChange: this.state.submitData.isNameChange,
            isDifference: this.state.isNameDifference,
            allCifTradingConditions: this.state.submitData.allCifTradingConditions,
            identiDifCifAcceptCheckResult: this.state.submitData.nameidentiNameDifCifAcceptCheckResult
        };
        this.action.setStateSubmitDataValue([
            {
                key: 'nameIdentityDocumentImg',
                value: this.changeUtils.verificationNameDocumentImgJudge(params)
            }
        ]);
        this.getNextChat(entity.next, pageIndex);
    }

    public onChangeContent(entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        this.getNextChat(entity.next, pageIndex);
    }

    /**
     * Request customer status
     * @param entity entity
     */
    public requestSwipeCifStatus(entity: ExistingSavingsQuestionsModel, pageIndex: number) {

        // スワイプCIFの受付可否チェック
        const params = {
            receptionTenban: this.loginState.belongToBranchNo,    // 受付店番
            accounts: [{
                customerId: this.state.submitData.customerId    // 顧客番号
            }], // 口座情報
            businessCode: BussinessCode.NAME_MENU_CHANGE, // 業務コード
        };
        const dict = {
            tabletApplyId: this.state.tabletApplyId,
            params: params,
        };

        this.store.registerSignalHandler(ExistingSavingsSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
            // 事故取引禁止注意エラーの場合、注意コードを取得の上エラーモーダルを表示する
            this.store.unregisterSignalHandler(ExistingSavingsSignal.UNACCEPTABLES_NG);
            const errorInfo = this.checkErrorCode(response.errors.data);
            this.showErrorModal(errorInfo);
        });

        this.store.registerSignalHandler(ExistingSavingsSignal.ACCEPT_CHECK_SWIPE_CIF, () => {
            this.store.unregisterSignalHandler(ExistingSavingsSignal.ACCEPT_CHECK_SWIPE_CIF);
            this.getNextChat(entity.next, pageIndex, Constants.NO_WAITING_TIME);
        });

        this.action.acceptCheckForSwipeCif(entity, dict);
    }

    /**
     * judgeの場合、次のチャットへ遷移する制御を行う
     * @param entity
     * @param pageIndex
     * @param result
     */
    private nextChatByJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number, result: string) {
        for (const choice of entity.choices) {
            if (result === choice.value) {
                // 次のチャットを開始させる
                console.log('this.emitMessageRetrivalEvent:' + choice.next);
                this.getNextChat(choice.next, pageIndex, Constants.NO_WAITING_TIME);
                return;
            }
        }
    }

    private acceptCheckForUpdateCif(entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        // 名寄せの氏名更新対象に対して受付可否チェック実施
        this.action.acceptCheckForNameDifCif(this.makeAcceptCheckApiParams(), this.state.submitData.nameDifferenceInfos);

        let judgeResult;
        let level;

        this.store.registerSignalHandler(ExistingSavingsSignal.ACCEPT_TARGET_FOR_NAME_DIF_CIF, (acceptCheckResult: AcceptionResult) => {
            this.store.unregisterSignalHandler(ExistingSavingsSignal.ACCEPT_TARGET_FOR_NAME_DIF_CIF);
            const errMessageArr: Array<{customerId: string, message: string}> = [];
            // レスポンスパラメータの中に、受付可否チェック検出対象がいたら離脱
            for (const item of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                let branchCode: string = '';
                for (const cifInfo of this.state.submitData.allCifInfos) {
                    if (item.customerId === cifInfo.customerId && this.changeUtils.isHostError(item.accounts.errorCode)) {
                        branchCode = cifInfo.customerManagementBranchCode;
                        if (item.accounts.unacceptables && item.accounts.unacceptables.length > 0) {
                            // 受付不可情報がある場合、表示メッセージは「エラー理由 ＋ 事故・取引禁止・注意コード」。
                            for (const acceptItem of item.accounts.unacceptables) {
                                errMessageArr.push({customerId: cifInfo.customerId, message: branchCode + COMMON_CONSTANTS.FULL_COLON
                                    + item.accounts.errorCode + COMMON_CONSTANTS.SPACE + acceptItem.unacceptableCode});
                            }
                        } else {
                            // 受付不可情報がない場合、表示メッセージは「エラー理由」のみ。
                            errMessageArr.push({customerId: cifInfo.customerId, message: branchCode
                                + COMMON_CONSTANTS.FULL_COLON + item.accounts.errorCode});
                        }
                    }
                }
            }
            const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
            let index = 0;
            let isNeedBr = 1;
            let message: string = '';
            let messageBefore: {customerId: string, message: string} = {customerId: undefined, message: undefined};
            if (errMessageArr.length > 0) {
                for (const err of errMessageArr) {
                    if (index === 0) {
                        message = err.message;
                    } else if (messageBefore.customerId === err.customerId &&  maxArr > isNeedBr) {
                        isNeedBr++;
                        message = message + COMMON_CONSTANTS.SLASH + err.message.substring(err.message.length - 3);
                    } else {
                        isNeedBr = 1;
                        message = message + COMMON_CONSTANTS.NEW_LINE + err.message;
                    }
                    index++;
                    messageBefore = err;
                }
                this.showErrorModal(message);
                return;
            }
            judgeResult = JudgeResultStatus.RESULT_1;
            if (this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                this.state.submitData.nameidentiNameDifCifAcceptCheckResult.forEach((acceptResult) => {
                    // ジュニアNISA対応
                    const cifInfo =
                        this.state.submitData.allCifInfos.filter((item) => item.customerId === acceptResult.customerId);
                    const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(cifInfo[0].birthDate,
                        acceptResult.accounts.tradingConditions);
                    level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                    if (level.levelOne || isHaveJuniorNisa) {
                        judgeResult = JudgeResultStatus.RESULT_0;
                    }
                });
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        });
    }

    /**
     * 受付可否チェックパラメータ生成
     */
    private makeAcceptCheckApiParams() {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((element) => {
            this.state.submitData.nameDifferenceInfos.forEach((difItem) => {
                if (element.customerId !== this.state.submitData.customerId &&
                    element.customerId === difItem.customerId && difItem.isDifference) {
                    accounts.push({
                        customerId: element.customerId
                    });
                }
            });
        });

        const acceptCheckApiParams = {
            tabletApplyId: this.state.tabletApplyId,
            params: {
                receptionTenban: this.loginState.belongToBranchNo,
                accounts: accounts,
                businessCode: BussinessCode.NAME_MENU_CHANGE,
            }
        };

        return acceptCheckApiParams;
    }

    private showErrorModal(errorCode: string, callback?: any) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            this.labels.common.error.host.support,
            errorCode, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.chatFlowCompelete(action.value);
        }
    }

    private getNextChatByKeyboard(entity: any, answer: any, pageIndex: number) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            // skipを選択の場合
            this.setAnswer({ text: this.labelService.labels.common.skipjp, value: [] });
            this.action.setStateSubmitDataValue([{key: 'existingChangeHolderName', value: undefined }]);
            this.action.setStateSubmitDataValue([{key: 'existingChangeFirstName', value: undefined }]);
            this.action.setStateSubmitDataValue([{key: 'existingChangeLastName', value: undefined }]);
            if (this.state.submitData.firstNamegana) {
                this.action.setStateSubmitDataValue([{key: 'existingChangeHolderNameFurigana', value: undefined }]);
                this.action.setStateSubmitDataValue([{key: 'existingChangeFirstNameKana', value: undefined }]);
                this.action.setStateSubmitDataValue([{key: 'existingChangeLastNameKana', value: undefined }]);
            }
            this.getNextChat(entity.skip, pageIndex);
        } else {
            // 文字とフリガナによって、カタカナを転換する
            InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                const needSpace = InputUtils.needAddSpace(answer.value[0].key);
                if (needSpace) { // 全角スペース必要かを判断する
                    const text = answer.value[0].value + COMMON_CONSTANTS.FULL_SPACE + answer.value[1].value;
                    this.setAnswer({
                        text: text,
                        value: [...results, { key: entity.name, value: text }]
                    });
                } else {
                    this.setAnswer({
                        text: answer.text,
                        value: [...results, { key: entity.name, value: answer.text }]
                    });
                }
                this.getNextChat(entity.next, pageIndex);
            });
        }
    }

    /**
     * スワイプCIF専用のエラーメッセージ作成処理
     */
    private checkErrorCode(acceptCheckResult: AcceptionResult) {
        let errorInfo: any;
        let isNeedBr = 1;
        let index = 0;
        const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        for (const account of acceptCheckResult.accounts) {
            if (this.changeUtils.isHostError(account.errorCode)) {
                let unacceptables = '';
                const swipeCifInfo =
                    this.state.submitData.allCifInfos.filter((cifInfo: CifInfo) => cifInfo.customerId === this.state.submitData.customerId);
                errorInfo = swipeCifInfo[0].customerManagementBranchCode + COMMON_CONSTANTS.FULL_COLON + account.errorCode;

                for (const unacceptable of account.unacceptables) {
                    unacceptables = unacceptable.unacceptableCode;
                    if (index === 0) {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SPACE + unacceptables;
                    } else if (isNeedBr > maxArr) {
                        // 1行に最大3つの注意コードを表示する
                        // 超える場合は改行して店番＋エラー情報＋注意コードを表示する
                        errorInfo = errorInfo + COMMON_CONSTANTS.NEW_LINE + errorInfo.slice(0, 14) + unacceptables;
                        isNeedBr = 1;
                    } else {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SLASH + unacceptables;
                    }
                    index++;
                    isNeedBr++;
                }
            }
        }
        return errorInfo;
    }
}
