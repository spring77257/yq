import { ViewContainerRef } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import { SavingsSignal, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    AgentInternalError, ChatOption, COMMON_CONSTANTS, NameNonConvert,
    StoreChanged
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ErrorUtils } from 'dhdt/branch/shared/utils/error-utils';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
/**
 * Self Saving Shop Confirm component(普通(貯蓄)預金 - スワイプあり口座開設店舗確認画面).
 */
export class ExistingSavingsBranchConfirmRenderer extends ExistingSavingsChatFlowRenderer {

    public processType = 1;

    private backupDataService: BackupDataService;

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private audioService: AudioService,
        private modalService: ModalService
    ) {
        super();
        this.backupDataService = InjectionUtils.injector.get(BackupDataService);

    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-existing-savings-branch-confirm.yml', pageIndex);
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'selectBranch': {
                this.onSelectBranch(question, pageIndex);
                break;
            }
            case 'request': {
                this.onRequest(question, pageIndex);
                break;
            }
        }
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        const submitData = this._store.getState().submitData;
        if (entity.choices) {
            switch (entity.name) {
                // 名前の聴取済かにより分岐
                case 'isChangeStore': {
                    // '00'理由入力なし　'01'理由入力必要
                    const cardBranchNo = submitData.cardInfo.branchNo;
                    // 受付店以外⇒受付店に口座開設店舗を修正した場合  受付店以外⇒受付店以外へ口座開設店舗を修正した場合
                    if (!submitData.changeStoreFlg
                        || (submitData.changeStoreFlg === StoreChanged.YES && submitData.savingBranchReason)) {
                        judgeResult = '00';
                    } else if (!submitData.savingBranchReason
                        && submitData.changeStoreFlg === StoreChanged.YES) {
                        judgeResult = '01';
                    }
                    // 確認画面の修正済みを表示するため
                    this._action.setStateSubmitDataValue([{ key: 'storeChangeFlg', value: judgeResult }]);
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                default : {
                    const choice = entity.choices.find((item) => {
                        return item.value === submitData[entity.name];
                    });
                    this.getNextChat(choice ? choice.next : entity.next, pageIndex);
                }
            }
        }
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            options.furiganaOnly = ChatOption.VALIDATION_ON;
            options.kanaText = this.backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value }
                    ]
                });
            }
            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onSelectBranch(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxColNum: 2
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectBranchComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            // 選択された支店を設定
            this._action.changeOpenStore(answer, this._store.getState().submitData);
            // 店舗変換後に純新規になる場合は、以下のチェックします。当てはまる場合はN-005エラーを表示
            // ・変換後のcustomerIdが存在しない
            // ・&& 氏名に漢字変換不可フラグある
            if (!InputUtils.getCustomerIdWithChange(this._store.getState().submitData)
                && this._store.getState().submitData.nameNonConvert === NameNonConvert.OFF) {
                this.showErrorModal(AgentInternalError.ERROR_CODE_N_005);
            } else {
                this.getNextChat(entity.next, pageIndex);
            }
        });
    }

    public onKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {

        const options = {
            validationRules: entity.validationRules,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    this.getNextChat(entity.next, pageIndex);
                });
            });
    }

    /**
     * APIリクエスト送信
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onRequest(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const existingSavingsState = this._store.getState();

        // 店舗変換した　かつ　変換先店舗にCIF情報がある場合
        // 新いcustomerIdを使って、受付チェックを実施します
        if (existingSavingsState.submitData.changeStoreFlg === StoreChanged.YES
            && existingSavingsState.submitData.customerIdChanged) {
            const savingsStore = InjectionUtils.injector.get(SavingsStore);
            const savingsState = savingsStore.getState();
            const savingsAction = InjectionUtils.injector.get(SavingsAction);
            const loginStore = InjectionUtils.injector.get(LoginStore);

            // 受付可否チェック（喪失・破損）の実行後処理を定義
            savingsStore.registerSignalHandler(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK, () => {
                savingsStore.unregisterSignalHandler(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK);

                // 情報取得後、チェックNGの場合はエラーモーダル、チェックOKの場合は次チャットへ遷移
                if (savingsState.submitData.responseForModal) {
                    ErrorUtils.errorHandling(
                        savingsState.submitData.responseForModal,
                        savingsState.submitData.allCifInfos,
                        this.modalService, this._labels);
                } else {
                    this.getNextChat(entity.next, pageIndex);
                }
            });

            // 店舗変換後のCIF情報の顧客番号をキーに受付可否チェックを行う
            const account = {
                tenban: null,
                accountType: null,
                accountNo: null,
                customerId: existingSavingsState.submitData.customerIdChanged
            };

            // 受付可否チェック（喪失・破損）を実行
            savingsAction.receptionLossCorruptionCheck({
                tabletApplyId: Number(loginStore.getState().tabletApplyId),
                params: {
                    receptionTenban: loginStore.getState().belongToBranchNo,
                    accounts: [
                        {
                            tenban: account.tenban,
                            accountType: account.accountType,
                            accountNo: account.accountNo,
                            customerId: account.customerId
                        }
                    ],
                    // 業務コード
                    businessCode: '01'
                }
            });
        } else {
            // 店舗変換していない　まだ　変換先店舗にCIF情報がない場合
            // 次のチャットに進む、何もしない
            this.getNextChat(entity.next, pageIndex);
        }
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }

    private showErrorModal(errorInfo: any, callback?: any) {
        const labels = InjectionUtils.injector.get(LabelService).labels;
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            labels.common.error.host.support,
            errorInfo, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }

    private goToNextChat(entity: ExistingSavingsQuestionsModel, judgeResult: string, pageIndex: number) {
        entity.choices.forEach((choice) => {
            if (judgeResult === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }
}
