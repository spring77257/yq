import { EventEmitter, Output, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { InjectionUtils } from 'adep/utils';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { ExistingSavingsStore } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { Content } from 'ionic-angular';

export interface OnRenderer {
    onText?(entity: ExistingSavingsQuestionsModel, pageIndex: number): void;
    onButton?(entity: ExistingSavingsQuestionsModel, pageIndex: number): void;
    onKeybord?(entity: ExistingSavingsQuestionsModel, pageIndex: number): void;
    onNumberKeybord?(entity: ExistingSavingsQuestionsModel, pageIndex: number): void;
    onRoute?(entity: ExistingSavingsQuestionsModel, pageIndex: number): void;
    onJudge?(entity: ExistingSavingsQuestionsModel, pageIndex: number): void;
}

/**
 * chat flow renderer.
 */
export abstract class ExistingSavingsChatFlowRenderer extends BaseComponent implements OnRenderer {
    public abstract processType: number;
    public _action: ExistingSavingsAction;
    public _store: ExistingSavingsStore;
    @Output() public nextChatEvent = new EventEmitter();
    @ViewChild(Content) public content: Content;

    constructor() {
        super();
        this._action = InjectionUtils.injector.get(ExistingSavingsAction);
        this._store = InjectionUtils.injector.get(ExistingSavingsStore);

    }

    public abstract loadTemplate(pageIndex: number);

    public onText(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        this.getNextChat(entity.next, pageIndex);
    }

    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onButton');
    }

    public onKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onKeybord');
    }

    public onNumberKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onNumberKeybord');
    }

    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onJudge');
    }

    /**
     * Called when message type is 'needpassword'
     * Should be override in sub classes
     * @param entity params
     * @param pageIndex index in current chat flow
     */
    public onPassword(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onPassword');
    }

    /**
     * Called when message type is 'picker'
     * Should be override in sub classes
     * @param entity params
     * @param pageIndex index in current chat flow
     */
    public onPicker(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onPicker');
    }

    /**
     * Called when message type is 'select street'
     * Should be override in sub classes
     * @param entity params
     * @param pageIndex index in current chat flow
     */
    public onSelectStreet(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onSelectStreet');
    }

    /**
     * Called when message type is 'select street'
     * Should be override in sub classes
     * @param entity params
     * @param pageIndex index in current chat flow
     */
    public onAccountInfoInput(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onAccountInfoInput');
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        switch (question.type) {
            case 'text': {
                this.onText(question, pageIndex);
                break;
            }
            case 'button': {
                this.onButton(question, pageIndex);
                break;
            }
            case 'image': {
                this.getNextChat(question.next, pageIndex);
                break;
            }
            case 'judge': {
                this.onJudge(question, pageIndex);
                break;
            }
            case 'keybord': {
                this.onKeybord(question, pageIndex);
                break;
            }
            case 'numberKeybord': {
                this.onNumberKeybord(question, pageIndex);
                break;
            }
            case 'route': {
                this.chatFlowCompelete(question.example, question.options);
                this.getNextChat(question.next, pageIndex);
                break;
            }
            case 'selectStreet': {
                this.onSelectStreet(question, pageIndex);
                break;
            }
            case 'prefecturePicker':
            case 'countyUrbanVillagePicker': {
                this.onPicker(question, pageIndex);
                break;
            }
            case 'needpassword': {
                this.onPassword(question, pageIndex);
                break;
            }
            case 'accountInfoInput': {
                this.onAccountInfoInput(question, pageIndex);
                break;
            }
            case 'saveSubmit': {
                this.onSaveSubmit(question, pageIndex);
                break;
            }
            case 'itemList': {
                this.getNextChat(question.next, pageIndex);
                break;
            }
        }
    }

    /**
     * チャットについてジャンプ
     * @param order メッセージの番号
     * @param pageIndex ページの番号
     */
    protected getNextChat(order: number, pageIndex: number, nextChatDelay?: number) {
        this.nextChatEvent.emit({ order: order, pageIndex: pageIndex, nextChatDelay: nextChatDelay});
    }

    /**
     * チャットについて賦値
     * @param answer ダイアログ賦値
     */
    protected setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this._action.setAnswer(answer);
    }

    /**
     * yml file ends and jumps to another yml file.
     * @param nextChatName The name of the yml file to jump to
     */
    protected chatFlowCompelete(nextChatName?: string, options: any = null) {
        this._action.chatFlowCompelete(nextChatName, options);
    }

    public onSaveSubmit(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onSaveSubmit');
    }

    protected chatFlowReturn(nextChatName?: string, options: any = null) {
        this._action.chatFlowReturn(nextChatName, options);
    }
}
