import { ViewContainerRef } from '@angular/core';
import {
    BcHoldingStatus, JudgeResultStatus, LossCardStatus, ScreenTransition, TheftCardStatus
} from 'dhdt/branch/pages/change/change-consts';
import { CardClass, CardType, COMMON_CONSTANTS, CountryCode, IdentificationCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { HoldingCardInfo } from 'dhdt/branch/pages/common/entity/medium-infos-response.entity';
import { MaxLength } from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import {
    ExistingSavingsState, ExistingSavingsStore
} from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { PrintNameInputComponent } from 'dhdt/branch/shared/components/print-name-input/print-name-input.component';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { KanaToRomaji } from 'dhdt/branch/shared/utils/kana-to-romaji-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

export class ExistingSavingsChangeAddCheckRenderer extends ExistingSavingsChatFlowRenderer {
    public processType: number = COMMON_CONSTANTS.ProcessType.BankClerkConfirm;
    private state: ExistingSavingsState;
    private swipedCifKanaNameDiffFlg: boolean = false;
    private kanaNameDiffInfos: string[] = [];

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private action: ExistingSavingsAction,
        private store: ExistingSavingsStore,
        private footerContent: ViewContainerRef,
    ) {
        super();
        this.state = this.store.getState();
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-existing-savings-change-add-check-confirmation.yml', pageIndex);
        if (this.state.submitData.existingChangeFirstNameKana) {
            this.action.setStateSubmitDataValue([
                {
                    key: 'existingChangeHolderNameFurigana',
                    value: this.state.submitData.existingChangeFirstNameKana + '　' + this.state.submitData.existingChangeLastNameKana
                }
            ]);
        }
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'printName': {
                this.onPrintName(question, pageIndex);
                break;
            }
        }
    }

    public onPrintName(entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        let firstNameRoma: string = '';
        let lastNameRoma: string = '';

        if (this.state.submitData.firstNameRoma) {
            firstNameRoma = this.state.submitData.firstNameRoma;
            lastNameRoma = this.state.submitData.lastNameRoma;
        } else {
            if (this.state.submitData.nationalityCode === CountryCode.Japan) {
                const kanaToRomaji = new KanaToRomaji();
                if (this.state.submitData.existingChangeFirstNameKana) {
                    firstNameRoma = kanaToRomaji.convert(StringUtils.convertHankaku2Zankaku(
                        this.state.submitData.existingChangeLastNameKana));
                    lastNameRoma = kanaToRomaji.convert(StringUtils.convertHankaku2Zankaku(
                        this.state.submitData.existingChangeFirstNameKana));
                } else {
                    const names = this.state.submitData.nameKana.split(COMMON_CONSTANTS.FULL_SPACE);
                    firstNameRoma = kanaToRomaji.convert(StringUtils.convertHankaku2Zankaku(names[1]));
                    lastNameRoma = kanaToRomaji.convert(StringUtils.convertHankaku2Zankaku(names[0]));
                }
            } else {
                if (this.state.submitData.existingChangeFirstNameAlphabet) {
                    firstNameRoma = this.state.submitData.existingChangeLastNameAlphabet;
                    lastNameRoma = this.state.submitData.existingChangeFirstNameAlphabet;
                } else {
                    const names = this.state.submitData.nameAlphabet.split(COMMON_CONSTANTS.SPACE);
                    firstNameRoma = names[1];
                    lastNameRoma = names[0];
                }
            }
        }

        const options = {
            validationRules: entity.validationRules,
            defaultValues: [firstNameRoma + ' ' + lastNameRoma, ''],
            maxLength: MaxLength.MAX_LENGTH_19,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PrintNameInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer.text.indexOf(COMMON_CONSTANTS.HALF_POINT_NO_SPACE) !== -1) {
                    answer.text = answer.text.replace(/\./g, COMMON_CONSTANTS.FULL_POINT);
                }
                // 最初の半角スペースによってローマ字氏名を分割する。
                // 前の部分をfirstNameRomaとして、後ろの部分はlastNameRomaとして
                const fullNameRoma = answer.value[0].value;
                const firstSpaceIndex = fullNameRoma.indexOf(COMMON_CONSTANTS.SPACE);
                const inputFirstNameRoma = fullNameRoma.substring(0, firstSpaceIndex);
                const inputLastNameRoma = fullNameRoma.substring(firstSpaceIndex + 1);
                const answerValue = [
                    {
                        key: 'firstNameRoma',
                        value: inputFirstNameRoma
                    },
                    {
                        key: 'lastNameRoma',
                        value: inputLastNameRoma
                    },
                ];
                this.setAnswer({ text: answer.text, value: answerValue });
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        let judgeResult: string = JudgeResultStatus.RESULT_02;

        switch (entity.name) {
            case 'bcCardType':
                // バンクカードチェック
                if (this.swipedCifKanaNameDiffFlg && this.state.submitData.swipeCifAcceptCheckResult.
                    account.bcHoldingStatus === BcHoldingStatus.HOLDING) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                        break;
                }
                bcCardType:
                for (const element of this.kanaNameDiffInfos) {
                    for (const item of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                        if (element === item.customerId && item.accounts.bcHoldingStatus === BcHoldingStatus.HOLDING) {
                            judgeResult = JudgeResultStatus.RESULT_01;
                            break bcCardType;
                        }
                    }
                }
                break;
            case 'bcSuicaCardType':
                // BC suicaチェック
                if (this.swipedCifKanaNameDiffFlg && this.state.submitData.swipeCifAcceptCheckResult.
                    account.bcSuicaHoldingStatus === BcHoldingStatus.HOLDING) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                        break;
                }
                bcSuicaCardType:
                for (const element of this.kanaNameDiffInfos) {
                    for (const item of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                        if (element === item.customerId && item.accounts.bcSuicaHoldingStatus === BcHoldingStatus.HOLDING) {
                            judgeResult = JudgeResultStatus.RESULT_01;
                            break bcSuicaCardType;
                        }
                    }
                }
                break;
                case 'bcSuicaLossDeclared':
                    // BCバンクカードSuicaは喪失届出済であるかないか
                    // 01: 喪失届出済 02: 喪失未済\
                    judgeResult = JudgeResultStatus.RESULT_02;
                    if (this.swipedCifKanaNameDiffFlg) {
                        // 保有通帳・カード・印鑑情報照会のレスポンスからスワイプCIFを抽出
                        const mediumInfoSwipeCif = this.state.submitData.mediumInfos.mediumInfo.filter(
                            (mediumInfo) => mediumInfo.customerId === this.state.submitData.customerId);
                        if (mediumInfoSwipeCif[0].accountInfo) {
                            for (const accountInfo of mediumInfoSwipeCif[0].accountInfo) {
                                if (accountInfo.holdingCardInfo) {
                                    for (const holdingCardInfo of accountInfo.holdingCardInfo) {
                                        if (this.isBcSuicaLoss(holdingCardInfo)) {
                                            judgeResult = JudgeResultStatus.RESULT_01;
                                            this.action.setBcSuicaLost();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    bcSuicaLossDeclared:
                    for (const element of this.kanaNameDiffInfos) {
                        for (const mediumInfo of this.state.submitData.mediumInfos.mediumInfo) {
                            if (element === mediumInfo.customerId) {
                                if (mediumInfo.accountInfo) {
                                    for (const accountInfo of mediumInfo.accountInfo) {
                                        if (accountInfo.holdingCardInfo) {
                                            for (const holdingCardInfo of accountInfo.holdingCardInfo) {
                                                if (this.isBcSuicaLoss(holdingCardInfo)) {
                                                    judgeResult = JudgeResultStatus.RESULT_01;
                                                    this.action.setBcSuicaLost();
                                                    break bcSuicaLossDeclared;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;
            case 'isNameKanaChanged':
                // カナ氏名変更が行われているかの判定(変更前後を半角変換&拗音を大文字変換して比較)
                if (this.state.submitData.existingChangeHolderNameFurigana && StringUtils.converContractedSound2HankakuKata
                    (StringUtils.convertZankaku2Hankaku(this.state.submitData.existingChangeHolderNameFurigana))
                    !== StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku(this.state.submitData.nameKana))) {
                    judgeResult = JudgeResultStatus.RESULT_01;
                    this.swipedCifKanaNameDiffFlg = true;
                }
                if (this.state.isNameDifference) {
                    if (this.state.submitData.existingChangeHolderNameFurigana) {
                        for (const diffInfo of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                            for (const cifInfo of this.state.submitData.allCifInfos) {
                                if ((diffInfo.customerId === cifInfo.customerId) &&
                                    (StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku(cifInfo.kanaName))
                                    !== StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku
                                        (this.state.submitData.existingChangeHolderNameFurigana)))) {
                                    judgeResult = JudgeResultStatus.RESULT_01;
                                    this.kanaNameDiffInfos.push(cifInfo.customerId);
                                }
                            }
                        }
                    } else {
                        for (const diffInfo of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                            for (const cifInfo of this.state.submitData.allCifInfos) {
                                if (diffInfo.customerId === cifInfo.customerId &&
                                    StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku(cifInfo.kanaName))
                                    !== StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku
                                        (this.state.submitData.nameKana))) {
                                    judgeResult = JudgeResultStatus.RESULT_01;
                                    this.kanaNameDiffInfos.push(cifInfo.customerId);
                                }
                            }
                        }
                    }
                }
                break;
            // 届出変更の有無により分岐
            case 'hasChange': {
                const isChanged = this.state.submitData.isNameChange || this.state.submitData.isAddressChange;
                judgeResult = this.state.submitData.existingChangeFlag === '1' || isChanged ?
                    JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                break;
            }
            // 本人確認コードは９９かどうか
            case 'isIdentificationCode99': {
                judgeResult = JudgeResultStatus.RESULT_0;

                const identificationCodeWithChange = InputUtils.getIdentificationCodeWithChange(this.state.submitData);

                // 本人確認コードは９９　また　存在しない
                if (!identificationCodeWithChange || identificationCodeWithChange === IdentificationCode.CODE_99) {
                    judgeResult = JudgeResultStatus.RESULT_1;
                }
                break;
            }
        }
        entity.choices.forEach((choice) => {
            if (judgeResult === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }

    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (answer.action.type === ScreenTransition.BACK_TO_TOP) {
                this.action.chatFlowCompelete(answer.action.value);
            }
            if (entity.name) {
                if ((entity.name === 'canNotIssueCardImmediately' && answer.value === COMMON_CONSTANTS.YML_GENERAL_YES)
                || (entity.name === 'haveFacePhoto' && answer.value === COMMON_CONSTANTS.YML_GENERAL_NO)) {
                    this.action.setMailDelivery();
                }
                this.action.setAnswer({
                    text: answer.text,
                    value: [
                        {key: entity.name, value: answer.value}
                    ]
                });
            }
            this.getNextChat(answer.next, pageIndex);
        });
    }

    /**
     * BCSuicaを保有していて、喪失届済であればtrue
     * @param holdingCardInfo
     */
    private isBcSuicaLoss(holdingCardInfo: HoldingCardInfo) {
        if (holdingCardInfo.cardClass !== CardClass.BANK_CARD) {
            // BCでなかった場合はfalseを返却
            return false;
        }

        if (!(holdingCardInfo.cardType === CardType.BC_SUICA ||
            holdingCardInfo.cardType === CardType.BC_SUICA_GOLD ||
            holdingCardInfo.cardType === CardType.BC_YOUNG_GOLD_SUICA)) {
            // BCSuicaまたはBCSuicaGOLDでない場合はfalseを返却
            return false;
        }

        if (!holdingCardInfo.unacceptableInfo ||
            (holdingCardInfo.unacceptableInfo.lossCardStatus === LossCardStatus.NOT_LOSS &&
                holdingCardInfo.unacceptableInfo.theftCardStatus === TheftCardStatus.NOT_THEFT)) {
            // カード喪失済みでない場合はfalseを返却
            return false;
        } else {
            // カード返却済の時はtrueを返却
            return true;
        }

    }
}
