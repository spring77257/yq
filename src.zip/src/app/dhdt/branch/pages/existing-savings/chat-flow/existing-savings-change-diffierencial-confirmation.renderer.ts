import { ViewContainerRef } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { AccountInfo as AccInfo } from 'dhdt/branch/pages/change/entity/change-questions.model';
import { AccountInfo, MediumInfosResponse } from 'dhdt/branch/pages/common/entity/medium-infos-response.entity';

import {
    COMMON_CONSTANTS, LiquidityDeposit
} from 'dhdt/branch/pages/common/branch-tablet-consts';

import { ChangeDocumentImg, Constants as ConstantsChange } from 'dhdt/branch/pages/change/change-consts';
import { LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { JudgeResultStatus, OsStatus } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import { ExistingSavingsState, ExistingSavingsStore } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { ModalController } from 'ionic-angular/components/modal/modal-controller';

import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';

/**
 * 普通預金 既存_普通預金口座開設 変更選択
 */
export class ExistingSavingsChangeDifferencialConfirmationRenderer extends ExistingSavingsChatFlowRenderer {

    public processType = 1;

    private loginStore: LoginStore;
    private state: ExistingSavingsState;
    private modalService: ModalService;
    private labelService: LabelService;
    private loginState: LoginState;
    private modalCtrl: ModalController;

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: ExistingSavingsStore,
        private audioService: AudioService,
        private action: ExistingSavingsAction,
        private changeUtils: ChangeUtils
    ) {
        super();
        this.state = this.store.getState();
        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.modalService = InjectionUtils.injector.get(ModalService);
        this.labelService = InjectionUtils.injector.get(LabelService);
        this.loginState = this.loginStore.getState();
        this.modalCtrl = InjectionUtils.injector.get(ModalController);
    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(COMMON_CONSTANTS.YML_CHAT_FLOW_EXISTING_SAVINGS_CHANGE_DIFFERENCIAL_CONFIRMATION, pageIndex);
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {

            case 'existingChangeContent': {
                this.onExistingChangeContent(question, pageIndex);
                break;
            }
            case 'verificationDocumentImgJudge': {
                this.onVerificationDocumentImgJudge(question, pageIndex);
                break;
            }
            case 'password4bits': {
                this.onPassword(question, pageIndex);
                break;
            }

        }
    }
    public onExistingChangeContent(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        this.action.setNameDifferenceFlg(false);
        this.action.setAddressDifferenceFlg(false);
        this.action.setTelphoneDifferenceFlg(false);
        this.state.submitData.nameDifferenceInfos.forEach((element) => {
            if (element.isDifference) {
                this.action.setNameDifferenceFlg(true);
            }
        });
        this.state.submitData.addressDifferenceInfos.forEach((element) => {
            if (element.isDifference) {
                this.action.setAddressDifferenceFlg(true);
            }
        });
        this.state.submitData.telDifferenceInfos.forEach((element) => {
            if (element.isDifference) {
                this.action.setTelphoneDifferenceFlg(true);
            }
        });
        this.getNextChat(entity.next, pageIndex);
    }
    public onPassword(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            birthday: this.state.submitData.birthdate,
            birthdayText: this.state.submitData.birthdateWithAge,
            telephone: [
                this.state.submitData.holderMobileNo,
                this.state.submitData.holderTelephoneNo
            ],
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PasswordInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onVerificationDocumentImgJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number) {

        this.action.setStateSubmitDataValue([
            {
                key: 'changeIdentityDocumentImg',
                value: this.verificationDocumentImgJudge()
            }
        ]);
        this.getNextChat(entity.next, pageIndex);
    }
    /**
     * 既存新規諸届ありの場合、取引ぶりにより、確認用本人確認書類画像を表示する
     * @param params
     * @returns
     */
    public verificationDocumentImgJudge(): string {
        const needX = this.state.submitData.isHaveNameDif === '1' ? true : false;
        const needA = this.isNeedA();
        const needB = this.isNeedB();
        const needC = this.isNeedC();
        let documentImg: string;
        if (needX && !needA && !needB && !needC) {
            documentImg = this.changeUtils.setChangeIdentityDocumentImg(ChangeDocumentImg.TYPE_X);
        }
        if (needX && needA && needB && needC) {
            documentImg = this.changeUtils.setChangeIdentityDocumentImg(ChangeDocumentImg.TYPE_XABC);
        }
        if (needX && needA && needB && !needC) {
            documentImg = this.changeUtils.setChangeIdentityDocumentImg(ChangeDocumentImg.TYPE_XAB);
        }
        if (needX && needA && !needB && needC) {
            documentImg = this.changeUtils.setChangeIdentityDocumentImg(ChangeDocumentImg.TYPE_XAC);
        }
        if (needX && needA && !needB && !needC) {
            documentImg = this.changeUtils.setChangeIdentityDocumentImg(ChangeDocumentImg.TYPE_XA);
        }
        if (needX && !needA && !needB && needC) {
            documentImg = this.changeUtils.setChangeIdentityDocumentImg(ChangeDocumentImg.TYPE_XC);
        }
        if (!needX && !needA && needB && needC) {
            documentImg = this.changeUtils.setChangeIdentityDocumentImg(ChangeDocumentImg.TYPE_BC);
        }
        if (!needX && !needA && needB && !needC) {
            documentImg = this.changeUtils.setChangeIdentityDocumentImg(ChangeDocumentImg.TYPE_B);
        }
        if (!needX && !needA && !needB && needC) {
            documentImg = this.changeUtils.setChangeIdentityDocumentImg(ChangeDocumentImg.TYPE_C);
        }
        return documentImg;
    }

    public isNeedA() {
        let isNeedA = false;
        if (this.state.submitData.isHaveNameDif === '1' && this.state.submitData.receptionCheckNameDiffResult) {
            this.state.submitData.receptionCheckNameDiffResult.forEach((item) => {
                if (this.changeUtils.isHaveSpecTradingInTarget([ConstantsChange.DBConsts.SpecTransactionCode.loanCreditOwned,
                ], item.accounts.tradingConditions)) {
                    isNeedA = true;
                }
            });
        }
        return isNeedA;

    }

    public isNeedB() {
        let isNeedB = false;
        if (this.state.submitData.isHaveAddressDif === '1') {
            for (const diffInfo of this.state.submitData.allCifAddressDif) {
                if (diffInfo.isDifference && this.state.submitData.allCifReceptionCheckResult) {
                    this.state.submitData.allCifReceptionCheckResult.accounts.forEach((item) => {
                        if (this.changeUtils.isHaveSpecTradingInTarget([ConstantsChange.DBConsts.SpecTransactionCode.other],
                            item.tradingConditions)) {
                            isNeedB = true;
                        }
                    });
                }
            }

        }
        return isNeedB;
    }

    public isNeedC() {
        let isNeedC = false;
        if (this.state.submitData.isHaveNameDif === '1' && this.state.submitData.receptionCheckNameDiffResult) {
            this.state.submitData.receptionCheckNameDiffResult.forEach((item) => {
                if (this.changeUtils.isHaveSpecTradingInTarget([ConstantsChange.DBConsts.SpecTransactionCode.Investment,
                ConstantsChange.DBConsts.SpecTransactionCode.specialDeposit], item.accounts.tradingConditions)) {
                    isNeedC = true;
                }
            });
        }
        if (this.state.submitData.isHaveAddressDif === '1') {
            for (const diffInfo of this.state.submitData.allCifAddressDif) {
                if (diffInfo.isDifference && this.state.submitData.allCifReceptionCheckResult) {
                    this.state.submitData.allCifReceptionCheckResult.accounts.forEach((item) => {
                        if (item.customerId === diffInfo.customerId &&
                            this.changeUtils.isHaveSpecTradingInTarget([ConstantsChange.DBConsts.SpecTransactionCode.Investment,
                            ConstantsChange.DBConsts.SpecTransactionCode.specialDeposit], item.tradingConditions)) {
                            isNeedC = true;
                        }
                    });
                }
            }

        }
        return isNeedC;
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                if (entity.name !== 'nextButton') {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }
            }

            if (answer.action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
                this.modalService.showModal(answer.action.value, { imgSrc: answer.action.imgSrc });
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else {
                this.chatFlowAccessor.clearComponent();
                if (entity.name !== 'nextButton') {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.text }
                        ]
                    });
                }
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        if (entity.choices) {
            switch (entity.name) {
                case 'needDocumentImgJudge': {
                    judgeResult = JudgeResultStatus.RESULT_02;
                    if (this.state.submitData.isHaveNameDif === '1') {
                        judgeResult = JudgeResultStatus.RESULT_01;
                    } else if (this.state.submitData.isHaveAddressDif === '1') {
                        for (const diffInfo of this.state.submitData.allCifAddressDif) {
                            if (diffInfo.isDifference && this.state.submitData.allCifReceptionCheckResult) {
                                this.state.submitData.allCifReceptionCheckResult.accounts.forEach((item) => {
                                    if (item.customerId === diffInfo.customerId &&
                                        this.changeUtils
                                            .isHaveSpecTradingInTarget([ConstantsChange.DBConsts.SpecTransactionCode.Investment,
                                            ConstantsChange.DBConsts.SpecTransactionCode.specialDeposit,
                                            ConstantsChange.DBConsts.SpecTransactionCode.other], item.tradingConditions)) {
                                        judgeResult = JudgeResultStatus.RESULT_01;
                                    }
                                });
                            }
                        }

                    }
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                case 'isCardIssuance': {
                    judgeResult = JudgeResultStatus.RESULT_02;
                    const mediumInfos: MediumInfosResponse = this.state.submitData.mediumInfos;
                    // rbeceptionCheckNameDiffResultは氏名変更対象CIFの受付可否チェック結果
                    for (const diffInfo of this.state.submitData.allCifNameDif) {
                        if (diffInfo.isDifference && mediumInfos.mediumInfo) { // 存在チェック
                            mediumInfos.mediumInfo.forEach(
                                (medium) => {
                                    if (medium.customerId === diffInfo.customerId && medium.accountInfo) { // 存在チェック
                                        medium.accountInfo.forEach(
                                            (account) => {
                                                // 流動性預金かどうかをチェック
                                                if (LiquidityDeposit.LD_SUBJECT_CODE.indexOf(account.accountType) > -1
                                                    && account.holdingCardInfo) {
                                                    // 存在する場合は、カードあるかどうかをチェック
                                                    account.holdingCardInfo.forEach(
                                                        (card) => {
                                                            if (card.cardType) {
                                                                judgeResult = JudgeResultStatus.RESULT_01;
                                                            }
                                                        }
                                                    );
                                                }
                                            }
                                        );
                                    }
                                }
                            );
                        }
                    }
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                // 氏名変更のあるCIFにて、ワンセットカードを保有チェック
                case 'hasOneSetCardCheck': {
                    const accountInfos: AccInfo[] = [];
                    let osCustomerId: String;
                    this.state.submitData.mediumInfos.mediumInfo.forEach((element) => {
                        for (const diffInfo of this.state.submitData.allCifNameDif) {
                            if (diffInfo.isDifference && diffInfo.customerId === element.customerId && element.accountInfo) {
                                element.accountInfo.forEach((account) => {
                                    if (account.osStatus === OsStatus.OS_STATUS_ON) {
                                        // ワンセットカード保有口座情報を格納
                                        const accountInfo: AccInfo = {
                                            branchName: account.branchName,
                                            branchNo: account.tenban,
                                            accountType: account.accountType,
                                            accountNo: account.accountNo
                                        };
                                        accountInfos.push(accountInfo);
                                    }
                                });
                                if (accountInfos.length > 0 && !osCustomerId) {
                                    osCustomerId = element.customerId;
                                    this.action.setStateSubmitDataValue([
                                        {
                                            key: 'oneSetAccountInfo',
                                            value: {
                                                customerId: element.customerId,
                                                accounts: accountInfos
                                            }
                                        }
                                    ]);
                                }
                            }
                        }
                    });
                    if (accountInfos.length === 0) {
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'oneSetAccountInfo',
                                value: undefined
                            }
                        ]);
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'isOneSetCardModify',
                                value: false
                            }
                        ]);
                    }
                    judgeResult = this.state.submitData.oneSetAccountInfo ? JudgeResultStatus.HAVE : JudgeResultStatus.NOT_HAVE;
                    if (this.state.submitData.savingAccountFirstPwd4bits && judgeResult === JudgeResultStatus.NOT_HAVE) {
                        this.action.clearOneSetCardPassword();
                    }
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                // ワンセットカード修正チャットであるかの判定
                case 'isOneSetCardModify': {
                    judgeResult = this.state.submitData.isOneSetCardModify ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                // 空CIF(パターンC)か判定
                // 空CIF(パターンC)でなく名前変更ありの場合、該当チャットを表示する
                // それ以外の場合スキップする
                case 'isOpeningAccountPatternC': {
                    judgeResult = (!this.state.submitData.openingAccountPatternC && this.state.submitData.isHaveNameDif === '1')
                        ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    this.goToNextChat(entity, judgeResult, pageIndex);
                    break;
                }
                default: {
                    const choice = entity.choices.find((item) => {
                        return item.value === this.state.submitData[entity.name];
                    });
                    this.getNextChat(choice ? choice.next : entity.next, pageIndex);
                }
            }
        }
    }

    /**
     * 固定値を保存する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSaveSubmit(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            this.action.setStateSubmitDataValue(entity.choices);
            this.getNextChat(entity.next, pageIndex);
        }
    }

    private goToNextChat(entity: ExistingSavingsQuestionsModel, judgeResult: string, pageIndex: number) {
        entity.choices.forEach((choice) => {
            if (judgeResult === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.chatFlowCompelete(action.value);
        }
    }

}
