import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import {
    AccountType, ApplyBC, ChatOption, COMMON_CONSTANTS, Constants, IdentificationCode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { IdentificationDocument } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import { ExistingSavingsState } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';

/**
 * Self Imgapply component(情報入力画面（本人確認書類聴取）_本人確認書類２の選択).
 */
export class SelfIdentificationDocumentTwo extends ExistingSavingsChatFlowRenderer {

    public processType = 1;

    private state: ExistingSavingsState;

    private backupDataService: BackupDataService;
    private serverInfoService: ServerInfoService;
    private swipedCifKanaNameDiffFlg: boolean;
    private kanaNameDiffInfos: any[];

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private changeUtils: ChangeUtils
    ) {
        super();
        this.state = this._store.getState();
        // this._action.setCustomerApplyStartDate();
        this.backupDataService = InjectionUtils.injector.get(BackupDataService);
        this.serverInfoService = InjectionUtils.injector.get(ServerInfoService);
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-self-identification-document-two.yml', pageIndex);
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'datepicker': {
                this.onPicker(question, pageIndex);
                break;
            }
        }
    }

    public onSaveSubmit(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            this._action.setStateSubmitDataValue(entity.choices);
            this.getNextChat(entity.next, pageIndex);
        }
    }

    public onPicker(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }

        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData,
            skip: {
                text: this.labels.picker.skipExpiryDate,
                width: 224,
                height: 64,
                marginRight: 32,
                marginBottom: 32
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer !== COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            ...answer.value,
                            {
                                key: entity.name + 'Text',
                                value: answer.text
                            }
                        ]
                    });
                } else {
                    this.setAnswer({
                        text: this.labels.picker.skipExpiryDate,
                        value: [{
                            key: entity.name,
                            value: COMMON_CONSTANTS.DEFAULT_EXPIRY_DATE
                        }, {
                            key: entity.name + 'Text',
                            value: this.labels.picker.skipExpiryDate
                        }]
                    });
                }
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            options.furiganaOnly = ChatOption.VALIDATION_ON;
            options.kanaText = this.backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value }
                    ]
                });

                if (/identificationDocument\d/.test(entity.name)) {
                    this._action.setStateSubmitDataValue([{
                        key: entity.name + 'Text',
                        value: answer.text
                    }]);
                }
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        const choices = InputUtils.changeValidationRuleMax(entity, this.state.submitData);

        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    this.getNextChat(entity.next, pageIndex);
                });
            });
    }

    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        const identificationCodeWithChange = InputUtils.getIdentificationCodeWithChange(this.state.submitData);
        const customerIdWithChange = InputUtils.getCustomerIdWithChange(this.state.submitData);
        switch (entity.name) {
            case 'expiryDateJudge': {
                judgeResult = '1';
                const submitData = this.state.submitData;
                if (!StringUtils.isEmpty(customerIdWithChange) &&
                    identificationCodeWithChange !== IdentificationCode.CODE_99) {
                    judgeResult = '0';
                }
                this.goToNextChat(entity, judgeResult, pageIndex);
                break;
            }
            case 'ifAllIdentificationCode80or90': {
                judgeResult = '0';
                if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
                    if (identificationCodeWithChange !== IdentificationCode.CODE_80 &&
                        identificationCodeWithChange !== IdentificationCode.CODE_90) {
                        judgeResult = '1';
                    } else if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
                        judgeResult = '1';
                    }
                } else if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT) {
                    judgeResult = '1';
                }
                this.goToNextChat(entity, judgeResult, pageIndex);
                break;
            }
            case 'identificationDocument1': {
                judgeResult = '0';
                if (this.state.submitData.identificationDocument1 === IdentificationDocument.INSURANCE ||
                    this.state.submitData.identificationDocument1 === IdentificationDocument.PWD_NO_ENTRY_FIELD_OWNER) {
                    judgeResult = '1';
                }
                this.goToNextChat(entity, judgeResult, pageIndex);
                break;
            }
            case 'judgmentOfPassportOrInsurance': {
                judgeResult = '0';
                if (this.state.submitData.identificationDocument1 === IdentificationDocument.INSURANCE) {
                    judgeResult = '1';
                }
                this.goToNextChat(entity, judgeResult, pageIndex);
                break;
            }
            case 'judgmentOfPassportOrOther': {
                judgeResult = this.state.submitData.identificationDocument1 === IdentificationDocument.PWD_NO_ENTRY_FIELD_OWNER ?
                    '1' : '0';
                this.goToNextChat(entity, judgeResult, pageIndex);
                break;
            }
            case 'ifAllIdentificationCode99ForFontCheck': {
                judgeResult = '0';
                if (identificationCodeWithChange !== IdentificationCode.CODE_80 &&
                    identificationCodeWithChange !== IdentificationCode.CODE_90) {
                    judgeResult = '1';
                }
                this.goToNextChat(entity, judgeResult, pageIndex);
                break;
            }
            case 'isNeedIssueCashCard':
                judgeResult = this.changeUtils.isNeedIssueCashCard(this.state.isNameDifference, this.state.submitData) ?
                '01' : '02';
                this.goToNextChat(entity, judgeResult, pageIndex);
                break;
            default:
                const choice = entity.choices.find((item) => {
                    return item.value === this.state.submitData[entity.name];
                });
                this.getNextChat(choice ? choice.next : entity.next, pageIndex);
                break;
        }
    }

    private goToNextChat(entity: ExistingSavingsQuestionsModel, judgeResult: string, pageIndex: number) {
        entity.choices.forEach((choice) => {
            if (judgeResult === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }
}
