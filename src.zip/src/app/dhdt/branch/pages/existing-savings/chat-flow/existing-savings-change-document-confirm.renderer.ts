import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { Constants, IdentificationDocument } from 'dhdt/branch/pages/change/change-consts';
import { COMMON_CONSTANTS, CountryCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatFlowAccessor } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.accessor';
import { ExistingSavingsChatFlowRenderer } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat-flow.renderer';
import { ExistingSavingsQuestionsModel } from 'dhdt/branch/pages/existing-savings/entity/existing-savings-questions.model';
import { JudgeResultStatus } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import {
    ExistingSavingsSignal, ExistingSavingsState, ExistingSavingsStore
} from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ButtonCameraComponent } from 'dhdt/branch/shared/components/button-group/button-camera.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { NavController } from 'ionic-angular';

/**
 * 普通預金口座開設 本人確認書類(届出事項の変更)
 */
export class ExistingSavingsChangeDocumentConfirmRenderer extends ExistingSavingsChatFlowRenderer {

    public processType = 1;
    public options: {
        category: number
    };

    private state: ExistingSavingsState;
    private modalService: ModalService;
    private loginStore: LoginStore;

    constructor(
        private chatFlowAccessor: ExistingSavingsChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: ExistingSavingsStore,
        private audioService: AudioService,
        private action: ExistingSavingsAction,
        private changeUtils: ChangeUtils,
        private navCtrl: NavController,
    ) {
        super();
        this.state = this.store.getState();
        this.modalService = InjectionUtils.injector.get(ModalService);
        this.changeUtils = InjectionUtils.injector.get(ChangeUtils);
        this.loginStore = InjectionUtils.injector.get(LoginStore);
    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(COMMON_CONSTANTS.YML_CHAT_FLOW_EXISTING_SAVINGS_CHANGE_DOCUMENT_CONFIRM, pageIndex);
    }

    public rendererComponents(question: ExistingSavingsQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'cameraButton': {
                this.onCameraButton(question, pageIndex);
                break;
            }
        }
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {

        const choices = entity.choices;
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getExistingSavingChangeDefaultValues(entity.name, this.state.submitData),
            title: entity.options ? entity.options.title : undefined,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            fullwidthHalfwidthDivisionCode: entity.fullwidthHalfwidthDivisionCode
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        if (entity.fullwidthHalfwidthDivisionCode) {
                            this.store.registerSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK, (data) => {
                                this.store.unregisterSignalHandler(ExistingSavingsSignal.CHARACTER_CHECK);
                                this.getNextChat(entity.next, pageIndex);
                            });
                            const params = {
                                tabletApplyId: this._store.getState().tabletApplyId,
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                                    checkStrings: [{
                                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                        checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                    }],
                                }
                            };
                            this._action.characteCheck(params, () => {
                                this._action.editChart(entity.order, pageIndex,
                                    this.state.showChats[this.state.showChats.length - 1].answer.order);
                                this.getNextChat(entity.order, pageIndex);
                            });
                        } else {
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });
                }
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        if (entity.name === 'identificationDocument3C') {
            entity.choices.forEach((choice) => {
                choice.options = {
                    cssClass: '',
                };
            });
        }
        const options = {
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        const changeDocumentImages = this.state.changeDocumentImages;
        let received = [];
        if (changeDocumentImages) {
            received = Object.keys(changeDocumentImages);
        }
        if (entity.name === 'identificationDocument3C') {
            for (const choice of entity.choices) {
                if (received.indexOf(choice.value) !== -1) {
                    choice.options = {
                        cssClass: 'disabled-button',
                    };
                }
            }
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {

            // 撮影書類選択時、書類名を保存
            if (entity.name === 'identificationDocument3X' ||
                entity.name === 'identificationDocument3A' ||
                entity.name === 'identificationDocument3B' ||
                entity.name === 'identificationDocument3C') {
                if (answer === 'skip') {
                    this.action.saveDocumentName({
                        key: entity.name + 'Name',
                        value: ''
                    });
                } else {
                    this.action.saveDocumentName({
                        key: entity.name + 'Name',
                        value: answer.text
                    });
                }
            }

            if (answer === 'skip') {
                this.setAnswer({
                    text: COMMON_CONSTANTS.SKIP_TEXT, value: [
                        { key: entity.name, value: COMMON_CONSTANTS.SKIP_TEXT }
                    ]
                });
                this.getNextChat(entity.skip, pageIndex);
            } else {
                if (answer.action.type.length > 0) {
                    this.configAction(answer, pageIndex);
                } else {
                    this.chatFlowAccessor.clearComponent();
                    if (entity.name !== 'nextButton' && !(entity.name === 'addIdentityDocumentImg' && answer.value === '1')) {
                        this.setAnswer({
                            text: answer.text,
                            value: [
                                { key: entity.name, value: answer.value },
                                { key: answer.name, value: answer.text }
                            ]
                        });
                    }
                    if (entity.name === 'addIdentityDocumentImg' && answer.value === '1') {
                        const choice = entity.choices ? entity.choices.find((item) => item.value === answer.value) : undefined;
                        this._action.resetLastNode({
                            order: choice ? choice.next : entity.order,
                            pageIndex: pageIndex
                        });
                    }
                    if (entity.name === 'identificationDocument3X') {
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'identificationDocument3X',
                                value: answer.value
                            }
                        ]);
                    }
                    if (entity.name === 'identificationDocument3B') {
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'identificationDocument3B',
                                value: answer.value
                            }
                        ]);
                    }
                    if (entity.name === 'identificationDocument3C') {
                        this.action.setStateSubmitDataValue([
                            {
                                key: 'identificationDocument3C',
                                value: answer.value
                            }
                        ]);
                    }
                    this.getNextChat(answer.next, pageIndex);
                }
            }
        });
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        let level;
        const confirmC = ['01', '02', '03', '05', '06', '07', '10', '11', '12', '13',
            '14', '15', '20', '21', '22', '24', '25', '27'];
        const possibleAdressIdentifications = ['01', '02', '03', '13', '05', '06', '07', '11', '15', '20', '21', '22', '27'];
        const hasOtherOfficial = ['24', '25'];
        const confirmAddressA = ['10'];
        const confirmAddressB = ['12', '14'];
        const skipPaperA = ['09', '11'];
        const skipPaperB = ['13', '15'];
        const branchPaperX = ['01', '02', '03', '13', '05', '06', '07', '11', '15', '20', '21', '22', '27', '24', '25'];
        let received = [];
        let hasNameChangeTarget: boolean;
        const changeDocumentImages = this.store.getState().changeDocumentImages;
        if (changeDocumentImages) {
            received = Object.keys(changeDocumentImages);
        }
        if (entity.choices) {
            if (entity.option === 'change') {
                switch (entity.name) {
                    // 氏名変更の有無
                    case 'nameChanged': {
                        if (this.state.submitData.isNameChange) {
                            hasNameChangeTarget = true;
                        } else {
                            this.state.submitData.nameDifferenceInfos.forEach((element) => {
                                if (element.isDifference) {
                                    hasNameChangeTarget = true;
                                }
                            });
                        }
                        judgeResult = hasNameChangeTarget ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                        break;
                    }
                    // 書類パターンA　取引振り
                    case 'isEnterPatternA': {
                        judgeResult = JudgeResultStatus.RESULT_0;
                        if (this.state.submitData.isNameChange) {
                            if (this.changeUtils.isHaveSpecTradingInTarget([
                                Constants.DBConsts.SpecTransactionCode.loanCreditOwned,
                                Constants.DBConsts.SpecTransactionCode.Investment,
                                Constants.DBConsts.SpecTransactionCode.specialDeposit
                            ], this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions)) {
                                judgeResult = JudgeResultStatus.RESULT_1;
                            }
                        }
                        if (this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                            this.state.submitData.nameidentiNameDifCifAcceptCheckResult.forEach((acceptResult) => {
                                level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                                if (level.levelTwo || level.levelThree) {
                                    judgeResult = JudgeResultStatus.RESULT_1;
                                }
                            });
                        }
                        if (this.state.submitData.isAddressChange) {
                            if (this.changeUtils.isHaveSpecTradingInTarget([
                                Constants.DBConsts.SpecTransactionCode.other,
                                Constants.DBConsts.SpecTransactionCode.Investment,
                                Constants.DBConsts.SpecTransactionCode.specialDeposit
                            ], this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions)) {
                                judgeResult = JudgeResultStatus.RESULT_1;
                            }
                        }
                        if (this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                            this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt.forEach((acceptResult) => {
                                level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                                if (level.levelFive || level.levelThree) {
                                    judgeResult = JudgeResultStatus.RESULT_1;
                                }
                            });
                        }
                        break;
                    }
                    // 区切り「次へ」を表示するかどうかの判断
                    // 条件は：①諸届書類X,A,B,Cに入れるかどうか、②既存新規SWなし・諸届あり
                    case 'isShowNext': {
                        judgeResult = JudgeResultStatus.RESULT_0;

                        // 以下は名前変更あるかどうかの条件、judge項目の「case: 'nameChanged'」と同じです
                        if (this.state.submitData.isNameChange) {
                            judgeResult = JudgeResultStatus.RESULT_1;
                        } else {
                            this.state.submitData.nameDifferenceInfos.forEach((element) => {
                                if (element.isDifference) {
                                    judgeResult = JudgeResultStatus.RESULT_1;
                                }
                            });
                        }

                        // 以下は書類A ,B,Cに入るかどうかの条件、judge項目の「case: 'isEnterPatternA'」と同じです
                        if (this.state.submitData.isNameChange) {
                            if (this.changeUtils.isHaveSpecTradingInTarget([
                                Constants.DBConsts.SpecTransactionCode.loanCreditOwned,
                                Constants.DBConsts.SpecTransactionCode.Investment,
                                Constants.DBConsts.SpecTransactionCode.specialDeposit
                            ], this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions)) {
                                judgeResult = JudgeResultStatus.RESULT_1;
                            }
                        }
                        if (this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                            this.state.submitData.nameidentiNameDifCifAcceptCheckResult.forEach((acceptResult) => {
                                level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                                if (level.levelTwo || level.levelThree) {
                                    judgeResult = JudgeResultStatus.RESULT_1;
                                }
                            });
                        }
                        if (this.state.submitData.isAddressChange) {
                            if (this.changeUtils.isHaveSpecTradingInTarget([
                                Constants.DBConsts.SpecTransactionCode.other,
                                Constants.DBConsts.SpecTransactionCode.Investment,
                                Constants.DBConsts.SpecTransactionCode.specialDeposit
                            ], this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions)) {
                                judgeResult = JudgeResultStatus.RESULT_1;
                            }
                        }
                        if (this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                            this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt.forEach((acceptResult) => {
                                level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                                if (level.levelFive || level.levelThree) {
                                    judgeResult = JudgeResultStatus.RESULT_1;
                                }
                            });
                        }

                        // 既存新規SWなし・諸届ありの場合
                        if (!this.state.submitData.selectTenpoCustomerId && (this.state.submitData.isHaveAddressDif === '1'
                            || this.state.submitData.isHaveTelDif === '1')) {
                                judgeResult = JudgeResultStatus.RESULT_1;
                        }
                        break;
                    }
                    // 空CIF(パターンC)か判定
                    // openingAccountPatternCが設定されている場合、空CIFの判定（該当チャットをスキップする）
                    case 'isOpeningAccountPatternC': {
                        judgeResult = this.state.submitData.openingAccountPatternC ?
                            JudgeResultStatus.RESULT_02 : JudgeResultStatus.RESULT_01;
                        break;
                    }
                }
            } else if (entity.option === 'confirm') {
                switch (entity.name) {
                    // 書類Cの撮影が必要な場合02、スキップの場合(書類を未撮影)01
                    case 'confirmC': {
                        judgeResult = '02';
                        if (received) {
                            const matchedCode = [];
                            received.forEach((receive) => {
                                if (confirmC.indexOf(receive) >= 0) {
                                    matchedCode.push(receive);
                                }
                            });
                            // 書類聴取済みの場合
                            if (matchedCode.length > 0) {
                                // 住所変更なしの場合（=氏名変更のみ）、聴取済みのためスキップ
                                if (!this.state.submitData.isAddressChange && !this.state.isAddressDifference) {
                                    judgeResult = '01';
                                    break;
                                }
                                // 住所変更ありの場合
                                // 本人確認書類聴取チャットにてパターンB確認済みの場合、住所確認をスキップする
                                const matchedCodePatternB = [];
                                received.forEach((receive) => {
                                    if (confirmAddressB.indexOf(receive) >= 0) {
                                        matchedCodePatternB.push(receive);
                                    }
                                });
                                if (matchedCodePatternB.length > 0 ||
                                    this.state.submitData.identificationDocument3B === COMMON_CONSTANTS.SKIP_TEXT) {
                                    judgeResult = '01';
                                    break;
                                }
                                // 住所確認が必要の場合
                                judgeResult = JudgeResultStatus.RESULT_03;
                            } else {
                                // 書類未聴取の場合、撮影必要
                                judgeResult = '02';
                            }
                        }
                        break;
                    }
                    case 'nationalityCode': {
                        if (this.state.submitData.nationalityCode) {
                            judgeResult = this.state.submitData.nationalityCode === CountryCode.Japan ? '01' : '02';
                        }
                        break;
                    }
                    case 'isChoicedPaperA': {
                        // 期限のある書類を撮影済みかどうか(パターンA)
                        const matchedCode = [];

                        received.forEach((receive) => {
                            if (skipPaperA.indexOf(receive) >= 0) {
                                matchedCode.push(receive);
                            }
                        });
                        judgeResult = matchedCode.length > 0 ? '01' : '02';
                        break;
                    }
                    case 'isChoicedPaperB': {
                        // 期限のある書類を撮影済みかどうか(パターンB)
                        const matchedCode = [];

                        received.forEach((receive) => {
                            if (skipPaperB.indexOf(receive) >= 0) {
                                matchedCode.push(receive);
                            }
                        });
                        judgeResult = matchedCode.length > 0 ? '01' : '02';
                        break;
                    }
                    // 書類C前の取引振り判断し、必要な場合02、スキップの場合01
                    case 'confirmBeforeC': {
                        judgeResult = '02';
                        if (this.state.submitData.isNameChange) {
                            if (this.changeUtils.isHaveSpecTradingInTarget([
                                Constants.DBConsts.SpecTransactionCode.Investment,
                                Constants.DBConsts.SpecTransactionCode.specialDeposit
                            ], this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions)) {
                                judgeResult = '01';
                            }
                        }
                        if (this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                            this.state.submitData.nameidentiNameDifCifAcceptCheckResult.forEach((acceptResult) => {
                                level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                                if (level.levelThree) {
                                    judgeResult = '01';
                                }
                            });
                        }
                        if (this.state.submitData.isAddressChange) {
                            if (this.changeUtils.isHaveSpecTradingInTarget([
                                Constants.DBConsts.SpecTransactionCode.Investment,
                                Constants.DBConsts.SpecTransactionCode.specialDeposit
                            ], this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions)) {
                                judgeResult = '01';
                            }
                        }
                        if (this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                            this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt.forEach((acceptResult) => {
                                level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                                if (level.levelThree) {
                                    judgeResult = '01';
                                }
                            });
                        }
                        break;
                    }
                    // 書類A前の取引振り判断し、必要な場合01、スキップの場合02
                    case 'isSkipA': {
                        judgeResult = '02';
                        if (this.state.submitData.isNameChange) {
                            if (this.changeUtils.isHaveSpecTradingInTarget([Constants.DBConsts.SpecTransactionCode.loanCreditOwned
                            ], this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions)) {
                                judgeResult = '01';
                            }
                        }
                        if (this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                            this.state.submitData.nameidentiNameDifCifAcceptCheckResult.forEach((acceptResult) => {
                                level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                                if (level.levelTwo) {
                                    judgeResult = '01';
                                }
                            });
                        }
                        break;
                    }
                    // 書類B前の取引振り判断し、必要な場合01、スキップの場合02
                    case 'isSkipB': {
                        judgeResult = '02';
                        if (this.state.submitData.isAddressChange) {
                            if (this.changeUtils.isHaveSpecTradingInTarget([Constants.DBConsts.SpecTransactionCode.other
                            ], this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions)) {
                                judgeResult = '01';
                            }
                        }
                        if (this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                            this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt.forEach((acceptResult) => {
                                level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                                if (level.levelFive) {
                                    judgeResult = '01';
                                }
                            });
                        }
                        break;
                    }
                    // 届出変更の有無により分岐
                    case 'hasChange': {
                        const isChanged = this.state.submitData.isNameChange || this.state.submitData.isAddressChange;
                        judgeResult = this.state.submitData.existingChangeFlag === '1' || isChanged ?
                            JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                        break;
                    }
                    case 'checkDocumentType3X': {
                        // パターンXにてマイナンバー撮影済みかどうか
                        judgeResult = this.state.submitData.identificationDocument3X === IdentificationDocument.MY_NUMBER_CARD ?
                            JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                        break;
                    }
                    // 書類Cで重複聴取あり時、書類Xで住所確認できない場合、
                    // 書類A聴取時は書類Aで住所確認可能か判断し、可能な場合01、不可能な場合02
                    case 'addressConfirmCWithA': {
                        const matchedCode = [];

                        received.forEach((receive) => {
                            if (confirmAddressA.indexOf(receive) >= 0) {
                                matchedCode.push(receive);
                            }
                        });
                        judgeResult = matchedCode.length > 0 ? '01' : '02';
                        break;
                    }
                    case 'checkDocumentType3C': {
                        // パターンCにてマイナンバー撮影済みかどうか
                        judgeResult = this.state.submitData.identificationDocument3C === IdentificationDocument.MY_NUMBER_CARD ?
                            JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                        break;
                    }
                    case 'branchDocumentX': {
                        // 撮影した書類から、Xで撮影した書類コードに合致したものをmatchedCodeに格納する
                        const matchedCode = [];
                        received.forEach((receive) => {
                            if (branchPaperX.indexOf(receive) >= 0) {
                                matchedCode.push(receive);
                            }
                        });
                        const resultOtherOfficial = matchedCode.some((code) => hasOtherOfficial.indexOf(code) >= 0);
                        if (resultOtherOfficial) {
                            // Xで撮影した書類コードが'24'または'25'の場合
                            judgeResult = JudgeResultStatus.RESULT_01;
                            break;
                        } else {
                            // Xで撮影した書類コードが'24','25'以外の場合
                            judgeResult = JudgeResultStatus.RESULT_02;
                            break;
                        }
                    }
                    case 'isCPattern': {
                        judgeResult = JudgeResultStatus.RESULT_0;
                        // 既存新規SWなし・諸届あり
                        // 住所もしくは電話番号をいずれか変更ありかつ書類聴取なしの場合、書類を聴取
                        if (!this.state.submitData.selectTenpoCustomerId && this.state.submitData.isHaveNameDif === '0'
                            && (this.state.submitData.isHaveAddressDif === '1' || this.state.submitData.isHaveTelDif === '1')
                            && this.state.orderChangeDocument.length === 0) {
                                judgeResult = JudgeResultStatus.RESULT_1;
                        }
                        break;
                    }
                }
            }
            entity.choices.forEach((choice) => {
                if (judgeResult === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    public onCameraButton(entity: ExistingSavingsQuestionsModel, pageIndex: number): void {
        let codeXABC = '';
        const options: any = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        // 写真を取ろうする書類の格納変数の値を取得
        codeXABC = this.getCode(entity.name);
        const currentImg = this.state.changeDocumentImages[codeXABC];
        // 書類に写真が存在する場合は、skipを渡す
        if (currentImg && currentImg.length > 0 && entity.skip) {
            options.skip = entity.skip;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonCameraComponent, this.footerContent, options
        ).subscribe((answer: any) => {
            if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                this.setAnswer({
                    text: COMMON_CONSTANTS.SKIP_TEXT,
                    value: undefined
                });
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(entity.skip, pageIndex);
            } else {
                // 写真を保存
                this.action.saveDocumentImages(answer.image, codeXABC, entity.name);
                this.getNextChat(entity.next, pageIndex);
            }
        });
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }

    /**
     * `entity.nameに対応する本人確認書類コードを返却する。
     */
    private getCode(name: string) {
        switch (name) {
            case 'nameIdentiImageX':
                return this.state.submitData.identificationDocument3X;
            case 'nameIdentiImageA':
                return this.state.submitData.identificationDocument3A;
            case 'nameIdentiImageB':
                return this.state.submitData.identificationDocument3B;
            case 'nameIdentiImageC':
                return this.state.submitData.identificationDocument3C;
        }
    }
}
