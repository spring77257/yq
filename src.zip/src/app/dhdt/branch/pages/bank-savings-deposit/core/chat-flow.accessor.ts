
import {
    ComponentFactory, ComponentFactoryResolver,
    ComponentRef, EventEmitter, NgZone
} from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { AppProperties } from 'app.properties';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingsSignal, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { ComponentProvider } from 'dhdt/branch/shared/components/component-provider';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { Content } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';

/**
 * chat flow accessor.
 */
export class ChatFlowAccessor {

    protected action: SavingsAction;
    protected store: SavingsStore;

    private _chatFlowRenderer: ChatFlowRenderer;

    private factory: ComponentFactory<ComponentProvider>;
    private qf: ComponentRef<ComponentProvider>;
    private componentFactoryResolver: ComponentFactoryResolver;
    private ngZone: NgZone;
    private editService: EditService;

    constructor(
        public chatFlowRenderer?: ChatFlowRenderer
    ) {

        this.action = InjectionUtils.injector.get(SavingsAction);
        this.store = InjectionUtils.injector.get(SavingsStore);
        this.componentFactoryResolver = InjectionUtils.injector.get(ComponentFactoryResolver);
        this.ngZone = InjectionUtils.injector.get(NgZone);
        this._chatFlowRenderer = chatFlowRenderer;
        this.editService = InjectionUtils.injector.get(EditService);

        this.addListioner();
    }

    public addComponent(datas: any, from: any, to: any, options: any = {}): EventEmitter<any> {
        this.clearComponent();
        this.factory = this.componentFactoryResolver.resolveComponentFactory(from);
        this.qf = to.createComponent(this.factory);
        this.qf.instance.datas = datas;
        this.qf.instance.options = options;
        this.qf.instance.content = this._chatFlowRenderer.content;
        this.qf.instance.footer = to;
        this.store.sendSignal(SavingsSignal.WILL_PUSH_FOOTER);
        if (this.qf.instance.refresh) {
            this.qf.instance.refresh.subscribe(() => {
                this.resize();
            });
        }
        return this.qf.instance.launch;
    }

    /**
     * Resize view
     * Called whenever view change
     */
    public resize() {
        this._chatFlowRenderer.content.resize();
        setTimeout(() => {
            if (this._chatFlowRenderer.content && this._chatFlowRenderer.content._scroll !== null) {
                this._chatFlowRenderer.content.scrollToBottom();
            }
        }, 400);
    }

    public clearComponent() {
        if (this.qf) {
            this.qf.destroy();
            this.store.sendSignal(SavingsSignal.WILL_DISMISS_FOOTER);
        }
    }

    public destroy(): void {
        this.store.unregisterSignalHandler(SavingsSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(SavingsSignal.SEND_ANSWER);
    }

    public setContent(content: Content) {
        this._chatFlowRenderer.content = content;
    }

    public setRenderer(chatFlowRenderer?: ChatFlowRenderer) {
        this._chatFlowRenderer = chatFlowRenderer;
    }

    private addListioner() {
        this.store.registerSignalHandler(SavingsSignal.GET_QUESTION, (pageIndex: number) => {
            // show first message
            this.clearComponent();
            this.action.getNextChatByAnswer(0, pageIndex);
        });
        this.store.registerSignalHandler(SavingsSignal.SEND_ANSWER, (datas) => {
            const question = datas.question;
            const pageIndex = datas.pageIndex;
            this.clearComponent();
            switch (question.type) {
                case 'text':
                case 'judge':
                case 'route':
                case 'image': {
                    this._chatFlowRenderer.rendererComponents(question, pageIndex);
                    break;
                }
                default: {
                    Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                        this.ngZone.run(() => {
                            this._chatFlowRenderer.rendererComponents(question, pageIndex);
                        });
                    });
                }
            }
        });
    }

}
