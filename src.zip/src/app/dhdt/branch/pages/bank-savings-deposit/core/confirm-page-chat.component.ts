import {
    AfterViewChecked, animate, ChangeDetectorRef,
    Component, ElementRef, OnDestroy, OnInit, state,
    style, transition, trigger, ViewChild, ViewContainerRef
} from '@angular/core';
import { BaseComponent } from 'adep/components';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { ConfirmApplyCommonComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/confirm/con-apply-common.component';
import { ConfirmSelfApplyComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/confirm/con-self-apply.component';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { COMMON_CONSTANTS, ConfirmChatPageId, ConfirmChatPageIndex } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { Content, ModalController, NavController, NavParams, ViewController } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';
@Component({
    selector: 'confirm-page-chat.component',
    templateUrl: 'chat.component.html',
    animations: [
        trigger('flyInOut', [
            state('in', style({transform: 'translateY(0)'})),
            state('out', style({transform: 'translateY(0)'})),
            transition('out => in', [
              style({transform: 'translateY(100%)'}),
              animate('0.3s  ease-in')
            ]),
            transition('in => out', [
                style({transform: 'translateY(-100%)'}),
                animate('0.3s  ease-in')
              ])
          ])
      ]
})

/**
 * control all chat page.
 */
export class ConfirmPageChatComponent extends BaseComponent implements AfterViewChecked, OnInit, OnDestroy {

    @ViewChild(Content) public content: Content;
    @ViewChild('footerContent', { read: ViewContainerRef }) public footerContent: ViewContainerRef;
    @ViewChild('topBlockView', { read: ElementRef }) public topBlockView: ElementRef;
    @ViewChild('bottomBlockView', { read: ElementRef }) public bottomBlockView: ElementRef;

    public chatFlowAccessor: ChatFlowAccessor;
    public state: SavingsState;
    public isCurrentPage: boolean;
    public needPassword: boolean = true;
    public currentTitle: string;
    public footerState = 'out';

    private currentPageComponent: ChatFlowRenderer;
    private currentPageIndex: number;
    private pageComponentList: ChatFlowRenderer[];

    private startOrder: number;
    private endOrder: number;
    private originShowConfirm: any[];
    private originSubmitData: any;

    constructor(
        public store: SavingsStore, public action: SavingsAction,
        private modalService: ModalService,
        private navCtrl: NavController, public changeDetectorRef: ChangeDetectorRef,
        private params: NavParams, public viewCtrl: ViewController, private loginStore: LoginStore,
        private deviceService: DeviceService, private modalCtrl: ModalController, private audioService: AudioService,
        private editService: EditService) {
        super();
        this.pageComponentList = [];
        this.state = this.store.getState();
        this.chatFlowAccessor = new ChatFlowAccessor();
        this.originShowConfirm = [...this.state.showConfirm];
        this.originSubmitData = {...this.state.submitData};
    }

    public ngOnInit() {
        this.isCurrentPage = true;
        this.currentTitle = this.params.get('isCurrentPage') ? this.params.get('currentTitle') : '';
        this.startOrder = this.params.get('startOrder');
        this.endOrder = this.params.get('endOrder');
        this.currentPageIndex = this.params.get('pageIndex');
        this.needPassword = this.params.get('needPassword') ? false : true;
        this.initializeChatComponent();

        this.store.registerSignalHandler(SavingsSignal.SET_ANSWER, () => this.changeDetectorRef.detectChanges());
        this.store.registerSignalHandler(SavingsSignal.WILL_PUSH_FOOTER, () => this.footerState = 'in');
        this.store.registerSignalHandler(SavingsSignal.WILL_DISMISS_FOOTER, () => this.footerState = 'out');

        if (this.params.get('name') === 'holderZipCode') {
            this.action.setStateSubmitDataValue({ name: 'holderAddressStreetNameInput', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'holderAddressStreetNameSelect', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'holderAddressStreetNameFuriKanaInput', value: undefined});
        }

        // 口座開設店の修正チャットの場合、比較用に修正前の口座開設店を保存する ※本チャットで変更していない場合、値を変更しない
        if (this.params.get('name') === 'branchNameKanji') {
            this.action.saveTenbanBefore(this.state.submitData.tenban || this.state.tenbanBefore);
        }
        if (this.params.get('name') === 'holderMobileNo') {
            this.action.setStateSubmitDataValue({ name: 'isSmsPhone', value: undefined });
        }
    }

    public ngOnDestroy() {
        this.chatFlowAccessor.destroy();
        this.store.unregisterSignalHandler(SavingsSignal.WILL_PUSH_FOOTER);
        this.store.unregisterSignalHandler(SavingsSignal.WILL_DISMISS_FOOTER);
        this.store.unregisterSignalHandler(SavingsSignal.SET_ANSWER);
    }

    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    public beforeAlert() {
        this.chatFlowAccessor.clearComponent();
    }
    public afterAlert() {
        const lastNode = this.state.showChats[this.state.showChats.length - 1];
        this.action.resetLastNode({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    public editCallBack(order: number, pageIndex: number, answerOrder: number) {
        this.editService.startEdit();
        this.beforeAlert();
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.editBtn, buttonValue: 'edit' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.editTitle,
            buttonList,
            (item) => {
                const preventedItem = this.editService.endEdit();
                if (item.buttonValue === 'edit') {
                    this.action.editChart(order, pageIndex, answerOrder);
                    this.chatFlowAccessor.clearComponent();
                    this.currentPageIndex = pageIndex;
                    this.currentPageComponent = this.getPageComponent(pageIndex);
                    this.getNextAnswer(order, pageIndex);
                    const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
                    this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
                } else {
                    if (preventedItem) {
                        this.getNextAnswer(preventedItem.order, preventedItem.pageIndex);
                    } else {
                        this.afterAlert();
                    }
                }
            },
            this.labels.alert.editSubTitle
        );
    }

    public get headerTitle(): string {
        if (this.currentPageIndex === 0) {
            return 'IYO BANK';
        }
        return this.state.submitData.accountTypeText;
    }

    public get processType(): number {
        return this.currentPageComponent.processType;
    }

    public handleCancelClickEmitter(value) {
        this.action.resetShowConfirm(this.originShowConfirm, this.originSubmitData);
        this.viewCtrl.dismiss(value);
    }

    private initializeChatComponent() {
        this.action.submitDataBackup();
        this.action.clearShowChats();
        if (this.currentPageIndex === ConfirmChatPageIndex.SELF_INFO) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, ConfirmChatPageId.SELF_INFO);
        } else if (this.currentPageIndex === ConfirmChatPageIndex.APPLY_COMMON) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, ConfirmChatPageId.APPLY_COMMON);
        } else if (this.currentPageIndex === ConfirmChatPageIndex.APPLY_COMMON_OTHER) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, ConfirmChatPageId.APPLY_COMMON_OTHER);
        }
        this.getNextAnswer(this.startOrder, this.currentPageIndex);
    }

    private getNextAnswer(order: number, pageIndex: number, nextChatDelay?: number) {
        if (this.startOrder != null && this.endOrder != null && (order > this.endOrder || order < 0)) {
            if (this.currentTitle === this.labels.confirm.customerInfo.mobileNo) {
                if (this.state.submitData.firstMobileNo || this.state.submitData.firstTel) {
                    this.viewCtrl.dismiss();
                } else {
                    const buttonList = [
                        { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
                    ];
                    this.modalService.showWarnAlert(
                        this.labels.alert.warnTelTitle,
                        buttonList, null
                    );
                }
            } else {
                this.viewCtrl.dismiss();
            }

            return;
        }

        const speed = (nextChatDelay === undefined) ? Number(AppProperties.CHAT_SPEED) : nextChatDelay;
        Observable.timer(speed).subscribe(() => {
            this.action.getNextChatByAnswer(order, pageIndex);
        });
    }

    private mappingComponentList(componentType: string): ChatFlowRenderer {
        let render: ChatFlowRenderer;
        if (componentType === 'ConfirmSelfApplyComponent') {
            render = new ConfirmSelfApplyComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.loginStore);
        } else if (componentType === 'ConfirmApplyCommonComponent') {
            const tmpRender = new ConfirmApplyCommonComponent(this.chatFlowAccessor, this.footerContent, this.store,
                this.modalService, this.loginStore, this.deviceService, this.navCtrl, this.audioService);
            // callback定義
            tmpRender.chatFlowCompelete = (result, backToTop = false) => this.chatFlowCompelete(result, backToTop);
            render = tmpRender;
        }

        return render;
    }

    private getPageComponent(pageIndex: number, componentType?: string): ChatFlowRenderer {
        if (this.pageComponentList[pageIndex] == null) {
            this.pageComponentList[pageIndex] = this.mappingComponentList(componentType);
            this.pageComponentList[pageIndex].nextChatEvent.subscribe((params) => {
                this.getNextAnswer(params.order, params.pageIndex, params.nextChatDelay);
            });
        }

        // this.topBlockView.nativeElement.style.height = '88px';

        if (this.chatFlowAccessor) {
            this.chatFlowAccessor.setRenderer(this.pageComponentList[pageIndex]);
            this.chatFlowAccessor.setContent(this.content);
        }
        return this.pageComponentList[pageIndex];
    }

    /**
     * chat flow completion callback
     * @param result changed result
     * @param backToTop backToTop flag
     */
    private chatFlowCompelete(result, backToTop) {
        if (backToTop) {
            this.viewCtrl.dismiss('backToTop', null, { animate: false });
        } else {
            this.viewCtrl.dismiss(result);
        }
    }
}
