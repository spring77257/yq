import {
    AfterViewChecked, animate, ChangeDetectorRef, Component, ElementRef, NgModule, OnDestroy,
    OnInit, state, style, transition, trigger, ViewChild, ViewContainerRef
} from '@angular/core';
import { BaseComponent } from 'adep/components';
import { LabelService } from 'adep/services';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import { AutomaticTransferChatComponent } from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-chat.component';
import { AutomaticTransferConfirmComponent } from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-confirm.component';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { ChatFlowInfoInterface } from 'dhdt/branch/pages/bank-savings-deposit/interface/chat-flow-info';
import { RegularAgentApplyComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/regular/regular-agent-apply.component';
import { RegularApplyCommonComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/regular/regular-apply-common.component';
import { RegularCommonComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/regular/regular-common.component';
import { RegularInitConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/regular/regular-init-confirm.component';
import { RegularInputComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/regular/regular-input.component';
import { RegularReserveComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/regular/regular-reserve.component';
import { RegularSelectCategoryComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/regular/regular-select-category.component';
import { RegularSelectMaterialComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/regular/regular-select-material.component';
import { RegularSelectProductComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/regular/regular-select-product.component';
import { RegularSelfApplyComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/regular/regular-self-apply.component';
import {
    AgentAddressIdentificationHolder
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/agent-address-identification-holder.component';
import { AgentAddressIdentification } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/agent-address-identification.component';
import { AgentApplyComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/agent-apply.component';
import { AgentCheckApplyComponentHolder } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/agent-check-apply-holder.component';
import { AgentCheckApplyComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/agent-check-apply.component';
import {
    AgentIdentificationDocumentOneHolder
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/agent-identification-documentOne-holder.component';
import {
    AgentIdentificationDocumentOne
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/agent-identification-documentOne.component';
import {
    AgentIdentificationDocumentTwoHolder
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/agent-identification-documentTwo-holder.component';
import {
    AgentIdentificationDocumentTwo
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/agent-identification-documentTwo.component';
import { AgentImgapplyComponentHolder } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/agent-imgapply-holder.component';
import { AgentImgapplyComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/agent-imgapply.component';
import { ApplyCommonComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/apply-common.component';
import { ExistingAccountConfirmation } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/existing-account-confirmation.component';
import {
    ForeignerAddressIdentificationComponent
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/foreigner-address-identification.component';
import {
    ForeignerAddressPassportIdentificationComponent
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/foreigner-address-passport-identification.component';
import {
    ForeignerCheckapplyComponent
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/foreigner-checkapply.component';
import { ForeignerInitConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/foreigner-init-confirm.component';
import { ForeignerPrincipalComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/foreigner-principal.component';
import { ForeignerResidenceCardComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/foreigner-residence-card.component';
import {
    ForeignerSpecialPermanentComponent
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/foreigner-special-permanent.component';
import { ForeignerUsArmyComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/foreigner-us-army.component';
import { InitConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/init-confirm.component';
import {
    ReceptionSelfApplyForeignerComponent
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/reception-self-apply-foreigner.component';
import { ReceptionSelfApplyInitComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/reception-self-apply-init.component';
import {
    ReceptionSelfApplyJapaneseComponent
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/reception-self-apply-japanese.component';
import { ReceptionSelfApplyTelComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/reception-self-apply-tel.component';
import { ReceptionComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/reception.component';
import { SelfAddressIdentification } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/self-address-identification.component';
import { SelfApplyComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/self-apply.component';
import { SelfCheckApplyComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/self-check-apply.component';
import {
    SelfCreditcardDocumentConfirmRenderer
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/self-creditcard-document-confirm.renderer';
import {
    SelfCreditCardStuffConfirmRenderer
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/self-creditcard-stuff-confirm.renderer';
import {
    SelfIdentificationDocumentOne
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/self-identification-documentOne.component';
import {
    SelfIdentificationDocumentTwo
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/self-identification-documentTwo.component';
import { SelfImgapplyComponent } from 'dhdt/branch/pages/bank-savings-deposit/render/savings/self-imgapply.component';
import {
    SelfSavingBranchConfirmComponent
} from 'dhdt/branch/pages/bank-savings-deposit/render/savings/self-saving-branch-confirm.component';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { AccountComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/account.component';
import { BsdAgentInfoComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/bsd-agent-info.component';
import {
    ExistingSavingsForeignConfirmComponent
} from 'dhdt/branch/pages/bank-savings-deposit/view/existing-savings-foreign/view/existing-savings-foreign-confirm.component';
import { RegularAgentInfoComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/regular/regular-agent-info.component';
import { RegularHolderInfoComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/regular/regular-holder-info.component';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelChatComponent } from 'dhdt/branch/pages/cancel/view/cancel-chat.component';
import { CancelComponent } from 'dhdt/branch/pages/cancel/view/cancel.component';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CashCardAccountComponent } from 'dhdt/branch/pages/cashcard/view/cashcard-account.component';
import { CashCardChatComponent } from 'dhdt/branch/pages/cashcard/view/cashcard-chat.component';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ChangeChatComponent } from 'dhdt/branch/pages/change/chat-flow/change-chat.component';
import { ChangeFinishComponent } from 'dhdt/branch/pages/change/view/change.component';
import { ClerkAction } from 'dhdt/branch/pages/clerk/action/clerk.action';
import { ClerkChatComponent } from 'dhdt/branch/pages/clerk/view/clerk-chat.component';
import {
    AccountType, ApplyBC, ApplyBusinessType, ChatFlowChoicesValue, COMMON_CONSTANTS,
    Constants, HasDriversCareerLicense, HasLicense, PrincipalAgentCategory
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginAction } from 'dhdt/branch/pages/common/login/action/login.action';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardChatComponent } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat.component';
import { CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { CreditCardConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-confirm.component';
import { ExistingReserveAction } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { ExistingReserveChatComponent } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat.component';
import { ExistingRegularConfirmComponent } from 'dhdt/branch/pages/existing-reserve/view/existing-regular-confirm.component';
import {
    ExistingReserveClerkConfirmationComponent
} from 'dhdt/branch/pages/existing-reserve/view/existing-reserve-clerk-confirmation.component';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatComponent } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat.component';
import { ExistingSavingsChangeConfirmComponent } from 'dhdt/branch/pages/existing-savings/view/existing-savings-change-confirm.component';
import { ExistingSavingsConfirmComponent } from 'dhdt/branch/pages/existing-savings/view/existing-savings-confirm.component';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatComponent } from 'dhdt/branch/pages/inherit/view/inherit-chat.component';
import { StaffConfirmationComponent } from 'dhdt/branch/pages/inherit/view/staff-confirmation.component';
import { LossReissueFindingAction } from 'dhdt/branch/pages/loss-reissue-finding/action/loss-reissue-finding.action';
import { LossConfirmComponent } from 'dhdt/branch/pages/loss-reissue-finding/view/loss-confirm.component';
import { LossReissueFindingChatComponent } from 'dhdt/branch/pages/loss-reissue-finding/view/loss-reissue-finding-chat.component';
import { ReissueConfirmComponent } from 'dhdt/branch/pages/loss-reissue-finding/view/reissue-confirm.component';
import { MynumberAction } from 'dhdt/branch/pages/mynumber/action/mynumber.action';
import { MynumberChatComponent } from 'dhdt/branch/pages/mynumber/view/mynumber-chat.component';
import { MynumberConfirmComponent } from 'dhdt/branch/pages/mynumber/view/mynumber-confirm.component';
import { MynumberInitConfirmComponent } from 'dhdt/branch/pages/mynumber/view/mynumber-initconfirm.component';
import { NewestAction } from 'dhdt/branch/pages/newest/action/newest.action';
import { NewestChatComponent } from 'dhdt/branch/pages/newest/view/newest-chat.component';
import { NewestConfirmComponent } from 'dhdt/branch/pages/newest/view/newest-confirm.component';
import { NewestInitConfirmComponent } from 'dhdt/branch/pages/newest/view/newest-initconfirm.component';
import { DirectBankingAction } from 'dhdt/branch/pages/point-direct/action/direct-banking.action';
import { PointDirectAction } from 'dhdt/branch/pages/point-direct/action/point-direct.action';
import { PointServiceAction } from 'dhdt/branch/pages/point-direct/action/point-service.action';
import { PointDirectChatComponent } from 'dhdt/branch/pages/point-direct/view/point-direct-chat.component';
import { ReplacementAction } from 'dhdt/branch/pages/replacement/action/replacement.action';
import { ReplacementChatComponent } from 'dhdt/branch/pages/replacement/view/replacement-chat.component';
import { ReplacementConfirmComponent } from 'dhdt/branch/pages/replacement/view/replacement-confirm.component';
import { ReplacementInitConfirmComponent } from 'dhdt/branch/pages/replacement/view/replacement-initconfirm.component';
import { StudentAction } from 'dhdt/branch/pages/student/action/student.action';
import { StudentChatComponent } from 'dhdt/branch/pages/student/chat-flow/student-chat.component';
import { StudentNewAgentConfirmComponent } from 'dhdt/branch/pages/student/view/new/student-new-agent-confirm.component';
import { StudentNewConfirmComponent } from 'dhdt/branch/pages/student/view/new/student-new-confirm.component';
import { StudentChangeConfirmComponent } from 'dhdt/branch/pages/student/view/student-change-confirm.component';
import { TerminateAction } from 'dhdt/branch/pages/terminate/action/terminate.action';
import { TerminateChatComponent } from 'dhdt/branch/pages/terminate/view/terminate-chat.component';
import { TerminateConfirmComponent } from 'dhdt/branch/pages/terminate/view/terminate-confirm.component';
import { TerminateCounterConfirmComponent } from 'dhdt/branch/pages/terminate/view/terminate-counter-confirm.component';
import { TimeDepositRewritingAction } from 'dhdt/branch/pages/time-deposit-rewriting/action/time-deposit-rewriting.action';
import { TimeDepositRewritingChatComponent } from 'dhdt/branch/pages/time-deposit-rewriting/view/time-deposit-rewriting-chat.component';
import { AccountModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/account-modal-password.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { CardService } from 'dhdt/branch/shared/services/card.service';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { HostErrorService } from 'dhdt/branch/shared/services/host-error.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ConfirmUtil } from 'dhdt/branch/shared/utils/confirm-util';
import { LossReissueFindingUtil } from 'dhdt/branch/shared/utils/loss-reissue-finding-util';
import { App, Content, ModalController, NavController, NavParams, ViewController } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';
@Component({
    selector: 'chat-component',
    templateUrl: 'chat.component.html',
    animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateY(0)' })),
            state('out', style({ transform: 'translateY(0)' })),
            transition('out => in', [
                style({ transform: 'translateY(100%)' }),
                animate('0.3s  ease-in')
            ]),
            transition('in => out', [
                style({ transform: 'translateY(-100%)' }),
                animate('0.3s  ease-in')
            ])
        ])
    ]
})

/**
 * control all chat page.
 */
export class ChatComponent extends BaseComponent implements AfterViewChecked, OnInit, OnDestroy {
    @ViewChild(Content) public content: Content;
    @ViewChild('footerContent', { read: ViewContainerRef }) public footerContent: ViewContainerRef;
    @ViewChild('topBlockView', { read: ElementRef }) public topBlockView: ElementRef;
    @ViewChild('bottomBlockView', { read: ElementRef }) public bottomBlockView: ElementRef;

    public chatFlowAccessor: ChatFlowAccessor;
    public state: SavingsState;
    // is current page
    public isCurrentPage: boolean;
    public currentTitle: string;
    public needPassword: boolean = true;
    public footerState = 'out';

    private currentPageComponent: ChatFlowRenderer;
    private currentPageIndex: number;
    private currentPageName: string;            // 当該ページ名
    private pageComponentList: ChatFlowRenderer[];

    private startOrder: number;
    private endOrder: number;
    private reapplyFlg: boolean;   // true: 再申請
    private cardFrontImage: any;
    private cartBackImage: any;
    private options?: {
        component: string;
        title: string;
        process: number;
        clear: boolean;
        submitData: any;
    };

    constructor(
        public store: SavingsStore, public action: SavingsAction,
        private cashCardAction: CashCardAction,
        private creditCardAction: CreditCardAction,
        private cancelAction: CancelAction,
        private changeAction: ChangeAction,
        private existingReserveAction: ExistingReserveAction,
        private studentAction: StudentAction,
        private existingSavingsAction: ExistingSavingsAction,
        private inheritAction: InheritAction,
        private pointDirectAction: PointDirectAction,
        private automaticTransferAction: AutomaticTransferAction,
        private pointServiceAction: PointServiceAction,
        private directBankingAction: DirectBankingAction,
        private labelService: LabelService,
        private timeDepositRewritingAction: TimeDepositRewritingAction,
        private lossReissueFindingAction: LossReissueFindingAction,
        private replacementAction: ReplacementAction,
        private newestAction: NewestAction,
        private terminateAction: TerminateAction,
        private mynumberAction: MynumberAction,
        private clerkAction: ClerkAction,
        private modalService: ModalService, private audioService: AudioService,
        private navCtrl: NavController, public changeDetectorRef: ChangeDetectorRef,
        private params: NavParams, public viewCtrl: ViewController,
        private modalCtrl: ModalController, private loginStore: LoginStore,
        private logging: LoggingService,
        private deviceService: DeviceService,
        private editService: EditService,
        private cardService: CardService,
        private rsaEncryptService: RsaEncryptService,
        private app: App,
        private loginAction: LoginAction,
        private lossReissueFindingUtil: LossReissueFindingUtil,
        private hostErrorService: HostErrorService,
        private creditCardStore: CreditCardStore,
        private confirmUtils: ConfirmUtil) {
        super();
        this.ngOnDestroy();
        this.pageComponentList = [];
        this.state = this.store.getState();
        this.chatFlowAccessor = new ChatFlowAccessor();

        this.options = params.get('options');

        // clear store data
        if (!this.options || this.options.clear) {
            this.action.clearStore();
            this.cashCardAction.clearStore();
            this.creditCardAction.clearStore();
            this.cancelAction.clearStore();
            this.changeAction.clearStore();
            this.existingReserveAction.clearStore();
            this.studentAction.clearStore();
            this.existingSavingsAction.clearStore();
            this.inheritAction.clearStore();
            this.pointDirectAction.clearStore();
            this.automaticTransferAction.clearStore();
            this.pointServiceAction.clearStore();
            this.directBankingAction.clearStore();
            this.timeDepositRewritingAction.clearStore();
            this.lossReissueFindingAction.clearState();
            this.terminateAction.clearState();
            this.mynumberAction.clearState();
            this.clerkAction.clearState();
            this.replacementAction.clearState();
            this.newestAction.clearState();
        } else {
            this.action.clearShowChats();
        }

        if (this.options && this.options.submitData) {
            this.action.setStateData(this.options);
        } else {
            this.action.setTabletApplyId(params.get('tabletApplyId'));

            this.action.setStateSubmitDataValue({
                name: 'tenban',
                value: this.loginStore.getState().belongToBranchNo
            });
            this.action.setStateSubmitDataValue({
                name: 'tenbanBak',
                value: this.loginStore.getState().belongToBranchNo
            });
            this.action.setStateSubmitDataValue({
                name: 'branchName',
                value: this.loginStore.getState().belongToBranchName
            });
            this.action.setStateSubmitDataValue({
                name: 'branchNameBak',
                value: this.loginStore.getState().belongToBranchName
            });
        }
    }

    public ngOnInit() {
        this.startOrder = this.params.get('startOrder');
        this.endOrder = this.params.get('endOrder');
        this.currentPageIndex = this.params.get('pageIndex');
        this.isCurrentPage = this.params.get('isCurrentPage') ? true : false;
        this.currentTitle = this.params.get('isCurrentPage') ? this.params.get('currentTitle') : '';
        this.needPassword = this.params.get('needPassword') ? false : true;
        this.reapplyFlg = this.params.get('reapplyFlg');

        // 各業務のコンポーネントをセット
        this.setChatFlowInfo();

        // 口座開設行員確認画面の本人確認書類修正チャットの場合
        if (this.options && this.isCurrentPage
            && (this.options.component === 'SelfCheckApplyComponent' || this.options.component === 'AgentCheckApplyComponentHolder')) {
            // OCRが運転経歴証明書の場合、hasLicenseを復元
            if (this.state.submitData.hasLicense === HasLicense.HAS_NOT_LICENSE
                && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES) {
                this.action.setStateSubmitDataValue({
                    name: 'hasLicense',
                    value: Constants.DriveCard
                });
            }
        }

        if (this.startOrder != null && this.endOrder != null) {
            this.action.clearShowChats();
            let componentName = '';
            if (this.state.submitData.accountType === '5') {
                if (this.currentPageIndex === 2) {
                    // キャッシュカード共通
                    componentName = 'CashCardCommonComponent';
                } else if (this.currentPageIndex === 4) {
                    // キャッシュカード家族
                    componentName = 'CashCardFamilyComponent';
                }
            } else {
                if (this.currentPageIndex === 1) {
                    componentName = 'InitConfirmComponent';
                } else if (this.currentPageIndex === 2) {
                    componentName = 'SelfApplyComponent';
                    if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) {
                        componentName = 'AgentApplyComponent';
                    }
                } else if (this.currentPageIndex === 3) {
                    componentName = 'ApplyCommonComponent';
                } else if (this.currentPageIndex === 4) {
                    componentName = 'AgentApplyComponent';
                }
            }
            this.action.submitDataBackup();
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, componentName);
            this.getNextAnswer(this.startOrder, this.currentPageIndex);
        } else {
            this.currentPageIndex = 0;
            this.currentPageComponent = this.getPageComponent(0, this.options ? this.options.component : undefined);
            setTimeout(() => {
                this.currentPageComponent.loadTemplate(0);
            }, 600);
        }

        this.store.registerSignalHandler(SavingsSignal.CHAT_FLOW_COMPELETE, (next) => {
            const { name, options } = next;

            this.currentPageName = name;

            if (name === undefined) {
                this.branchStatusUpdate();
            } else if (name === 'top') {
                Observable.timer(Constants.PageConsts.backToTopStayTime).subscribe(() => {
                    this.app.getRootNav().setRoot(TopComponent);
                    this.chatFlowAccessor.clearComponent();
                });
            } else if (name === ChatFlowChoicesValue.BACK_TO_TOP) {
                Observable.timer(Constants.ZERO).subscribe(() => {
                    this.app.getRootNav().setRoot(TopComponent);
                    this.chatFlowAccessor.clearComponent();
                });
            } else if (name === ChatFlowChoicesValue.BACK_TO_TOP_NOT_FROM_ROOT) {
                Observable.timer(Constants.ZERO).subscribe(() => {
                    if (this.navCtrl !== this.app.getRootNav()) {
                        this.viewCtrl.dismiss(null, null, {
                            animate: false
                        }).then(() => this.app.getRootNav().setRoot(TopComponent));
                    } else {
                        this.app.getRootNav().setRoot(TopComponent);
                    }
                });
            } else if (name === 'compelete') {
                this.viewCtrl.dismiss({
                    ...this.state
                });
            } else {
                if (name === 'InitConfirmComponent' || name === 'ForeignerInitConfirmComponent') {
                    this.action.clearShowChats();
                }
                this.currentPageIndex += 1;
                this.currentPageComponent = this.getPageComponent(this.currentPageIndex, name, options);
                Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                    this.currentPageComponent.loadTemplate(this.currentPageIndex);
                });
                this.chatFlowAccessor.clearComponent();
            }
        });

        this.store.registerSignalHandler(SavingsSignal.CHAT_FLOW_RETURN, (next) => {
            const copyShowChats = Array.from(this.state.showChats);
            const item = copyShowChats.reverse().find(
                (qus) => {
                    return qus.name === next.name && qus.type !== 'judge';
                }
            );

            this.toEditChat(item.order, item.pageIndex, item.answer.order, item.orderIndex);
        });

        this.store.registerSignalHandler(SavingsSignal.SET_ANSWER, () => this.changeDetectorRef.detectChanges());
        this.store.registerSignalHandler(SavingsSignal.WILL_PUSH_FOOTER, () => this.footerState = 'in');
        this.store.registerSignalHandler(SavingsSignal.WILL_DISMISS_FOOTER, () => this.footerState = 'out');
    }

    public getCurrentComponent() {
        return this.currentPageComponent;
    }

    public ngOnDestroy() {
        if (this.chatFlowAccessor) {
            this.chatFlowAccessor.destroy();
        }

        this.store.unregisterSignalHandler(SavingsSignal.GET_INFO_OCR_COMPLETE);
        this.store.unregisterSignalHandler(SavingsSignal.CHAT_FLOW_COMPELETE);
        this.store.unregisterSignalHandler(SavingsSignal.CHAT_FLOW_RETURN);
        this.store.unregisterSignalHandler(SavingsSignal.WILL_PUSH_FOOTER);
        this.store.unregisterSignalHandler(SavingsSignal.WILL_DISMISS_FOOTER);
        this.store.unregisterSignalHandler(SavingsSignal.SET_ANSWER);

        this.store.unregisterSignalHandler(SavingsSignal.GET_TABLET_COUNT_RESULT);
        this.store.unregisterSignalHandler(SavingsSignal.INSERT_TABLET_APPLY_SUCCESS);
    }

    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    public beforeAlert() {
        this.chatFlowAccessor.clearComponent();
    }
    public afterAlert() {
        const lastNode = this.state.showChats[this.state.showChats.length - 1];
        this.action.resetLastNode({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    public editCallBack(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.editService.startEdit();
        this.beforeAlert();
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.editBtn, buttonValue: 'edit' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.editTitle,
            buttonList,
            (item) => {
                const preventedItem = this.editService.endEdit();
                if (item.buttonValue === 'edit') {
                    this.action.editChart(order, pageIndex, answerOrder, orderIndex);
                    this.chatFlowAccessor.clearComponent();
                    this.currentPageIndex = pageIndex;
                    this.currentPageComponent = this.getPageComponent(pageIndex);
                    this.getNextAnswer(order, pageIndex);
                    const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
                    this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
                } else {
                    if (preventedItem) {
                        this.getNextAnswer(preventedItem.order, preventedItem.pageIndex);
                    } else {
                        this.afterAlert();
                    }
                }
            },
            this.labels.alert.editSubTitle
        );
    }

    public get headerTitle(): string {
        if (this.currentPageIndex === 0 || this.currentPageName === 'ReceptionComponent') {
            return this.options ? this.options.title : 'IYO BANK';
        }
        // 口座開設受付チャットのタイトルを決める
        if (this.currentPageName === 'ReceptionSelfApplyJapaneseComponent'
            || this.currentPageName === 'ReceptionSelfApplyInitComponent'
            || this.currentPageName === 'ReceptionSelfApplyTelComponent'
            || this.currentPageName === 'ReceptionSelfApplyForeignerComponent'
        ) {
            return this.labels.reception.chatTitle;
        }
        return this.options ? this.options.title : this.state.submitData.accountTypeText;
    }

    public get processType(): number {
        if (this.options) {
            return this.options.process;
        }
        return this.currentPageComponent.processType === 0 ? 1 : this.currentPageComponent.processType;
    }

    // header cancel button click
    public handleCancelClickEmitter(value) {
        // タイトルが「本人確認書類」の場合、ポップアップを表示。※本人確認チャット
        if (this.headerTitle === '本人確認書類') {
            const buttonList = [
                { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
                { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.backToConfirmTitle,
                buttonList,
                (item) => {
                    if (item.buttonValue === 'back') {
                        // BCありの場合
                        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
                            this.viewCtrl.dismiss('backConfirmTwoScn');
                        } else {
                            this.viewCtrl.dismiss(value);
                        }
                    }
                }
            );
        } else {
            this.viewCtrl.dismiss(value);
        }
    }

    public get leftHeadTitle() {
        return (this.headerTitle === '本人確認書類') ? this.labels.common.leftSubTitle.backConfirm : this.labels.header.leftSubTitle;
    }

    private toEditChat(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.beforeAlert();
        this.action.editChart(order, pageIndex, answerOrder, orderIndex);
        this.chatFlowAccessor.clearComponent();
        this.currentPageIndex = pageIndex;
        this.currentPageComponent = this.getPageComponent(pageIndex);
        this.getNextAnswer(order, pageIndex);
        const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
        this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
    }

    private getNextAnswer(order: number, pageIndex: number, nextChatDelay?: number) {
        if (this.startOrder != null && this.endOrder != null && order > this.endOrder) {
            if (this.needPassword) {
                const modal = this.modalCtrl.create(AccountModalPasswordComponent,
                    { data: 'キャッシュカードの暗証番号を入力してください。' },
                    { cssClass: 'settings-modal', enableBackdropDismiss: false });
                modal.onDidDismiss((value) => this.viewCtrl.dismiss(value));
                modal.present();
            } else {
                this.viewCtrl.dismiss();
            }
            return;
        }

        const speed = (nextChatDelay === undefined) ? Number(AppProperties.CHAT_SPEED) : nextChatDelay;
        Observable.timer(speed).subscribe(() => {
            this.action.getNextChatByAnswer(order, pageIndex);
        });
    }

    private mappingComponentList(componentType: string, options: any = null): ChatFlowRenderer {

        let render: ChatFlowRenderer;
        if (componentType === undefined) {
            render = new ReceptionComponent(this.chatFlowAccessor, this.footerContent, this.navCtrl,
                this.loginStore, this.labelService, this.deviceService, this.cardService, this.rsaEncryptService,
                this.audioService, this.modalService, this.logging);
        } else if (componentType === 'ReceptionComponent') {
            render = new ReceptionComponent(this.chatFlowAccessor, this.footerContent, this.navCtrl,
                this.loginStore, this.labelService, this.deviceService, this.cardService, this.rsaEncryptService,
                this.audioService, this.modalService, this.logging);
        } else if (componentType === 'InitConfirmComponent') {
            render = new InitConfirmComponent(this.chatFlowAccessor, this.footerContent, this.store, this.loginStore,
                this.modalService, this.audioService);
        } else if (componentType === 'ForeignerInitConfirmComponent') {
            render = new ForeignerInitConfirmComponent(this.chatFlowAccessor, this.footerContent, this.store,
                this.modalService, this.audioService);
        } else if (componentType === 'SelfCheckApplyComponent') {
            render = new SelfCheckApplyComponent(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'SelfImgapplyComponent') {
            render = new SelfImgapplyComponent(this.chatFlowAccessor, this.footerContent);
            Reflect.defineProperty(render, 'options', {
                value: options
            });
        } else if (componentType === 'SelfAddressIdentification') {
            render = new SelfAddressIdentification(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.loginStore, this.action);
        } else if (componentType === 'SelfIdentificationDocumentOne') {
            render = new SelfIdentificationDocumentOne(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'SelfIdentificationDocumentTwo') {
            render = new SelfIdentificationDocumentTwo(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'SelfApplyComponent') {
            render = new SelfApplyComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.modalService, this.loginStore, this.action);
        } else if (componentType === 'ReceptionSelfApplyJapaneseComponent') {
            render = new ReceptionSelfApplyJapaneseComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.modalService, this.loginStore, this.action);
        } else if (componentType === 'ReceptionSelfApplyInitComponent') {
            render = new ReceptionSelfApplyInitComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.modalService, this.loginStore, this.action);
        } else if (componentType === 'ReceptionSelfApplyTelComponent') {
            render = new ReceptionSelfApplyTelComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService,
                this.modalService, this.loginStore, this.action, this.labelService, this.navCtrl);
        } else if (componentType === 'ReceptionSelfApplyForeignerComponent') {
            render = new ReceptionSelfApplyForeignerComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.modalService, this.loginStore, this.action, this.labelService);
        } else if (componentType === 'ExistingAccountConfirmation') {
            render = new ExistingAccountConfirmation(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'AgentApplyComponent') {
            render = new AgentApplyComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.modalService, this.loginStore, this.action);
        } else if (componentType === 'ForeignerUsArmyComponent') {
            render = new ForeignerUsArmyComponent(this.chatFlowAccessor, this.footerContent,
                this.store, this.audioService, this.modalService, this.loginStore, this.action, this.labelService);
        } else if (componentType === 'ForeignerResidenceCardComponent') {
            render = new ForeignerResidenceCardComponent(this.chatFlowAccessor, this.footerContent,
                this.store, this.audioService, this.modalService, this.loginStore, this.action, this.labelService);
        } else if (componentType === 'ForeignerSpecialPermanentComponent') {
            render = new ForeignerSpecialPermanentComponent(this.chatFlowAccessor, this.footerContent,
                this.store, this.audioService, this.modalService, this.loginStore, this.action, this.labelService);
        } else if (componentType === 'ForeignerPrincipalComponent') {
            render = new ForeignerPrincipalComponent(this.chatFlowAccessor, this.footerContent, this.store,
                this.audioService, this.modalService, this.loginStore, this.action, this.labelService, this.navCtrl,
                this.rsaEncryptService, this.modalCtrl, this.confirmUtils);
        } else if (componentType === 'ApplyCommonComponent') {
            render = new ApplyCommonComponent(this.chatFlowAccessor, this.footerContent, this.store,
                this.modalService, this.loginStore, this.navCtrl, this.action, this.modalCtrl, this.audioService, this.rsaEncryptService,
                this.confirmUtils);
        } else if (componentType === 'RegularInitConfirmComponent') {
            render = new RegularInitConfirmComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.modalService, this.audioService);
        } else if (componentType === 'RegularSelectMaterialComponent') {
            render = new RegularSelectMaterialComponent(this.chatFlowAccessor,
                this.footerContent, this.store);
        } else if (componentType === 'RegularSelectCategoryComponent') {
            render = new RegularSelectCategoryComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.modalService);
        } else if (componentType === 'RegularSelectProductComponent') {
            render = new RegularSelectProductComponent(this.chatFlowAccessor,
                this.footerContent, this.store);
        } else if (componentType === 'RegularReserveComponent') {
            render = new RegularReserveComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.modalService, this.navCtrl);
        } else if (componentType === 'RegularSelfApplyComponent') {
            render = new RegularSelfApplyComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.action);
        } else if (componentType === 'RegularAgentApplyComponent') {
            render = new RegularAgentApplyComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.modalService,
                this.loginStore, this.action);
        } else if (componentType === 'RegularApplyCommonComponent') {
            render = new RegularApplyCommonComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.modalService, this.navCtrl);
        } else if (componentType === 'RegularInputComponent') {
            render = new RegularInputComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.modalService, this.navCtrl);
        } else if (componentType === 'RegularCommonComponent') {
            render = new RegularCommonComponent(this.chatFlowAccessor, this.footerContent, this.store,
                this.modalService, this.loginStore, this.deviceService, this.navCtrl);
        } else if (componentType === 'AgentIdentificationDocumentOne') {
            render = new AgentIdentificationDocumentOne(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'AgentIdentificationDocumentTwo') {
            render = new AgentIdentificationDocumentTwo(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'AgentCheckApplyComponent') {
            render = new AgentCheckApplyComponent(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'AgentImgapplyComponent') {
            render = new AgentImgapplyComponent(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'AgentIdentificationDocumentOneHolder') {
            render = new AgentIdentificationDocumentOneHolder(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'AgentIdentificationDocumentTwoHolder') {
            render = new AgentIdentificationDocumentTwoHolder(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'AgentCheckApplyComponentHolder') {
            render = new AgentCheckApplyComponentHolder(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'AgentImgapplyComponentHolder') {
            render = new AgentImgapplyComponentHolder(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'AgentAddressIdentification') {
            render = new AgentAddressIdentification(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.loginStore, this.action);
        } else if (componentType === 'AgentAddressIdentificationHolder') {
            render = new AgentAddressIdentificationHolder(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.loginStore, this.action);
        } else if (componentType === 'ForeignerCheckapplyComponent') {
            render = new ForeignerCheckapplyComponent(this.chatFlowAccessor, this.footerContent, this.creditCardStore);
        } else if (componentType === 'ForeignerAddressIdentificationComponent') {
            render = new ForeignerAddressIdentificationComponent(this.chatFlowAccessor, this.footerContent, this.creditCardStore);
        } else if (componentType === 'ForeignerAddressPassportIdentificationComponent') {
            render = new ForeignerAddressPassportIdentificationComponent(this.chatFlowAccessor, this.footerContent);
        } else if (componentType === 'SelfSavingShopConfirmComponent') {
            render = new SelfSavingBranchConfirmComponent(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.modalService, this.loginStore, this.action);
        } else if (componentType === 'CreditcardDocumentConfirmComponent') {
            render = new SelfCreditcardDocumentConfirmRenderer(this.chatFlowAccessor, this.footerContent, this.store, this.creditCardStore);
        } else if (componentType === 'CreditCardStuffConfirmComponent') {
            render = new SelfCreditCardStuffConfirmRenderer(this.chatFlowAccessor, this.footerContent,
                this.store, this.loginStore);
        }
        return render;
    }

    private getPageComponent(pageIndex: number, componentType?: string, options: any = null): ChatFlowRenderer {
        if (this.pageComponentList[pageIndex] == null) {
            this.pageComponentList[pageIndex] = this.mappingComponentList(componentType, options);
            this.pageComponentList[pageIndex].nextChatEvent.subscribe((params) => {
                this.getNextAnswer(params.order, params.pageIndex, params.nextChatDelay);
            });
        }

        (this.currentPageIndex === 0) ? this.topBlockView.nativeElement.style.height = '0'
            : this.topBlockView.nativeElement.style.height = '88px';

        if (this.chatFlowAccessor) {
            this.chatFlowAccessor.setRenderer(this.pageComponentList[pageIndex]);
            this.chatFlowAccessor.setContent(this.content);
        }
        return this.pageComponentList[pageIndex];
    }

    private branchStatusUpdate() {
        let leaveReason = '';
        let status = '';

        switch (this.state.submitData.leaveType) {
            case 'corporation':
                leaveReason = Constants.DBConsts.leaveReason.corporation;
                status = Constants.DBConsts.updateStatus.corporation;
                break;
            case 'against':
                leaveReason = Constants.DBConsts.leaveReason.against;
                status = Constants.DBConsts.updateStatus.against;
                break;
            case 'importantForeigner':
                leaveReason = Constants.DBConsts.leaveReason.importantForeigner;
                status = Constants.DBConsts.updateStatus.importantForeigner;
                break;
            case 'notInJapan':
                leaveReason = Constants.DBConsts.leaveReason.notInJapan;
                status = Constants.DBConsts.updateStatus.corporation;
                break;
            case 'agentNoConfirmFile':
                leaveReason = Constants.DBConsts.leaveReason.agentNoConfirmFile;
                status = Constants.DBConsts.updateStatus.agentNoConfirmFile;
                break;
            case 'noCohabitation':
                leaveReason = Constants.DBConsts.leaveReason.noCohabitation;
                status = Constants.DBConsts.updateStatus.noCohabitation;
                break;
            case 'noConfirmFile':
                leaveReason = Constants.DBConsts.leaveReason.noConfirmFile;
                status = Constants.DBConsts.updateStatus.noConfirmFile;
                break;
            case 'pointServiceApplied':
                leaveReason = Constants.DBConsts.leaveReason.pointServiceApplied;
                status = Constants.DBConsts.updateStatus.pointServiceApplied;
                break;
            case 'directBankingApplied':
                leaveReason = Constants.DBConsts.leaveReason.directBankingApplied;
                status = Constants.DBConsts.updateStatus.directBankingApplied;
                break;
        }

        const params = {
            tabletApplyId: this.store.getState().tabletApplyId,
            leaveReason: leaveReason,
            status: status,
            userMngNo: this.loginStore.getState().bankclerkId
        };

        this.action.branchStatusUpdate(params);
    }

    // 各業務のコンポーネントをセット
    private setChatFlowInfo() {
        const chatFlowInfo: ChatFlowInfoInterface[] = [
            // 普通預金口座開設（新規）
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.OrdinaryDeposit,
                selectedFlow: 'InitConfirmComponent',
                root: false,
                component: 'InitConfirmComponent',
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.ORDINARY_DEPOSIT,
                accountTypeText: this.labels.accountTypes.header.ordinaryDeposit,
                applyBusinessType: ApplyBusinessType.ORDINARY_DEPOSIT,
                confirmPage: AccountComponent,
                confirmPageSub: BsdAgentInfoComponent,
                checkComponent: 'SelfCheckApplyComponent',
                checkComponentSub: 'AgentCheckApplyComponentHolder',
                params: {
                    nameKana: 'holderNameFurikana',
                    birthdate: 'holderBirthdate',
                },
            },
            // 普通預金口座開設（外国人新規）
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.OrdinaryDeposit,
                selectedFlow: 'ForeignerInitConfirmComponent',
                root: false,
                component: 'ForeignerInitConfirmComponent',
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.ORDINARY_DEPOSIT,
                accountTypeText: this.labels.accountTypes.header.ordinaryDeposit,
                applyBusinessType: ApplyBusinessType.ORDINARY_DEPOSIT,
                confirmPage: AccountComponent,
                confirmPageSub: BsdAgentInfoComponent,
                checkComponent: 'SelfCheckApplyComponent',
                params: {
                    nameKana: 'holderNameFurikana',
                    birthdate: 'holderBirthdate',
                },
            },
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.ChildrenDeposit,
                selectedFlow: 'InitConfirmComponent',
                root: false,
                component: 'InitConfirmComponent',
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.ORDINARY_DEPOSIT_CHILDREN,
                accountTypeText: this.labels.accountTypes.header.childrenDeposit,
                applyBusinessType: ApplyBusinessType.ORDINARY_DEPOSIT_CHILDREN,
                confirmPage: AccountComponent,
                confirmPageSub: BsdAgentInfoComponent,
                params: {
                    nameKana: 'holderNameFurikana',
                    birthdate: 'holderBirthdate',
                },
            },
            // 貯蓄預金口座開設
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.StorageDeposit,
                selectedFlow: 'InitConfirmComponent',
                root: false,
                component: 'InitConfirmComponent',
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.ORDINARY_DEPOSIT_SAVINGS_DIPOSIT,
                accountTypeText: this.labels.accountTypes.header.storageDeposit,
                applyBusinessType: ApplyBusinessType.ORDINARY_DEPOSIT_SAVINGS_DIPOSIT,
                confirmPage: AccountComponent,
                confirmPageSub: BsdAgentInfoComponent,
                params: {
                    nameKana: 'holderNameFurikana',
                    birthdate: 'holderBirthdate',
                },
            },
            // 定期預金口座開設(ご新規・お預入れ) スワイプなし
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.TimeDepositNew,
                selectedFlow: 'RegularInitConfirmComponent',
                root: false,
                component: 'RegularInitConfirmComponent',
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.TIME_SAVING,
                accountTypeText: this.labels.accountTypes.header.regularDeposit,
                applyBusinessType: null,
                confirmPage: RegularHolderInfoComponent,
                confirmPageSub: RegularAgentInfoComponent,
                params: {
                    nameKana: 'holderNameFurikana',
                    birthdate: 'holderBirthdate',
                }
            },
            // キャッシュカード-初発行
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.CashCardFirstPublish,
                selectedFlow: 'CashCardMenuComponent',
                root: true,
                component: CashCardChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCardOrNot,
                accountType: AccountType.CASH_CARD,
                accountTypeText: this.labels.cashcard.title,
                applyBusinessType: ApplyBusinessType.CASHCARD_FIRST_PUBLISH,
                confirmPage: CashCardAccountComponent,
                pageIndex: 1
            },
            // キャッシュカード-暗証忘れ
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.CashCardPassword,
                selectedFlow: 'CashCardMenuComponent',
                root: true,
                component: CashCardChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCardOrNot,
                accountType: AccountType.CASH_CARD,
                accountTypeText: this.labels.cashcard.title,
                applyBusinessType: ApplyBusinessType.CASHCARD_PASSWORD,
                confirmPage: CashCardAccountComponent,
                pageIndex: 1
            },
            // キャッシュカード-破損・磁気不良
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.CashCardBroken,
                selectedFlow: 'CashCardMenuComponent',
                root: true,
                component: CashCardChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCardOrNot,
                accountType: AccountType.CASH_CARD,
                accountTypeText: this.labels.cashcard.title,
                applyBusinessType: ApplyBusinessType.CASHCARD_BROKEN,
                confirmPage: CashCardAccountComponent,
                pageIndex: 1
            },
            // キャッシュカード-紛失・盗難
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.CashCardLost,
                selectedFlow: 'CashCardMenuComponent',
                root: true,
                component: CashCardChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCardOrNot,
                accountType: AccountType.CASH_CARD,
                accountTypeText: this.labels.cashcard.title,
                applyBusinessType: ApplyBusinessType.CASHCARD_LOST,
                confirmPage: CashCardAccountComponent,
                pageIndex: 1
            },
            // バンクカード用
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.CreditCardFistPublish,
                selectedFlow: 'CreditCardCommonComponent',
                root: true,
                component: CreditCardChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCard,
                accountType: AccountType.CREDIT_CARD,
                accountTypeText: this.labels.creditcard.titleHeader,
                applyBusinessType: null,
                checkComponent: 'CreditCardCheckApplyComponent',
                confirmPage: CreditCardConfirmComponent,
                params: {
                    nameKana: 'holderNameFurikana',
                    birthdate: 'holderBirthdate',
                },
            },
            // 定期預金払い戻し
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.CancellationReserve,
                selectedFlow: 'CancelInitComponent',
                root: true,
                component: CancelChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCard,
                accountType: AccountType.CANCEL,
                accountTypeText: this.labels.cancel.title,
                applyBusinessType: ApplyBusinessType.CANCELLATION,
                checkComponent: 'CancelIdentificationDocumentComponent',
                confirmPage: CancelComponent
            },
            // 各種お手続き(変更・自動振り込み等)-住所変更
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.ChangeAddress,
                selectedFlow: 'ChangeChatComponent',
                root: true,
                component: ChangeChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCardOrNot,
                accountType: AccountType.CHANGE,
                accountTypeText: this.labels.change.completion.headerTitle,
                applyBusinessType: ApplyBusinessType.CHANGE_NAME_ADDRESS,
                confirmPage: ChangeFinishComponent
            },
            // 各種お手続き(変更・自動振り込み等)-氏名変更
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.ChangeName,
                selectedFlow: 'ChangeChatComponent',
                root: true,
                component: ChangeChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCardOrNot,
                accountType: AccountType.CHANGE,
                accountTypeText: this.labels.change.completion.headerTitle,
                applyBusinessType: ApplyBusinessType.CHANGE_NAME_ADDRESS,
                confirmPage: ChangeFinishComponent
            },
            // 普通預金口座開設（既存）
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.OrdinaryDeposit,
                selectedFlow: 'ExistingSavingsVerificationComponent',
                root: true,
                component: ExistingSavingsChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCard,
                accountType: AccountType.EXISTING_SAVINGS,
                accountTypeText: this.labels.existingSavings.title,
                applyBusinessType: ApplyBusinessType.EXISTING_ORDINARY_DEPOSIT,
                confirmPage: [ExistingSavingsConfirmComponent, ExistingSavingsChangeConfirmComponent],
                checkComponent: 'SelfCheckApplyComponent',
                params: {
                    nameKana: 'holderNameFurigana',
                    birthdate: 'holderBirthdate',
                }
            },
            // 貯蓄預金口座開設（既存）
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.StorageDeposit,
                selectedFlow: 'ExistingSavingsVerificationComponent',
                root: true,
                component: ExistingSavingsChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCard,
                accountType: AccountType.EXISTING_STORAGE,
                accountTypeText: this.labels.existingStorage.title,
                applyBusinessType: ApplyBusinessType.EXISTING_ORDINARY_DEPOSIT_SAVINGS_DIPOSIT,
                confirmPage: ExistingSavingsConfirmComponent,
                params: {
                    nameKana: 'holderNameFurigana',
                    birthdate: 'holderBirthdate',
                },
            },
            // 定期預金口座開設(ご新規・お預入れ) スワイプあり
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.TimeDepositNew,
                selectedFlow: 'ExistingReserveComponent',
                root: true,
                component: ExistingReserveChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCard,
                accountType: AccountType.EXISTING_RESERVE,
                accountTypeText: this.labels.accountTypes.header.regularDeposit,
                applyBusinessType: null,
                checkComponent: 'ExistingCheckApplyComponent',
                confirmPage: ExistingRegularConfirmComponent,
                confirmPageSub: ExistingReserveClerkConfirmationComponent,
                params: {
                    nameKana: 'holderNameFurikana',
                    birthdate: 'holderBirthdate',
                },
            },
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.StudentDeposit,
                selectedFlow: 'StudentNewInitComponent',
                root: true,
                component: StudentChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.STUDENT_NEW,
                accountTypeText: this.labels.student.newTitle,
                applyBusinessType: ApplyBusinessType.STUDENT_NEW,
                confirmPage: StudentNewConfirmComponent,
                confirmPageSub: StudentNewAgentConfirmComponent,
                params: {
                    nameKana: 'holderNameFurigana',
                    birthdate: 'holderBirthdate',
                }
            },
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.StudentDeposit,
                selectedFlow: 'StudentChangeComponent',
                root: true,
                component: StudentChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCard,
                accountType: AccountType.STUDENT_CHANGE,
                accountTypeText: this.labels.student.changeTitle,
                applyBusinessType: ApplyBusinessType.STUDENT_CHANGE,
                confirmPage: StudentChangeConfirmComponent
            },
            // 相続
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.Inherit,
                selectedFlow: 'InheritChatComponent',
                root: true,
                component: InheritChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCardOrNot,
                accountType: AccountType.INHERIT,
                accountTypeText: this.labels.inherit.title,
                applyBusinessType: ApplyBusinessType.INHERIT,
                confirmPage: StaffConfirmationComponent
            },
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.PointDirect,
                selectedFlow: 'PointDirectChatComponent',
                root: true,
                component: PointDirectChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCard,
                accountType: AccountType.POINT_DIRECT,
                accountTypeText: this.labels.pointDirect.title,
                applyBusinessType: undefined,
                confirmPage: undefined
            },
            // 自動振込
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.AutomaticTransfer,
                selectedFlow: 'AutomaticTransferChatComponent',
                root: true,
                component: AutomaticTransferChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCard,
                accountType: AccountType.AUTOMATIC_TRANSFER,
                accountTypeText: this.labels.automaticTransfer.title,
                applyBusinessType: ApplyBusinessType.AUTOMATIC_TRANSFER,
                confirmPage: AutomaticTransferConfirmComponent
            },
            // 定期預金書替
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.TimeDepositContinue,
                selectedFlow: 'TimeDepositRewritingChatComponent',
                root: true,
                component: TimeDepositRewritingChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCard,
                accountType: AccountType.TIME_DEPOSIT_REWRITING,
                accountTypeText: this.labels.timeDepositRewriting.title,
                applyBusinessType: ApplyBusinessType.TIME_DEPOSIT_REWRITING,
                confirmPage: undefined
            },
            // 普通\口座開設（外国人申込用）
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.OrdinaryDeposit,
                selectedFlow: 'ForeignerCheckapplyComponent',
                root: true,
                component: ForeignerCheckapplyComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.FOREIGN_SAVINGS,
                accountTypeText: this.labels.change.accountTypesStyle.title,
                applyBusinessType: ApplyBusinessType.ORDINARY_DEPOSIT_FOREIGN,
                confirmPage: ExistingSavingsForeignConfirmComponent,
                checkComponent: 'ForeignerCheckapplyComponent',
                params: {
                    nameKana: 'holderNameFurigana',
                    birthdate: 'holderBirthdate',
                }
            },
            // 喪失・発見・再発行
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.CashCardLost,
                selectedFlow: 'LossReissueFindingChatComponent',
                root: true,
                component: LossReissueFindingChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCardOrNot,
                accountType: AccountType.LOSS_REISSUE_FINDING,
                accountTypeText: this.labels.lossReissueFinding.titleHeader,
                applyBusinessType: ApplyBusinessType.LOSS,
                confirmPage: [ChangeFinishComponent, ReissueConfirmComponent, LossConfirmComponent],
                checkComponent: 'ReissueDocumentComponent'
            },
            // 解約
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.CancellationNormal,
                selectedFlow: 'TerminateChatComponent',
                root: true,
                component: TerminateChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.TERMINATE,
                accountTypeText: this.labels.terminate.headerTitle,
                applyBusinessType: ApplyBusinessType.ACTIVE,
                confirmPage: [TerminateConfirmComponent, TerminateCounterConfirmComponent]
            },
            // 口座状態照会
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.ClerkAccountStatusInquiry,
                selectedFlow: 'ClerkChatComponent',
                root: true,
                component: ClerkChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.CLERK_ACCOUNT_STATUS_INQUIRY,
                accountTypeText: this.labels.clerk.headerTitle,
                applyBusinessType: ApplyBusinessType.CLERK_ACCOUNT_STATUS_INQUIRY,
                confirmPage: undefined,
                /*confirmPage: TerminateConfirmComponent*/
            },
            // 口座状態照会
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.ClerkAccountStatusInquiry,
                selectedFlow: 'ClerkChatComponent',
                root: true,
                component: ClerkChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.CLERK_ACCOUNT_STATUS_INQUIRY,
                accountTypeText: this.labels.clerk.headerTitle,
                applyBusinessType: ApplyBusinessType.CLERK_ACCOUNT_STATUS_INQUIRY,
                confirmPage: undefined
            },
            // カード差替
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.CashCardBroken,
                selectedFlow: 'ReplacementChatComponent',
                root: true,
                component: ReplacementChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeCardOrNot,
                accountType: AccountType.REPLACEMENT,
                accountTypeText: this.labels.replacement.titleHeader,
                applyBusinessType: ApplyBusinessType.REPLACEMENT,
                confirmPage: [ChangeFinishComponent, ReplacementInitConfirmComponent, ReplacementConfirmComponent],
                checkComponent: 'ReplacementDocumentComponent'
            },
            // マイナンバー
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.MyNumber,
                selectedFlow: 'MynumberChatComponent',
                root: true,
                component: MynumberChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.MYNUMBER,
                accountTypeText: this.labels.mynumber.headerTitle,
                applyBusinessType: ApplyBusinessType.MYNUMBER,
                confirmPage: [MynumberInitConfirmComponent, MynumberConfirmComponent]
            },
            // カード新規発行
            {
                purpose: COMMON_CONSTANTS.EQPurposeType.CashCardFirstPublish,
                selectedFlow: 'NewestChatComponent',
                root: true,
                component: NewestChatComponent,
                swipecif: COMMON_CONSTANTS.SwipeCardType.SwipeNoCard,
                accountType: AccountType.NEWEST,
                accountTypeText: this.labels.newest.titleHeader,
                applyBusinessType: ApplyBusinessType.NEWEST,
                confirmPage: [ChangeFinishComponent, NewestInitConfirmComponent, NewestConfirmComponent],
                checkComponent: 'NewestDocumentComponent'
            }
        ];

        this.action.setChatFlowInfo(chatFlowInfo);
    }
}
