import { EventEmitter, Output, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { InjectionUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { Content } from 'ionic-angular';

export interface OnRenderer {
    onText?(entity: SavingQuestionsModel, pageIndex: number): void;
    onButton?(entity: SavingQuestionsModel, pageIndex: number): void;
    onKeybord?(entity: SavingQuestionsModel, pageIndex: number): void;
    onNumberKeybord?(entity: SavingQuestionsModel, pageIndex: number): void;
    onRoute?(entity: SavingQuestionsModel, pageIndex: number): void;
    onJudge?(entity: SavingQuestionsModel, pageIndex: number): void;
    onSaveSubmit?(entity: SavingQuestionsModel, pageIndex: number): void;
}

/**
 * chat flow renderer.
 */
export abstract class ChatFlowRenderer extends BaseComponent implements OnRenderer {
    public abstract processType: number;
    public _action: SavingsAction;
    public _store: SavingsStore;
    @Output() public nextChatEvent = new EventEmitter();
    @ViewChild(Content) public content: Content;

    constructor() {
        super();
        this._action = InjectionUtils.injector.get(SavingsAction);
        this._store = InjectionUtils.injector.get(SavingsStore);
    }

    public abstract loadTemplate(pageIndex: number);

    public onText(entity: SavingQuestionsModel, pageIndex: number): void {
        this.getNextChat(entity.next, pageIndex);
    }

    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onButton');
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onKeybord');
    }

    public onNumberKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onNumberKeybord');
    }

    public onPassword(entity: SavingQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onPassword');
    }

    public onAccountInfoInput(entity: SavingQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onAccountInfoInput');
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onJudge');
    }

    public onSaveSubmit(entity: SavingQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onSaveSubmit');
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        switch (question.type) {
            case 'text': {
                this.onText(question, pageIndex);
                break;
            }
            case 'button': {
                this.onButton(question, pageIndex);
                break;
            }
            case 'image': {
                this.getNextChat(question.next, pageIndex);
                break;
            }
            case 'judge': {
                this.onJudge(question, pageIndex);
                break;
            }
            case 'keybord': {
                this.onKeybord(question, pageIndex);
                break;
            }
            case 'numberKeybord': {
                this.onNumberKeybord(question, pageIndex);
                break;
            }
            case 'route': {
                this.chatFlowCompelete(question.example, question.options);
                this.getNextChat(question.next, pageIndex, 0);
                break;
            }
            case 'needpassword': {
                this.onPassword(question, pageIndex);
                break;
            }
            case 'accountInfoInput': {
                this.onAccountInfoInput(question, pageIndex);
                break;
            }
            case 'saveSubmit': {
                this.onSaveSubmit(question, pageIndex);
                break;
            }
        }
    }

    protected getNextChat(order: number, pageIndex: number, nextChatDelay?: number) {
        this.nextChatEvent.emit({ order: order, pageIndex: pageIndex, nextChatDelay: nextChatDelay });
    }

    protected setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this._action.setAnswer(answer);
    }

    protected chatFlowCompelete(nextChatName?: string, options: any = null) {
        this._action.chatFlowCompelete(nextChatName, options);
    }

    protected chatFlowReturn(nextChatName?: string, options: any = null) {
        this._action.chatFlowReturn(nextChatName, options);
    }
}
