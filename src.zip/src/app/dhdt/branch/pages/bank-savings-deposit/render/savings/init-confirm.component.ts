import { ViewContainerRef } from '@angular/core';
import { ObjectUtils } from 'adep/utils';
import { AppProperties } from 'app.properties';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { AccountType, COMMON_CONSTANTS, PrincipalAgentCategory } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';

/**
 * Init confirm component(普通(貯蓄)預金 - 初期確認事項画面).
 */
export class InitConfirmComponent extends ChatFlowRenderer {
    public processType = 0;
    private state: SavingsState;

    constructor(private chatFlowAccessor: ChatFlowAccessor,
                private footerContent: ViewContainerRef,
                private store: SavingsStore,
                private loginStore: LoginStore,
                private modalService: ModalService,
                private audioService: AudioService,
    ) {
        super();
        this.state = this.store.getState();
    }

    public loadTemplate(pageIndex: number) {
        // this._action.loadTemplate('test-template.json', pageIndex);
        this._action.loadTemplate('chat-flow-def-initialconfirm.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'datepicker': {
                this.onPicker(question, pageIndex);
                break;
            }
        }
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {

        const choices = this.changeValidationRuleMax(entity, this.state.submitData);
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                let maxLenth;
                if (choices && choices.length > 0) {
                    maxLenth = InputUtils.calculateMaxLength(choices[0].name,
                        this.state.submitData.holderAddressStreetNameFuriKanaInput,
                        this.state.submitData.holderAddressStreetNameFuriKanaSelect);
                }

                InputUtils.getKanjiToKana(answer.value, maxLenth).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    if (entity.fullwidthHalfwidthDivisionCode) {
                        this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                        this.store.registerSignalHandler(SavingsSignal.CHARACTER_CHECK, (data) => {
                            this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                            this.getNextChat(entity.next, pageIndex);
                        });
                        const params = {
                            tabletApplyId: this._store.getState().tabletApplyId,
                            params: {
                                receptionTenban: this.loginStore.getState().belongToBranchNo,
                                checkStrings: [{
                                    checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                    checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                }],
                            }
                        };
                        this._action.characteCheck(params, () => {
                            this._action.editChart(entity.order, pageIndex,
                                this.state.showChats[this.state.showChats.length - 1].answer.order);
                            this.getNextChat(entity.order, pageIndex);
                        });
                    } else {
                        this.getNextChat(entity.next, pageIndex);
                    }
                });
            });
    }

    /**
     * ピッカーコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onPicker(entity: SavingQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }
        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData,
            value: undefined
        };

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    if (choice.next !== -1) {
                        if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT_CHILDREN) {
                            this._action.setStateSubmitDataValue({
                                name: COMMON_CONSTANTS.KEY_IS_AGENT,
                                value: PrincipalAgentCategory.AGENT,
                            });
                        }
                        this.getNextChat(choice.next, pageIndex);
                        return;
                    } else {
                        this.configAction(choice, pageIndex);
                    }
                }
            });
        }
    }

    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                if (!answer.action ||
                    (answer.action.value !== 'noticeButtonModal' &&
                    answer.action.type !== COMMON_CONSTANTS.ACTION_TYPE_MODAL)) {
                        this.setAnswer({
                            text: answer.text,
                            value: [
                                { key: entity.name, value: answer.value },
                                { key: answer.name, value: answer.value }
                            ]
                        });
                }
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'modal') {
            if (action.value === 'modalNextChat') {
                this.modalService.showModal('noticeButtonModal', { imgSrc: COMMON_CONSTANTS.LINE_OFFICIAL_ACCOUNT },
                    (result) => {
                        this.getNextChat(choice.next, pageIndex);
                });
            } else {
                this.modalService.showModal(action.value, { imgSrc: COMMON_CONSTANTS.REGULATIONS_KOUZA_TOKUCHOU });
            }
        } else if (action.type === 'admin') {
            this.audioService.subject.next(true);
            this.chatFlowCompelete();
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }

    /**
     * change ValidationRule Max length
     * @param entity チャットフローエンティティー
     * @param submitData データ
     */
    private changeValidationRuleMax(entity: any, submitData: any) {
        const choicesResult = ObjectUtils.clone(entity.choices);

        // 「町丁名（漢字）」の入力済桁数により、「番地以降（漢字）」の入力可能最大桁数を調整する
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW
            && submitData.holderAddressStreetNameSelect
            && submitData.holderAddressStreetNameSelect.length > 0) {
            let holderAddressStreetLength = 0;
            holderAddressStreetLength = submitData.holderAddressStreetNameSelect.length;
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max - holderAddressStreetLength;
        } else if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW
            && choicesResult[0].name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER
            && submitData.holderAddressStreetNameInput
            && submitData.holderAddressStreetNameInput.length > 0) {
            let holderAddressStreetLength = 0;
            holderAddressStreetLength = submitData.holderAddressStreetNameInput.length;
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max - holderAddressStreetLength + 1;
        }

        // 「町丁名（カナ）」の入力済桁数により、「番地以降（カナ）」の入力可能最大桁数を調整する
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FURIKANA_FOR_SHOW
            && choicesResult.length > 1
            && choicesResult[0].name === 'holderAddressStreetNameFuriKanaInput'
            && choicesResult[1].name === 'holderAddressHouseNumberFuriKana') {
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max -
                submitData.holderAddressStreetNameFuriKanaSelect.length;
        }

        return choicesResult;
    }

}
