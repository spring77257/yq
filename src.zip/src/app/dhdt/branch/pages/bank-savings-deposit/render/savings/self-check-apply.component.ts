import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import { SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    AntiSocietyAnswer, ChatOption, COMMON_CONSTANTS, Constants, HasDriversCareerLicense,
    IdentityDocumentType, IsModifyJudge, JudgeResultStatus
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import * as moment from 'moment';

/**
 * Self Check apply component(情報入力画面（本人確認書類聴取）_OCR読取有無).
 */
export class SelfCheckApplyComponent extends ChatFlowRenderer {

    public processType = 1;

    private state: SavingsState;

    private backupDataService: BackupDataService;
    private serverInfoService: ServerInfoService;

    constructor(
        private chatFlowAccessor: ChatFlowAccessor,
        private footerContent: ViewContainerRef
    ) {
        super();
        this.state = this._store.getState();
        this._action.setCustomerApplyStartDate();
        this.backupDataService = InjectionUtils.injector.get(BackupDataService);
        this.serverInfoService = InjectionUtils.injector.get(ServerInfoService);
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-self-checkapply.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'datepicker': {
                this.onPicker(question, pageIndex);
                break;
            }
        }
    }

    /**
     * ピッカーコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onPicker(entity: SavingQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }
        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData,
            value: undefined
        };

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this._action.setStateSubmitDataValue({
                    name: IdentityDocumentType.AGENT_IDENTITY_DOCUMENT_EXPIRY_DATE,
                    value: answer.value[0].value
                });
                this._action.setStateSubmitDataValue({
                    name: IdentityDocumentType.AGENT_IDENTITY_DOCUMENT_EXPIRY_DATE + 'Text',
                    value: answer.text
                });
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            options.furiganaOnly = ChatOption.VALIDATION_ON;
            options.kanaText = this.backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                    ]
                });

                if (/identificationDocument\d/.test(entity.name)) {
                    this._action.setStateSubmitDataValue({
                        name: entity.name + 'Text',
                        value: answer.text
                    });
                }
            }
            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                if (answer.name === 'backToRelateChat') {
                    this._action.gobackRelateChat();
                }
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const choices = InputUtils.changeValidationRuleMax(entity, this.state.submitData);

        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    this.getNextChat(entity.next, pageIndex);
                });
            });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        if (entity.option === 'url') {
            this.serverInfoService.getInfoFormServe(entity.name).subscribe((result) => {
                entity.choices.forEach((choice) => {
                    if (result === choice.value) {
                        this.getNextChat(choice.next, pageIndex);
                        return;
                    }
                });
            });
        } else if (entity.choices) {
            let choice = null;
            if (entity.name === 'isHaveMobile') {
                // 携帯電話あるかどうかの判断
                judgeResult = this.state.submitData.firstMobileNo ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                choice = entity.choices.find((item) => judgeResult === item.value);
                this.getNextChat(choice ? choice.next : entity.next, pageIndex);
            } else if (entity.name === 'isHaveTel') {
                // 固定電話あるかどうかの判断
                judgeResult = this.state.submitData.firstTel ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                choice = entity.choices.find((item) => judgeResult === item.value);
                this.getNextChat(choice ? choice.next : entity.next, pageIndex);
            } else if (entity.name === 'attributeCheck') {
                choice = this.haveNoInAntiSocietyAnswer() ? entity.choices.find((item) => AntiSocietyAnswer.NO === item.value)
                    : entity.choices.find((item) => AntiSocietyAnswer.YES === item.value);
                this.getNextChat(choice ? choice.next : entity.next, pageIndex);
                // 純新規
            } else if (entity.name === 'ifAllIdentificationCode80or90') {
                judgeResult = '0';
                this.goToNextChat(entity, judgeResult, pageIndex);
            } else if (entity.name === 'HasDriversCareerLicenseChatControl') {
                judgeResult = '0';
                // 修正チャットかつ運転経歴証明書選択の場合、書類選択のチャットをスキップさせる
                if (this.state.submitData.isModify === IsModifyJudge.IsModify
                    && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES) {
                    judgeResult = '1';
                }
                this.goToNextChat(entity, judgeResult, pageIndex);
            } else if (entity.name === 'isNeedIssueCashCard') {
                judgeResult = '02';
                this.goToNextChat(entity, judgeResult, pageIndex);
            } else if (entity.name === 'isExpiryDateExists') {
                judgeResult = JudgeResultStatus.RESULT_0;
                // 修正チャットかつ、書類1の有効期限なしのとき、有効期限確認チャットを表示せず必須入力させる
                if (this.state.submitData.isModify === IsModifyJudge.IsModify
                    && this.state.modifyExpiryDateExists) {
                    judgeResult = JudgeResultStatus.RESULT_1;
                }
                this.goToNextChat(entity, judgeResult, pageIndex);
            } else {
                choice = entity.choices.find((item) => this.state.submitData[entity.name] === item.value);
                this.getNextChat(choice ? choice.next : entity.next, pageIndex);

            }
        }
    }

    private goToNextChat(entity: SavingQuestionsModel, judgeResult: string, pageIndex: number) {
        entity.choices.forEach((choice) => {
            if (judgeResult === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }
    /**
     * 反社会の質問の中に、いいえが回答したことあるかどうか判断
     *
     * @private
     * @returns {boolean} true: いいえの回答がある  false: 全部はいの回答
     * @memberof SelfCheckApplyComponent
     */
    private haveNoInAntiSocietyAnswer(): boolean {
        return this.state.submitData.nameKanjiCheck === AntiSocietyAnswer.NO
            || this.state.submitData.nameKanaCheck === AntiSocietyAnswer.NO
            || this.state.submitData.addressKanjiCheck === AntiSocietyAnswer.NO
            || this.state.submitData.birthdateCheck === AntiSocietyAnswer.NO;
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_RETURN_TO_CHAT) {
            this.chatFlowReturn(action.value);
        }
    }
}
