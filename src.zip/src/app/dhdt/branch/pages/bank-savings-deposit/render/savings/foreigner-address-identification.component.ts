import { ViewContainerRef } from '@angular/core';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsState } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    Age, COMMON_CONSTANTS, Constants, IsModifyJudge
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { Career, IsNearGraduate } from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { JudgeResultStatus } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import { ButtonCameraComponent } from 'dhdt/branch/shared/components/button-group/button-camera.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import * as moment from 'moment';

/**
 * foreigner address identification component情報入力画面（外国人確認書類聴取）現住所確認書類確認（在留カード or 特別永住者証明書）.
 */
export class ForeignerAddressIdentificationComponent extends ChatFlowRenderer {

    public processType = 1;

    private state: SavingsState;

    constructor(
        private chatFlowAccessor: ChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private creditCardStore: CreditCardStore
    ) {
        super();
        this.state = this._store.getState();
        this._action.setCustomerApplyStartDate();
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-foreigner-address-identification.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'cameraButton': {
                this.onCameraButton(question, pageIndex);
                break;
            }
            case 'keybord': {
                this.onKeybord(question, pageIndex);
                break;
            }
            case 'datepicker': {
                this.onPicker(question, pageIndex);
                break;
            }
        }
    }

    public onSaveSubmit(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((item: any) => {
                this._action.setStateSubmitDataValue(item);
            });
            this.getNextChat(entity.next, pageIndex);
        }
    }

    public onPicker(entity: SavingQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }

        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData,
            skip: {
                text: this.labels.picker.skipExpiryDate,
                width: 224,
                height: 64,
                marginRight: 32,
                marginBottom: 32
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer !== COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            ...answer.value,
                            {
                                key: entity.name + 'Text',
                                value: answer.text
                            }
                        ]
                    });
                } else {
                    this.setAnswer({
                        text: this.labels.picker.skipExpiryDate,
                        value: [{
                            key: entity.name,
                            value: COMMON_CONSTANTS.DEFAULT_EXPIRY_DATE
                        }, {
                            key: entity.name + 'Text',
                            value: this.labels.picker.skipExpiryDate
                        }]
                    });
                }
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onCameraButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options: any = {
            saveFrontPhotoKey: 'holderCardImageFront',
            saveBackPhotoKey: 'holderCardImageBack',
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        // 写真を取ろうする書類の格納変数の値を取得
        const currentImg = this.state.submitData[this._store.documentMap.get(this.state.submitData.category)];
        // 書類に写真が存在する場合は、skipを渡す
        if (currentImg && currentImg.length > 0 && entity.skip) {
            options.skip = entity.skip;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonCameraComponent, this.footerContent, options
        ).subscribe((answer: any) => {
            if (answer === 'skip') {
                this.setAnswer({
                    text: 'スキップ',
                    value: undefined
                });

                this.chatFlowAccessor.clearComponent();
                this.getNextChat(entity.skip, pageIndex);
            } else {
                if (answer.image) {
                    this._action.saveIdentityDocumentImage({
                        image: answer.image,
                        category: this.state.submitData.category
                    });
                }

                if (answer.chatFlowChoice.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.chatFlowChoice.next, pageIndex);
                }
            }
        });
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const choices = InputUtils.changeValidationRuleMax(entity, this.state.submitData);

        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    this.getNextChat(entity.next, pageIndex);
                });
            }
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                if (entity.name === 'addIdentityDocumentImg' && answer.value === '1') {
                    const choice = entity.choices ? entity.choices.find((item) => item.value === answer.value) : undefined;
                    this._action.resetLastNode({
                        order: choice ? choice.next : entity.order,
                        pageIndex: pageIndex
                    });
                } else {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {

        if (entity.name === 'checkDocumentCategory') {
            const choice = entity.choices.find((item) => item.value === this.state.submitData.category);
            if (choice) {
                this.getNextChat(choice.next, pageIndex);
            }
        } else if (entity.name === 'checkDocumentType') {
            const choice = entity.choices.find((item) => {
                if (this.state.submitData.category === Constants.IdentityDocumentCategory.AgentDocument1) {
                    if (this.state.submitData.agentIdentificationDocument1 === Constants.MyNumberCard) {
                        return item.value;
                    }
                }
                return !item.value;
            });
            if (choice) {
                this.getNextChat(choice.next, pageIndex);
            }
        } else if (entity.name === 'validationAge16') {
            // 16歳以上 or 16歳未満 のLogic
            // 定年齢未満チェック (指定年齢未満の場合: false)
            const result = this.validateAge(this.state.submitData.birthdate, Age.Age_16,
                this.state.submitData.customerApplyStartDate);

            const choice = entity.choices.find((item) => item.value === result);

            if (choice) {
                this.getNextChat(choice.next, pageIndex);
            }
        } else if (entity.name === 'existsKanjiName') {
            const existsKanjiName: string = this.state.submitData.firstNameKanji && this.state.submitData.lastNameKanji ? '1' : '0';
            const choice = entity.choices.find((item) => item.value === existsKanjiName);
            if (choice) {
                this.getNextChat(choice.next, pageIndex);
            }
        } else if (entity.name === 'ifApplyBC')  {
            const choice = entity.choices.find((item) => {
                return item.value === this.state.submitData[entity.name];
            });
            this.getNextChat(choice ? choice.next : entity.next, pageIndex);
        }  else if (entity.name === 'isStudent') {
            // 学生かどうか判定（BC複合のみ）
            const judgeResult = this.creditCardStore.getState().submitData.career === Career.STUDENT
                || this.creditCardStore.getState().submitData.isNearGraduate === IsNearGraduate.YES
                ? 'true' : 'false';
            const result = entity.choices.find((item) => item.value === judgeResult);
            this.getNextChat(result.next, pageIndex);
            return;
        } else if (entity.name === 'isModify') {
            // 修正チャットかどうか判定
            const judgeResult = this.state.submitData.isModify === IsModifyJudge.IsModify ?
                IsModifyJudge.IsModify : IsModifyJudge.IsNotModify;
            const result = entity.choices.find((item) => item.value === judgeResult);
            this.getNextChat(result.next, pageIndex);
            return;
        }
    }

    /**
     * 指定年齢未満チェック
     * @param birthday 西暦の日付 [フォーマット:yyyyMMdd]
     * @param age 指定年齢
     * @returns 指定年齢未満の場合: false
     */
    private validateAge(birthday: string, age: number, today: string): boolean {
        // 日付フォーマット
        const birthdayMo = moment(birthday, COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
        const todayMo = moment(today);

        return todayMo.isAfter(birthdayMo.add(age, 'y'));
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }
}
