import { ViewContainerRef } from '@angular/core';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * Regular select category component(定期預金　新規・入金 - 商品分類選択画面).
 */
export class RegularSelectCategoryComponent extends ChatFlowRenderer {
    public processType = 1;

    private state: SavingsState;

    constructor(private chatFlowAccessor: ChatFlowAccessor, private footerContent: ViewContainerRef,
                private store: SavingsStore, private modalService: ModalService) {
        super();
        this.state = this.store.getState();
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-regular-select-category.yml', pageIndex);
    }

    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
        .subscribe((answer) => {
            if (answer.action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
                this.modalService.showModal(answer.action.value, { imgSrc: answer.action.imgSrc, cssClass: 'settings-modal-h698' });
            }
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value }
                    ]
                });
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    private configAction(choice: any) {
        const action = choice.action;
        if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }
}
