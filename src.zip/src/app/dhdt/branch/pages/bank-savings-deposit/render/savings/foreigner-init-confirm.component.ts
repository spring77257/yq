import { ViewContainerRef } from '@angular/core';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import { SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { AccountType, COMMON_CONSTANTS, PrincipalAgentCategory } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * Init confirm component(普通(貯蓄)預金 - 初期確認事項画面).
 */
export class ForeignerInitConfirmComponent extends ChatFlowRenderer {
    public processType = 0;
    private state: SavingsState;

    private backupDataService: BackupDataService;

    constructor(private chatFlowAccessor: ChatFlowAccessor,
                private footerContent: ViewContainerRef,
                private store: SavingsStore,
                private modalService: ModalService,
                private audioService: AudioService,
    ) {
        super();
        this.state = this.store.getState();

    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-foreigner-initialconfirm.yml', pageIndex);
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    if (choice.next !== -1) {
                        if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT_CHILDREN) {
                            this._action.setStateSubmitDataValue({
                                name: COMMON_CONSTANTS.KEY_IS_AGENT,
                                value: PrincipalAgentCategory.AGENT,
                            });
                        }
                        this.getNextChat(choice.next, pageIndex);
                        return;
                    } else {
                        this.configAction(choice, pageIndex);
                    }
                }
            });
        }
    }

    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                if (!answer.action ||
                    (answer.action.value !== 'noticeButtonModal' &&
                    answer.action.type !== COMMON_CONSTANTS.ACTION_TYPE_MODAL)) {
                        this.setAnswer({
                            text: answer.text,
                            value: [
                                { key: entity.name, value: answer.value },
                                { key: answer.name, value: answer.value }
                            ]
                        });
                }
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'modal') {
            if (action.value === 'modalNextChat') {
                this.modalService.showModal('noticeButtonModal', { imgSrc: COMMON_CONSTANTS.LINE_OFFICIAL_ACCOUNT },
                    (result) => {
                        this.getNextChat(choice.next, pageIndex);
                });
            } else {
                this.modalService.showModal(action.value, { imgSrc: COMMON_CONSTANTS.REGULATIONS_KOUZA_TOKUCHOU });
            }
        } else if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }

}
