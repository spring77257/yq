import { ViewContainerRef } from '@angular/core';
import { DeviceService } from 'dhd/common/services/device.service';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { BsdAgentConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/savings/bsd-agent-confirm.component';
import {
    AccountType, Age, CodeCategory, COMMON_CONSTANTS, IdentificationCode, JudgeResultStatus, NameNonConvert, PrincipalAgentCategory
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardChatComponent } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat.component';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { CardListComponent } from 'dhdt/branch/shared/components/card-list/card-list.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { ModalBcnoticeScrollCheckComponent } from 'dhdt/branch/shared/components/modal/modal-pdf/modal-bcnotice-scroll-check.component';
import { MultiButtonGroupComponent } from 'dhdt/branch/shared/components/multi-button-group/multi-button-group.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { RadioButtonComponent } from 'dhdt/branch/shared/components/radio-button-group/radio-button.component';
import { SignatureComponent } from 'dhdt/branch/shared/components/signature/signature.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ConfirmUtil } from 'dhdt/branch/shared/utils/confirm-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController } from 'ionic-angular';

/**
 * Apply common component(普通(貯蓄)預金 - 情報入力画面（本人申込・代理人申込共通）).
 */
export class ApplyCommonComponent extends ChatFlowRenderer {
    public processType = 1;

    private state: SavingsState;

    private phoneIsSkiped: boolean = false;
    private telIsSkiped: boolean = false;
    private careerNextOrder = '11';

    constructor(private chatFlowAccessor: ChatFlowAccessor, private footerContent: ViewContainerRef,
                private store: SavingsStore, private modalService: ModalService, private loginStore: LoginStore,
                public navCtrl: NavController, private action: SavingsAction, private modalCtrl: ModalController,
                private audioService: AudioService, public rsaEncryptService: RsaEncryptService, private confirmUtils: ConfirmUtil) {
        super();
        this.state = this.store.getState();
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-principal-agent.yml', pageIndex);
        // 受付店番号を設定(確認画面比較用)
        this._action.setStateSubmitDataValue({ name: 'receptionBranchNo', value: this.loginStore.getState().belongToBranchNo });
        this._action.saveTenbanBefore(this.loginStore.getState().belongToBranchNo);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'password6bits':
            case 'password4bits': {
                this.onPasswordInput(question, pageIndex);
                break;
            }
            case 'card': {
                this.onCard(question, pageIndex);
                break;
            }
            case 'buttonTwoCols': {
                this.onButtonTwoCols(question, pageIndex);
                break;
            }
            case 'agreedModal': {
                this.onModal(question, pageIndex);
                break;
            }
            case 'radioButton': {
                this.onRadioButton(question, pageIndex);
                break;
            }
            case 'mulitButton': {
                this.onMulitButton(question, pageIndex);
                break;
            }
            case 'sign': {
                this.onSignature(question, pageIndex);
                break;
            }
            case 'route': {
                this.chatFlowCompelete(question.example);
                this.getNextChat(question.next, pageIndex);
                break;
            }
            case 'categoryNameLogicPicker': {
                this.onCategoryNameLogicPicker(question, pageIndex, 'data');
                break;
            }
            case 'categoryNamePhysicsPicker': {
                this.onCategoryNameLogicPicker(question, pageIndex, 'filler1');
                break;
            }
            case 'complete': {
                if (question.example === 'BsdAgentConfirmComponent') {
                    this.navCtrl.setRoot(BsdAgentConfirmComponent);
                }
                break;
            }
            case 'bankCard': {
                if (question.example === 'CreditCardCommonComponent') {
                    this.navCtrl.setRoot(CreditCardChatComponent,
                        {
                            submitData: this.confirmUtils.makeSubmitDataSavingsForBc(this.state, this.loginStore.getState()),
                            tabletApplyId: this.loginStore.getState().tabletApplyId,
                            pageIndex: 0,
                            accountType: this.state.submitData.accountType,
                            customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                            cardInfo: this.state.submitData.cardInfo,
                            receptionTenban: this.loginStore.getState().belongToBranchNo,
                        });
                }
                break;
            }
            case 'selectBranch': {
                this.onSelectBranch(question, pageIndex);
                break;
            }
        }
    }

    /**
     * 固定値を保存する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSaveSubmit(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((item: any) => {
                this._action.setStateSubmitDataValue(item);
            });
            this.getNextChat(entity.next, pageIndex);
        }
    }

    public onCategoryNameLogicPicker(entity: SavingQuestionsModel, pageIndex: number, entryName?: any) {
        const options = {
            type: entity.type,
            validationRules: entity.validationRules,
            applyBizCategory: this.state.submitData.applyBizCategory,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
        };
        this.action.getCategoryNameLogic().subscribe((data) => {
            this.chatFlowAccessor.addComponent(
                data.map((item) => {
                    return {
                        text: item[entryName],
                        value: item.codeValue
                    };
                }),
                PickerCommonComponent,
                this.footerContent,
                options
            ).subscribe((answer) => {
                this.setAnswer({
                    text: answer.text,
                    value: [{
                        key: entity.name, value: answer.value[0].value
                    }, {
                        key: entity.name + 'Text', value: answer.text
                    }]
                });
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(entity.next, pageIndex);
            });
        });
    }

    public onSignature(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData
        };
        this.chatFlowAccessor.addComponent(entity.choices, SignatureComponent, this.footerContent, options).subscribe((answer) => {
            this.setAnswer({
                text: answer.text,
                value: [{
                    key: entity.name, value: answer.value
                }]
            });
            this.chatFlowAccessor.clearComponent();
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onMulitButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxLength: entity.validationRules.max
        };
        this.chatFlowAccessor.addComponent(entity.choices, MultiButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
            }

            this.chatFlowAccessor.clearComponent();

            let next = answer.next.split(COMMON_CONSTANTS.FULL_PAUSE)[0];
            if (entity.name === COMMON_CONSTANTS.HOLDER_CAREER) {
                answer.next.split(COMMON_CONSTANTS.FULL_PAUSE).forEach((order) => {
                    if (order === this.careerNextOrder) {
                        next = order;
                    }
                });
            }
            this.getNextChat(Number.parseInt(next), pageIndex);
        });
    }

    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (answer.action && answer.action.value && answer.action.value === 'pdfModal') {
                const title = answer.action.type === 'crs' ? this.labels.signature.crsExplanationTitle
                : this.labels.signature.fatcaTitle;
                this.modalService.showModal(answer.action.value, {pdfSrc: answer.action.imgSrc, title: title});
                return;
            }
            // 口座開設店の場合は改めて保存する
            if (entity.name === 'savingShopSelect') {
                this.action.setStateSubmitDataValue({
                    name: 'tenban',
                    value: this.state.submitData.tenbanBak
                });
                this.action.setStateSubmitDataValue({
                    name: 'branchName',
                    value: this.state.submitData.branchNameBak
                });
            }
            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.text }
                    ]
                });

                // BC申し込みボタンの場合はバックアップを取ります。
                // 申し込み確認画面でifApplyBCの値が変更される可能性があるので、申し込みチャットの選択肢を記録する必要があります
                if (entity.name === 'ifApplyBC') {
                    this.action.setStateSubmitDataValue(
                        {
                            name: 'ifApplyBCBak',
                            value: answer.value
                        }
                    );
                }
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    // fix 2 cols
    public onButtonTwoCols(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            maxColNum: 2,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.text }
                    ]
                });
                this.getNextChat(answer.next, pageIndex);
            });
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        if (entity.fullwidthHalfwidthDivisionCode) {
                            this.store.registerSignalHandler(SavingsSignal.CHARACTER_CHECK, (data) => {
                                this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                                this.getNextChat(entity.next, pageIndex);
                            });
                            const params = {
                                tabletApplyId: this._store.getState().tabletApplyId,
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                                    checkStrings: [{
                                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                        checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                    }],
                                }
                            };
                            this.action.characteCheck(params, () => {
                                this.action.editChart(entity.order, pageIndex,
                                    this.state.showChats[this.state.showChats.length - 1].answer.order);
                                this.getNextChat(entity.order, pageIndex);
                            });
                        } else {
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });
                }
            });
    }

    public onNumberKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                } else {
                    this.setAnswer({
                        text: answer.text,
                        value: [...answer.value,
                            {
                                key: entity.name,
                                value: answer.text
                            }
                        ]
                    });
                }

                const isShowModal = this.telSkip(entity.name, answer === 'skip');
                if (!isShowModal) {
                    this.getNextChat(answer === 'skip' ? entity.skip : entity.next, pageIndex);
                }
            });
    }

    public onPasswordInput(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            birthday: this.state.submitData.holderBirthdate,
            birthdayText: this.state.submitData.holderBirthdateText,
            telephone: [
                this.state.submitData.getHolderMobileNo(),
                this.state.submitData.getHolderTelephoneNo(),
            ],
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PasswordInputComponent,
            this.footerContent, options).subscribe((answer) => {
                if (answer === 'skip') {
                    this.chatFlowAccessor.clearComponent();
                    this.setAnswer({ text: 'スキップ', value: [] });
                } else {
                    this.chatFlowAccessor.clearComponent();
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    public onModal(entity: SavingQuestionsModel, pageIndex: number): void {
        let pdfSrc: string = '';
        switch (this.state.submitData.accountType) {
            case AccountType.ORDINARY_DEPOSIT:
                pdfSrc = COMMON_CONSTANTS.REGULATIONS_SHINKI_FUTSUU;
                break;
            case AccountType.ORDINARY_DEPOSIT_CHILDREN:
                pdfSrc = COMMON_CONSTANTS.REGULATIONS_SHINKI_KODOMO;
                break;
            case AccountType.ORDINARY_DEPOSIT_SAVINGS_DIPOSIT:
                pdfSrc = COMMON_CONSTANTS.REGULATIONS_SHINKI_CHOCHIKU;
                break;
        }

        this.modalService.showModal(entity.type, { pdfSrc: pdfSrc }, () => {
            this.navCtrl.setRoot(BsdAgentConfirmComponent);
        });
    }

    public onRadioButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, RadioButtonComponent, this.footerContent, options).subscribe((answer) => {
            if (answer.action.type === 'modal') {
                this.modalService.showModal(answer.action.value, { imgSrc: answer.imgSrc });
            }

            if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onCard(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, CardListComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: entity.name + 'ImageSrc', value: answer.imgSrc }
                ]
            });
            this.getNextChat(answer.next, pageIndex);
        });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        if (entity.name === 'below18YearExist') {
            const isBlow18 = !InputUtils.validateAge(this.state.submitData.holderBirthdate, Age.Age_18,
                this.state.submitData.tabletStartDate);
            judgeResult = isBlow18 ? '1' : '0';

            if (judgeResult === JudgeResultStatus.RESULT_1) {
                this._action.setStateSubmitDataValue({ name: 'ifApplyBC', value: '00' });
            }

            entity.choices.forEach((choice) => {
                if (judgeResult === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        } else if (entity.name === 'agentOrSelfSavingJudge') {
            judgeResult = JudgeResultStatus.RESULT_0;
            if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT ||
                this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT) {
                    // 代理人口座開設または、スワイプなし普通預金口座開設
                    judgeResult = JudgeResultStatus.RESULT_1;
            }
            entity.choices.forEach((choice) => {
                if (choice.value === judgeResult) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        } else if (entity.name === 'isChangeStore') {
            const receptionBranchNo = this.state.submitData.receptionBranchNo;
            // 受付店/受付店以外を選択したかどうかで判定
            judgeResult = this.state.submitData.tenban === receptionBranchNo ? '00' : '01';
            entity.choices.forEach((choice) => {
                if (choice.value === judgeResult) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        } else if (entity.name === 'isHaveMobile') { // 携帯電話番号あるかどうか
            judgeResult = this.state.submitData.firstMobileNo ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;

            entity.choices.forEach((choice) => {
                if (choice.value === judgeResult) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        } else if (entity.name === 'is18YearsOld') {
            // 満18歳判定
            judgeResult = InputUtils.calculateAge(this.state.submitData.holderBirthdate) === Age.Age_18 ?
                JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
            entity.choices.forEach((choice) => {
                if (choice.value === judgeResult) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        } else if (entity.choices) {
            const choice = entity.choices.find((item) => {
                return item.value === this.state.submitData[entity.name];
            });
            this.getNextChat(choice ? choice.next : entity.next, pageIndex, 0);
        }
    }

    public onSelectBranch(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxColNum: 2
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectBranchComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            // 選択された支店を設定
            this.action.changeOpenStore(answer);
            this.action.saveTenbanBefore(answer.tenban || answer.branchNo);
            this.getNextChat(entity.next, pageIndex);
        });
    }

    // if phone and tel are skiped , modal show
    private telSkip(name: string, isSkip: boolean): boolean {
        if (name === 'holderMobileNo') {
            this.phoneIsSkiped = isSkip;
        }
        if (name === 'holderTelephoneNo') {
            this.telIsSkiped = isSkip;
        }
        if (name === 'holderTelephoneNo' && this.phoneIsSkiped === true && this.telIsSkiped === true) {
            const buttonList = [
                { text: 'OK', buttonValue: 'ok' },
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.warnTelTitle,
                buttonList, () => {
                    this.action.needInputPhoenNo();
                }
            );
            return true;
        }
        return false;
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        } else if (action.type === 'modal' && action.value === 'modalNextChat') {
            // BankCardの紹介モーダルを表示
            const modal = this.modalCtrl.create(
                ModalBcnoticeScrollCheckComponent,
                { title: this._labels.creditcard.introduce.title,
                  pdfSrc: this._labels.creditcard.introduce.imgSrc },
                { cssClass: 'settings-modal-bank-card-all', enableBackdropDismiss: false }
            );

            modal.onDidDismiss(() => {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(choice.next, pageIndex);
                });

            modal.present();

        } else if (action.type === 'modal' && action.value === 'noticeButtonModal') {
            // 印鑑レスの紹介モーダルを表示
            this.modalService.showModal('noticeButtonModal', { imgSrc: COMMON_CONSTANTS.REGULATIONS_KOUZA_TOKUCHOU });
        } else if (action.type === 'resetOrder') {
            this.action.resetSpecialNode({order: parseInt(action.value, 10), pageIndex: pageIndex});
        }
    }
}
