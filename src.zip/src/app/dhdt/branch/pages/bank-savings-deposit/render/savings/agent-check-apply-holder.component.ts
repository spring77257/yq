import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import { SavingsState } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    ChatOption, COMMON_CONSTANTS, Constants, HasDriversCareerLicense,
    IdentityDocumentType, IsModifyJudge, JudgeResultStatus
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import * as moment from 'moment';

/**
 * Self Check apply component(情報入力画面（本人確認書類聴取）_OCR読取有無).
 */
export class AgentCheckApplyComponentHolder extends ChatFlowRenderer {

    public processType = 1;

    private state: SavingsState;

    private backupDataService: BackupDataService;
    private serverInfoService: ServerInfoService;

    constructor(
        private chatFlowAccessor: ChatFlowAccessor,
        private footerContent: ViewContainerRef
    ) {
        super();
        this.state = this._store.getState();
        this._action.setCustomerApplyStartDate();
        this.backupDataService = InjectionUtils.injector.get(BackupDataService);
        this.serverInfoService = InjectionUtils.injector.get(ServerInfoService);
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-agent-checkapply-holder.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'datepicker': {
                this.onPicker(question, pageIndex);
                break;
            }
        }
    }

    /**
     * ピッカーコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onPicker(entity: SavingQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }
        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData,
            value: undefined
        };

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this._action.setStateSubmitDataValue({
                    name: IdentityDocumentType.AGENT_IDENTITY_DOCUMENT_EXPIRY_DATE + 'Text',
                    value: answer.text
                });
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            options.furiganaOnly = ChatOption.VALIDATION_ON;
            options.kanaText = this.backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                    ]
                });

                if (/identificationDocument\d/.test(entity.name)) {
                    this._action.setStateSubmitDataValue({
                        name: entity.name + 'Text',
                        value: answer.text
                    });
                }
            }
            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                if (answer.name === 'backToRelateChat') {
                    this._action.gobackRelateChat();
                }
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const choices = InputUtils.changeValidationRuleMax(entity, this.state.submitData);

        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    this.getNextChat(entity.next, pageIndex);
                });
            });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.option === 'url') {
            this.serverInfoService.getInfoFormServe(entity.name).subscribe((result) => {
                entity.choices.forEach((choice) => {
                    if (result === choice.value) {
                        this.getNextChat(choice.next, pageIndex);
                        return;
                    }
                });
            });
        } else if (entity.choices) {
            let choice = null;

            if (entity.name === 'isHaveMobile') {
                // 携帯電話番号が存在するかどうかをチェック
                const judgeResult = this.state.submitData.firstMobileNo ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                choice = entity.choices.find((item) => judgeResult === item.value);
            } else if (entity.name === 'isHaveTel') {
                // 固定電話番号が存在するかどうかをチェック
                const judgeResult = this.state.submitData.firstTel ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                choice = entity.choices.find((item) => judgeResult === item.value);
            } else if (entity.name === 'HasDriversCareerLicenseChatControl') {
                let judgeResult = '0';
                // 修正チャットかつ運転経歴証明書選択の場合、書類選択のチャットをスキップさせる
                if (this.state.submitData.isModify === IsModifyJudge.IsModify
                    && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES) {
                    judgeResult = '1';
                }
                choice = entity.choices.find((item) => judgeResult === item.value);
            } else if (entity.name === 'isExpiryDateExists') {
                let judgeResult = JudgeResultStatus.RESULT_0;
                // 修正チャットかつ、書類1の有効期限なしのとき、有効期限確認チャットを表示せず必須入力させる
                if (this.state.submitData.isModify === IsModifyJudge.IsModify
                    && this.state.modifyExpiryDateExists) {
                    judgeResult = JudgeResultStatus.RESULT_1;
                }
                choice = entity.choices.find((item) => judgeResult === item.value);
            } else {
                choice = entity.choices.find((item) => this.state.submitData[entity.name] === item.value);
            }

            this.getNextChat(choice.next, pageIndex);
        }
    }

    public onSaveSubmit(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((item: any) => {
                this._action.setStateSubmitDataValue(item);
            });
            this.getNextChat(entity.next, pageIndex);
        }
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_RETURN_TO_CHAT) {
            this.chatFlowReturn(action.value);
        }
    }
}
