import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import { SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    ChatFlowChoicesText, ChatFlowChoicesValue,
    ChatFlowName, ChatOption, COMMON_CONSTANTS, Constants, EventsType, YearCalculation
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { SelectAddressComponent } from 'dhdt/branch/shared/components/address/view/select-address.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { ButtonCameraComponent } from 'dhdt/branch/shared/components/button-group/button-camera.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { OcrInfoInterface } from 'dhdt/branch/shared/interface/ocr-info.interface';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { PRODUCT_TYPE } from 'dhdt/branch/shared/utils/product-category-utils';
import { Events } from 'ionic-angular';
import * as moment from 'moment';

declare let cordova: any;

/**
 * Regular agent apply component(定期預金　新規・入金 - 情報入力画面（代理人申込用）).
 */
export class RegularAgentApplyComponent extends ChatFlowRenderer {
    public processType = 1;

    private state: SavingsState;

    private backupDataService: BackupDataService;
    private serverInfoService: ServerInfoService;
    private events: Events;

    constructor(private chatFlowAccessor: ChatFlowAccessor,
                private footerContent: ViewContainerRef,
                private store: SavingsStore,
                private audioService: AudioService,
                private modalService: ModalService,
                private loginStore: LoginStore,
                private action: SavingsAction,
    ) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
        this.backupDataService = InjectionUtils.injector.get(BackupDataService);
        this.serverInfoService = InjectionUtils.injector.get(ServerInfoService);
        this.events = InjectionUtils.injector.get(Events);
    }

    public loadTemplate(pageIndex: number) {
        // this._action.loadTemplate('agent-apply.json', pageIndex);
        this._action.loadTemplate('chat-flow-def-regular-agent-apply.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'buttonThreeCols': {
                this.onButton(question, pageIndex);
                break;
            }
            case 'datepicker':
            case 'prefecturePicker':
            case 'countyUrbanVillagePicker': {
                this.onPicker(question, pageIndex);
                break;
            }
            case 'selectAddress': {
                this.onSelectAddress(question, pageIndex);
                break;
            }
            case 'selectStreet': {
                this.onSelectStreet(question, pageIndex);
                break;
            }
            case 'cameraButton': {
                this.onCameraButton(question, pageIndex);
                break;
            }
        }
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            maxColNum: (entity.type === 'buttonThreeCols') ? 3 : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };
        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            options.furiganaOnly = ChatOption.VALIDATION_ON;
            options.kanaText = this.backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
            .subscribe((answer) => {
                if (entity.name.length > 0 && answer.value.length > 0) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }

                if (entity.name === ChatFlowName.AGENT_HASCONFIRMFILE &&
                    answer.text === ChatFlowChoicesText.AGENT_HASCONFIRMFILE_TEXT &&
                    answer.value === ChatFlowChoicesValue.AGENT_HASCONFIRMFILE_VALUE) {
                    this.updateTabletApplyInfo();
                    this.getNextChat(answer.next, pageIndex);
                } else if (answer.action.type.length > 0) {
                    this.configAction(answer, pageIndex);
                } else if (answer.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.next, pageIndex);
                }
            });
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {

        const choices = InputUtils.changeValidationRuleMax(entity, this.state.submitData);
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    this.getNextChat(entity.next, pageIndex);
                });
            });
    }

    public onNumberKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    public onPicker(entity: SavingQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        let title = entity.options ? entity.options.title : undefined;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else if (entity.name === COMMON_CONSTANTS.HOLDER_BIRTHDATE &&
            this._store.getState().submitData.selectProductType === PRODUCT_TYPE.HAPPINESS1) {
            validation = {
                ...entity.validationRules,
                max: moment(customerApplyStartDate)
                    .subtract(YearCalculation.HAPPINESS1_MIN_AGE, COMMON_CONSTANTS.DATE_YEAR)
                    .add(1, COMMON_CONSTANTS.DATE_DAY)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                min: moment(customerApplyStartDate)
                    .subtract(YearCalculation.HAPPINESS1_MAX_AGE, COMMON_CONSTANTS.DATE_YEAR)
                    .add(1, COMMON_CONSTANTS.DATE_DAY)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
            };
            title = this.labels.common.pickerHappinessTitle;
        } else {
            validation = entity.validationRules;
        }
        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: title,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData
        };
        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onSelectAddress(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectAddressComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            this.getNextChat(answer.value ? entity.next : entity.skip, pageIndex);
        });
    }

    public onSelectStreet(entity: SavingQuestionsModel, pageIndex: number): void {
        const params = {
            prefectureKanji: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillageKanji: this.state.submitData.holderAddressCountyUrbanVillage
        };
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(params, SelectStreetComponent, this.footerContent, options)
            .subscribe((result: { isSkip: boolean, text: string, value: any }) => {
                this.chatFlowAccessor.clearComponent();

                if (result.value) {
                    const answer = {
                        text: result.text,
                        value: [
                            { key: 'holderAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'holderAddressStreetNameFuriKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) },
                            { key: 'streetWork', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'showStreet', value: (result.isSkip ? undefined : result.value.streetKanji) }
                        ]
                    };
                    this.setAnswer(answer);
                    this.getNextChat(result.isSkip ? entity.skip : entity.next, pageIndex);
                } else {
                    this._action.resetLastNode({ order: entity.next, pageIndex: pageIndex });
                }
            });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.option === 'url') {
            this.serverInfoService.getInfoFormServe(entity.name).subscribe((result) => {
                entity.choices.forEach((choice) => {
                    if (result === choice.value) {
                        this.getNextChat(choice.next, pageIndex);
                        return;
                    }
                });
            });
        } else if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    public onCameraButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            saveFrontPhotoKey: 'agentCardImageFront',
            saveBackPhotoKey: 'agentCardImageBack',
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonCameraComponent, this.footerContent, options
            ).subscribe((answer: OcrInfoInterface) => {
            const values = [];
            if (answer.ocrInfo) {
                if (answer.ocrInfo.cardImageFront) {
                    this._action.setInfoFromOCR(answer.ocrInfo.ocrAnalysisInfo);
                }

                if (answer.ocrInfo.cardImageBack) {
                    this._action.setStateSubmitDataValue({
                        name: COMMON_CONSTANTS.KEY_AGENT_CARD_IMAGE_BACK,
                        value: answer.ocrInfo.cardImageBack
                    });
                }
            }

            if (entity.name.length > 0 && answer.chatFlowChoice.value.length > 0) {
                this.setAnswer({
                    text: answer.chatFlowChoice.text,
                    value: values
                });
            }

            if (answer.chatFlowChoice.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.chatFlowChoice.next, pageIndex);
            }
        });
    }

    /**
     * update tablet_apply information
     */
    private updateTabletApplyInfo() {
        const params = {
            tabletApplyId: this.store.getState().tabletApplyId,
            leaveReason: null,
            status: Constants.DBConsts.updateStatus.start,
            userMngNo: this.loginStore.getState().bankclerkId
        };
        this.action.branchStatusUpdate(params);
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'modal') {
            this.events.publish(EventsType.AUDIO_PLAY, true);
            this.modalService.showModal(action.value, undefined, (result) => {
                if (result) {
                    this.getNextChat(choice.next, pageIndex);
                }
            });
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        } else if (action.type === 'admin') {
            this.audioService.subject.next(true);
            this.chatFlowCompelete();
        }
    }
}
