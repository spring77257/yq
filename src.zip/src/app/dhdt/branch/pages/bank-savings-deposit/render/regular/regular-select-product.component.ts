import { ViewContainerRef } from '@angular/core';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { COMMON_CONSTANTS, Money } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { SelectProductComponent } from 'dhdt/branch/shared/components/select-product/select-product.component';
import { PRODUCT_TYPE, ProductCategoryUtils } from 'dhdt/branch/shared/utils/product-category-utils';
declare let cordova: any;

/**
 * Regular select product component(商品選択画面).
 */
export class RegularSelectProductComponent extends ChatFlowRenderer {
    public processType = 1;

    private state: SavingsState;

    constructor(private chatFlowAccessor: ChatFlowAccessor, private footerContent: ViewContainerRef,
                private store: SavingsStore) {
        super();
        this.state = this.store.getState();
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-regular-select-product.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'selectProduct': {
                this.onSelectProduct(question, pageIndex);
                break;
            }
        }
    }

    public onSelectProduct(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(ProductCategoryUtils.getProductInfos(), SelectProductComponent, this.footerContent, options)
        .subscribe((answer) => {
            const valueArr = [
                { key: entity.name, value: answer.category },
                {
                    key: COMMON_CONSTANTS.ELEMENT_TYPE_SELECT_PRODUCT_NAME,
                    value: ProductCategoryUtils.getProductName(answer.category)
                }
            ];
            if (answer.category === PRODUCT_TYPE.ORANGE) {
                valueArr.push({
                    key: COMMON_CONSTANTS.ELEMENT_TYPE_ACCOUNT_OPENING_DEPOSIT_AMOUNT,
                    value: Money.MONEY_0
                });
            }
            this.setAnswer({
                text: answer.name,
                value: [...valueArr]
            });
            this.chatFlowAccessor.clearComponent();
            this.getNextChat(entity.next, pageIndex);
        });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.getNextChat(choice.next, pageIndex, 0);
                    return;
                }
            });
        }
    }
}
