import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils/injection.utils';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { COMMON_CONSTANTS, Constants, CssConsts } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { NavController } from 'ionic-angular';

/**
 * QRコード Reception component(受付画面).
 */
export class ReceptionQrComponent extends ChatFlowRenderer {
    public processType = -1;
    public modalService: ModalService;

    private state: SavingsState;
    private cameraTitle: string = '';

    constructor(
        private chatFlowAccessor: ChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: SavingsStore,
        private navCtrl: NavController,
        private loginStore: LoginStore,
        private deviceService: DeviceService,
        private logging: LoggingService,
    ) {
        super();
        this._action.setTabletStartDate();
        this.state = this.store.getState();
        this.modalService = InjectionUtils.injector.get(ModalService);
    }

    /**
     * YMLファイル読み取り
     * DEV_MODE = 'true' の場合、QR読み取り有無を選べる
     * @param pageIndex 画面インデックス
     */
    public loadTemplate(pageIndex: number) {
        if (AppProperties.DEV_MODE === 'true') {
            this._action.loadTemplate('chat-flow-def-reception-qr-dev.yml', pageIndex);
        } else {
            this._action.loadTemplate('chat-flow-def-reception-qr.yml', pageIndex);
        }
    }

    /**
     * タイプにより、各コンポーネントをレンダリング
     * @param question ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'cameraScan': {
                this.onCameraScan(question, pageIndex);
                break;
            }
        }
    }

    /**
     * QRコードをスキャンするコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onCameraScan(entity: SavingQuestionsModel, pageIndex: number): void {
        // カメラタイトルを取得する
        this.cameraTitle = entity.example;

        // QRコードよりバリデーションする
        this.validateQrCode();

        // QRコードの複数回スキャンの判断結果
        this.duplicateScan();

        // QRコードをスキャンする
        this.scanQrCode();
    }

    /**
     * ボタングループのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value }
                    ]
                });
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.chatFlowCompelete(action.value);
        }
    }

    private scanQrCode(): void {
        cordova.plugins.DHDQRScan.startScan(
            {
                title: this.cameraTitle,
            },
            (qrCode) => {
                // 複合化QRコードを取得してから、該当画面へ遷移する
                this._action.getInfoFromQR(qrCode);
            },
            (errorMessage) => {
                console.log('failure with errorMessage: ' + errorMessage);
            }
        );
    }

    private validateQrCode(): void {
        this.store.registerSignalHandler(SavingsSignal.GET_INFO_QR_COMPLETE, (result) => {

            // バリデーション成功の場合
            if (result) {
                // QRコードの複数回スキャンを判断する
                const params = {
                    numberTag: this.state.receptionInfo.receptionNo,
                    numberTagPublishDate: this.state.receptionInfo.receptionTime ?
                        this.state.receptionInfo.receptionTime.substring(0, 14) : '',
                    agencyBranchNo: this.state.receptionInfo.receptionBranchNo,
                };

                // QRコードの複数回スキャンを判断するため、タブレット申込情報照会を行う
                if (this.state.receptionInfo.purpose === COMMON_CONSTANTS.EQPurposeType.AutomaticTransfer) {
                    this._action.getApplyInfoInquiry(params, false);
                } else {
                    this._action.getApplyInfoInquiry(params);
                }
                // バリデーション失敗の場合
            } else {
                this.modalService.showWarnAlert(
                    this.labels.alert.qrFailuer,
                    [{
                        text: COMMON_CONSTANTS.UPPERCASE_OK,
                        buttonValue: COMMON_CONSTANTS.LOWERCASE_OK
                    }],
                    () => {
                        this.scanQrCode();
                    });
            }
        });
    }

    // QRコードの複数回スキャンの判断結果
    private duplicateScan() {
        this.store.registerSignalHandler(SavingsSignal.GET_TABLET_COUNT_RESULT, (result) => {

            // QRコードの複数回スキャンの場合、複数業務メニュー画面へ移動
            if (result) {
                this.modalService.showWarnAlert(
                    this.labels.alert.qrFailuer,
                    [{
                        text: COMMON_CONSTANTS.UPPERCASE_OK,
                        buttonValue: COMMON_CONSTANTS.LOWERCASE_OK
                    }],
                    () => {
                        this.scanQrCode();
                    },
                    null,
                    CssConsts.CSS_CLASS_WARNING_MODAL
                );
            } else {
                // QRコードより該当フローをセレクトする
                this.selectFlowFromQrCode();

                // 申込開始、タブレット申込管理へデータを挿入する
                const tabletApplyParams = {
                    applyDate: this.loginStore.getState().applyDate,
                    applyBusinessType: this.state.submitData.applyBusinessType,
                    status: Constants.DBConsts.insertStatus,
                    deviceId: this.deviceService.getDeviceId(),
                    numberTag: this.state.submitData.receptionNo,
                    numberTagPublishDate: this.state.submitData.receptionTime ?
                        this.state.submitData.receptionTime.substring(0, 14) : '',
                    agencyBranchNo: this.state.submitData.receptionBranchNo,
                    tabletStartDate: this.state.submitData.tabletStartDate,
                    customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                    userMngNo: this.loginStore.getState().bankclerkId,
                    swipeBranchCif: this.state.submitData.swipeCif,
                    swipeBranchNo: this.state.submitData.swipeBranchNo,
                    swipeAccountNo: this.state.submitData.swipeAccountNo,
                    swipeAccountType: this.state.submitData.swipeAccountType,
                };

                // タブレット申込管理へデータを挿入する
                if (this.state.receptionInfo.purpose === COMMON_CONSTANTS.EQPurposeType.AutomaticTransfer) {
                    this._action.branchStatusInsert(tabletApplyParams, false);
                } else {
                    this._action.branchStatusInsert(tabletApplyParams);
                }

                this.store.unregisterSignalHandler(SavingsSignal.GET_INFO_QR_COMPLETE);
                this.store.unregisterSignalHandler(SavingsSignal.GET_TABLET_COUNT_RESULT);
            }
        });
    }

    // 来店目的より、該当業務フローに移動する
    private selectFlowFromQrCode(): void {
        this.store.registerSignalHandler(SavingsSignal.INSERT_TABLET_APPLY_SUCCESS, () => {
            this.store.unregisterSignalHandler(SavingsSignal.INSERT_TABLET_APPLY_SUCCESS);

            for (const element of this.state.chatFlowInfo) {
                // 来店目的より該当画面遷移を行う
                if (element.purpose === this.state.receptionInfo.purpose) {
                    if ((element.purpose === COMMON_CONSTANTS.EQPurposeType.OrdinaryDeposit) ||
                        (element.purpose === COMMON_CONSTANTS.EQPurposeType.StorageDeposit) ||
                        (element.purpose === COMMON_CONSTANTS.EQPurposeType.TimeDepositNew)) {
                        if ((this.state.receptionInfo.branchCif && !element.root)
                            || (!this.state.receptionInfo.branchCif && element.root)) {
                            continue;
                        }
                    }

                    if (element.root) {
                        this.navCtrl.setRoot(element.component,
                            {
                                swipeInfo: this.state.receptionInfo,
                                tabletApplyId: this.state.tabletApplyId,
                                pageIndex: element.pageIndex,
                                accountType: this.state.submitData.accountType,
                                customerApplyStartDate: this.state.submitData.customerApplyStartDate
                            });
                    } else {
                        this.chatFlowCompelete(element.component as string);
                    }

                    break;
                }
            }
        });
    }
}
