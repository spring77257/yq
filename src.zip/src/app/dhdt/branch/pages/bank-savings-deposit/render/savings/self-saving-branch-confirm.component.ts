import { ViewContainerRef } from '@angular/core';
import { InjectionUtils, ObjectUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { ChatOption, COMMON_CONSTANTS, Constants} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
/**
 * Self Saving Branch Confirm component(普通(貯蓄)預金 - 口座開設店舗確認画面).
 */
export class SelfSavingBranchConfirmComponent extends ChatFlowRenderer {

    public processType = 1;

    private state: SavingsState;

    private backupDataService: BackupDataService;
    constructor(
        private chatFlowAccessor: ChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: SavingsStore,
        private audioService: AudioService,
        private modalService: ModalService,
        private loginStore: LoginStore,
        private action: SavingsAction,
    ) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
        this.backupDataService = InjectionUtils.injector.get(BackupDataService);
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-self-saving-branch-confirm.yml', pageIndex);
        // 受付店番号を設定(確認画面比較用)
        this._action.setStateSubmitDataValue({ name: 'receptionBranchNo', value: this.loginStore.getState().belongToBranchNo });
        this._action.saveTenbanBefore(this.loginStore.getState().belongToBranchNo);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'selectBranch': {
                this.onSelectBranch(question, pageIndex);
                break;
            }
        }
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            options.furiganaOnly = ChatOption.VALIDATION_ON;
            options.kanaText = this.backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value }
                    ]
                });
            }

            // 口座開設店の場合は改めて保存する
            if (entity.name === 'savingShopSelect') {
                this.action.setStateSubmitDataValue({
                    name: 'tenban',
                    value: this.state.submitData.tenbanBak
                });
                this.action.setStateSubmitDataValue({
                    name: 'branchName',
                    value: this.state.submitData.branchNameBak
                });
            }
            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const choices =  ObjectUtils.clone(entity.choices);
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            fullwidthHalfwidthDivisionCode: entity.fullwidthHalfwidthDivisionCode
        };
        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                let maxLenth;
                if (choices && choices.length > 0) {
                    maxLenth = InputUtils.calculateMaxLength(choices[0].name,
                        this.state.submitData.holderAddressStreetNameFuriKanaInput,
                        this.state.submitData.holderAddressStreetNameFuriKanaSelect);
                }

                InputUtils.getKanjiToKana(answer.value, maxLenth).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    if (entity.fullwidthHalfwidthDivisionCode) {
                        this.store.registerSignalHandler(SavingsSignal.CHARACTER_CHECK, (data) => {
                            this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                            this.getNextChat(entity.next, pageIndex);
                        });
                        const params = {
                            tabletApplyId: this._store.getState().tabletApplyId,
                            params: {
                                receptionTenban: this.loginStore.getState().belongToBranchNo,
                                checkStrings: [{
                                    checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                    checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                }],
                            }
                        };
                        this.action.characteCheck(params, () => {
                            this.action.editChart(entity.order, pageIndex,
                                this.state.showChats[this.state.showChats.length - 1].answer.order);
                            this.getNextChat(entity.order, pageIndex);
                        });
                    } else {
                        this.getNextChat(entity.next, pageIndex);
                    }
                });

            });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.name === 'isChangeStore') {
            const receptionBranchNo = this.state.submitData.receptionBranchNo;
            // 受付店/受付店以外を選択したかどうかで判定
            const judgeResult = this.state.submitData.tenban === receptionBranchNo ? '00' : '01';
            entity.choices.forEach((choice) => {
                if (choice.value === judgeResult) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
        entity.choices.forEach((choice) => {
            if (this.state.submitData[entity.name] === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }

    public onSelectBranch(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxColNum: 2
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectBranchComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            // 選択された支店を設定
            this.action.changeOpenStore(answer);
            this.action.saveTenbanBefore(answer.tenban || answer.branchNo);
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * update tablet_apply information
     */
    private updateTabletApplyInfo() {
        const params = {
            tabletApplyId: this.store.getState().tabletApplyId,
            leaveReason: null,
            status: Constants.DBConsts.updateStatus.start,
            userMngNo: this.loginStore.getState().bankclerkId
        };

        this.action.branchStatusUpdate(params);
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }
}
