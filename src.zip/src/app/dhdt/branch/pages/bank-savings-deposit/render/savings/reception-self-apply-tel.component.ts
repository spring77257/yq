import { ViewContainerRef } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { ReceptionCompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/reception-completion.component';
import {
    ChatOption, COMMON_CONSTANTS, CountryCode, JudgeResultStatus, PrincipalAgentCategory, SearchMode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { NavController } from 'ionic-angular';

/**
 * 受付チャットの電話番号入力と行員認証呼ぶと後続業務引きつく
 */
export class ReceptionSelfApplyTelComponent extends ChatFlowRenderer {
    public processType = -1;

    private state: SavingsState;

    private backupDataService: BackupDataService;
    private serverInfoService: ServerInfoService;

    private phoneIsSkiped: boolean = false; // 携帯電話スキップフラグ
    private telIsSkiped: boolean = false; // 自宅電話スキップフラグ

    constructor(private chatFlowAccessor: ChatFlowAccessor,
                private footerContent: ViewContainerRef,
                private store: SavingsStore,
                private audioService: AudioService,
                private modalService: ModalService,
                private loginStore: LoginStore,
                private action: SavingsAction,
                private labelService: LabelService,
                private navCtrl: NavController,
    ) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
        this.backupDataService = InjectionUtils.injector.get(BackupDataService);
        this.serverInfoService = InjectionUtils.injector.get(ServerInfoService);
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-reception-selfapply-tel', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'button': {
                this.onButton(question, pageIndex);
                break;
            }
            case 'changeContentReissueForAttribute': {
                this.onChangeContentReissueForAttribute(question, pageIndex);
                break;
            }
            case 'selectBranch': {
                this.onSelectBranch(question, pageIndex);
                break;
            }
            case 'request': {
                this.onRequest(question, pageIndex);
                break;
            }
            case 'chatCard': {
                this.onChatCard(question, pageIndex);
                break;
            }
            case 'pushView': {
                this.onPushView(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_COMPLETE: {
                this.onComplete(question, pageIndex);
                break;
            }
        }
    }

    public onChatCard(entity: any, pageIndex: number) {
        this.getNextChat(entity.next, pageIndex);
    }

    public onSaveSubmit(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.name === 'oldNameCardContent') {

            this.action.setStateSubmitDataValue(
                {
                    name: 'outCardContent',
                    value: {
                        title: '入力内容',
                        datas: this.makeOldNameCardData(this.state.submitData)
                    }
                }
            );
        } else if (entity.name === 'inputedCustomerInfoCardContent') {
            this.action.setStateSubmitDataValue(
                {
                    name: 'outCardContent',
                    value: {
                        title: '申込内容',
                        datas: this.makeInputedCustomerInfoCardData(this.state.submitData)
                    }
                }
            );
        } else if (entity.name === 'zipCode') {
            // 郵便番号が存在しない時に、サーバ経由うして、zipcodeを取得してせってします
            if (!this.state.submitData.firstZipCode && !this.state.submitData.lastZipCode) {
                this.action.getHolderZipCode(
                    this.state.submitData.holderAddressPrefecture,
                    this.state.submitData.holderAddressCountyUrbanVillage,
                    this.state.submitData.holderAddressStreetNameSelect);
            }
        } else if (entity.choices) {
            entity.choices.forEach((item: any) => {
                this._action.setStateSubmitDataValue(item);
            });
        }

        this.getNextChat(entity.next, pageIndex);
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            options.furiganaOnly = ChatOption.VALIDATION_ON;
            options.kanaText = this.backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value },
                        { key: entity.name + 'Text', value: answer.text }
                    ]
                });
            }

            // 口座開設店舗を変更するとき、どっちを選択しても、ログイン店舗の情報を入れる
            // 理由はこの後のチャットで口座開設店舗前チャットの修正鉛筆で修正すると、店舗情報が消えます
            if (entity.name === 'savingShopSelect') {
                this.action.setStateSubmitDataValue({
                    name: 'branchName',
                    value: this.loginStore.getState().belongToBranchName
                });
                this.action.setStateSubmitDataValue({
                    name: 'tenban',
                    value: this.loginStore.getState().belongToBranchNo
                });
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        if (entity.name === 'nameKanaOld') {
                            // カナ氏名入力の場合、submitDataに登録する時にfirstNameKanaOld,lastNameKanaOldに分けて登録します
                            const nameKana = InputUtils.getNameKanaAnswerOldObject(results[0].value);
                            this.setAnswer({ text: answer.text, value: nameKana});
                        } else {
                            this.setAnswer({ text: answer.text, value: results });
                        }
                        if (entity.fullwidthHalfwidthDivisionCode) {
                            this.store.registerSignalHandler(SavingsSignal.CHARACTER_CHECK, (data) => {
                                this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                                this.getNextChat(entity.next, pageIndex);
                            });
                            const params = {
                                tabletApplyId: this._store.getState().tabletApplyId,
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                                    checkStrings: [{
                                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                        checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                    }],
                                }
                            };
                            this.action.characteCheck(params, () => {
                                this.action.editChart(entity.order, pageIndex,
                                    this.state.showChats[this.state.showChats.length - 1].answer.order);
                                this.getNextChat(entity.order, pageIndex);
                            });
                        } else {
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });
                }
            });
    }

    public onNumberKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                } else {
                    this.setAnswer({
                        text: answer.text,
                        value: [...answer.value,
                            {
                                key: entity.name,
                                value: answer.text
                            }
                        ]
                    });
                }

                const isShowModal = this.telSkip(entity.name, answer === 'skip');
                if (!isShowModal) {
                    this.getNextChat(answer === 'skip' ? entity.skip : entity.next, pageIndex);
                }
            });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        if (entity.name === 'isChangeStore') {
            const receptionBranchNo = this.state.submitData.receptionBranchNo;
            // 受付店/受付店以外を選択したかどうかで判定
            judgeResult = this.state.submitData.tenban === receptionBranchNo ? '00' : '01';
            entity.choices.forEach((choice) => {
                if (choice.value === judgeResult) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        } else if (entity.name === 'isAgentOrForgner') {
            if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT || // 代理人選択
                this.state.submitData.nationBtn === '1' || // 外国人選択
                this.isHaveForginerInSameHolders()) { // 同一名義人に外国人いる
                judgeResult = JudgeResultStatus.RESULT_1;
            } else {
                judgeResult = JudgeResultStatus.RESULT_0;
            }
            const choice = entity.choices.find((item) => {
                return item.value === judgeResult;
            });

            this.getNextChat(choice ? choice.next : entity.next, pageIndex);
        } else if (entity.name === 'isMobileNoExist') {
            if (this.state.submitData.firstMobileNo) {
                judgeResult = JudgeResultStatus.RESULT_1;
            } else {
                judgeResult = JudgeResultStatus.RESULT_0;
            }
            const choice = entity.choices.find((item) => {
                return item.value === judgeResult;
            });

            this.getNextChat(choice ? choice.next : entity.next, pageIndex);
        } else if (entity.name === 'isCustomerSearchStatusValid') { // 同一名義人レスポンスには未出力明細あるかどうかをチェック
            judgeResult = this.state.customerSearchStatus === COMMON_CONSTANTS.CustomerSearchStatus.NOT_ALL_OUTPUT ?
                JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;

            const choice = entity.choices.find((item) => {
                return item.value === judgeResult;
            });

            this.getNextChat(choice ? choice.next : entity.next, pageIndex);

        } else if (entity.choices) {
            const choice = entity.choices.find((item) => {
                return item.value === this.state.submitData[entity.name];
            });

            this.getNextChat(choice ? choice.next : entity.next, pageIndex);
        }

    }

    public onChangeContentReissueForAttribute(entity: SavingQuestionsModel, pageIndex: number): void {
        this.getNextChat(entity.next, pageIndex);
    }

    public onSelectBranch(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxColNum: 2
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectBranchComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            // 選択された支店を設定
            this.action.changeOpenStore(answer);
            this.action.saveTenbanBefore(answer.tenban || answer.branchNo);
            this.getNextChat(entity.next, pageIndex);
        });
    }

    public onRequest(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.name === 'sameHolderInquiry') {
            this.sameHolderCheckApi(entity, pageIndex);
        }
    }

    public onPushView(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.name === 'ReceptionCompletionComponent') {
            this.navCtrl.push(ReceptionCompletionComponent);
        }
    }

    /**
     * 受付画面を完了し、次画面に遷移する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onComplete(entity: SavingQuestionsModel, pageIndex: number): void {
        this.switchPatterns(this.state.submitData.openingAccountPattern);
        const info = {
            applyBusinessCategory: this.state.submitData.applyBizCategory,
            tabletApplyId: this.loginStore.getState().tabletApplyId
        };
        this._action.updateApplyBizCategory(info);
        // メニューから選択したフローに遷移する
        this.selectChatFlow(this.state.submitData.chatFlowName);
        // 選択した口座タイプをセットする
        this._action.setAccountTypeInfo(this.state.submitData.accountType);
        // 顧客申し込み開始時間を設定する
        this._action.setCustomerStartDate();
    }

    // if phone and tel are skiped , modal show
    private telSkip(name: string, isSkip: boolean): boolean {
        if (name === 'holderMobileNo') {
            this.phoneIsSkiped = isSkip;
        }
        if (name === 'holderTelephoneNo') {
            this.telIsSkiped = isSkip;
        }
        if (name === 'holderTelephoneNo' && this.phoneIsSkiped === true && this.telIsSkiped === true) {
            const buttonList = [
                { text: 'OK', buttonValue: 'ok' },
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.warnTelTitle,
                buttonList, () => {
                    this.action.needInputPhoenNo();
                }
            );
            return true;
        }
        return false;
    }

    /**
     * 同一名義人照会チェック
     */
    private sameHolderCheckApi(entity: SavingQuestionsModel, pageIndex: number) {
        let judgeResult: string = '';

        const namekanaReqParam = this.state.submitData.firstNameKanaOld ?
            StringUtils.convertZankaku2Hankaku(
                this.state.submitData.firstNameKanaOld + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKanaOld) :
            StringUtils.convertZankaku2Hankaku(
                this.state.submitData.firstNameKana + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKana);
        // パラメータ準備
        const sameHolderCheckApiParams = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                nameKana: namekanaReqParam,
                birthdate: this.state.submitData.birthdate || this.state.submitData.holderBirthdate,
                address: this.getAddress(),
                phoneNo1: this.state.submitData.firstMobileNo ?
                    this.state.submitData.firstMobileNo + '-' + this.state.submitData.secondMobileNo + '-'
                    + this.state.submitData.thirdMobileNo : undefined,
                phoneNo2: this.state.submitData.firstTel ?
                    this.state.submitData.firstTel + '-' + this.state.submitData.secondTel + '-'
                    + this.state.submitData.thirdTel : undefined,
                searchMode: SearchMode.ADDRESS_CHANGE,
            }
        };

        // 受信
        this.store.registerSignalHandler(SavingsSignal.GET_SAME_HOLDER_INQUIRY, (data) => {
            this.store.unregisterSignalHandler(SavingsSignal.GET_SAME_HOLDER_INQUIRY);
            judgeResult = data.length === 0 ? '0' : '1';
            this.goToNextChat(entity, judgeResult, pageIndex);
        });
        // 送信開始
        this.action.getSameHolderInquiry(sameHolderCheckApiParams);
    }

    private goToNextChat(entity: SavingQuestionsModel, judgeResult: string, pageIndex: number) {
        entity.choices.forEach((choice) => {
            if (judgeResult === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }
    private getAddress() {
        const prefecture = this.state.submitData.holderAddressPrefecture ? this.state.submitData.holderAddressPrefecture : '';
        const countyUrbanVillage = this.state.submitData.holderAddressCountyUrbanVillage ?
            this.state.submitData.holderAddressCountyUrbanVillage : '';
        const streetName = this.state.submitData.showStreet ?
            this.state.submitData.showStreet : this.state.submitData.getHolderAddressStreetName();
        const addressHouseNumber = this.state.submitData.holderAddressHouseNumber ? this.state.submitData.holderAddressHouseNumber : '';

        return prefecture + countyUrbanVillage + streetName + addressHouseNumber;
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'modal') {
            this.modalService.showModal(action.value, { imgSrc: COMMON_CONSTANTS.REGULATIONS_KOUZA_TOKUCHOU });
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        } else if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === 'pushView') {
            this.navCtrl.push(ReceptionCompletionComponent);
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_RETURN_TO_CHAT) {
            this.chatFlowReturn(action.value);
        }
    }

    /**
     * メニューから選択したフローに遷移する
     * @param chatFlowName チャットフロー名
     */
    private selectChatFlow(chatFlowName: string) {
        for (const element of this.state.chatFlowInfo) {
            // 来店目的より該当画面遷移を行う
            if (element.selectedFlow === chatFlowName) {
                if (element.root) {
                    this.navCtrl.setRoot(element.component,
                        {
                            submitData: this.state.submitData,
                            tabletApplyId: this.loginStore.getState().tabletApplyId,
                            pageIndex: element.pageIndex,
                            accountType: this.state.submitData.accountType,
                            customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                            cardInfo: this.state.submitData.cardInfo,
                            receptionTenban: this.loginStore.getState().belongToBranchNo,
                        });
                } else {
                    this.chatFlowCompelete(chatFlowName);
                }

                break;
            }
        }
    }

    /**
     * 旧姓のカード表示
     *
     * @private
     * @param {*} submitData
     * @return {*}
     * @memberof ReceptionSelfApplyTelComponent
     */
    private makeOldNameCardData(submitData) {
        const contents = [];
        contents.push(
            {
                title: 'カナ氏名',
                // 外国人場合はfullNameKanaを使用、日本人の場合firstNameKana、lastNameKanaを使う
                content: submitData.fullNameKanaOld ||
                    submitData.firstNameKanaOld + '　' + submitData.lastNameKanaOld
            }
        );

        if (submitData.firstNameOld) {
            contents.push(
                {
                    title: '漢字氏名',
                    content: submitData.firstNameOld + '　' + submitData.lastNameOld
                }
            );
        }

        if (submitData.fullNameAlphabetOld) {
            contents.push(
                {
                    title: '英字氏名',
                    content: submitData.fullNameAlphabetOld,
                }
            );
        }
        return contents;
    }

    /**
     * 入力した顧客情報の表示カード
     *
     * @private
     * @param {*} submitData
     * @return {*}
     * @memberof ReceptionSelfApplyTelComponent
     */
    private makeInputedCustomerInfoCardData(submitData) {
        const contents = [];
        contents.push(
            {
                title: 'カナ氏名',
                // 外国人場合はfullNameKanaを使用、日本人の場合firstNameKana、lastNameKanaを使う
                content: submitData.fullNameKana ||
                    submitData.firstNameKana + '　' + submitData.lastNameKana
            }
        );

        if (submitData.firstName) {
            contents.push(
                {
                    title: '漢字氏名',
                    content: submitData.firstName + '　' + submitData.lastName
                }
            );
        }

        if (submitData.firstNameAlphabet) {
            contents.push(
                {
                    title: '英字氏名',
                    content: submitData.firstNameAlphabet + '　' + submitData.lastNameAlphabet
                }
            );
        }

        contents.push(
            {
                title: '生年月日',
                content: submitData.holderBirthdateText
            },
            {
                title: '郵便番号',
                content: submitData.firstZipCode + '-' + submitData.lastZipCode
            },
            {
                title: 'カナ住所',
                content: submitData.holderAddressPrefectureFuriKana +
                    submitData.holderAddressCountyUrbanVillageFuriKana +
                    submitData.holderAddressStreetNameFuriKanaSelect +
                    submitData.holderAddressHouseNumberFuriKana
            },
            {
                title: '漢字住所',
                content: submitData.holderAddressPrefecture +
                    submitData.holderAddressCountyUrbanVillage +
                    submitData.holderAddressStreetNameSelect +
                    submitData.holderAddressHouseNumber
            },
        );

        if (submitData.firstMobileNo) {
            contents.push(
                {
                    title: '携帯電話',
                    content: submitData.firstMobileNo + '-' + submitData.secondMobileNo + '-' + submitData.thirdMobileNo
                }
            );
        }

        if (submitData.firstTel) {
            contents.push(
                {
                    title: '固定電話',
                    content: submitData.firstTel + '-' + submitData.secondTel + '-' + submitData.thirdTel
                }
            );
        }

        contents.push(
            {
                title: '開設店',
                content: submitData.branchName
            }
        );

        return contents;
    }

    /**
     * 後続業務がうまくいくために
     * 必要なパラメータを作る
     * @param pattern
     */
    private switchPatterns(pattern: string) {
        switch (pattern) {
            case 'A':
                if (this.state.submitData.nationBtn === '0') {
                    this.changeNewAccountJapanes();
                } else {
                    this.changeNewAccountForginer();
                }

                break;
            case 'B':
                this.changeExistingAccount();
                break;

            default:
                break;
        }
    }

    /**
     * 純新規日本人、代理人
     *
     * @private
     * @memberof ReceptionSelfApplyTelComponent
     */
    private changeNewAccountJapanes() {
        this._action.receptionChangeNewAccountJapanes();
    }

    /**
     * 純新規外国人
     *
     * @private
     * @memberof ReceptionSelfApplyTelComponent
     */
    private changeNewAccountForginer() {
        this._action.receptionChangeNewAccountForginer();
    }

    /**
     * 既存新規
     *
     * @private
     * @memberof ReceptionSelfApplyTelComponent
     */
    private changeExistingAccount() {
        this._action.receptionChangeExistingAccount();
    }

    /**
     * 同一名義人に外国人が存在するかどうかをチェック
     *
     * @private
     * @return {*}
     * @memberof ReceptionSelfApplyTelComponent
     */
    private isHaveForginerInSameHolders() {
        let result = false;
        if (this.state.duplicateAccountInfos) {
            this.state.duplicateAccountInfos.forEach(
                (accountInfo) => {
                    if (accountInfo.nationality !== CountryCode.Japan) {
                        result = true;
                    }
                }
            );
        }

        return result;
    }
}
