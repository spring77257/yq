import { ViewContainerRef } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsSignal, SavingsState } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { UnacceptableCode } from 'dhdt/branch/pages/change/change-consts';
import { ChangeConfirmComponent } from 'dhdt/branch/pages/change/view/change-confirm.component';
import {
    AccountType, AgentInternalError, BusinessCode, COMMON_CONSTANTS,
    Constants, ContractCategory, CountryCode, HostErrorCodeReceptionNG, JudgeResultStatus, SearchMode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo, DomesticAccountInfo, ForexAccountInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';

import { ReceptionCheckAccountInfo } from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-response.entity';
import { TerminateConsts } from 'dhdt/branch/pages/terminate/terminate-consts';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { ButtonCameraComponent } from 'dhdt/branch/shared/components/button-group/button-camera.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { DialogComponent } from 'dhdt/branch/shared/components/dialog/dialog.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { MultiButtonGroupComponent } from 'dhdt/branch/shared/components/multi-button-group/multi-button-group.component';
import { AccountInfoInputComponent } from 'dhdt/branch/shared/components/number-input/account-info-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { CardInfoEntity } from 'dhdt/branch/shared/entity/card-info.entity';
import { OcrInfoInterface } from 'dhdt/branch/shared/interface/ocr-info.interface';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { CardService } from 'dhdt/branch/shared/services/card.service';
import { HostErrorService } from 'dhdt/branch/shared/services/host-error.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { NavController } from 'ionic-angular';
import { ModalController } from 'ionic-angular/components/modal/modal-controller';
import { switchMap } from 'rxjs/operators';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { AccountCheckExistingErrorResult } from 'dhdt/branch/shared/entity/account-check-existing-error-response.entity';


/**
 * Reception component(受付画面).
 */
export class ReceptionComponent extends ChatFlowRenderer {
    public processType = -1;
    private state: SavingsState;
    private modalCtrl: ModalController;
    // 送信電文
    private icCardTeleGram: string = null;

    constructor(
        private chatFlowAccessor: ChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private navCtrl: NavController,
        private loginStore: LoginStore,
        private labelService: LabelService,
        private deviceService: DeviceService,
        private cardService: CardService,
        private rsaEncryptService: RsaEncryptService,
        private audioService: AudioService,
        private modalService: ModalService,
        private logging: LoggingService
    ) {
        super();
        this._action.setTabletStartDate();
        this.state = this._store.getState();
        this.modalCtrl = InjectionUtils.injector.get(ModalController);
    }

    public loadTemplate(pageIndex: number) {
        // this._action.loadTemplate('chat-flow-def-reception.json', pageIndex);
        this._action.loadTemplate('chat-flow-def-reception.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_BUTTON_TWO_COLS: {
                this.onButtonTwoCols(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_BUTTON_THREE_COLS: {
                this.onButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_CONFIRMATION: {
                this.onConfirmation(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECT_BRANCH: {
                this.onSelectBranch(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_DATE_PICKER: {
                this.onPicker(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_NAME_AGGREGATION: {
                this.onNameAggregationInquiry(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_REQUEST: {
                this.onRequest(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_COMPLETE: {
                this.onComplete(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_CIF_INFOS_INQUIRY: {
                this.onCifInfosInquiry(question, pageIndex);
                break;
            }
            case 'mulitButton': {
                this.onMulitButton(question, pageIndex);
                break;
            }
        }
    }

    /**
     * ボタングループコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onButtonTwoCols(entity: SavingQuestionsModel, pageIndex: number): void {
        /*if (this.state.submitData.tenban !== TerminateConsts.BranchCode.CC
            && this.state.submitData.tenban !== TerminateConsts.BranchCode.INHERIT
            && entity.name === COMMON_CONSTANTS.NAME_ACCOUNT_TYPE) {
            entity.choices.forEach((item: any) => {
                if (item.value === AccountType.TERMINATE
                    || item.value === AccountType.CLERK_ACCOUNT_STATUS_INQUIRY) {
                    item.options = {
                        cssClass: 'hidden-button',
                    };
                }
            });
        }*/
        const options = {
            maxColNum: 2,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (entity.name === COMMON_CONSTANTS.NAME_ACCOUNT_TYPE) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: COMMON_CONSTANTS.NAME_ACCOUNT_TYPE, value: answer.value },
                            { key: COMMON_CONSTANTS.NAME_ACCOUNT_TYPE_TEXT, value: answer.text.replace(/(\S+)（\S+）/, '$1') },
                            { key: COMMON_CONSTANTS.NAME_APPLY_BIZ_CATEGORY, value: answer.applyBizCategory },
                            { key: COMMON_CONSTANTS.NAME_BUSINESS_CODE, value: answer.businessCode },
                            { key: COMMON_CONSTANTS.NAME_CHAT_FLOW_NAME, value: answer.action.value },
                            { key: COMMON_CONSTANTS.NAME_TABLET_APPLY_ID, value: this.loginStore.getState().tabletApplyId }
                        ]
                    });
                }

                if (entity.name === 'menuNational') {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: COMMON_CONSTANTS.NAME_APPLY_BIZ_CATEGORY, value: answer.applyBizCategory },
                            { key: COMMON_CONSTANTS.NAME_CHAT_FLOW_NAME, value: answer.action.value }
                        ]
                    });
                }

                if (answer.next !== -1) {
                    if (entity.name !== COMMON_CONSTANTS.NAME_ACCOUNT_TYPE) {
                        this.setAnswer({
                            text: answer.text,
                            value: [
                                { key: entity.name, value: answer.value }
                            ]
                        });
                    }
                    this.getNextChat(answer.next, pageIndex);
                }
            });
    }

    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            maxColNum: (entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON) ? 3 : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            if (answer.action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
                this.chatFlowCompelete(answer.action.value);
            } else if (answer.action.type === COMMON_CONSTANTS.BUTTON_TYPE_CONTINUE) {
                this.getNextChat(answer.next, pageIndex);
            } else if (answer.action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
                this.audioService.subject.next(true);
                const buttonList = [{ text: this.labels.common.dialog.ok }];
                this.modalService.showAlert(
                    this.labels.alert.waitTitle,
                    null,
                    'icon_hourgrass@2x.png',
                    buttonList,
                    COMMON_CONSTANTS.CSS_MODAL_W_480
                );
            } else if (answer.action.type === COMMON_CONSTANTS.ACTION_TYPE_EDIT) {
                this.gobackRelateChat(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * パスワードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onPassword(entity: SavingQuestionsModel, pageIndex: number): void {
        let modal;
        modal = this.modalCtrl.create(ModalPasswordComponent, {
            data: {
                subText: this.labelService.labels.password.inputPasswordSubText,
                units: COMMON_CONSTANTS.PASSWORD_MODAL_UNITS,
                needConfirm: false,
                validation: (password) => this._action.validatePassword({
                    tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                    params: {
                        receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                        tenban: this.state.submitData.cardInfo.branchNo, // 店番
                        accountType: this.state.submitData.cardInfo.accountType, // 科目
                        accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                        icCardInfo: this.icCardTeleGram,  // カードのIC情報（INQ電文用データ）
                        passcode: this.rsaEncryptService.encrypt(password)  // 暗証番号
                    }
                })
            }
        }, { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.present();
        modal.onDidDismiss((params) => {
            if (params) {
                this.getNextChat(entity.next, pageIndex);
            }
        });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number) {
        let judgeResult: string;
        if (entity.name === 'cardReader') {
            // 開発環境では無い場合 かつ　研修環境でカードIDがNOTではない場合　カードリーダを使用
            if (AppProperties.DEV_MODE === String(false)
                && !InputUtils.isTrngEnvNoCard(this.loginStore.getState().cardReaderDeviceId)) {

                const subscribeOnCard = this.cardService.onCardPresent().pipe(
                    switchMap(() => {
                        return this.cardService.readCardInfoWapper();
                    })
                ).subscribe((info: CardInfoEntity) => {
                    this.cardService.reset();
                    // 送信電文を得る
                    this.icCardTeleGram = info.getTelegramInfo();
                    // ICログ
                    try {
                        this.logging.saveCustomOperationLog(
                            'reception',
                            'ic-data:' + (this.icCardTeleGram ? this.icCardTeleGram.length : 'null')
                        );
                        this.logging.saveSpecialCustomOperationLog(
                            'reception',
                            info.checkTelegramInfoItemLength()
                        );
                    } catch (ex) {
                        this.logging.saveCustomOperationLog('reception', 'Exception');
                    }
                    // 送信電文をstateに保存
                    this._action.setIcData(this.icCardTeleGram);
                    this._action.setPanApd(info.pan);
                    this.getNextChat(entity.next, pageIndex);
                },
                    (data) => {
                        subscribeOnCard.unsubscribe();
                        this._action.resetLastNode({ order: entity.order, pageIndex: pageIndex });
                    });
            } else {
                this.onAccountInfoInput(entity, pageIndex);
            }
        } else if (entity.name === 'checkForAllCustomerInfosResponse') {
            // 全店名寄せ照会APIの顧客情報リスト内で国籍相違が存在するか
            const isNationalityInconsistent = this.state.submitData.allCifInfos.some(
                (cifInfo) => cifInfo.nationality !== this.state.submitData.allCifInfos[0].nationality);
            const isForeignerKanjuNameNull = this.state.submitData.allCifInfos.some(
                (cifInfo) => cifInfo.nationality !== CountryCode.Japan && !cifInfo.englishName);
            if (this.state.submitData.customerSearchStatus === COMMON_CONSTANTS.CustomerSearchStatus.NOT_ALL_OUTPUT) {
                // 全店名寄せ照会APIの顧客検索結果が「1:未出力明細あり」の場合
                this.showErrorModal(AgentInternalError.ERROR_CODE_N_001);
            } else if (isNationalityInconsistent) {
                // 全店名寄せ照会APIの顧客情報リスト内で国籍相違が存在する場合
                this.showErrorModal(AgentInternalError.ERROR_CODE_N_002);
            } else if (isForeignerKanjuNameNull) {
                // 全店名寄せ照会APIの顧客情報リスト内で外国籍かつ英字氏名nullが存在する場合
                this.showErrorModal(AgentInternalError.ERROR_CODE_N_003);
            } else {
                // 上記エラー事由に該当しない場合
                this.getNextChat(entity.next, pageIndex);
            }
        } else if (entity.name === 'hasDoubleCif') {
            if (!InputUtils.isTrngEnv() && !this.businessCodeJudge()) {
                // 研修環境以外かつ特定業務以外の場合、二重CIF判定
                if (this.doubleCifJudge()) {
                    this.showErrorModal(AgentInternalError.ERROR_CODE_N_004);
                } else {
                    // 上記エラー事由に該当しない場合
                    this.getNextChat(entity.next, pageIndex);
                }
            } else {
                // 上記以外の場合
                this.getNextChat(entity.next, pageIndex);
            }
        } else if (entity.name === 'primaryAccountCheck') {
            // 既存新規口座開設の場合、代表口座存在チェック
            if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
                let primaryCount: number = 0;  // 代表口座件数
                let relationCount: number = 0;  // 関連口座件数
                this.state.submitData.allCifInfos.forEach((cifInfo) => {
                    if (cifInfo.domesticAccountInfo) {
                        cifInfo.domesticAccountInfo.forEach((accountInfo) => {
                            if (accountInfo.ibContractInfo && accountInfo.ibContractInfo.contractCategory) {
                                accountInfo.ibContractInfo.contractCategory === ContractCategory.primary ?
                                    primaryCount++ : relationCount++;
                            }
                        });
                    }
                });
                // PID配下口座なし、または代表口座ありの場合、次のチャットへ進む
                if ((primaryCount === 0 && relationCount === 0) || primaryCount > 0) {
                    this.getNextChat(entity.next, pageIndex);
                } else {
                    // 代表口座なしかつ関連口座１件以上の場合、エラーモーダル
                    this.showErrorModal(AgentInternalError.ERROR_CODE_N_007);
                }
            } else {
                this.getNextChat(entity.next, pageIndex);
            }
        } else if (entity.name === 'checkNotExistingAddressCodeStatus') {
            // 住所コードが存在するか
            const isNotExistingAddressCodeStatus = this.state.submitData.allCifInfos.some(
                (cifInfo) => cifInfo.addressInfo && cifInfo.customerId === this.state.submitData.customerId &&
                    cifInfo.addressInfo.notExistingAddressCodeStatus === COMMON_CONSTANTS.NotExistingAddressCodeStatus.NOT_APPLICABLE);
            // 全店名寄せ照会APIの住所コード該当有無を格納
            this._action.setStateSubmitDataValue({ name: 'isNotExistingAddressCodeStatus', value: isNotExistingAddressCodeStatus });
            this.getNextChat(entity.next, pageIndex);
        } else if (entity.name === 'setNextComponentInfo') {
            for (const choice of entity.choices) {
                if (choice.value === this.state.submitData.accountType) {
                    this._action.setStateSubmitDataValue({ name: COMMON_CONSTANTS.NAME_ACCOUNT_TYPE, value: choice.setInfo.value });
                    this._action.setStateSubmitDataValue({ name: COMMON_CONSTANTS.NAME_BUSINESS_CODE, value: choice.setInfo.businessCode });
                    this._action.setStateSubmitDataValue(
                        { name: COMMON_CONSTANTS.NAME_APPLY_BIZ_CATEGORY, value: choice.setInfo.applyBizCategory });
                    this._action.setStateSubmitDataValue(
                        { name: COMMON_CONSTANTS.NAME_CHAT_FLOW_NAME, value: choice.setInfo.action.value });

                    this.getNextChat(choice.next, pageIndex);
                    break;
                }
            }
        } else if (entity.name === 'isChangeStore') {
            const receptionBranchNo = this.state.submitData.receptionBranchNo;
            // 受付店/受付店以外を選択したかどうかで判定
            judgeResult = this.state.submitData.tenban === receptionBranchNo ? '00' : '01';
            entity.choices.forEach((choice) => {
                if (choice.value === judgeResult) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        } else {
            // nameに一致するsubmitDataの値を返却し、一致するchoiceに進む
            judgeResult = this.state.submitData[entity.name];
            for (const choice of entity.choices) {
                if (choice.value === judgeResult) {
                    // 次のチャットを開始させる
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            }
            // 一致するものがない場合、entityのnextを参照する
            this.getNextChat(entity.next, pageIndex);
        }
    }

    public onAccountInfoInput(entity: SavingQuestionsModel, pageIndex: number): void {

        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        if (!InputUtils.isTrngEnv()) {
            // 研修環境以外の場合、店番号は任意の3桁が入力可能
            this.chatFlowAccessor.addComponent([{
                //     placeholder: '金融機関 4桁',
                //     validationRules: {
                //         required: true,
                //         regex: '^[0-9]{4}$'
                //     }
                // }, {
                placeholder: '店番号 3桁',
                value: '',
                validationRules: {
                    required: true,
                    regex: '^[0-9]{3}$',
                    max: 3
                }
            }, {
                //     placeholder: '種目 1桁',
                //     validationRules: {
                //         required: true,
                //         regex: '^[0-9]{1}$'
                //     }
                // }, {
                placeholder: '口座番号 7桁',
                value: '',
                validationRules: {
                    required: true,
                    regex: '^[0-9]{7}$',
                    max: 7
                }
            }], AccountInfoInputComponent,
                this.footerContent, options).subscribe((answer) => {
                    this._action.setPanApd(answer.map((item) => item.value).join(''));
                    this.getNextChat(entity.next, pageIndex);
                });
        } else {
            // 研修環境の場合、店番号は033固定
            this.chatFlowAccessor.addComponent([{
                placeholder: '店番号 3桁',
                value: '033',
                validationRules: {
                    required: true,
                    regex: '^(033)$',
                    max: 3
                }
            }, {
                placeholder: '口座番号 7桁',
                value: '',
                validationRules: {
                    required: true,
                    regex: '^[0-9]{7}$',
                    max: 7
                }
            }], AccountInfoInputComponent,
                this.footerContent, options).subscribe((answer) => {
                    this._action.setPanApd(answer.map((item) => item.value).join(''));
                    this.getNextChat(entity.next, pageIndex);
                });
        }
    }

    /**
     * 確認画面コンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onConfirmation(entity: SavingQuestionsModel, pageIndex: number): void {
        this.showConfirmPage(entity.next, pageIndex, null);
    }

    /**
     * 店舗コンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onSelectBranch(entity: SavingQuestionsModel, pageIndex: number): void {
        if (!InputUtils.isTrngEnv()) {
            // 研修環境ではない場合
            const options = {
                logInfo: {
                    screenName: this.state.currentFileInfo.screenId,
                    yamlId: this.state.currentFileInfo.yamlId,
                    yamlOrder: entity.order
                },
                maxColNum: 2,
                accountType: this.state.submitData.accountType
            };
            this.chatFlowAccessor.addComponent(entity.type, SelectBranchComponent, this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer({
                    text: answer.text,
                    value: [
                        {
                            key: entity.name,
                            value: answer.branchNo
                        },
                        {
                            key: entity.name + 'Text',
                            value: answer.branchNameKanji
                        },
                    ]
                });
                this.getNextChat(entity.next, pageIndex);
            });
        } else {
            // 研修環境の場合、SelectBranchComponentを呼び出さない。固定値：研修店をsetAnswerして次のチャットへ
            this.setAnswer({
                text: '第三研修',
                value: [{
                    key: entity.name,
                    value: '033'
                }]
            });
            this.getNextChat(entity.next, pageIndex);
        }
    }

    /**
     * キーボードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData)
        };
        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                    if (entity.name === 'manualNameFurikana') {
                        results.push({ key: entity.name, value: answer.text });
                    }
                    this.setAnswer({ text: answer.text, value: results });
                    this.getNextChat(entity.next, pageIndex);
                });
            });
    }

    /**
     * 口座番号を入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onNumberKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();

            // 受付可否チェックエラーのとき、エラーモーダルに注意コードを表示
            this._store.unregisterSignalHandler(SavingsSignal.UNACCEPTABLES_NG);
            this._store.registerSignalHandler(SavingsSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
                // 事故取引禁止注意エラーの場合、注意コードを取得の上エラーモーダルを表示する
                this._store.unregisterSignalHandler(SavingsSignal.UNACCEPTABLES_NG);
                const errorInfo = this.checkErrorCode(response.errors.data);
                this.showErrorModalForReceptionCheck(errorInfo);
            });

            // 口座存在チェックハンドルを追加
            this._store.unregisterSignalHandler(SavingsSignal.GET_CHECK_ACCOUNT_EXISTING);
            this._store.registerSignalHandler(SavingsSignal.GET_CHECK_ACCOUNT_EXISTING, (data) => {
                this._store.unregisterSignalHandler(SavingsSignal.GET_CHECK_ACCOUNT_EXISTING);
                this._store.unregisterSignalHandler(SavingsSignal.UNACCEPTABLES_NG);
                this.getNextChat(data ? entity.next : entity.skip, pageIndex);
            });
            this.setAnswer(answer);
            // 科目：普通預金を固定でセット
            if (entity.example === COMMON_CONSTANTS.AccountTypeCodeCoreBanking.ordinary) {
                this._action.setStateSubmitDataValue({
                    name: COMMON_CONSTANTS.NAME_INPUT_ACCOUNT_TYPE,
                    value: COMMON_CONSTANTS.AccountTypeCodeCoreBanking.ordinary
                });
            }

            const accountParam = {
                tabletApplyId: this.loginStore.getState().tabletApplyId,
                params: {
                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                    tenban: this.state.submitData.inputBranchNo,
                    accountType: this.state.submitData.inputAccountType,
                    accountNo: answer.value[0].value,
                    businessCode: BusinessCode.COMMON_NG, // 業務共通NGチェックの業務コードを付与
                    inheritFlg: InheritConsts.InheritFlg.flagFalse
                }
            };

            const params = {
                order: entity.order,
                pageIndex: pageIndex
            };
            this._action.checkAccountExisting(accountParam, params);
        });
    }

    /**
     * Pickerコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onPicker(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            validationRules: entity.validationRules,
            submitData: this.state.submitData,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * 全店名寄せ照会
     */
    public onNameAggregationInquiry(entity: SavingQuestionsModel, pageIndex: number): void {
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                customerId: this.state.submitData.customerId, // 全店顧客番号
            }
        };
        this._store.unregisterSignalHandler(SavingsSignal.GET_NAME_AGGREGATION_INQUIRY);
        this._store.registerSignalHandler(SavingsSignal.GET_NAME_AGGREGATION_INQUIRY, () => {
            this._store.unregisterSignalHandler(SavingsSignal.GET_NAME_AGGREGATION_INQUIRY);

            // 内部API:受付 の業務受付可否チェックがNGの場合、エラーモーダルを表示。
            // モーダル表示に全店名寄せレスポンスを利用するため、ここに実装する。
            if (this.state.submitData.responseForModal) {
                this.errorHandling(this.state.submitData.responseForModal);
            } else {
                this.getNextChat(entity.next, pageIndex);
            }

        });
        this._action.nameAggregationInquiry(param);
    }

    /**
     * 顧客情報照会（PID配下全て）
     */
    public onCifInfosInquiry(entity: SavingQuestionsModel, pageIndex: number): void {
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                accounts: this.makeAccountsList(), // 口座情報リスト
            }
        };
        this._store.unregisterSignalHandler(SavingsSignal.GET_CUSTOMER_INFO);
        this._store.registerSignalHandler(SavingsSignal.GET_CUSTOMER_INFO, () => {
            this._store.unregisterSignalHandler(SavingsSignal.GET_CUSTOMER_INFO);
            this.getNextChat(entity.next, pageIndex);
        });
        this._action.getCustomerInfo(param);
    }

    /**
     * APIリクエスト送信
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onRequest(entity: SavingQuestionsModel, pageIndex: number): void {
        switch (entity.name) {
            case 'receptionCheckCommon': // 受付可否チェック【業務共通NGチェック】
                this.applyCheck(entity, pageIndex, BusinessCode.COMMON_NG);
                break;
            case 'receptionCheck': // 受付可否チェック【業務選択後（申込手続き前）】
                if (this.state.submitData.businessCode === BusinessCode.SAVING_ACCOUNT ||
                    this.state.submitData.businessCode === BusinessCode.BC_APPLY ||
                    this.state.submitData.businessCode === BusinessCode.INHERIT ||
                    this.state.submitData.businessCode === BusinessCode.EXISTING_REGULAR ||
                    this.state.submitData.businessCode === BusinessCode.EXISTING_CANCEL) {
                    this.receptionCheck(entity, pageIndex);
                } else {
                    this.getNextChat(entity.next, pageIndex);
                }
                break;
        }
    }

    /**
     * 受付画面を完了し、次画面に遷移する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onComplete(entity: SavingQuestionsModel, pageIndex: number): void {
        const info = {
            applyBusinessCategory: this.state.submitData.applyBizCategory,
            tabletApplyId: this.loginStore.getState().tabletApplyId
        };
        this._action.updateApplyBizCategory(info);
        // メニューから選択したフローに遷移する
        this.selectChatFlow(this.state.submitData.chatFlowName);
        // 選択した口座タイプをセットする
        this._action.setAccountTypeInfo(this.state.submitData.accountType);
        // 顧客申し込み開始時間を設定する
        this._action.setCustomerStartDate();
    }

    /**
     * 固定値を保存する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSaveSubmit(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((item: any) => {
                this._action.setStateSubmitDataValue(item);
            });
            this.getNextChat(entity.next, pageIndex);
        }
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onMulitButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxLength: entity.validationRules.max
        };
        this.chatFlowAccessor.addComponent(entity.choices, MultiButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
            }

            this.chatFlowAccessor.clearComponent();

            let next = answer.next.split(COMMON_CONSTANTS.FULL_PAUSE)[0];
            if (entity.name === COMMON_CONSTANTS.HOLDER_CAREER) {
                answer.next.split(COMMON_CONSTANTS.FULL_PAUSE).forEach((order) => {
                    if (order === entity.next) {
                        next = order;
                    }
                });
            }
            this.getNextChat(Number.parseInt(next), pageIndex);
        });
    }

    private showConfirmPage(next: number, pageIndex: number, result: any) {
        this.navCtrl.push(
            ChangeConfirmComponent,
            {
                type: COMMON_CONSTANTS.BusinessFlowType.ExistingSavings,
                processType: this.processType,
                cifInfo: this.state.submitData,
                isTelErrorShow: true,
                callBack: (info: any) => {
                    this._action.setCifInfo({
                        result: {
                            cifInfoInquiryResponse: info.submitData
                        }
                    });
                    if (info.selectChange) {
                        this._action.selectChange();
                        // 全店名寄せ照会APIのレスポンスに対してのエラーチェック実施（N-001～N-004）
                        const nameAggregationCheckResult = this.nameAggregationCheck();
                        if (nameAggregationCheckResult) {
                            // エラー事由該当あり
                            this.showErrorModal(nameAggregationCheckResult);
                        } else {
                            // エラー事由該当なし
                            this.getNextChat(next, pageIndex);
                        }
                    } else {
                        this.getNextChat(next, pageIndex);
                    }
                },
                tabletApplyId: this.loginStore.getState().tabletApplyId,
                receptionTenban: this.loginStore.getState().belongToBranchNo,
            },
            { animate: false }
        );
    }

    /**
     * メニューから選択したフローに遷移する
     * @param chatFlowName チャットフロー名
     */
    private selectChatFlow(chatFlowName: string) {
        for (const element of this.state.chatFlowInfo) {
            // 来店目的より該当画面遷移を行う
            if (element.selectedFlow === chatFlowName) {
                if (chatFlowName === 'CashCardMenuComponent') {
                    element.pageIndex = 0;
                }

                if (element.root) {
                    this.navCtrl.setRoot(element.component,
                        {
                            submitData: this.state.submitData,
                            tabletApplyId: this.loginStore.getState().tabletApplyId,
                            pageIndex: element.pageIndex,
                            accountType: this.state.submitData.accountType,
                            customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                            cardInfo: this.state.submitData.cardInfo,
                            receptionTenban: this.loginStore.getState().belongToBranchNo,
                        });
                } else {
                    this.chatFlowCompelete(chatFlowName);
                }

                break;
            }
        }
    }

    /**
     * タブレット申込管理へデータを挿入する
     */
    private insertTabletApply() {
        this._store.registerSignalHandler(SavingsSignal.GET_SERVE_TIME, () => {
            this._store.unregisterSignalHandler(SavingsSignal.GET_SERVE_TIME);

            // 申込開始、タブレット申込管理へデータを挿入する
            const tabletApplyParams = {
                applyDate: this.loginStore.getState().applyDate,
                applyBusinessType: this.state.submitData.applyBusinessType,
                status: Constants.DBConsts.insertStatus,
                deviceId: this.deviceService.getDeviceId(),
                numberTag: this.state.submitData.receptionNo,
                numberTagPublishDate: this.state.submitData.receptionTime ?
                    this.state.submitData.receptionTime.substring(0, 14) : '',
                agencyBranchNo: this.state.submitData.receptionBranchNo,
                tabletStartDate: this.state.submitData.tabletStartDate,
                customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                userMngNo: this.loginStore.getState().bankclerkId,
                swipeBranchCif: this.state.submitData.swipeCif,
                swipeBranchNo: this.state.submitData.swipeBranchNo,
                swipeAccountNo: this.state.submitData.swipeAccountNo,
                swipeAccountType: this.state.submitData.swipeAccountType,
            };

            // タブレット申込管理へデータを挿入する
            // if (this.state.receptionInfo.purpose === COMMON_CONSTANTS.EQPurposeType.AutomaticTransfer) {
            //     this._action.branchStatusInsert(tabletApplyParams, false);
            // } else {
            this._action.branchStatusInsert(tabletApplyParams);
            // }
        });
    }

    /**
     * 受付可否チェック（業務共通NGチェック）を実行し、結果保存の上チェックOK/NGより次処理を行う。
     * 業務コードは呼び出し元にて設定する。
     *
     * @private
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof LossReissueProcessBranchRenderer
     */
    private applyCheck(entity, pageIndex, businessCode: string) {
        // 受付可否チェック（喪失・破損）の実行後処理を定義
        this._store.registerSignalHandler(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK, () => {
            this._store.unregisterSignalHandler(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK);
            // 情報取得後、チェックNGの場合はエラーモーダル、チェックOKの場合は次チャットへ遷移
            if (this.state.submitData.responseForModal) {
                this.errorHandling(this.state.submitData.responseForModal);
            } else {
                this.getNextChat(entity.next, pageIndex);
            }
        });

        // 受付可否チェック（喪失・破損）を実行(実行結果をPID以下の全CIFに対してのチェックとして保存する)
        this._action.receptionLossCorruptionCheck({
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                // PID以下全CIFを対象とする
                accounts: this.state.submitData.allCifInfos.map((cifInfo: CifInfo) => {
                    // 顧客番号をキーに受付可否チェックを行う
                    return {
                        tenban: null,
                        accountType: null,
                        accountNo: null,
                        customerId: cifInfo.customerId
                    };
                }),
                // 業務コード
                businessCode: businessCode
            }
        }, 'allCifReceptionCheckResult');
    }

    /**
     * 受付可否チェック（業務選択後（申込手続き前））を実行し、結果保存の上チェックOK/NGより次処理を行う。
     *
     * @private
     * @param {SavingQuestionsModel} entity
     * @param {number} pageIndex
     * @memberof ReceptionComponent
     */
    private receptionCheck(entity: SavingQuestionsModel, pageIndex: number) {
        // 受付可否チェック（喪失・破損）の実行後処理を定義
        this._store.registerSignalHandler(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK, () => {
            this._store.unregisterSignalHandler(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK);
            // BC申込の場合、スワイプ口座についても受付可否チェックを実行する
            if (this.state.submitData.businessCode === BusinessCode.BC_APPLY) {
                this.receptionCheckForAccount(entity, pageIndex, BusinessCode.BC_APPLY_ACCOUNT);
                return;
            }
            // 情報取得後、チェックNGの場合はエラーモーダル、チェックOKの場合は次チャットへ遷移
            if (this.state.submitData.responseForModal) {
                this.errorHandling(this.state.submitData.responseForModal);
            } else {
                this.getNextChat(entity.next, pageIndex);
            }
        });

        let account;
        if (this.state.submitData.businessCode === BusinessCode.EXISTING_REGULAR ||
            this.state.submitData.businessCode === BusinessCode.EXISTING_CANCEL) {
            // スワイプCIFの店科口をキーに受付可否チェックを行う
            account = {
                tenban: this.state.submitData.cardInfo.branchNo,
                accountType: this.state.submitData.cardInfo.accountType,
                accountNo: this.state.submitData.cardInfo.accountNo,
                customerId: null
            };
        } else {
            // スワイプCIFの顧客番号をキーに受付可否チェックを行う
            account = {
                tenban: null,
                accountType: null,
                accountNo: null,
                customerId: this.state.submitData.customerId
            };
        }

        // 受付可否チェック（喪失・破損）を実行
        this._action.receptionLossCorruptionCheck({
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                accounts: [
                    {
                        tenban: account.tenban,
                        accountType: account.accountType,
                        accountNo: account.accountNo,
                        customerId: account.customerId
                    }
                ],
                // 業務コード
                businessCode: this.state.submitData.businessCode
            }
        });
    }

    /**
     * スワイプ口座の受付可否チェック。（CIFの受付可否チェック実行後に、必要な業務のみ実行する）
     * 受付可否チェック（業務選択後（申込手続き前））を実行し、結果保存の上チェックOK/NGより次処理を行う。
     *
     * @private
     * @param {SavingQuestionsModel} entity
     * @param {number} pageIndex
     * @memberof ReceptionComponent
     */
    private receptionCheckForAccount(entity: SavingQuestionsModel, pageIndex: number, businessCode: string) {

        // 受付可否チェック（喪失・破損）の実行後処理を定義
        this._store.registerSignalHandler(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK_ACCOUNT, () => {
            this._store.unregisterSignalHandler(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK_ACCOUNT);
            // 情報取得後、チェックNGの場合はエラーモーダル、チェックOKの場合は次チャットへ遷移
            if (this.state.submitData.responseForModal) {
                this.errorHandling(this.state.submitData.responseForModal);
            } else {
                this.getNextChat(entity.next, pageIndex);
            }
        });

        // 受付可否チェック（喪失・破損）を実行
        this._action.receptionLossCorruptionCheckAdd({
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                accounts: [
                    {
                        tenban: this.state.submitData.cardInfo.branchNo, // 店番
                        accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                        accountType: this.state.submitData.cardInfo.accountType, // 科目
                        customerId: null
                    }
                ],
                // 業務コード
                businessCode: businessCode
            }
        });
    }

    /**
     *
     * エラーハンドリング処理
     * @private
     * @param {*} response
     * @memberof ReceptionComponent
     */
    private errorHandling(responseForModal: Array<{
        customerId?: string, branchCode?: string, subjectCode?: string, bankAccountId?: string,
        accounts: ReceptionCheckAccountInfo
    }>) {
        const errMessageArr: Array<{ customerId: string, message: string }> = [];
        // レスポンスパラメータの中に、受付可否チェック検出対象がいたら離脱
        for (const item of responseForModal) {
            for (const cifInfo of this.state.submitData.allCifInfos) {
                if (item.customerId === cifInfo.customerId && this.isHostError(item.accounts.errorCode)) {
                    this.makeErrorMessage(item, cifInfo, errMessageArr);
                } else if (item.branchCode && item.subjectCode && item.bankAccountId &&
                    this.isHostError(item.accounts.errorCode)) {
                    // 店科口が一致するCIFの顧客管理店番を用いてエラーメッセージを作成
                    if (cifInfo.domesticAccountInfo && cifInfo.domesticAccountInfo.some((domesticAccount: DomesticAccountInfo) =>
                        domesticAccount.branchCode === item.branchCode &&
                        domesticAccount.subjectCode === item.subjectCode &&
                        domesticAccount.bankAccountId === item.bankAccountId)) {
                        this.makeErrorMessage(item, cifInfo, errMessageArr);
                    } else if (cifInfo.forexAccountInfo && cifInfo.forexAccountInfo.some((forexAccount: ForexAccountInfo) =>
                        forexAccount.branchCode === item.branchCode &&
                        forexAccount.subjectCode === item.subjectCode &&
                        forexAccount.bankAccountId === item.bankAccountId)) {
                        this.makeErrorMessage(item, cifInfo, errMessageArr);
                    }
                }
            }
        }
        const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        let index = 0;
        let isNeedBr = 1;
        let message: string = '';
        let messageBefore: { customerId: string, message: string } = { customerId: undefined, message: undefined };
        if (errMessageArr.length > 0) {
            for (const err of errMessageArr) {
                if (index === 0) {
                    message = err.message;
                } else if (messageBefore.customerId === err.customerId && maxArr > isNeedBr) {
                    isNeedBr++;
                    message = message + COMMON_CONSTANTS.SLASH + err.message.substring(err.message.length - 3);
                } else {
                    isNeedBr = 1;
                    message = message + COMMON_CONSTANTS.NEW_LINE + err.message;
                }
                index++;
                messageBefore = err;
            }
            this.showErrorModalForReceptionCheck(message);
            return;
        }
    }

    /**
     *
     * エラーメッセージ作成
     * @private
     * @param {*} item
     * @param {CifInfo} cifInfo
     * @param {string[]} errMessageArr
     * @return {string[]}
     * @memberof LossReissueProcessBranchRenderer
     */
    private makeErrorMessage(item: {
        customerId?: string, branchCode?: string, subjectCode?: string, bankAccountId?: string,
        accounts: ReceptionCheckAccountInfo
    },
        cifInfo: CifInfo, errMessageArr: Array<{ customerId: string, message: string }>):
        Array<{ customerId: string, message: string }> {
        let branchCode: string = '';
        branchCode = cifInfo.customerManagementBranchCode;
        if (item.accounts.unacceptables && item.accounts.unacceptables.length > 0) {
            // 受付不可情報がある場合、表示メッセージは「エラー理由 ＋ 事故・取引禁止・注意コード」。
            for (const acceptItem of item.accounts.unacceptables) {
                errMessageArr.push({
                    customerId: cifInfo.customerId, message: branchCode + COMMON_CONSTANTS.FULL_COLON
                        + item.accounts.errorCode + COMMON_CONSTANTS.SPACE + acceptItem.unacceptableCode
                });
            }
        } else {
            // 受付不可情報がない場合、表示メッセージは「エラー理由」のみ。
            errMessageArr.push({
                customerId: cifInfo.customerId, message: branchCode
                    + COMMON_CONSTANTS.FULL_COLON + item.accounts.errorCode
            });
        }
        return errMessageArr;
    }

    /**
     * 修正ボタン
     */
    private gobackRelateChat(entity: SavingQuestionsModel, pageIndex: number) {
        let order: number;
        let answerOrder: number;
        let orderIndex: number;
        order = entity.next;
        this.state.showChats.forEach((choice) => {
            if (order === choice.order) {
                if (choice.answer) {
                    answerOrder = choice.answer.order;
                    orderIndex = choice.orderIndex;
                }
            }
        });
        this._action.editChart(order, pageIndex, answerOrder, orderIndex);
        this.getNextChat(order, pageIndex);
    }

    /**
     * エラーモーダルを表示する（受付可否チェック以外のエラー用）
     */
    private showErrorModal(errorCode: string) {
        const errorParams = {
            imgSrc: 'icon_hourgrass@2x.png',
            message: this.labels.common.error.host.support,
            subMessage: `<span class="font-color-red">${errorCode}</span>`,
            buttonList: [{ text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK }]
        };
        const errorModal = this.modalCtrl.create(
            DialogComponent, errorParams, { cssClass: 'settings-error-modal', enableBackdropDismiss: false }
        );
        this.audioService.subject.next(true);
        errorModal.present();
    }

    /**
     * エラーモーダルを表示する（受付可否チェック用）
     */
    private showErrorModalForReceptionCheck(errorCode: string, callback?: any) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            this.labelService.labels.common.error.host.support,
            `<span class="font-color-red">${errorCode}</span>`, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
        this.audioService.subject.next(true);
    }

    /**
     * 返却されたエラーコードが、受付可否チェック検出対象かを確認する。
     */
    private isHostError(errorCode: string): boolean {
        return (Object.keys(HostErrorCodeReceptionNG).some((key) => HostErrorCodeReceptionNG[key] === errorCode));
    }

    /**
     * 選択業務が特定業務（相続、定期預金）かどうか判定
     */
    private businessCodeJudge(): boolean {
        return this.state.submitData.businessCode === BusinessCode.INHERIT ||
            this.state.submitData.businessCode === BusinessCode.EXISTING_REGULAR ||
            this.state.submitData.businessCode === BusinessCode.EXISTING_CANCEL;
    }

    /**
     * 全店名寄せ照会APIの顧客リスト内で顧客管理店番号が重複するCIFが二件以上あるか判定
     */
    private doubleCifJudge(): boolean {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((cifInfo) => {
            accounts.push(cifInfo.customerManagementBranchCode);
        });
        const list = new Set(accounts);
        return accounts.length !== list.size;
    }

    /**
     * 全店名寄せ照会APIのレスポンスに対してのエラーチェック
     */
    private nameAggregationCheck() {
        let errorCode: string;
        const isNationalityInconsistent = this.state.submitData.allCifInfos.some(
            (cifInfo) => cifInfo.nationality !== this.state.submitData.allCifInfos[0].nationality);
        const isForeignerKanjuNameNull = this.state.submitData.allCifInfos.some(
            (cifInfo) => cifInfo.nationality !== CountryCode.Japan && !cifInfo.englishName);
        if (this.state.submitData.customerSearchStatus === COMMON_CONSTANTS.CustomerSearchStatus.NOT_ALL_OUTPUT) {
            // 全店名寄せ照会APIの顧客検索結果が「1:未出力明細あり」の場合
            errorCode = AgentInternalError.ERROR_CODE_N_001;
        } else if (isNationalityInconsistent) {
            // 全店名寄せ照会APIの顧客情報リスト内で国籍相違が存在する場合
            errorCode = AgentInternalError.ERROR_CODE_N_002;
        } else if (isForeignerKanjuNameNull) {
            // 全店名寄せ照会APIの顧客情報リスト内で外国籍かつ英字氏名nullが存在する場合
            errorCode = AgentInternalError.ERROR_CODE_N_003;
        } else if (!InputUtils.isTrngEnv() && this.doubleCifJudge()) {
            // 全店名寄せ照会のレスポンス内に同一店多重CIFが存在する場合（研修環境は判定しない）
            errorCode = AgentInternalError.ERROR_CODE_N_004;
        }
        return errorCode;
    }

    /**
     * 顧客情報照会APIのパラメータリスト作成
     */
    private makeAccountsList(): any {
        const accountsListArr = [];
        let account = {};
        for (const cifInfo of this.state.submitData.allCifInfos) {
            // 全店名寄せ照会結果から、国内口座情報の先頭の店科口がある場合、店科口を設定。
            // 国内口座情報の先頭の店科口がない場合、顧客番号を設定。
            account = cifInfo.domesticAccountInfo && cifInfo.domesticAccountInfo.length > 0 ?
                {
                    tenban: cifInfo.domesticAccountInfo[0].branchCode,
                    accountType: cifInfo.domesticAccountInfo[0].subjectCode,
                    accountNo: cifInfo.domesticAccountInfo[0].bankAccountId,
                    customerId: cifInfo.domesticAccountInfo[0].branchCode && cifInfo.domesticAccountInfo[0].subjectCode
                        && cifInfo.domesticAccountInfo[0].bankAccountId ? null : cifInfo.customerId,
                } :
                { customerId: cifInfo.customerId };
            accountsListArr.push(account);
        }
        return accountsListArr;
    }

    /**
     * スワイプCIF専用のエラーメッセージ作成処理
     */
    private checkErrorCode(accountCheckExistingErrorResult: AccountCheckExistingErrorResult) {
        let errorInfo: any;
        let isNeedBr = 1;
        let index = 0;
        const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        if (this.isHostError(accountCheckExistingErrorResult.errorCode)) {
            let unacceptables = '';
            // 口座存在チェックエラー結果のCIF情報照会結果の店番＋コロン＋エラーコードを設定
            errorInfo = accountCheckExistingErrorResult.cifInfoInquiryResponse.tenban + COMMON_CONSTANTS.FULL_COLON + accountCheckExistingErrorResult.errorCode;
            for (const unacceptable of accountCheckExistingErrorResult.unacceptables) {
                unacceptables = unacceptable.unacceptableCode;
                if (index === 0) {
                    errorInfo = errorInfo + COMMON_CONSTANTS.SPACE + unacceptables;
                } else if (isNeedBr > maxArr) {
                    // 1行に最大3つの注意コードを表示する
                    // 超える場合は改行して店番＋エラー情報＋注意コードを表示する
                    errorInfo = errorInfo + COMMON_CONSTANTS.NEW_LINE + errorInfo.slice(0, 14) + unacceptables;
                    isNeedBr = 1;
                } else {
                    errorInfo = errorInfo + COMMON_CONSTANTS.SLASH + unacceptables;
                }
                index++;
                isNeedBr++;
            }
        }
        return errorInfo;
    }
}
