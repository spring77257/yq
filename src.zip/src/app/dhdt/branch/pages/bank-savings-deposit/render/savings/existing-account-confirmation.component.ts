import { ViewContainerRef } from '@angular/core';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsState } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { ExistingAccountTableComponent } from 'dhdt/branch/shared/components/existing-account-table/existing-account-table.component';

/**
 * Self Imgapply component(情報入力画面（本人確認書類聴取）_写真撮影).
 */
export class ExistingAccountConfirmation extends ChatFlowRenderer {

    public processType = 1;

    private state: SavingsState;

    constructor(
        private chatFlowAccessor: ChatFlowAccessor,
        private footerContent: ViewContainerRef,
    ) {
        super();
        this.state = this._store.getState();
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-existing-account-confirmation.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'existingAccount': {
                this.onExistingAccount(question, pageIndex);
                break;
            }
        }
    }

    public onExistingAccount(entity: SavingQuestionsModel, pageIndex: number) {
        const options = {
            data: this.state.duplicateAccountInfos,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ExistingAccountTableComponent, this.footerContent, options
            ).subscribe((answer: any) => {
            if (answer) {
                this._action.setExistingAccountInfo(answer);
            }
            this.chatFlowAccessor.clearComponent();
            this.getNextChat(entity.next, pageIndex);
        });
    }
}
