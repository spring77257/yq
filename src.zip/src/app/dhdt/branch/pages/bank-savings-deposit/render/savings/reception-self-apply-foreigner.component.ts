import { ViewContainerRef } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils, ObjectUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    CategoryCode, ChatOption, COMMON_CONSTANTS, Constants, ForeignResidenceCode, SearchMode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { SelectAddressComponent } from 'dhdt/branch/shared/components/address/view/select-address.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';

/**
 * 受付チャットの外国人個人情報入力（名前、住所、生年月日など）
 */
export class ReceptionSelfApplyForeignerComponent extends ChatFlowRenderer {
    public processType = -1; // processbarを表示しない

    private state: SavingsState;

    private backupDataService: BackupDataService;
    private serverInfoService: ServerInfoService;

    constructor(private chatFlowAccessor: ChatFlowAccessor,
                private footerContent: ViewContainerRef,
                private store: SavingsStore,
                private audioService: AudioService,
                private modalService: ModalService,
                private loginStore: LoginStore,
                private action: SavingsAction,
                private labelService: LabelService,
    ) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
        this.backupDataService = InjectionUtils.injector.get(BackupDataService);
        this.serverInfoService = InjectionUtils.injector.get(ServerInfoService);
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-reception-selfapply-foreigner.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'button': {
                this.onButton(question, pageIndex);
                break;
            }
            case 'datepicker':
            case 'prefecturePicker':
            case 'countyUrbanVillagePicker': {
                this.onPicker(question, pageIndex);
                break;
            }
            case 'selectAddress': {
                this.onSelectAddress(question, pageIndex);
                break;
            }
            case 'selectStreet': {
                this.onSelectStreet(question, pageIndex);
                break;
            }
        }
    }

    public onSaveSubmit(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((item: any) => {
                this._action.setStateSubmitDataValue(item);
            });
            this.getNextChat(entity.next, pageIndex);
        }
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            options.furiganaOnly = ChatOption.VALIDATION_ON;
            options.kanaText = this.backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value },
                        { key: entity.name + 'Text', value: answer.text }
                    ]
                });
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const choices = this.changeValidationRuleMax(entity, this.state.submitData);
        const items = InputUtils.getDefaultValues(entity.name, this.state.submitData);
        const options = {
            validationRules: entity.validationRules,
            defaultValues: entity.name === 'nameKana' && items[0] && items[1] ?
                [items[0] + COMMON_CONSTANTS.FULL_SPACE + items[1]] : items,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            fullwidthHalfwidthDivisionCode: entity.fullwidthHalfwidthDivisionCode
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === 'skip') {
                    this.setAnswer({
                        text: this.labelService.labels.common.skipjp, value: [{
                            key: entity.name,
                            value: undefined
                        }, ...entity.choices.map((choice) => {
                            return {
                                key: choice.name,
                                value: undefined
                            };
                        })] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    let maxLenth;
                    if (choices && choices.length > 0) {
                        maxLenth = InputUtils.calculateMaxLength(
                            choices[0].name, this.state.submitData.holderAddressStreetNameFuriKanaInput,
                            this.state.submitData.holderAddressStreetNameFuriKanaSelect);
                    }

                    InputUtils.getKanjiToKana(answer.value, maxLenth).subscribe((results) => {
                        if (entity.name === 'nameAlphabet') {
                            // 英語氏名入力の場合、submitDataに登録する時にfirstNameAlphabet,lastNameAlphabetに分けて登録します
                            const nameAlphabet = InputUtils.getNameAlphabetAnswerObject(results[0].value.toUpperCase());
                            this.setAnswer({ text: answer.text.toUpperCase(), value: nameAlphabet});
                        } else if (entity.name === 'nameKana') {
                            // カナ氏名入力の場合、submitDataに登録する時にfirstNameKana,lastNameKanaに分けて登録します
                            const nameKana = InputUtils.getNameKanaAnswerObject(results[0].value);
                            this.setAnswer({ text: answer.text, value: nameKana});
                        } else {
                            this.setAnswer({ text: answer.text, value: results });
                        }

                        if (entity.fullwidthHalfwidthDivisionCode) {
                            this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                            this.store.registerSignalHandler(SavingsSignal.CHARACTER_CHECK, (data) => {
                                this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                                this.getNextChat(entity.next, pageIndex);
                            });
                            const params = {
                                tabletApplyId: this._store.getState().tabletApplyId,
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                                    checkStrings: [{
                                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                        checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                    }],
                                }
                            };
                            this.action.characteCheck(params, () => {
                                this.action.editChart(entity.order, pageIndex,
                                    this.state.showChats[this.state.showChats.length - 1].answer.order);
                                this.getNextChat(entity.order, pageIndex);
                            });
                        } else {
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });
                }
            });
    }

    public onNumberKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === 'skip') {
                    this.setAnswer({ text: this.labelService.labels.common.skipjp, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer({ text: '〒' + answer.text, value: answer.value });
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * ピッカーコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onPicker(entity: SavingQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }
        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name === 'birthdate' ? entity.name + 'Birth' : entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData,
            value: undefined
        };

        switch (entity.name) {
            case 'holderAddressPrefecture':
                options.value = this.loginStore.getState().prefectureKanji;
                break;
            case 'holderAddressCountyUrbanVillage':
                options.value = this.loginStore.getState().countyUrbanVillageKanji;
                break;
        }

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (entity.name === 'birthdate') {
                    this.setAnswer({
                        text: answer.text,
                        value: [{
                            key: entity.name,
                            value: answer.value[0].value
                        }, {
                            key: entity.name + 'Text',
                            value: answer.value[1].value
                        }]
                    });
                } else {
                    this.setAnswer(answer);
                }
                this.getNextChat(entity.next, pageIndex);
        });
    }

    public onSelectAddress(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectAddressComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            this.getNextChat(answer.value ? entity.next : entity.skip, pageIndex);
        });
    }

    public onSelectStreet(entity: SavingQuestionsModel, pageIndex: number): void {
        const params = {
            prefectureKanji: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillageKanji: this.state.submitData.holderAddressCountyUrbanVillage
        };
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(params, SelectStreetComponent, this.footerContent, options)
            .subscribe((result: { isSkip: boolean, text: string, value: any }) => {
                this.chatFlowAccessor.clearComponent();
                if (result.value) {
                    const answer = {
                        text: result.text,
                        value: [
                            { key: 'holderAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'holderAddressStreetNameFuriKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) },
                            { key: 'streetWork', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'showStreet', value: (result.isSkip ? undefined : result.value.streetKanji) }
                        ]
                    };
                    this.setAnswer(answer);
                    this.getNextChat(result.isSkip ? entity.skip : entity.next, pageIndex);
                } else {
                    this._action.resetLastNode({ order: entity.next, pageIndex: pageIndex });
                }
            });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.name === 'remainingPeriod') {
            this.remainingPeriodFuc(entity, pageIndex);
        } else {
            if (entity.option === 'url') {
                this.serverInfoService.getInfoFormServe(entity.name).subscribe((result) => {
                    entity.choices.forEach((choice) => {
                        if (result === choice.value) {
                            // 郵便番号不正の場合、「firstZipCode」と「lastZipCode」にブランクを設定です、
                            // 本人確認画面初期、「firstZipCode」と「lastZipCode」はブランクの場合、郵便番号再検索を実行する。
                            if (choice.value === '1') {
                                this.action.setStateSubmitDataValue({
                                    name: 'firstZipCode',
                                    value: null,
                                });
                                this.action.setStateSubmitDataValue({
                                    name: 'lastZipCode',
                                    value: null,
                                });
                            }
                            this.getNextChat(choice.next, pageIndex);
                            return;
                        }
                    });
                });
            } else if (entity.option === 'account') {
                this.sameHolderCheckApi(entity, pageIndex);
                return;
            } else if (entity.choices) {
                const choice = entity.choices.find((item) => this.state.submitData[entity.name] === item.value);
                this.getNextChat(choice ? choice.next : entity.next, pageIndex);
            }
        }
    }

    /**
     * 同一名義人照会チェック
     */
    private sameHolderCheckApi(entity: SavingQuestionsModel, pageIndex: number) {
        let judgeResult: string = '';

        // パラメータ準備
        const sameHolderCheckApiParams = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                nameKana: StringUtils.convertZankaku2Hankaku(
                    this.state.submitData.firstNameKana + '　' + this.state.submitData.lastNameKana),
                birthdate: this.state.submitData.birthdate || this.state.submitData.holderBirthdate,
                address: this.getAddress(),
                searchMode: SearchMode.ORDINARY,
            }
        };

        // 受信
        this.store.registerSignalHandler(SavingsSignal.GET_SAME_HOLDER_INQUIRY, (data) => {
            this.store.unregisterSignalHandler(SavingsSignal.GET_SAME_HOLDER_INQUIRY);
            judgeResult = data.length === 0 ? '0' : '1';
            this.goToNextChat(entity, judgeResult, pageIndex);
        });
        // 送信開始
        this.action.getSameHolderInquiry(sameHolderCheckApiParams);
    }

    private goToNextChat(entity: SavingQuestionsModel, judgeResult: string, pageIndex: number) {
        entity.choices.forEach((choice) => {
            if (judgeResult === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }
    private getAddress() {
        const prefecture = this.state.submitData.holderAddressPrefecture ? this.state.submitData.holderAddressPrefecture : '';
        const countyUrbanVillage = this.state.submitData.holderAddressCountyUrbanVillage ?
            this.state.submitData.holderAddressCountyUrbanVillage : '';
        const streetName = this.state.submitData.showStreet ?
            this.state.submitData.showStreet : this.state.submitData.getHolderAddressStreetName();
        const addressHouseNumber = this.state.submitData.holderAddressHouseNumber ? this.state.submitData.holderAddressHouseNumber : '';

        return prefecture + countyUrbanVillage + streetName + addressHouseNumber;
    }
    // 残余期間の計算方法
    private remainingPeriodFuc(entity: SavingQuestionsModel, pageIndex: number): number {
        this.action.getSystemTime().subscribe((customerApplyStartDate) => {
            const momentEffective = moment(this.state.submitData.residenceExpirationDate, COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
            const momentCustomer = moment(customerApplyStartDate, COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
            const remainingPeriod = momentEffective.diff(momentCustomer, COMMON_CONSTANTS.DATE_MONTH);

            if (remainingPeriod >= 3) {
                this.action.setStateSubmitDataValue({
                    name: entity.name,
                    value: remainingPeriod
                });
                this.getNextChat(entity.next, pageIndex);
                return;
            } else {
                entity.choices.forEach((choice) => {
                    this.action.setStateSubmitDataValue({
                        name: entity.name,
                        value: remainingPeriod
                    });
                    this.getNextChat(choice.next, pageIndex);
                    return;
                });
            }
        });
        return;
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'modal') {
            this.modalService.showModal(action.value, { imgSrc: COMMON_CONSTANTS.REGULATIONS_KOUZA_TOKUCHOU });
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        } else if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        }
    }

    /**
     * change ValidationRule Max length
     * @param entity チャットフローエンティティー
     * @param submitData データ
     */
    private changeValidationRuleMax(entity: any, submitData: any) {
        const choicesResult = ObjectUtils.clone(entity.choices);

        // 「町丁名（漢字）」の入力済桁数により、「番地以降（漢字）」の入力可能最大桁数を調整する
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW
            && submitData.holderAddressStreetNameSelect
            && submitData.holderAddressStreetNameSelect.length > 0) {
            let holderAddressStreetLength = 0;
            holderAddressStreetLength = submitData.holderAddressStreetNameSelect.length;
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max - holderAddressStreetLength;
        } else if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW
            && choicesResult[0].name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER
            && submitData.holderAddressStreetNameInput
            && submitData.holderAddressStreetNameInput.length > 0) {
            let holderAddressStreetLength = 0;
            holderAddressStreetLength = submitData.holderAddressStreetNameInput.length;
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max - holderAddressStreetLength + 1;
        }

        // 「町丁名（カナ）」の入力済桁数により、「番地以降（カナ）」の入力可能最大桁数を調整する
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FURIKANA_FOR_SHOW
            && choicesResult[0].name === 'holderAddressStreetNameFuriKanaInput'
            && choicesResult[1].name === 'holderAddressHouseNumberFuriKana') {
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max -
                submitData.holderAddressStreetNameFuriKanaSelect.length;
        }
        return choicesResult;
    }
}
