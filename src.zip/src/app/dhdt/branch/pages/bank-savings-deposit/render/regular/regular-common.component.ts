import { ViewContainerRef } from '@angular/core';
import { DeviceService } from 'dhd/common/services/device.service';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { BrdConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/regular/brd-confirm.component';
import { COMMON_CONSTANTS, Constants, CoreBankingConst } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { CardListComponent } from 'dhdt/branch/shared/components/card-list/card-list.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { RadioButtonComponent } from 'dhdt/branch/shared/components/radio-button-group/radio-button.component';
import { NewPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/new-password-rule-check.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { ProductCategoryUtils } from 'dhdt/branch/shared/utils/product-category-utils';
import { NavController } from 'ionic-angular';

/**
 * Regular common component(定期預金 - 情報入力画面 - 最後（本人申込・代理人申込共通）).
 */
export class RegularCommonComponent extends ChatFlowRenderer {
    public processType = 1;

    private state: SavingsState;

    private phoneIsSkiped: boolean = false;
    private telIsSkiped: boolean = false;

    constructor(private chatFlowAccessor: ChatFlowAccessor, private footerContent: ViewContainerRef,
                private store: SavingsStore, private modalService: ModalService, private loginStore: LoginStore,
                private deviceService: DeviceService, public navCtrl: NavController) {
        super();
        this.state = this.store.getState();
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-regular-common.yml', pageIndex);
        // this._action.loadTemplate('chat-flow-def-principal-agent.json', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'password6bits':
            case 'password4bits': {
                this.onPasswordInput(question, pageIndex);
                break;
            }
            case 'card': {
                this.onCard(question, pageIndex);
                break;
            }
            case 'agreedModal': {
                this.onModal(question, pageIndex);
                break;
            }
            case 'radioButton': {
                this.onRadioButton(question, pageIndex);
                break;
            }
        }
    }

    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.text }
                ]
            });
            this.getNextChat(answer.next, pageIndex);
        });
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        this.getNextChat(entity.next, pageIndex);
                    });
                }
            });
    }

    public onPasswordInput(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PasswordInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                } else {
                    // 暗証番号ルール適合性チェックハンドルを追加
                    this.store.registerSignalHandler(SavingsSignal.GET_PASSWORD_RULE, (data) => {
                        this.store.unregisterSignalHandler(SavingsSignal.GET_PASSWORD_RULE);
                        if (data.response.values.result === '1') {
                            const buttonList = [
                                { text: 'OK', buttonValue: 'ok' },
                            ];
                            this.modalService.showAlert(
                                this.labels.error.passwordError,
                                null, 'icon_alert@2x.png', buttonList, 'settings-alert-modal',
                                () => {
                                    const lastNode = this.state.showChats[this.state.showChats.length - 1];
                                    this._action.resetLastNode({ order: lastNode.order, pageIndex: lastNode.pageIndex });
                                }
                            );
                        } else {
                            this.chatFlowAccessor.clearComponent();
                            this.setAnswer(answer);
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });

                    // 暗証番号ルール適合性チェックを行う
                    const param: NewPasswordRuleCheckInterface = {
                        tabletApplyId: this.loginStore.getState().tabletApplyId,
                        userMngNo: this.loginStore.getState().bankclerkId,
                        path: CoreBankingConstants.ApiPathConsts.PASSWORD_RULE_CHECK,
                        params: {
                            bankNo: CoreBankingConst.bankNo,
                            receptionTenban: this.state.submitData.receptionBranchNo,
                            receptionNo: this.state.submitData.receptionNo,
                            terminalNo: this.deviceService.getDeviceId(),
                            passcodeType: entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4 ? '1' : '2',
                            passcode: answer.value[0].value,
                            birthday: this.state.submitData.holderBirthdate,
                            telephoneNo: this.state.submitData.getHolderTelephoneNo(),
                            mobileNo: this.state.submitData.getHolderMobileNo(),
                            officeNo: ''
                        }
                    };
                    this._action.checkNewCustomerPasswordRule(param);
                }
            });
    }

    public onModal(entity: SavingQuestionsModel, pageIndex: number): void {
        const pdfSrc: string = ProductCategoryUtils.getPdfSrc(this.state.submitData.selectProductType, true);

        this.modalService.showModal(entity.type, { pdfSrc: pdfSrc }, () => {
            this.navCtrl.setRoot(BrdConfirmComponent);
        });
    }

    public onRadioButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, RadioButtonComponent, this.footerContent, options).subscribe((answer) => {
            if (answer.action.type === 'modal') {
                this.modalService.showModal(answer.action.value, { imgSrc: answer.imgSrc });
            }

            if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onCard(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, CardListComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: entity.name + 'ImageSrc', value: answer.imgSrc }
                ]
            });
            this.getNextChat(answer.next, pageIndex);
        });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }
}
