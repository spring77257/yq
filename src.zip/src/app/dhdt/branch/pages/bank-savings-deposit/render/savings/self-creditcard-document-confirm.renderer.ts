import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    ApplyBC, COMMON_CONSTANTS, Constants, HasDriversCareerLicense, HasLicense, IsModifyJudge
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { Career, IsNearGraduate } from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { JudgeResultStatus } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';

/**
 * 本人確認書類聴取画面（BC複合取引）
 */
export class SelfCreditcardDocumentConfirmRenderer extends ChatFlowRenderer {

    public processType = -1;

    private state: SavingsState;
    private creditcardState: CreditCardState;
    private modalService: ModalService;

    constructor(
        private chatFlowAccessor: ChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: SavingsStore,
        private creditCardStore: CreditCardStore
    ) {
        super();
        this.state = this.store.getState();
        this.modalService = InjectionUtils.injector.get(ModalService);
    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-self-creditcard-document-confirm.yml', pageIndex);
    }

    /**
     * 固定値を保存する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSaveSubmit(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            this._action.setStateSubmitDataValue(entity.choices);
            this.getNextChat(entity.next, pageIndex);
        }
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                if (entity.name === 'addIdentityDocumentImg' && answer.value === '1') {
                    const choice = entity.choices ? entity.choices.find((item) => item.value === answer.value) : undefined;
                    this._action.resetLastNode({
                        order: choice ? choice.next : entity.order,
                        pageIndex: pageIndex
                    });
                    return;
                } else {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer);
                this.getNextChat(answer.next, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const choices = InputUtils.changeValidationRuleMax(entity, this.state.submitData);

        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        this.getNextChat(entity.next, pageIndex);
                    });
                }

            });
    }

    /**
     * キャッシュカード口座入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onNumberKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * メモリにの値を判断する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        if (entity.choices) {
            switch (entity.name) {
                case 'isModify': {
                    judgeResult = this.state.submitData.isModify === IsModifyJudge.IsModify ?
                        IsModifyJudge.IsModify : IsModifyJudge.IsNotModify;
                    break;
                }
                case 'ifApplyBC': {
                    judgeResult = JudgeResultStatus.RESULT_0;
                    if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
                        judgeResult = JudgeResultStatus.RESULT_1;
                    }
                    break;
                }
                case 'isDriverLicense': {
                    this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE ?
                        judgeResult = this.state.submitData.hasLicense === Constants.DriveCard &&
                            this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.NO ? 'true' : 'false' :
                        judgeResult = this.state.submitData.identificationDocument1 === '01' ? 'true' : 'false';
                    break;
                }
                case 'isStudent': {
                    judgeResult = this.creditCardStore.getState().submitData.career === Career.STUDENT
                        || this.creditCardStore.getState().submitData.isNearGraduate === IsNearGraduate.YES
                        ? 'true' : 'false';
                    break;
                }
            }
            entity.choices.forEach((choice) => {
                if (choice.value === judgeResult) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(choice: any) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            this.modalService.showModal(action.value, { imgSrc: action.imgSrc });
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }
}
