import { ViewContainerRef } from '@angular/core';
import { ObjectUtils } from 'adep/utils';
import { InjectionUtils } from 'adep/utils/injection.utils';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { ChatOption, COMMON_CONSTANTS, YearCalculation } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { PRODUCT_TYPE } from 'dhdt/branch/pages/existing-reserve/utils/product-category-utils';
import { SelectAddressComponent } from 'dhdt/branch/shared/components/address/view/select-address.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';
declare let cordova: any;

/**
 * 確認画面修正用コンポネント（個人情報）.
 */
export class ConfirmSelfApplyComponent extends ChatFlowRenderer {
    public processType = 1;

    private state: SavingsState;
    private serverInfoService: ServerInfoService;

    constructor(
        private chatFlowAccessor: ChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: SavingsStore,
        private loginStore: LoginStore,
    ) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
        this.serverInfoService = InjectionUtils.injector.get(ServerInfoService);
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-confirm-page-selfinfo.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'buttonThreeCols': {
                this.onButton(question, pageIndex);
                break;
            }
            case 'datepicker':
            case 'prefecturePicker':
            case 'countyUrbanVillagePicker': {
                this.onPicker(question, pageIndex);
                break;
            }
            case 'selectAddress': {
                this.onSelectAddress(question, pageIndex);
                break;
            }
            case 'selectStreet': {
                this.onSelectStreet(question, pageIndex);
                break;
            }
        }
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                maxColNum: (entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON) ? 3 : undefined,
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            const backupDataService = InjectionUtils.injector.get(BackupDataService);
            options.furiganaOnly = ChatOption.VALIDATION_ON;
            options.kanaText = backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
            .subscribe((answer) => {
                if (entity.name.length > 0 && answer.value.length > 0) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }

                if (answer.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.next, pageIndex);
                }
            });
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {

        const choices = this.changeValidationRuleMax(entity, this.state.submitData);
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                let maxLenth;
                if (choices && choices.length > 0) {
                    maxLenth = InputUtils.calculateMaxLength(choices[0].name,
                        this.state.submitData.holderAddressStreetNameFuriKanaInput,
                        this.state.submitData.holderAddressStreetNameFuriKanaSelect);
                }

                InputUtils.getKanjiToKana(answer.value, maxLenth).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    if (entity.fullwidthHalfwidthDivisionCode) {
                        this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                        this.store.registerSignalHandler(SavingsSignal.CHARACTER_CHECK, (data) => {
                            this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                            this.getNextChat(entity.next, pageIndex);
                        });
                        const params = {
                            tabletApplyId: this._store.getState().tabletApplyId,
                            params: {
                                receptionTenban: this.loginStore.getState().belongToBranchNo,
                                checkStrings: [{
                                    checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                    checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                }],
                            }
                        };
                        this._action.characteCheck(params, () => {
                            this._action.editChart(entity.order, pageIndex,
                                this.state.showChats[this.state.showChats.length - 1].answer.order);
                            this.getNextChat(entity.order, pageIndex);
                        });
                    } else {
                        this.getNextChat(entity.next, pageIndex);
                    }
                });
            });
    }

    public onNumberKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this._action.clearSubmitData(entity.choices);
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            if (answer === 'skip') {
                this.setAnswer({ text: 'スキップ', value: [] });
                this.getNextChat(entity.skip, pageIndex);
            } else {
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            }
        });
    }

    /**
     * ピッカーコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onPicker(entity: SavingQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        let title = entity.options ? entity.options.title : undefined;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else if (entity.name === COMMON_CONSTANTS.CHILDERN_BIRTHDATE &&
            this._store.getState().submitData.selectProductType === PRODUCT_TYPE.LOVE) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .startOf(COMMON_CONSTANTS.DATE_YEAR)
                    .endOf(COMMON_CONSTANTS.DATE_MONTH)
                    .subtract(YearCalculation.LOVE_MAX_AGE, COMMON_CONSTANTS.DATE_YEAR)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                max: moment(customerApplyStartDate)
                    .add(1, COMMON_CONSTANTS.DATE_DAY)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else if (entity.name === COMMON_CONSTANTS.HOLDER_BIRTHDATE &&
            this.state.submitData.selectProductType === PRODUCT_TYPE.HAPPINESS1) {
            validation = {
                ...entity.validationRules,
                max: moment(customerApplyStartDate)
                    .subtract(YearCalculation.HAPPINESS1_MIN_AGE, COMMON_CONSTANTS.DATE_YEAR)
                    .add(1, COMMON_CONSTANTS.DATE_DAY)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                min: moment(customerApplyStartDate)
                    .subtract(YearCalculation.HAPPINESS1_MAX_AGE, COMMON_CONSTANTS.DATE_YEAR)
                    .add(1, COMMON_CONSTANTS.DATE_DAY)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
            };
            title = this.labels.common.pickerHappinessTitle;
        } else {
            validation = entity.validationRules;
        }

        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: title,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData
        };
        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                if (entity.name === 'depositPeriodYearMonth') {
                    this._action.setDueDate();
                }
                if (entity.name === 'pensionYearMonth') {
                    this._action.setDueDateAndDepositPeriodYearMonth();
                }
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onSelectAddress(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectAddressComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            this.getNextChat(answer.value ? entity.next : entity.skip, pageIndex);
        });
    }

    /**
     * 町丁名コンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSelectStreet(entity: SavingQuestionsModel, pageIndex: number): void {
        const params = {
            prefectureKanji: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillageKanji: this.state.submitData.holderAddressCountyUrbanVillage
        };
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(params, SelectStreetComponent, this.footerContent, options)
            .subscribe((result: { isSkip: boolean, text: string, value: any }) => {
                this.chatFlowAccessor.clearComponent();

                if (result.value) {
                    const answer = {
                        text: result.text,
                        value: [
                            { key: 'holderAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'holderAddressStreetNameFuriKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) },
                            { key: 'streetWork', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'showStreet', value: (result.isSkip ? undefined : result.value.streetKanji) }
                        ]
                    };
                    this.setAnswer(answer);
                    this.getNextChat(result.isSkip ? entity.skip : entity.next, pageIndex);
                } else {
                    this._action.resetLastNode({ order: entity.next, pageIndex: pageIndex });
                }
            });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        if (entity.option === 'url') {
            this.serverInfoService.getInfoFormServe(entity.name).subscribe((result) => {
                entity.choices.forEach((choice) => {
                    if (result === choice.value) {
                        if (choice.value === '1') {
                            this._action.setStateSubmitDataValue({
                                name: 'resetZipCodeFlg',
                                value: true,
                            });
                        }
                        this.getNextChat(choice.next, pageIndex);
                        return;
                    }
                });
            });
        } else if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }
    /**
     * change ValidationRule Max length
     * @param entity チャットフローエンティティー
     * @param submitData データ
     */
    private changeValidationRuleMax(entity: any, submitData: any) {
        const choicesResult = ObjectUtils.clone(entity.choices);

        // 「町丁名（漢字）」の入力済桁数により、「番地以降（漢字）」の入力可能最大桁数を調整する
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW
            && submitData.holderAddressStreetNameSelect
            && submitData.holderAddressStreetNameSelect.length > 0) {
           let holderAddressStreetLength = 0;
           holderAddressStreetLength = submitData.holderAddressStreetNameSelect.length;
           choicesResult[0].validationRules.max = entity.choices[0].validationRules.max - holderAddressStreetLength;
         } else if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW
            && choicesResult[0].name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER
            && submitData.holderAddressStreetNameInput
            && submitData.holderAddressStreetNameInput.length > 0) {
            let holderAddressStreetLength = 0;
            holderAddressStreetLength = submitData.holderAddressStreetNameInput.length;
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max - holderAddressStreetLength + 1;
        }

        // 「町丁名（カナ）」の入力済桁数により、「番地以降（カナ）」の入力可能最大桁数を調整する
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FURIKANA_FOR_SHOW
            && choicesResult.length > 1
            && choicesResult[0].name === 'holderAddressStreetNameFuriKanaInput'
            && choicesResult[1].name === 'holderAddressHouseNumberFuriKana') {
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max -
                submitData.holderAddressStreetNameFuriKanaSelect.length;
        }
        return choicesResult;
    }
}
