import { ViewContainerRef } from '@angular/core';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { COMMON_CONSTANTS} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

/**
 * 本人確認書類聴取画面（BC複合取引）
 */
export class SelfCreditCardStuffConfirmRenderer extends ChatFlowRenderer {

    public processType = -1;
    private state: SavingsState;

    constructor(
        private chatFlowAccessor: ChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: SavingsStore,
        private loginStore: LoginStore
    ) {
        super();
        this.state = this.store.getState();
    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-self-creditcard-stuff-confirm.yml', pageIndex);
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const choices = InputUtils.changeValidationRuleMax(entity, this.state.submitData);

        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        if (entity.fullwidthHalfwidthDivisionCode) {
                            this.store.registerSignalHandler(SavingsSignal.CHARACTER_CHECK, (data) => {
                                this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                                this.getNextChat(entity.next, pageIndex);
                            });
                            const params = {
                                tabletApplyId: this._store.getState().tabletApplyId,
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                                    checkStrings: [{
                                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                        checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                    }],
                                }
                            };
                            this._action.characteCheck(params, () => {
                                this._action.editChart(entity.order, pageIndex,
                                    this.state.showChats[this.state.showChats.length - 1].answer.order);
                                this.getNextChat(entity.order, pageIndex);
                            });
                        } else {
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });
                }

            });
    }

    /**
     * キャッシュカード口座入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onNumberKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name) {
                this._action.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
            }
            this.getNextChat(answer.next, pageIndex);
        });
    }
}
