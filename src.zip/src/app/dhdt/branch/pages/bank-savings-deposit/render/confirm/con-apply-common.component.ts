import { ViewContainerRef } from '@angular/core';
import { ObjectUtils } from 'adep/utils';
import { InjectionUtils } from 'adep/utils/injection.utils';
import { DeviceService } from 'dhd/common/services/device.service';
import { ChatFlowAccessor } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.accessor';
import { ChatFlowRenderer } from 'dhdt/branch/pages/bank-savings-deposit/core/chat-flow.renderer';
import { SavingQuestionsModel } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/bank-savings-deposit/service/backup-data.service';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { BsdAgentConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/savings/bsd-agent-confirm.component';
import {
    ButtonSelect, ChatOption,
    childrenNumbersFlag, ChildrenRelationship, COMMON_CONSTANTS, MonthCalculation, PensionType, YearCalculation
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { PRODUCT_TYPE } from 'dhdt/branch/pages/existing-reserve/utils/product-category-utils';
import { SelectAddressComponent } from 'dhdt/branch/shared/components/address/view/select-address.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { CardListComponent } from 'dhdt/branch/shared/components/card-list/card-list.component';
import { DepositInputComponent } from 'dhdt/branch/shared/components/deposit-input/deposit-input.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { MonthInputComponent } from 'dhdt/branch/shared/components/month-input/month-input.component';
import { MultiButtonGroupComponent } from 'dhdt/branch/shared/components/multi-button-group/multi-button-group.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { QuantityInputComponent } from 'dhdt/branch/shared/components/quantity-input/quantity-input.component';
import { RadioButtonComponent } from 'dhdt/branch/shared/components/radio-button-group/radio-button.component';
import { SelectProductComponent } from 'dhdt/branch/shared/components/select-product/select-product.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { ProductCategoryUtils } from 'dhdt/branch/shared/utils/product-category-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { NavController } from 'ionic-angular';
import * as moment from 'moment';
import { take, tap } from 'rxjs/operators';

/**
 * 確認画面修正用コンポネント（申し込み情報）.
 */
export class ConfirmApplyCommonComponent extends ChatFlowRenderer {

    public processType = 1;

    private state: SavingsState;

    private phoneIsSkiped: boolean = false;
    private telIsSkiped: boolean = false;
    private serverInfoService: ServerInfoService;
    private childrenRelationshipOld: string;

    constructor(private chatFlowAccessor: ChatFlowAccessor, private footerContent: ViewContainerRef,
                private store: SavingsStore, private modalService: ModalService, private loginStore: LoginStore,
                private deviceService: DeviceService, public navCtrl: NavController, private audioService: AudioService) {
        super();
        this.state = this.store.getState();
        this.serverInfoService = InjectionUtils.injector.get(ServerInfoService);
        this.childrenRelationshipOld = this.state.submitData.childrenRelationship;
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-confirm-page-common.yml', pageIndex);
    }

    public rendererComponents(question: SavingQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'password6bits':
            case 'password4bits': {
                this.onPasswordInput(question, pageIndex);
                break;
            }
            case 'card': {
                this.onCard(question, pageIndex);
                break;
            }
            case 'mulitButton': {
                this.onMulitButton(question, pageIndex);
                break;
            }
            case 'buttonTwoCols': {
                this.onButtonTwoCols(question, pageIndex);
                break;
            }
            case 'buttonThreeCols': {
                this.onButton(question, pageIndex);
                break;
            }
            case 'agreedModal': {
                this.onModal(question, pageIndex);
                break;
            }
            case 'radioButton': {
                this.onRadioButton(question, pageIndex);
                break;
            }
            case 'yearPicker':
            case 'monthpicker':
            case COMMON_CONSTANTS.ELEMENT_TYPE_YEARMONTH_PICKER:
            case 'daypicker':
            case 'datepicker':
            case 'picker':
            case 'prefecturePicker':
            case 'countyUrbanVillagePicker': {
                this.onPicker(question, pageIndex);
                break;
            }
            case 'selectAddress': {
                this.onSelectAddress(question, pageIndex);
                break;
            }
            case 'selectStreet': {
                this.onSelectStreet(question, pageIndex);
                break;
            }
            case 'selectProduct': {
                this.onSelectProduct(question, pageIndex);
                break;
            }
            case 'normalDepositInput':
            case 'thousandDepositInput': {
                this.onDepositInput(question, pageIndex);
                break;
            }
            case 'selectMonth': {
                this.onSelectMonth(question, pageIndex);
                break;
            }
            case 'selectbranch': {
                this.onSelectBranch(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_NUMBER_THOUSAND: {
                this.onQuantityInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_REQUEST: {
                this.requestDefaultAddress(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_TEMP: {
                this.onButton(question, pageIndex, true);
                break;
            }
        }
    }

    public onSelectBranch(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxColNum: 2
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectBranchComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            // 選択された支店を設定
            this._action.changeOpenStore(answer);
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: SavingQuestionsModel, pageIndex: number, defaultAddress = false): void {
        if (defaultAddress) {
            entity.choices[0].text = entity.options.branchNameKanji;
            entity.choices[0].value = entity.options;
        }
        const options = {
            logInfo: {
                maxColNum: (entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON) ? 3 : undefined,
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            const backupDataService = InjectionUtils.injector.get(BackupDataService);
            options.furiganaOnly = ChatOption.VALIDATION_ON;
            options.kanaText = backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
            .subscribe((answer) => {
                if (entity.name.length > 0 && answer.value.length > 0) {
                    if (entity.name === 'accountOpeningPurpose') {
                        const name: string = answer.name;
                        const values: any[] = [];
                        entity.choices.forEach((element) => {
                            let selectedName = null;
                            if (name === element.name) {
                                values.push({ key: element.name, value: ButtonSelect.BUTTON_IS_SELECT });
                                selectedName = element.name;
                            }
                            if (!selectedName) {
                                values.push({ key: element.name, value: ButtonSelect.BUTTON_IS_NOT_SELECT });
                            }
                        });
                        this.setAnswer({
                            text: answer.text,
                            value: values
                        });
                    } else {
                        this.setAnswer({
                            text: answer.text,
                            value: [
                                { key: entity.name, value: answer.value },
                                { key: answer.name, value: answer.value }
                            ]
                        });
                    }
                }

                if (entity.name === 'childrenRelationship') {
                    if ((this.childrenRelationshipOld === ChildrenRelationship.FATHER
                        || this.childrenRelationshipOld === ChildrenRelationship.MOTHER)
                        && (answer.value === ChildrenRelationship.GRAND_FATHER || answer.value === ChildrenRelationship.GRAND_MOTHER)) {
                        this.state.submitData.childrenNumbersFlag = childrenNumbersFlag.CHILDREN_NUMBER_NOT_NEXT_TWO;
                    } else if ((this.childrenRelationshipOld === ChildrenRelationship.GRAND_FATHER
                        || this.childrenRelationshipOld === ChildrenRelationship.GRAND_MOTHER)
                        && (answer.value === ChildrenRelationship.FATHER || answer.value === ChildrenRelationship.MOTHER)) {
                        this.state.submitData.childrenNumbersFlag = childrenNumbersFlag.CHILDREN_NUMBER_NEXT;
                    } else if ((this.childrenRelationshipOld === ChildrenRelationship.FATHER
                        || this.childrenRelationshipOld === ChildrenRelationship.MOTHER)
                        && (answer.value === ChildrenRelationship.FATHER
                            || answer.value === ChildrenRelationship.MOTHER)) {
                        this.state.submitData.childrenNumbersFlag = childrenNumbersFlag.CHILDREN_NUMBER_NOT_NEXT;
                    } else if ((this.childrenRelationshipOld === ChildrenRelationship.GRAND_FATHER
                        || this.childrenRelationshipOld === ChildrenRelationship.GRAND_MOTHER)
                        && (answer.value === ChildrenRelationship.GRAND_FATHER
                            || answer.value === ChildrenRelationship.GRAND_MOTHER)) {
                        this.state.submitData.childrenNumbersFlag = childrenNumbersFlag.CHILDREN_NUMBER_NOT_NEXT;
                    }
                    this.getNextChat(answer.next, pageIndex);
                    this.childrenRelationshipOld = this.state.submitData.childrenRelationship;
                } else if (defaultAddress) {
                    this.chatFlowAccessor.clearComponent();
                    let result;
                    if (answer.next < 0) {
                        const tempAnswer = [];
                        for (const key in entity.options) {
                            if (entity.options.hasOwnProperty(key)) {
                                const element = entity.options[key];
                                tempAnswer.push({ key: key, value: element });
                            }
                        }
                        result = {
                            text: entity.options.branchNameKanji,
                            value: tempAnswer
                        };
                    } else {
                        result = {
                            text: answer.text,
                            value: [
                                { key: entity.name, value: answer.value },
                                { key: answer.name, value: answer.value }
                            ]
                        };
                    }
                    this.setAnswer(result);
                    this.getNextChat(answer.next, pageIndex);
                } else if (answer.action.type.length > 0) {
                    this.configAction(answer, pageIndex);
                } else if (answer.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.next, pageIndex);
                }
            });
    }

    // fix 2 cols
    public onButtonTwoCols(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            maxColNum: 2,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
                this.getNextChat(answer.next, pageIndex);
            });
    }

    public onMulitButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxLength: entity.validationRules.max
        };
        this.chatFlowAccessor.addComponent(entity.choices, MultiButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }                    ]
                });
            }

            this.chatFlowAccessor.clearComponent();

            let next = answer.next.split('、')[0];
            if (entity.name === COMMON_CONSTANTS.HOLDER_CAREER) {
                answer.next.split('、').forEach((order) => {
                    if (order === COMMON_CONSTANTS.ExistingSavings.CareerNextOrder) {
                        next = order;
                    }
                });
            }
            this.getNextChat(Number.parseInt(next), pageIndex);
        });
    }

    public onKeybord(entity: SavingQuestionsModel, pageIndex: number): void {

        const choices = this.changeValidationRuleMax(entity, this.state.submitData);
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {

                    let maxLenth;
                    if (choices && choices.length > 0) {
                        maxLenth = InputUtils.calculateMaxLength(choices[0].name,
                            this.state.submitData.holderAddressStreetNameFuriKanaInput,
                        this.state.submitData.holderAddressStreetNameFuriKanaSelect);
                    }
                    InputUtils.getKanjiToKana(answer.value, maxLenth).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        if (entity.fullwidthHalfwidthDivisionCode) {
                            this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                            this.store.registerSignalHandler(SavingsSignal.CHARACTER_CHECK, (data) => {
                                this.store.unregisterSignalHandler(SavingsSignal.CHARACTER_CHECK);
                                this.getNextChat(entity.next, pageIndex);
                            });
                            const params = {
                                tabletApplyId: this._store.getState().tabletApplyId,
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                                    checkStrings: [{
                                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                        checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                    }],
                                }
                            };
                            this._action.characteCheck(params, () => {
                                this._action.editChart(entity.order, pageIndex,
                                    this.state.showChats[this.state.showChats.length - 1].answer.order);
                                this.getNextChat(entity.order, pageIndex);
                            });
                        } else {
                            if (entity.name === 'pensionType'
                                    && this._store.getState().submitData.pensionType !== PensionType.OTHER_DETAIL) {
                                this._action.setStateSubmitDataValue({ name: 'pensionTypeOtherDetail', value: null });
                            }
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });
                }
            });
    }

    public onNumberKeybord(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this._action.clearSubmitData(entity.choices);
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                } else {
                    this.setAnswer(answer);
                }

                const isShowModal = this.telSkip(entity.name, answer === 'skip');
                if (!isShowModal) {
                    this.getNextChat(answer === 'skip' ? entity.skip : entity.next, pageIndex);
                }
            });
    }

    public onPasswordInput(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            birthday: this.state.submitData.holderBirthdate,
            birthdayText: this.state.submitData.holderBirthdateText,
            telephone: [
                this.state.submitData.getHolderMobileNo(),
                this.state.submitData.getHolderTelephoneNo(),
            ],
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PasswordInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                } else {

                    // 暗証番号ルール適合性チェックハンドルを追加
                    // this.store.registerSignalHandler(SavingsSignal.GET_PASSWORD_RULE, (data) => {
                    //     this.store.unregisterSignalHandler(SavingsSignal.GET_PASSWORD_RULE);
                    //     if (data.response.values.result === '1') {
                    //         const buttonList = [
                    //             { text: 'OK', buttonValue: 'ok' },
                    //         ];
                    //         this.modalService.showAlert(
                    //             this.labels.error.passwordError,
                    //             null, 'icon_alert@2x.png', buttonList, 'settings-alert-modal',
                    //             () => {
                    //                 const lastNode = this.state.showChats[this.state.showChats.length - 1];
                    //                 this._action.resetLastNode({ order: lastNode.order, pageIndex: lastNode.pageIndex });
                    //             }
                    //         );
                    //     } else {
                    //         this.chatFlowAccessor.clearComponent();
                    //         this.setAnswer(answer);
                    //         this.getNextChat(entity.next, pageIndex);
                    //     }
                    // });

                    this.chatFlowAccessor.clearComponent();
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);

                    // // 暗証番号ルール適合性チェックを行う
                    // const param: NewPasswordRuleCheckInterface = {
                    //     tabletApplyId: this.state.tabletApplyId,
                    //     userMngNo: this.loginStore.getState().bankclerkId,
                    //     path: CoreBankingConstants.ApiPathConsts.PASSWORD_RULE_CHECK,
                    //     params: {
                    //         bankNo: CoreBankingConst.bankNo,
                    //         receptionTenban: this.state.submitData.receptionBranchNo,
                    //         receptionNo: this.state.submitData.receptionNo,
                    //         terminalNo: this.deviceService.getDeviceId(),
                    //         passcodeType: entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4 ? '1' : '2',
                    //         passcode: answer.value[0].value,
                    //         birthday: this.state.submitData.holderBirthdate,
                    //         telephoneNo: this.state.submitData.getHolderTelephoneNo(),
                    //         mobileNo: this.state.submitData.getHolderMobileNo(),
                    //         officeNo: ''
                    //     }
                    // };
                    // this._action.checkNewCustomerPasswordRule(param);
                }
            });
    }

    public onModal(entity: SavingQuestionsModel, pageIndex: number): void {
        this.modalService.showModal(entity.type, undefined, () => {
            this.navCtrl.setRoot(BsdAgentConfirmComponent);
        });
    }

    public onRadioButton(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, RadioButtonComponent, this.footerContent, options).subscribe((answer) => {
            if (answer.action.type === 'modal') {
                this.modalService.showModal(answer.action.value, { imgSrc: answer.imgSrc });
            }

            if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onCard(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, CardListComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: entity.name + 'ImageSrc', value: answer.imgSrc }
                ]
            });
            this.getNextChat(answer.next, pageIndex);
        });
    }

    public onJudge(entity: SavingQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        if (entity.option === 'url') {
            this.serverInfoService.getInfoFormServe(entity.name).subscribe((result) => {
                entity.choices.forEach((choice) => {
                    if (result === choice.value) {
                        this.getNextChat(choice.next, pageIndex);
                        return;
                    }
                });
            });
        } else if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    if (this.state.submitData.childrenNumbersFlag === '2') {
                        delete this.state.submitData.childrenNumbers;
                    }
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
            switch (entity.name) {
                // 名前の聴取済かにより分岐
                case 'isChangeStore': {
                    const receptionBranchNo = this.state.submitData.receptionBranchNo;
                    // 受付店以外⇒受付店に口座開設店舗を修正した場合  受付店以外⇒受付店以外へ口座開設店舗を修正した場合
                    if ((this.state.tenbanBefore !== receptionBranchNo && this.state.submitData.tenban === receptionBranchNo)
                    || (this.state.tenbanBefore !== receptionBranchNo && this.state.submitData.tenban !== receptionBranchNo
                        && this.state.submitData.savingBranchReason)
                    || (this.state.tenbanBefore === receptionBranchNo && this.state.submitData.tenban === receptionBranchNo)) {
                        judgeResult = '00';
                    // 受付店⇒受付店以外
                    } else if (this.state.tenbanBefore === receptionBranchNo
                        && this.state.submitData.tenban !== receptionBranchNo) {
                        judgeResult = '01';
                    }
                    this._action.setStateSubmitDataValue({ name: 'storeChangeFlg', value: judgeResult });
                    break;
                }
            }
            entity.choices.forEach((choice) => {
                if (judgeResult === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    /**
     * ピッカーコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onPicker(entity: SavingQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else if (entity.name === COMMON_CONSTANTS.CHILDERN_BIRTHDATE &&
            this._store.getState().submitData.selectProductType === PRODUCT_TYPE.LOVE) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .startOf(COMMON_CONSTANTS.DATE_YEAR)
                    .endOf(COMMON_CONSTANTS.DATE_MONTH)
                    .subtract(YearCalculation.LOVE_MAX_AGE, COMMON_CONSTANTS.DATE_YEAR)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                max: moment(customerApplyStartDate)
                    .add(1, COMMON_CONSTANTS.DATE_DAY)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else if (entity.name === COMMON_CONSTANTS.PENSION_YEAR_MONTH &&
            this.state.submitData.selectProductType === PRODUCT_TYPE.HAPPINESS1) {
            validation = {
                ...entity.validationRules,
                range: [YearCalculation.ADD_YEAR_ZERO, moment(customerApplyStartDate).month() === MonthCalculation.JAN ?
                    YearCalculation.ADD_YEAR_TWO : YearCalculation.ADD_YEAR_THREE],
                max: moment(customerApplyStartDate)
                    .add(YearCalculation.ADD_YEAR_THREE, COMMON_CONSTANTS.DATE_YEAR)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM),
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM)
            };
        } else {
            validation = entity.validationRules;
        }
        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            currentYear: Number(moment(customerApplyStartDate).format(COMMON_CONSTANTS.DATE_FORMAT_YYYY)),
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData
        };
        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                if (entity.name === 'depositPeriodYearMonth') {
                    this._action.setDueDate();
                }
                if (entity.name === 'pensionYearMonth') {
                    this._action.setDueDateAndDepositPeriodYearMonth();
                }
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onSelectAddress(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectAddressComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            this.getNextChat(answer.value ? entity.next : entity.skip, pageIndex);
        });
    }

    public onSelectStreet(entity: SavingQuestionsModel, pageIndex: number): void {
        const params = {
            prefectureKanji: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillageKanji: this.state.submitData.holderAddressCountyUrbanVillage
        };
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(params, SelectStreetComponent, this.footerContent, options)
            .subscribe((result: { isSkip: boolean, text: string, value: any }) => {
                this.chatFlowAccessor.clearComponent();

                if (result.value) {
                    const answer = {
                        text: result.text,
                        value: [
                            { key: 'holderAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'holderAddressStreetNameFuriKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) },
                            { key: 'streetWork', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'showStreet', value: (result.isSkip ? undefined : result.value.streetKanji) }
                        ]
                    };
                    this.setAnswer(answer);
                    this.getNextChat(result.isSkip ? entity.skip : entity.next, pageIndex);
                } else {
                    this._action.resetLastNode({ order: entity.next, pageIndex: pageIndex });
                }
            });
    }

    public onSelectProduct(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(ProductCategoryUtils.getProductInfos(), SelectProductComponent, this.footerContent, options)
            .subscribe((answer) => {
                this.setAnswer({
                    text: answer.name,
                    value: [
                        { key: entity.name, value: answer.category },
                        { key: 'selectProductName', value: ProductCategoryUtils.getProductName(answer.category) }
                    ]
                });
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onDepositInput(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, DepositInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onSelectMonth(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, MonthInputComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer({
                text: answer.text,
                value: entity.choices.map((choice) => {
                    return { key: choice.name, value: answer.value[choice.name] };
                })
            });
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * 千円以上の金額入力コンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onQuantityInput(entity: SavingQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            unit: entity.options ? entity.options.unit : undefined,
            validationRules: entity.validationRules
        };

        this.chatFlowAccessor.addComponent(entity.choices, QuantityInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * チャット終了
     *
     * @param nextChatName
     * @param backToTop TOPへ戻る用
     */
    public chatFlowCompelete(nextChatName?: string, backToTop: any = null) {
        this._action.chatFlowCompelete(nextChatName, backToTop);
    }

    // if phone and tel are skiped , modal show
    private telSkip(name: string, isSkip: boolean): boolean {
        if (name === 'holderMobileNo') {
            this.phoneIsSkiped = isSkip;
        }
        if (name === 'holderTelephoneNo') {
            this.telIsSkiped = isSkip;
        }
        if (name === 'holderTelephoneNo' && this.phoneIsSkiped === true && this.telIsSkiped === true) {
            const buttonList = [
                { text: 'OK', buttonValue: 'ok' },
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.warnTelTitle,
                buttonList, () => {
                    this._action.needInputPhoenNo();
                }
            );
            return true;
        }
        return false;
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === 'route') {
            // Topへ戻る
            this.chatFlowCompelete(action.value, true);

        } else if (action.type === 'modal' && choice.name === 'accountFeatures') {
            // 印鑑レスの紹介モーダルを表示
            this.modalService.showModal('noticeButtonModal', { imgSrc: COMMON_CONSTANTS.REGULATIONS_KOUZA_TOKUCHOU },
            () => {
                const lastNode = this.state.showChats.pop();
                // this._action.resetLastNode({order: lastNode.order, pageIndex: lastNode.pageIndex});
                this.getNextChat(lastNode.order, lastNode.pageIndex);
            });

        } else if (action.type === 'modal') {
            this.modalService.showModal(action.value, { tabletApplyId: this.state.tabletApplyId }, (result) => {
                if (result) {
                    this.getNextChat(choice.next, pageIndex);
                }
            });
        } else if (action.type === 'resetOrder') {
            this._action.resetSpecialNode({order: parseInt(action.value, 10), pageIndex: pageIndex});
        }
    }

    /**
     * Request default address
     * @param entity entity
     * @param pageIndex pageIndex
     */
    private requestDefaultAddress(entity, pageIndex) {
        const codeParams = {
            prefectureKanji: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillageKanji: this.state.submitData.holderAddressCountyUrbanVillage,
            streetKanji: this.state.submitData.holderAddressStreetNameSelect
        };
        this._action
            .searchRegionCode(codeParams)
            .pipe(
                take(1),
                tap(({ result : { regionCode } }) => {
                    const addressParams = { regionCode: regionCode || '' };
                    this._action.requestDefaultAddress(addressParams, entity, pageIndex);
                })
            )
            .subscribe();
    }

    /**
     * change ValidationRule Max length
     * @param entity チャットフローエンティティー
     * @param submitData データ
     */
    private changeValidationRuleMax(entity: any, submitData: any) {
        const choicesResult = ObjectUtils.clone(entity.choices);

        // 「町丁名（漢字）」の入力済桁数により、「番地以降（漢字）」の入力可能最大桁数を調整する
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW
            && submitData.holderAddressStreetNameSelect
            && submitData.holderAddressStreetNameSelect.length > 0) {
           let holderAddressStreetLength = 0;
           holderAddressStreetLength = submitData.holderAddressStreetNameSelect.length;
           choicesResult[0].validationRules.max = entity.choices[0].validationRules.max - holderAddressStreetLength;
         } else if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW
            && choicesResult[0].name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER
            && submitData.holderAddressStreetNameInput
            && submitData.holderAddressStreetNameInput.length > 0) {
            let holderAddressStreetLength = 0;
            holderAddressStreetLength = submitData.holderAddressStreetNameInput.length;
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max - holderAddressStreetLength + 1;
        }

        // 「町丁名（カナ）」の入力済桁数により、「番地以降（カナ）」の入力可能最大桁数を調整する
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FURIKANA_FOR_SHOW
            && choicesResult.length > 1
            && choicesResult[0].name === 'holderAddressStreetNameFuriKanaInput'
            && choicesResult[1].name === 'holderAddressHouseNumberFuriKana') {
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max -
                submitData.holderAddressStreetNameFuriKanaSelect.length;
        }
        return choicesResult;
    }
}
