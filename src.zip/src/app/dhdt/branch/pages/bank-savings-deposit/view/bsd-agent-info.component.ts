import { Component, OnInit, ViewChild } from '@angular/core';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { SubmitEntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { AccountComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/account.component';
import { AgentConfirmPageBaseComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/common/agent-confirm-page-base.component';
import { BsdAgentConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/savings/bsd-agent-confirm.component';
import { CommonBusinessType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessChatComponent } from 'dhdt/branch/pages/common-business/view/common-business-chat.component';
import {
    ClearSavingImagesClickRecordType, COMMON_CONSTANTS, Constants,
    ContinueOrBackToConfirm, HasDriversCareerLicense, HasLicense, LicensePhotoType, MaskingCheckboxName
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { AgentConfirmMethodComponent } from 'dhdt/branch/shared/components/confirmpage-common/agent-confirm-method.component';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { NavController, NavParams, ViewController } from 'ionic-angular';
import { ModalController } from 'ionic-angular/components/modal/modal-controller';

@Component({
    selector: 'bsd-agent-info-component',
    templateUrl: 'bsd-agent-info.component.html'
})

/**
 * BsdAgent info component(行員認証画面（代理人）ー 代理人情報).
 */
export class BsdAgentInfoComponent extends AgentConfirmPageBaseComponent implements OnInit {

    public options: any;
    @ViewChild(AgentConfirmMethodComponent)
    private agentConfirmMethodComponent: AgentConfirmMethodComponent;

    constructor(
        public navCtrl: NavController,
        public navParam: NavParams,
        public modalCtrl: ModalController,
        public viewCtrl: ViewController,
        public modalService: ModalService,
    ) {
        super(navCtrl, navParam, viewCtrl);
    }

    public ngOnInit() {
        super.ngOnInit();
        this.setLogOptions();
        this.action.submitDataBackup();
    }

    public moveToNextPage() {
        this.saveOperationLog(this.labels.logging.AccountConfirm.agentNextButton);
        this.navCtrl.push(AccountComponent, {
            sameHolderList: this.sameHolderList
        });

    }

    public onChangeReceptionNumber(data) {
        data.forEach((element) => {
            this.action.setStateSubmitDataValue({
                name: element.key,
                value: element.value
            });
        });
        this.action.updateSubmitDataBackup(data);
    }

    public onEditIdentityDocument() {
        // 修正チャットフラグを設定
        this.action.setStateSubmitDataValue({
            name: 'isModify',
            value: '1'
        });

        // 行員確認画面で名義人の本人確認書類１の有効期限が空欄のとき、
        // 修正チャットで必ず有効期限を聴取するために、
        // クリア状態を判別するためのフラグを設ける。
        if (!this.state.submitData.identificationDocument1ExpiryDate
            || !this.state.submitData.identificationDocument1ExpiryDateText) {
            // 有効期限のクリア判別フラグをtrueに更新する。
            this.action.setModifyExpiryDateExists(true);
        } else {
            // 有効期限のクリア判別フラグをfalseに更新する。
            this.action.setModifyExpiryDateExists(false);
        }

        // 行員確認画面（口座名義人）で最新（再撮影後）の画像をバックアップ
        // 再撮影後、行員確認画面（口座名義人）→行員確認画面（代理人）に戻り修正チャットを起動すると
        // 再撮影前の画像になってしまうのを防ぐ
        const imgBackup = this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE ?
            // OCR(運転免許証・マイナンバーカード)の場合、OCR画像データをバックアップ
            {
                // 本チャットで「運転経歴証明書」を選択し再撮影後
                // 「運転免許証」に変更した場合、holderCardImageFront,Backがクリアされundefinedとなるため
                // copySubmitData配下の値を取得する
                holderCardImageFront: this.state.submitData.holderCardImageFront ?
                    this.state.submitData.holderCardImageFront : this.state.copySubmitData.holderCardImageFront,
                holderCardImageBack: this.state.submitData.holderCardImageBack ?
                    this.state.submitData.holderCardImageBack : this.state.copySubmitData.holderCardImageBack,
            } :
            // それ以外の場合、copySubmitData配下をバックアップ
            {
                holderCardImageFront: this.state.copySubmitData.holderCardImageFront,
                holderCardImageBack: this.state.copySubmitData.holderCardImageBack,
            };
        // OCR運転免許証・運転経歴証明書の場合、本人確認書類をバックアップ
        const identificationDocument1ImagesBackUp = {
            identificationDocument1Images: this.state.submitData.hasLicense === HasLicense.HAS_NOT_LICENSE
                && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES ?
                this.state.submitData.identificationDocument1Images : undefined
        };

        const options = {
            component: 'AgentCheckApplyComponentHolder',
            process: -1,
            clear: false,
            submitData: {
                ...this.state.copySubmitData,
                ...this.state.confirmPageChanges,
                ...imgBackup,
                ...identificationDocument1ImagesBackUp,
                isModify: this.state.submitData.isModify,
                // OCR（本人のみ）の期限表示は本人確認上で表示する。copySubmitDataにのデータが古いので、最新のデータを本人確認チャットに渡す
                identificationDocument1ExpiryDate: this.state.submitData.identificationDocument1ExpiryDate,
                identificationDocument1ExpiryDateText: this.state.submitData.identificationDocument1ExpiryDateText,
                hasDriversCareerLicense: this.state.submitData.hasDriversCareerLicense
            }
        };
        const modal = this.modalCtrl.create(ChatComponent, {
            options,
            isCurrentPage: true,
            currentTitle: this.labels.confirm.identityDocumentConfirm.table.title5
        }, {
            cssClass: 'full-modal'
        });
        const backup = Object.assign(new SubmitEntity(), this.state.submitData);

        modal.onDidDismiss((state: any) => {
            // 戻るボタン及び修正チャット完了時、有効期限のクリア判別フラグを初期化する。
            this.action.setModifyExpiryDateExists(false);
            if (state && state !== COMMON_CONSTANTS.DIMISS_CLOSE_VALUE) {
                // 本人確認画面が終わったら、maskingチェックボックスをリセット
                this.clearMaskingCheckBox();
                // 運転経歴証明書の場合は、setStateData内でクリア処理させる
                this.action.setStateData(state);
                // 運転免許証の場合のクリア処理
                if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE
                    && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.NO) {
                    this.action.setStateSubmitDataValue({ name: 'identificationDocument1Images', value: undefined });
                }
                // 最新の写真によってマスキング未確認データをセットする
                this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.DOCUMENT);
                // チャットフロー上で「申込内容確認へ戻る」ボタンが選択された場合、申込画面へ戻る
                if (state.submitData.continueOrBackToConfirm === ContinueOrBackToConfirm.BACK_TO_CONFIRM) {
                    this.backToConfirm();
                }
            } else {
                this.state.submitData = backup;
            }
        });

        return modal.present();
    }

    /**
     * 確認書類の写真だけを撮り直す
     *
     * @param {string} type
     * @memberof AccountComponent
     */
    public onReTakeIdentityDocument(params: { type: string, imgDocumentName: string }) {
        const config: any = {
            name: 'reimg',
            currentTitle: this._labels.confirm.reTakeDocument,
            pageIndex: 0,
            isCurrentPage: true
        };

        // OCR2枚
        if (params.type === LicensePhotoType.CARD_FRONT_AND_BACK) {
            config.startOrder = 60;
        }

        // OCR1枚
        if (params.type === LicensePhotoType.CARD_FRONT) {
            config.startOrder = 60;
            config.endOrder = 80;
        }

        const modal = this.modalCtrl.create(CommonBusinessChatComponent, {
            businessType: CommonBusinessType.ReImg,
            ...config
        }, {
            cssClass: 'full-modal'
        });
        modal.present();
        modal.onDidDismiss((data) => {
            // 「戻る」以外によってダイアログを閉じる場合
            if (data !== 'close') {
                if (params.type === LicensePhotoType.CARD_FRONT_AND_BACK) {
                    // OCR2枚。免許
                    this.action.editSomeDataInSubmitData(undefined,
                        'agentCardImageFront',
                        data.identityDocument[0]);
                    this.action.editSomeDataInSubmitData(undefined,
                        'agentCardImageBack',
                        data.identityDocument[1]);
                    this.action.resetSpecialNotMaskingConfirmImages('agentCardImageFront');
                    this.action.resetSpecialNotMaskingConfirmImages('agentCardImageBack');
                } else if (params.type === LicensePhotoType.CARD_FRONT) {
                    // OCR1枚
                    this.action.editSomeDataInSubmitData(undefined,
                        'agentCardImageFront',
                        data.identityDocument[0]);
                    this.action.resetSpecialNotMaskingConfirmImages('agentCardImageFront');
                } else {
                    // OCR以外の書類
                    // imgDocumentNameによって特定な写真を入れ替わる
                    this.action.editSomeDataInSubmitData(undefined,
                        params.imgDocumentName,
                        data.identityDocument);

                    this.action.resetSpecialNotMaskingConfirmImages(params.imgDocumentName);
                }

                this.clearMaskingCheckBox();
            }
        });
    }

    /**
     * 入力チェック結果を返す
     */
    public get isNextButtonDisable(): boolean {
        return !(this.state.submitData.receptionNumber && /\S{3}/.test(this.state.submitData.receptionNumber))
            || (this.agentConfirmMethodComponent &&  // 代理人確認方法コンポが存在
                this.agentConfirmMethodComponent.isShowCheckboxBlock() && // 表示写真が存在する
                !this.state.checkboxStatus.isAgentAllMaskingStatus); // マスキングチェックボックスを未チェック
    }

    /**
     * 画像をクリックしたら画像修正モーダル開き
     *
     * @param {{ index: number, fieldName: string, value: string }} data
     * @memberof AccountComponent
     */
    public onImageMaskingComplete(data: { index: number, fieldName: string, value: string }) {
        this.action.editSomeDataInSubmitData(data.index, data.fieldName, data.value);
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.action.modifyCheckboxStatus(checboxItem);
    }

    public onMaskingConfirmEmmiterHandler(imageInfo: { documentName: string, index: number }) {
        this.action.removeNotMaskingConfirmImages(imageInfo);
    }

    // click 申込内容確認へ戻る button
    public backConfirmClick() {
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    // 申込画面に戻るので、マスキング未確認オブジェクトをクリア
                    this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.CLEAR);
                    this.saveOperationLog(this.labels.logging.AccountConfirm.backConfirmButton);
                    this.backToConfirm();
                }
            }
        );
    }

    private setLogOptions() {
        this.options = {
            logInfo: {
                screenName: this.logging.getConfirmPageScreenName(this.state.submitData, true),
                yamlId: undefined,
                yamlOrder: undefined,
            }
        };
    }

    private clearMaskingCheckBox() {
        // 本人確認画面が終わったら、maskingチェックボックスをリセット
        if (this.state.checkboxStatus.isAllMaskingStatus) {
            this.action.modifyCheckboxStatus(MaskingCheckboxName.MASKING_CHECKBOX_NAME);
        }
        if (this.state.checkboxStatus.isAgentAllMaskingStatus) {
            this.action.modifyCheckboxStatus(MaskingCheckboxName.AGENT_MASKING_CHECKBOX_NAME);
        }
    }

    private backToConfirm() {
        this.clearConfirmPageInfo();
        this.navCtrl.setRoot(BsdAgentConfirmComponent)
            .then(() => this.action.resetSubmitData());
    }

    private clearConfirmPageInfo() {
        this.action.clearConfirmPageInfo();
    }
}
