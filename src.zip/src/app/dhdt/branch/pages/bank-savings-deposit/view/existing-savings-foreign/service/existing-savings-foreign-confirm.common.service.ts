import { Injectable, Injector } from '@angular/core';
import { LabelService } from 'adep/services';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';

export enum ExistingSavingsForeignConfirmType {
    NAME_JAPANESE = 'ExistingSavingsForeign_NAME_JAPANESE',
    DATE_BIRTH_JAPANESE = 'ExistingSavingsForeign_DATE_BIRTH_JAPANESE',
    GENDER_JAPANESE = 'ExistingSavingsForeign_GENDER_JAPANESE',
    ADDRESS_JAPANESE = 'ExistingSavingsForeign_ADDRESS_JAPANESE',
    TELEPHONE_NUMBER_JAPANESE = 'ExistingSavingsForeign_TELEPHONE_NUMBER_JAPANESE',
    OCCUPATION_JAPANESE = 'ExistingSavingsForeign_OCCUPATION_JAPANESE',
    JOB_TITLE_JAPANESE = 'ExistingSavingsForeign_JOB_TITLE_JAPANESE',
    GENERAL_NAME_JAPANESE = 'ExistingSavingsForeign_GENERAL_NAME_JAPANESE',
    DATE_RESIDENCE_JAPANESE = 'ExistingSavingsForeign_DATE_RESIDENCE_JAPANESE',
    EXPIRATION_DATE_JAPANESE = 'ExistingSavingsForeign_EXPIRATION_DATE_JAPANESE',
    CERTIFICATE_PERMANENT_RESIDENT_JAPANESE = 'ExistingSavingsForeign_CERTIFICATE_PERMANENT_RESIDENT_JAPANESE',
    DATE_VALIDITY_JAPANESE = 'ExistingSavingsForeign_DATE_VALIDITY_JAPANESE',
    AMERICAN_EXPIRATION_DATE_PASSPORT_JAPANESE = 'ExistingSavingsForeign_AMERICAN_EXPIRATION_DATE_PASSPORT_JAPANESE',
    ESTABLISHMENT_ACCOUNT = 'ExistingSavingsForeign_AMERICAN_ACCOUNT_ESTABLISHMENT',
    PASS_CODE = 'ExistingSavingsForeign_PASS_CODE'
}

@Injectable()
export class ExistingSavingsForeignConfirmCommonService {
    private params: Map<string, any>;
    private action: SavingsAction;
    private principalPageIndex: number = 97;
    private residenceCardPageIndex: number = 100;
    private specialPermanentPageIndex: number = 101;
    private usArmyPageIndex: number = 102;
    private labels: any;

    constructor(private injector: Injector) {
        this.action = injector.get(SavingsAction);
        this.params = new Map();
        this.labels = injector.get(LabelService).labels;
    }

    public loadConfirmTemplate() {
        this.action.loadConfirmPageTemplate('chat-flow-def-foreigner-principal-confirm.yml', this.principalPageIndex);
        this.action.loadConfirmPageTemplate('chat-flow-def-foreigner-residence-card-confirm.yml', this.residenceCardPageIndex);
        this.action.loadConfirmPageTemplate('chat-flow-def-foreigner-special-permanent-confirm.yml', this.specialPermanentPageIndex);
        this.action.loadConfirmPageTemplate('chat-flow-def-foreigner-us-army-confirm.yml', this.usArmyPageIndex);
    }

    public getShowChatPrincipalParams() {
        const params: Map<string, any> = new Map();
        // 性別
        params.set(ExistingSavingsForeignConfirmType.GENDER_JAPANESE,
        {
            startOrder: 1, endOrder: 1, name: 'gender',
            currentTitle: this.labels.foreignModify.genderJapanese, pageIndex: this.principalPageIndex
        });
        // 電話番号
        params.set(ExistingSavingsForeignConfirmType.TELEPHONE_NUMBER_JAPANESE,
        {
            startOrder: 100, endOrder: 140, name: 'mobilePhoneNo',
            currentTitle: this.labels.foreignModify.telephoneNumberJapanese, pageIndex: this.principalPageIndex
        });
        // ご職業
        params.set(ExistingSavingsForeignConfirmType.OCCUPATION_JAPANESE,
        {
            startOrder: 30, endOrder: 39, name: 'occBusiness',
            currentTitle: this.labels.foreignModify.occupationJapanese, pageIndex: this.principalPageIndex
        });
        // お勤め先名称
        params.set(ExistingSavingsForeignConfirmType.JOB_TITLE_JAPANESE,
        {
            startOrder: 9, endOrder: 11, name: 'workPlace',
            currentTitle: this.labels.foreignModify.jobTitleJapanese, pageIndex: this.principalPageIndex
        });
        // 通学先名称
        params.set(ExistingSavingsForeignConfirmType.GENERAL_NAME_JAPANESE,
        {
            startOrder: 9, endOrder: 13, name: 'schoolName',
            currentTitle: this.labels.foreignModify.generalNameJapanese, pageIndex: this.principalPageIndex
        });
        // 口座開設目的
        params.set(ExistingSavingsForeignConfirmType.ESTABLISHMENT_ACCOUNT,
        {
            startOrder: 14, endOrder: 14, name: 'accountOpeningPurpose',
            currentTitle: this.labels.foreignModify.accountEstablishment, pageIndex: this.principalPageIndex
        });
        // キャッシュカード暗証番号
        params.set(ExistingSavingsForeignConfirmType.PASS_CODE,
        {
            startOrder: 16, endOrder: 16, name: 'passcode',
            currentTitle: this.labels.foreignModify.passCode, pageIndex: this.principalPageIndex
        });
        return params;
    }

    public getShowChatParams(code: any) {
        const params: Map<string, any> = new Map();
        // お名前
        params.set(ExistingSavingsForeignConfirmType.NAME_JAPANESE,
        {
            startOrder: 1, endOrder: 4, name: 'nameKanji',
            currentTitle: this.labels.foreignModify.nameJapanese, pageIndex: this.residenceCardPageIndex
        });
        // 生年月日
        params.set(ExistingSavingsForeignConfirmType.DATE_BIRTH_JAPANESE,
        {
            startOrder: 10, endOrder: 10, name: 'birthdate',
            currentTitle: this.labels.foreignModify.dateBirthJapanese, pageIndex: this.residenceCardPageIndex
        });
        // ご住所
        params.set(ExistingSavingsForeignConfirmType.ADDRESS_JAPANESE,
        {
            startOrder: 250, endOrder: 25771, name: 'zipCode',
            currentTitle: this.labels.foreignModify.addressJapanese, pageIndex: this.residenceCardPageIndex
        });
        if (code === '01') {
            // 在留カードー許可年月日
            params.set(ExistingSavingsForeignConfirmType.DATE_RESIDENCE_JAPANESE,
                {
                    startOrder: 500, endOrder: 500, name: 'permissionLapsedPeriod',
                    currentTitle: this.labels.foreignModify.dateResidenceJapanese, pageIndex: this.residenceCardPageIndex
                });
            // 在留カードー在留許可満了日
            params.set(ExistingSavingsForeignConfirmType.EXPIRATION_DATE_JAPANESE,
            {
                startOrder: 600, endOrder: 26106, name: 'residenceExpirationDate',
                currentTitle: this.labels.foreignModify.expirationDateJapanese, pageIndex: this.residenceCardPageIndex
            });
        } else  if (code === '02') {
            // 特別永住者証明書ー有効期間到来日
            params.set(ExistingSavingsForeignConfirmType.DATE_VALIDITY_JAPANESE,
            {
                startOrder: 500, endOrder: 26106, name: 'effectiveDate',
                currentTitle: this.labels.foreignModify.certificatePermanentResidentJapanese, pageIndex: this.specialPermanentPageIndex
            });
        } else  if (code === '03') {
            // 米軍ID有効期限
            params.set(ExistingSavingsForeignConfirmType.DATE_VALIDITY_JAPANESE,
            {
                startOrder: 500, endOrder: 26106, name: 'effectiveDate',
                currentTitle: this.labels.foreignModify.dateValidityJapanese, pageIndex: this.usArmyPageIndex
            });
            // パスポート有効期限
            params.set(ExistingSavingsForeignConfirmType.AMERICAN_EXPIRATION_DATE_PASSPORT_JAPANESE,
            {
                startOrder: 600, endOrder: 600, name: 'passPortRemainingPeriod',
                currentTitle: this.labels.foreignModify.americanExpirationDatePassportJapanese, pageIndex: this.usArmyPageIndex
            });
        }

        return params;
    }
}
