import { Component, NgZone, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import {
    ConfirmPageCommonService
} from 'dhdt/branch/pages/bank-savings-deposit/service/confirmpage.common.service';
import { SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { CompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/completion.component';
import {
    ExistingSavingsForeignConfirmCommonService
} from 'dhdt/branch/pages/bank-savings-deposit/view/existing-savings-foreign/service/existing-savings-foreign-confirm.common.service';
import {
    AccountType, Age, ApplyBC, ApplyBusinessType, DirectApplyExpectation,
    ForeignResidenceCode,
    ReferenceFlg, SsnWrite
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardChatComponent } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat.component';
import { CreditCardInitConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-initconfirm.component';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { PasscodeValidator } from 'dhdt/branch/shared/utils/ passcode-validator';
import { ConfirmUtil } from 'dhdt/branch/shared/utils/confirm-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController, NavParams } from 'ionic-angular';
/**
 * 申込内容確認（外国人申込用）
 */
@Component({
    selector: 'existing-savings-foreign-initconfirm-component',
    templateUrl: 'existing-savings-foreign-initconfirm.component.html'
})

export class ExistingSavingsForeignInitConfirmComponent extends BaseComponent implements OnInit {
    public state: SavingsState;
    public saveShowChats: any = {};
    public confirmPageCommonParams = new Map<string, any>();
    public confirmPageCommonParamsForOpenStore: Map<string, any> = null;
    public confirmPageParams: Map<string, any> = null;
    public passwordValid: boolean = true;
    public changeHolderMobileNoFlag: boolean = false;
    public isCareerShow: boolean = false;
    public isSignShow: boolean = false;
    public isW9Show: boolean = false;
    public isFatcaShow: boolean = false;
    public editedList: any = {};

    constructor(
        private action: SavingsAction,
        private store: SavingsStore,
        private modalCtrl: ModalController,
        private navCtrl: NavController,
        private logging: LoggingService,
        private loginStore: LoginStore,
        private zone: NgZone,
        private confirmPageCommonService: ExistingSavingsForeignConfirmCommonService,
        private confirmPageCommonServiceForOpenStore: ConfirmPageCommonService,
        private params: NavParams,
        private confirmUtils: ConfirmUtil
    ) {
        super();
        this.state = this.store.getState();
    }

    public ngOnInit() {

        this.confirmPageCommonService.loadConfirmTemplate();
        this.confirmPageCommonParams = this.confirmPageCommonService.getShowChatPrincipalParams();
        this.confirmPageCommonServiceForOpenStore.loadConfirmTemplate();
        this.confirmPageCommonParamsForOpenStore = this.confirmPageCommonServiceForOpenStore.getShowChatParams();
        this.confirmPageParams = this.confirmPageCommonService.getShowChatParams(this.state.submitData.identificationDocType);
        this.state.showConfirm.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
        this.saveApplyBCAndBCBak(this.params.get('ifApplyBC'), this.params.get('ifApplyBCBak'));
        // OCR PARAMTER
        this.action.setStateSubmitDataValue({
            name: 'isJapanLive',
            value: '1'
        });
        this.isCareerShow = true;
        this.isSignShow = true;
        this.isW9Show = this.state.submitData.isSsnWrite === SsnWrite.YES;
        this.isFatcaShow = this.state.submitData.isSsnWrite && this.state.submitData.isSsnWrite !== SsnWrite.YES;

        this.getHolderZipCode();
        this.action.setStateSubmitDataValue({
            name: 'accountType',
            value: '14'
        });
        this.action.setStateSubmitDataValue({
            name: 'foreignFlg',
            value: true
        });
        this.action.setStateSubmitDataValue({
            name: 'nameKanji',
            value: this.getShowChatsText('holderName') === this.labels.common.skipjp
                ? null : this.getShowChatsText('holderName')
        });
        this.action.setStateSubmitDataValue({
            name: 'nameKana',
            value: this.getShowChatsText('nameKana')
        });
        this.action.setStateSubmitDataValue({
            name: 'nameAlphabet',
            value: this.getShowChatsText('nameAlphabet')
        });
        this.action.setStateSubmitDataValue({
            name: 'zipCode',
            value: this.state.submitData.firstZipCode + this.state.submitData.lastZipCode
        });

        this.action.getSystemTime().subscribe((time) => {
            this.action.setStateSubmitDataValue({
                name: 'systemTime',
                value: time
            });
        });

    }

    /**
     * ・BC修正ボタンによってBC申込チャットが完了時にBC申込Viewから呼ばれる
     *
     * @param {*} data
     * @memberof ExistingSavingsForeignInitConfirmComponent
     */
    public receiveBCParamByModify(data: any) {
        // bc申込状態を保存する
        this.saveApplyBCAndBCBak(data.ifApplyBC, data.ifApplyBCBak);
    }

    public onModifying(data) {
        Object.keys(data).forEach((key) => {
            this.action.setStateSubmitDataValue({
                name: key,
                value: data[key]
            });
        });
    }

    public onModifyingBcApply(data) {
        // BC複合申込を変更した場合、キャッシュカード申込欄も編集済み表示にするため
        // 確認画面の子componentで共通のeditedListをtrueに設定
        this.editedList.bcApply = true;
        // 申込チャットで「申し込まない」を選び、修正によって「申し込む」を選んだ場合
        if (data.ifApplyBC === ApplyBC.YES
            && this.state.submitData.ifApplyBCBak !== ApplyBC.YES) {
            this.onModifying(data);

            this.navCtrl.push(CreditCardChatComponent,
                {
                    submitData: {
                        ...this.confirmUtils.processSubmitDataForeignerBC(this.state, this.loginStore.getState()),
                        referenceFlg: ReferenceFlg.Confrim, // 遷移元フラグ
                        accountType: AccountType.ORDINARY_DEPOSIT // 申し込みチャットからBC遷移と一致するために
                    },
                    tabletApplyId: this.loginStore.getState().tabletApplyId,
                    pageIndex: 0,
                    accountType: this.state.submitData.accountType,
                    customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                    cardInfo: this.state.submitData.cardInfo,
                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                }
            );
        } else {
            this.onModifying(data);
        }
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.zone.run(() => this.action.modifyCheckboxStatusForeign(checboxItem));
    }

    // 18以上の場合は、BC申込欄を表示
    public get isBcShow() {
        // 特別永住者証明書 or 在留カードの区分が永住者
        let isRightDoc = false;
        if (
            this.state.submitData.identificationDocType === '02' ||
            (
                this.state.submitData.identificationDocType === '01' &&
                this.state.submitData.residenceStatus === ForeignResidenceCode.PermanentResident
            )
        ) {
            isRightDoc = true;
        }
        // 18未満
        const isBlow18 = !InputUtils.validateAge(this.state.submitData.birthdate, Age.Age_18,
            this.state.submitData.tabletStartDate);
        return !isBlow18 && isRightDoc ? true : false;
    }

    public get bottonTitle(): string {
        return this.state.submitData.ifApplyBC === ApplyBC.YES ?
            this.labels.change.confirm.button : this.labels.confirm.confirmButton;
    }

    public get topMessage(): string {
        return this.state.submitData.ifApplyBC === ApplyBC.YES ?
            this.labels.student.initDesc3 : this.labels.student.initDesc1;
    }

    /**
     * footer button disable
     */
    public get disableFooterButton() {
        const checkboxTotalValid = this.checkboxValid();
        const passwordValid = !this.getCardPwdAndConfirmPwdError();
        const kanaKanjiOK = this.checkContainKanjiValidation();
        return checkboxTotalValid && passwordValid && kanaKanjiOK;

    }

    /**
     * ページのタイトル
     */
    public get headerTitle(): string {
        if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
            return this.labels.existingSavings.title;
        } else if (this.state.submitData.accountType === AccountType.EXISTING_STORAGE) {
            return this.labels.existingStorage.title;
        } else if (this.state.submitData.accountType === AccountType.FOREIGN_SAVINGS) {
            return this.labels.existingSavings.title;
        }
    }

    // 郵便番号
    public getHolderZipCode() {
        if (this.state.submitData.holderAddressPrefecture && this.state.submitData.holderAddressCountyUrbanVillage) {
            this.action.getHolderZipCode(
                this.state.submitData.holderAddressPrefecture,
                this.state.submitData.holderAddressCountyUrbanVillage,
                this.state.submitData.getHolderAddressStreetName());
        } else {
            this.action.setDefaultZipCode();
        }
    }

    /**
     * click 'お申込み' button
     */
    public moveToNextPage() {
        this.action.setCustomerApplyEndDate();
        this.action.setStateSubmitDataValue({
            name: 'isModify',
            value: '2'
        });
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.action.setStateSubmitDataValue({
                name: 'holderMobileNo',
                value: this.state.submitData.mobilePhoneNo ? this.state.submitData.mobilePhoneNo : ''
            });
            this.action.setStateSubmitDataValue({
                name: 'holderTelephoneNo',
                value: this.state.submitData.otherPhoneNo ? this.state.submitData.otherPhoneNo : ''
            });
            this.navCtrl.push(CreditCardInitConfirmComponent,
                {
                    submitData: this.state.submitData
                });
            const info = {
                applyBusinessCategory: ApplyBusinessType.BANKCARD_COMPOSIT, // 普通預金口座開設（BC複合）
                tabletApplyId: this.loginStore.getState().tabletApplyId
            };
            this.action.updateApplyBizCategory(info);
        } else {
            const modal = this.modalCtrl.create(
                ModalPasswordComponent,
                {
                    data: {
                        text: this.labels.confirm.passwordModal.text,
                        subText: this.labels.confirm.passwordModal.subText,
                        units: 4,
                        errorMessage: this.labels.confirm.passwordModal.errorMessage,
                        needConfirm: true,
                        inputPassword: this.state.submitData.firstPwd4bits
                    }
                },
                { cssClass: 'settings-modal', enableBackdropDismiss: false });
            modal.onDidDismiss((value) => {
                if (value) {
                    this.navCtrl.push(CompletionComponent);
                }
            });
            modal.present();
        }
        this.saveOperationLog();
    }

    // 暗証番号 emitter
    public passwordOKEmitterHandler(flag: boolean) {
        // this.passwordOK = !this.getCardPwdAndConfirmPwdError();
    }

    /**
     * password valid
     * @param passwordValid  password valid result
     */
    public passwordEmmiterHandler(passwordValid: boolean) {
        this.passwordValid = passwordValid;
    }

    /**
     * set password value
     * @param value {name: passwordName, value: password}
     */
    public passwordValueEmmiterHandler(value) {
        const passwordValue = [{
            key: value.name,
            value: value.value
        }];
        this.action.setStateSubmitDataValue(passwordValue);
    }

    /**
     * 変更項目を設定
     * @param data 変更項目
     */
    public handleItemChangedEmitter(data) {
        this.action.setStateSubmitDataValue([
            {
                key: 'holderName',
                value: data.holderNameKanji,
            }
        ]);
    }

    public get isNoteMessageHide(): boolean {
        return !this.state.checkboxStatusForeign.isAntisocialStatus &&
            this.state.checkboxStatusForeign.isJapaneseResidentStatus &&
            this.state.checkboxStatusForeign.isRegulationStatus &&
            (this.isCareerShow ? !this.state.checkboxStatusForeign.isForeignPulicFiguresSatus : true) &&
            this.state.checkboxStatusForeign.isTransactionStatus;
    }

    // get キャッシュカードデザイン show text
    public getShowChatsText(name: string): string {
        if (!this.saveShowChats || !this.saveShowChats[name] || !this.saveShowChats[name].answer) {
            return '';
        }

        return this.saveShowChats[name].answer.text;
    }

    public refsShowChart() {
        this.state.showConfirm.forEach((item) => {
            if (item.type !== 'judge') {
                this.saveShowChats[item.name] = item;
            }
        });
    }
    public refsStateSubmitData() {
        this.action.setStateSubmitDataValue({ name: 'workPlace', value: null });
        this.action.setStateSubmitDataValue({ name: 'attendingSchoolName', value: null });
    }

    public onChangeOpenStore(data) {
        this.action.changeOpenStore(data);
    }

    public refsChangeHolderMobileNoFlag(flag: boolean) {
        this.changeHolderMobileNoFlag = flag;
    }

    /**
     * show checkbox valid
     */
    private checkboxValid(): boolean {
        const preconditionsOK = this.isNoteMessageHide;

        const confirmationCheckedOK = this.state.submitData.directApplyExpectation === DirectApplyExpectation.APPLY
            && this.state.submitData.showDirectApply ?
            this.state.checkboxStatus.confirmationStatus : true;
        const checkboxTotalValid = confirmationCheckedOK && preconditionsOK;
        return checkboxTotalValid;
    }

    /**
     * add operation log
     */
    private saveOperationLog() {
        const logInfo: IOperationInfo = {
            screenName: this.logging.getConfirmPageScreenName(this.state.submitData, false),
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: this._labels.logging.InfoComfirm.ApplyButton,
        };
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }

    private getCardPwdAndConfirmPwdError(): boolean {
        let result = !this.getPasswordValidation(this.state.submitData.firstPwd4bits);
        if (!result && this.state.submitData.directApplyExpectation === '1') {
            result = !this.getPasswordValidation(this.state.submitData.firstPwd6bits);
        }
        return result;
    }

    private getPasswordValidation(password: string): boolean {
        const validate = PasscodeValidator.validation(
            password,
            {
                gregorian: this.state.submitData.birthdate,
                japan: this.state.submitData.birthdateText
            },
            [
                this.state.submitData.getHolderMobileNo(),
                this.state.submitData.getHolderTelephoneNo(),
            ]);
        return validate;
    }

    /**
     * 「カナ氏名」「カナ住所」に漢字が混在している場合は、
     * 申込内容確認画面の「申込をする」ボタンが非活性になること
     */
    private checkContainKanjiValidation(): boolean {
        const holderName = this.state.submitData.nameKana;
        const holderAddress = this.state.submitData.holderAddressPrefectureFuriKana
            + this.state.submitData.holderAddressCountyUrbanVillageFuriKana
            + this.state.submitData.getHolderAddressStreetNameFuriKana()
            + this.state.submitData.holderAddressHouseNumberFuriKana;

        let result = StringUtils.validateNameKana(holderName);
        if (result) {
            result = StringUtils.validateAddressKana(holderAddress);
        }
        return result;
    }

    /**
     * 複数箇所に使われるので、共通化する
     *
     * @private
     * @param {string} ifApplyBC
     * @param {string} ifApplyBCBak
     * @memberof ExistingSavingsInitConfirmComponent
     */
    private saveApplyBCAndBCBak(ifApplyBC: string, ifApplyBCBak: string) {
        if (ifApplyBC) {
            this.action.setStateSubmitDataValue({
                name: 'ifApplyBC',
                value: ifApplyBC
            });
        }
        if (ifApplyBCBak) {
            this.action.setStateSubmitDataValue({
                name: 'ifApplyBCBak',
                value: ifApplyBCBak
            });
        }
    }

}
