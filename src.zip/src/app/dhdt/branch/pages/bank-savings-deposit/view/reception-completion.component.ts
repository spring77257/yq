import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { DeviceService } from 'dhd/common/services/device.service';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    AccountType, COMMON_CONSTANTS
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { ExistingReserveState, ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsState, ExistingSavingsStore } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { LossReissueFindingAction } from 'dhdt/branch/pages/loss-reissue-finding/action/loss-reissue-finding.action';
import { LossReissueFindingState, LossReissueFindingStore } from 'dhdt/branch/pages/loss-reissue-finding/store/loss-reissue-finding.store';
import { StudentState, StudentStore } from 'dhdt/branch/pages/student/store/student.store';
import { ModalDigitalComponent } from 'dhdt/branch/shared/components/modal/modal-digital/view/modal-digital.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { LossReissueFindingUtil } from 'dhdt/branch/shared/utils/loss-reissue-finding-util';
import { NavController } from 'ionic-angular';
import { ModalController } from 'ionic-angular/components/modal/modal-controller';
import { CommonBusinessType } from '../../common-business/manager/common-business.manager';
import { CommonBusinessChatComponent } from '../../common-business/view/common-business-chat.component';

@Component({
    selector: 'completion-component',
    templateUrl: 'reception-completion.component.html'
})

/**
 * Completion component(入力完了画面).
 */
export class ReceptionCompletionComponent extends BaseComponent implements OnInit {
    public imgUrl = '';         // バックグラウンド画像Url
    private state: SavingsState;
    private creditCardState: CreditCardState;
    private lossReissueFindingState: LossReissueFindingState;
    private existingReserveState: ExistingReserveState;
    private existingSavingsState: ExistingSavingsState;
    private studentState: StudentState;
    private savingsState: SavingsState;

    private modalInfor = {
        title: this.labels.change.userConfirm,
        subTitle: this.labels.change.inputPassword,
        showInput: 'two-inputs',
        tabletApplyId: undefined
    };

    constructor(
        private modalCtrl: ModalController,
        private navCtrl: NavController,
        private action: SavingsAction,
        private store: SavingsStore,
        private audioService: AudioService,
        private logging: LoggingService,
        private creditCardStore: CreditCardStore,
        private lossReissueFindingStore: LossReissueFindingStore,
        private existingReserveStore: ExistingReserveStore,
        private existingSavingsStore: ExistingSavingsStore,
        private loginStore: LoginStore,
        private deviceService: DeviceService,
        private studentStore: StudentStore,
        private savingsStore: SavingsStore,
        private lossReissueFindingUtil: LossReissueFindingUtil,
    ) {
        super();
        this.state = this.store.getState();
        this.creditCardState = this.creditCardStore.getState();
        this.lossReissueFindingState = this.lossReissueFindingStore.getState();
        this.existingReserveState = this.existingReserveStore.getState();
        this.existingSavingsState = this.existingSavingsStore.getState();
        this.studentState = this.studentStore.getState();
        this.savingsState = this.savingsStore.getState();
    }

    public ngOnInit(): void {
        this.imgUrl = COMMON_CONSTANTS.FLOW_TYPE_INIT_CONFIRM;
    }

    /**
     * View did enter
     */
    public ionViewDidEnter() {
        this.audioService.subject.next(true);
    }

    public presentModal() {
        this.saveOperationLog();

        this.modalInfor.tabletApplyId = this.loginStore.getState().tabletApplyId;

        const modal = this.modalCtrl.create(
            ModalDigitalComponent,
            { data: this.modalInfor },
            { cssClass: 'two-inputs' }
        );
        modal.onDidDismiss((success) => {
            if (success) {
                const config: any = {
                    currentTitle: this.labels.reception.clerkConfirm.modaltitle,
                    pageIndex: 0,
                    isCurrentPage: true,
                    data: {
                            ...this.state.submitData,
                            existing: this.state.duplicateAccountInfos, // 同一名義人リストを表示するため
                            customerSearchStatus: this.state.customerSearchStatus, // 同一名義人リストを表示するため
                            account : {
                                holderName: this.state.submitData.firstNameKanaReception +
                                COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKanaReception
                            }, // 同一名義人リストを表示するため
                          }
                };

                const modal = this.modalCtrl.create(CommonBusinessChatComponent, {
                    businessType: CommonBusinessType.ReceptionClerkConfirm,
                    ...config
                }, {
                    cssClass: 'full-modal'
                });
                modal.onDidDismiss((val) => {
                    if (val === 'close') {
                        this.navCtrl.pop();
                    } else {
                        this.passParameters(val);
                        // 正常終了、口座開設チャットへ進む
                        this.navCtrl.pop().then(
                            () => {
                                const controller = this.navCtrl.getActive();
                                controller.instance.getCurrentComponent().onComplete();
                            }
                        );

                    }
                });

                modal.present();
            }
        });
        modal.present();
    }

    // headerTitle
    public get headerTitle(): string {
        return '普通預金口座開設受付';
    }

    private passParameters(modalSubmitData) {
        if (modalSubmitData) {
            this.action.setStateSubmitDataValue({
                name: 'openingAccountPattern',
                value: modalSubmitData.openingAccountPattern
            });

            // 受付行員認証チャットで決めた 顧客番号
            if (modalSubmitData.customerId) {
                this.action.setStateSubmitDataValue({
                    name: 'customerId',
                    value: modalSubmitData.customerId
                });
            }
            // 口座開設CIFの顧客番号
            if (modalSubmitData.openAccountCid) {
                this.action.setStateSubmitDataValue({
                    name: 'openAccountCid',
                    value: modalSubmitData.openAccountCid
                });
            }
            // 口座開設CIFの本人確認コード
            if (modalSubmitData.openAccountIdentiCode) {
                this.action.setStateSubmitDataValue({
                    name: 'openAccountIdentiCode',
                    value: modalSubmitData.openAccountIdentiCode
                });
            }
            // 受付行員認証チャットで決めた 新規扱いフラグ
            if (modalSubmitData.isNewCustomerFlg) {
                this.action.setStateSubmitDataValue({
                    name: 'isNewCustomerFlg',
                    value: modalSubmitData.isNewCustomerFlg
                });
            }
            // パターンCフラグ（空CIF）
            if (modalSubmitData.openingAccountPatternC) {
                this.action.setStateSubmitDataValue({
                    name: 'openingAccountPatternC',
                    value: modalSubmitData.openingAccountPatternC
                });
            }
            // 受付行員認証チャットで判断した　諸届変更有りかどうか
            if (modalSubmitData.isNameAddressTelDiff) {
                this.action.setStateSubmitDataValue({
                    name: 'isNameAddressTelDiff',
                    value: modalSubmitData.isNameAddressTelDiff
                });
            }
            // 受付行員認証チャットで決めた　氏名差分
            if (modalSubmitData.isHaveNameDif) {
                this.action.setStateSubmitDataValue({
                    name: 'isHaveNameDif',
                    value: modalSubmitData.isHaveNameDif
                });
            }
            // 受付行員認証チャットで決めた　住所差分
            if (modalSubmitData.isHaveAddressDif) {
                this.action.setStateSubmitDataValue({
                    name: 'isHaveAddressDif',
                    value: modalSubmitData.isHaveAddressDif
                });
            }
            // 受付行員認証チャットで決めた　電話差分
            if (modalSubmitData.isHaveTelDif) {
                this.action.setStateSubmitDataValue({
                    name: 'isHaveTelDif',
                    value: modalSubmitData.isHaveTelDif
                });
            }

            // 受付行員認証チャットで選択した　カードスワイプ店舗番号
            if (modalSubmitData.selectTenpoCode) {
                this.action.setStateSubmitDataValue({
                    name: 'selectTenpoCode',
                    value: modalSubmitData.selectTenpoCode
                });
            }
            // 受付行員認証チャットで選択した　カードスワイプ店舗名
            if (modalSubmitData.selectTenpoName) {
                this.action.setStateSubmitDataValue({
                    name: 'selectTenpoName',
                    value: modalSubmitData.selectTenpoName
                });
            }
            // 受付行員認証チャットで選択した　カードスワイプ店舗の顧客番号
            if (modalSubmitData.selectTenpoCustomerId) {
                this.action.setStateSubmitDataValue({
                    name: 'selectTenpoCustomerId',
                    value: modalSubmitData.selectTenpoCustomerId
                });
            }
            if (modalSubmitData.allCifNameDif) {
                this.action.setStateSubmitDataValue({
                    name: 'allCifNameDif',
                    value: modalSubmitData.allCifNameDif
                });
            }
            if (modalSubmitData.allCifAddressDif) {
                this.action.setStateSubmitDataValue({
                    name: 'allCifAddressDif',
                    value: modalSubmitData.allCifAddressDif
                });
            }
            if (modalSubmitData.allCifTelDif) {
                this.action.setStateSubmitDataValue({
                    name: 'allCifTelDif',
                    value: modalSubmitData.allCifTelDif
                });
            }
            if (modalSubmitData.receptionCheckNameDiffResult) {
                this.action.setStateSubmitDataValue({
                    name: 'receptionCheckNameDiffResult',
                    value: modalSubmitData.receptionCheckNameDiffResult
                });
            }
            if (modalSubmitData.receptionCheckAddressTelDiffResult) {
                this.action.setStateSubmitDataValue({
                    name: 'receptionCheckAddressTelDiffResult',
                    value: modalSubmitData.receptionCheckAddressTelDiffResult
                });
            }
            if (modalSubmitData.mediumInfos) {
                this.action.setStateSubmitDataValue({
                    name: 'mediumInfos',
                    value: modalSubmitData.mediumInfos
                });
            }
            if (modalSubmitData.holderBirthdateText) {
                this.action.setStateSubmitDataValue({
                    name: 'holderBirthdateText',
                    value: modalSubmitData.holderBirthdateText
                });
            }
            if (modalSubmitData.holderAddressCode) {
                this.action.setStateSubmitDataValue({
                    name: 'holderAddressCode',
                    value: modalSubmitData.holderAddressCode
                });
            }
            if (modalSubmitData.confirmPurpose) {
                this.action.setStateSubmitDataValue({
                    name: 'confirmPurpose',
                    value: modalSubmitData.confirmPurpose
                });
            }

        }
    }

    /**
     * add operation log
     */
    private saveOperationLog() {
        const logInfo: IOperationInfo = {
            screenName: this._labels.logging.CompletionPage.ScreenName,
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: this._labels.logging.CompletionPage.accountConfirmButton
        };
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }
}
