import { OnDestroy, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ConfirmPageCommonService } from 'dhdt/branch/pages/bank-savings-deposit/service/confirmpage.common.service';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
     AccountType, COMMON_CONSTANTS, HasLicense, PrincipalAgentCategory, RegularOpenPur
    } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ModalDigitalStore } from 'dhdt/branch/shared/components/modal/modal-digital/store/modal-digital.store';
import { SameHolderInquiryEntity } from 'dhdt/branch/shared/entity/same-holder-inquiry.entity';
import { DocumentCategoryService } from 'dhdt/branch/shared/modules/document-category/service/document-category.service';
import { LoadingService, SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { CommitDataProcessUtils } from 'dhdt/branch/shared/utils/commitdata-process-util';
import { PRODUCT_TYPE } from 'dhdt/branch/shared/utils/product-category-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { NavController, NavParams, ViewController } from 'ionic-angular';

/**
 * 行員確認画面の共通ベースコンポネント
 */
export abstract class ConfirmPageBaseComponent extends BaseComponent implements OnInit, OnDestroy {
    protected readonly action: SavingsAction;
    protected readonly store: SavingsStore;
    protected readonly confirmPageCommonService: ConfirmPageCommonService;
    protected readonly commitDataProcessUtils: CommitDataProcessUtils;
    protected readonly loginStore: LoginStore;
    protected readonly modalDigitalStore: ModalDigitalStore;
    protected readonly loadingService: LoadingService;
    protected readonly logging: LoggingService;
    protected readonly categoryService: DocumentCategoryService;

    public state: SavingsState;
    protected _labels;
    public changeHolderMobileNoFlag: boolean = false;
    public isClerkConfirm: boolean = true;
    public submitted: boolean = false;

    public open: boolean = true;
    public saveShowChats: any = {};
    public tabletApplyId: number;
    public confirmPageCommonParams: Map<string, any> = null;

    public showPassbook: boolean = false;
    public isTimeSavings: boolean = false;

    // 同一名義人照会結果
    public sameHolderList: SameHolderInquiryEntity[];

    public insertImageType: string = COMMON_CONSTANTS.InsertImageType.image;
    public insertImageTypeNoFace: string = COMMON_CONSTANTS.InsertImageType.image;
    public accountSelected: boolean = false;    // 既存CIF・口座確認 has been selected
    public duplicateAccountValid: boolean = true;

    constructor(public navCtrl: NavController, public modalService: ModalService,
                public navParam: NavParams, public viewCtrl: ViewController) {
        super();
        this.action = InjectionUtils.injector.get(SavingsAction);
        this.store = InjectionUtils.injector.get(SavingsStore);
        this.confirmPageCommonService = InjectionUtils.injector.get(ConfirmPageCommonService);
        this.commitDataProcessUtils = InjectionUtils.injector.get(CommitDataProcessUtils);
        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.modalDigitalStore = InjectionUtils.injector.get(ModalDigitalStore);
        this.loadingService = InjectionUtils.injector.get(LoadingService);
        this.logging = InjectionUtils.injector.get(LoggingService);
        this.state = this.store.getState();
        const labelService = InjectionUtils.injector.get(LabelService);
        this._labels = labelService.labels;
        this.categoryService = InjectionUtils.injector.get(DocumentCategoryService);
    }

    public ngOnInit() {
        const loadingId = this.loadingService.showLoading(SpinnerType.SHOW);

        this.setSubComponentParameters();
        this.saveShowChatsData();
        this.pushNextPage();
        this.getShowPassbook();
        // get '定期預金' component
        this.getTimeDepositShow();

        this.loadingService.dismissLoading(loadingId);
    }

    public ngOnDestroy(): void {
        this.unregisterSignalHandlers();
    }

    public get headerTitle(): string {
        if (!this.state.submitData.accountType || !this.state.submitData.accountTypeText) {
            return '';
        }
        return this.state.submitData.accountTypeText;
    }

    public changeHolderMobileNoEmitter(value) {
        this.changeHolderMobileNoFlag = value;
    }

    // click 認証する button
    public submit() {
        this.submitted = true;
        this.submitAccountApplyInfo();
    }

    public clearMemory() {
        this.action.clearStore();
    }

    // click 申込内容確認へ戻る
    public clearConfirmPageInfo() {
        this.action.clearConfirmPageInfo();
    }

    public unregisterSignalHandlers() {
        this.store.unregisterSignalHandler(SavingsSignal.SUCCESS_INSERT_INFO);
        this.store.unregisterSignalHandler(SavingsSignal.SET_DUPLICATE_ACCOUNT_INFO);
    }

    public saveShowChatsData() {
        this.state.showConfirm.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
    }

    public get isApplyButtonDisable(): boolean {
        let validationResult = !this.changeHolderMobileNoFlag;

        if (validationResult) {
            validationResult = this.checkInputValidation();
        }

        return !validationResult || !this.duplicateAccountValid;
    }

    /**
     * 重複口座情報をセットする
     * @param event 重複口座情報
     */
    public getDuplicateAccountInfo(event: any) {
        this.store.registerSignalHandler(SavingsSignal.SET_DUPLICATE_ACCOUNT_INFO, () => {
            if (this.accountSelected) {
                this.getDuplicateAccountValid();
            }
        });
        this.action.setDuplicateAccountInfo(event);
    }

    /**
     * handle accountSelectedEmitter
     */
    public handleAccountSelectedEmitter(accountSelected: boolean) {
        this.accountSelected = accountSelected;
        this.accountSelected ? this.getDuplicateAccountValid() : this.duplicateAccountValid = true;
    }

    /**
     * 重複口座情報の有効性をチェックする
     */
    public getDuplicateAccountValid() {
        this.duplicateAccountValid = this.state.submitData.redundantReason ? true : false;
    }

    /**
     * 総合口座文言表示フラグ設定
     */
    public hasComprehensiveDisplay(): boolean {
        if (this.duplicateAccountValid && this.state.submitData.hasComprehensive &&
            (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT ||
             this.state.submitData.accountType === AccountType.TIME_SAVING)) {
            return true;
        }
        return false;
    }

    /**
     * Determines whether the "通帳デザイン" is displayed
     */
    public getShowPassbook() {
        this.showPassbook =
            this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT_CHILDREN ||
            this.state.submitData.selectProductType === PRODUCT_TYPE.LOVE;
    }

    /**
     * get time deposit show
     */
    public getTimeDepositShow() {
        this.isTimeSavings = this.state.submitData.regularPurpos === RegularOpenPur.TIMG_SAVING;
    }

    public abstract processSubmitData(): any;

    public abstract pushNextPage();

    public abstract submitProcessedData(submitData: any);

    /**
     * 顔写真のある本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedEmitter(event?: any) {
        this.insertImageType = event || this.insertImageType;
        this.action.setDocumentType({ name: COMMON_CONSTANTS.InsertDocument.Holder, value: this.insertImageType });
    }

    /**
     * 顔写真のない本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedNoFaceEmitter(event?: any) {
        this.insertImageTypeNoFace = event || this.insertImageTypeNoFace;
        this.action.setDocumentType({ name: COMMON_CONSTANTS.InsertDocument.HolderAdditional, value: this.insertImageTypeNoFace });
    }

    protected submitAccountApplyInfo() {
        const submitData = this.processSubmitData();
        this.submitProcessedData(submitData);
    }

    protected saveOperationLog(value: string) {
        const logInfo: IOperationInfo = {
            screenName: this.logging.getConfirmPageScreenName(this.state.submitData, true),
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: value,
        };
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }

    private setPageInitialData() {
        // 行員登録画面に遷移するとき、入力する行員IDを記録する
        this.action.setBankclerkId(this.modalDigitalStore.getState().bankclerkId);
        // 取次店番を記録する
        this.action.setAgencyBranchInfo(this.loginStore.getState().belongToBranchNo);
        // 受付店を口座開設店として記録する
        this.action.setBranchInfo(this.loginStore.getState().belongToBranchName, this.loginStore.getState().belongToBranchNo);
        // 行員認証開始時間を記録する
        this.action.setBankclerkAuthenticationStartDate();
    }

    private setSubComponentParameters() {
        this.confirmPageCommonService.loadConfirmTemplate();
        this.confirmPageCommonParams = this.confirmPageCommonService.getShowChatParams();

        // 重複口座情報セット
        this.sameHolderList = this.navParam.get('sameHolderList');
    }

    private checkInputValidation(): boolean {
        let validationResult = this.checkIdentityDocumentsValidation();

        if (validationResult && this.state.submitData.holderNoCopyReason) { // コピー徴求ができない理由
            validationResult = StringUtils.validateZenkaku(this.state.submitData.holderNoCopyReason);
        }

        if (validationResult && this.state.submitData.holderIdentityDocumentNoCopyReason) { // コピー徴求ができない理由
            validationResult = StringUtils.validateZenkaku(this.state.submitData.holderIdentityDocumentNoCopyReason);
        }

        return validationResult;
    }

    /**
     * 本人確認書類チェック
     */
    private checkIdentityDocumentsValidation(): boolean {
        if (this.state.submitData.holderIdentityDocumentType) {
            // OCR画像登録
            if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE &&
                this.state.submitData.isAgent === PrincipalAgentCategory.HOLDER) {
                return true;
            }

            // 顔写真のある本人確認の画像登録
            if (this.state.identityDocuments && this.state.identityDocuments.length > 0) {
                return true;
            }

            // 顔写真のある本人確認のテキスト登録
            if (this.state.submitData.holderNoCopyReason || this.state.submitData.holderPublisher ||
                this.state.submitData.holderPublishDate || this.state.submitData.holderSignNo) {
                return true;
            }

            // 顔写真のない本人確認の画像登録
            if (this.state.additionalInfoDocuments && this.state.additionalInfoDocuments.length > 0) {
                return true;
            }

            // 顔写真のない本人確認のテキスト登録
            if (this.state.submitData.holderIdentityDocumentNoCopyReason || this.state.submitData.holderIdentityDocumentPublisher ||
                this.state.submitData.holderIdentityDocumentPublishDate || this.state.submitData.holderIdentityDocumentSignNo) {
                return true;
            }
        }

        return false;
    }
}
