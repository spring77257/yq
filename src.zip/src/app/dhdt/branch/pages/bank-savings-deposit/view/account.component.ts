import { Component, OnInit } from '@angular/core';
import { LabelService } from 'adep/services';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { SubmitEntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsSignal } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { ConfirmPageBaseComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/common/confirm-page-base.component';
import { BsdAgentConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/savings/bsd-agent-confirm.component';
import { CommonBusinessType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessChatComponent } from 'dhdt/branch/pages/common-business/view/common-business-chat.component';
import {
    AccountCategory,
    AccountType, Age, AntiSocietyAnswer, ApplyBC, ApplyBusinessType, CHANGECATEGORY, ClearSavingImagesClickRecordType,
    CodeCategory, COMMON_CONSTANTS, Constants, ContinueOrBackToConfirm,
    ExistingHolderCareerCode, HasBankCard, HasDriversCareerLicense, HasLicense,
    HostResultCode,
    IdentificationCode, IdentificationDocumentCode, IdentificationDocumentMethod, LicensePhotoType,
    MaskingCheckboxName, NameNonConvert, OutStatusText,
    PrincipalAgentCategory, ServiceCategory, SsnHave, SsnWrite
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardChatComponent } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat.component';
import {
    IsBankCardGoldSelected, IsBankCardSelected, IsBankCardSuicaGoldSelected,
    IsBankCardSuicaSelected
} from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-confirm.component';
import { Length } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import {
    ConfirmationRadioButtonOption
} from 'dhdt/branch/shared/components/confirmpage-common/confirmation-radio-button-group/confirmation-radio-button-group.component';
import { FilteringParameterEntity } from 'dhdt/branch/shared/entity/filtering-parameter.entity';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ConfirmUtil } from 'dhdt/branch/shared/utils/confirm-util';
import { CreditCardUtil } from 'dhdt/branch/shared/utils/creditcard-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController, NavParams, ViewController } from 'ionic-angular';

@Component({
    selector: 'account-component',
    templateUrl: 'account.component.html'
})

/**
 * Account component(行員認証画面（本人）).
 */
export class AccountComponent extends ConfirmPageBaseComponent implements OnInit {
    // ログイン button タン押下時の二重リクエスト防止
    public isBacking = false;
    public mailing = false;
    public isW9Show: boolean = false;
    public isFatcaShow: boolean = false;
    public isClerkConfirm: boolean = true;
    public idConfirmTitle: string;
    public isAgent: boolean = false;
    public options: any;
    public bottonTitle: string;
    public topMessage: string;
    public hasBankCard: boolean = false;

    public designOptions: ConfirmationRadioButtonOption[] = [{
        text: this.labels.cardDesign.hope,
        key: 'bankCardFlag',
        value: 0,
        isShow: true,
    }, {
        text: this.labels.cardDesign.not,
        key: 'clearBankCardFlag',
        value: 1,
        isShow: true,
    }];

    private originSubmitData: any;

    constructor(
        public navCtrl: NavController, public modalCtrl: ModalController, public modalService: ModalService,
        public rsaEncryptService: RsaEncryptService,
        public navParam: NavParams, public viewCtrl: ViewController,
        public confirmUtil: ConfirmUtil,
        private creditCardUtil: CreditCardUtil,
        private creditCardAction: CreditCardAction,
        private labelService: LabelService,
        private errorMessageService: ErrorMessageService) {
        super(navCtrl, modalService, navParam, viewCtrl);
        this.isW9Show = this.state.submitData.isSsnWrite === SsnWrite.YES;
        this.isFatcaShow = this.state.submitData.isSsnHave === SsnHave.NO || this.state.submitData.isTaxForAmerican === SsnHave.NO;
        this.originSubmitData = Object.assign(new SubmitEntity(), this.state.submitData);

    }

    public ngOnInit() {
        super.ngOnInit();
        this.setLogOptions();
        if (this.state.submitData.isAgent !== PrincipalAgentCategory.AGENT) {
            this.action.submitDataBackup();
        } else {
            // 普通預金新規代理人の場合、初期化ロジックにフィルタニングを呼ぶ
            this.filterInquiry();
        }
        this.isAgent = this.state.submitData.isAgent === PrincipalAgentCategory.AGENT;
        this.idConfirmTitle = this.state.submitData.isAgent === PrincipalAgentCategory.AGENT
            ? this.labels.ordinary.agent.idConfirmMethod : this.labels.confirm.identityDocumentConfirm.title;

        this.bottonTitle = this.labels.existingSavings.clerk.nextButton; // 認証する
        this.topMessage = this.labels.ordinary.holder.description3; // 申し込み
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.bottonTitle = this.labels.change.confirm.button; // 次へ
            this.topMessage = this.labels.ordinary.holder.description4; // 次へ
        }
    }

    // 18歳未満　また　代理人の場合は、BC欄を非表示する
    public get isBcShow() {
        const isBlow18 = !InputUtils.validateAge(this.state.submitData.holderBirthdate, Age.Age_18,
            this.state.submitData.tabletStartDate);
        return (isBlow18 || this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) ? false : true;
    }

    public submitProcessedData(submitData: any) {
        this.saveOperationLog(this.labels.logging.AccountConfirm.confirmButton);
        this.action.saveSubmitData(submitData);
    }

    public pushNextPage() {
        // ※※ 継承しているConfirmPageBaseComponentのngOnInitの影響で、このメソッドが意図せず走るためコメントアウト ※※※
        // this.store.registerSignalHandler(SavingsSignal.SUCCESS_INSERT_INFO, () => {
        //     this.presentModal();
        // });
    }

    public onChangeExistingAccount(info) {
        // this.action.setStateSubmitDataValue({
        //     name: 'selectExistingAccount',
        //     value: true
        // });

        this.action.changeExistingAccount(info.existingAccount);
        this.action.setStateSubmitDataValue({ name: 'allCifInfos', value: info.allCifInfos });
        this.action.setStateSubmitDataValue({ name: 'confirmPurpose', value: info.confirmPurpose });
        this.action.updateSubmitDataBackup([
            {
                key: 'existingAccount',
                value: info.existingAccount
            },
            {
                key: 'allCifInfos',
                value: info.allCifInfos
            },
            {
                // 書類修正時データをクリアされないため、confirmPageSubmitDataに保存する。
                key: 'selectExistingAccount',
                value: true
            },
            {
                key: 'confirmPurpose',
                value: info.confirmPurpose
            }
        ]);
    }

    public onBankCardStatusChange(data: boolean) {
        this.hasBankCard = data;
    }

    public onChangeReceptionNumber(data) {
        data.forEach((element) => {
            this.action.setStateSubmitDataValue({
                name: element.key,
                value: element.value
            });
        });
        this.action.updateSubmitDataBackup(data);
    }

    public onChangeOpenStore(data) {
        this.action.changeOpenStore(data);
        this.action.updateSubmitDataBackup([
            {
                key: 'branchName',
                value: data.branchName || data.branchNameKanji
            }, {
                key: 'tenban',
                value: data.tenban || data.branchNo
            }, {
                key: 'existingAccount',
                value: undefined
            }
        ]);
        this.action.upDateBackUp(data);
    }

    /**
     * 入力チェック結果を返す
     */
    public get disableFooterButton(): boolean {

        // // 名寄せ候補がある場合、名寄せリストに何も選択しない場合、trueになる、非活性になる
        // const hasExAndSelect = this.state.duplicateAccountInfos && this.state.duplicateAccountInfos.length > 0
        //     && !this.state.confirmPageChanges.selectExistingAccount;

        // // 名寄せ候補が11件以上あるかどうか
        // const isDuplicateAccountMax = this.state.duplicateAccountInfos &&
        //     this.state.duplicateAccountInfos.length > Length.DUPLICATE_ACCOUNT_MAX;

        // BC申込ありの場合、PID配下にBC保有があるかどうか
        let hasBankCard = false;
        if (this.state.submitData.ifApplyBC === ApplyBC.YES && this.state.submitData.existingAccount
            && this.state.submitData.receptionCheckResult) {
            this.state.submitData.receptionCheckResult.accounts.forEach((account) => {
                if (account.bcHoldingStatus === HasBankCard.YES) {
                    hasBankCard = true;
                }
            });
        }

        // 受付番号なし　また　マスキンチェックボックスがチェックされない
        // もしくは　口座開設店舗確認がチェックされてない
        // BC申込ありでBC保有ありの場合
        // 有効期限が空欄の場合
        return !this.state.submitData.receptionNumber || !this.state.checkboxStatus.isAllMaskingStatus
            || !this.state.checkboxStatus.isCheckBranchStatus || hasBankCard
            || !this.state.submitData.identificationDocument1ExpiryDate || !this.state.submitData.identificationDocument1ExpiryDateText;
    }

    public presentModal(result: any) {
        // 認証画面で、申込を希望するバンクカードのタイプを選択する場合、バンクカード申込業務へ遷移する
        if (this.state.submitData.bankCardFlag === IsBankCardSelected.IS_SELECTED
            || this.state.submitData.bankCardGoldFlag === IsBankCardGoldSelected.IS_SELECTED
            || this.state.submitData.bankCardSuicaFlag === IsBankCardSuicaSelected.IS_SELECTED
            || this.state.submitData.bankCardSuicaGoldFlag === IsBankCardSuicaGoldSelected.IS_SELECTED) {
            this.navCtrl.setRoot(CreditCardChatComponent,
                {
                    submitData: this.makeSubmitDataForBc(result),
                    tabletApplyId: this.loginStore.getState().tabletApplyId,
                    pageIndex: 0,
                    accountType: this.state.submitData.accountType,
                    customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                    cardInfo: this.state.submitData.cardInfo,
                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                });
            this.action.updateApplyBizCategory({
                applyBusinessCategory: ApplyBusinessType.BANKCARD_COMPOSIT,
                tabletApplyId: this.loginStore.getState().tabletApplyId
            });
        } else {
            const buttonList = [
                { text: this.labels.alert.backToTopBtn, buttonValue: COMMON_CONSTANTS.BACK_TYPE_TOP }
            ];
            this.modalService.showInfoAlert(
                this.labels.alert.applyCompletionTitle,
                buttonList,
                () => {
                    this.navCtrl.setRoot(TopComponent);
                },
                null,
                false,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        }
    }

    // click 申込内容確認へ戻る button
    public backConfirmClick() {
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    // 申込画面に戻るので、マスキング未確認オブジェクトをクリア
                    this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.CLEAR);
                    this.saveOperationLog(this.labels.logging.AccountConfirm.backConfirmButton);
                    this.backToConfirm();
                }
            }
        );
        this.isBacking = true;
    }

    // click 代理人確認へ戻る button
    public backAgentConfirmClick() {
        this.isBacking = true;
        this.saveOperationLog(this.labels.logging.AccountConfirm.backAgentConfirmButton);
        this.action.clearConfirmPageInfo(false);
        this.navCtrl.pop();
    }

    /**
     * 貯蓄預金判断
     */
    public isStorage(): boolean {
        return this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT_SAVINGS_DIPOSIT ? true : false;
    }

    public submit() {
        this.submitted = true;
        this.store.registerSignalHandler(SavingsSignal.SUCCESS_INSERT_INFO, (result) => {
            this.store.unregisterSignalHandler(SavingsSignal.SUCCESS_INSERT_INFO);
            if (result.resultCode === HostResultCode.SUCCESS) {
                this.presentModal(result);
            } else {
                this.errorMessageService.showMessageModal(this.labelService.labels.common.error.host.applyErrorMessage, () => {
                    this.navCtrl.setRoot(TopComponent);
                    this.action.clearStore();
                });
            }
        });

        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.navCtrl.push(CreditCardConfirmComponent,
                {
                    submitData: this.state.submitData,
                    originSubmitData: this.originSubmitData,
                    tabletApplyId: this.loginStore.getState().tabletApplyId,
                    pageIndex: 0,
                    accountType: this.state.submitData.accountType,
                    customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                    cardInfo: this.state.submitData.cardInfo,
                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                });
        } else {
            this.action.submitTimeSavingOrangeApplyInfo(this.processSubmitData());
        }

        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId
                : this.logging.getConfirmPageScreenName(this.state.submitData, true),
            this.labels.logging.AccountConfirm.confirmButton,
        );
    }

    /**
     * 画像をクリックしたら画像修正モーダル開き
     *
     * @param {{ index: number, fieldName: string, value: string }} data
     * @memberof AccountComponent
     */
    public onImageMaskingComplete(data: { index: number, fieldName: string, value: string }) {
        this.action.editSomeDataInSubmitData(data.index, data.fieldName, data.value);
    }

    public onEditIdentityDocument() {
        const backup = Object.assign(new SubmitEntity(), this.state.submitData);

        // 修正の場合
        this.action.setStateSubmitDataValue({
            name: 'isModify',
            value: '1'
        });

        // 行員確認画面で本人確認書類１の有効期限が空欄のとき、
        // 修正チャットで必ず有効期限を聴取するために、
        // クリア状態を判別するためのフラグを設ける。
        if (!this.state.submitData.identificationDocument1ExpiryDate
            || !this.state.submitData.identificationDocument1ExpiryDateText) {
            // 有効期限のクリア判別フラグをtrueに更新する。
            this.action.setModifyExpiryDateExists(true);
        } else {
            // 有効期限のクリア判別フラグをfalseに更新する。
            this.action.setModifyExpiryDateExists(false);
        }
        const checkComponent = this.state.submitData.isAgent === PrincipalAgentCategory.HOLDER ?
            'SelfCheckApplyComponent' : 'AgentCheckApplyComponentHolder';

        const ocrExpiry = {
            identificationDocument1ExpiryDate: this.state.submitData.identificationDocument1ExpiryDate,
            identificationDocument1ExpiryDateText: this.state.submitData.identificationDocument1ExpiryDateText
        };

        const imgBackup = this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE ?
            // OCR(運転免許証・マイナンバーカード)の場合、OCR画像データをバックアップ
            {
                // 本チャットで「運転経歴証明書」を選択し再撮影後
                // 「運転免許証」に変更した場合、holderCardImageFront,Backがクリアされundefinedとなるため
                // copySubmitData配下の値を取得する
                holderCardImageFront: this.state.submitData.holderCardImageFront ?
                    this.state.submitData.holderCardImageFront : this.state.copySubmitData.holderCardImageFront,
                holderCardImageBack: this.state.submitData.holderCardImageBack ?
                    this.state.submitData.holderCardImageBack : this.state.copySubmitData.holderCardImageBack,
            } :
            // それ以外の場合、copySubmitData配下をバックアップ
            {
                holderCardImageFront: this.state.copySubmitData.holderCardImageFront,
                holderCardImageBack: this.state.copySubmitData.holderCardImageBack,
            };
        // OCR運転免許証・運転経歴証明書の場合、本人確認書類をバックアップ
        const identificationDocument1ImagesBackUp = {
            identificationDocument1Images: this.state.submitData.hasLicense === HasLicense.HAS_NOT_LICENSE
                && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES ?
                this.state.submitData.identificationDocument1Images : undefined
        };

        const options = {
            component: checkComponent,
            process: -1,
            clear: false,
            submitData: {
                ...this.state.copySubmitData, // 認証画面に最初入る時のsubmitData（行員確認チャットの情報を入れないため）
                ...this.state.confirmPageChanges, // 認証画面で発生する変更内容
                // OCR（本人のみ）の期限表示は本人確認上で表示する。copySubmitDataにのデータが古いので、最新のデータを本人確認チャットに渡す
                ...ocrExpiry,
                ...imgBackup,
                ...identificationDocument1ImagesBackUp,
                isModify: this.state.submitData.isModify,
                contactNote: this.state.submitData.contactNote,
                identificationStudentImages: this.state.submitData.identificationStudentImages,
                hasDriversCareerLicense: this.state.submitData.hasDriversCareerLicense
            }
        };
        const modal = this.modalCtrl.create(ChatComponent, {
            options,
            isCurrentPage: true,
            currentTitle: '本人確認書類'
        }, {
            cssClass: 'full-modal'
        });

        modal.onDidDismiss((state: any) => {
            // 戻るボタン及び修正チャット完了時、有効期限のクリア判別フラグを初期化する。
            this.action.setModifyExpiryDateExists(false);
            if (state && state !== COMMON_CONSTANTS.DIMISS_CLOSE_VALUE) {
                // 本人確認画面が終わったら、maskingチェックボックスをリセット
                this.clearMaskingCheckBox();
                // 運転経歴証明書の場合は、setStateData内でクリア処理させる
                this.action.setStateData(state);
                // 運転免許証の場合のクリア処理
                if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE
                    && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.NO) {
                    this.action.setStateSubmitDataValue({ name: 'identificationDocument1Images', value: undefined });
                }
                // 最新の写真によってマスキング未確認データをセットする
                this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.DOCUMENT);
                // 本人確認チャットから確認画面へ戻るときに、代理人の場合は
                // 「代理人確認へ戻る」ボタンの処理を真似して、代理人画面へ戻る
                if (state.submitData.continueOrBackToConfirm !== ContinueOrBackToConfirm.BACK_TO_CONFIRM
                    && this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) {
                    this.action.clearConfirmPageInfo(false);
                    this.navCtrl.pop();
                }
                // チャットフロー上で「申込内容確認へ戻る」ボタンが選択された場合、申込画面へ戻る
                if (state.submitData.continueOrBackToConfirm === ContinueOrBackToConfirm.BACK_TO_CONFIRM) {
                    this.backToConfirm();
                }
            } else {
                this.state.submitData = backup;
            }
        });

        return modal.present();
    }

    /**
     * 確認書類の写真だけを撮り直す
     *
     * @param {string} type
     * @memberof AccountComponent
     */
    public onReTakeIdentityDocument(params: { type: string, imgDocumentName: string }) {
        const config: any = {
            name: 'reimg',
            currentTitle: this._labels.confirm.reTakeDocument,
            pageIndex: 0,
            isCurrentPage: true
        };

        // OCR2枚
        if (params.type === LicensePhotoType.CARD_FRONT_AND_BACK) {
            config.startOrder = 60;
        }

        // OCR1枚
        if (params.type === LicensePhotoType.CARD_FRONT) {
            config.startOrder = 60;
            config.endOrder = 80;
        }

        const modal = this.modalCtrl.create(CommonBusinessChatComponent, {
            businessType: CommonBusinessType.ReImg,
            ...config
        }, {
            cssClass: 'full-modal'
        });
        modal.present();
        modal.onDidDismiss((data) => {
            // 「戻る」以外によってダイアログを閉じる場合
            if (data !== 'close') {
                if (params.type === LicensePhotoType.CARD_FRONT_AND_BACK) {
                    // OCR2枚。免許
                    this.action.editSomeDataInSubmitData(undefined,
                        'holderCardImageFront',
                        data.identityDocument[0]);
                    this.action.editSomeDataInSubmitData(undefined,
                        'holderCardImageBack',
                        data.identityDocument[1]);
                    this.action.resetSpecialNotMaskingConfirmImages('holderCardImageFront');
                    this.action.resetSpecialNotMaskingConfirmImages('holderCardImageBack');
                } else if (params.type === LicensePhotoType.CARD_FRONT) {
                    // OCR1枚
                    this.action.editSomeDataInSubmitData(undefined,
                        'holderCardImageFront',
                        data.identityDocument[0]);
                    this.action.resetSpecialNotMaskingConfirmImages('holderCardImageFront');
                } else {
                    // OCR以外の書類
                    // imgDocumentNameによって特定な写真を入れ替わる
                    this.action.editSomeDataInSubmitData(undefined,
                        params.imgDocumentName,
                        data.identityDocument);
                    this.action.resetSpecialNotMaskingConfirmImages(params.imgDocumentName);
                }

                this.clearMaskingCheckBox();
            }
        });
    }

    /**
     * サブミットデータを加工する
     */
    public processSubmitData(): any {
        return {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            openAccountParams: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                eyeCueNo: this.state.submitData.receptionNumber,
                bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
                operatorName: this.loginStore.getState().clerkInfo.operatorName,
                hasChange: '0',
                // BC申込データ
                ifApplyBc: '0',    // BC申込無
                // 顧客情報
                customerInfos: this.makeCustomerInfo()
            }
        };
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.action.modifyCheckboxStatus(checboxItem);
    }

    public onMaskingConfirmEmmiterHandler(imageInfo: { documentName: string, index: number }) {
        this.action.removeNotMaskingConfirmImages(imageInfo);
    }

    public filterInquiry() {
        const prefecture = this.state.submitData.holderAddressPrefecture ? this.state.submitData.holderAddressPrefecture : '';
        const countyUrbanVillage = this.state.submitData.holderAddressCountyUrbanVillage
            ? this.state.submitData.holderAddressCountyUrbanVillage : '';
        const streetName = this.state.submitData.showStreet
            ? this.state.submitData.showStreet : this.state.submitData.getHolderAddressStreetName();
        const addressHouseNumber = this.state.submitData.holderAddressHouseNumber ? this.state.submitData.holderAddressHouseNumber : '';

        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                nameKanji: this.state.submitData.firstName + COMMON_CONSTANTS.HALF_AT + this.state.submitData.lastName,
                nameKana: this.state.submitData.firstNameKana + COMMON_CONSTANTS.HALF_AT + this.state.submitData.lastNameKana,
                nameAlphabet: this.state.submitData.nameEnglish,
                birthdate: this.state.submitData.holderBirthdate,
                address: prefecture + countyUrbanVillage + streetName + addressHouseNumber,
                agentNameKanji: this.state.submitData.agentName ?
                    this.state.submitData.agentFirstName + COMMON_CONSTANTS.HALF_AT + this.state.submitData.agentLastName
                    : this.state.submitData.agentName,
                agentNameKana: this.state.submitData.agentNameFurikana ?
                    this.state.submitData.agentFirstNameKana + COMMON_CONSTANTS.HALF_AT + this.state.submitData.agentLastNameKana
                    : this.state.submitData.agentNameFurikana,
                agentBirthdate: this.state.submitData.agentBirthdate,
                bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
            }
        };

        const curFilteringParamters = new FilteringParameterEntity();
        curFilteringParamters.nameKanji = param.params.nameKanji;
        curFilteringParamters.nameKana = param.params.nameKana;
        curFilteringParamters.birthdate = param.params.birthdate;
        curFilteringParamters.agentNameKanji = param.params.agentNameKanji;
        curFilteringParamters.agentNameKana = param.params.agentNameKana;
        curFilteringParamters.agentBirthdate = param.params.agentBirthdate;

        // 前回のパラメータと比較
        const isChanged = this.confirmUtil.isFilteringParameterChanged(this.state.lastFilteringParameter, curFilteringParamters);
        this.store.registerSignalHandler(SavingsSignal.FILTERING_INQUIRY, (data) => {
            this.store.unregisterSignalHandler(SavingsSignal.FILTERING_INQUIRY);
            this.action.updateSubmitDataBackup(data);
            this.setDesignOptions();
        });
        if (isChanged) {
            this.action.filterInquiry(param);
            // 今回のパラメータを保存
            this.action.setLastFilteringParameters(curFilteringParamters);
        } else {
            // 前回のフィルタリング照会結果を表示変数に渡す
            this.action.setLastFilteringResult(this.state.lastFilteringResult);
        }
    }

    private clearMaskingCheckBox() {
        // 本人確認画面が終わったら、maskingチェックボックスをリセット
        if (this.state.checkboxStatus.isAllMaskingStatus) {
            this.action.modifyCheckboxStatus(MaskingCheckboxName.MASKING_CHECKBOX_NAME);
        }
        if (this.state.checkboxStatus.isAgentAllMaskingStatus) {
            this.action.modifyCheckboxStatus(MaskingCheckboxName.AGENT_MASKING_CHECKBOX_NAME);
        }
    }

    private clearStudentMaskingCheckBox() {
        // 本人確認画面が終わったら、学生証のmaskingチェックボックスをリセット
            this.creditCardAction.callModifyCheckboxStatus(MaskingCheckboxName.STUDENT_CHECKBOX_NAME);
    }

    /**
     * 本人確認方法
     */
    private idInfoMethod() {
        if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
            // OCR読み取りの場合、01：1種類提示
            return '01';
        }
        return this.state.submitData.idInfoMethod;
    }

    /**
     * 本人確認書類１
     */
    private idInfoDoc1() {
        if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
            // OCR読み取りの場合、画面で選択した本人確認資料　01：運転免許証 or 08：個人番号カード
            return this.state.submitData.hasLicense;
        }
        return this.state.submitData.identificationDocument1;
    }

    /**
     * 本人確認書類1（画像ファイル）
     */
    private imageDoc1() {
        if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
            // OCR読み取りの場合、OCRから取得した画像ファイル
            if (this.state.submitData.hasLicense === Constants.DriveCard) {
                return this.state.submitData.holderCardImageFront && this.state.submitData.holderCardImageBack ?
                    [this.state.submitData.holderCardImageFront, this.state.submitData.holderCardImageBack] : undefined;
            } else if (this.state.submitData.hasLicense === Constants.MyNumberCard) {
                return this.state.submitData.holderCardImageFront ? [this.state.submitData.holderCardImageFront] : undefined;
            } else {
                return undefined;
            }
        }
        return this.state.submitData.identificationDocument1Images;
    }

    /**
     * 代理人ー本人確認方法
     */
    private agentMethod() {
        if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) {
            return this.state.submitData.agentMethod;
        }
        return undefined;
    }

    /**
     * 代理人ー本人確認書類１
     */
    private agentDoc1() {
        if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) {
            return this.state.submitData.agentIdentificationDocument1;
        }
        return undefined;
    }

    /**
     * 代理人確認書類1（画像ファイル）
     */
    private imageAgentDoc1() {
        if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) {
            return this.state.submitData.identificationDocument1AgentImages;
        }
        return undefined;
    }

    private setDesignOptions() {
        let isShowArray = [];
        if (this.state.submitData.outStatusText === OutStatusText.ON) {
            isShowArray = [false, false, false, false, true];
        } else {
            const isBlow18 = !InputUtils.validateAge(this.state.submitData.holderBirthdate, Age.Age_18,
                this.state.submitData.tabletStartDate);
            const isFrom20To65 = InputUtils.validateAgeRange(this.state.submitData.holderBirthdate, Age.Age_66, Age.Age_20,
                this.state.submitData.tabletStartDate);
            const noWorkExist = this.state.submitData.holderCareer.split('、').indexOf(ExistingHolderCareerCode.NO_WORK);
            const houseWifeExist = this.state.submitData.holderCareer.split('、').indexOf(ExistingHolderCareerCode.HOUSEWIFE);
            const studentExist = this.state.submitData.holderCareer.split('、').indexOf(ExistingHolderCareerCode.STUDENT);
            const isCareerAvalible = noWorkExist === -1 && houseWifeExist === -1 && studentExist === -1 ? true : false;
            isShowArray = [
                !isBlow18,
                isFrom20To65 && isCareerAvalible,
                !isBlow18,
                isFrom20To65 && isCareerAvalible,
                true];
        }
        this.designOptions.forEach((item: ConfirmationRadioButtonOption, index: number) => {
            item.isShow = isShowArray[index];
        });
    }

    private setLogOptions() {
        this.options = {
            logInfo: {
                screenName: this.logging.getConfirmPageScreenName(this.state.submitData, true),
                yamlId: undefined,
                yamlOrder: undefined,
            }
        };
    }

    /**
     * BC申込(複合取引)のパラメーター作成
     */
    private makeSubmitDataForBc(result: any) {
        let submitData: any;
        submitData = this.processSubmitDataForBc();
        submitData.address = this.state.submitData.holderAddressPrefecture + this.state.submitData.holderAddressCountyUrbanVillage
            + this.state.submitData.getHolderAddressStreetName() + this.state.submitData.holderAddressHouseNumber;
        submitData.addressKana = this.state.submitData.holderAddressPrefectureFuriKana
            + this.state.submitData.holderAddressCountyUrbanVillageFuriKana + this.state.submitData.getHolderAddressStreetNameFuriKana()
            + this.state.submitData.holderAddressHouseNumberFuriKana;
        if (result.accountInfos && result.accountInfos.tenban && result.accountInfos.accountType && result.accountInfos.accountNo) {
            const complexAccountInfo = {
                branchNo: result.accountInfos.tenban,
                accountType: result.accountInfos.accountType,
                accountNo: result.accountInfos.accountNo,
            };
            submitData.complexAccountInfo = complexAccountInfo;
        }
        return submitData;
    }

    /**
     * サブミットデータを加工する
     */
    private processSubmitDataForBc(): any {
        // dataの加工処理を実行する
        return {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            receptionTenban: this.loginStore.getState().belongToBranchNo,
            nameKanji: this.state.submitData.holderName,
            nameKana: this.state.submitData.holderNameFurikana,
            nameNonConvert: NameNonConvert.ON,
            gender: this.state.submitData.holderGender,
            genderText: this.state.submitData.genderText,
            birthdate: this.state.submitData.holderBirthdate,
            customerId: this.state.submitData.existingAccount ? this.state.submitData.existingAccount.customerId : undefined,
            zipCode: this.state.submitData.holderZipCode,
            prefecture: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillage: this.state.submitData.holderAddressCountyUrbanVillage,
            street: this.state.submitData.getHolderAddressStreetName(),
            subAddress: this.state.submitData.holderAddressHouseNumber,
            prefectureKana: this.state.submitData.holderAddressPrefectureFuriKana,
            countyUrbanVillageKana: this.state.submitData.holderAddressCountyUrbanVillageFuriKana,
            streetKana: this.state.submitData.getHolderAddressStreetNameFuriKana(),
            subAddressKana: this.state.submitData.holderAddressHouseNumberFuriKana,
            holderMobileNo: this.state.submitData.holderMobileNo,
            holderTelephoneNo: this.state.submitData.holderTelephoneNo,
            occBusiness: this.state.submitData.holderCareer ? this.state.submitData.holderCareer.split('、') : undefined,
            workPlace: this.state.submitData.holderWorkPlace,
            accountOpeningPurpose:
                this.state.submitData.accountOpeningPurpose ? this.state.submitData.accountOpeningPurpose.split('、') : undefined,
            nationalityCode: this.state.submitData.nationalityCode,
            agentNameKana: this.state.submitData.agentNameFurikana,
            agentName: this.state.submitData.agentName,
            agentBirthdate: this.state.submitData.agentBirthdate,
            agentRelationship: this.state.submitData.relationship,
            agentMethod: this.agentMethod(),
            agentDoc1: this.agentDoc1(),
            agentExpirationDate1: this.state.submitData.agentIdentificationDocument1ExpiryDate,
            agentDoc2: this.state.submitData.agentIdentificationDocument2,
            agentExpirationDate2: this.state.submitData.agentIdentificationDocument2ExpiryDate,
            agentDocName: this.state.submitData.agentDocName,
            agentExpirationDate: this.state.submitData.agentExpirationDate,
            residenceFlagJapanOnly: this.state.submitData.isJapanLive,
            principalAgentCategory: this.state.submitData.isAgent,
            nameDifferenceFlag: this.state.submitData.isDifferenceKanji,
            addressDifferenceFlag: this.state.submitData.addressDifferenceFlag,
            eyeCueNo: this.state.submitData.receptionNumber,
            bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
            operatorName: this.loginStore.getState().clerkInfo.operatorName,
            // 「フィルタリングシステム検索」APIから取得した「フィルタリングシステムの案件番号」
            outIssueNo: this.state.submitData.outIssueNo,
            // 「フィルタリングシステム検索」APIから取得した「照会結果」を設定
            outStatus: this.state.submitData.outStatus,
            passcode: this.rsaEncryptService.encrypt(this.state.submitData.firstPwd4bits),
            otherResidenceAddress: this.state.submitData.otherCountry,
            menuCode: '04',
            w9NameAlphabet: this.state.submitData.nameEnglish,
            w9AddressAlphabet: this.state.submitData.addressEnglish,
            w9CityNameAlphabet: this.state.submitData.cityOrTown,
            w9PrefecturesAlphabet: this.state.submitData.province,
            w9CountryNameAlphabet: this.state.submitData.agentCountryEnglish,
            w9SocialSecurityNo:
                this.state.submitData.socialSecurityNumber ? this.state.submitData.socialSecurityNumber.replace(/\-/g, '') : undefined,
            w9AmericanSuggestionInfo: this.state.submitData.w9AmericanSuggestionInfo,
            remainingPeriod: this.state.submitData.remainingPeriod,
            birthCountry: this.state.submitData.fatcaCountry,
            residenceCountryName: '0100',
            otherResidenceCountryName: this.state.submitData.agentCountry,
            accountOpeningBranchCode:
                this.state.submitData.existingAccount ? this.state.submitData.existingAccount.branchNo : this.state.submitData.tenban,
            receiptMethod: this.state.submitData.receiptMethod || CodeCategory.RECEIPT_METHOD_MAIL,
            idInfoMethod: this.idInfoMethod(),
            identificationDocument1: this.idInfoDoc1(),
            identificationDocument2: this.state.submitData.identificationDocument2,
            identificationDocument1Text: this.idInfoDoc1Text(),
            identificationDocument2Text: this.state.submitData.identificationDocument2Text,
            identificationDocument1ExpiryDate: this.state.submitData.identificationDocument1ExpiryDate,
            identificationDocument1ExpiryDateText: this.state.submitData.identificationDocument1ExpiryDateText,
            documentListName: this.state.submitData.documentListName,
            identificationDocument2ExpiryDate: this.state.submitData.identificationDocument2ExpiryDate,
            identificationDocument2ExpiryDateText: this.state.submitData.identificationDocument2ExpiryDateText,
            documentListName2: this.state.submitData.documentListName2,
            addressConfirmationDocumentName: this.state.submitData.addressConfirmationDocumentName,
            identificationAddressExpiryDate: this.state.submitData.identificationAddressExpiryDate,
            identificationAddressExpiryDateText: this.state.submitData.identificationAddressExpiryDateText,
            identificationCode: IdentificationCode.CODE_80,
            bankCardFlag: this.state.submitData.bankCardFlag,
            bankCardGoldFlag: this.state.submitData.bankCardGoldFlag,
            bankCardSuicaFlag: this.state.submitData.bankCardSuicaFlag,
            bankCardSuicaGoldFlag: this.state.submitData.bankCardSuicaGoldFlag,
            identificationDocument1Images: this.imageDoc1(),
            identificationDocument2Images: this.state.submitData.identificationDocument2Images,
            identificationAddressImages: this.state.submitData.identificationAddressImages,
            imageAgentDoc1: this.imageAgentDoc1(),
            imageAgentDoc2: this.state.submitData.identificationDocument2AgentImages,
            imageAgentAddressDoc: this.state.submitData.identificationAddressAgentImages,
            signatureCrs: this.state.submitData.sign,
            signatureFatca: this.state.submitData.signFatca,
            signatureOath: this.state.submitData.signOath,
            signatureAgree: this.state.submitData.signAgree,
            notAntisocialForceConsent: '1',
            agentLetterType: this.state.submitData.agentLetterType,
            ageClassification: this.state.submitData.ageClassification,
            birthdateWithAge: this.state.submitData.holderBirthdateText,
            firstPwd4bits: this.state.submitData.firstPwd4bits,
            receptionNumber: undefined,
        };
    }

    /**
     * 本人確認書類１
     */
    private idInfoDoc1Text() {
        if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
            // OCR読み取りの場合、画面で選択した本人確認資料　01：運転免許証 or 08：個人番号カード
            if (this.state.submitData.hasLicense === '01') {
                return '運転免許証';
            } else if (this.state.submitData.hasLicense === '08') {
                return '個人番号カード';
            } else {
                return this.state.submitData.identificationDocument1Text;
            }
        }
        return this.state.submitData.identificationDocument1Text;
    }

    private hasExistingMobilePhoneNumber(): string {

        const { holderTelNo1, holderTelNo2, holderTelNo3 } = this.state.submitData.existingAccount[0];

        if (holderTelNo1 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo1)) {
            return Constants.HAS_EXISTS_MOBILE_NO;
        }
        if (holderTelNo2 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo2)) {
            return Constants.HAS_EXISTS_MOBILE_NO;
        }
        if (holderTelNo3 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo3)) {
            return Constants.HAS_EXISTS_MOBILE_NO;
        }

        return Constants.NO_EXISTS_MOBILE_NO;
    }

    private backToConfirm() {
        this.action.setStateData({ submitData: this.originSubmitData });
        this.clearConfirmPageInfo();
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.creditCardAction.clearConfirmPageInfo();
            // バックアップした運転免許証番号、学生証、連絡事項をクリア
            this.creditCardAction.clearCopyComplexTransConfirmInfos();
            this.clearStudentMaskingCheckBox();
        }
        this.action.setStateSubmitDataValue([{
            name: 'isModify',
            value: '2'
        }]);
        this.navCtrl.setRoot(BsdAgentConfirmComponent)
            .then(() => this.action.resetSubmitData());
    }

    /**
     * 書類１はパスポート（所持欄記載なし）かどうかを判断
     *
     * @private
     * @param {string} identificationDocument1
     * @return {*}  {boolean}　true：パスポート（所持欄記載なし）　false：パスポート（所持欄記載なし）以外
     */
    private isDocumentOneNewPassport(identificationDocument1: string): boolean {
        return !StringUtils.isEmpty(identificationDocument1) && identificationDocument1
            === IdentificationDocumentCode.PASSPORT_WITHOUT_SELF_INPUT;
    }

    /**
     * 書類２はその他官公庁から発行された書類（顔写真なし）かどうかを判断
     *
     * @private
     * @param {string} identificationDocument2
     * @return {*}  {boolean}　true：他官公庁から発行された書類（顔写真なし）　false：他官公庁から発行された書類（顔写真なし）以外
     */
    private isDocumentTwoOther(identificationDocument2: string): boolean {
        return !StringUtils.isEmpty(identificationDocument2) && identificationDocument2
            === IdentificationDocumentCode.OTHER_IDENTIFICATION_NO_PHOTO_DOCUMENT;
    }

    /**
     *  顧客情報データを加工する
     */
    private makeCustomerInfo(): any {
        let customerInfos;
        // 1件目は口座開設情報
        customerInfos = [
            {
                ...this.makeCustomerInfoDefult()
            }
        ];
        if (this.state.submitData.existingAccount) {
            // 店番号(代表口座）
            const ibInfo = this.creditCardUtil.getIbInfo(this.state.submitData);
            customerInfos[0].ibBranchCode = ibInfo ? ibInfo.branchCode : undefined;
            // 科目コード(代表口座）
            customerInfos[0].ibSubjectCode = ibInfo ? ibInfo.subjectCode : undefined;
            // 口座番号(代表口座）
            customerInfos[0].ibBankAccountId = ibInfo ? ibInfo.bankAccountId : undefined;
            // サービス利用区分
            customerInfos[0].serviceCategory =
                ibInfo && ibInfo.ibContractInfo.serviceCategory === ServiceCategory.TB_ONLY ? ServiceCategory.IB : undefined;
        }
        // 本人の場合、選択された名寄せを追加
        if (this.state.submitData.isAgent === '0' && this.state.submitData.existingAccount) {
            this.state.submitData.existingAccount.forEach((account) => {
                let customerInfo;
                customerInfo = {
                    ...this.makeCustomerInfoDefult(),
                    customerId: account.customerId,
                    identificationCode: account.identificationCode,
                    changeCategory: CHANGECATEGORY.NOTCHANGE,    // 届出事項変更区分:変更不要
                    accountCategory: AccountCategory.NO,    // 普通口座開設区分
                };
                customerInfos.push(customerInfo);
            });
        }
        return customerInfos;
    }

    /**
     * 顧客情報デフォルトデータを加工する
     */
    private makeCustomerInfoDefult(): any {

        // 米国人示唆情報
        const fatcaStasus = this.confirmUtil.getFatcaStatusTextJp(
            this.state.submitData.isGreenCardHave, this.state.submitData.fatcaStatus);

        return {
            nameKanji: this.state.submitData.holderName,
            nameKana: this.state.submitData.holderNameFurikana,
            gender: this.state.submitData.holderGender,
            birthdate: this.state.submitData.holderBirthdate,
            customerId: this.state.submitData.existingAccount ? this.setCustomerId() : undefined,
            identificationCode: this.state.submitData.existingAccount ?
                this.setIdentificationCode(this.setCustomerId()) : undefined,
            zipCode: this.state.submitData.holderZipCode ? this.state.submitData.holderZipCode.replace(/\-/g, '') : undefined,
            prefecture: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillage: this.state.submitData.holderAddressCountyUrbanVillage,
            street: this.state.submitData.getHolderAddressStreetName(),
            subAddress: this.state.submitData.holderAddressHouseNumber,
            prefectureKana: this.state.submitData.holderAddressPrefectureFuriKana,
            countyUrbanVillageKana: this.state.submitData.holderAddressCountyUrbanVillageFuriKana,
            streetKana: this.state.submitData.getHolderAddressStreetNameFuriKana(),
            subAddressKana: this.state.submitData.holderAddressHouseNumberFuriKana,
            mobilePhoneNo: this.state.submitData.holderMobileNo,
            otherPhoneNo: this.state.submitData.holderTelephoneNo,
            occBusiness: this.state.submitData.holderCareer ? this.state.submitData.holderCareer.split('、') : undefined,
            workPlace: this.state.submitData.holderWorkPlace,
            accountOpeningPurpose: this.state.submitData.accountOpeningPurpose ?
                this.state.submitData.accountOpeningPurpose.split('、') : undefined,
            nationalityCode: this.state.submitData.agentCountry,
            agentNameKana: this.state.submitData.agentNameFurikana,
            agentName: this.state.submitData.agentName,
            agentBirthdate: this.state.submitData.agentBirthdate,
            agentRelationship: this.state.submitData.relationship,
            // 代理人本人確認方法
            // 代理人本人確認書類１がパスポート（所持欄記載なし）場合「04」を設定、以外の場合は既存通り
            agentMethod: this.isDocumentOneNewPassport(this.state.submitData.agentIdentificationDocument1) ?
                IdentificationDocumentMethod.PRESENT_ONE_ADDRESS_TYPE : this.agentMethod(),
            agentDoc1: this.agentDoc1(),
            agentExpirationDate1: this.state.submitData.agentIdentificationDocument1ExpiryDate,
            // 代理人書類１の具体書類名
            agentIdentityDocument1Name: this.state.submitData.agentDocumentListName,
            // 代理人本人確認書類２コード
            // 代理人本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            agentDoc2: this.isDocumentOneNewPassport(this.state.submitData.agentIdentificationDocument1) ?
                undefined : this.state.submitData.agentIdentificationDocument2,
            // 代理人本人確認書類２有効期間
            // 代理人本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            agentExpirationDate2: this.isDocumentOneNewPassport(this.state.submitData.agentIdentificationDocument1) ?
                undefined : this.state.submitData.agentIdentificationDocument2ExpiryDate,
            // 代理人本人確認書類２その他書類名
            // 代理人本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            agentIdentityDocument2Name: this.isDocumentOneNewPassport(this.state.submitData.agentIdentificationDocument1) ?
                undefined : this.state.submitData.agentDocumentListName2,
            // 代理人住所確認書類の書類名
            // 代理人本人確認書類１がパスポート（所持欄記載なし）場合 かつ　書類２がその他場合、入力書類名を設定。書類２が以外の場合、ボタン名を設定
            // 代理人本人確認書類１がパスポート（所持欄記載なし）以外場合既存通り
            agentDocName:
                (this.isDocumentOneNewPassport(this.state.submitData.agentIdentificationDocument1)
                    && !StringUtils.isEmpty(this.state.submitData.agentIdentificationDocument2)) ?
                    (this.isDocumentTwoOther(this.state.submitData.agentIdentificationDocument2) ?
                        this.state.submitData.agentDocumentListName2 :
                        this.state.submitData.agentIdentificationDocument2Text) :
                    this.state.submitData.agentDocName,
            // 代理人住所確認書類の有効期間
            // 代理人本人確認書類１がパスポート（所持欄記載なし）場合「本人確認書類２の有効期間」を設定、以外の場合は既存通り
            agentExpirationDate: (this.isDocumentOneNewPassport(this.state.submitData.agentIdentificationDocument1)
                && !StringUtils.isEmpty(this.state.submitData.agentIdentificationDocument2)) ?
                this.state.submitData.agentIdentificationDocument2ExpiryDate :
                this.state.submitData.agentExpirationDate,
            residenceFlagJapanOnly: this.state.submitData.isJapanLive,
            principalAgentCategory: this.state.submitData.isAgent,
            nameDifferenceFlag: this.state.submitData.isDifferenceKanji,
            addressDifferenceFlag: this.state.submitData.addressDifferenceFlag,

            // 「フィルタリングシステム検索」APIから取得した「フィルタリングシステムの案件番号」
            outIssueNo: this.state.submitData.outIssueNo,
            // 「フィルタリングシステム検索」APIから取得した「照会結果」を設定
            outStatus: this.state.submitData.outStatus,
            passcode: this.rsaEncryptService.encrypt(this.state.submitData.firstPwd4bits),
            otherResidenceAddress: this.state.submitData.otherCountry,
            menuCode: '01',
            w9NameAlphabet: this.state.submitData.nameEnglish,
            w9AddressAlphabet: this.state.submitData.addressEnglish,
            w9CityNameAlphabet: this.state.submitData.cityOrTown,
            w9PrefecturesAlphabet: this.state.submitData.province,
            w9CountryNameAlphabet: this.state.submitData.agentCountryEnglish,
            w9SocialSecurityNo: this.state.submitData.socialSecurityNumber ?
                this.state.submitData.socialSecurityNumber.replace(/\-/g, '') : undefined,
            // 米国人示唆情報、　this.state.submitData.w9AmericanSuggestionInfo,の利用は廃止する。
            w9AmericanSuggestionInfo: fatcaStasus.americanSuggestionInfo,
            remainingPeriod: this.state.submitData.remainingPeriod,
            birthCountry: this.state.submitData.fatcaCountry,
            residenceCountryName: '0100',
            otherResidenceCountryName: this.state.submitData.agentCountry,
            accountOpeningBranchCode: this.state.submitData.tenban,
            receiptMethod: this.state.submitData.receiptMethod || CodeCategory.RECEIPT_METHOD_MAIL,
            // 本人確認方法
            // 本人確認書類１がパスポート（所持欄記載なし）場合「04」を設定、以外の場合は既存通り
            idInfoMethod: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                IdentificationDocumentMethod.PRESENT_ONE_ADDRESS_TYPE :
                this.idInfoMethod(),
            idInfoDoc1: this.idInfoDoc1(),
            // 本人確認書類２コード
            // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            idInfoDoc2: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                undefined : this.state.submitData.identificationDocument2,
            identityDocument1ExpirationDate: this.state.submitData.identificationDocument1ExpiryDate,
            identityDocument1Name: this.state.submitData.documentListName,
            // 本人確認書類２有効期間
            // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            identityDocument2ExpirationDate: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                undefined : this.state.submitData.identificationDocument2ExpiryDate,
            // 本人確認書類２その他書類名
            // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            identityDocument2Name: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                undefined : this.state.submitData.documentListName2,
            // 住所確認書類の書類名
            // 本人確認書類１がパスポート（所持欄記載なし）場合 かつ　書類２がその他場合、入力書類名を設定。書類２が以外の場合、ボタン名を設定
            // 本人確認書類１がパスポート（所持欄記載なし）以外場合既存通り
            addressConfirmationDocumentName:
                (this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1)
                    && !StringUtils.isEmpty(this.state.submitData.identificationDocument2)) ?
                    (this.isDocumentTwoOther(this.state.submitData.identificationDocument2) ?
                        this.state.submitData.documentListName2 :
                        this.state.submitData.identificationDocument2Text) :
                    this.state.submitData.addressConfirmationDocumentName,
            // 住所確認書類の有効期間
            // 本人確認書類１がパスポート（所持欄記載なし）場合「本人確認書類２の有効期間」を設定、以外の場合は既存通り
            addressConfirmationDocumentExpirationDate: (this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1)
                && !StringUtils.isEmpty(this.state.submitData.identificationDocument2)) ?
                this.state.submitData.identificationDocument2ExpiryDate :
                this.state.submitData.identificationAddressExpiryDate,

            bankCardFlag: this.state.submitData.bankCardFlag,
            bankCardGoldFlag: this.state.submitData.bankCardGoldFlag,
            bankCardSuicaFlag: this.state.submitData.bankCardSuicaFlag === IsBankCardSuicaSelected.IS_SELECTED ||
                this.state.submitData.bankCardSuicaGoldFlag === IsBankCardSuicaGoldSelected.IS_SELECTED ?
                IsBankCardSuicaSelected.IS_SELECTED : IsBankCardSuicaSelected.IS_NOT_SELECTED,
            imageDoc1: this.imageDoc1(),
            // 本人確認書類２画像
            // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            imageDoc2: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                undefined : this.state.submitData.identificationDocument2Images,
            // 住所確認書類画像
            // 本人確認書類１がパスポート（所持欄記載なし）場合「本人確認書類２の画像」を設定、以外の場合は既存通り
            imageAddressDoc: (this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1)
                && !StringUtils.isEmpty(this.state.submitData.identificationDocument2)) ?
                this.state.submitData.identificationDocument2Images :
                this.state.submitData.identificationAddressImages,
            imageAgentDoc1: this.imageAgentDoc1(),
            // 代理人本人確認書類２画像
            // 代理人本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            imageAgentDoc2: this.isDocumentOneNewPassport(this.state.submitData.agentIdentificationDocument1) ?
                undefined : this.state.submitData.identificationDocument2AgentImages,
            // 代理人住所確認書類画像
            // 代理人本人確認書類１がパスポート（所持欄記載なし）場合「代理人本人確認書類２の画像」を設定、以外の場合は既存通り
            imageAgentAddressDoc: (this.isDocumentOneNewPassport(this.state.submitData.agentIdentificationDocument1)
                && !StringUtils.isEmpty(this.state.submitData.agentIdentificationDocument2)) ?
                this.state.submitData.identificationDocument2AgentImages :
                this.state.submitData.identificationAddressAgentImages,
            signatureCrs: this.state.submitData.sign,
            signatureFatca: this.state.submitData.signFatca,
            signatureOath: this.state.submitData.signOath,
            signatureAgree: this.state.submitData.signAgree,
            // 名寄あるとき携帯電話存在チェック結果を格納、名寄なしときundefinedを格納
            existsMobileNoFlg: this.state.submitData.existingAccount ? this.hasExistingMobilePhoneNumber() : undefined,
            isSmsPhone: this.state.submitData.isSmsPhone,
            isNeedPassbook: this.state.submitData.isNeedPassbook, // 通帳発行するかどうか　１：発行　０：発行しない
            // 基準特例
            confirmPurpose: this.state.submitData.confirmPurpose
        };
    }

    private setCustomerId(): string {
        let customerId;

        const sameBranchAccountList = this.state.submitData.existingAccount.filter((account) =>
            account.branchNo === this.state.submitData.tenban);

        if (sameBranchAccountList.length === 1) {
            customerId = sameBranchAccountList[0].customerId;
        } else if (sameBranchAccountList.length > 1) {
            const sameBranchCustomerIdList = [];
            sameBranchAccountList.forEach((account) => {
                sameBranchCustomerIdList.push(account.customerId);
            });
            const sameBranchCifInfoList = [];
            sameBranchCustomerIdList.forEach((cid) => {
                for (const cifInfo of this.state.submitData.allCifInfos) {
                    if (cifInfo.customerId === cid) {
                        sameBranchCifInfoList.push(cifInfo);
                        break;
                    }
                }
            });
            sameBranchCifInfoList.sort((a, b) => {
                return Number(a.openingDate) - Number(b.openingDate);
            });
            customerId = sameBranchCifInfoList[0].customerId;
        }

        return customerId;
    }

    /**
     * 名寄せ時、既存口座の存在有無をチェックする
     *
     * @param customerId 顧客番号
     * @returns
     */
    private noAccountCheck(customerId: string): boolean {
        // チェック対象の科目
        const subjectCodeList = {
            11: true,  // 当座預金（一般当座貸越含む）
            12: true,  // 普通預金（総合口座貸越、普通預金貸越含む）
            13: true,  // 貯蓄預金
            14: true,  // 納税準備預金
            16: true,  // 通知預金
            19: false, // 別段預金　←チェック対象外
            20: true,  // 定期預金
            26: true,  // 積立定期預金（財形含む）
            48: false  // 貸越専用カードローン　←チェック対象外
        };

        let retVal = false;
        if (customerId && this.state.submitData.allCifInfos) {
            const cifInfo = this.state.submitData.allCifInfos.find((item) => item.customerId === customerId);
            if (cifInfo) {
                const domesticAccountInfos = cifInfo.domesticAccountInfo ? cifInfo.domesticAccountInfo : [];
                let accountCnt = 0;
                domesticAccountInfos.forEach((domesticAccountInfo) => {
                    if (subjectCodeList[domesticAccountInfo.subjectCode]) {
                        accountCnt++;
                    }
                });
                if (accountCnt === 0) {
                    retVal = true;
                }
            }
        }
        return retVal;
    }

    private setIdentificationCode(customerId: string): string {
        if (customerId) {
            if (this.noAccountCheck(customerId)) {
                // 名寄せかつ、口座を持たない顧客の場合、本人確認コード９９として扱う
                return IdentificationCode.CODE_99;
            } else {
                const cifInfo = this.state.submitData.allCifInfos.find((item) => item.customerId === customerId);
                return cifInfo.identificationCode;
            }
        } else {
            return undefined;
        }
    }

}
