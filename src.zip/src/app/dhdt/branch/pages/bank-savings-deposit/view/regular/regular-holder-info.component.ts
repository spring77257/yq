import { Component } from '@angular/core';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { SavingsSignal } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { ConfirmPageBaseComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/common/confirm-page-base.component';
import { BrdConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/regular/brd-confirm.component';
import { COMMON_CONSTANTS, RegularOpenPur } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { PRODUCT_TYPE } from 'dhdt/branch/shared/utils/product-category-utils';
import { NavController, NavParams, ViewController } from 'ionic-angular';
@Component({
    selector: 'regular-holder-info-component',
    templateUrl: 'regular-holder-info.component.html'
})
/**
 * 定期預金 行員確認画面 本人コンポネント
 */
export class RegularHolderInfoComponent extends ConfirmPageBaseComponent {
    // ログイン button タン押下時の二重リクエスト防止
    public isBacking = false;

    constructor(
        public navCtrl: NavController, public modalService: ModalService,
        public navParam: NavParams, public viewCtrl: ViewController) {
            super(navCtrl, modalService, navParam, viewCtrl);
    }

    public submitProcessedData(submitData: any) {
        this.saveOperationLog(this.labels.logging.AccountConfirm.confirmButton);
        if (RegularOpenPur.TIMG_SAVING === this.state.submitData.regularPurpos) {
            // 定期預金口座開設申込情報を加工する
            this.action.submitTimeSavingApplyInfo(submitData);
        } else {
            if (this.state.submitData.selectProductType === PRODUCT_TYPE.SMILE) {
                this.action.submitTimeSavingSmileApplyInfo(submitData);
            } else if (this.state.submitData.selectProductType === PRODUCT_TYPE.ORANGE) {
                this.action.submitTimeSavingOrangeApplyInfo(submitData);
            } else if (this.state.submitData.selectProductType === PRODUCT_TYPE.LOVE) {
                this.action.submitTimeSavingLoveApplyInfo(submitData);
            }
        }
    }

    public processSubmitData(): any {
        return this.commitDataProcessUtils.processReqularSavingsSubmitData(this.state);
    }

    public pushNextPage() {
        this.saveOperationLog(this.labels.logging.AccountConfirm.confirmButton);
        this.store.registerSignalHandler(SavingsSignal.SUCCESS_INSERT_INFO, () => {
            this.presentModal();
        });
    }

    public presentModal() {
        const buttonList = [
            { text: this.labels.alert.backToTopBtn, buttonValue: COMMON_CONSTANTS.BACK_TYPE_TOP }
        ];
        this.modalService.showInfoAlert(
            this.labels.alert.applyCompletionTitle,
            buttonList,
            () => {
                this.navCtrl.setRoot(TopComponent);
            },
            null,
            false,
            COMMON_CONSTANTS.CSS_MODAL_W_480
        );
    }

    // click 申込内容確認へ戻る button
    public backConfirmClick() {
        this.isBacking = true;
        this.saveOperationLog(this.labels.logging.AccountConfirm.backConfirmButton);
        this.clearConfirmPageInfo();
        // 定期預金口座開設
        this.navCtrl.setRoot(BrdConfirmComponent);
    }
}
