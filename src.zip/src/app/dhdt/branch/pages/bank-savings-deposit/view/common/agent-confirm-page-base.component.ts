import { OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { InjectionUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ConfirmPageCommonService } from 'dhdt/branch/pages/bank-savings-deposit/service/confirmpage.common.service';
import { SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { COMMON_CONSTANTS, HasLicense } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { SameHolderInquiryEntity } from 'dhdt/branch/shared/entity/same-holder-inquiry.entity';
import { DocumentCategoryService } from 'dhdt/branch/shared/modules/document-category/service/document-category.service';
import { LoadingService, SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { NavController, NavParams, ViewController } from 'ionic-angular';

/**
 * 行員確認画面(代理人)の共通ベースコンポネント
 */
export abstract class AgentConfirmPageBaseComponent extends BaseComponent implements OnInit {
    protected readonly store: SavingsStore;
    protected readonly action: SavingsAction;
    public readonly state: SavingsState;
    protected readonly confirmPageCommonService: ConfirmPageCommonService;
    protected readonly logging: LoggingService;
    protected readonly categoryService: DocumentCategoryService;
    protected readonly loadingService: LoadingService;

    public open: boolean = true;
    public confirmPageCommonParams: Map<string, any> = null;
    public saveShowChats: any = {};
    public isClerkConfirm: boolean = true;
    // 同一名義人照会結果
    public sameHolderList: SameHolderInquiryEntity[];

    public insertImageType: string = COMMON_CONSTANTS.InsertImageType.image;
    public insertImageTypeNoFace: string = COMMON_CONSTANTS.InsertImageType.image;

    constructor(public navCtrl: NavController, public navParam: NavParams, public viewCtrl: ViewController) {
        super();
        this.store = InjectionUtils.injector.get(SavingsStore);
        this.state = this.store.getState();
        this.action = InjectionUtils.injector.get(SavingsAction);
        this.confirmPageCommonService = InjectionUtils.injector.get(ConfirmPageCommonService);
        this.logging = InjectionUtils.injector.get(LoggingService);
        this.categoryService = InjectionUtils.injector.get(DocumentCategoryService);
        this.loadingService = InjectionUtils.injector.get(LoadingService);

        this.viewCtrl.willEnter.subscribe(() => this.categoryService.addObserver((data) => {
            this.action.setDocumentCategory(data, false, false);
        }, this));

        this.viewCtrl.willLeave.subscribe(() => this.categoryService.removeObserver(this));
    }

    public ngOnInit() {
        const loadingId = this.loadingService.showLoading(SpinnerType.SHOW);
        this.confirmPageCommonParams = this.confirmPageCommonService.getBankSavDepositAgentConfirmPageComponentParams();

        // 重複口座情報セット
        this.sameHolderList = this.navParam.get('sameHolderList');
        this.loadingService.dismissLoading(loadingId);
    }

    public get headerTitle(): string {
        if (!this.state.submitData.accountType || !this.state.submitData.accountTypeText) {
            return '';
        }
        return this.state.submitData.accountTypeText;
    }

    public get isNextButtonDisable(): boolean {
        return !this.checkInputValidation();
    }

    public checkInputValidation(): boolean {
        let validationResult = this.checkIdentityDocumentsValidation();

        if (validationResult && this.state.submitData.agentNoCopyReason) { // コピー徴求ができない理由
            validationResult = StringUtils.validateZenkaku(this.state.submitData.agentNoCopyReason);
        }

        if (validationResult && this.state.submitData.agentIdentityDocumentNoCopyReason) { // コピー徴求ができない理由
            validationResult = StringUtils.validateZenkaku(this.state.submitData.agentIdentityDocumentNoCopyReason);
        }

        return validationResult;
    }

    /**
     * 本人確認書類チェック
     */
    public checkIdentityDocumentsValidation(): boolean {
        if (this.state.submitData.agentIdentityDocumentType) {
            // OCR画像登録
            if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
                return true;
            }

            // 顔写真のある本人確認の画像登録
            if (this.state.agentIdentityDocuments && this.state.agentIdentityDocuments.length > 0) {
                return true;
            }

            // 顔写真のある本人確認のテキスト登録
            if (this.state.submitData.agentNoCopyReason || this.state.submitData.agentPublisher ||
                this.state.submitData.agentPublishDate || this.state.submitData.agentSignNo) {
                return true;
            }

            // 顔写真のない本人確認の画像登録
            if (this.state.agentAdditionalInfoDocuments && this.state.agentAdditionalInfoDocuments.length > 0) {
                return true;
            }

            // 顔写真のない本人確認のテキスト登録
            if (this.state.submitData.agentIdentityDocumentNoCopyReason || this.state.submitData.agentIdentityDocumentPublisher ||
                this.state.submitData.agentIdentityDocumentPublishDate || this.state.submitData.agentIdentityDocumentSignNo) {
                return true;
            }
        }

        return false;
    }

    /**
     * 顔写真のある本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedEmitter(event?: any) {
        this.insertImageType = event || this.insertImageType;
        this.action.setDocumentType({ name: COMMON_CONSTANTS.InsertDocument.Agent, value: this.insertImageType });
    }

    /**
     * 顔写真のない本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedNoFaceEmitter(event?: any) {
        this.insertImageTypeNoFace = event || this.insertImageTypeNoFace;
        this.action.setDocumentType({ name: COMMON_CONSTANTS.InsertDocument.AgentAdditional, value: this.insertImageTypeNoFace });
    }

    protected saveOperationLog(value: string) {
        const logInfo: IOperationInfo = {
            screenName: this.logging.getConfirmPageScreenName(this.state.submitData, true),
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: value,
        };
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }
}
