import { Component } from '@angular/core';
import { AgentConfirmPageBaseComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/common/agent-confirm-page-base.component';
import { RegularAgentHolderInfoComponent
            } from 'dhdt/branch/pages/bank-savings-deposit/view/regular/regular-agent-holder-info.component';
import { NavController, NavParams, ViewController } from 'ionic-angular';

@Component({
    selector: 'regular-agent-info-component',
    templateUrl: 'regular-agent-info.component.html'
})
/**
 * 定期預金 行員確認画面 代理人（代理人）コンポネント
 */
export class RegularAgentInfoComponent extends AgentConfirmPageBaseComponent {
    constructor(public navCtrl: NavController, public navParam: NavParams, public viewCtrl: ViewController) {
        super(navCtrl, navParam, viewCtrl);
    }

    public moveToNextPage() {
        this.saveOperationLog(this.labels.logging.AccountConfirm.agentNextButton);
        this.navCtrl.push(RegularAgentHolderInfoComponent, {
            sameHolderList: this.sameHolderList
        });
    }
}
