import { Component, OnDestroy, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { DeviceService } from 'dhd/common/services/device.service';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ConfirmPageCommonService } from 'dhdt/branch/pages/bank-savings-deposit/service/confirmpage.common.service';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { CompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/completion.component';
import { AccountType, RegularOpenPur } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { LoadingService, SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { PRODUCT_TYPE } from 'dhdt/branch/shared/utils/product-category-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { PasswordValidator } from 'dhdt/branch/shared/validators/password.validator';
import { ModalController, NavController } from 'ionic-angular';

/**
 * AP320_4_画面仕様書_T04-SC4001_情報確認画面（定期預金）
 */
@Component({
    selector: 'brd-confirm-component',
    templateUrl: 'brd-confirm.component.html'
})
export class BrdConfirmComponent extends BaseComponent implements OnInit, OnDestroy {
    public open: boolean = true;
    public state: SavingsState;
    public confirmPageCommonParams: Map<string, any> = null;
    public changeHolderMobileNoFlag: boolean = false;
    public saveShowChats: any = {};

    public isSelfApplyConfirm: boolean = true;  // distinguish 申込内容確認 from (行員確認用)ご本人確認
    public passwordOK: boolean = true; // 暗証番号 password validate result
    public showPassbook: boolean = false;
    public isTimeSavings: boolean = false;

    @ViewChild('productContainer', { read: ViewContainerRef })
    public productContainer: ViewContainerRef;

    // 自動振替する
    private readonly doAutoTransfer: string = '0';
    // 毎月振替
    private readonly monthly: string = '1';

    constructor(
        private action: SavingsAction,
        private navCtrl: NavController,
        private store: SavingsStore,
        private confirmPageCommonService: ConfirmPageCommonService,
        private modalCtrl: ModalController,
        private logging: LoggingService,
        private loginStore: LoginStore,
        private loadingService: LoadingService,
        private deviceService: DeviceService
    ) {
        super();
        this.state = this.store.getState();
    }

    public ngOnInit() {
        const loadingId = this.loadingService.showLoading(SpinnerType.SHOW);
        this.confirmPageCommonService.loadConfirmTemplate();
        this.confirmPageCommonParams = this.confirmPageCommonService.getShowChatParams();
        // 郵便番号
        this.getHolderZipCode();
        // chat
        this.state.showChats.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
        this.store.registerSignalHandler(SavingsSignal.SHOULD_UPDATE_DUE_DATE, () => {
            // 翌営業日を取得する
            this.getNextBusinessDay();
        });

        // 入学年  YYYY --> YYYY(平成XX)年
        this.getEnrollingYearText();
        // 預入期間(満期日)設定
        this.action.setDueDateAndDepositPeriodYearMonth();
        // determines whether the "通帳デザイン" is displayed
        this.getShowPassbook();
        // get '定期預金' component
        this.getTimeDepositShow();
        // 受付店を口座開設店として記録する
        this.action.setBranchInfo(this.loginStore.getState().belongToBranchName, this.loginStore.getState().belongToBranchNo);
        // 振替開始日を設定する(申込日翌日で設定するため、customerApplyStartDateを渡す)
        this.action.setAutomaticTransferStartDate(this.state.submitData.customerApplyStartDate);

        this.loadingService.dismissLoading(loadingId);
    }

    public ngOnDestroy(): void {
        this.store.unregisterSignalHandler(SavingsSignal.SHOULD_UPDATE_DUE_DATE);
    }

    public getShowText(name: string): string {
        if (!this.saveShowChats || !this.saveShowChats[name] || !this.saveShowChats[name].answer) {
            return '';
        }
        return this.saveShowChats[name].answer.text;
    }

    // 修正 mobile
    public changeHolderMobileNoEmitter(value) {
        this.changeHolderMobileNoFlag = value;
        // this.passwordOK = !this.getCardPwdAndConfirmPwdError();
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.action.modifyCheckboxStatus(checboxItem);
    }

    // headerTitle
    public get headerTitle(): string {
        if (!this.state.submitData.accountType || !this.state.submitData.accountTypeText) {
            return '';
        }
        return this.state.submitData.accountTypeText;
    }

    // 郵便番号
    public getHolderZipCode() {
        if (!this.state.submitData.firstZipCode && !this.state.submitData.lastZipCode) {
            if (this.state.submitData.holderAddressPrefecture && this.state.submitData.holderAddressCountyUrbanVillage) {
                this.action.getHolderZipCode(
                    this.state.submitData.holderAddressPrefecture,
                    this.state.submitData.holderAddressCountyUrbanVillage,
                    this.state.submitData.getHolderAddressStreetName());
            } else {
                this.action.setDefaultZipCode();
            }
        }
    }

    // 暗証番号 emitter
    public passwordOKEmitterHandler(flag: boolean) {
        // this.passwordOK = !this.getCardPwdAndConfirmPwdError();
    }

    /**
     * 郵便番号 emitter
     */
    public changePostSkipEmitterHandler() {
        this.getHolderZipCode();
    }

    // footer button disable
    public get footerBtnDisable() {
        const preconditionsOK = !this.state.checkboxStatus.isAntisocialStatus &&
            !this.state.checkboxStatus.isForeignPulicFiguresSatus &&
            this.state.checkboxStatus.isJapaneseResidentStatus;
        const confirmationCheckedOK = this.getShowText('directApplyExpectation') === '申し込む' ?
            this.state.checkboxStatus.confirmationStatus : true;
        const receiptMethodOK = this.getShowText('receiptMethod') === 'ご自宅' ? this.state.checkboxStatus.receiptMethodStatus : true;
        this.passwordOK = !this.getCardPwdAndConfirmPwdError();
        const kanaKanjiOK = this.checkContainKanjiValidation();
        const autoTransferValid = this.validateAutoTransferInfo();
        const totalValid = this.passwordOK && confirmationCheckedOK && receiptMethodOK && preconditionsOK && kanaKanjiOK
            && autoTransferValid;
        return totalValid;
    }

    // click 'お申込み' button
    public moveToNextPage() {
        const modal = this.modalCtrl.create(
            ModalPasswordComponent,
            {
                data: {
                    text: this.labels.confirm.passwordModal.text,
                    subText: this.labels.confirm.passwordModal.subText,
                    units: 4,
                    errorMessage: this.labels.confirm.passwordModal.errorMessage,
                    needConfirm: true,
                    inputPassword: this.state.submitData.firstPwd4bits
                }
            },
            { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.onDidDismiss((value) => {
            if (value) {
                this.action.setCustomerApplyEndDate();
                this.navCtrl.push(CompletionComponent);
            }
        });
        modal.present();
        this.saveOperationLog();
    }

    // 入学年  YYYY --> YYYY(平成XX)年
    public getEnrollingYearText() {
        const params = { birthday: this.state.submitData.enrollingYear };
        this.action.getEnrollingYearText({ params: params });
    }

    /**
     * get time deposit show
     */
    public getTimeDepositShow() {
        this.isTimeSavings = this.state.submitData.regularPurpos === RegularOpenPur.TIMG_SAVING;
    }

    // show checkbox errorMessage
    public get checkboxValid(): boolean {
        const preconditionsOK = !this.state.checkboxStatus.isAntisocialStatus &&
            !this.state.checkboxStatus.isForeignPulicFiguresSatus &&
            this.state.checkboxStatus.isJapaneseResidentStatus;
        const confirmationCheckedOK = this.getShowText('directApplyExpectation') === '申し込む' ?
            this.state.checkboxStatus.confirmationStatus : true;
        const receiptMethodOK = this.getShowText('receiptMethod') === 'ご自宅' ? this.state.checkboxStatus.receiptMethodStatus : true;
        const totalValid = confirmationCheckedOK && receiptMethodOK && preconditionsOK;
        return totalValid;
    }

    /**
     * Determines whether the "通帳デザイン" is displayed
     */
    public getShowPassbook() {
        this.showPassbook =
            this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT_CHILDREN ||
            this.state.submitData.selectProductType === PRODUCT_TYPE.LOVE;
    }

    private getCardPwdAndConfirmPwdError(): boolean {
        let result = !this.getPasswordValidation(this.state.submitData.firstPwd4bits);
        if (!result && this.state.submitData.directApplyExpectation === '1') {
            result = !this.getPasswordValidation(this.state.submitData.firstPwd6bits);
        }
        return result;
    }

    private getPasswordValidation(password: string): boolean {
        const telephone = this.state.submitData.firstTel + '-' + this.state.submitData.secondTel + '-' + this.state.submitData.thirdTel;
        const mobile = this.state.submitData.firstMobileNo + '-' + this.state.submitData.secondMobileNo
            + '-' + this.state.submitData.thirdMobileNo;
        const birthday = StringUtils.datetransfer(this.state.submitData.holderBirthdateText);

        const validate = PasswordValidator.validateB(password, password, telephone, mobile, birthday);
        return validate;
    }

    /**
     * add operation log
     */
    private saveOperationLog() {
        const logInfo: IOperationInfo = {
            screenName: this.logging.getConfirmPageScreenName(this.state.submitData, false),
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: this._labels.logging.InfoComfirm.ApplyButton,
        };
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }

    /**
     * 「カナ氏名」「カナ住所」に漢字が混在している場合は、
     * 申込内容確認画面の「申込をする」ボタンが非活性になること
     */
    private checkContainKanjiValidation(): boolean {
        const holderName = this.state.submitData.firstNameKana + this.state.submitData.lastNameKana;
        const holderAddress = this.state.submitData.holderAddressPrefectureFuriKana
        + this.state.submitData.holderAddressCountyUrbanVillageFuriKana
        + this.state.submitData.getHolderAddressStreetNameFuriKana()
        + this.state.submitData.holderAddressHouseNumberFuriKana;
        const agentName = this.state.submitData.agentFirstNameKana + this.state.submitData.agentLastNameKana;
        const childrenName = this.state.submitData.childrenFirstNamegana + this.state.submitData.childrenLastNamegana;

        let result = StringUtils.validateNameKana(holderName);
        if (result) {
            result = StringUtils.validateAddressKana(holderAddress);
        }
        if (result && this.state.submitData.isAgent === '1') {
            result = StringUtils.validateNameKana(agentName);
        }
        if (result && this.state.submitData.selectProductType === PRODUCT_TYPE.LOVE) {
            result = StringUtils.validateNameKana(childrenName);
        }
        return result;
    }

    private validateAutoTransferInfo(): boolean {
        if (this.state.submitData.autoTransfer === this.doAutoTransfer) {
            if (this.state.submitData.monthly === this.monthly) {
                return (this.state.submitData.normalMonthTransferDay && this.state.submitData.normalMonthTransferAmount) ? true : false;
            } else {
                return (this.state.submitData.normalMonthValue
                    && this.state.submitData.normalMonthArray && this.state.submitData.normalMonthTransferDay
                    && this.state.submitData.normalMonthTransferAmount) ? true : false;
            }
        }
        return true;
    }

    /**
     * #24401
     * 翌営業日を取得する。
     */
    private getNextBusinessDay() {
        if (this.state.submitData.selectProductType === PRODUCT_TYPE.HAPPINESS1) {
            const params = {
                tabletApplyId: this.state.submitData.tabletApplyId,
                userMngNo: this.loginStore.getState().bankclerkId,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                bankNo: this.state.submitData.swipeBranchNo,
                terminalNo: this.deviceService.getDeviceId(),
                newDueDate: this.state.submitData.dueDate.replace(/-/g, '')
            };
            this.action.getNextBusinessDay(params);
        }
    }
}

export interface ConfirmComponentProvider {
    submitData?: any;
    showChats?: any;
    saveShowChats?: any;
    confirmPageCommonParams?: any;
}
