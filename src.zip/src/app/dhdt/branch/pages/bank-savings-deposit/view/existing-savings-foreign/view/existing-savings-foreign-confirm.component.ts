import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { SubmitEntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    ExistingSavingsForeignInitConfirmComponent
} from 'dhdt/branch/pages/bank-savings-deposit/view/existing-savings-foreign/view/existing-savings-foreign-initconfirm.component';
import { CommonBusinessType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessChatComponent } from 'dhdt/branch/pages/common-business/view/common-business-chat.component';
import {
    AccountType, Age, ApplyBC, CertificateOfEnrollment, ClearSavingImagesClickRecordType, CodeCategory, COMMON_CONSTANTS, Constants,
    ContinueOrBackToConfirm, DocShootingStatus, ForeignHolderCareerCode, ForeignResidenceCode, HostResultCode, IdentificationCode,
    IdInfoDocType, LicensePhotoType, MaskingCheckboxName, SsnWrite
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import {
    IsBankCardSuicaGoldSelected,
    IsBankCardSuicaSelected
} from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-confirm.component';
import { Length } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import {
    ExistingSavingsConfirmPageCommonService
} from 'dhdt/branch/pages/existing-savings/service/existing-savings-confirmpage.common.service';
import {
    IdentityDocumentConfirmForeignComponent
} from 'dhdt/branch/shared/components/confirmpage-common/identity-document-confirm-foreign.component';
import { ShowChartParam } from 'dhdt/branch/shared/components/confirmpage-common/showchart.param';
import { ModalDigitalStore } from 'dhdt/branch/shared/components/modal/modal-digital/store/modal-digital.store';
import { FilteringParameterEntity } from 'dhdt/branch/shared/entity/filtering-parameter.entity';
import { SameHolderInquiryEntity } from 'dhdt/branch/shared/entity/same-holder-inquiry.entity';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ConfirmUtil } from 'dhdt/branch/shared/utils/confirm-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController, NavParams } from 'ionic-angular';

/**
 * 行員確認画面（外国人申込用）
 */
@Component({
    selector: 'existing-savings-foreign-confirm.component',
    templateUrl: 'existing-savings-foreign-confirm.component.html'
})
export class ExistingSavingsForeignConfirmComponent extends BaseComponent implements OnInit, OnDestroy {
    public state: SavingsState;
    public confirmPageCommonParams: Map<string, any> = null;
    public saveShowChats: any = {};
    public isSelfApplyConfirm: boolean = true;
    public loginStore: LoginStore;
    public submitted: boolean = false;
    public isClerkConfirm: boolean = true;
    // 二度押下を回避するフラグ
    public isBackToCustomerConfirmPage = false;
    public editedList = {};

    // 同一名義人照会結果
    public sameHolderList: SameHolderInquiryEntity[];
    public accountSelected: boolean = false;    // 既存CIF・口座確認 has been selected
    public duplicateAccountValid: boolean = true;

    public isSignShow: boolean = false;
    public isW9Show: boolean = false;
    public isFatcaShow: boolean = false;

    public mailing = false;
    public bottonTitle: string;
    public topMessage: string;

    private insertImageType: string = COMMON_CONSTANTS.InsertImageType.image;
    private insertImageTypeNoFace: string = COMMON_CONSTANTS.InsertImageType.image;
    private originSubmitData: any;

    @ViewChild(IdentityDocumentConfirmForeignComponent)
    private identityDocumentConfirmForeignComponent: IdentityDocumentConfirmForeignComponent;

    private selectExistingAccount: boolean = false;

    constructor(
        private action: SavingsAction,
        private navCtrl: NavController,
        private store: SavingsStore,
        private confirmPageCommonService: ExistingSavingsConfirmPageCommonService,
        private modalDigitalStore: ModalDigitalStore,
        private modalCtrl: ModalController,
        private modalService: ModalService,
        private logging: LoggingService,
        private rsaEncryptService: RsaEncryptService,
        private navParam: NavParams,
        private confirmUtil: ConfirmUtil,
        private labelService: LabelService,
        private errorMessageService: ErrorMessageService,
        private creditCardAction: CreditCardAction
    ) {
        super();
        this.state = this.store.getState();
        this.sameHolderList = this.navParam.get('sameHolderList');
        this.isSignShow = this.state.submitData.identificationCode === IdentificationCode.CODE_99;
        this.isW9Show = this.state.submitData.isSsnWrite === SsnWrite.YES;
        this.isFatcaShow = this.state.submitData.isSsnWrite && this.state.submitData.isSsnWrite !== SsnWrite.YES;
        this.originSubmitData = this.state.submitData;
    }

    /**
     * 画面初期化
     */
    public ngOnInit() {
        this.action.setStateSubmitDataValue({
            name: 'zipCode',
            value: this.state.submitData.firstZipCode + this.state.submitData.lastZipCode
        });

        this.initShowData();

        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.confirmPageCommonParams = this.confirmPageCommonService.getShowChatParams();
        this.initPageData();
        this.registerSignalHandlers();

        this.action.submitDataBackup();

        this.action.clearForeignIdentificationDocument();

        this.bottonTitle = this.labels.existingSavings.clerk.nextButton; // 認証する
        this.topMessage = this.labels.existingSavings.clerk.description3; // 申し込み
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.bottonTitle = this.labels.change.confirm.button; // 次へ
            this.topMessage = this.labels.existingSavings.clerk.description4; // 次へ

        }
    }

    // 18以上の場合は、BC申込欄を表示
    public get isBcShow() {
        // 特別永住者証明書 or 在留カードの区分が永住者
        let isRightDoc = false;
        if (
            this.state.submitData.identificationDocType === '02' ||
            (
                this.state.submitData.identificationDocType === '01' &&
                this.state.submitData.residenceStatus === ForeignResidenceCode.PermanentResident
            )
        ) {
            isRightDoc = true;
        }
        // 18未満
        const isBlow18 = !InputUtils.validateAge(this.state.submitData.birthdate, Age.Age_18,
            this.state.submitData.tabletStartDate);
        return !isBlow18 && isRightDoc ? true : false;
    }
    // 書類撮影区分
    public setDocumentShootingStatus() {
        const imageEnrollmentCertificate: boolean = this.state.submitData.imageEnrollmentCertificate
            && this.state.submitData.imageEnrollmentCertificate.length;
        const imageSchoolName: boolean = this.state.submitData.imageSchoolName
            && this.state.submitData.imageSchoolName.length;
        const isUSArmy = this.state.submitData.isUSArmy;
        let documentShootingStatus: string;
        // 職業が米軍のみの場合(isUSArmyが「1」の時)、「1：お勤め先」を設定する
        if (isUSArmy === '1') {
            documentShootingStatus = DocShootingStatus.SHOOTING_IMG_OFFICE;
        } else {
            // 上記以外はお勤め先＋通学先⇒３、お勤め先⇒１、通学先⇒２、撮影なし⇒０
            documentShootingStatus = imageEnrollmentCertificate && imageSchoolName ? DocShootingStatus.SHOOTING_IMG_SCHOOL_AND_OFFICE
                : imageEnrollmentCertificate ? DocShootingStatus.SHOOTING_IMG_OFFICE
                : imageSchoolName ? DocShootingStatus.SHOOTING_IMG_SCHOOL
                : DocShootingStatus.SHOOTING_NO_IMG;
        }
        return documentShootingStatus;
    }

    // 在籍証明資料
    public setCertificateOfEnrollment() {
        const imageEnrollmentCertificate: boolean = this.state.submitData.imageEnrollmentCertificate
            && this.state.submitData.imageEnrollmentCertificate.length;
        const imageSchoolName: boolean = this.state.submitData.imageSchoolName
            && this.state.submitData.imageSchoolName.length;
        let certificateOfEnrollment = null;

        if (this.state.submitData.identificationDocType === IdInfoDocType.TYPE_US_TROOPS &&
            this.state.submitData.occBusiness === ForeignHolderCareerCode.US_TROOPS) {
            certificateOfEnrollment = CertificateOfEnrollment.USARMYID;
        } else if (this.state.submitData.identificationDocType === IdInfoDocType.TYPE_US_TROOPS) {
            certificateOfEnrollment = imageEnrollmentCertificate && imageSchoolName ?
                CertificateOfEnrollment.USARMYID_SCHOOL_WOPK_PLACE : imageEnrollmentCertificate ?
                CertificateOfEnrollment.USARMYID_WOPK_PLACE : imageSchoolName ?
                CertificateOfEnrollment.USARMYID_SCHOOL : CertificateOfEnrollment.USARMYID;
        } else {
            certificateOfEnrollment = imageEnrollmentCertificate && imageSchoolName ?
                CertificateOfEnrollment.SCHOOL_AND_WOPK_PLACE_CERTIFICATE : imageEnrollmentCertificate ?
                CertificateOfEnrollment.WOPK_PLACE_CERTIFICATE : imageSchoolName ?
                CertificateOfEnrollment.SCHOOL_CERTIFICATE : null;
        }
        return certificateOfEnrollment;
    }

    public onChangeExistingAccount(info) {
        // 名寄せで何かを選択して、送信する
        this.selectExistingAccount = true;

        this.action.changeExistingAccount(info.existingAccount);
        this.action.updateSubmitDataBackup([{
            key: 'existingAccount',
            value: info.existingAccount
        }]);
    }

    /**
     * 画面破壊
     */
    public ngOnDestroy(): void {
        this.unregisterSignalHandlers();
    }

    /**
     * データをサブミットする
     */
    public submit() {
        // BC複合の考慮で「書類撮影区分」「在籍証明資料」をsubmitdata配下に保管
        this.action.setStateSubmitDataValue ({name: 'documentShootingStatus', value: this.setDocumentShootingStatus()});
        this.action.setStateSubmitDataValue ({name: 'certificateOfEnrollment', value: this.setCertificateOfEnrollment()});
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.navCtrl.push(CreditCardConfirmComponent,
                {
                    submitData: this.state.submitData,
                    tabletApplyId: this.loginStore.getState().tabletApplyId,
                    pageIndex: 0,
                    accountType: this.state.submitData.accountType,
                    customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                    cardInfo: this.state.submitData.cardInfo,
                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                });
        } else {
            this.submitted = true;
            this.store.registerSignalHandler(SavingsSignal.SUCCESS_INSERT_INFO, (result) => {
                this.store.unregisterSignalHandler(SavingsSignal.SUCCESS_INSERT_INFO);
                if (result.resultCode === HostResultCode.SUCCESS) {
                    this.presentModal(result);
                } else {
                    this.errorMessageService.showMessageModal(this.labelService.labels.common.error.host.applyErrorMessage, () => {
                        this.navCtrl.setRoot(TopComponent);
                        this.action.clearStore();
                    });
                }
            });
            this.action.submitTimeSavingOrangeApplyInfo(this.processSubmitData());
            this.logging.saveCustomOperationLog(
                this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
                this.labels.logging.AccountConfirm.confirmButton,
            );
        }
    }

    public presentModal(result: any) {
        const buttonList = [
            { text: this.labels.alert.backToTopBtn, buttonValue: COMMON_CONSTANTS.BACK_TYPE_TOP }
        ];
        this.modalService.showInfoAlert(
            this.labels.alert.applyCompletionTitle,
            buttonList,
            () => {
                this.navCtrl.setRoot(TopComponent);
            },
            null,
            false,
            COMMON_CONSTANTS.CSS_MODAL_W_480
        );
    }

    public processSubmitData() {
        let documentParam = null;

        switch (this.state.submitData.identificationDocType) {
            case IdInfoDocType.TYPE_RESIDENCE_CARD:
                documentParam = {
                    // 本人確認資料1
                    idInfoDoc1: this.state.submitData.identificationDocument1,
                    // 本人確認資料2
                    idInfoDoc2: this.state.submitData.identificationDocument2,
                    // 本人確認書類１有効期限
                    identityDocument1ExpirationDate: this.state.submitData.identityDocument1ExpirationDate,
                    // 本人確認書類２有効期限
                    identityDocument2ExpirationDate: this.state.submitData.identityDocument2ExpirationDate,
                    // 現住所確認書類有効期限
                    addressConfirmationDocumentExpirationDate: this.state.submitData.addressConfirmationDocumentExpirationDate,
                    // 本人確認書類1（画像ファイル）
                    imageDoc1: this.state.submitData.identificationDocument1Images,
                    // 本人確認書類2（画像ファイル）
                    imageDoc2: this.state.submitData.identificationDocument2Images,
                    // 本人現住所確認書類（画像ファイル）
                    imageAddressDoc: this.state.submitData.identificationAddressImages,
                    // 通勤先在籍書類
                    imageEnrollmentCertificate: this.state.submitData.imageEnrollmentCertificate,
                    // 通学先在籍書類
                    imageSchoolName: this.state.submitData.imageSchoolName,
                    // お勤め先
                    workPlace: this.state.submitData.workPlace,
                };
                break;
            case IdInfoDocType.TYPE_PERMANENT_RESIDENT:
                documentParam = {
                    // 本人確認資料1
                    idInfoDoc1: this.state.submitData.identificationDocument1,
                    // 本人確認資料2
                    idInfoDoc2: this.state.submitData.identificationDocument2,
                    // 本人確認書類１有効期限
                    identityDocument1ExpirationDate: this.state.submitData.identityDocument1ExpirationDate,
                    // 本人確認書類２有効期限
                    identityDocument2ExpirationDate: this.state.submitData.identityDocument2ExpirationDate,
                    // 現住所確認書類有効期限
                    addressConfirmationDocumentExpirationDate: this.state.submitData.addressConfirmationDocumentExpirationDate,
                    // 本人確認書類1（画像ファイル）
                    imageDoc1: this.state.submitData.identificationDocument1Images,
                    // 本人確認書類2（画像ファイル）
                    imageDoc2: this.state.submitData.identificationDocument2Images,
                    // 本人現住所確認書類（画像ファイル）
                    imageAddressDoc: this.state.submitData.identificationAddressImages,
                    // 在留期間満了日 = 顧客が入力した特別永住者証明書の有効期限
                    residenceExpirationDate: this.state.submitData.identityDocument1ExpirationDate,
                    // 通勤先在籍書類
                    imageEnrollmentCertificate: this.state.submitData.imageEnrollmentCertificate,
                    // 通学先在籍書類
                    imageSchoolName: this.state.submitData.imageSchoolName,
                    // お勤め先
                    workPlace: this.state.submitData.workPlace,
                };
                break;
            case IdInfoDocType.TYPE_US_TROOPS:
                documentParam = {
                    // 本人確認資料1
                    idInfoDoc1: this.state.submitData.identificationDocument2,
                    // 本人確認資料2
                    idInfoDoc2: null,
                    // 在留期間満了日 = 顧客が入力した米軍IDの有効期限
                    residenceExpirationDate: this.state.submitData.identityDocument1ExpirationDate,
                    // 本人確認書類１有効期限 = 顧客が入力したパスポートの有効期限
                    identityDocument1ExpirationDate: this.state.submitData.identityDocument2ExpirationDate,
                    // 本人確認書類２有効期限
                    identityDocument2ExpirationDate: null,
                    // 現住所確認書類有効期限
                    addressConfirmationDocumentExpirationDate: this.state.submitData.addressConfirmationDocumentExpirationDate,
                    // 米軍IDの画像+通勤先在籍書類
                    imageEnrollmentCertificate: this.state.submitData.imageEnrollmentCertificate ?
                        this.state.submitData.identificationDocument1Images.concat(this.state.submitData.imageEnrollmentCertificate) :
                        this.state.submitData.identificationDocument1Images,
                    // 本人確認書類1（画像ファイル） = パスポートの写真
                    imageDoc1: this.state.submitData.identificationDocument2Images,
                    // 本人確認書類2（画像ファイル）
                    imageDoc2: null,
                    // 本人現住所確認書類（画像ファイル）
                    imageAddressDoc: this.state.submitData.identificationAddressImages,
                    // お勤め先
                    workPlace: this.state.submitData.isUSArmy && this.state.submitData.isUSArmy === '1'
                        ? this.state.submitData.workPlace = this.labels.confirm.americanSuggestionInfoLabel.usMilitary
                        : this.state.submitData.workPlace,
                    // 通学先在籍書類
                    imageSchoolName: this.state.submitData.imageSchoolName,
                };
                break;
            default:
        }

        // 米国人示唆情報
        const fatcaStasus = this.confirmUtil.getFatcaStatusTextFor(
            this.state.submitData.nationalityCode, this.state.submitData.isGreenCardHave);

        return {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            openAccountParams: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                eyeCueNo: this.state.submitData.receptionNumber,
                bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
                operatorName: this.loginStore.getState().clerkInfo.operatorName,
                hasChange: '0',
                // BC申込データ
                ifApplyBc: '0',    // BC申込無
                // 顧客情報
                customerInfos: [
                    {
                        ...this.state.submitData,
                        schoolName: this.state.submitData.attendingSchoolName,
                        nameDifferenceFlag: this.state.submitData.isDifferenceKanji,
                        passcode: this.rsaEncryptService.encrypt(this.state.submitData.firstPwd4bits),
                        occBusiness: this.state.submitData.occBusiness ? this.state.submitData.occBusiness.split('、') : undefined,
                        accountOpeningPurpose: this.state.submitData.accountOpeningPurpose ?
                            this.state.submitData.accountOpeningPurpose.split('、') : undefined,
                        w9SocialSecurityNo: this.state.submitData.w9SocialSecurityNo ?
                            this.state.submitData.w9SocialSecurityNo.replace(/\-/g, '') : undefined,
                        receptionTenban: this.loginStore.getState().belongToBranchNo,
                        accountOpeningBranchCode: this.state.submitData.existingAccount ?
                            this.state.submitData.existingAccount.branchNo : this.state.submitData.tenban,
                        prefecture: this.state.submitData.holderAddressPrefecture,
                        countyUrbanVillage: this.state.submitData.holderAddressCountyUrbanVillage,
                        street: this.state.submitData.getHolderAddressStreetName(),
                        prefectureKana: this.state.submitData.holderAddressPrefectureFuriKana,
                        countyUrbanVillageKana: this.state.submitData.holderAddressCountyUrbanVillageFuriKana,
                        streetKana: this.state.submitData.getHolderAddressStreetNameFuriKana(),
                        subAddressKana: this.state.submitData.holderAddressHouseNumberFuriKana,
                        subAddress: this.state.submitData.holderAddressHouseNumber,
                        residenceFlagJapanOnly: this.state.submitData.residenceOnlyJapan,
                        // 本人代理人区分 0：本人
                        principalAgentCategory: '0',
                        // 行員ID
                        bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
                        // オペレータ氏名
                        operatorName: this.loginStore.getState().clerkInfo.operatorName,
                        signatureCrs: this.state.submitData.sign,
                        menuCode: '05',
                        receiptMethod: this.state.submitData.receiptMethod || CodeCategory.RECEIPT_METHOD_MAIL,
                        w9CountryNameAlphabet: this.state.submitData.agentCountryEnglish === COMMON_CONSTANTS.OTHER_COUNTRY_NAME ?
                            this.state.submitData.w9CountryNameAlphabet : this.state.submitData.agentCountryEnglish,
                        residenceStatus: this.state.submitData.residenceStatusText,
                        customerId: this.state.submitData.existingAccount ? this.state.submitData.existingAccount.customerId : undefined,
                        eyeCueNo: this.state.submitData.receptionNumber,
                        residenceCountryName: this.state.submitData.residenceCountryName || '0100',   // 日本
                        nameKanji: this.state.submitData.firstNameKanji && this.state.submitData.lastNameKanji ?
                            this.state.submitData.firstNameKanji + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKanji : null,
                        nameKana:
                            this.state.submitData.firstNameKana + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKana,
                        nameAlphabet:
                            this.state.submitData.firstNameAlphabet + COMMON_CONSTANTS.SPACE + this.state.submitData.lastNameAlphabet,
                        bankCardSuicaFlag: this.state.submitData.bankCardSuicaFlag === IsBankCardSuicaSelected.IS_SELECTED ||
                            this.state.submitData.bankCardSuicaGoldFlag === IsBankCardSuicaGoldSelected.IS_SELECTED ?
                            IsBankCardSuicaSelected.IS_SELECTED : IsBankCardSuicaSelected.IS_NOT_SELECTED,
                        ...documentParam,
                        isNeedPassbook: this.state.submitData.isNeedPassbook, // 通帳発行するかどうか　１：発行　０：発行しない
                        // 米国人示唆情報、　this.state.submitData.w9AmericanSuggestionInfo,の利用は廃止する。
                        w9AmericanSuggestionInfo: fatcaStasus.americanSuggestionInfo,
                    }
                ]
            }
        };
    }

    /**
     * リスナーを初期化する
     */
    public registerSignalHandlers() {
        this.store.registerSignalHandler(SavingsSignal.NEED_UPDATE_SHOW_CHATS, () => {
            this.state.showConfirm.forEach((item) => {
                if (item.type !== COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE) {
                    this.saveShowChats[item.name] = item;
                }
            });
        });
    }

    /**
     * リスナーをアンインストールする
     */
    public unregisterSignalHandlers() {
        this.store.unregisterSignalHandler(SavingsSignal.SUCCESS_INSERT_INFO);
        this.store.unregisterSignalHandler(SavingsSignal.TABLET_APPLY_INSERT_SUCCESS);
        this.store.unregisterSignalHandler(SavingsSignal.SET_DUPLICATE_ACCOUNT_INFO);
        this.store.unregisterSignalHandler(SavingsSignal.NEED_UPDATE_SHOW_CHATS);
    }

    /**
     * 前遷移画面を設定する
     */
    public backToInfoConfirmPage() {
        this.isBackToCustomerConfirmPage = true;
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    // 申込画面に戻るので、マスキング未確認オブジェクトをクリア
                    this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.CLEAR);
                    this.clearConfirmPageInfo();
                    if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
                        this.creditCardAction.clearConfirmPageInfo();
                        // バックアップした運転免許証番号、学生証、連絡事項をクリア
                        this.creditCardAction.clearCopyComplexTransConfirmInfos();
                    }
                    this.navCtrl.setRoot(ExistingSavingsForeignInitConfirmComponent)
                        .then(() => this.action.resetSubmitData());
                    this.logging.saveCustomOperationLog(
                        this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
                        this.labels.logging.AccountConfirm.backConfirmButton,
                    );
                } else {
                    this.isBackToCustomerConfirmPage = false;
                }
            }
        );
    }

    /**
     * 入力チェック結果を返す
     */
    public get disableFooterButton(): boolean {
        // 名寄せ候補がある場合、名寄せリストに何も選択しない場合、trueになる、非活性になる
        const hasExAndSelect = this.state.duplicateAccountInfos && this.state.duplicateAccountInfos.length > 0
            && !this.selectExistingAccount;

        // 非活性の条件
        // 受付番号存在しない　まだ　本人確認component存在するかつチャックボックス存在かつチェックボックスが選択されない
        // もしくは　口座開設店舗の確認がチェックされてない
        // または名寄せ候補が11件以上存在する場合
        return !this.state.submitData.receptionNumber
            || (this.identityDocumentConfirmForeignComponent &&
                this.identityDocumentConfirmForeignComponent.isShowCheckboxBlock() && !this.state.checkboxStatus.isAllMaskingStatus)
            || !this.state.checkboxStatus.isCheckBranchStatus
            || hasExAndSelect;
    }

    /**
     * 申込内容確認へ戻る
     */
    public clearConfirmPageInfo() {
        this.action.setStateData({ submitData: this.originSubmitData });
        this.action.clearConfirmPageInfo();
        this.action.setStateSubmitDataValue([{
            name: 'isModify',
            value: '2'
        }]);
    }

    /**
     * 修正ボタン Emitハンドラー
     * @param params params
     */
    public showChatComponentHandler(params: ShowChartParam) {
        console.log(params);
    }

    /**
     * 重複口座情報をセットする
     * @param event 重複口座情報
     */
    public getDuplicateAccountInfo(event: any) {
        this.store.registerSignalHandler(SavingsSignal.SET_DUPLICATE_ACCOUNT_INFO, () => {
            if (this.accountSelected) {
                this.getDuplicateAccountValid();
            }
        });
        this.action.setDuplicateAccountInfo(event);
    }

    /**
     * 顔写真のある本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedEmitter(event?: any) {
        this.insertImageType = event || this.insertImageType;
    }

    /**
     * 顔写真のない本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedNoFaceEmitter(event?: any) {
        this.insertImageTypeNoFace = event || this.insertImageTypeNoFace;
    }

    /**
     * handle accountSelectedEmitter
     */
    public handleAccountSelectedEmitter(accountSelected: boolean) {
        this.accountSelected = accountSelected;
        this.accountSelected ? this.getDuplicateAccountValid() : this.duplicateAccountValid = true;
    }

    /**
     * 重複口座情報の有効性をチェックする
     */
    public getDuplicateAccountValid() {
        this.duplicateAccountValid = this.state.submitData.redundantReason ? true : false;
    }

    /**
     * 総合口座文言表示フラグ設定
     */
    public hasComprehensiveDisplay(): boolean {
        if (this.duplicateAccountValid && this.state.submitData.hasComprehensive &&
            (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS)) {
            return true;
        }
        return false;
    }

    public onEditIdentityDocument() {
        const backup = Object.assign(new SubmitEntity(), this.state.submitData);

        // 修正の場合
        this.action.setStateSubmitDataValue({
            name: 'isModify',
            value: '1'
        });

        const options = {
            component: 'ForeignerCheckapplyComponent',
            process: -1,
            clear: false,
            submitData: {
                ...this.state.copySubmitData,
                ...this.state.confirmPageChanges,
                isModify: this.state.submitData.isModify,
                contactNote: this.state.submitData.contactNote,
                identificationStudentImages: this.state.submitData.identificationStudentImages
            }
        };
        const modal = this.modalCtrl.create(ChatComponent, {
            options,
            isCurrentPage: true,
            currentTitle: '本人確認書類'
        }, {
            cssClass: 'full-modal'
        });

        modal.onDidDismiss((state: any) => {
            if (state && state !== COMMON_CONSTANTS.DIMISS_CLOSE_VALUE) {
                // 本人確認画面が終わったら、maskingチェックボックスをリセット
                this.clearMaskingCheckBox();
                this.action.setStateData(state);
                this.state.showConfirm.forEach((item) => {
                    if (item.type !== COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE) {
                        this.saveShowChats[item.name] = item;
                    }
                });
                // 最新の写真によってマスキング未確認データをセットする
                this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.DOCUMENT);

                // チャットフロー上で「申込内容確認へ戻る」ボタンが選択された場合、申込画面へ戻る
                if (state.submitData.continueOrBackToConfirm === ContinueOrBackToConfirm.BACK_TO_CONFIRM) {
                    this.backToConfirm();
                }
            } else {
                this.state.submitData = backup;
            }
        });

        modal.present();
    }

    /**
     * 確認書類の写真だけを撮り直す
     *
     * @param {string} type
     * @memberof AccountComponent
     */
    public onReTakeIdentityDocument(params: { type: string, imgDocumentName: string }) {
        const config: any = {
            name: 'reimg',
            currentTitle: this._labels.confirm.reTakeDocument,
            pageIndex: 0,
            isCurrentPage: true
        };

        const modal = this.modalCtrl.create(CommonBusinessChatComponent, {
            businessType: CommonBusinessType.ReImg,
            ...config
        }, {
            cssClass: 'full-modal'
        });
        modal.present();
        modal.onDidDismiss((data) => {
            // 「戻る」以外によってダイアログを閉じる場合
            if (data !== 'close') {
                if (params.type === LicensePhotoType.DOCUMENT) {
                    // OCR以外の書類
                    // imgDocumentNameによって特定な写真を入れ替わる
                    this.action.editSomeDataInSubmitData(undefined,
                        params.imgDocumentName,
                        data.identityDocument);

                    this.clearMaskingCheckBox();
                    this.action.resetSpecialNotMaskingConfirmImages(params.imgDocumentName);
                }
            }
        });
    }

    /**
     * 画像をクリックしたら画像修正モーダル開き
     *
     * @param {{ index: number, fieldName: string, value: string }} data
     * @memberof AccountComponent
     */
    public onImageMaskingComplete(data: { index: number, fieldName: string, value: string }) {
        this.action.editSomeDataInSubmitData(data.index, data.fieldName, data.value);
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.action.modifyCheckboxStatus(checboxItem);
    }

    public onChangeReceptionNumber(data) {
        data.forEach((element) => {
            this.action.setStateSubmitDataValue({
                name: element.key,
                value: element.value
            });
        });
        this.action.updateSubmitDataBackup(data);
    }

    public onChangeBranchTenpo(value) {
        if (value) {
            const changeArr = new Array();
            for (const key in value) {
                changeArr.push({
                    key: key,
                    value: value[key]
                });
            }
            this.action.setStateSubmitDataValue(changeArr);
        }
    }

    public onChangeOpenStore(data) {
        this.action.changeOpenStore(data);
        this.action.updateSubmitDataBackup([
            {
                key: 'branchName',
                value: data.branchName || data.branchNameKanji
            }, {
                key: 'tenban',
                value: data.tenban || data.branchNo
            }, {
                key: 'existingAccount',
                value: undefined
            }
        ]);
        this.action.upDateBackUp(data);
    }

    /**
     * 在留カードの場合
     */
    public isResidenceCard() {
        return this.state.submitData.identificationDocType === IdInfoDocType.TYPE_RESIDENCE_CARD;
    }

    public onMaskingConfirmEmmiterHandler(imageInfo: { documentName: string, index: number }) {
        this.action.removeNotMaskingConfirmImages(imageInfo);
    }

    public filterInquiry() {
        const prefecture = this.state.submitData.holderAddressPrefecture ? this.state.submitData.holderAddressPrefecture : '';
        const countyUrbanVillage = this.state.submitData.holderAddressCountyUrbanVillage
            ? this.state.submitData.holderAddressCountyUrbanVillage : '';
        const streetName = this.state.submitData.showStreet
            ? this.state.submitData.showStreet : this.state.submitData.getHolderAddressStreetName();
        const addressHouseNumber = this.state.submitData.holderAddressHouseNumber ? this.state.submitData.holderAddressHouseNumber : '';

        // submitData.lastNameKanaにミドルネームがあれば、分割する
        let lastNameKana = this.state.submitData.lastNameKana;
        let middleNameKana = '';
        const firstSpaceIndex = this.state.submitData.lastNameKana.indexOf(COMMON_CONSTANTS.FULL_SPACE);
        if (this.state.submitData.lastNameKana && firstSpaceIndex !== -1) {
            // submitData.lastNameKana存在かつsubmitData.lastNameKanaに全角スペースある場合
            // 名とミドルネームを分割
            lastNameKana = this.state.submitData.lastNameKana.substring(0, firstSpaceIndex);
            middleNameKana = COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKana.substring(firstSpaceIndex + 1);
        }
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                nameKanji: this.state.submitData.firstNameKanji && this.state.submitData.lastNameKanji ?
                    this.state.submitData.firstNameKanji + COMMON_CONSTANTS.HALF_AT + this.state.submitData.lastNameKanji : null,
                nameKana:
                    this.state.submitData.firstNameKana + middleNameKana + COMMON_CONSTANTS.HALF_AT + lastNameKana,
                nameAlphabet:
                    this.state.submitData.firstNameAlphabet + COMMON_CONSTANTS.SPACE + this.state.submitData.lastNameAlphabet,
                birthdate: this.state.submitData.birthdate,
                // birthdate: '19880101',
                address: prefecture + countyUrbanVillage + streetName + addressHouseNumber,
                bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
                // bankClerkId: '1111111',
            }
        };

        const curFilteringParamters = new FilteringParameterEntity();
        curFilteringParamters.nameKanji = param.params.nameKanji;
        curFilteringParamters.nameKana = param.params.nameKana;
        curFilteringParamters.nameAlphabet = param.params.nameAlphabet;
        curFilteringParamters.birthdate = param.params.birthdate;

        // 前回のパラメータと比較
        const isChanged = this.confirmUtil.isFilteringParameterChanged(this.state.lastFilteringParameter, curFilteringParamters);
        this.store.registerSignalHandler(SavingsSignal.FILTERING_INQUIRY, (data) => {
            this.store.unregisterSignalHandler(SavingsSignal.FILTERING_INQUIRY);
            this.action.updateSubmitDataBackup(data);
        });
        if (isChanged) {
            this.action.filterInquiry(param);
            // 今回のパラメータを保存
            this.action.setLastFilteringParameters(curFilteringParamters);
        } else {
            // 前回のフィルタリング照会結果を表示変数に渡す
            this.action.setLastFilteringResult(this.state.lastFilteringResult);
        }
    }

    /**
     * 画面の表示データを初期化する
     */
    private initShowData() {
        // 画面の表示データを初期化する
        this.state.showConfirm.forEach((item) => {
            if (item.type !== COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE) {
                this.saveShowChats[item.name] = item;
            }
        });
    }

    /**
     * 画面データ初期化する
     */
    private initPageData() {
        // 行員登録画面に遷移するとき、入力する行員IDを記録する
        this.action.setBankclerkId(this.modalDigitalStore.getState().bankclerkId);
        // 取次店番を記録する
        this.action.setAgencyBranchInfo(this.loginStore.getState().belongToBranchNo);
        // 受付店を口座開設店として記録する
        this.action.setBranchInfo(this.loginStore.getState().belongToBranchName, this.loginStore.getState().belongToBranchNo);
        // 行員認証開始時間を記録する
        this.action.setBankclerkAuthenticationStartDate();

        // 行員登録画面に遷移するとき、入力する行員IDを記録する
        this.action.setBankclerkId(this.modalDigitalStore.getState().bankclerkId);
    }

    /**
     * ページのタイトル
     */
    public get headerTitle(): string {
        if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
            return this.labels.existingSavings.title;
        } else if (this.state.submitData.accountType === AccountType.EXISTING_STORAGE) {
            return this.labels.existingStorage.title;
        } else if (this.state.submitData.accountType === AccountType.FOREIGN_SAVINGS) {
            return this.labels.existingSavings.title;
        }
    }

    /**
     * 画面の入力するチェック
     */
    private checkInputValidation(): boolean {
        const submitData = this.state.submitData;

        let validationResult = this.checkIdentityDocumentsValidation();

        if (validationResult && submitData.holderIdentityDocumentNoCopyReason) { // コピー徴求ができない理由
            validationResult = StringUtils.validateZenkaku(submitData.holderIdentityDocumentNoCopyReason);
        }

        if (validationResult && submitData.holderNoCopyReason) { // コピー徴求ができない理由
            validationResult = StringUtils.validateZenkaku(submitData.holderNoCopyReason);
        }

        return validationResult;
    }

    /**
     * 本人確認書類チェック
     */
    private checkIdentityDocumentsValidation(): boolean {
        if (this.state.submitData.holderIdentityDocumentType && !this.submitted) {
            // 顔写真のある本人確認の画像登録
            if (this.state.identityDocuments && this.state.identityDocuments.length > 0) {
                return true;
            }

            // 顔写真のある本人確認のテキスト登録
            if (this.state.submitData.holderNoCopyReason || this.state.submitData.holderPublisher ||
                this.state.submitData.holderPublishDate || this.state.submitData.holderSignNo) {
                return true;
            }

            // 顔写真のない本人確認の画像登録
            if (this.state.additionalInfoDocuments && this.state.additionalInfoDocuments.length > 0) {
                return true;
            }

            // 顔写真のない本人確認のテキスト登録
            if (this.state.submitData.holderIdentityDocumentNoCopyReason || this.state.submitData.holderIdentityDocumentPublisher ||
                this.state.submitData.holderIdentityDocumentPublishDate || this.state.submitData.holderIdentityDocumentSignNo) {
                return true;
            }
        }

        return false;
    }

    private clearMaskingCheckBox() {
        // 本人確認画面が終わったら、maskingチェックボックスをリセット
        if (this.state.checkboxStatus.isAllMaskingStatus) {
            this.action.modifyCheckboxStatus(MaskingCheckboxName.MASKING_CHECKBOX_NAME);
        }
    }

    private hasExistingMobilePhoneNumber(): string {

        const { holderTelNo1, holderTelNo2, holderTelNo3 } = this.state.submitData.existingAccount;

        if (holderTelNo1 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo1)) {
            return Constants.HAS_EXISTS_MOBILE_NO;
        }
        if (holderTelNo2 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo2)) {
            return Constants.HAS_EXISTS_MOBILE_NO;
        }
        if (holderTelNo3 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo3)) {
            return Constants.HAS_EXISTS_MOBILE_NO;
        }

        return Constants.NO_EXISTS_MOBILE_NO;
    }

    /**
     * 申込確認画面へ戻る
     */
    private backToConfirm() {
        // 申込画面に戻るので、マスキング未確認オブジェクトをクリア
        this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.CLEAR);
        this.clearConfirmPageInfo();
        this.navCtrl.setRoot(ExistingSavingsForeignInitConfirmComponent)
            .then(() => this.action.resetSubmitData());
    }
}
