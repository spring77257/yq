export class CheckboxStatusForeignEntity {
    public receiptMethodStatus: boolean;  // カードお受取方法 checkbox
    public confirmationStatus: boolean;  // 契約状況確認
    public isAntisocialStatus: boolean;  // 反社会的勢力
    public isForeignPulicFiguresSatus: boolean;  // 外国の重要な公的地位にある者
    public isJapaneseResidentStatus: boolean;  // 日本居住者です
    public isRegulationStatus: boolean;
    public isTransactionStatus: boolean; // 口座の売買
}
