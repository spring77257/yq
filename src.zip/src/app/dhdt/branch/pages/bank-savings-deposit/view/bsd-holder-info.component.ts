import { Component } from '@angular/core';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { SavingsSignal } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { ConfirmPageBaseComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/common/confirm-page-base.component';
import { BsdAgentConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/savings/bsd-agent-confirm.component';
import { AccountType, COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { NavController, NavParams, ViewController } from 'ionic-angular';

@Component({
    selector: 'bsd-holder-info-component',
    templateUrl: 'bsd-holder-info.component.html'
})

/**
 * Bsd holder info component(行員認証画面（代理人）ー 本人情報).
 */
export class BsdHolderInfoComponent extends ConfirmPageBaseComponent {
    // ログイン button タン押下時の二重リクエスト防止
    public isBacking = false;

    constructor(
        public navCtrl: NavController, public modalService: ModalService,
        public navParam: NavParams, public viewCtrl: ViewController) {
        super(navCtrl, modalService, navParam, viewCtrl);
    }

    public submitProcessedData(submitData: any) {
        this.action.saveSubmitData(submitData);
    }

    public processSubmitData(): any {
        return this.commitDataProcessUtils.processOrdinarySavingsSubmitData(this.state);
    }

    public pushNextPage() {
        this.saveOperationLog(this.labels.logging.AccountConfirm.confirmButton);
        this.store.registerSignalHandler(SavingsSignal.SUCCESS_INSERT_INFO, () => {
            this.presentModal();
        });
    }

    public presentModal() {
        const buttonList = [
            { text: this.labels.alert.backToTopBtn, buttonValue: COMMON_CONSTANTS.BACK_TYPE_TOP }
        ];
        this.modalService.showInfoAlert(
            this.labels.alert.applyCompletionTitle,
            buttonList,
            () => {
                this.navCtrl.setRoot(TopComponent);
            },
            null,
            false,
            COMMON_CONSTANTS.CSS_MODAL_W_480
        );
    }

    // click 申込内容確認へ戻る button
    public backConfirmClick() {
        this.isBacking = true;
        this.saveOperationLog(this.labels.logging.AccountConfirm.backConfirmButton);
        this.clearConfirmPageInfo();
        this.navCtrl.setRoot(BsdAgentConfirmComponent);
    }

    public onChangeOpenStore(data) {
        this.action.changeOpenStore(data);
    }

    /**
     * 貯蓄預金判断
     */
    public isStorage(): boolean {
        return this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT_SAVINGS_DIPOSIT ? true : false;
    }

}
