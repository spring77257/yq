import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { DeviceService } from 'dhd/common/services/device.service';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { SavingsSignal, SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelSubmitEntity } from 'dhdt/branch/pages/cancel/entity/cancel-submit.entity';
import { CancelState, CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';
import { CancelChatComponent } from 'dhdt/branch/pages/cancel/view/cancel-chat.component';
import {
    AccountType, ApplyBC, ClearSavingImagesClickRecordType, COMMON_CONSTANTS,
    Constants, ContinueOrBackToConfirm, HasDriversCareerLicense, HasLicense, IdentificationCode, PrincipalAgentCategory, SearchMode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardChatComponent } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat.component';
import { CreditCardBrand } from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { ExistingReserveChatComponent } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat.component';
import { ExistingReserveState, ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { PRODUCT_TYPE } from 'dhdt/branch/pages/existing-reserve/utils/product-category-utils';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { ExistingSavingsChatComponent } from 'dhdt/branch/pages/existing-savings/chat-flow/existing-savings-chat.component';
import { ExistingSavingsState, ExistingSavingsStore } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { LossReissueFindingAction } from 'dhdt/branch/pages/loss-reissue-finding/action/loss-reissue-finding.action';
import { LossReissueFindingSubmitEntity } from 'dhdt/branch/pages/loss-reissue-finding/entity/loss-reissue-finding-questions.model';
import { LossReissueFindingConsts } from 'dhdt/branch/pages/loss-reissue-finding/loss-reissue-finding-consts';
import { LossReissueFindingState, LossReissueFindingStore } from 'dhdt/branch/pages/loss-reissue-finding/store/loss-reissue-finding.store';
import { LossReissueFindingChatComponent } from 'dhdt/branch/pages/loss-reissue-finding/view/loss-reissue-finding-chat.component';
import { NewestState, NewestStore } from 'dhdt/branch/pages/newest//store/newest.store';
import { NewestAction } from 'dhdt/branch/pages/newest/action/newest.action';
import { NewestSubmitEntity } from 'dhdt/branch/pages/newest/entity/newest-questions.model';
import { NewestConsts } from 'dhdt/branch/pages/newest/newest-consts';
import { NewestChatComponent } from 'dhdt/branch/pages/newest/view/newest-chat.component';
import { ReplacementState, ReplacementStore } from 'dhdt/branch/pages/replacement//store/replacement.store';
import { ReplacementAction } from 'dhdt/branch/pages/replacement/action/replacement.action';
import { ReplacementSubmitEntity } from 'dhdt/branch/pages/replacement/entity/replacement-questions.model';
import { ReplacementConsts } from 'dhdt/branch/pages/replacement/replacement-consts';
import { ReplacementChatComponent } from 'dhdt/branch/pages/replacement/view/replacement-chat.component';
import { StudentState, StudentStore } from 'dhdt/branch/pages/student/store/student.store';
import { ModalDigitalComponent } from 'dhdt/branch/shared/components/modal/modal-digital/view/modal-digital.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { LossReissueFindingUtil } from 'dhdt/branch/shared/utils/loss-reissue-finding-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { NavController } from 'ionic-angular';
import { ModalController } from 'ionic-angular/components/modal/modal-controller';

@Component({
    selector: 'completion-component',
    templateUrl: 'completion.component.html'
})

/**
 * Completion component(入力完了画面).
 */
export class CompletionComponent extends BaseComponent implements OnInit {
    public imgUrl = '';         // バックグラウンド画像Url
    private state: SavingsState;
    private creditCardState: CreditCardState;
    private lossReissueFindingState: LossReissueFindingState;
    private ReplacementState: ReplacementState;
    private newestState: NewestState;
    private existingReserveState: ExistingReserveState;
    private existingSavingsState: ExistingSavingsState;
    private studentState: StudentState;
    private savingsState: SavingsState;
    private cancelState: CancelState;

    private modalInfor = {
        title: this.labels.change.userConfirm,
        subTitle: this.labels.change.inputPassword,
        showInput: 'two-inputs',
        tabletApplyId: undefined
    };

    constructor(
        private modalCtrl: ModalController,
        private navCtrl: NavController,
        private action: SavingsAction,
        private store: SavingsStore,
        private audioService: AudioService,
        private logging: LoggingService,
        private creditCardStore: CreditCardStore,
        private lossReissueFindingStore: LossReissueFindingStore,
        private existingReserveStore: ExistingReserveStore,
        private existingSavingsStore: ExistingSavingsStore,
        private ReplacementStore: ReplacementStore,
        private newestStore: NewestStore,
        private loginStore: LoginStore,
        private deviceService: DeviceService,
        private studentStore: StudentStore,
        private savingsStore: SavingsStore,
        private lossReissueFindingUtil: LossReissueFindingUtil,
        private existingSavingsAction: ExistingSavingsAction,
        private lossReissueFindingAction: LossReissueFindingAction,
        private ReplacementAction: ReplacementAction,
        private newestAction: NewestAction,
        private creditCardAction: CreditCardAction,
        private cancelStore: CancelStore,
        private cancelAction: CancelAction
    ) {
        super();
        this.state = this.store.getState();
        this.creditCardState = this.creditCardStore.getState();
        this.lossReissueFindingState = this.lossReissueFindingStore.getState();
        this.existingReserveState = this.existingReserveStore.getState();
        this.existingSavingsState = this.existingSavingsStore.getState();
        this.studentState = this.studentStore.getState();
        this.savingsState = this.savingsStore.getState();
        this.ReplacementState = this.ReplacementStore.getState();
        this.cancelState = this.cancelStore.getState();
        this.newestState = this.newestStore.getState();
    }

    public ngOnInit(): void {
        if (this.creditCardState.submitData.accountType === AccountType.CREDIT_CARD) {
            this.action.setStateSubmitDataValue({
                name: 'accountType',
                value: AccountType.CREDIT_CARD
            });
        }
        console.log(this.state.submitData.accountType);

        // フローによって画像が変わる
        switch (this.state.submitData.accountType) {
            case AccountType.ORDINARY_DEPOSIT:
            case AccountType.ORDINARY_DEPOSIT_CHILDREN: // '2'
            case AccountType.ORDINARY_DEPOSIT_SAVINGS_DIPOSIT: // '3'
            case AccountType.TIME_SAVING: // '4'
            case AccountType.CANCEL: // '7'
            case AccountType.CASH_CARD:
            case AccountType.STUDENT_NEW:
            case AccountType.STUDENT_CHANGE:
            case AccountType.EXISTING_SAVINGS: // '9'
            case AccountType.EXISTING_STORAGE: // '13'
            case AccountType.AUTOMATIC_TRANSFER:
            case AccountType.TIME_DEPOSIT_REWRITING:
            case AccountType.FOREIGN_SAVINGS: // 14
            case AccountType.EXISTING_RESERVE: // '11'
            case AccountType.LOSS_REISSUE_FINDING:
            case AccountType.REPLACEMENT: // '18'
            case AccountType.NEWEST: // '19'
            case AccountType.CREDIT_CARD: { // '6'
                this.imgUrl = COMMON_CONSTANTS.FLOW_TYPE_INIT_CONFIRM;
                break;
            }
        }
    }

    /**
     * View did enter
     */
    public ionViewDidEnter() {
        this.audioService.subject.next(true);
    }

    public presentModal() {
        this.saveOperationLog();

        this.modalInfor.tabletApplyId = this.loginStore.getState().tabletApplyId;

        const modal = this.modalCtrl.create(
            ModalDigitalComponent,
            { data: this.modalInfor },
            { cssClass: 'two-inputs' }
        );
        modal.onDidDismiss((success) => {
            if (success) {
                for (const element of this.state.chatFlowInfo) {
                    if (element.accountType === this.state.submitData.accountType) {
                        if ((element.accountType === AccountType.ORDINARY_DEPOSIT
                            || element.accountType === AccountType.ORDINARY_DEPOSIT_CHILDREN
                            || element.accountType === AccountType.ORDINARY_DEPOSIT_SAVINGS_DIPOSIT
                            || element.accountType === AccountType.TIME_SAVING
                            || element.accountType === AccountType.EXISTING_SAVINGS
                            || (element.accountType === AccountType.EXISTING_RESERVE
                                && ((this.existingReserveState.submitData.identificationCode !== IdentificationCode.CODE_80
                                    && this.existingReserveState.submitData.identificationCode !== IdentificationCode.CODE_90)
                                    || this.existingReserveState.submitData.selectProductType === '02')
                            )
                            || element.accountType === AccountType.EXISTING_STORAGE
                            || element.accountType === AccountType.STUDENT_NEW
                            || element.accountType === AccountType.FOREIGN_SAVINGS
                            || element.accountType === AccountType.CREDIT_CARD) && element.params) {
                            let component: any;
                            let nameKana: string;
                            let birthdate: string;
                            let submitData: any;
                            let checkComponent: string = element.checkComponent;
                            let chatComponent: any = ChatComponent;

                            if (element.accountType === AccountType.EXISTING_SAVINGS
                                || element.accountType === AccountType.EXISTING_STORAGE) {
                                chatComponent = ExistingSavingsChatComponent;
                                submitData = this.existingSavingsState.submitData;
                                const isChanged = submitData.isNameChange || submitData.isAddressChange;
                                component = element.confirmPage[0];
                                if (submitData.existingChangeFlag === '1' || isChanged) {
                                    component = element.confirmPage[1];
                                }
                                if (submitData.ifApplyBC === ApplyBC.YES) {
                                    this.creditCardAction.backupOriginSubmitData();
                                }
                                // OCRが運転経歴証明書の場合、hasLicenseを復元
                                if (submitData.hasLicense === HasLicense.HAS_NOT_LICENSE
                                    && submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES) {
                                    this.existingSavingsAction.setStateSubmitDataValue([
                                        {
                                            key: 'hasLicense',
                                            value: Constants.DriveCard
                                        }
                                    ]);
                                }
                                // OCRの場合、画像を復元
                                // 運転経歴証明書の場合、クリアされた画像を復元
                                // 運転免許証/マイナンバーカードの場合、マスキング済み⇒もとに復元）
                                if (submitData.hasLicense === HasLicense.HAS_NOT_LICENSE
                                    && submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES
                                    || this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
                                    this.existingSavingsAction.setStateSubmitDataValue([
                                        {
                                            key: 'holderCardImageFront',
                                            value: this.savingsState.submitData.holderCardImageFront
                                        },
                                        {
                                            key: 'holderCardImageBack',
                                            value: this.savingsState.submitData.holderCardImageBack
                                        }
                                    ]);
                                }
                                // OCRの場合、有効期限をバックアップ
                                this.existingSavingsAction.backupOCRDueDate();
                                nameKana = this.existingSavingsState.submitData[element.params.nameKana as string];
                                birthdate = this.existingSavingsState.submitData[element.params.birthdate as string];
                            } else if (element.accountType === AccountType.EXISTING_RESERVE) {
                                chatComponent = ExistingReserveChatComponent;
                                submitData = this.existingReserveState.submitData;
                                component = this.existingReserveState.submitData.regularPurpose === '0' ?
                                    element.confirmPageSub : element.confirmPage;
                                nameKana = this.existingReserveState.submitData[element.params.nameKana as string];
                                birthdate = this.existingReserveState.submitData[element.params.birthdate as string];
                            } else if (element.accountType === AccountType.FOREIGN_SAVINGS) {
                                submitData = this.savingsState.submitData;
                                component = element.confirmPage;
                                nameKana = this.existingSavingsState.submitData[element.params.nameKana as string];
                                birthdate = this.existingSavingsState.submitData[element.params.birthdate as string];
                                if (this.savingsState.submitData.ifApplyBC === ApplyBC.YES) {
                                    // 本人確認書類チャットにて入力した情報をクリアする（本人確認書類1は申込チャットで選択しているため、クリアしない）
                                    const backupIdentificationDocument1 = this.state.submitData.identificationDocument1;
                                    const backupIdentificationDocument1Text = this.state.submitData.identificationDocument1Text;
                                    this.action.clearCreditCardConfirmPageInfo();
                                    this.action.setStateSubmitDataValue({
                                        name: 'identificationDocument1',
                                        value: backupIdentificationDocument1
                                    });
                                    this.action.setStateSubmitDataValue({
                                        name: 'identificationDocument1Text',
                                        value: backupIdentificationDocument1Text
                                    });
                                    this.creditCardAction.backupOriginSubmitData();
                                }
                            } else if (this.state.submitData.accountType === AccountType.CREDIT_CARD) {
                                chatComponent = CreditCardChatComponent;
                                submitData = this.creditCardState.submitData;
                                component = element.confirmPage;
                                nameKana = this.creditCardState.submitData[element.params.nameKana as string];
                                birthdate = this.creditCardState.submitData[element.params.birthdate as string];
                            } else {
                                component = this.state.submitData.isAgent === PrincipalAgentCategory.HOLDER
                                    ? element.confirmPage : element.confirmPageSub;
                                checkComponent = this.state.submitData.isAgent === PrincipalAgentCategory.HOLDER
                                    ? element.checkComponent : element.checkComponentSub;
                                nameKana = this.state.submitData[element.params.nameKana as string];
                                birthdate = this.state.submitData[element.params.birthdate as string];
                                submitData = this.state.submitData;
                                if (this.savingsState.submitData.ifApplyBC === ApplyBC.YES) {
                                    this.action.clearCreditCardConfirmPageInfo();
                                    if (this.state.submitData.hasLicense !== '0') {
                                        this.action.setStateSubmitDataValue({
                                            name: 'identificationDocument1ExpiryDate',
                                            value: this.state.ocrEntity.dueDate
                                        });
                                        this.action.setStateSubmitDataValue({
                                            name: 'identificationDocument1ExpiryDateText',
                                            value: this.state.ocrEntity.dueDateWareki
                                        });
                                    }
                                    this.creditCardAction.backupOriginSubmitData();
                                }
                            }
                            this.presendIdentificationDocumentChat(
                                {
                                    component: checkComponent,
                                    title: '本人確認書類',
                                    process: -1,
                                    clear: false,
                                    submitData: submitData,
                                },
                                chatComponent,
                                element.accountType
                            ).then(() => {
                                this.navCtrl.push(component, undefined, {
                                    animate: false
                                });
                            });
                        } else {
                            if (this.state.submitData.accountType === AccountType.CREDIT_CARD
                                && this.creditCardState.submitData.cardBrand === CreditCardBrand.JCB) {
                                this.navCtrl.push(element.confirmPageSub);
                                return;
                            } else if (this.state.submitData.accountType === AccountType.LOSS_REISSUE_FINDING
                                && !this.lossReissueFindingState.isLossReport) {
                                const component = this.lossReissueFindingState.isCustomerInfoChanged
                                    ? element.confirmPage[0] : element.confirmPage[1];
                                const params: any = {};
                                // 書類聴取チャット実施直前の喪失系submitData
                                params.originSubmitData =
                                    Object.assign(new LossReissueFindingSubmitEntity(), this.lossReissueFindingState.submitData);
                                // 諸届ありの場合、ChangeContentConfirmComponentからChangeFinishComponentへ、editedListを受け渡す
                                params.editedList = this.lossReissueFindingState.isCustomerInfoChanged
                                    ? this.navCtrl.first().instance.editedList
                                    : null;
                                this.presendIdentificationDocumentChat(
                                    {
                                        component: element.checkComponent,
                                        title: '本人確認書類',
                                        process: -1,
                                        clear: false,
                                        submitData: this.lossReissueFindingState.submitData,
                                    },
                                    LossReissueFindingChatComponent
                                ).then(() => {
                                    this.navCtrl.push(component, params, {
                                        animate: false
                                    });
                                });
                                return;
                            } else if (this.state.submitData.accountType === AccountType.EXISTING_RESERVE
                                && (this.existingReserveState.submitData.selectProductType === PRODUCT_TYPE.ORANGE
                                    || this.existingReserveState.submitData.selectProductType === PRODUCT_TYPE.SMILE
                                    || this.existingReserveState.submitData.selectProductType === PRODUCT_TYPE.LOVE)) {
                                this.navCtrl.push(element.confirmPageSub);
                                return;
                            } else if (this.state.submitData.accountType === AccountType.EXISTING_RESERVE
                                && this.existingReserveState.submitData.regularPurpose === '0') {
                                this.navCtrl.push(element.confirmPageSub);
                                return;
                            } else if (this.state.submitData.accountType === AccountType.REPLACEMENT) {
                                // 遷移元を設定
                                const component = this.ReplacementState.isCustomerInfoChanged
                                    ? element.confirmPage[0] : element.confirmPage[2];
                                const params: any = {};
                                // 書類聴取チャット実施直前の新規系submitData
                                params.originSubmitData =
                                    Object.assign(new ReplacementSubmitEntity(), this.ReplacementState.submitData);
                                // 諸届ありの場合、ChangeContentConfirmComponentからChangeFinishComponentへ、editedListを受け渡す
                                params.editedList = this.ReplacementState.isCustomerInfoChanged
                                    ? this.navCtrl.first().instance.editedList
                                    : null;
                                this.presendIdentificationDocumentChat(
                                    {
                                        component: element.checkComponent,
                                        title: '本人確認書類',
                                        process: -1,
                                        clear: false,
                                        submitData: this.ReplacementState.submitData,
                                    },
                                    ReplacementChatComponent
                                ).then(() => {
                                    this.navCtrl.push(component, params, {
                                        animate: false
                                    });
                                });
                                return;
                            } else if (this.state.submitData.accountType === AccountType.CANCEL) {
                                const params: any = {};
                                 // 書類聴取チャット実施直前の定期解約のsubmitData
                                params.originSubmitData =
                                Object.assign(new CancelSubmitEntity(), this.cancelState.submitData);
                                this.presendIdentificationDocumentChat(
                                    {
                                        component: element.checkComponent,
                                        title: '本人確認書類',
                                        process: -1,
                                        clear: false,
                                        submitData: this.cancelState.submitData,
                                    },
                                    CancelChatComponent
                                ).then(() => {
                                    this.navCtrl.push(element.confirmPage, params, {
                                        animate: false
                                    });
                                });
                                return;
                            }  else if (this.state.submitData.accountType === AccountType.NEWEST) {
                                // 遷移元を設定
                                const component = this.newestState.isCustomerInfoChanged
                                    ? element.confirmPage[0] : element.confirmPage[2];
                                const params: any = {};
                                // 書類聴取チャット実施直前の新規系submitData
                                params.originSubmitData =
                                    Object.assign(new NewestSubmitEntity(), this.newestState.submitData);
                                // 諸届ありの場合、ChangeContentConfirmComponentからChangeFinishComponentへ、editedListを受け渡す
                                params.editedList = this.newestState.isCustomerInfoChanged
                                    ? this.navCtrl.first().instance.editedList
                                    : null;
                                this.presendIdentificationDocumentChat(
                                    {
                                        component: element.checkComponent,
                                        title: '本人確認書類',
                                        process: -1,
                                        clear: false,
                                        submitData: this.newestState.submitData,
                                    },
                                    NewestChatComponent
                                ).then(() => {
                                    this.navCtrl.push(component, params, {
                                        animate: false
                                    });
                                });
                                return;
                            }

                            this.navCtrl.push(element.confirmPage);
                        }
                        break;
                    }
                }
            }
        });
        modal.present();
    }

    // headerTitle
    public get headerTitle(): string {
        if (!this.state.submitData.accountType || !this.state.submitData.accountTypeText) {
            return '';
        }

        if (this.state.submitData.accountType === AccountType.EXISTING_RESERVE) {
            return this.labels.existingReserve.title;
        }

        if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
            return this.labels.existingSavings.title;
        }

        if (this.state.submitData.accountType === AccountType.EXISTING_STORAGE) {
            return this.labels.existingStorage.title;
        }

        if (this.studentState.submitData.swipeAccountNo) {
            return this.labels.student.changeTitle;
        }

        if (this.state.submitData.accountType === AccountType.CREDIT_CARD) {
            return this.labels.creditcard.titleHeader;
        }

        if (this.state.submitData.accountType === AccountType.LOSS_REISSUE_FINDING) {
            return this.lossReissueFindingUtil.getHeaderTitle(this.lossReissueFindingState.submitData);
        }

        if (this.state.submitData.accountType === AccountType.REPLACEMENT) {
            return this.labels.replacement.headerTitle;
        }
        if (this.state.submitData.accountType === AccountType.NEWEST) {
            return this.labels.newest.headerTitle;
        }

        return this.state.submitData.accountTypeText;
    }

    /**
     * add operation log
     */
    private saveOperationLog() {
        const logInfo: IOperationInfo = {
            screenName: this._labels.logging.CompletionPage.ScreenName,
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: this._labels.logging.CompletionPage.accountConfirmButton
        };
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }

    /**
     * 同一名義人照会を呼び出す
     */
    private getSameHolderInquiry() {
        // 同一名義人照会を行う
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                nameKanji: this.state.submitData.firstName ?
                    this.state.submitData.firstName + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastName :
                    this.state.submitData.firstNameKanji + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKanji,
                nameKana: StringUtils.convertZankaku2Hankaku(
                    this.state.submitData.firstNameKana + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKana),
                birthdate: this.state.submitData.birthdate || this.state.submitData.holderBirthdate,
                address: this.getAddress(),
                searchMode: SearchMode.ORDINARY,
            }
        };

        this.store.registerSignalHandler(SavingsSignal.GET_SAME_HOLDER_INQUIRY, (data) => {
            this.store.unregisterSignalHandler(SavingsSignal.GET_SAME_HOLDER_INQUIRY);
            const controller = this.navCtrl.getActive();
            if (controller.instance.action && controller.instance.action.updateDuplicateAccountInfos) {
                controller.instance.action.updateDuplicateAccountInfos(data);
            }
        });
        this.action.getSameHolderInquiry(param);
    }

    private getAddress() {
        const prefecture = this.state.submitData.holderAddressPrefecture ? this.state.submitData.holderAddressPrefecture : '';
        const countyUrbanVillage = this.state.submitData.holderAddressCountyUrbanVillage ?
            this.state.submitData.holderAddressCountyUrbanVillage : '';
        const streetName = this.state.submitData.showStreet ?
            this.state.submitData.showStreet : this.state.submitData.getHolderAddressStreetName();
        const addressHouseNumber = this.state.submitData.holderAddressHouseNumber ? this.state.submitData.holderAddressHouseNumber : '';

        return prefecture + countyUrbanVillage + streetName + addressHouseNumber;
    }

    private presendIdentificationDocumentChat(options: any, chatComponent: any, accountType?: string) {
        const modal = this.modalCtrl.create(chatComponent, {
            options: options
        }, {
            cssClass: 'full-modal'
        });
        modal.onDidDismiss((state: any) => {
            if (state) {
                const controller = this.navCtrl.getActive();
                // チャットフロー上で「申込内容確認へ戻る」ボタンが選択された場合、３個目前画面（申込内容画面）に戻る
                if (state === 'backConfirm' || state.submitData
                    && state.submitData.continueOrBackToConfirm === ContinueOrBackToConfirm.BACK_TO_CONFIRM) {
                    this.navCtrl.popTo(this.navCtrl.getByIndex(this.navCtrl.length() - 3));
                    if (controller.instance.action && controller.instance.action.resetSubmitData) {
                        controller.instance.action.resetSubmitData();
                    }
                } else if (state === 'backConfirmTwoScn') {
                    this.navCtrl.popTo(this.navCtrl.getByIndex(this.navCtrl.length() - 4));
                    if (controller.instance.action && controller.instance.action.resetSubmitData) {
                        controller.instance.action.resetSubmitData();
                    }
                } else if (state === 'backConfirmThreeScn') {
                    this.navCtrl.popTo(this.navCtrl.getByIndex(this.navCtrl.length() - 5));
                    if (controller.instance.action && controller.instance.action.resetSubmitData) {
                        controller.instance.action.resetSubmitData();
                    }
                } else if (state === LossReissueFindingConsts.ScreenTransition.BACK_CONFIRM_LOSS) {
                    this.navCtrl.popTo(this.navCtrl.getByIndex(this.navCtrl.length() - 3));
                    this.lossReissueFindingAction.resetSubmitData();
                } else if (state === ReplacementConsts.ScreenTransition.BACK_CONFIRM_REPLACE) {
                    this.navCtrl.popTo(this.navCtrl.getByIndex(this.navCtrl.length() - 3));
                    this.ReplacementAction.resetSubmitData();
                } else if (state === 'backConfirmCancel') {
                    this.navCtrl.popTo(this.navCtrl.getByIndex(this.navCtrl.length() - 3));
                    this.cancelAction.resetSubmitData();
                } else if (state === NewestConsts.ScreenTransition.BACK_CONFIRM_NEWEST) {
                    this.navCtrl.popTo(this.navCtrl.getByIndex(this.navCtrl.length() - 3));
                    this.newestAction.resetSubmitData();
                } else if (controller.instance.action && controller.instance.action.setIdentificationDocument) {
                    controller.instance.action.setIdentificationDocument(state);

                    // accountTypeが存在かつ業務は普通預金新規、普通預金既存の場合はフィルタリング実施
                    // 代理人の場合は口座名義人認証画面に入ったら、フィルタリング実施
                    if (accountType
                        && (accountType === AccountType.ORDINARY_DEPOSIT
                            || accountType === AccountType.FOREIGN_SAVINGS || accountType === AccountType.EXISTING_SAVINGS)) {
                        if (controller.instance.filterInquiry) {
                            controller.instance.filterInquiry();
                        }
                    }
                }

                // マスキング未確認データリセットメソッドが存在する場合は、データを初期化する
                if (controller.instance.action && controller.instance.action.resetNotMaskingConfirmImages) {
                    controller.instance.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.DOCUMENT);
                }
            }
        });

        return modal.present();
    }
}
