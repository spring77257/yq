import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ConfirmPageCommonService } from 'dhdt/branch/pages/bank-savings-deposit/service/confirmpage.common.service';
import { SavingsState, SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { CompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/completion.component';
import {
    AccountType, Age, ApplyBC, ApplyBusinessType, PrincipalAgentCategory, ReferenceFlg, SsnHave, SsnWrite
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardChatComponent } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat.component';
import { CreditCardInitConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-initconfirm.component';
import { BussinessCode } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { DocumentCategoryService } from 'dhdt/branch/shared/modules/document-category/service/document-category.service';
import { LoadingService, SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { PasscodeValidator } from 'dhdt/branch/shared/utils/ passcode-validator';
import { ConfirmUtil } from 'dhdt/branch/shared/utils/confirm-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { PRODUCT_TYPE } from 'dhdt/branch/shared/utils/product-category-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController, NavParams, ViewController } from 'ionic-angular';
/**
 * T03-SC2002 普通_情報確認画面（代理人申込用）
 */
@Component({
    selector: 'bsd-agent-confirm-component',
    templateUrl: 'bsd-agent-confirm.component.html'
})

export class BsdAgentConfirmComponent extends BaseComponent implements OnInit {
    public open: boolean = true;
    public state: SavingsState;
    public confirmPageCommonParams: Map<string, any> = null;
    public changeHolderMobileNoFlag: boolean = false;
    public saveShowChats: any = {};

    public isSelfApplyConfirm: boolean = true;  // distinguish 申込内容確認 from (行員確認用)ご本人確認
    public passwordOK: boolean = true; // 暗証番号 password validate result
    public showPassbook: boolean = false;
    public isW9Show: boolean = false;
    public isFatcaShow: boolean = false;
    public confirmPageChatComponentFlay: boolean = true;
    public editedList: any = {};
    public businessCode: string = BussinessCode.OPEN_ACCOUNT;
    public submitData: any;

    constructor(
        private action: SavingsAction,
        private navCtrl: NavController,
        private store: SavingsStore,
        private confirmPageCommonService: ConfirmPageCommonService,
        private modalCtrl: ModalController,
        private logging: LoggingService,
        private loginStore: LoginStore,
        private categoryService: DocumentCategoryService,
        private loadingService: LoadingService,
        private viewCtrl: ViewController,
        private params: NavParams,
        private confirmUtils: ConfirmUtil
    ) {
        super();
        this.state = this.store.getState();

        this.viewCtrl.willEnter.subscribe(() => this.categoryService.addObserver((data) => {
            this.action.setDocumentCategory(data, false, this.state.submitData.isAgent === PrincipalAgentCategory.HOLDER);
        }, this));

        this.viewCtrl.willLeave.subscribe(() => this.categoryService.removeObserver(this));
    }

    public ngOnInit() {
        const loadingId = this.loadingService.showLoading(SpinnerType.SHOW);

        // こどもが来店できない理由
        this.getChildrenCantComeReason();

        this.confirmPageCommonService.loadConfirmTemplate();
        this.confirmPageCommonParams = this.confirmPageCommonService.getShowChatParams();
        this.getHolderZipCode();
        this.getShowPassbook();
        this.state.showConfirm.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
        this.action.setHolderAgeFlag(
            {
                birthdate: this.state.submitData.holderBirthdate,
                agentBirthdate: this.state.submitData.agentBirthdate,
                today: this.state.submitData.tabletStartDate
            }
        );

        this.isW9Show = this.state.submitData.isSsnWrite === SsnWrite.YES;
        this.isFatcaShow = this.state.submitData.isSsnHave === SsnHave.NO || this.state.submitData.isTaxForAmerican === SsnHave.NO;

        this.saveApplyBCAndBCBak(this.params.get('ifApplyBC'), this.params.get('ifApplyBCBak'));

        this.loadingService.dismissLoading(loadingId);
    }

    /**
     * ・BC修正ボタンによってBC申込チャットが完了時にBC申込Viewから呼ばれる
     *
     * @param {*} data
     * @memberof ExistingSavingsInitConfirmComponent
     */
    public receiveBCParamByModify(data: any) {
        // bc申込状態を保存する
        this.saveApplyBCAndBCBak(data.ifApplyBC, data.ifApplyBCBak);
    }

    public getShowText(name: string): string {
        if (!this.saveShowChats || !this.saveShowChats[name] || !this.saveShowChats[name].answer) {
            return '';
        }
        return this.saveShowChats[name].answer.text;
    }

    // click 'お申込み' button
    public moveToNextPage() {
        this.saveOperationLog();
        this.action.setCustomerApplyEndDate();
        // 認証の場合
        this.action.setStateSubmitDataValue({
            name: 'isModify',
            value: '2'
        });
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.navCtrl.push(CreditCardInitConfirmComponent,
                {
                    submitData: this.state.submitData
                });
            const info = {
                    applyBusinessCategory: ApplyBusinessType.BANKCARD_COMPOSIT, // 普通預金口座開設（BC複合）
                    tabletApplyId: this.loginStore.getState().tabletApplyId
            };
            this.action.updateApplyBizCategory(info);
        } else {
            const modal = this.modalCtrl.create(
                ModalPasswordComponent,
                {
                    data: {
                        text: this.labels.confirm.passwordModal.text,
                        subText: this.labels.confirm.passwordModal.subText,
                        units: 4,
                        errorMessage: this.labels.confirm.passwordModal.errorMessage,
                        needConfirm: true,
                        inputPassword: this.state.submitData.firstPwd4bits
                    }
                },
                { cssClass: 'settings-modal', enableBackdropDismiss: false });
            modal.onDidDismiss((value) => {
                if (value) {
                    this.navCtrl.push(CompletionComponent);
                }
            });
            modal.present();
        }
    }

    public changeHolderMobileNoEmitter(value: boolean) {
        this.changeHolderMobileNoFlag = value;
        // this.passwordOK = !this.getCardPwdAndConfirmPwdError();
    }

    public get headerTitle(): string {
        if (!this.state.submitData.accountType || !this.state.submitData.accountTypeText) {
            return '';
        }
        return this.state.submitData.accountTypeText;
    }

    public get bottonTitle(): string {
        return this.state.submitData.ifApplyBC === ApplyBC.YES ?
                    this.labels.change.confirm.button : this.labels.confirm.confirmButton;
    }

    public get topMessage(): string {
        return this.state.submitData.ifApplyBC === ApplyBC.YES ?
            this.labels.student.initDesc3 : this.labels.student.initDesc1;
    }

    // 郵便番号
    public getHolderZipCode() {
        if (this.state.submitData.holderAddressPrefecture && this.state.submitData.holderAddressCountyUrbanVillage) {
            this.action.getHolderZipCode(
                this.state.submitData.holderAddressPrefecture,
                this.state.submitData.holderAddressCountyUrbanVillage,
                this.state.submitData.getHolderAddressStreetName());
        } else {
            this.action.setDefaultZipCode();
        }
    }

    public onModifying(data) {
        Object.keys(data).forEach((key) => {
            this.action.setStateSubmitDataValue({
                name: key,
                value: data[key]
            });
        });
    }

    public onModifyingBcApply(data) {
        // BC複合申込を変更した場合、キャッシュカード申込欄も編集済み表示にするため
        // 確認画面の子componentで共通のeditedListをtrueに設定
        this.editedList.bcApply = true;
        // 申込チャットで「申し込まない」を選び、修正によって「申し込む」を選んだ場合
        if (data.ifApplyBC === ApplyBC.YES
            && this.state.submitData.ifApplyBCBak !== ApplyBC.YES) {
            this.onModifying(data);

            this.navCtrl.push(CreditCardChatComponent,
                {
                    submitData: {
                        ...this.confirmUtils.makeSubmitDataSavingsForBc(this.state, this.loginStore.getState()),
                        referenceFlg: ReferenceFlg.Confrim
                    },
                    tabletApplyId: this.loginStore.getState().tabletApplyId,
                    pageIndex: 0,
                    accountType: this.state.submitData.accountType,
                    customerApplyStartDate: this.state.submitData.customerApplyStartDate,
                    cardInfo: this.state.submitData.cardInfo,
                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                }
            );
        } else {
            this.onModifying(data);
        }
    }

    public onChangeOpenStore(data) {
        this.action.changeOpenStore(data);
    }

    // 暗証番号 emitter
    public passwordOKEmitterHandler(flag: boolean) {
        // this.passwordOK = !this.getCardPwdAndConfirmPwdError();
    }

    /**
     * 郵便番号 emitter
     */
    public changePostSkipEmitterHandler() {
        this.getHolderZipCode();
    }

    // 18歳未満　また　代理人の場合は、BC欄を非表示する
    public get isBcShow() {
        const isBlow18 = !InputUtils.validateAge(this.state.submitData.holderBirthdate, Age.Age_18,
            this.state.submitData.tabletStartDate);
        return (isBlow18 || this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) ? false : true;
    }

    // footer button disable
    public get footerBtnDisable() {
        const preconditionsOK = !this.state.checkboxStatus.isAntisocialStatus &&
            !this.state.checkboxStatus.isForeignPulicFiguresSatus &&
            this.state.checkboxStatus.isJapaneseResidentStatus &&
            this.state.checkboxStatus.isRegulationStatus;
        const confirmationCheckedOK = this.getShowText('directApplyExpectation') === '申し込む' ?
            this.state.checkboxStatus.confirmationStatus : true;
        const receiptMethodOK = this.getShowText('receiptMethod') === 'ご自宅' ? this.state.checkboxStatus.receiptMethodStatus : true;
        this.passwordOK = !this.getCardPwdAndConfirmPwdError();
        const kanaKanjiOK = this.checkContainKanjiValidation();
        const totalValid = this.passwordOK && confirmationCheckedOK && receiptMethodOK && preconditionsOK && kanaKanjiOK;
        return totalValid;
    }

    // show checkbox errorMessage
    public get checkboxValid(): boolean {
        const preconditionsOK = !this.state.checkboxStatus.isAntisocialStatus &&
            !this.state.checkboxStatus.isForeignPulicFiguresSatus &&
            this.state.checkboxStatus.isJapaneseResidentStatus &&
            this.state.checkboxStatus.isRegulationStatus;
        const confirmationCheckedOK = this.getShowText('directApplyExpectation') === '申し込む' ?
            this.state.checkboxStatus.confirmationStatus : true;
        const receiptMethodOK = this.getShowText('receiptMethod') === 'ご自宅' ? this.state.checkboxStatus.receiptMethodStatus : true;
        const totalValid = confirmationCheckedOK && receiptMethodOK && preconditionsOK;
        return totalValid;
    }

    /**
     * Determines whether the "通帳デザイン" is displayed
     */
    public getShowPassbook() {
        this.showPassbook =
            this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT_CHILDREN ||
            this.state.submitData.selectProductType === PRODUCT_TYPE.LOVE;
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.action.modifyCheckboxStatus(checboxItem);
    }

    /**
     * 貯蓄預金判断
     */
    public isStorage(): boolean {
        return this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT_SAVINGS_DIPOSIT ? true : false;
    }

    /**
     * get action
     */
    public getAction() {
        return this.action;
    }

    /**
     * CD暗証番号を修正した場合、その更新をBC暗証番号に反映させる
     * @param data 変更項目
     */
    public setPwdForCashCardFirstPwd4bitsEmitter(data) {
        // 口座開設側のstate.submitDataの暗証番号に修正後の値を格納
        this.action.setStateSubmitDataValue({ name: 'firstPwd4bits', value: data.value });
        this.action.setStateSubmitDataValue({ name: 'cashCardFirstPwd4bits', value: data.value });
    }

    /**
     * add operation log
     */
    private saveOperationLog() {
        const logInfo: IOperationInfo = {
            screenName: this.logging.getConfirmPageScreenName(this.state.submitData, false),
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: this._labels.logging.InfoComfirm.ApplyButton,
        };
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }

    private getCardPwdAndConfirmPwdError(): boolean {
        let result = !this.getPasswordValidation(this.state.submitData.firstPwd4bits);
        if (!result && this.state.submitData.directApplyExpectation === '1') {
            result = !this.getPasswordValidation(this.state.submitData.firstPwd6bits);
        }
        return result;
    }

    private getPasswordValidation(password: string): boolean {
        const validate = PasscodeValidator.validation(
            password,
            {
                gregorian: this.state.submitData.holderBirthdate,
                japan: this.state.submitData.holderBirthdateText
            },
            [
                this.state.submitData.getHolderMobileNo(),
                this.state.submitData.getHolderTelephoneNo(),
            ]);
        return validate;
    }

    /**
     * こどもが来店できない理由
     */
    private getChildrenCantComeReason() {
        if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT_CHILDREN && !this.state.submitData.cantComeReason) {
            this.action.getChildrenCantComeReason();
        }
    }

    /**
     * 「カナ氏名」「カナ住所」に漢字が混在している場合は、
     * 申込内容確認画面の「申込をする」ボタンが非活性になること
     */
    private checkContainKanjiValidation(): boolean {
        const holderName = this.state.submitData.firstNameKana + this.state.submitData.lastNameKana;
        const holderAddress = this.state.submitData.holderAddressPrefectureFuriKana
            + this.state.submitData.holderAddressCountyUrbanVillageFuriKana
            + this.state.submitData.getHolderAddressStreetNameFuriKana()
            + this.state.submitData.holderAddressHouseNumberFuriKana;
        const agentName = this.state.submitData.agentFirstNameKana + this.state.submitData.agentLastNameKana;

        let result = StringUtils.validateNameKana(holderName);
        if (result) {
            result = StringUtils.validateAddressKana(holderAddress);
        }
        if (result && this.state.submitData.isAgent === '1') {
            result = StringUtils.validateNameKana(agentName);
        }
        return result;
    }

    /**
     * 複数箇所に使われるので、共通化する
     *
     * @private
     * @param {string} ifApplyBC
     * @param {string} ifApplyBCBak
     * @memberof ExistingSavingsInitConfirmComponent
     */
    private saveApplyBCAndBCBak(ifApplyBC: string, ifApplyBCBak: string) {
        if (ifApplyBC) {
            this.action.setStateSubmitDataValue({
                name: 'ifApplyBC',
                value: ifApplyBC
            });
        }
        if (ifApplyBCBak) {
            this.action.setStateSubmitDataValue({
                name: 'ifApplyBCBak',
                value: ifApplyBCBak
            });
        }
    }
}
