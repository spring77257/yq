import { NgModule, Type } from '@angular/core';
import { HttpModule } from '@angular/http';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { ConfirmPageChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/confirm-page-chat.component';
import { ForeignerPageChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/foreigner-page-chat.component';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { AccountComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/account.component';
import { BsdAgentInfoComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/bsd-agent-info.component';
import { BsdHolderInfoComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/bsd-holder-info.component';
import { CompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/completion.component';
import {
    ExistingSavingsForeignConfirmComponent
} from 'dhdt/branch/pages/bank-savings-deposit/view/existing-savings-foreign/view/existing-savings-foreign-confirm.component';
import {
    ExistingSavingsForeignInitConfirmComponent
} from 'dhdt/branch/pages/bank-savings-deposit/view/existing-savings-foreign/view/existing-savings-foreign-initconfirm.component';
import { BrdConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/regular/brd-confirm.component';
import { RegularAgentHolderInfoComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/regular/regular-agent-holder-info.component';
import { RegularAgentInfoComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/regular/regular-agent-info.component';
import { RegularHolderInfoComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/regular/regular-holder-info.component';
import { BsdAgentConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/savings/bsd-agent-confirm.component';
import { CommonBusinessModule } from 'dhdt/branch/pages/common-business/common-business.module';
import { ApplyCompletionModule } from 'dhdt/branch/pages/common/apply-completion/apply-completion.module';
import { LoginModule } from 'dhdt/branch/pages/common/login/login.module';
import { TopModule } from 'dhdt/branch/pages/common/top/top.module';
import { ExistingAccountChangeModule } from 'dhdt/branch/pages/existing-account-change/existing-account-change.module';
import { AddressModule } from 'dhdt/branch/shared/components/address/address.module';
import { BranchListModule } from 'dhdt/branch/shared/components/branch-list/branch-list.module';
import { ConfirmPageCommonModule } from 'dhdt/branch/shared/components/confirmpage-common/confirmpage.common.module';
import { ModalDigitalModule } from 'dhdt/branch/shared/components/modal/modal-digital/modal-digital.module';
import { ModalPasswordModule } from 'dhdt/branch/shared/components/modal/modal-password/modal-password.module';
import { PickerModule } from 'dhdt/branch/shared/components/picker/picker.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';
import { ReceptionCompletionComponent } from './view/reception-completion.component';

export const SHARED_FORM_COMPONENT: Array<Type<any>> = [
    AccountComponent,
    CompletionComponent,
    ReceptionCompletionComponent,
    BsdAgentInfoComponent,
    BsdHolderInfoComponent,
    RegularHolderInfoComponent,
    RegularAgentInfoComponent,
    RegularAgentHolderInfoComponent,
    BsdAgentConfirmComponent,
    BrdConfirmComponent,
    ChatComponent,
    ConfirmPageChatComponent,
    ExistingSavingsForeignInitConfirmComponent,
    ExistingSavingsForeignConfirmComponent,
    ForeignerPageChatComponent,
];

@NgModule({
    declarations: SHARED_FORM_COMPONENT,
    imports: [
        IonicModule,
        SharedModule,
        ModalDigitalModule,
        ConfirmPageCommonModule,
        HttpModule,
        PickerModule,
        TopModule,
        LoginModule,
        AddressModule,
        ApplyCompletionModule,
        ModalPasswordModule,
        ExistingAccountChangeModule,
        CommonBusinessModule,
        BranchListModule
    ],
    exports: SHARED_FORM_COMPONENT,
    entryComponents: [
        SHARED_FORM_COMPONENT
    ],
    providers: [
        SavingsAction,
        SavingsStore

    ]
})
export class BankSavingsDepositModule {
}
