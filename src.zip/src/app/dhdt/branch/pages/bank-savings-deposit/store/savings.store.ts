import { DatePipe } from '@angular/common';
import { Injectable, NgZone } from '@angular/core';
import { InternalFormsSharedModule } from '@angular/forms/src/directives';
import { ActionBind, State, Store } from 'adep/flux';
import { LabelService } from 'adep/services';
import { AppProperties } from 'app.properties';
import { SavingsActionType } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { AttributeCodeEntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/attribute-code.entity';
import { BranchEntity, TownEntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/branch.entity';
import { OCREntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/ocr.entity';
import { ReceptionInfoEntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/reception-info.entity';
import {
    BranchNameListEntity, CheckboxStatusEntity, DropDownListEntity, PageQuestionsModel, SavingQuestionsModel, SubmitEntity
} from 'dhdt/branch/pages/bank-savings-deposit/entity/saving-questions.model';
import { ChatFlowInfoInterface } from 'dhdt/branch/pages/bank-savings-deposit/interface/chat-flow-info';
import {
    CheckboxStatusForeignEntity
} from 'dhdt/branch/pages/bank-savings-deposit/view/existing-savings-foreign/entity/checbox-status.entity';
import {
    AccountType, AddressMaxLengthArr, Age, AgentNoVistingReason, ApplyBusinessType, BusinessCode, ClearSavingImagesClickRecordType,
    CodeCategory, COMMON_CONSTANTS, Constants, HasDriversCareerLicense, HasLicense, HolderAgeRange, HostErrorCodeReceptionNG,
    IdentificationDocumentCode, IdentificationDocumentMethod, IdentityDocumentType, NameNonConvert, OutStatus,
    OutStatusText, PrincipalAgentCategory, SavingAccountType, SelectChangeParam, TimeSavingsAccountType,
    ZipCode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import {
    ReceptionLossCorruptionCheckRequest
} from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-request.entity';
import {
    ReceptionCheckAccountInfo, ReceptionLossCorruptionCheckResponse
} from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-response.entity';
import { AcceptionResultAccount } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { DuplicateAccountEntity } from 'dhdt/branch/shared/entity/duplicate-account.entity';
import { FilteringParameterEntity } from 'dhdt/branch/shared/entity/filtering-parameter.entity';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { MorphologyService } from 'dhdt/branch/shared/services/morphology.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { PRODUCT_TYPE } from 'dhdt/branch/shared/utils/product-category-utils';
import { RegularSavingsLogicUtil } from 'dhdt/branch/shared/utils/regular-savings-logic-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';
import { Observable } from 'rxjs/Observable';

export interface SavingsState extends State {
    questions: SavingQuestionsModel[][];
    showChats: PageQuestionsModel[];
    showConfirm: PageQuestionsModel[];
    submitData: SubmitEntity;
    tabletStartDate: string;
    customerApplyStartDate: string;
    tabletApplyId: number;
    applyBusinessType: string;
    identityDocuments: string[];
    additionalInfoDocuments: string[];
    agentIdentityDocuments: string[];
    agentAdditionalInfoDocuments: string[];
    copySubmitData: SubmitEntity;
    dropDownList: DropDownListEntity[];
    branchEntities: BranchEntity[];
    townEntities: TownEntity[];
    checkboxStatus: CheckboxStatusEntity;
    currentFileInfo: any;
    ocrEntity: OCREntity;
    accountOpeningTypeEntity: AttributeCodeEntity;
    receptionInfo: ReceptionInfoEntity;
    chatFlowInfo: ChatFlowInfoInterface[];
    documentType: {
        holder: COMMON_CONSTANTS.InsertImageType,
        holderAdditional: COMMON_CONSTANTS.InsertImageType
        agent: COMMON_CONSTANTS.InsertImageType,
        agentAdditional: COMMON_CONSTANTS.InsertImageType
    };
    duplicateAccountInfos: any[];
    checkboxStatusForeign: CheckboxStatusForeignEntity;
    confirmPageChanges: any;
    icData: string;
    lastFilteringParameter: FilteringParameterEntity;
    lastFilteringResult: any;
    customerSearchStatus: string;
    tenbanBefore: string;
    modifyExpiryDateExists: boolean;

    // 各書類の画像について、masking確認完了されたない画像のIndexを格納するオブジェクト
    notMaskingConfirmImages: {
        holderCardImageFront: boolean,
        holderCardImageBack: boolean,
        agentCardImageFront: boolean,
        agentCardImageBack: boolean,
        imageEnrollmentCertificate: number[], // 在籍確認書類(勤務先)
        imageSchoolName: number[], // 在籍確認書類(通学先)
        identificationDocument1Images: number[],    // 本人確認書類１
        identificationDocument2Images: number[],    // 本人確認書類２
        identificationAddressImages: number[],   // 住所確認書類
        identificationDocument1AgentImages: number[], // 代理人本人確認書類１
        identificationDocument2AgentImages: number[], // 代理人本人確認書類2
        identificationAddressAgentImages: number[], // 代理人住所確認書類
        identificationStudentImages: number[] // 学生証
    };
}

export const SavingsSignal = {
    SEND_ANSWER: 'SEND_ANSWER',
    SET_ANSWER: 'SET_ANSWER',
    GET_QUESTION: 'GET_QUESTION',
    GET_INFO_OCR_COMPLETE: 'GET_INFO_OCR_COMPLETE',
    SUCCESS_VALIDATION: 'SUCCESS_VALIDATION',
    FAILED_VALIDATION: 'FAILED_VALIDATION',
    SUCCESS_INSERT_INFO: 'SUCCESS_INSERT_INFO',
    CHAT_FLOW_COMPELETE: 'CHAT_FLOW_COMPELETE',
    CHAT_FLOW_RETURN: 'CHAT_FLOW_RETURN',
    SUCCESS_INSERT_IMAGES_INFO: 'SUCCESS_INSERT_IMAGES_INFO',  // イメージアップロードAPIが正しく実行完了
    SUCCESS_INSERT_TIME_SAVINGS_APPLY: 'SUCCESS_INSERT_TIME_SAVINGS_APPLY',  // イメージアップロードAPIが正しく実行完了
    GET_INFO_QR_COMPLETE: 'GET_INFO_QR_COMPLETE',            // QRcode正しく取得完了
    SUCCESS_RESET_SPECIAL_TRANSFER_INFO: 'SUCCESS_RESET_SPECIAL_TRANSFER_INFO',
    SUCCESS_MODIFY_SPECIAL_TRANSFER_INFO_2: 'SUCCESS_MODIFY_SPECIAL_TRANSFER_INFO_2',
    TOWN_COMPLETE: 'TOWN_COMPLETE',
    SUCCESS_MODIFY_CHECKBOX_STATUS: 'SUCCESS_MODIFY_CHECKBOX_STATUS',
    SUCCESS_MODIFY_CONFIRMATION_CHECKBOX_STATUS_FALSE: 'SUCCESS_MODIFY_CONFIRMATION_CHECKBOX_STATUS_FALSE', // 契約状況確認 チェックボックスの初期値   false
    SUCCESS_RESET_RECEIPT_RENEW_INFO: 'SUCCESS_RESET_RECEIPT_RENEW_INFO',
    SUCCESS_RESET_RECEIPT_SCHEDULE_INFO: 'SUCCESS_RESET_RECEIPT_SCHEDULE_INFO',
    WILL_DISMISS_FOOTER: 'WILL_DISMISS_FOOTER',
    SUCCESS_PASSBOOK_PRINT_MESSAGE_SKIP: 'SUCCESS_PASSBOOK_PRINT_MESSAGE_SKIP',
    WILL_PUSH_FOOTER: 'WILL_PUSH_FOOTER',
    SUCCESS_MODIFY_RECEIPT_SCHEDULE_INFO_2: 'SUCCESS_MODIFY_RECEIPT_SCHEDULE_INFO_2',
    GET_PASSWORD_RULE: 'GET_NEW_PASSWORD_RULE',              // 暗証番号ルール適合性チェック結果
    GET_SAME_HOLDER_INQUIRY: 'SavingsSignal_GET_SAME_HOLDER_INQUIRY',              // 同一名義人照会結果
    GET_TABLET_COUNT_RESULT: 'SavingsSignal_GET_TABLET_COUNT_RESULT',
    INSERT_TABLET_APPLY_SUCCESS: 'SavingsSignal_INSERT_TABLET_APPLY_SUCCESS',
    GET_SERVE_TIME: 'SavingsSignal_GET_SERVE_TIME',
    GET_MODAL_DROPDOWN_LIST: 'SavingsSignal_GET_MODAL_DROPDOWN_LIST',
    SET_DUPLICATE_ACCOUNT_INFO: 'SavingsSignal_SET_DUPLICATE_ACCOUNT_INFO',

    SHOULD_UPDATE_DUE_DATE: 'SavingsSignal_SHOULD_UPDATE_DUEDATE',

    CHARACTER_CHECK: 'SavingsSignal_CHARACTER_CHECK',
    RECEPTION_CHECK: 'SavingsSignal_RECEPTION_CHECK',
    RECEPTION_CHECK_ALL_CIF: 'SavingsSignal_RECEPTION_CHECK_ALL_CIF',
    FILTERING_INQUIRY: 'SavingsSignal_FILTERING_INQUIRY',
    RECEPTION_GET_ERROR: 'SavingsSignal_RECEPTION_GET_ERROR',
    TABLET_APPLY_INSERT_SUCCESS: 'SavingsSignal_TABLET_APPLY_INSERT_SUCCESS',
    NEED_UPDATE_SHOW_CHATS: 'SavingsSignal_NEED_UPDATE_SHOW_CHATS',

    GET_CHECK_ACCOUNT_EXISTING: 'SavingsSignal_GET_CHECK_ACCOUNT_EXISTING',
    GET_NAME_AGGREGATION_INQUIRY: 'SavingsSignal_GET_NAME_AGGREGATION_INQUIRY',
    RECEPTION_LOSS_CORRUPTION_CHECK: 'SavingsSignal_RECEPTION_LOSS_CORRUPTION_CHECK',
    RECEPTION_LOSS_CORRUPTION_CHECK_ACCOUNT: 'SavingsSignal_RECEPTION_LOSS_CORRUPTION_CHECK_ACCOUNT',
    GET_CUSTOMER_INFO: 'SavingsSignal_GET_CUSTOMER_INFO',
    UNACCEPTABLES_NG: 'SavingsSignal_UNACCEPTABLES_NG'
};

@Injectable()
export class SavingsStore extends Store<SavingsState> {
    public documentMap: Map<number, string>;
    private replaceValues: Array<{ key: string, value: string }>;
    private keysArr: any[] = [];
    private applyBusinessType: Map<string, string>;     // Reception Menuから選択した口座タイプの情報
    private keysArrBackup: any[] = [];

    constructor(
        private morphologyService: MorphologyService,
        private ngZone: NgZone,
        private regularSavingsLogicUtil: RegularSavingsLogicUtil,
        private editService: EditService,
        private labelService: LabelService,
        private loginStore: LoginStore,
        private datePipe: DatePipe,
        private errorMessageService: ErrorMessageService) {
        super();
        this.state = {
            chatFlowInfo: [],
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new SubmitEntity(),
            tabletStartDate: '',
            customerApplyStartDate: '',
            tabletApplyId: -1,
            applyBusinessType: null,
            identityDocuments: [],
            additionalInfoDocuments: [],
            agentIdentityDocuments: [],
            agentAdditionalInfoDocuments: [],
            copySubmitData: null,
            dropDownList: [],
            branchEntities: [],
            townEntities: [],
            checkboxStatus: {
                receiptMethodStatus: false,  // カードお受取方法 checkbox
                confirmationStatus: false,  // 契約状況確認
                isAntisocialStatus: true, // 反社会的勢力
                isForeignPulicFiguresSatus: true,  // 外国の重要な公的地位にある者
                isJapaneseResidentStatus: false,  // 日本居住者です
                isRegulationStatus: false,
                isAllMaskingStatus: false, // 写真マスキング
                isAgentAllMaskingStatus: false, // 写真マスキング
                isCheckBranchStatus: false // 開設店舗確認
            },
            currentFileInfo: {},
            ocrEntity: new OCREntity(),
            accountOpeningTypeEntity: null,
            receptionInfo: null,
            documentType: {
                holder: COMMON_CONSTANTS.InsertImageType.image,
                holderAdditional: COMMON_CONSTANTS.InsertImageType.image,
                agent: COMMON_CONSTANTS.InsertImageType.image,
                agentAdditional: COMMON_CONSTANTS.InsertImageType.image
            },
            duplicateAccountInfos: null,
            checkboxStatusForeign: {
                receiptMethodStatus: false,  // カードお受取方法 checkbox
                confirmationStatus: false,  // 契約状況確認
                isAntisocialStatus: true, // 反社会的勢力
                isForeignPulicFiguresSatus: true,  // 外国の重要な公的地位にある者
                isJapaneseResidentStatus: false,  // 日本居住者です
                isRegulationStatus: false,
                isTransactionStatus: false, // 口座の売買
            },
            confirmPageChanges: {},
            icData: null,
            lastFilteringParameter: new FilteringParameterEntity(),  // 前回フィルタリング照会のパラメータ
            lastFilteringResult: {},  // 前回フィルタリング照会の結果

            notMaskingConfirmImages: {
                holderCardImageFront: false,
                holderCardImageBack: false,
                agentCardImageFront: false,
                agentCardImageBack: false,
                imageEnrollmentCertificate: [],
                imageSchoolName: [],
                identificationDocument1Images: [],
                identificationDocument2Images: [],
                identificationAddressImages: [],
                identificationDocument1AgentImages: [],
                identificationDocument2AgentImages: [],
                identificationAddressAgentImages: [],
                identificationStudentImages: []
            },
            customerSearchStatus: '',
            tenbanBefore: '',
            modifyExpiryDateExists: false
        };

        // Reception Menuから選択した口座タイプの情報をセット
        this.getApplyBusinessTypeFromMenu();
        this.setDocumentMap();
    }

    /**
     * バンクカード申込フラグを設定
     * @param value value
     */
    @ActionBind(SavingsActionType.SET_BANK_CARD_FLAG)
    private setBankCardFlag(data: any[]) {
        data.forEach((element) => {
            this.setSubmitData(element.key, element.flag);
        });
        if (data && data.length > 0) {
            data.forEach((item) => {
                this.state.confirmPageChanges[item.key] = item.flag;
            });
        }
    }

    /**
     * タブレットIDを保存
     * @param id タブレットID
     */
    @ActionBind(SavingsActionType.SET_TABLET_ID)
    private setTabletApplyId(id: any) {
        this.state.tabletApplyId = id;
    }

    /**
     * cif情報をセット
     */
    @ActionBind(SavingsActionType.SET_CIF_INFO)
    private setCifInfo(data: any) {
        const info = data.errors && data.errors.data ? data.errors.data.cifInfoInquiryResponse
            : data.result.cifInfoInquiryResponse;
        if (!info) {
            return;
        }
        Object.keys(info).forEach((key) => {
            this.setSubmitData(key, info[key]);
        });

        this.setSubmitData('addressKana', StringUtils.convertHankaku2Zankaku(info.addressKana));
        this.setSubmitData('nameKana', StringUtils.convertHankaku2Zankaku(info.nameKana));

        // 漢字変換不可フラグがtrueの場合、かな名を設定する。
        if (this.state.submitData.nameNonConvert === NameNonConvert.OFF) {
            this.setSubmitData('nameKanjiBackup', this.state.submitData.nameKanjiBackup || this.state.submitData.nameKanji);
            this.setSubmitData('nameKanji', this.state.submitData.nameKana);
        }

        // 16歳以上年齢フラグ設定
        this.setHolderAgeFlag({
            birthdate: info.birthdate,
            agentBirthdate: info.agentBirthdate,
            today: info.tabletStartDate
        });

        if (data.errors && data.errors.data && this.isHostError(data.errors.data.errorCode)) {
            this.setSubmitData('resultCode', data.errors.data.resultCode);
            this.setSubmitData('errorCode', data.errors.data.errorCode);
            this.setSubmitData('errorType', data.errors.data.errorType);
            this.setSubmitData('unacceptables', data.errors.data.unacceptables);

            const unacceptableCode = data.errors.data.unacceptables.map((unacceptable: any) => {
                return unacceptable.unacceptableCode;
            }).join('/');
            this.setSubmitData('unacceptableCode', unacceptableCode);

            // 受付可否チェック、エラーモーダル表示用データを作成する
            const responseForModal: Array<{ customerId: string, accounts: ReceptionCheckAccountInfo }> = [
                {
                    customerId: info.customerId,
                    accounts: {
                        resultCode: data.errors.data.resultCode,
                        errorType: data.errors.data.errorType,
                        errorCode: data.errors.data.errorCode,
                        customerId: info.customerId,
                        unacceptables: data.errors.data.unacceptables,
                        tradingConditions: null,
                        unprintableKanji: null,
                        hasLoanAccountHoldingDetails: null,
                    }
                }
            ];
            // 後続処理にてモーダル表示のため、stateに格納
            this.setSubmitData('responseForModal', responseForModal);

        }
        if (info.nextTabletApplyId) {
            this.setSubmitData('tabletApplyId', info.nextTabletApplyId);
        }
    }

    /**
     * 全店名寄せ情報をセット
     */
    @ActionBind(SavingsActionType.NAME_AGGREGATION)
    private setAllCifInfos(data: { customerInfo: CifInfo[], customerSearchStatus: string }) {
        if (data) {
            this.setSubmitData('allCifInfos', data.customerInfo);
            this.setSubmitData('customerSearchStatus', data.customerSearchStatus);
            this.state.submitData.allCifInfos.forEach((cifInfo) => {
                cifInfo.kanaName = StringUtils.convertHankaku2Zankaku(cifInfo.kanaName);
                if (cifInfo.addressInfo) {
                    cifInfo.addressInfo.kanaAddress = StringUtils.convertHankaku2Zankaku(cifInfo.addressInfo.kanaAddress);
                    cifInfo.addressInfo.kanaAuxiliaryAddress = StringUtils.convertHankaku2Zankaku(cifInfo.addressInfo.kanaAuxiliaryAddress);
                }
                if (cifInfo.address2Info) {
                    cifInfo.address2Info.kanaAddress2 = StringUtils.convertHankaku2Zankaku(cifInfo.address2Info.kanaAddress2);
                }
            });
            this.makeBranchList();
        }
        this.sendSignal(SavingsSignal.GET_NAME_AGGREGATION_INQUIRY);
    }

    /**
     * 内部API: 顧客情報照会のレスポンスをstateにセットする
     * @param data APIのレスポンス
     */
    @ActionBind(SavingsActionType.SET_CUSTOMER_INFO)
    private setCustomerInfo(data: any) {
        // 複数件の顧客情報をそのままsubmitData.cifInfosListへ設定する
        if (data && data.cifInfoInquiryResponses && data.cifInfoInquiryResponses.length > 0) {
            this.setSubmitData('cifInfosList', data.cifInfoInquiryResponses);
        }

        this.sendSignal(SavingsSignal.GET_CUSTOMER_INFO);
    }

    /**
     * 16歳以上年齢フラグ設定
     * @param params birthdate: 生年月日, today: システム日付
     */
    @ActionBind(SavingsActionType.SET_HOLDER_AGE_FLAG)
    private setHolderAgeFlag(params: any) {
        this.setSubmitData(
            'holderAgeFlag',
            !InputUtils.validateAge(params.birthdate, Age.Age_16,
                params.today) ? HolderAgeRange.BELOW_16 : HolderAgeRange.ABOVE_16
        );
        if (params.agentBirthdate) {
            this.setSubmitData(
                'agentAgeFlag',
                !InputUtils.validateAge(params.agentBirthdate, Age.Age_16,
                    params.today) ? HolderAgeRange.BELOW_16 : HolderAgeRange.ABOVE_16
            );
        }
    }

    /**
     * 本人確認書類typeをセット
     * @param data type情報
     */
    @ActionBind(SavingsActionType.SET_DOCUMENT_TYPE)
    private setDocumentType(data: { name, value }) {
        this.state.documentType[data.name] = data.value;
    }

    @ActionBind(SavingsActionType.SET_IDENTIFICATION_DOCUMENT)
    private setIdentificationDocument(data) {
        const { submitData, showChats } = data;
        this.state.submitData = submitData;
        // OCR読取した免許証が運転経歴証明書だった場合のstate更新処理
        this.setStateDataForHasDriversCareerLicense();
        this.sendSignal(SavingsSignal.NEED_UPDATE_SHOW_CHATS);
    }

    /**
     * ユーザーカード番号を保存
     */
    @ActionBind(SavingsActionType.SET_USER_CARD_PAN)
    private setPanApd(code: any) {
        Object.keys(code).forEach((key) => {
            this.setSubmitData(key, code[key]);
        });
    }

    /**
     * Stateにチャットフロー情報をセット
     * @param data チャットフロー情報
     */
    @ActionBind(SavingsActionType.SET_CHAT_FLOW_INFO)
    private setChatFlowInfo(data: any) {
        this.state.chatFlowInfo = data;
    }

    @ActionBind(SavingsActionType.SET_BANKCLERK_ID)
    private setBankclerkId(params: any) {
        this.setSubmitData('userMngNo', params.bankclerkId);
    }

    @ActionBind(SavingsActionType.SET_AGENCY_BRANCH_INFO)
    private setAgencyBranchInfo(params: any) {
        this.setSubmitData('agencyBranchNo', params.branchNo);
    }

    @ActionBind(SavingsActionType.SET_BRANCH_INFO)
    private setBranchInfo(params: any) {
        this.setSubmitData('branchNameKanji', params.branchNameKanji);
        this.setSubmitData('branchNo', params.branchNo);
    }

    @ActionBind(SavingsActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.saveCurrentYamlInfo(params.fileInfo[0]);

            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(SavingsSignal.GET_QUESTION, params.pageIndex);
        }
    }

    @ActionBind(SavingsActionType.BRANCH_STATUS_INSERT)
    private branchStatusInsert(data: any) {
        if (data) {
            this.state.tabletApplyId = data;
            this.setSubmitData('tabletApplyId', data);

            // タブレット申込情報照会結果を発送する
            this.sendSignal(SavingsSignal.INSERT_TABLET_APPLY_SUCCESS);
        }
    }

    @ActionBind(SavingsActionType.UPLOAD_IMAGE)
    private uploadImage(data: any) {
        if (data) {
            this.sendSignal(SavingsSignal.SUCCESS_INSERT_IMAGES_INFO);
        }
    }

    @ActionBind(SavingsActionType.CLEAR)
    private clearStore() {
        this.keysArr = [];
        this.state = {
            chatFlowInfo: [],
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new SubmitEntity(),
            tabletStartDate: '',
            customerApplyStartDate: '',
            tabletApplyId: -1,
            applyBusinessType: null,
            identityDocuments: [],
            additionalInfoDocuments: [],
            agentIdentityDocuments: [],
            agentAdditionalInfoDocuments: [],
            copySubmitData: null,
            dropDownList: [],
            branchEntities: [],
            townEntities: [],
            checkboxStatus: {
                receiptMethodStatus: false,  // カードお受取方法 checkbox
                confirmationStatus: false,  // 契約状況確認
                isAntisocialStatus: true, // 反社会的勢力
                isForeignPulicFiguresSatus: true,  // 外国の重要な公的地位にある者
                isJapaneseResidentStatus: false,  // 日本居住者です
                isRegulationStatus: false,
                isAllMaskingStatus: false, // 写真マスキング
                isAgentAllMaskingStatus: false, // 代理人写真マスキング
                isCheckBranchStatus: false // 開設店舗確認
            },
            currentFileInfo: {},
            ocrEntity: new OCREntity(),
            accountOpeningTypeEntity: null,
            receptionInfo: null,
            documentType: {
                holder: COMMON_CONSTANTS.InsertImageType.image,
                holderAdditional: COMMON_CONSTANTS.InsertImageType.image,
                agent: COMMON_CONSTANTS.InsertImageType.image,
                agentAdditional: COMMON_CONSTANTS.InsertImageType.image
            },
            duplicateAccountInfos: null,
            checkboxStatusForeign: {
                receiptMethodStatus: false,  // カードお受取方法 checkbox
                confirmationStatus: false,  // 契約状況確認
                isAntisocialStatus: true, // 反社会的勢力
                isForeignPulicFiguresSatus: true,  // 外国の重要な公的地位にある者
                isJapaneseResidentStatus: false,  // 日本居住者です
                isRegulationStatus: false,
                isTransactionStatus: false, // 口座の売買
            },
            confirmPageChanges: {},
            icData: null,
            lastFilteringParameter: new FilteringParameterEntity(),
            lastFilteringResult: {},

            notMaskingConfirmImages: {
                holderCardImageFront: false,
                holderCardImageBack: false,
                agentCardImageFront: false,
                agentCardImageBack: false,
                imageEnrollmentCertificate: [],
                imageSchoolName: [],
                identificationDocument1Images: [],
                identificationDocument2Images: [],
                identificationAddressImages: [],
                identificationDocument1AgentImages: [],
                identificationDocument2AgentImages: [],
                identificationAddressAgentImages: [],
                identificationStudentImages: []
            },
            customerSearchStatus: '',
            tenbanBefore: '',
            modifyExpiryDateExists: false
        };
    }

    @ActionBind(SavingsActionType.CLEAR_CONFIRM_PAGE_INFO)
    private clearConfirmPageInfo(data) {
        if (this.state.submitData.hasLicense === HasLicense.HAS_NOT_LICENSE) {
            // 本人確認書類
            this.setSubmitData('holderIdentityDocumentType', null);
        } else {
            if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) {
                this.setSubmitData('holderIdentityDocumentType', null);
            }
        }
        // 本人確認書類をクリアする
        this.state.identityDocuments = [];
        // 本人確認補完書類をクリアする
        this.state.additionalInfoDocuments = [];
        // 遠隔地等住所等の場合の理由
        this.setSubmitData('holderRemoteAddressReason', null);
        // 住所が相違する理由
        this.setSubmitData('addressDiffrentReason', null);
        // コピー徴求ができない理由
        this.setSubmitData('holderIdentityDocumentNoCopyReason', null);
        // 発行元
        this.setSubmitData('holderIdentityDocumentPublisher', null);
        // 発行日
        this.setSubmitData('holderIdentityDocumentPublishDate', null);
        // 記号番号
        this.setSubmitData('holderIdentityDocumentSignNo', null);
        // コピー徴求ができない理由
        this.setSubmitData('holderNoCopyReason', null);
        // 発行元
        this.setSubmitData('holderPublisher', null);
        // 発行日
        this.setSubmitData('holderPublishDate', null);
        // 記号番号
        this.setSubmitData('holderSignNo', null);
        // 顔写真のない本人確認書類の場合の補完書類
        this.setSubmitData('holderIdentityDocumentPhotographType', null);
        // 本人確認書類の住所と現住所が異なる場合の補完書類
        this.setSubmitData('holderIdentityDocumentAddressType', null);

        if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) {
            if (this.state.submitData.hasLicense === HasLicense.HAS_NOT_LICENSE) {
                // 代理人本人確認書類
                this.setSubmitData('agentIdentityDocumentType', null);
            }
            // 代理人本人確認書類をクリアする
            this.state.agentIdentityDocuments = [];
            // 代理人本人確認補完書類をクリアする
            this.state.agentAdditionalInfoDocuments = [];
            // 住所が相違する理由
            this.setSubmitData('agentIdentityDocumentAddressReason', null);
            // コピー徴求ができない理由
            this.setSubmitData('agentIdentityDocumentNoCopyReason', null);
            // 発行元
            this.setSubmitData('agentIdentityDocumentPublisher', null);
            // 発行日
            this.setSubmitData('agentIdentityDocumentPublishDate', null);
            // 記号番号
            this.setSubmitData('agentIdentityDocumentSignNo', null);
            // コピー徴求ができない理由
            this.setSubmitData('agentNoCopyReason', null);
            // 発行元
            this.setSubmitData('agentPublisher', null);
            // 発行日
            this.setSubmitData('agentPublishDate', null);
            // 記号番号
            this.setSubmitData('agentSignNo', null);
            // 顔写真のない本人確認書類の場合の補完書類
            this.setSubmitData('agentIdentityDocumentPhotographType', null);
            // 本人確認書類の住所と現住所が異なる場合の補完書類
            this.setSubmitData('agentIdentityDocumentAddressType', null);
        }

        console.log('===isResetMaskingCheckbox===' + data.isResetMaskingCheckbox);
        if (data.isResetMaskingCheckbox) {
            // maskingのチェックボックをリセット
            this.state.checkboxStatus.isAllMaskingStatus = false;
            this.state.checkboxStatus.isAgentAllMaskingStatus = false;
        }
        // 開設店舗確認
        this.state.checkboxStatus.isCheckBranchStatus = false;
    }

    @ActionBind(SavingsActionType.CLEAR_CREDIT_CARD_CONFIRM_PAGE_INFO)
    private clearCreditCardConfirmPageInfo() {
        // マスキング確認
        this.state.checkboxStatus.isAllMaskingStatus = false;
        // 開設店舗確認
        this.state.checkboxStatus.isCheckBranchStatus = false;
        // 本人確認書類１の名称、画像、書類コード、有効期限
        this.setSubmitData('identificationDocument1', undefined);
        this.setSubmitData('identificationDocument1Images', undefined);
        this.setSubmitData('identificationDocument1ExpiryDate', undefined);
        this.setSubmitData('identificationDocument1ExpiryDateText', undefined);
        this.setSubmitData('identificationDocument1Text', undefined);
        this.setSubmitData('documentListName', undefined);
        // 本人確認書類２の名称、画像、書類コード、有効期限
        this.setSubmitData('identificationDocument2', undefined);
        this.setSubmitData('identificationDocument2Images', undefined);
        this.setSubmitData('identificationDocument2ExpiryDate', undefined);
        this.setSubmitData('identificationDocument2ExpiryDateText', undefined);
        this.setSubmitData('identificationDocument2Text', undefined);
        this.setSubmitData('documentListName2', undefined);
        // 免許証番号
        this.setSubmitData('identificationDocumentLicenseNo', undefined);
        // 現住所確認書類の名称、画像、有効期限
        this.setSubmitData('addressConfirmationDocumentName', undefined);
        this.setSubmitData('identificationAddressImages', undefined);
        this.setSubmitData('identificationAddressExpiryDate', undefined);
        this.setSubmitData('identificationAddressExpiryDateText', undefined);
        // 在籍確認書類：お勤め先画像、通学先画像
        this.setSubmitData('imageEnrollmentCertificate', undefined);
        this.setSubmitData('imageSchoolName', undefined);
        // 学生証
        this.setSubmitData('identificationStudentImages', undefined);
        // 連絡事項
        this.setSubmitData('contactNote', undefined);
    }

    @ActionBind(SavingsActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: { order: number, pageIndex: number }, options = null) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<SavingQuestionsModel>(this.state.questions[pageIndex])
                    .min<SavingQuestionsModel>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus = new PageQuestionsModel();
                        qus.order = item.order;
                        qus.next = item.next;
                        qus.type = item.type;
                        qus.question = this.replaceParams(item.question, item.type);
                        qus.name = item.name;
                        qus.skip = item.skip;
                        qus.pageIndex = pageIndex;
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        this.sendSignal(SavingsSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<SavingQuestionsModel>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        if (options) {
                            item.options = options;
                        }
                        const qus = new PageQuestionsModel();
                        qus.order = item.order;
                        qus.next = item.next;
                        qus.type = item.type;
                        qus.question = this.replaceParams(item.question, item.type);
                        qus.name = item.name;
                        qus.skip = item.skip;
                        qus.pageIndex = pageIndex;
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        const repeatOrderArr = this.state.showChats.filter((filterItem) => filterItem.order === order);
                        // orderは繰り返しの場合、orderIndexを追加する。
                        (repeatOrderArr && repeatOrderArr.length > 0) ? qus.orderIndex = repeatOrderArr.length : qus.orderIndex = 0;
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        this.sendSignal(SavingsSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => { console.log('Outside Done!'); });
        });
    }

    /**
     * 質問文言をリプレースする
     * @param str 文言
     * @param type イメージ
     *
     */
    private replaceParams(str: string, type: string): string {
        if (type === COMMON_CONSTANTS.ELEMENT_TYPE_IMAGE) {
            if (str.endsWith(COMMON_CONSTANTS.DATA_IMAGE_PNG)) {
                return str;
            } else if (str.indexOf(COMMON_CONSTANTS.DATA_IMAGE_CARD_IMAGE) !== -1) {
                return this.state.submitData[str];
            }
        }

        if (str.indexOf('@') === -1) {
            return str;
        }

        this.replaceValues = [
            {
                key: '@Doc2SkipLabel',
                value: this.state.submitData.identificationDocument1 === IdentificationDocumentCode.PASSPORT_WITHOUT_SELF_INPUT ?
                    '' : this.labelService.labels.confirm.identityDocumentConfirm.doc2SkipLabel
            },
            {
                key: '@AgentDoc2SkipLabel',
                value: this.state.submitData.agentIdentificationDocument1 === IdentificationDocumentCode.PASSPORT_WITHOUT_SELF_INPUT ?
                    '' : this.labelService.labels.confirm.identityDocumentConfirm.doc2SkipLabel
            },
            { key: '@ForeignNameKanji', value: this.state.submitData.firstNameKanji + '　' + this.state.submitData.lastNameKanji },
            { key: '@NameOCR', value: this.state.ocrEntity.firstName + '　' + this.state.ocrEntity.lastName },
            { key: '@NameKanaOCR', value: this.state.ocrEntity.firstNameKana + '　' + this.state.ocrEntity.lastNameKana },
            { key: '@BirthdayOCR', value: this.state.ocrEntity.birthdayJap },
            { key: '@ZipCodeOCR', value: this.state.ocrEntity.postalNumber },

            {
                key: '@OCRValidPeriod', value: this.state.submitData.identificationDocument1ExpiryDateText ?
                    this.state.submitData.identificationDocument1ExpiryDateText : this.state.ocrEntity.dueDateWareki
            },

            { key: '@FirstName', value: this.state.submitData.firstName },
            { key: '@FirstAgentName', value: this.state.submitData.agentFirstName },
            // 都道府県+市区町村+町丁名
            {
                key: '@AddressCountyUrbanVillageStreet', value: this.state.submitData.holderAddressPrefectureFuriKana +
                    this.state.submitData.holderAddressCountyUrbanVillageFuriKana +
                    (this.getOCREntityAddressStreetNameFuriKana ? this.getOCREntityAddressStreetNameFuriKana().replace('－', '') : '')
            },
            // 都道府県+市区町村
            {
                key: '@AddressCountyUrbanVillage', value: this.state.submitData.holderAddressPrefecture +
                    this.state.submitData.holderAddressCountyUrbanVillage
            },
            {
                key: '@AddressKana', value: this.state.submitData.holderAddressPrefectureFuriKana +
                    this.state.submitData.holderAddressCountyUrbanVillageFuriKana +
                    (this.state.submitData.getHolderAddressStreetNameFuriKana ?
                        this.state.submitData.getHolderAddressStreetNameFuriKana() : '') +
                    this.state.submitData.holderAddressHouseNumberFuriKana
            },
            {
                key: '@AddressWithoutHouseKanaOCR', value: this.state.ocrEntity.prefectureKana +
                    this.state.ocrEntity.countyUrbanVillageKana +
                    (this.getOCREntityAddressStreetNameFuriKana ? this.getOCREntityAddressStreetNameFuriKana() : '') +
                    this.state.ocrEntity.houseNumberKana
            },
            {
                key: '@AddressWithoutHouseKana', value: this.state.submitData.holderAddressPrefectureFuriKana +
                    this.state.submitData.holderAddressCountyUrbanVillageFuriKana
            },
            {
                key: '@AddressWithoutHouseOCR', value: this.state.submitData.getAddressWithoutHouseOcr ?
                    this.state.submitData.getAddressWithoutHouseOcr() : ''
            },
            {
                key: '@AddressWithoutHouseKanji', value: (this.state.submitData.holderAddressPrefecture +
                    this.state.submitData.holderAddressCountyUrbanVillage +
                    (this.state.submitData.getHolderAddressStreetName ? this.state.submitData.getHolderAddressStreetName() : ''))
            },
            {
                key: '@AddressOCR', value: this.getOCREntityAddress()
            },
            {
                key: '@Address', value: this.state.submitData.holderAddressPrefecture ? (this.state.submitData.holderAddressPrefecture +
                    this.state.submitData.holderAddressCountyUrbanVillage +
                    (this.state.submitData.getHolderAddressStreetName ? this.state.submitData.getHolderAddressStreetName() : '') +
                    this.state.submitData.holderAddressHouseNumber) : this.state.submitData.address
            },
            {
                key: '@AgentAddress', value: this.agentAddress()
            },
            {
                key: '@NameKana',
                value: this.state.submitData.firstNameKana + '　' + this.state.submitData.lastNameKana
                    || this.state.submitData.firstNameKanji + '　' + this.state.submitData.lastNameKanji
            },
            {
                key: '@Name',
                value: this.state.submitData.firstName ?
                    (this.state.submitData.firstName + '　' + this.state.submitData.lastName) : this.state.submitData.nameKanji
            },
            { key: '@AlphabetName', value: this.state.submitData.firstNameAlphabet + ' ' + this.state.submitData.lastNameAlphabet },
            { key: '@AgentBirthday', value: this.state.submitData.agentBirthdateOCR },
            { key: '@Birthday', value: this.state.submitData.holderBirthdateOCR },
            { key: '@FirstAgentName', value: this.state.submitData.agentFirstName },
            { key: '@AgentNameKana', value: this.state.submitData.agentFirstNameKana + '　' + this.state.submitData.agentLastNameKana },
            { key: '@AgentName', value: this.state.submitData.agentFirstName + '　' + this.state.submitData.agentLastName },
            { key: '@ZipCode', value: this.state.submitData.firstZipCode + '-' + this.state.submitData.lastZipCode },
            { key: '@ProductName', value: this.state.submitData.selectProductName },
            { key: '@SpecialTransferDate1', value: this.state.submitData.specialTransferDate1Text },
            { key: '@SpecialTransferDate2', value: this.state.submitData.specialTransferDate2Text },
            { key: '@cashCardFamilyFirstName', value: this.state.submitData.cashCardFamilyFirstName }, // MVP2 Added@2018/07/03
            { key: '@SpecificTransferMonth1', value: this.state.submitData.specificTransferMonth1Text },
            { key: '@SpecificTransferMonth2', value: this.state.submitData.specificTransferMonth2Text },
            { key: '@SpecificTransferMonth1', value: this.state.submitData.specificTransferMonth1Text },
            { key: '@SpecificTransferMonth2', value: this.state.submitData.specificTransferMonth2Text },
            {
                key: '@agentIdentificationDocument1', value: this.state.submitData.agentIdentificationDocument1Text
            },
            {
                key: '@agentIdentificationDocument2', value: this.state.submitData.agentIdentificationDocument2Text
            },
            {
                key: '@idInfoDoc1', value: this.state.submitData.idInfoDoc1Text || this.state.submitData.identificationDocument1Text
            },
            {
                key: '@idInfoDoc2', value: this.state.submitData.idInfoDoc2Text || this.state.submitData.identificationDocument2Text
            },
            {
                key: '@identificationDocument1', value: this.state.submitData.identificationDocument1Text
            },
            {
                key: '@identificationDocument2', value: this.state.submitData.identificationDocument2Text
            }, {
                key: '@nameKanji',
                value: this.state.submitData.nameKanji || this.state.submitData.holderName ||
                    this.state.submitData.firstNameKanji !== undefined ?
                    this.state.submitData.firstNameKanji + '　' + this.state.submitData.lastNameKanji :
                    this.state.submitData.firstNameKana + '　' + this.state.submitData.lastNameKana
            }, {
                key: '@receptionNameKanji',
                value: this.state.submitData.firstName !== undefined ?
                    this.state.submitData.firstName + '　' + this.state.submitData.lastName :
                    this.state.submitData.firstNameKana + '　' + this.state.submitData.lastNameKana
            }, {
                key: '@receptionOldNameKanji',
                value: this.state.submitData.firstNameOld !== undefined ?
                    this.state.submitData.firstNameOld + '　' + this.state.submitData.lastNameOld :
                    this.state.submitData.firstNameKanaOld + '　' + this.state.submitData.lastNameKanaOld
            }, {
                key: '@birthdate',
                value: this.state.submitData.birthdate ? moment(this.state.submitData.birthdate).format('YYYY年MM月DD日') :
                    this.state.submitData.holderBirthdateOCR
            }, {
                key: '@agentCountry',
                value: this.state.submitData.agentCountryText
            }, {
                key: '@workPlace',
                value: this.state.submitData.workPlace
            }, {
                key: '@residenceStatus',
                value: this.state.submitData.residenceStatusText
            }, {
                key: '@schoolName',
                value: this.state.submitData.attendingSchoolName
            }, {
                key: '@subAddressKana',
                value: this.state.submitData.subAddressKanaText
            }, {
                // 普通預金本人確認チャットで生年月日を表示
                key: '@IdenConfirmChatBirthdate',
                value: this.state.submitData.foreignFlg ?
                    this.state.submitData.birthdateText : this.state.submitData.holderBirthdateText
            }, {
                // 普通預金本人確認チャットで漢字氏名を表示
                key: '@IdenConfirmChatName',
                value: this.state.submitData.foreignFlg ?
                    this.state.submitData.firstNameKanji + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKanji
                    : this.state.submitData.firstName + '　' + this.state.submitData.lastName
            }, {
                // 普通預金本人確認チャットでカナ氏名を表示
                key: '@IdenConfirmChatKanaName',
                value: this.state.submitData.firstNameKana + '　' + this.state.submitData.lastNameKana
            }, {
                // 外国人の本人チャットの英字氏名
                key: '@IdenConfirmChatEnglishName',
                value: this.state.submitData.firstNameAlphabet + COMMON_CONSTANTS.SPACE + this.state.submitData.lastNameAlphabet
            }, {
                // 普通預金本人確認チャットで住所を表示
                key: '@IdenConfirmChatAddress', value: this.getAddressIdenConfirm()
            }, {
                // 普通預金本人確認チャットで住所カナを表示
                key: '@IdenConfirmChatKanaAddress', value: this.getAddressFurikanaIdenConfirm()
            },
            {
                // 普通預金本人確認チャットで携帯電話を表示
                key: '@IdenConfirmChatMobileNo',
                value: this.state.submitData.firstMobileNo + '-' +
                    this.state.submitData.secondMobileNo + '-' +
                    this.state.submitData.thirdMobileNo
            },
            {
                // 普通預金本人確認チャットで固定電話を表示
                key: '@IdenConfirmChatTelNo',
                value: this.state.submitData.firstTel + '-' +
                    this.state.submitData.secondTel + '-' +
                    this.state.submitData.thirdTel
            },
            {
                // 普通預金本人確認チャットで口座開設店舗を表示
                key: '@IdenConfirmChatOpeningBranchName',
                value: this.state.submitData.branchName
            },
            {
                // 普通預金店舗：本取引店
                key: '@branchName', value: this.state.submitData.branchName || this.state.submitData.branchNameBak
            }, {
                // 口座名義人氏名カナ（手入力）
                key: '@AccountHolderNameKana',
                value: this.state.submitData.manualNameFurikana
            }, {
                // 口座名義人氏名（CIF情報）
                key: '@AccountHolderName',
                value: StringUtils.isEmpty(this.state.submitData.nameKanji)
                    ? this.state.submitData.nameAlphabet : this.state.submitData.nameKanjiBackup ?
                        this.state.submitData.nameKanjiBackup : this.state.submitData.nameKanji
            }, {
                // 選択業務名称
                key: '@AccountTypeText', value: this.state.submitData.accountTypeText
            }
        ];

        let result = str;
        const documentNameKeyArr = ['@idInfoDoc2', '@identificationDocument1', '@identificationDocument2',
            '@agentIdentificationDocument1', '@agentIdentificationDocument2'];
        this.replaceValues.forEach((element) => {
            if (result.indexOf(element.key) !== -1) {
                let identificationDocumentName;
                const propertyName = documentNameKeyArr[documentNameKeyArr.indexOf(element.key)];
                if ((this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT ||
                    this.state.submitData.accountType === AccountType.EXISTING_SAVINGS ||
                    this.state.submitData.accountType === AccountType.FOREIGN_SAVINGS) &&
                    element.key === propertyName) {
                    // 普通預金口座開設（スワイプあり）, 普通預金口座開設（スワイプなし）の場合
                    // 本人確認書類１/２ && 記載ありの場合、chatFlowのorder繰り返し運用する、バグ修正する。
                    const qus = this.state.showChats.forEach((item, index) => {
                        if (this.state.submitData.accountType === AccountType.FOREIGN_SAVINGS &&
                            item.name === 'identificationDocument2') {
                            // 外国人の場合、idInfoDoc2 => identificationDocument2を設定する。
                            identificationDocumentName = (item.answer && item.answer.text) ? item.answer.text : null;
                        } else if (propertyName.replace('@', '') === item.name) {
                            // 文言のパラメータはshowChatsからです
                            identificationDocumentName = (item.answer && item.answer.text) ? item.answer.text : null;
                        }
                    });

                    /**
                     * 「本人確認書類１/２選択 && 本人確認書類１/２名はブランク」 or
                     * if   「submitDataの本人確認書類１/２名」は「showChatsの本人確認書類１/２名」と違う の場合、表示の文言のパラメータはshowChatsからです、
                     * else 表示の文言のパラメータはsubmitDataからです
                     */
                    result = ((element.value === undefined || identificationDocumentName !== element.value)
                        && identificationDocumentName !== null) ?
                        result.replace(element.key, identificationDocumentName) :
                        result.replace(element.key, element.value);
                } else {
                    result = result.replace(element.key, element.value);
                }
            }
        });

        return result;
    }

    private getOCREntityAddress(): string {
        const prefecture = this.state.ocrEntity.prefecture ? this.state.ocrEntity.prefecture : '';
        const countyUrbanVillage = this.state.ocrEntity.countyUrbanVillage ? this.state.ocrEntity.countyUrbanVillage : '';
        const streetName = this.state.ocrEntity.showStreet ? this.state.ocrEntity.showStreet : '';
        const houseNumber = this.state.ocrEntity.houseNumber ? this.state.ocrEntity.houseNumber : '';
        return prefecture + countyUrbanVillage + streetName + houseNumber;
    }

    private getOCREntityAddressStreetNameFuriKana(): string {
        return this.state.ocrEntity.streetKana ? this.state.ocrEntity.streetKana : '';
    }

    @ActionBind(SavingsActionType.NEED_INPUT_PHONE_NO)
    private needInputPhoenNo() {
        const chats = this.state.showChats.splice(-5);
        if (chats && chats.length > 0) {
            const chat = chats[0];

            this.getNextChatByAnswer({
                order: chat.order,
                pageIndex: chat.pageIndex
            });
        }
    }

    /**
     * 本人確認書類画像をクリア
     */
    @ActionBind(SavingsActionType.CLEAN_DOCUMENT_IMAGE)
    private cleanIdentityDocumentImage(category: Constants.IdentityDocumentCategory) {
        const submitKey = this.documentMap.get(category);
        this.setSubmitData(submitKey, null);
    }

    /**
     * 本人確認書類画像を保存
     */
    @ActionBind(SavingsActionType.SAVE_DOCUMENT_IMAGE)
    private saveIdentityDocumentImage(document: any) {
        const { image, category } = document;
        const submitKey = this.documentMap.get(category);
        this.setSubmitData(
            submitKey,
            this.state.submitData[submitKey] ?
                [...this.state.submitData[submitKey], image] : [image]
        );
    }

    @ActionBind(SavingsActionType.EDIT_CHAT)
    private editChat(params: any) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;
        const orderIndex = params.orderIndex;

        let i = -1;
        let index = -1;

        if (orderIndex !== null && orderIndex !== undefined) {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order && message.orderIndex === orderIndex) {
                    index = i;
                }
            });
        } else {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order) {
                    index = i;
                }
            });
        }

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }
        this.cleanSubmitData(answerOrder);
        this.resetIdentificationDocument(order, pageIndex);
    }

    @ActionBind(SavingsActionType.SET_ANSWER)
    private setAnswer(answer: { order: number, text: string, value: Array<{ key: string, value: string }> }) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        answer.order = this.getTopOrder();
        chat.answer = answer;
        if (answer.value) {
            answer.value.forEach((item) => {
                this.setSubmitData(item.key, item.value);
                // this.state.showConfirm.set(item.key, { value: item.value, text: answer.text });
                if (item.key && item.key.indexOf('OCR') !== -1) {
                    this.saveOCRValue(item.key, item.value);
                }
            });
        }
        this.sendSignal(SavingsSignal.SET_ANSWER);
    }

    private saveOCRValue(entityName: String, value: string) {
        if (entityName.indexOf('NameKana') !== -1 && value === '0') {
            this.setSubmitData('firstNameKana', this.state.ocrEntity.firstNameKana);
            this.setSubmitData('lastNameKana', this.state.ocrEntity.lastNameKana);
        } else if (entityName.indexOf('Name') !== -1 && value === '0') {
            this.setSubmitData('firstName', this.state.ocrEntity.firstName);
            this.setSubmitData('lastName', this.state.ocrEntity.lastName);
        } else if (entityName.indexOf('Birthday') !== -1 && value === '0') {
            this.setSubmitData('holderBirthdate', this.state.ocrEntity.birthdayEng);
            this.setSubmitData('holderBirthdateText', this.state.ocrEntity.birthdayAge);
            this.setSubmitData('holderBirthdateOCR', this.state.ocrEntity.birthdayJap);
        } else if (entityName.indexOf('AddressKana') !== -1) {
            // 都道府県フリガナ
            this.setSubmitData('holderAddressPrefectureFuriKana', this.state.ocrEntity.prefectureKana);
            // 市区町村フリガナ
            this.setSubmitData('holderAddressCountyUrbanVillageFuriKana', this.state.ocrEntity.countyUrbanVillageKana);
            // 町丁名フリガナ
            this.setSubmitData('holderAddressStreetNameFuriKanaSelect', this.state.ocrEntity.streetKana);
            // 番地以降フリガナ
            this.setSubmitData('holderAddressHouseNumberFuriKana', this.state.ocrEntity.houseNumberKana);
        } else if (entityName.indexOf('Address') !== -1 && value === '0') {
            // 都道府県
            this.setSubmitData('holderAddressPrefecture', this.state.ocrEntity.prefecture);
            // 市区町村
            this.setSubmitData('holderAddressCountyUrbanVillage', this.state.ocrEntity.countyUrbanVillage);
            // 町丁名
            this.setSubmitData('holderAddressStreetNameSelect', this.state.ocrEntity.street);
            // 番地以降
            this.setSubmitData('holderAddressHouseNumber', this.state.ocrEntity.houseNumber);
            // 町丁名（Work）
            this.setSubmitData('streetWork', this.state.ocrEntity.streetWork);
            // 町丁名（表示用）
            this.setSubmitData('showStreet', this.state.ocrEntity.showStreet);
        } else if (entityName.indexOf('ZipCode') !== -1 && value === '0') {
            if (this.state.ocrEntity.postalNumber) {
                const num = this.state.ocrEntity.postalNumber.replace('-', '');
                if (num.length === 7) {
                    this.setSubmitData('firstZipCode', num.substring(0, 3));
                    this.setSubmitData('lastZipCode', num.substring(3, 7));
                }
            }

            if (!this.state.submitData.firstZipCode) {
                this.setSubmitData('firstZipCode', '000');
                this.setSubmitData('lastZipCode', '0000');
            }
        }
    }

    @ActionBind(SavingsActionType.SET_STATE_SUBMIT_DATA_VALUE)
    private setStateSubmitDataValue(data: any) {
        if (data) {
            this.setSubmitData(data.name, data.value);
        }
    }

    @ActionBind(SavingsActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    @ActionBind(SavingsActionType.SET_STATE_DATA)
    private setStateData(data: any) {
        this.state.submitData = Object.assign(new SubmitEntity(), data.submitData);
        // OCR読取した免許証が運転経歴証明書だった場合のstate更新処理
        this.setStateDataForHasDriversCareerLicense();
    }

    @ActionBind(SavingsActionType.SET_SUBMIT_DATA)
    private editSubmitData(data: { index, key, val }) {
        if (data.key) {
            // indexが存在するときに、配列のフィルドに値を入れる。
            // indexが存在しないときに、配列ではないフィルドに値を入れる
            (data.index !== undefined && data.index !== null) ?
                this.state.submitData[data.key][data.index] = data.val :
                this.state.submitData[data.key] = data.val;
        }
    }

    /**
     * データ設定
     *
     * @param data 回答
     */
    @ActionBind(SavingsActionType.SET_STATE_DATA_FOR_BC)
    private setData(submitData: any) {
        Object.keys(submitData).forEach((key) => {
            this.setSubmitData(key, submitData[key]);
        });
    }

    @ActionBind(SavingsActionType.GET_INFO_OCR)
    private getInfoFromOCR(params: any) {
        // this.state.ocrEntity.firstName = '山田';
        // this.state.ocrEntity.lastName = '太郎';
        // this.state.ocrEntity.firstNameKana = 'ヤマダ';
        // this.state.ocrEntity.lastNameKana = 'タロウ';
        // this.state.ocrEntity.birthdayEng = '19900101';
        // this.state.ocrEntity.birthdayAge = '1989（平成2）年10月10日';
        // this.state.ocrEntity.birthdayJap = '1989（平成2）年10月10日';
        // this.state.ocrEntity.prefecture = '愛媛県';
        // this.state.ocrEntity.countyUrbanVillage = '松山市';
        // this.state.ocrEntity.street = '一番町1丁目';
        // this.state.ocrEntity.showStreet = '一番町1丁目';
        // this.state.ocrEntity.prefectureKana = 'ＡＡＡ';
        // this.state.ocrEntity.countyUrbanVillageKana = 'ＢＢＢ';
        // this.state.ocrEntity.streetKana = 'ＣＣＣ';
        // this.state.ocrEntity.houseNumberKana = 'ＤＤＤ';
        // this.state.ocrEntity.maskImg = '';
        // this.state.ocrEntity.postalNumber = '1234567';

        // if (this.state.submitData.isAgent === '0') {
        //     this.setSubmitData('holderIdentityDocumentType', Constants.DBConsts.IdentityDocumentType.DRIVER_LISENCE);
        // } else {
        //     this.setSubmitData('agentIdentityDocumentType', Constants.DBConsts.IdentityDocumentType.DRIVER_LISENCE);
        // }

        // this.setSubmitData('changeChatFlowFlg', '0');

        // this.sendSignal(SavingsSignal.GET_INFO_OCR_COMPLETE, { status: 0, errorCode: -1 });

        if (params) {
            this.state.ocrEntity = params;

            if (params.maskImg) {
                this.setSubmitData('holderCardImageFront', 'data:image/jpeg;base64,' + params.maskImg);
            }
            this.setSubmitData('holderIdentityDocumentType', Constants.DBConsts.IdentityDocumentType.DRIVER_LISENCE);
            this.setSubmitData('timeSavingsAccountType', (params.birthdayEng && params.birthdayEng.length === 8) ?
                this.regularSavingsLogicUtil.getTimeSavingsAccountType(params.birthdayEng) : '0');
            // if (this.state.submitData.isAgent === '0') {
            //     if (params.maskImg) {
            //         this.setSubmitData('holderCardImageFront', 'data:image/jpeg;base64,' + params.maskImg);
            //     }
            //     this.setSubmitData('holderIdentityDocumentType', Constants.DBConsts.IdentityDocumentType.DRIVER_LISENCE);
            //     this.setSubmitData('timeSavingsAccountType', (params.birthdayEng && params.birthdayEng.length === 8) ?
            //         this.regularSavingsLogicUtil.getTimeSavingsAccountType(params.birthdayEng) : '0');
            // } else {
            //     if (params.maskImg) {
            //         this.setSubmitData('agentCardImageFront', 'data:image/jpeg;base64,' + params.maskImg);
            //     }
            //     this.setSubmitData('agentIdentityDocumentType', Constants.DBConsts.IdentityDocumentType.DRIVER_LISENCE);
            // }

            // チャットフロー
            this.setSubmitData('changeChatFlowFlg', params.changeChatFlowFlg);
            this.sendSignal(SavingsSignal.GET_INFO_OCR_COMPLETE, { status: params.status, errorCode: params.errorCode });
        } else {
            this.sendSignal(SavingsSignal.GET_INFO_OCR_COMPLETE, { status: 1, errorCode: -1 });
        }
    }

    /**
     * OCRから取得された情報SubmitDataに設定する
     * @param　params OCRから取得された情報
     */
    @ActionBind(SavingsActionType.SET_INFO_OCR)
    private setInfoFromOCR(params: any) {
        this.state.ocrEntity = params;
        this.setSubmitData(IdentityDocumentType.AGENT_IDENTITY_DOCUMENT_EXPIRY_DATE, this.state.ocrEntity.dueDate);
        this.setSubmitData(IdentityDocumentType.AGENT_IDENTITY_DOCUMENT_EXPIRY_DATE + 'Text', this.state.ocrEntity.dueDateWareki);
        // 残存期間（残存月）
        this.setSubmitData('remainingPeriod', params.remainingPeriod);
        if (this.state.ocrEntity.houseNumber) {
            this.morphologyService.getReading(this.state.ocrEntity.houseNumber).subscribe((value) => {

                const valueMaxLength = StringUtils.convertHankaku2Zankaku(
                    StringUtils.convertZankaku2Hankaku(value).substring(0, AddressMaxLengthArr.holderAddressHouseNumber));
                this.state.ocrEntity.houseNumberKana = StringUtils.converHiraKana2Kata(valueMaxLength);
            });
        }
        // 漢字姓名、カナ姓名、漢字住所、カナ住所を最大桁数でトリム
        this.modifyOcrEntityByMaxLength(this.state.ocrEntity);

        // 正面写真を保存する
        if (params.maskImg) {
            this.setSubmitData(COMMON_CONSTANTS.KEY_HOLDER_CARD_IMAGE_FRONT, COMMON_CONSTANTS.DATA_IMAGE_JPEG + params.maskImg);
        }
        this.setSubmitData(IdentityDocumentType.HOLDER_IDENTITY_DOCUMENT_TYPE, Constants.DBConsts.IdentityDocumentType.DRIVER_LISENCE);
        this.setSubmitData(COMMON_CONSTANTS.ELEMENT_TYPE_TIME_SAVING_ACCOUNT_TYPE,
            (params.birthdayEng && params.birthdayEng.length === 8) ?
                this.regularSavingsLogicUtil.getTimeSavingsAccountType(params.birthdayEng) : TimeSavingsAccountType.NEW);
        // if (this.state.submitData.isAgent === PrincipalAgentCategory.HOLDER) {
        //     if (params.maskImg) {
        //         this.setSubmitData(COMMON_CONSTANTS.KEY_HOLDER_CARD_IMAGE_FRONT, COMMON_CONSTANTS.DATA_IMAGE_JPEG + params.maskImg);
        //     }
        //     this.setSubmitData(IdentityDocumentType.HOLDER_IDENTITY_DOCUMENT_TYPE,
        //          Constants.DBConsts.IdentityDocumentType.DRIVER_LISENCE);
        //     this.setSubmitData(COMMON_CONSTANTS.ELEMENT_TYPE_TIME_SAVING_ACCOUNT_TYPE,
        //         (params.birthdayEng && params.birthdayEng.length === 8) ?
        //             this.regularSavingsLogicUtil.getTimeSavingsAccountType(params.birthdayEng) : TimeSavingsAccountType.NEW);
        // } else {
        //     this.setSubmitData(IdentityDocumentType.AGENT_DOCUMENT_EXPIRY_DATE, this.state.ocrEntity.dueDate);
        //     this.setSubmitData(IdentityDocumentType.AGENT_DOCUMENT_EXPIRY_DATE + 'Text', this.state.ocrEntity.dueDateWareki);
        //     if (params.maskImg) {
        //         this.setSubmitData(COMMON_CONSTANTS.KEY_AGENT_CARD_IMAGE_FRONT, COMMON_CONSTANTS.DATA_IMAGE_JPEG + params.maskImg);
        //     }
        //     this.setSubmitData(IdentityDocumentType.AGENT_IDENTITY_DOCUMENT_TYPE,
        //          Constants.DBConsts.IdentityDocumentType.DRIVER_LISENCE);
        // }

        // チャットフロー
        this.setSubmitData(COMMON_CONSTANTS.CHANGE_CHAT_FLOW_FLG, params.changeChatFlowFlg);
    }

    // get holderZipCode 郵便番号
    @ActionBind(SavingsActionType.GET_HOLDER_ZIP_CODE)
    private getHolderZipCode(data: any) {
        const firstZipCode = data.substring(0, 3);
        const lastZipCode = data.substring(3, 7);

        if (firstZipCode !== this.state.submitData.firstZipCode || lastZipCode !== this.state.submitData.lastZipCode) {
            this.setSubmitData('firstZipCode', firstZipCode);
            this.setSubmitData('lastZipCode', lastZipCode);
        }
    }

    @ActionBind(SavingsActionType.VALIDATION_PASSWORD)
    private validationPassword(params: any) {
        if (params.type === 'SUCCESS') {
            this.sendSignal(SavingsSignal.SUCCESS_VALIDATION);
        } else {
            this.sendSignal(SavingsSignal.FAILED_VALIDATION);
        }
    }

    @ActionBind(SavingsActionType.SUBMIT_DATA_BACKUP)
    private submitDataBackup() {
        this.state.copySubmitData = Object.assign(new SubmitEntity(), this.state.submitData);
        this.state.confirmPageChanges = {};
    }

    @ActionBind(SavingsActionType.UPDATA_SUBMIT_DATA_BACKUP)
    private updateSubmitDataBackup(datas: Array<{ key: string, value: string }>) {
        if (datas && datas.length > 0) {
            datas.forEach((item) => {
                this.state.confirmPageChanges[item.key] = item.value;
                // 開設店舗変更時、重複口座情報変更時
                if (item.key === 'existingAccount') {
                    // 開設店舗確認
                    this.state.checkboxStatus.isCheckBranchStatus = false;
                }
            });
        }
    }

    @ActionBind(SavingsActionType.RESET_SUBMIT_DATA)
    private resetSubmitData() {
        this.state.submitData = this.state.copySubmitData;
        this.state.copySubmitData = null;
    }

    @ActionBind(SavingsActionType.RETRIEVE_DROP_LIST)
    private retrieveDropList(data) {
        this.state.dropDownList = data;
        this.sendSignal(SavingsSignal.GET_MODAL_DROPDOWN_LIST);
    }

    @ActionBind(SavingsActionType.UP_DATE_BACK_UP)
    private upDateBackUp(data) {
        this.state.copySubmitData.branchName = data.branchName || data.branchNameKanji;
        this.state.copySubmitData.tenban = data.tenban || data.branchNo;
        this.state.copySubmitData.existingAccount = undefined;
    }

    @ActionBind(SavingsActionType.GET_ACCOUNT_OPENING_TYPE)
    private getAccountOpeningType(data) {
        this.state.accountOpeningTypeEntity = data;
    }

    @ActionBind(SavingsActionType.BRANCH_INFO_INSERT)
    private branchInfoInsert(data) {
        this.sendSignal(SavingsSignal.SUCCESS_INSERT_INFO);
    }

    /**
     * Set the item as the current time of server
     * @param data system time and the key of item
     */
    @ActionBind(SavingsActionType.SET_SYSTEM_TIME)
    private setAsSystemTime(data: any) {
        this.state[data.key] = data.systemTime;
        this.setSubmitData(data.key, data.systemTime);
        this.sendSignal(SavingsSignal.GET_SERVE_TIME);
    }

    @ActionBind(SavingsActionType.CHAT_FLOW_COMPELETE)
    private chatFlowCompelete(next: any) {
        this.sendSignal(SavingsSignal.CHAT_FLOW_COMPELETE, next);
    }

    @ActionBind(SavingsActionType.CHAT_FLOW_RETURN)
    private chatFlowReturn(next: any) {
        this.sendSignal(SavingsSignal.CHAT_FLOW_RETURN, next);
    }

    @ActionBind(SavingsActionType.RESET_LAST_NODE)
    private resetLastNode(params: { order: number, pageIndex: number }) {
        this.getState().showChats.pop();
        this.getNextChatByAnswer(params);
    }

    /**
     * 指定したorderのチャットに戻る
     *
     * @private
     * @param {{ order: number, pageIndex: number }} params
     * @memberof SavingsStore
     */
    @ActionBind(SavingsActionType.RESET_SPECIAL_NODE)
    private resetSpecialNode(params: { order: number, pageIndex: number }) {
        let lastOrder: number;
        // 指定Orderのチャットまで進む
        while (this.getState().showChats[this.getState().showChats.length - 1].order !== params.order) {
            const lastChat = this.getState().showChats.pop();
            if (lastChat.answer && lastChat.answer.order) {
                lastOrder = lastChat.answer.order;
            }
        }
        // 指定Orderのチャットを外す
        const holderMobileChat = this.getState().showChats.pop();
        if (lastOrder) {
            this.cleanSubmitData(lastOrder);
        }
        this.getNextChatByAnswer(params);
    }

    @ActionBind(SavingsActionType.SUBMIT_TIME_SAVING_APPLY_INFO)
    private timeSavingApplyInfoInsert(data) {
        this.sendSignal(SavingsSignal.SUCCESS_INSERT_INFO);
    }

    @ActionBind(SavingsActionType.SUBMIT_TIME_SAVING_LOVE_APPLY_INFO)
    private submitTimeSavingLoveApplyInfo(data) {
        this.sendSignal(SavingsSignal.SUCCESS_INSERT_INFO);
    }

    @ActionBind(SavingsActionType.SUBMIT_TIME_SAVING_ORANGE_APPLY_INFO)
    private submitTimeSavingOrangeApplyInfo(data) {
        this.sendSignal(SavingsSignal.SUCCESS_INSERT_INFO, data);
    }

    @ActionBind(SavingsActionType.SUBMIT_TIME_SAVING_SMILE_APPLY_INFO)
    private submitTimeSavingSmileApplyInfo(data) {
        this.sendSignal(SavingsSignal.SUCCESS_INSERT_INFO);
    }

    /**
     * QRコード復号化してから値をStoreに置く
     * @param qrInfo 復号化QRコード
     */
    @ActionBind(SavingsActionType.GET_INFO_QR)
    private getInfoFromQR(qrInfo: any) {
        let result: boolean = false;    // true: 取得成功、false: 取得失敗

        if (qrInfo) {
            const receptionTimeYMD = qrInfo.receptionTime ? qrInfo.receptionTime.substring(0, 12) : '';
            const tabletStartDate = this.datePipe.transform(
                this.state.tabletStartDate,
                COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDDHHMMSS_PIPE,
                COMMON_CONSTANTS.STANDARD_TIME_ZONE).substring(0, 12);
            const lessTime = Number.parseInt(tabletStartDate) - Number.parseInt(receptionTimeYMD);
            const isNotReceptionQrExpired =
                Number(AppProperties.RECEPTION_QR_TTL) > -1 ? lessTime <= Number(AppProperties.RECEPTION_QR_TTL) : true;

            // 来店目的ありの場合
            // 受付時間が5時間以内の場合
            // 受付店番がログインの所属店番の場合
            if (qrInfo.purpose
                && isNotReceptionQrExpired
                && qrInfo.receptionBranchNo === this.loginStore.getState().belongToBranchNo) {
                result = true;

                // 画面遷移時のデータ転送のため、スキャン結果を設定する
                this.state.receptionInfo = qrInfo as ReceptionInfoEntity;
                // 複合化のQRコードからState情報をセットする
                this.setQrCodeInfo();
            }
        }

        this.sendSignal(SavingsSignal.GET_INFO_QR_COMPLETE, result);
    }

    @ActionBind(SavingsActionType.GET_CONFIRM_PAGE_TEMPLATE)
    private loadConfirmTemplate(params: any) {
        if (params) {
            this.state.questions[params.pageIndex] = params.data;
        }
    }

    // get 入学年 YYYY --> YYYY(平成XX)年
    @ActionBind(SavingsActionType.GET_ENROLLING_YEAR_TEXT)
    private getEnrollingYearText(data: any) {
        this.setSubmitData('enrollingYearText', data.jpBirthday);
    }

    /**
     * 預入期間(満期日)設定
     */
    @ActionBind(SavingsActionType.SET_DUE_DATE_AND_DEPOSIT_PERIOD_YEARMONTH)
    private setDueDateAndDepositPeriodYearMonth() {
        if (this.getState().submitData.selectProductType === PRODUCT_TYPE.HAPPINESS1) {
            this.setSubmitData('depositPeriodYearMonth',
                this.regularSavingsLogicUtil.getHappinessOneDepositPeriodYearMonth(this.getState().submitData)
                + this.labelService.labels.common.year);
        } else if (this.state.submitData.selectProductType === PRODUCT_TYPE.HAPPINESS2
            || this.state.submitData.selectProductType === PRODUCT_TYPE.POINT) {
            this.setSubmitData('depositPeriodYearMonth', this.labelService.labels.timeDeposit.OneYear);
        } else if (this.state.submitData.selectProductType === PRODUCT_TYPE.CHILD) {
            this.setSubmitData('depositPeriodYearMonth', this.labelService.labels.timeDeposit.ThreeYear);
        }
        this.setSubmitData('dueDate', this.regularSavingsLogicUtil.getDueDate(this.getState().submitData));
        this.sendSignal(SavingsSignal.SHOULD_UPDATE_DUE_DATE);
    }

    /**
     * 満期日を設定する
     * @param data 預入期間
     */
    @ActionBind(SavingsActionType.SET_DUE_DATE)
    private setDueDate() {
        this.setSubmitData('dueDate', this.regularSavingsLogicUtil.getDueDate(this.getState().submitData));
        this.sendSignal(SavingsSignal.SHOULD_UPDATE_DUE_DATE);
    }

    // get カードお受取方法
    @ActionBind(SavingsActionType.GET_RECEIPT_METHOD)
    private getReceiptMethod(data: any) {
        this.setSubmitData('receiptMethod', data.receiptMethod);
    }

    @ActionBind(SavingsActionType.GET_TOWN)
    private getTown(data: any) {
        this.state.townEntities = data.branchInfo;
        this.sendSignal(SavingsSignal.TOWN_COMPLETE);
    }

    @ActionBind(SavingsActionType.CLEAN_TOWNENTITIES)
    private cleanTownEntities(data: any) {
        this.state.townEntities = data;
        this.sendSignal(SavingsSignal.TOWN_COMPLETE);
    }

    // modify checkbox status -- カードお受取方法
    @ActionBind(SavingsActionType.MODIFY_CHECKBOX_STATUS)
    private modifyCheckboxStatus(name: string) {
        this.state.checkboxStatus[name] = !this.state.checkboxStatus[name];    // ture
        this.sendSignal(SavingsSignal.SUCCESS_MODIFY_CHECKBOX_STATUS);
    }

    // modify checkbox status -- カードお受取方法
    @ActionBind(SavingsActionType.MODIFY_CHECKBOX_STATUS_FOREIGN)
    private modifyCheckboxStatusForeign(name: string) {
        this.state.checkboxStatusForeign[name] = !this.state.checkboxStatusForeign[name];    // ture
        this.sendSignal(SavingsSignal.SUCCESS_MODIFY_CHECKBOX_STATUS);
    }

    // modify checkbox status -- 契約状況確認 チェックボックスの初期値   false
    @ActionBind(SavingsActionType.MODIFY_CONFIRMATION_CHECKBOX_STATUS_FALSE)
    private modifycConfirmationCheckboxStatusFalse() {
        this.state.checkboxStatus.confirmationStatus = false;
        this.sendSignal(SavingsSignal.SUCCESS_MODIFY_CONFIRMATION_CHECKBOX_STATUS_FALSE);
    }

    // Save yaml file Information
    private saveCurrentYamlInfo(params: any) {
        this.state.currentFileInfo.yamlId = params.id;
        this.state.currentFileInfo.screenId = params.screenId;
        this.state.currentFileInfo.screenName = params.screenName;
    }

    // reset 特定振替日1,特定振替額1 / 特定振替日2,特定振替額2
    @ActionBind(SavingsActionType.RESET_SPECIAL_TRANSFER_INFO)
    private resetSpecialTransferInfo() {
        let resetSetAddEveryMonthTransferDate = false;
        this.setSubmitData('specificTransferMonth1', null);
        this.setSubmitData('specificTransferAmount1', null);
        if (this.state.submitData.setAddEveryMonthTransferDate === '0') { // 特定振替日2設定する
            resetSetAddEveryMonthTransferDate = true;
            // modify 特定振替日1設定しない to 特定振替日1設定する
            this.setSubmitData('setEveryMonthTransferDate', '0');
            this.setSubmitData('specificTransferMonth1', this.state.submitData.specificTransferMonth2);
            this.setSubmitData('specificTransferAmount1', this.state.submitData.specificTransferAmount2);
            // modify 特定振替日2設定する to 特定振替日2設定しない
            this.setSubmitData('setAddEveryMonthTransferDate', '1');
            this.setSubmitData('specificTransferMonth2', null);
            this.setSubmitData('specificTransferAmount2', null);
        }
        this.sendSignal(SavingsSignal.SUCCESS_RESET_SPECIAL_TRANSFER_INFO, resetSetAddEveryMonthTransferDate);
    }

    // 修正 特定振替日(年2回まで)を追加で設定しますか？ 設定しない
    // modifySpecialTransferInfo2
    @ActionBind(SavingsActionType.MODIFY_SPECIAL_TRANSFER_INFO_2)
    private modifySpecialTransferInfo2() {
        this.setSubmitData('specificTransferMonth2', null);
        this.setSubmitData('specificTransferAmount2', null);
        this.sendSignal(SavingsSignal.SUCCESS_MODIFY_SPECIAL_TRANSFER_INFO_2);
    }

    // 積立金受取方法を修正して、新た値が設定する前に、積立金受取方法に関連する値を
    // サイクル指定
    @ActionBind(SavingsActionType.RESET_RECEIPT_RENEW_INFO)
    private resetReceiptRenewInfo() {
        // 初回受取日
        this.setSubmitData('firstReceiptDate', null);
        // 受取サイクル
        this.setSubmitData('receiptCycle', null);
        this.sendSignal(SavingsSignal.SUCCESS_RESET_RECEIPT_RENEW_INFO);
    }

    // 積立金受取方法を修正して、新た値が設定する前に、積立金受取方法に関連する値を
    // 受取日指定
    @ActionBind(SavingsActionType.RESET_RECEIPT_SCHEDULE_INFO)
    private resetReceiptScheduleInfo() {
        // 受取指定日1
        this.setSubmitData('receiptDesignatedDate1', null);
        // 受取指定日2
        this.setSubmitData('receiptDesignatedDate2', null);
        this.sendSignal(SavingsSignal.SUCCESS_RESET_RECEIPT_SCHEDULE_INFO);
    }

    // 修正 受取日指定 追加で受取日2を指定しますか？ 指定しない
    // modifyReceiptScheduleInfo2
    @ActionBind(SavingsActionType.MODIFY_RECEIPT_SCHEDULE_INFO_2)
    private modifyReceiptScheduleInfo2() {
        // 受取指定日2
        this.setSubmitData('receiptDesignatedDate2', null);
        this.sendSignal(SavingsSignal.SUCCESS_MODIFY_RECEIPT_SCHEDULE_INFO_2);
    }

    /**
     * Reset showConfirm
     * @param showConfirm showConfirm
     */
    @ActionBind(SavingsActionType.RESET_SHOW_CONFIRM)
    private resetShowConfirm({ showConfirm, submitData }) {
        this.state.showConfirm = showConfirm;
        for (const item in submitData) {
            this.state.submitData[item] = submitData[item];
        }
    }

    /**
     * clear item from submit data
     */
    @ActionBind(SavingsActionType.CLEAR_SUBMIT_DATA)
    private clearSubmitData(choices: any[]) {
        choices.forEach((element) => {
            this.state.submitData[element.name] = null;
        });
    }

    private setSubmitData(key, value) {
        if (key !== undefined) {
            this.state.submitData[key] = value;
            this.keyPush(key, value);
        }
    }

    private keyPush(key: any, value: any) {
        if (value === null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                this.keysArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1) {
            this.keysArr.push(key);
        } else {
            const index = this.keysArr.indexOf(key);
            this.keysArr[index] = moment().format('YYYYMMDDHHmmss');
            this.keysArr.push(key);
        }

    }

    private cleanSubmitData(remain: number) {
        // backup
        // const holderAddressHouseNumberFuriKanaBackup = this.state.submitData.holderAddressHouseNumberFuriKana;
        // const holderAddressStreetNameFuriKanaInputBackup = this.state.submitData.holderAddressStreetNameFuriKanaInput;
        this.keysArr = this.keysArr.slice(0, remain);

        for (const item in this.state.submitData) {
            if (item.startsWith('get')) {
                continue;
            }
            if (item === '_normalMonthValue') {
                continue;
            }
            if (this.keysArr.indexOf(item) < 0) {
                this.state.submitData[item] = undefined;
            }
        }

        // 町長名手入力があり、フリガナがないとき、フリガナを作る、最大半角８３までトリムして、
        if (this.state.submitData.holderAddressStreetNameInput && !this.state.submitData.holderAddressStreetNameFuriKanaInput) {
            InputUtils.getKanjiToKana([{
                key: 'holderAddressStreetNameInput',
                value: this.state.submitData.holderAddressStreetNameInput
            }], AddressMaxLengthArr.holderAddressStreetNameInput).subscribe((result) => {
                result.map((item) => {
                    return {
                        name: item.key,
                        value: item.value
                    };
                }).filter((item) => item.name !== 'holderAddressStreetNameInput'
                ).forEach((data) => {
                    this.setStateSubmitDataValue(data);
                });
            });
        }

        // 番地以降が入力された場合、番地以降フリガナをセット
        if (this.state.submitData.holderAddressHouseNumber && !this.state.submitData.holderAddressHouseNumberFuriKana) {
            InputUtils.getKanjiToKana([{
                key: 'holderAddressHouseNumber',  // 番地以降
                value: this.state.submitData.holderAddressHouseNumber
            }]).subscribe((resultHouseNumber) => {
                resultHouseNumber.map((item) => {
                    return {
                        name: item.key,
                        value: item.value
                    };
                }).filter((item) => item.name !== 'holderAddressHouseNumber'
                ).forEach((dataHouseNumber) => {
                    if (this.state.submitData.holderAddressStreetNameInput) {
                        // 町長名手入力があるときに
                        // 番地以降は８４から半角の町長名長さ引いた値までトリムする
                        InputUtils.getKanjiToKana([{
                            key: 'holderAddressStreetNameInput',　 // 町長名手入力
                            value: this.state.submitData.holderAddressStreetNameInput
                        }], AddressMaxLengthArr.holderAddressStreetNameInput).subscribe((resultStreetName) => {
                            resultStreetName.map((item) => {
                                return {
                                    name: item.key,
                                    value: item.value
                                };
                            }).filter((item) => item.name !== 'holderAddressStreetNameInput'
                            ).forEach((dataStreetName) => {
                                // 番地以降の半角長さをけんさんする
                                const maxlengthHouseNumber =
                                    InputUtils.calculateMaxLength('holderAddressHouseNumber', dataStreetName.value, undefined);
                                // 番地以降のを半角で計算済の長さでトリムする
                                dataHouseNumber.value =
                                    InputUtils.getStringByMaxLength(dataHouseNumber.value, maxlengthHouseNumber);
                                // 番地以降の全角フリガナをセットする
                                this.setStateSubmitDataValue(dataHouseNumber);
                            });
                        });
                    } else {
                        // 町長名手入力がないときに、番地以降を半角８４けたまでトリム
                        dataHouseNumber.value =
                            InputUtils.getStringByMaxLength(dataHouseNumber.value, AddressMaxLengthArr.holderAddressHouseNumber);
                        // 番地以降の全角フリガナをセットする
                        this.setStateSubmitDataValue(dataHouseNumber);
                    }
                });
            });
        }
    }

    private getTopOrder() {
        return this.keysArr.length;
    }

    // 通帳に印刷する文字 skip
    @ActionBind(SavingsActionType.PASSBOOK_PRINT_MESSAGE_SKIP)
    private passbookPrintMessageSkip() {
        this.setSubmitData('passbookPrintMessage', null);
        this.sendSignal(SavingsSignal.SUCCESS_PASSBOOK_PRINT_MESSAGE_SKIP);
    }

    /**
     * 暗証番号ルール適合性チェック(新規顧客)結果設定
     * @param data response data
     */
    @ActionBind(SavingsActionType.GET_NEW_PASSWORD_RULE)
    private signalExistingCustomerPasswordCheckResult(data: any) {
        // 暗証番号ルール適合性チェック結果を発送する
        this.sendSignal(SavingsSignal.GET_PASSWORD_RULE, data);
    }

    /**
     * 同一名義人照会結果設定
     * @param data response data
     */
    @ActionBind(SavingsActionType.GET_SAME_HOLDER_INQUIRY)
    private signalSameHolderInquiry(data: any) {
        data.result.duplicateAccountInfos.forEach((item: any) => {
            item.nameKana = StringUtils.convertHankaku2Zankaku(item.nameKana);
        });
        // 同一名義人照会結果を発送する
        this.state.duplicateAccountInfos = data.result.duplicateAccountInfos;
        this.state.customerSearchStatus = data.result.customerSearchStatus;
        this.sendSignal(SavingsSignal.GET_SAME_HOLDER_INQUIRY, data.result.duplicateAccountInfos);
    }

    @ActionBind(SavingsActionType.UPDATE_SAME_HOLDER_INQUIRY)
    private updateDuplicateAccountInfos(data: any) {
        this.state.duplicateAccountInfos = data;
    }

    @ActionBind(SavingsActionType.SET_EXISTING_ACCOUNT_INFO)
    private setExistingAccountInfo(value: any) {
        const { branchName, branchNo } = value;

        this.setSubmitData('branchName', branchName);
        this.setSubmitData('tenban', branchNo);
    }

    /**
     * delete firstPwd6bits
     */
    @ActionBind(SavingsActionType.DELETE_PWD_6BITS)
    private deleteFirstPwd6bits() {
        this.setSubmitData('firstPwd6bits', null);
    }

    /**
     * Request default address
     * @param result default address
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @ActionBind(SavingsActionType.GET_DEFAULT_ADDRESS)
    private requestDefaultAddress({ result, entity, pageIndex }) {
        const order = (result.branchNameKanji && result.branchNo) ? entity.next : entity.skip;
        this.getNextChatByAnswer({ order: order, pageIndex: pageIndex }, result);
    }

    /*
     * タブレット申込情報照会結果設定
     * @param data タブレット申込情報照会結果
     */
    @ActionBind(SavingsActionType.GET_TABLET_APPLY_COUNT)
    private signalTabletApplyInfoResult(data: any) {
        if (!data.isSecondApply) {
            // 業務フロー関連情報を設定する
            this.setBusinessFlowInfo();

            // 顧客申込開始時間を設定する
            this.setSubmitData('customerApplyStartDate', data.systemTime);
        }

        // タブレット申込情報照会結果を発送する
        this.sendSignal(SavingsSignal.GET_TABLET_COUNT_RESULT, data.isSecondApply);
    }

    /**
     * 口座タイプを設定
     * @param data 口座タイプ
     */
    @ActionBind(SavingsActionType.SET_ACCOUNT_TYPE_INFO)
    private setAccountTypeInfo(data: any) {
        // 業務フロー関連情報を設定する
        this.setBusinessFlowInfo(data);
    }

    private setQrCodeInfo() {
        this.setSubmitData('swipeCif', this.state.receptionInfo.branchCif);
        this.setSubmitData('swipeBranchNo', this.state.receptionInfo.cardBranchNo);
        this.setSubmitData('swipeAccountNo', this.state.receptionInfo.cardAccountNo);
        this.setSubmitData('swipeAccountType', this.state.receptionInfo.cardAccountType);

        this.setSubmitData('receptionBranchNo', this.state.receptionInfo.receptionBranchNo);
        this.setSubmitData('receptionNo', this.state.receptionInfo.receptionNo);
        this.setSubmitData('receptionTime', this.state.receptionInfo.receptionTime);

        this.state.chatFlowInfo.forEach((element) => {
            if (element.purpose === this.state.receptionInfo.purpose) {
                this.errorMessageService.applyBusinessType = element.applyBusinessType;
            }
        });
    }

    private setBusinessFlowInfo(accountType?: string) {
        if (accountType) {
            if (this.applyBusinessType.get(accountType)) {
                this.setSubmitData('applyBusinessType', this.applyBusinessType.get(accountType));
            } else {
                this.setSubmitData('applyBusinessType', null);
            }
        } else {
            this.state.chatFlowInfo.forEach((element) => {
                if (element.purpose === this.state.receptionInfo.purpose) {
                    if ((element.swipecif === COMMON_CONSTANTS.SwipeCardType.SwipeCardOrNot)
                        || (this.state.receptionInfo.branchCif && element.swipecif === COMMON_CONSTANTS.SwipeCardType.SwipeCard)
                        || (!this.state.receptionInfo.branchCif && element.swipecif === COMMON_CONSTANTS.SwipeCardType.SwipeNoCard)) {
                        this.setSubmitData('accountType', element.accountType);
                        this.setSubmitData('accountTypeText', element.accountTypeText);
                        this.setSubmitData('applyBusinessType', element.applyBusinessType);
                    }
                }
            });
        }
    }

    // Reception Menuから選択した口座タイプの情報をセット
    private getApplyBusinessTypeFromMenu() {
        // 初期化
        this.applyBusinessType = new Map<string, string>();
        // 普通預金口座開設
        this.applyBusinessType.set(AccountType.ORDINARY_DEPOSIT, ApplyBusinessType.ORDINARY_DEPOSIT);
        this.applyBusinessType.set(AccountType.ORDINARY_DEPOSIT_CHILDREN, ApplyBusinessType.ORDINARY_DEPOSIT_CHILDREN);
        // 貯蓄預金口座開設
        this.applyBusinessType.set(AccountType.ORDINARY_DEPOSIT_SAVINGS_DIPOSIT, ApplyBusinessType.ORDINARY_DEPOSIT_SAVINGS_DIPOSIT);
        // 既存・普通預金口座開設
        this.applyBusinessType.set(AccountType.EXISTING_SAVINGS, ApplyBusinessType.EXISTING_ORDINARY_DEPOSIT);
        // 定期預金払い戻し
        this.applyBusinessType.set(AccountType.CANCEL, ApplyBusinessType.CANCELLATION);
        // 届出内容の変更
        this.applyBusinessType.set(AccountType.CHANGE, ApplyBusinessType.CHANGE_NAME_ADDRESS);
        this.applyBusinessType.set(AccountType.STUDENT_NEW, ApplyBusinessType.STUDENT_NEW);
        this.applyBusinessType.set(AccountType.STUDENT_CHANGE, ApplyBusinessType.STUDENT_CHANGE);
        this.applyBusinessType.set(AccountType.STUDENT_CHANGE, ApplyBusinessType.STUDENT_CHANGE);
        // 相続
        this.applyBusinessType.set(AccountType.INHERIT, ApplyBusinessType.INHERIT);
        // 既存・貯蓄預金口座開設
        this.applyBusinessType.set(AccountType.EXISTING_STORAGE, ApplyBusinessType.EXISTING_ORDINARY_DEPOSIT_SAVINGS_DIPOSIT);
        // 自動振込
        this.applyBusinessType.set(AccountType.AUTOMATIC_TRANSFER, ApplyBusinessType.AUTOMATIC_TRANSFER);
        // 定期預金書替
        this.applyBusinessType.set(AccountType.TIME_DEPOSIT_REWRITING, ApplyBusinessType.TIME_DEPOSIT_REWRITING);
    }

    private setDocumentMap() {
        this.documentMap = new Map<number, string>();
        this.documentMap.set(Constants.IdentityDocumentCategory.Document1, 'identificationDocument1Images');
        this.documentMap.set(Constants.IdentityDocumentCategory.Document2, 'identificationDocument2Images');
        this.documentMap.set(Constants.IdentityDocumentCategory.Address, 'identificationAddressImages');
        this.documentMap.set(Constants.IdentityDocumentCategory.AgentDocument1, 'identificationDocument1AgentImages');
        this.documentMap.set(Constants.IdentityDocumentCategory.AgentDocument2, 'identificationDocument2AgentImages');
        this.documentMap.set(Constants.IdentityDocumentCategory.AgentAddress, 'identificationAddressAgentImages');
        // 在籍確認書類
        this.documentMap.set(Constants.IdentityDocumentCategory.EnrollmentCertificate, 'imageEnrollmentCertificate');
        this.documentMap.set(Constants.IdentityDocumentCategory.SchoolName, 'imageSchoolName');
        // 学生確認
        this.documentMap.set(Constants.IdentityDocumentCategory.StudentId, 'identificationStudentImages');
    }

    /**
     * 重複口座情報をセット
     * @param data 重複口座情報
     */
    @ActionBind(SavingsActionType.SET_DUPLICATE_ACCOUNT_INFO)
    private settingDuplicateAccount(data: DuplicateAccountEntity) {
        this.setSubmitData('redundantReason', data.reason.value);
        this.setSubmitData('redundantReasonText',
            data.reason.value === CodeCategory.CODE_CATEGORY_DUPLICATION_REASON_OTHER ? data.reason.text : null);
        this.setSubmitData('redundantCif', data.branchCif);
        this.setSubmitData('redundantBranchNo', data.branchNo);
        this.setSubmitData('interviewFlag', data.interview);
        // 本人確認資料確認
        this.setSubmitData('redundantIdentityVerifiedFlag', data.identityVerified);
        // 取引時確認記録状況
        this.setSubmitData('redundantStartUpVerifiedFlag', data.startUpVerified);
        // 共通印登録状況
        this.setSubmitData('redundantCommonSealStatus', data.sharedSignetType);
        // 総合口座を持っているフラグ
        this.setSubmitData('hasComprehensive', data.hasComprehensive);

        this.sendSignal(SavingsSignal.SET_DUPLICATE_ACCOUNT_INFO);
    }

    /**
     * こどもが来店できない理由
     */
    @ActionBind(SavingsActionType.SET_CANT_COME_REASON)
    private setChildrenCantComeReason() {
        this.setSubmitData('cantComeReason', AgentNoVistingReason.TOO_YOUNG);
    }

    /**
     * 郵便番号　default value
     */
    @ActionBind(SavingsActionType.SET_DEFAULT_ZIP_CODE)
    private setDefaultZipCode() {
        this.setSubmitData('firstZipCode', ZipCode.FIRST_ZIP_CODE);
        this.setSubmitData('lastZipCode', ZipCode.LAST_ZIP_CODE);

    }

    /**
     * 自動振替情報更新
     */
    @ActionBind(SavingsActionType.MODIFY_AUTO_TRANSFER)
    private modifyAutoTransfer() {
        this.setSubmitData('autoTransfer', '0');
    }

    /**
     * 振替開始日／初回振替開始日を設定する（引数で渡された日付の翌日を設定する）
     * @param data 日付文字列
     */
    @ActionBind(SavingsActionType.SET_AUTOMATIC_TRANSFER_START_DATE)
    private setAutomaticTransferStartDate(data: string) {
        const automaticTransferStartDate = moment(data).add(1, COMMON_CONSTANTS.DATE_DAY)
            .format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
        this.setSubmitData('automaticTransferStartDate', automaticTransferStartDate);
    }

    /**
     * 文字チェック。
     */
    @ActionBind(SavingsActionType.CHARACTER_CHECK)
    private characteCheck(data: any) {
        this.sendSignal(SavingsSignal.CHARACTER_CHECK);
    }

    /**
     * 受付可否チェック。
     */
    @ActionBind(SavingsActionType.RECEPTION_CHECK)
    private receptionCheck(data: any) {
        Object.keys(data).forEach((key) => {
            this.setSubmitData(key, data[key]);
        });
    }

    /**
     * 受付可否チェック。
     */
    @ActionBind(SavingsActionType.RECEPTION_CHECK_ALL_CIF)
    private receptionCheckAllCif(data: any) {
        Object.keys(data).forEach((key) => {
            this.setSubmitData(key, data[key]);
        });
        this.sendSignal(SavingsSignal.RECEPTION_CHECK_ALL_CIF);
    }

    /**
     * 受付可否チェック(喪失・破損)のレスポンスをstateにセットする
     * @param data APIのレスポンス
     */
    @ActionBind(SavingsActionType.RECEPTION_LOSS_CORRUPTION_CHECK)
    private onAcceptCheck(param: {
        name?: string, data: ReceptionLossCorruptionCheckResponse,
        requestParams: ReceptionLossCorruptionCheckRequest
    }) {
        // 受付可否チェックの実行結果を保存する
        if (param.name) {
            this.setSubmitData(param.name, param.data);
        } else {
            // 内部API:受付可否チェック（喪失・破損）と内部API:受付可否チェックのレスポンス構造差分吸収
            // MVP3向けAPIレスポンスを、MVP2向けAPIレスポンスの型に合わせ、後続処理への影響を軽減。
            const response = param.data instanceof HttpStatusError ? param.data : {
                errorCode: param.data.errorCode,
                errorType: param.data.errorType,
                resultCode: param.data.resultCode,
                unacceptables: param.data.accounts[0].unacceptables
            };
            Object.keys(response).forEach((key) => {
                this.setSubmitData(key, response[key]);
            });
        }

        // エラーモーダル表示用データを作成する
        let responseForModal: Array<{
            customerId?: string, branchCode?: string, subjectCode?: string, bankAccountId?: string,
            accounts: ReceptionCheckAccountInfo
        }> = [];

        if (param.data && (this.isHostError(param.data.errorCode) ||
            param.data.accounts.some((accountInfo) => this.isHostError(accountInfo.errorCode)))) {
            if (param.data.accounts) {
                for (let i = 0; i < param.data.accounts.length; i++) {
                    if (param.requestParams.params.accounts[i].customerId) {
                        responseForModal.push(
                            {
                                customerId: param.requestParams.params.accounts[i].customerId,
                                accounts: param.data.accounts[i]
                            }
                        );
                    } else {
                        responseForModal.push(
                            {
                                branchCode: param.requestParams.params.accounts[i].tenban,
                                subjectCode: param.requestParams.params.accounts[i].accountType,
                                bankAccountId: param.requestParams.params.accounts[i].accountNo,
                                accounts: param.data.accounts[i]
                            }
                        );
                    }
                }
            }
        } else {
            // エラーがない場合はresponseForModalにundefinedを設定
            responseForModal = undefined;
        }
        // 後続処理にてモーダル表示のため、stateに格納
        this.setSubmitData('responseForModal', responseForModal);

        this.sendSignal(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK);
    }

    /**
     * 受付可否チェック(喪失・破損)のレスポンスをstateにセットする。
     * エラー情報が存在する場合、追加する。
     * @param data APIのレスポンス
     */
    @ActionBind(SavingsActionType.RECEPTION_LOSS_CORRUPTION_CHECK_ADD)
    private onAcceptCheckAndResponseAdd(param: {
        name?: string, data: ReceptionLossCorruptionCheckResponse,
        requestParams: ReceptionLossCorruptionCheckRequest
    }) {
        // 受付可否チェックの実行結果を保存する
        if (param.name) {
            this.setSubmitData(param.name, param.data);
        } else {
            // 内部API:受付可否チェック（喪失・破損）と内部API:受付可否チェックのレスポンス構造差分吸収
            // MVP3向けAPIレスポンスを、MVP2向けAPIレスポンスの型に合わせ、後続処理への影響を軽減。
            const response = param.data instanceof HttpStatusError ? param.data : {
                errorCode: param.data.errorCode,
                errorType: param.data.errorType,
                resultCode: param.data.resultCode,
                unacceptables: param.data.accounts[0].unacceptables
            };
            Object.keys(response).forEach((key) => {
                this.setSubmitData(key, response[key]);
            });
        }

        // エラーモーダル表示用データを作成する(前回チェック時のエラーデータが存在する場合は追記する)
        let responseForModal: Array<{
            customerId?: string, branchCode?: string, subjectCode?: string, bankAccountId?: string,
            accounts: ReceptionCheckAccountInfo
        }> = this.state.submitData.responseForModal ? this.state.submitData.responseForModal : [];

        if (param.data && (this.isHostError(param.data.errorCode) ||
            param.data.accounts.some((accountInfo) => this.isHostError(accountInfo.errorCode)))) {
            if (param.data.accounts) {
                for (let i = 0; i < param.data.accounts.length; i++) {
                    if (param.requestParams.params.accounts[i].customerId) {
                        responseForModal.push(
                            {
                                customerId: param.requestParams.params.accounts[i].customerId,
                                accounts: param.data.accounts[i]
                            }
                        );
                    } else {
                        responseForModal.push(
                            {
                                branchCode: param.requestParams.params.accounts[i].tenban,
                                subjectCode: param.requestParams.params.accounts[i].accountType,
                                bankAccountId: param.requestParams.params.accounts[i].accountNo,
                                accounts: param.data.accounts[i]
                            }
                        );
                    }
                }
            }
        }

        // エラーがない場合はresponseForModalにundefinedを設定
        if (!responseForModal.length) {
            responseForModal = undefined;
        }

        // 後続処理にてモーダル表示のため、stateに格納
        this.setSubmitData('responseForModal', responseForModal);

        this.sendSignal(SavingsSignal.RECEPTION_LOSS_CORRUPTION_CHECK_ACCOUNT);
    }

    /**
     * フィルタリングシステム検索。
     */
    @ActionBind(SavingsActionType.FILTERING_INQUIRY)
    private filterInquiry(data: any) {
        Object.keys(data).forEach((key) => {
            this.setSubmitData(key, data[key]);
        });
        this.setSubmitData('outStatusText', data.outStatus === OutStatus.OFF ? OutStatusText.OFF : OutStatusText.ON);
        this.sendSignal(SavingsSignal.FILTERING_INQUIRY, [{
            key: 'outStatusText',
            value: data.outStatus === OutStatus.OFF ? OutStatusText.OFF : OutStatusText.ON
        }, ...Object.keys(data).map((key) => {
            return {
                key: key,
                value: data[key]
            };
        })]);

        // filtering結果を前回フィルタリング結果対象に保存
        this.state.lastFilteringResult = data;
    }

    /**
     * フィルタリングシステムのパラメタを保存。
     */
    @ActionBind(SavingsActionType.SET_LAST_FILTERING_PARAMS)
    private setLastFilteringParams(data: FilteringParameterEntity) {
        this.state.lastFilteringParameter = data;
    }

    /**
     * #24401
     * 翌営業日を取得する。
     */
    @ActionBind(SavingsActionType.GET_NEXT_BUSINESS_DAY)
    private getNextBusinessDay(data: any) {
        const d = moment(data.data.nextBusinessDay).format('YYYY-MM-DD');
        this.setSubmitData('dueDate', d);
    }

    /**
     * マスキング未確認データから確認済の写真を削除する
     *
     * @private
     * @param {*} data
     * @memberof SavingsStore
     */
    @ActionBind(SavingsActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES)
    private removeNotMaskingConfirmImages(data: any) {
        const { documentName, index } = data;
        // indexパラメータが存在する時に、documentNameの属性が配列と認識して
        if (index !== undefined) {
            this.state.notMaskingConfirmImages[documentName].splice(index, 1);
        } else if (this.state.notMaskingConfirmImages[documentName] !== undefined
            && typeof this.state.notMaskingConfirmImages[documentName] === 'boolean') {
            // documentNameの属性は存在かつbooleanの場合、値をfalseにする
            this.state.notMaskingConfirmImages[documentName] = false;
        }
    }

    @ActionBind(SavingsActionType.RESET_NOT_MASKING_CONFIRM_IMAGES)
    private resetNotMaskingConfirmImages(type: ClearSavingImagesClickRecordType) {
        const _documentResetFn = (documentName: string) => {
            // 書類の保存タイプはboolean
            if (typeof this.state.notMaskingConfirmImages[documentName] === 'boolean') {
                this.state.notMaskingConfirmImages[documentName] = false;

                if (this.state.submitData[documentName]) {
                    this.state.notMaskingConfirmImages[documentName] = true;
                }
            } else {
                // 書類の保存タイプは配列
                this.state.notMaskingConfirmImages[documentName] = [];

                if (this.state.submitData[documentName]) {
                    this.state.submitData[documentName].forEach(
                        (item, index) => {
                            this.state.notMaskingConfirmImages[documentName].push(index);
                        }
                    );
                }
            }
        };

        switch (type) {
            case ClearSavingImagesClickRecordType.DOCUMENT:
                // 既存写真によって、マスキング未確認データをリセット
                Object.keys(this.state.notMaskingConfirmImages).forEach(
                    (atrribute) => {
                        _documentResetFn(atrribute);
                    }
                );
                break;
            case ClearSavingImagesClickRecordType.CLEAR:
                // 在籍確認書類、本人確認書類１、本人確認書類２、住所確認書類をクリア
                Object.keys(this.state.notMaskingConfirmImages).forEach(
                    (atrribute) => {
                        this.state.notMaskingConfirmImages[atrribute] =
                            typeof this.state.notMaskingConfirmImages[atrribute] === 'boolean' ? false : [];
                    }
                );
                break;
            default:
                break;
        }
    }

    @ActionBind(SavingsActionType.RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES)
    private resetSpecialNotMaskingConfirmImages(specalDocumentName: string) {
        const _documentResetFn = (documentName: string) => {
            // 書類の保存タイプはboolean
            if (typeof this.state.notMaskingConfirmImages[documentName] === 'boolean') {
                this.state.notMaskingConfirmImages[documentName] = false;

                if (this.state.submitData[documentName]) {
                    this.state.notMaskingConfirmImages[documentName] = true;
                }
            } else {
                // 書類の保存タイプは配列
                this.state.notMaskingConfirmImages[documentName] = [];

                if (this.state.submitData[documentName]) {
                    this.state.submitData[documentName].forEach(
                        (item, index) => {
                            this.state.notMaskingConfirmImages[documentName].push(index);
                        }
                    );
                }
            }
        };

        _documentResetFn(specalDocumentName);
    }

    private agentAddress() {
        const prefecture = this.state.submitData.holderAddressPrefecture ? this.state.submitData.holderAddressPrefecture : '';
        const countyUrbanVillage = this.state.submitData.holderAddressCountyUrbanVillage ?
            this.state.submitData.holderAddressCountyUrbanVillage : '';
        const streetName = this.state.submitData.showStreet ?
            this.state.submitData.showStreet : (this.state.submitData.getHolderAddressStreetName
                ? this.state.submitData.getHolderAddressStreetName() : '');
        const addressHouseNumber = this.state.submitData.holderAddressHouseNumber ? this.state.submitData.holderAddressHouseNumber : '';

        return prefecture + countyUrbanVillage + streetName + addressHouseNumber;
    }

    private resetIdentificationDocument(order, pageIndex) {
        const chat = this.state.questions[pageIndex].find((item) => item.order === order);
        // 本人確認書類が「住民票の写し（原本）」を選択された場合、「記載あり」→「記載なし」変更された時に、本人確認書類が「null」になることを対応
        if (chat && /@\S+にマイナンバーは記載されていますか？/.test(chat.question)) {
            let propertyNm;
            // 代理人/本人
            chat.question.indexOf('@agentIdentificationDocument') > -1 ?
                propertyNm = 'agentIdentificationDocument' : propertyNm = 'identificationDocument';
            const name = propertyNm + chat.question.replace(/@\S+(\d{1})\S+/, '$1');
            const filter = this.state.showChats.filter((show) => show.name === name);
            if (filter && filter.length > 0) {
                const answer = filter[filter.length - 1].answer;
                answer.value.forEach((element) => {
                    this.setSubmitData(element.key, element.value);
                });
                this.setSubmitData(name + 'Text', answer.text);
            }
        }
    }

    /**
     * 普通預金本人確認チャットに表示する住所を取得
     * 認証画面の表示を一致するため、認証画面の表示ロジックをコッピーしてくる
     *
     * @private
     * @returns
     * @memberof SavingsStore
     */
    private getAddressIdenConfirm() {
        const prefecture = this.state.submitData.holderAddressPrefecture ? this.state.submitData.holderAddressPrefecture : '';
        const countyUrbanVillage =
            this.state.submitData.holderAddressCountyUrbanVillage ? this.state.submitData.holderAddressCountyUrbanVillage : '';
        const streetName =
            this.state.submitData.showStreet ? this.state.submitData.showStreet : this.state.submitData.getHolderAddressStreetName();
        const addressHouseNumber = this.state.submitData.holderAddressHouseNumber ? this.state.submitData.holderAddressHouseNumber : '';

        return prefecture + countyUrbanVillage + streetName + addressHouseNumber;
    }

    /**
     * 普通預金本人確認チャットに表示するカナ住所を取得
     * 認証画面の表示を一致するため、認証画面の表示ロジックをコッピーしてくる
     *
     * @private
     * @returns
     * @memberof SavingsStore
     */
    private getAddressFurikanaIdenConfirm() {
        const prefecturekana =
            this.state.submitData.holderAddressPrefectureFuriKana ? this.state.submitData.holderAddressPrefectureFuriKana : '';
        const countyUrbanVillagekana = this.state.submitData.holderAddressCountyUrbanVillageFuriKana ?
            this.state.submitData.holderAddressCountyUrbanVillageFuriKana : '';
        const streetNamekana = this.state.submitData.getHolderAddressStreetNameFuriKana() ?
            this.state.submitData.getHolderAddressStreetNameFuriKana() : '';
        const addressHouseNumberkana = this.state.submitData.holderAddressHouseNumberFuriKana ?
            this.state.submitData.holderAddressHouseNumberFuriKana : '';

        return prefecturekana + countyUrbanVillagekana + streetNamekana + addressHouseNumberkana;
    }

    /**
     * ICカードの情報をstateに登録
     *
     * @private
     * @param {string} data
     * @memberof SavingsStore
     */
    @ActionBind(SavingsActionType.SET_IC_DATA)
    private setIcData(data: string) {
        this.state.icData = data;
    }

    /**
     * 外国人本人確認書類をクリア
     */
    @ActionBind(SavingsActionType.CLEAR_FOREIGN_ALL_DOCUMENT)
    private clearForeignIdentificationDocument() {
        // 本人確認書類チャット
        this.cleanIdentityDocumentImage(Constants.IdentityDocumentCategory.Address);
        this.cleanIdentityDocumentImage(Constants.IdentityDocumentCategory.AgentAddress);
        this.cleanIdentityDocumentImage(Constants.IdentityDocumentCategory.AgentDocument1);
        this.cleanIdentityDocumentImage(Constants.IdentityDocumentCategory.AgentDocument2);
        this.cleanIdentityDocumentImage(Constants.IdentityDocumentCategory.Document1);
        this.cleanIdentityDocumentImage(Constants.IdentityDocumentCategory.Document2);
        this.cleanIdentityDocumentImage(Constants.IdentityDocumentCategory.EnrollmentCertificate);
        this.cleanIdentityDocumentImage(Constants.IdentityDocumentCategory.StudentId);

        this.setSubmitData('identificationDocument1ExpiryDate', null);
        this.setSubmitData('identificationDocument2', null);
        this.setSubmitData('identificationDocument2ExpiryDate', null);
        this.setSubmitData('identificationDocument2Text', null);
        this.setSubmitData('identificationDocumentLicenseNo', null);
        this.setSubmitData('addressConfirmationDocumentName', null);
        this.setSubmitData('addressConfirmationDocumentExpirationDate', null);
        // 連絡事項
        this.setSubmitData('contactNote', null);

        this.state.checkboxStatus = {
            receiptMethodStatus: false,
            confirmationStatus: false,
            isAntisocialStatus: true,
            isForeignPulicFiguresSatus: true,
            isJapaneseResidentStatus: false,
            isRegulationStatus: false,
            isAllMaskingStatus: false,
            isCheckBranchStatus: false,
            isAgentAllMaskingStatus: false,
        };
    }

    /**
     * ocrEntityの項目を最大桁数でカットする
     * 以下の項目：
     * ・漢字氏名
     * ・カナ氏名
     * ・漢字住所
     * ・カナ住所
     *
     * @private
     * @param {OCREntity} ocrEntity
     * @memberof SavingsStore
     */
    private modifyOcrEntityByMaxLength(ocrEntity: OCREntity) {
        // 漢字氏名姓名がそれぞれ最大２８文字、合わせて２９文字
        const resultKanjiName = InputUtils.getTwoStringByMaxLength(ocrEntity.firstName, ocrEntity.lastName, 28, 28, 29);
        ocrEntity.firstName = resultKanjiName.item1Result;
        ocrEntity.lastName = resultKanjiName.item2Result;

        // カナ氏名姓名がそれぞれ最大３０文字、合わせて４７文字。半角で計算
        const resultKanaName = InputUtils.getTwoStringByMaxLength(ocrEntity.firstNameKana, ocrEntity.lastNameKana, 30, 30, 47, true);
        ocrEntity.firstNameKana = resultKanaName.item1Result;
        ocrEntity.lastNameKana = resultKanaName.item2Result;

        // 番地以後漢字最大５０文字
        ocrEntity.houseNumber = ocrEntity.houseNumber ? ocrEntity.houseNumber.substr(0, 50) : ocrEntity.houseNumber;
        ocrEntity.houseNumberKana = ocrEntity.houseNumberKana ?
            InputUtils.getStringByMaxLength(ocrEntity.houseNumberKana, 84) : ocrEntity.houseNumberKana;
    }

    /**
     * 口座存在チェック結果設定
     * @param data response data
     */
    @ActionBind(SavingsActionType.GET_ACCOUNT_EXISTING)
    private signalAccountExistenceCheckResult(data: any) {
        if (data.hasAccountExist) {
            const info = data.result.cifInfoInquiryResponse;
            if (!info) {
                return;
            }
            Object.keys(info).forEach((key) => {
                this.setSubmitData(key, info[key]);
            });

            this.setSubmitData('addressKana', StringUtils.convertHankaku2Zankaku(info.addressKana));
            this.setSubmitData('nameKana', StringUtils.convertHankaku2Zankaku(info.nameKana));

            // 漢字変換不可フラグがtrueの場合、かな名を設定する。
            if (this.state.submitData.nameNonConvert === NameNonConvert.OFF) {
                this.setSubmitData('nameKanjiBackup', this.state.submitData.nameKanjiBackup || this.state.submitData.nameKanji);
                this.setSubmitData('nameKanji', this.state.submitData.nameKana);
            }

            if (data.errors && data.errors.data && this.isHostError(data.errors.data.errorCode)) {
                this.setSubmitData('resultCode', data.result.resultCode);
                this.setSubmitData('errorCode', data.result.errorCode);
                this.setSubmitData('errorType', data.result.errorType);
                this.setSubmitData('unacceptables', data.result.unacceptables);

                const unacceptableCode = data.result.unacceptables.map((unacceptable: any) => {
                    return unacceptable.unacceptableCode;
                }).join('/');

                this.setSubmitData('unacceptableCode', unacceptableCode);
            }
        }
        // 口座存在チェック結果を発送する
        this.sendSignal(SavingsSignal.GET_CHECK_ACCOUNT_EXISTING, data.hasAccountExist);
    }

    /**
     * 諸届選択時、申込業務を書換する。
     *
     * @private
     * @memberof SavingsStore
     */
    @ActionBind(SavingsActionType.SELECT_CHANGE)
    private selectChange() {
        this.setSubmitData(COMMON_CONSTANTS.NAME_ACCOUNT_TYPE, SelectChangeParam.ACCOUNT_TYPE);
        this.setSubmitData(COMMON_CONSTANTS.NAME_ACCOUNT_TYPE_TEXT, this.labelService.labels.reception.changeButtonReception);
        this.setSubmitData(COMMON_CONSTANTS.NAME_APPLY_BIZ_CATEGORY, SelectChangeParam.APPLY_BIZ_CATEGORY);
        this.setSubmitData(COMMON_CONSTANTS.NAME_BUSINESS_CODE, SelectChangeParam.BUSINESS_CODE);
        this.setSubmitData(COMMON_CONSTANTS.NAME_CHAT_FLOW_NAME, 'ChangeChatComponent');
    }

    /**
     *  OCR読取した免許証が運転経歴証明書だった場合のstate更新処理
     *
     * @private
     * @memberof SavingsStore
     */
    private setStateDataForHasDriversCareerLicense() {
        // OCR読取した免許証が運転経歴証明書だった場合に処理を実行
        if (this.state.submitData.hasLicense === Constants.DriveCard
            && this.state.submitData.hasDriversCareerLicense === HasDriversCareerLicense.YES) {
            // 免許証を持っていないステータスに変更
            this.setSubmitData('hasLicense', HasLicense.HAS_NOT_LICENSE);

            // 本人の場合の本人確認書類情報をstateにセット
            this.setSubmitData('identificationDocument1', IdentificationDocumentCode.OTHER_IDENTIFICATION_DOCUMENT);
            this.setSubmitData(
                'identificationDocument1Text', this.labelService.labels.confirm.identityDocumentConfirm.otherIdentificationDocument
            );
            this.setSubmitData('documentListName', this.labelService.labels.confirm.identityDocumentConfirm.driversCareerLicense);
            // 運転経歴証明書を再撮影した場合、再撮影後の画像データは
            // identificationDocument1Imagesに格納されているので最初にOCR撮影した画像で書き換わらないようにする
            if (this.state.submitData.identificationDocument1Images === undefined) {
                // identificationDocument1Imagesがundefinedの場合、OCR撮影した画像データを格納する
                this.setSubmitData(
                    'identificationDocument1Images', [this.state.submitData.holderCardImageFront, this.state.submitData.holderCardImageBack]
                );
            }
            this.setSubmitData('identificationDocument1ExpiryDate', COMMON_CONSTANTS.DEFAULT_EXPIRY_DATE);
            this.setSubmitData('identificationDocument1ExpiryDateText', this.labelService.labels.picker.skipExpiryDate);
            this.setSubmitData('idInfoMethod', IdentificationDocumentMethod.PRESENT_ONE_TYPE);

            // OCR読取ありの場合の画像保存変数を初期化
            // 撮影した画像はOCR読取なしの場合の画像保存変数に移行済みのため重複を防ぐ
            this.state.submitData.holderCardImageFront = undefined;
            this.state.submitData.holderCardImageBack = undefined;

            // if (this.state.submitData.isAgent === PrincipalAgentCategory.HOLDER) {
            //     // 本人の場合の本人確認書類情報をstateにセット
            //     this.setSubmitData('identificationDocument1', IdentificationDocumentCode.OTHER_IDENTIFICATION_DOCUMENT);
            //     this.setSubmitData(
            //         'identificationDocument1Text', this.labelService.labels.confirm.identityDocumentConfirm.otherIdentificationDocument
            //     );
            //     this.setSubmitData('documentListName', this.labelService.labels.confirm.identityDocumentConfirm.driversCareerLicense);
            //     this.setSubmitData(
            //         'identificationDocument1Images',
            //          [this.state.submitData.holderCardImageFront, this.state.submitData.holderCardImageBack]
            //     );
            //     this.setSubmitData('identificationDocument1ExpiryDate', COMMON_CONSTANTS.DEFAULT_EXPIRY_DATE);
            //     this.setSubmitData('identificationDocument1ExpiryDateText', this.labelService.labels.picker.skipExpiryDate);
            //     this.setSubmitData('idInfoMethod', IdentificationDocumentMethod.PRESENT_ONE_TYPE);

            //     // OCR読取ありの場合の画像保存変数を初期化
            //     // 撮影した画像はOCR読取なしの場合の画像保存変数に移行済みのため重複を防ぐ
            //     this.state.submitData.holderCardImageFront = undefined;
            //     this.state.submitData.holderCardImageBack = undefined;

            // } else if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) {
            //     // 代理人の場合の本人確認書類情報をstateにセット
            //     this.setSubmitData('agentIdentificationDocument1', IdentificationDocumentCode.OTHER_IDENTIFICATION_DOCUMENT);
            //     this.setSubmitData(
            //         'agentIdentificationDocument1Text',
            //          this.labelService.labels.confirm.identityDocumentConfirm.otherIdentificationDocument
            //     );
            //     this.setSubmitData('agentDocumentListName',
            //          this.labelService.labels.confirm.identityDocumentConfirm.driversCareerLicense);
            //     this.setSubmitData(
            //         'identificationDocument1AgentImages',
            //         [this.state.submitData.agentCardImageFront, this.state.submitData.agentCardImageBack]
            //     );
            //     this.setSubmitData('agentIdentificationDocument1ExpiryDate', COMMON_CONSTANTS.DEFAULT_EXPIRY_DATE);
            //     this.setSubmitData('agentIdentificationDocument1ExpiryDateText', this.labelService.labels.picker.skipExpiryDate);

            //     // OCR読取ありの場合の画像保存変数を初期化
            //     // 撮影した画像はOCR読取なしの場合の画像保存変数に移行済みのため重複を防ぐ
            //     this.state.submitData.agentCardImageFront = undefined;
            //     this.state.submitData.agentCardImageBack = undefined;
            // }
        }
    }

    private makeBranchList() {
        const allBranchNameList: string[] = [];
        const customerIdList: string[] = [];
        const branchNameList: string[] = [];
        const firstIndex: string = '１';
        this.state.submitData.allCifInfos.forEach((cifInfo) => {
            let branchName = cifInfo.customerManagementBranchName;
            // 支店名が重複した場合、同一支店名リスト作成（初回ループは作成なし）
            const sameBranchNameList = allBranchNameList.filter((item) => item === branchName);
            allBranchNameList.push(branchName);
            // 同一支店名編集
            if (sameBranchNameList.length > 0) {
                if (sameBranchNameList.length === 1) {
                    // 先頭の支店名に”１”を付与
                    const editIndex = branchNameList.findIndex((item) => item === branchName);
                    branchNameList[editIndex] += firstIndex;
                }
                // 同一支店名に数字を付与
                branchName += (sameBranchNameList.length + 1);
                branchName = StringUtils.convertHankaku2Zankaku(branchName);
            }
            branchNameList.push(branchName);
            customerIdList.push(cifInfo.customerId);
        });
        this.setSubmitData('branchNameList', branchNameList);
        // 後続業務で利用するためEntity型の情報も保存する
        const branchNameListEntity: BranchNameListEntity[] = [];
        for (let i = 0; i < this.state.submitData.allCifInfos.length; i++) {
            branchNameListEntity.push({ branchName: branchNameList[i], customerId: customerIdList[i] });
        }
        this.setSubmitData('branchNameListEntity', branchNameListEntity);

    }
    /**
     * keysAryをバックアップ
     */
    @ActionBind(SavingsActionType.KEYS_ARY_BACKUP)
    private keysAryBackup() {
        this.keysArrBackup = Object.assign(new Array(), this.keysArr);

    }

    /**
     * keysAryを戻す
     */
    @ActionBind(SavingsActionType.KEYS_ARY_ROLLBACK)
    private keysAryRollback() {
        this.keysArr = this.keysArrBackup;
    }

    /**
     * 返却されたエラーコードが、受付可否チェック検出対象かを確認する。
     */
    private isHostError(errorCode: string): boolean {
        return (Object.keys(HostErrorCodeReceptionNG).some((key) => HostErrorCodeReceptionNG[key] === errorCode));
    }

    /**
     * BC複合取引情報を保存する。
     */
    @ActionBind(SavingsActionType.SAVE_CREDIT_CARD_DATA)
    private saveCreditCardData(creditCardSubmitData: any) {
        // 職業
        this.setSubmitData('career', creditCardSubmitData.career);
        // 卒業90日以内のフラグ
        this.setSubmitData('isNearGraduate', creditCardSubmitData.isNearGraduate);
    }

    /**
     * 修正前の口座開設店を保存する。
     */
    @ActionBind(SavingsActionType.SAVE_TENBAN_BEFORE)
    private saveTenbanBefore(tenban: string) {
        this.state.tenbanBefore = tenban;
    }

    /**
     * 受付チャットから「純新規」後続業務に行くときに、
     * 後続業務をうまく実行するために、パラメータ変更を行います。
     * @param params
     */
    @ActionBind(SavingsActionType.RECEPTION_CHANGE_NEW_ACCOUNT_JAPANES)
    private receptionChangeNewAccountJapanes() {
        this.setSubmitData('hasSwipeCard', false);
        this.setSubmitData('chatFlowName', 'InitConfirmComponent');
        this.setSubmitData('applyBusinessType', '01');
        this.setSubmitData('applyBizCategory', '01');
        this.setSubmitData('menuNational', '1');
    }

    /**
     * 受付チャットから「外国人」後続業務に行くときに、
     * 後続業務をうまく実行するために、パラメータ変更を行います。
     * @param params
     */
    @ActionBind(SavingsActionType.RECEPTION_CHANGE_NEW_ACCOUNT_FORGINER)
    private receptionChangeNewAccountForginer() {
        this.setSubmitData('hasSwipeCard', false);
        this.setSubmitData('chatFlowName', 'ForeignerInitConfirmComponent');
        this.setSubmitData('applyBusinessType', '01');
        this.setSubmitData('applyBizCategory', '04');
        this.setSubmitData('menuNational', '1');

        this.setSubmitData('firstNameKanji', this.state.submitData.firstName);
        this.setSubmitData('lastNameKanji', this.state.submitData.lastName);
        this.setSubmitData('birthdate', this.state.submitData.holderBirthdate);
        this.setSubmitData('birthdateText', this.state.submitData.holderBirthdateText);
        this.setSubmitData('mobilePhoneNo', this.state.submitData.holderMobileNo);
        this.setSubmitData('otherPhoneNo', this.state.submitData.holderTelephoneNo);
    }

    /**
     * 受付チャットから「既存新規」後続業務に行くときに、
     * 後続業務をうまく実行するために、パラメータ変更を行います。
     * @param params
     */
    @ActionBind(SavingsActionType.RECEPTION_CHANGE_EXISTING_ACCOUNT)
    private receptionChangeExistingAccount() {
        this.state.submitData.hasSwipeCard = false;
        this.state.submitData.chatFlowName = 'ExistingSavingsVerificationComponent';
        this.state.submitData.accountType = AccountType.EXISTING_SAVINGS;
        this.state.submitData.applyBizCategory = '01';
        this.state.submitData.businessCode = BusinessCode.SAVING_ACCOUNT;
        this.state.submitData.menuNational = '1';

        // ===========名前 start========
        this.state.submitData.existingChangeFirstName = this.state.submitData.firstName;
        this.state.submitData.existingChangeLastName = this.state.submitData.lastName;
        this.state.submitData.existingChangeFirstNameKana = this.state.submitData.firstNameKana;
        this.state.submitData.existingChangeLastNameKana = this.state.submitData.lastNameKana;
        this.state.submitData.existingChangeHolderName = this.state.submitData.firstName + '　' + this.state.submitData.lastName;
        this.state.submitData.existingChangeHolderNameFurigana = this.state.submitData.firstNameKana + '　'
            + this.state.submitData.lastNameKana;
        // ===========名前 end========

        // ===========電話番号 start========
        this.state.submitData.existingChangeFirstMobileNo = this.state.submitData.firstMobileNo; // 携帯番号　first
        this.state.submitData.existingChangeSecondMobileNo = this.state.submitData.secondMobileNo; // 携帯番号　seconde
        this.state.submitData.existingChangeThirdMobileNo = this.state.submitData.thirdMobileNo; // 携帯番号　third
        this.state.submitData.existingChangeHolderMobileNo = this.state.submitData.holderMobileNo; // 携帯番号

        this.state.submitData.existingChangeFirstTel = this.state.submitData.firstTel; // 固定番号　first
        this.state.submitData.existingChangeSecondTel = this.state.submitData.secondTel; // 固定番号　second
        this.state.submitData.existingChangeThirdTel = this.state.submitData.thirdTel; // 固定番号　third
        this.state.submitData.existingChangeHolderTelephoneNo = this.state.submitData.holderTelephoneNo; // 固定番号
        // ===========電話番号 end========

        // ===========口座開設店 start========
        this.setSubmitData('openAccountTenban', this.state.submitData.tenban);
        this.setSubmitData('openAccountBranchName', this.state.submitData.branchName);
        // ===========口座開設店 end========

        // ===========諸届paramsMVP5→MVP3 start========
        const swipeCid = this.state.submitData.selectTenpoCustomerId ?
            this.state.submitData.selectTenpoCustomerId : this.state.submitData.customerId;
        // SWCIFを除いた差分情報を格納する
        this.state.submitData.nameDifferenceInfos =
            this.state.submitData.allCifNameDif
            && this.state.submitData.allCifNameDif.filter((info) => info.customerId !== swipeCid);

        this.state.submitData.addressDifferenceInfos =
            this.state.submitData.allCifAddressDif
            && this.state.submitData.allCifAddressDif.filter((info) => info.customerId !== swipeCid);

        this.state.submitData.telDifferenceInfos =
            this.state.submitData.allCifTelDif
            && this.state.submitData.allCifTelDif.filter((info) => info.customerId !== swipeCid);

        this.state.submitData.isNameChange = false;
        this.state.submitData.isAddressChange = false;
        this.state.submitData.isTelphoneChange = false;

        // SWCIF氏名変更有無
        this.state.submitData.isNameChange =
            (this.state.submitData.allCifNameDif &&
                this.state.submitData.allCifNameDif.some((info) => info.customerId === swipeCid && info.isDifference));

        // SWCIF住所変更有無
        this.state.submitData.isAddressChange =
            (this.state.submitData.allCifAddressDif &&
                this.state.submitData.allCifAddressDif.some((info) => info.customerId === swipeCid && info.isDifference));

        // SWCIF電話番号変更有無
        this.state.submitData.isTelphoneChange =
            (this.state.submitData.allCifTelDif &&
                this.state.submitData.allCifTelDif.some((info) => info.customerId === swipeCid && info.isDifference));

        // SWCIFの受付可否チェックを格納する
        const swipeCifAcceptCheckResult =
            (this.state.submitData.receptionCheckNameDiffResult
                && this.state.submitData.receptionCheckNameDiffResult.find((result) => result.customerId === swipeCid)
                && this.state.submitData.receptionCheckNameDiffResult.filter((result) => result.customerId === swipeCid))
            || (this.state.submitData.receptionCheckAddressTelDiffResult
                && this.state.submitData.receptionCheckAddressTelDiffResult.find((result) => result.customerId === swipeCid)
                && this.state.submitData.receptionCheckAddressTelDiffResult.filter((result) => result.customerId === swipeCid));

        if (swipeCifAcceptCheckResult) {
            this.setSubmitData('swipeCifAcceptCheckResult',
                { customerId: swipeCifAcceptCheckResult[0].customerId, account: swipeCifAcceptCheckResult[0].accounts });
        }

        // 氏名差分ありCIFの受付可否チェックを格納する
        this.state.submitData.nameidentiNameDifCifAcceptCheckResult =
            (this.state.submitData.receptionCheckNameDiffResult
                && this.state.submitData.receptionCheckNameDiffResult.filter((result) => result.customerId !== swipeCid));

        // 住所差分ありCIFの受付可否チェックを格納する
        // 氏名差分ありの受付可否チェック結果を取得
        let nameidentiAddressDifCifAcceptCheckRestlt = this.state.submitData.receptionCheckNameDiffResult ?
            this.state.submitData.receptionCheckNameDiffResult.filter((result) => result.customerId !== swipeCid) : [];
        // 住所・電話番号差分ありの受付可否チェック結果があれば追加
        if (this.state.submitData.receptionCheckAddressTelDiffResult) {
            nameidentiAddressDifCifAcceptCheckRestlt =
                nameidentiAddressDifCifAcceptCheckRestlt
                    .concat(this.state.submitData.receptionCheckAddressTelDiffResult
                        .filter((result) => result.customerId !== swipeCid));
        }
        // 差分ありのcustomerIdを抽出
        const addressDiffCids = (this.state.submitData.addressDifferenceInfos && this.state.submitData.addressDifferenceInfos.filter(
            (info) => info.isDifference).map(({ customerId }) => customerId));
        // MVP3の変数に格納
        this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt =
            nameidentiAddressDifCifAcceptCheckRestlt.filter(({ customerId }) => addressDiffCids.includes(customerId));

        // 電話番号差分ありCIFの受付可否チェックを格納する
        // 氏名差分ありの受付可否チェック結果を取得
        let nameidentiTelDifCifAcceptCheckResult = this.state.submitData.receptionCheckNameDiffResult ?
            this.state.submitData.receptionCheckNameDiffResult.filter((result) => result.customerId !== swipeCid) : [];
        // 住所・電話番号差分ありの受付可否チェック結果があれば追加
        if (this.state.submitData.receptionCheckAddressTelDiffResult) {
            nameidentiTelDifCifAcceptCheckResult =
                nameidentiTelDifCifAcceptCheckResult
                    .concat(this.state.submitData.receptionCheckAddressTelDiffResult
                        .filter((result) => result.customerId !== swipeCid));
        }
        // 差分ありのcustomerIdを抽出
        const telDiffCids = (this.state.submitData.telDifferenceInfos && this.state.submitData.telDifferenceInfos.filter(
            (info) => info.isDifference).map(({ customerId }) => customerId));
        // MVP3の変数に格納
        this.state.submitData.nameidentiTelDifCifAcceptCheckResult =
            nameidentiTelDifCifAcceptCheckResult.filter(({ customerId }) => telDiffCids.includes(customerId));

        // // ===========諸届paramsMVP5→MVP3 end========
    }

    @ActionBind(SavingsActionType.GO_BACK_RELATE_CHAT)
    private gobackRelateChat() {
        this.getState().showChats.splice(this.state.showChats.length - 2, 2);
    }

    /**
     * 修正チャットで有効期限がクリア状態か判別するフラグを保存する。
     */
    @ActionBind(SavingsActionType.MODIFY_EXPIRY_DATE_EXISTS)
    private setModifyExpiryDateExists(value) {
        this.state.modifyExpiryDateExists = value;
    }

    /**
     * 受付可否チェック(共通:22)にてエラーになった旨送信する
     * @param data
     */
    @ActionBind(SavingsActionType.UNACCEPTABLES_NG)
    private signalUnacceptablesNg(data: any) {
        this.sendSignal(SavingsSignal.UNACCEPTABLES_NG, data);
    }
}
