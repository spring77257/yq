import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { AccountType } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { PRODUCT_TYPE } from 'dhdt/branch/shared/utils/product-category-utils';

export namespace ConfirmPageComponentParamName {
    export const ACCOUNT_TYPE: string = 'ACCOUNT_TYPE';
    export const BASICINFO_HOLERNAME: string = 'BASICINFO_HOLERNAME';
    export const BASICINFO_HOLDERNAMEFURIKANA: string = 'BASICINFO_HOLDERNAMEFURIKANA';
    export const BASICINFO_HOLDERBIRTHDATE: string = 'BASICINFO_HOLDERBIRTHDATE';
    export const BASICINFO_HOLDERGENDER: string = 'BASICINFO_HOLDERGENDER';
    export const BASICINFO_HOLDERZIPCODE: string = 'BASICINFO_HOLDERZIPCODE';
    export const BASICINFO_HOLDERADDRESSPREFECTURE: string = 'BASICINFO_HOLDERADDRESSPREFECTURE';
    export const BASICINFO_HOLDERADDRESSPREFECTUREFURIKANA: string = 'BASICINFO_HOLDERADDRESSPREFECTUREFURIKANA';
    export const BASICINFO_HOLDERMOBILENO: string = 'BASICINFO_HOLDERMOBILENO';
    export const BASICINFO_HOLDERTELEPHONENO: string = 'BASICINFO_HOLDERTELEPHONENO';
    export const BASICINFO_HOLDERCAREER: string = 'BASICINFO_HOLDERCAREER';
    export const BASICINFO_HOLDERWORKPLACE: string = 'BASICINFO_HOLDERWORKPLACE';
    export const CARDRECEIPT_METHOD_SHOWCHARTPARAM: string = 'CARDRECEIPT_METHOD_SHOWCHARTPARAM';
    export const CONFIRM_CONTRACT_STATUS_POINTSERVICE: string = 'CONFIRM_CONTRACT_STATUS_POINTSERVICE';
    export const CONFIRM_CONTRACT_STATUS_DIRECTAPPLY: string = 'CONFIRM_CONTRACT_STATUS_DIRECTAPPLY';
    export const OPENSTORE_SHOWCHART: string = 'OPENSTORE_SHOWCHART';
    export const OTHERSTORE_RESEAON: string = 'OTHERSTORE_RESEAON';
    export const OPENING_PURPOSE: string = 'OPENING_PURPOSE';
    export const PASSBOOK_PASSBOOKTYPE: string = 'PASSBOOK_PASSBOOKTYPE';
    export const PASSBOOK_PASSBOOKPRINTMESSAGE: string = 'PASSBOOK_PASSBOOKPRINTMESSAGE';
    export const PASSWORD_CARDPASSWORD: string = 'PASSWORD_CARDPASSWORD';
    export const PASSWORD_CONFIRMPASSWORD: string = 'PASSWORD_CONFIRMPASSWORD';

    export const BASICINFO_AGENTNAME: string = 'BASICINFO_AGENTNAME';
    export const BASICINFO_AGENTNAMEFURIKANA: string = 'BASICINFO_AGENTNAMEFURIKANA';
    export const BASICINFO_AGENTBIRTHDATE: string = 'BASICINFO_AGENTBIRTHDATE';
    export const BASICINFO_AGENTADDRESSPREFECTURE: string = 'BASICINFO_AGENTADDRESSPREFECTURE';
    export const BASICINFO_AGENTADDRESSPREFECTUREFURIKANA: string = 'BASICINFO_AGENTADDRESSPREFECTUREFURIKANA';
    export const BASICINFO_RELATIONSHIP: string = 'BASICINFO_RELATIONSHIP';
    export const BASICINFO_CANTCOMEREASON: string = 'BASICINFO_CANTCOMEREASON';
    export const BASICINFO_AGENTZIPCODE: string = 'BASICINFO_AGENTZIPCODE';

    export const CANCELINFO_BRANCHNAME: string = 'CANCELINFO_BRANCHNAME';
    export const CANCELINFO_ACCOUNTNO: string = 'CANCELINFO_ACCOUNTNO';
    export const CANCELINFO_ITEM: string = 'CANCELINFO_ITEM';
    export const CANCELINFO_ITEMDETAIL: string = 'CANCELINFO_ITEMDETAIL';
    export const CANCELINFO_OWNNO: string = 'CANCELINFO_OWNNO';
    export const CANCELINFO_RATE: string = 'CANCELINFO_RATE';
    export const CANCELINFO_TERM: string = 'CANCELINFO_TERM';
    export const CANCELINFO_STARTDATE: string = 'CANCELINFO_STARTDATE';
    export const CANCELINFO_DUEDATE: string = 'CANCELINFO_DUEDATE';
    export const CANCELINFO_CANCELAMOUNT: string = 'CANCELINFO_CANCELAMOUNT';
    export const CANCELINFO_CANCELLIST: string = 'CANCELINFO_CANCELLIST';

    // キャッシュカード
    export const CASHCARD_FAMILYNAME: string = 'CASHCARD_FAMILYNAME';
    export const CASHCARD_FAMILYNAMEFURIKANA: string = 'CASHCARD_FAMILYNAMEFURIKANA';
    export const CASHCARD_FAMILYTYPE: string = 'CASHCARD_FAMILYTYPE';
    export const CASHCARD_FAMILYDESIGN: string = 'CASHCARD_FAMILYDESIGN';
    export const CASHCARD_TYPE: string = 'CASHCARD_TYPE';
    export const CASHCARD_BRANCHNAMEKANJI: string = 'CASHCARD_BRANCHNAMEKANJI';
    export const CASHCARD_BRANCHNO: string = 'CASHCARD_BRANCHNO';
    export const CASHCARD_DESIGN: string = 'CASHCARD_DESIGN';
    export const CASHCARD_PASSWORD: string = 'CASHCARD_PASSWORD';
    export const CASHCARD_FAMILY_PASSWORD: string = 'CASHCARD_FAMILY_PASSWORD';
    // お子さま基本情報
    export const LOVE_CHILDRENNAME: string = 'LOVE_CHILDRENNAME';
    export const LOVE_CHILDRENNAMEFURIKANA: string = 'LOVE_CHILDRENNAMEFURIKANA';
    export const LOVE_CHILDRENBIRTHDATE: string = 'LOVE_CHILDRENBIRTHDATE';
    export const LOVE_CHILDRENGENDER: string = 'LOVE_CHILDRENGENDER';
    export const LOVE_CHILDRENRELATIONSHIP: string = 'LOVE_CHILDRENRELATIONSHIP';
    export const LOVE_CHILDRENNUMBERS: string = 'LOVE_CHILDRENNUMBERS';
    export const LOVE_ENROLLINGSCHOOL: string = 'LOVE_ENROLLINGSCHOOL';
    export const LOVE_ENROLLINGYEAR: string = 'LOVE_ENROLLINGYEAR';

    // 商品情報
    export const PRODUCT_SELECTPRODUCTNAME: string = 'PRODUCT_SELECTPRODUCTNAME';  // お申込商品type

    // 定期
    export const PRODUCT_AMOUNT: string = 'PRODUCT_AMOUNT';  // 口座開設時預金額
    export const PRODUCT_DEPOSITPERIODYEARMONTH: string = 'PRODUCT_DEPOSITPERIODYEARMONTH';  // 預入期間(満期日)
    export const PRODUCT_AUTOMICRENEWAL: string = 'PRODUCT_AUTOMICRENEWAL';  // 自動継続方法
    export const PRODUCT_TIMEPENSIONDATE: string = 'PRODUCT_TIMEPENSIONDATE';  // 年金受取予定年月
    export const PRODUCT_TIMEPENSIONAGE: string = 'PRODUCT_TIMEPENSIONAGE';   // 受取予定年齢
    export const PRODUCT_TIMEPENSIONTYPE: string = 'PRODUCT_TIMEPENSIONTYPE';   // 受取予定の年金種類

    export const LOVE_PRODUCT_AMOUNT: string = 'LOVE_PRODUCT_AMOUNT';  // 口座開設時預金額
    export const LOVE_PRODUCT_NORMALMONTHTRANSFERDAY: string = 'LOVE_PRODUCT_NORMALMONTHTRANSFERDAY';  // 毎月振替日 / 通常月振替日
    export const LOVE_PRODUCT_NORMALMONTHTRANSFERAMOUNT: string = 'LOVE_PRODUCT_NORMALMONTHTRANSFERAMOUNT';  // 毎月振替額 / 通常月振替額
    export const LOVE_PRODUCT_SPECIFICTRANSFERMONTH1: string = 'LOVE_PRODUCT_SPECIFICTRANSFERMONTH1';  // 特定振替日1
    export const LOVE_PRODUCT_SPECIFICTRANSFERAMOUNT1: string = 'LOVE_PRODUCT_SPECIFICTRANSFERAMOUNT1';  // 特定振替額1
    export const LOVE_PRODUCT_SPECIFICTRANSFERMONTH2: string = 'LOVE_PRODUCT_SPECIFICTRANSFERMONTH2';  // 特定振替日2
    export const LOVE_PRODUCT_SPECIFICTRANSFERAMOUNT2: string = 'LOVE_PRODUCT_SPECIFICTRANSFERAMOUNT2';  // 特定振替額2
    export const LOVE_PRODUCT_TRANSFERMONTH: string = 'LOVE_PRODUCT_TRANSFERMONTH';  // transferMonth通常月

    export const ORANGE_PRODUCT_NORMALMONTHTRANSFERDAY: string = 'ORANGE_PRODUCT_NORMALMONTHTRANSFERDAY';  // 毎月振替日 / 通常月振替日
    export const ORANGE_PRODUCT_NORMALMONTHTRANSFERAMOUNT: string = 'ORANGE_PRODUCT_NORMALMONTHTRANSFERAMOUNT';  // 毎月振替額 / 通常月振替額
    export const ORANGE_PRODUCT_SPECIFICTRANSFERMONTH1: string = 'ORANGE_PRODUCT_SPECIFICTRANSFERMONTH1';  // 特定振替日1
    export const ORANGE_PRODUCT_SPECIFICTRANSFERAMOUNT1: string = 'ORANGE_PRODUCT_SPECIFICTRANSFERAMOUNT1';  // 特定振替額1
    export const ORANGE_PRODUCT_SPECIFICTRANSFERMONTH2: string = 'ORANGE_PRODUCT_SPECIFICTRANSFERMONTH2';  // 特定振替日2
    export const ORANGE_PRODUCT_SPECIFICTRANSFERAMOUNT2: string = 'ORANGE_PRODUCT_SPECIFICTRANSFERAMOUNT2';  // 特定振替額2
    export const ORANGE_PRODUCT_MONTHLY: string = 'ORANGE_PRODUCT_MONTHLY';  // 通常月

    export const SMILE_PRODUCT_FUNDINGPURPOSE: string = 'SMILE_PRODUCT_FUNDINGPURPOSE'; // お積立目的
    export const SMILE_PRODUCT_DEPOSITPERIODYEARMONTH: string = 'SMILE_PRODUCT_DEPOSITPERIODYEARMONTH';  // 預入期間(満期日)
    export const SMILE_PRODUCT_NORMALMONTHTRANSFERDAY: string = 'SMILE_PRODUCT_NORMALMONTHTRANSFERDAY';  // 毎月振替日
    export const SMILE_PRODUCT_NORMALMONTHTRANSFERAMOUNT: string = 'SMILE_PRODUCT_NORMALMONTHTRANSFERAMOUNT';  // 毎月振替額
    export const SMILE_PRODUCT_SPECIFICTRANSFERMONTH1: string = 'SMILE_PRODUCT_SPECIFICTRANSFERMONTH1';  // 特定振替日1
    export const SMILE_PRODUCT_SPECIFICTRANSFERAMOUNT1: string = 'SMILE_PRODUCT_SPECIFICTRANSFERAMOUNT1';  // 特定振替額1
    export const SMILE_PRODUCT_SPECIFICTRANSFERMONTH2: string = 'SMILE_PRODUCT_SPECIFICTRANSFERMONTH2';  // 特定振替日2
    export const SMILE_PRODUCT_SPECIFICTRANSFERAMOUNT2: string = 'SMILE_PRODUCT_SPECIFICTRANSFERAMOUNT2';  // 特定振替額2
    export const SMILE_PRODUCT_RESERVEDFUNDRECEIPTTYPE: string = 'SMILE_PRODUCT_RESERVEDFUNDRECEIPTTYPE';  // 積立金受取方法
    // 積立金受取方法__サイクル設定
    export const SMILE_PRODUCT_FIRSTRECEIPTDATE: string = 'SMILE_PRODUCT_FIRSTRECEIPTDATE';  // 初回受取日
    export const SMILE_PRODUCT_RECEIPTCYCLE: string = 'SMILE_PRODUCT_RECEIPTCYCLE';  // 受取サイクル
    // 積立金受取方法__受取日指定
    export const SMILE_PRODUCT_RECEIPTDESIGNATEDDATE1: string = 'SMILE_PRODUCT_RECEIPTDESIGNATEDDATE1';  // 受取日1
    export const SMILE_PRODUCT_RECEIPTDESIGNATEDDATE2: string = 'SMILE_PRODUCT_RECEIPTDESIGNATEDDATE2';  // 受取日2

    export const  HOLDER_CAREER = 'ExistingSavings_HOLDER_CAREER'; // ご職業
    export const  HOLDER_WORK_PLACE = 'ExistingSavings_HOLDER_WORK_PLACE'; // お勤め先名称

    export const NAME_ENGLISH = 'ExistingSavings_NAME_ENGLISH'; // nameEnglish
    export const ADDRESS_ENGLISH = 'ExistingSavings_ADDRESS_ENGLISH'; // addressEnglish
    export const CITY_OR_TOWN_ENGLISH = 'ExistingSavings_CITY_OR_TOWN_ENGLISH'; // cityOrTownEnglish
    export const PROVINCE = 'ExistingSavings_CITY_OR_TOWN_PROVINCE'; // State or Province and Zip code
    export const AGENT_COUNTRY_ENGLISH = 'ExistingSavings_AGENT_COUNTRY_ENGLISH'; // agentCountryEnglish
    export const NUMBER_KEYBORD = 'ExistingSavings_CATEGORY_NUMBER_KEYBORD'; // numberKeybord
    export const SIGN_OATH = 'ExistingSavings_CATEGORY_NUMBER_SIGN_OATH'; // 宣誓署名
    export const SIGN_SIGN = 'ExistingSavings_CATEGORY_NUMBER_SIGN_SIGN'; // 申告のご署名

    export const ACCOUNT_OPENING_PURPOSE = 'ExistingSavings_ACCOUNT_OPENING_PURPOSE'; // 口座開設目的
    export const FIRST_PWD_4_BITS = 'ExistingSavings_FIRST_PWD_4_BITS'; // キャッシュカード暗証番号

    export const SIGN = 'ExistingSavings_SIGN'; // 電子サイン
    export const OTHER_COUNTRY = 'ExistingSavings_OTHER_COUNTRY'; // 住所

    export const FATCA_COUNTRY = 'ExistingSavings_FATCA_COUNTRY'; // 出生国
    export const SIGN_FATCA = 'ExistingSavings_SIGN_FATCA'; // Fatca署名
}

export namespace ChartID {
    export const INIT_CONFIRM: Number = 1;
    export const SELF_APPLY: Number = 2;
    export const APPLY_COMMON: Number = 3;
    export const AGENT_APPLY: Number = 4;
    export const CANCEL: Number = 98;
    export const CANCEL_METHOD: Number = 99;
    // キャッシュカード
    export const CASHCARD_COMMON: Number = 2;
    export const CASHCARD_APPLY: Number = 4;
    export const CON_APPLY_SELFINFO: Number = 98;
    export const CON_APPLY_COMMON: Number = 99;
    export const CON_APPLY_COMMON_OTHER: Number = 88;
}

@Injectable()
export class ConfirmPageCommonService {
    private params: Map<string, any>;
    private labels: any;

    constructor(
        private labelService: LabelService,
        private store: SavingsStore,
        private action: SavingsAction
    ) {
        this.params = new Map();
        this.labels = this.labelService.labels;
    }

    public loadConfirmTemplate() {
        this.action.loadConfirmPageTemplate('chat-flow-def-confirm-page-selfinfo-confirmpage.yml', 98);
        this.action.loadConfirmPageTemplate('chat-flow-def-confirm-page-common-confirmpage.yml', 99);
    }

    public updateAddressShowChatParams(isHolderInfo: boolean) {
        if (isHolderInfo) {
            if (this.store.getState().submitData.holderAddressStreetNameFuriKanaSelect) {
                this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERADDRESSPREFECTUREFURIKANA,
                    {
                        startOrder: 11, endOrder: 12, name: 'holderAddressPrefectureFuriKana',
                        currentTitle: '住所(フリガナ)', pageIndex: ChartID.CON_APPLY_SELFINFO
                    });
            } else {
                this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERADDRESSPREFECTUREFURIKANA,
                    {
                        startOrder: 14, endOrder: 15, name: 'holderAddressPrefectureFuriKana',
                        currentTitle: '住所(フリガナ)', pageIndex: ChartID.CON_APPLY_SELFINFO
                    });
            }
        } else {
            if (this.store.getState().submitData.holderAddressStreetNameFuriKanaSelect) {
                this.params.set(ConfirmPageComponentParamName.BASICINFO_AGENTADDRESSPREFECTUREFURIKANA,
                    {
                        startOrder: 48, endOrder: 49, name: 'holderAddressPrefectureFuriKana',
                        currentTitle: '住所(フリガナ)', pageIndex: ChartID.CON_APPLY_COMMON
                    });
            } else {
                this.params.set(ConfirmPageComponentParamName.BASICINFO_AGENTADDRESSPREFECTUREFURIKANA,
                    {
                        startOrder: 50, endOrder: 51, name: 'holderAddressPrefectureFuriKana',
                        currentTitle: '住所(フリガナ)', pageIndex: ChartID.CON_APPLY_COMMON
                    });
            }
        }
    }

    public getShowChatParams() {
        this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLERNAME,
            {
                startOrder: 1, endOrder: 2, name: 'holderName',
                currentTitle: 'おなまえ', pageIndex: ChartID.CON_APPLY_SELFINFO
            });
        this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERNAMEFURIKANA,
            {
                startOrder: 2, endOrder: 2, name: 'holderNameFurikana',
                currentTitle: 'おなまえ(フリガナ)', pageIndex: ChartID.CON_APPLY_SELFINFO
            });
        this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERBIRTHDATE,
            {
                startOrder: 3, endOrder: 3, name: 'holderBirthdate',
                currentTitle: '生年月日', pageIndex: ChartID.CON_APPLY_SELFINFO
            });
        this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERGENDER,
            {
                startOrder: 4, endOrder: 4, name: 'holderGender',
                currentTitle: '性別', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERZIPCODE,
            {
                startOrder: 161, endOrder: 174, name: 'holderZipCode',
                currentTitle: '郵便番号', pageIndex: ChartID.CON_APPLY_SELFINFO
            });
        this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERADDRESSPREFECTURE,
            {
                startOrder: 16, endOrder: 21, name: 'holderAddressPrefecture',
                currentTitle: '住所', pageIndex: ChartID.CON_APPLY_SELFINFO
            });
        if (this.store.getState().submitData.holderAddressStreetNameSelect) {
            this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERADDRESSPREFECTUREFURIKANA,
                {
                    startOrder: 11, endOrder: 12, name: 'holderAddressPrefectureFuriKana',
                    currentTitle: '住所(フリガナ)', pageIndex: ChartID.CON_APPLY_SELFINFO
                });
        } else {
            this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERADDRESSPREFECTUREFURIKANA,
                {
                    startOrder: 14, endOrder: 15, name: 'holderAddressPrefectureFuriKana',
                    currentTitle: '住所(フリガナ)', pageIndex: ChartID.CON_APPLY_SELFINFO
                });
        }
        this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERMOBILENO,
            {
                startOrder: 3190, endOrder: 3240, name: 'holderMobileNo',
                currentTitle: '携帯電話番号', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERTELEPHONENO,
            {
                startOrder: 18, endOrder: 19, name: 'holderTelephoneNo',
                currentTitle: 'ご自宅電話番号', pageIndex: ChartID.CON_APPLY_COMMON
            });

        if (this.store.getState().submitData.accountType === AccountType.ORDINARY_DEPOSIT_CHILDREN) {
            this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERCAREER,
                {
                    startOrder: 137, endOrder: 137, name: 'holderCareer',
                    currentTitle: this.labelService.labels.holderCareer.schoolSituation, pageIndex: ChartID.CON_APPLY_COMMON
                });
        } else {
            this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERCAREER,
                {
                    startOrder: 20, endOrder: 22, name: 'holderCareer',
                    currentTitle: this.labelService.labels.holderCareer.occupation, pageIndex: ChartID.CON_APPLY_COMMON
                });
        }
        this.params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERWORKPLACE,
            {
                startOrder: 20, endOrder: 22, name: 'holderWorkPlace',
                currentTitle: 'お勤め先名称', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.ACCOUNT_OPENING_PURPOSE,
            {
                startOrder: 23, endOrder: 23, name: 'accountOpeningPurpose',
                currentTitle: '口座開設目的', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.ACCOUNT_TYPE,
            {
                startOrder: 25, endOrder: 25, name: 'cardDesign',
                currentTitle: 'キャッシュカードデザイン', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.CONFIRM_CONTRACT_STATUS_POINTSERVICE,
            {
                startOrder: 26, endOrder: 27, name: 'pointServiceExpectation',
                currentTitle: 'ポイントサービス', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.CONFIRM_CONTRACT_STATUS_DIRECTAPPLY,
            {
                startOrder: 175, endOrder: 176, name: 'directApplyExpectation',
                currentTitle: this.labels.confirm.applyInfo.directApplyExpectation1, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.FIRST_PWD_4_BITS,
            {
                startOrder: 29, endOrder: 29, name: 'cardPassword',
                currentTitle: 'キャッシュカード暗証番号', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.SIGN,
            {
                startOrder: 555, endOrder: 555, name: 'sign',
                currentTitle: this.labels.confirm.sign.table.title2, pageIndex: ChartID.CON_APPLY_COMMON_OTHER
            });
        this.params.set(ConfirmPageComponentParamName.OTHER_COUNTRY,
            {
                startOrder: 666, endOrder: 666, name: 'otherCountry',
                currentTitle: this.labels.confirm.sign.table.title4, pageIndex: ChartID.CON_APPLY_COMMON_OTHER
            });
        this.params.set(ConfirmPageComponentParamName.PASSWORD_CONFIRMPASSWORD,
            {
                startOrder: 30, endOrder: 30, name: 'confirmPassword',
                currentTitle: 'いよぎんダイレクト確認暗証番号', pageIndex: ChartID.CON_APPLY_COMMON
            });
        if (this.store.getState().submitData.accountType === AccountType.ORDINARY_DEPOSIT_CHILDREN) {
            this.params.set(ConfirmPageComponentParamName.PASSBOOK_PASSBOOKTYPE,
                {
                    startOrder: 31, endOrder: 34, name: 'passbookType',
                    currentTitle: '通帳デザイン', pageIndex: ChartID.CON_APPLY_COMMON
                });
        } else if (this.store.getState().submitData.accountType === AccountType.TIME_SAVING) {
            if (this.store.getState().submitData.selectProductType === PRODUCT_TYPE.LOVE) {
                this.params.set(ConfirmPageComponentParamName.PASSBOOK_PASSBOOKTYPE,
                    {
                        startOrder: 103, endOrder: 117, name: 'passbookType',
                        currentTitle: '通帳デザイン', pageIndex: ChartID.CON_APPLY_COMMON
                    });
            }
        }
        if (this.store.getState().submitData.accountType === AccountType.ORDINARY_DEPOSIT_CHILDREN) {
            this.params.set(ConfirmPageComponentParamName.PASSBOOK_PASSBOOKPRINTMESSAGE,
                {
                    startOrder: 32, endOrder: 34, name: 'passbookPrintMessage',
                    currentTitle: '通帳に印刷する文字', pageIndex: ChartID.CON_APPLY_COMMON
                });
        } else if (this.store.getState().submitData.accountType === AccountType.TIME_SAVING) {
            if (this.store.getState().submitData.selectProductType === PRODUCT_TYPE.LOVE) {
                this.params.set(ConfirmPageComponentParamName.PASSBOOK_PASSBOOKPRINTMESSAGE,
                    {
                        startOrder: 115, endOrder: 117, name: 'passbookPrintMessage',
                        currentTitle: '通帳に印刷する文字', pageIndex: ChartID.CON_APPLY_COMMON
                    });
            }
        }
        this.params.set(ConfirmPageComponentParamName.CARDRECEIPT_METHOD_SHOWCHARTPARAM,
            {
                startOrder: 86, endOrder: 86, name: 'receiptMethod',
                currentTitle: 'カードお受取方法', pageIndex: ChartID.CON_APPLY_COMMON
            });
        // 支店名修正
        this.params.set(ConfirmPageComponentParamName.OPENSTORE_SHOWCHART,
            {
                startOrder: 9950, endOrder: 9956, name: 'branchNameKanji',
                currentTitle: '支店名', pageIndex: ChartID.CON_APPLY_COMMON
            });

        // 他店舗での口座開設理由修正
        this.params.set(ConfirmPageComponentParamName.OTHERSTORE_RESEAON,
            {
                startOrder: 9955, endOrder: 9956, name: 'savingBranchReason',
                currentTitle: '他店舗での口座開設理由', pageIndex: ChartID.CON_APPLY_COMMON
            });

        // 代理人
        this.params.set(ConfirmPageComponentParamName.BASICINFO_AGENTNAME,
            {
                startOrder: 39, endOrder: 40, name: 'agentName',
                currentTitle: this.labels.confirm.agentInfo.name, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.BASICINFO_AGENTBIRTHDATE,
            {
                startOrder: 41, endOrder: 41, name: 'agentBirthdate',
                currentTitle: this.labels.confirm.agentInfo.birthday, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.BASICINFO_AGENTZIPCODE,
            {
                startOrder: 161, endOrder: 174, name: 'holderZipCode',
                currentTitle: this.labels.confirm.agentInfo.address, pageIndex: ChartID.CON_APPLY_COMMON
            });
        if (this.store.getState().submitData.accountType === AccountType.ORDINARY_DEPOSIT_CHILDREN) {
            this.params.set(ConfirmPageComponentParamName.BASICINFO_RELATIONSHIP,
                {
                    startOrder: 36, endOrder: 36, name: 'relationship',
                    currentTitle: this.labels.confirm.agentInfo.relationship, pageIndex: ChartID.CON_APPLY_COMMON
                });
        } else {
            this.params.set(ConfirmPageComponentParamName.BASICINFO_RELATIONSHIP,
                {
                    startOrder: 35, endOrder: 543, name: 'relationship',
                    currentTitle: this.labels.confirm.agentInfo.relationship, pageIndex: ChartID.CON_APPLY_COMMON
                });
        }
        this.params.set(ConfirmPageComponentParamName.BASICINFO_CANTCOMEREASON,
            {
                startOrder: 38, endOrder: 38, name: 'cantComeReason',
                currentTitle: this.labels.confirm.agentInfo.reason, pageIndex: ChartID.CON_APPLY_COMMON
            });

        // 商品
        this.params.set(ConfirmPageComponentParamName.PRODUCT_SELECTPRODUCTNAME,
            {
                startOrder: 52, endOrder: 52, name: 'selectProductName',
                currentTitle: 'お申込商品', pageIndex: ChartID.CON_APPLY_COMMON
            });

        // 定期
        this.params.set(ConfirmPageComponentParamName.PRODUCT_AMOUNT,
            {
                startOrder: 142, endOrder: 157, name: 'amount',
                currentTitle: this.labels.confirm.product.amount, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.PRODUCT_DEPOSITPERIODYEARMONTH,
            {
                startOrder: 158, endOrder: 160, name: 'depositPeriodYearMonth',
                currentTitle: this.labels.confirm.product.depositPeriodYearMonth, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.PRODUCT_AUTOMICRENEWAL,
            {
                startOrder: 57, endOrder: 57, name: 'automicRenewal',
                currentTitle: this.labels.confirm.product.automicRenewal, pageIndex: ChartID.CON_APPLY_COMMON
            });
        // pensionDate
        this.params.set(ConfirmPageComponentParamName.PRODUCT_TIMEPENSIONDATE,
            {
                startOrder: 138, endOrder: 139, name: 'pensionYearMonth',
                currentTitle: this.labels.timeDeposit.apply.annuityReceiptYM, pageIndex: ChartID.CON_APPLY_COMMON
            });
        // pensionAge
        this.params.set(ConfirmPageComponentParamName.PRODUCT_TIMEPENSIONAGE,
            {
                startOrder: 139, endOrder: 139, name: 'pensionAge',
                currentTitle: this.labels.timeDeposit.apply.receiptAge, pageIndex: ChartID.CON_APPLY_COMMON
            });
        // pensionType
        this.params.set(ConfirmPageComponentParamName.PRODUCT_TIMEPENSIONTYPE,
            {
                startOrder: 140, endOrder: 141, name: 'pensionType',
                currentTitle: this.labels.timeDeposit.apply.annuityType, pageIndex: ChartID.CON_APPLY_COMMON
            });

        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_FUNDINGPURPOSE,
            {
                startOrder: 58, endOrder: 58, name: 'fundingPurpose',
                currentTitle: 'お積立目的', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_DEPOSITPERIODYEARMONTH,
            {
                startOrder: 59, endOrder: 59, name: 'depositPeriodYearMonth',
                currentTitle: '預入期間(満期日)', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_NORMALMONTHTRANSFERDAY,
            {
                startOrder: 61, endOrder: 61, name: 'normalMonthTransferDay',
                currentTitle: '毎月振替日', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_NORMALMONTHTRANSFERAMOUNT,
            {
                startOrder: 62, endOrder: 62, name: 'normalMonthTransferAmount',
                currentTitle: '毎月振替額', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_SPECIFICTRANSFERMONTH1,
            {
                startOrder: 177, endOrder: 179, name: 'specificTransferMonth1',
                currentTitle: this.labels.confirm.product.specificTransferMonth, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_SPECIFICTRANSFERAMOUNT1,
            {
                startOrder: 177, endOrder: 179, name: 'specificTransferAmount1',
                currentTitle: this.labels.confirm.product.specificTransferAmount, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_SPECIFICTRANSFERMONTH2,
            {
                startOrder: 180, endOrder: 182, name: 'specificTransferMonth2',
                currentTitle: this.labels.confirm.product.specificTransferMonth, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_SPECIFICTRANSFERAMOUNT2,
            {
                startOrder: 180, endOrder: 182, name: 'specificTransferAmount2',
                currentTitle: this.labels.confirm.product.specificTransferAmount, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_RESERVEDFUNDRECEIPTTYPE,
            {
                startOrder: 2177, endOrder: 2183, name: 'reservedFundReceiptType',
                currentTitle: this.labels.confirm.product.reservedFundReceiptType, pageIndex: ChartID.CON_APPLY_COMMON
            });
        // 積立金受取方法__サイクル設定
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_FIRSTRECEIPTDATE,
            {
                startOrder: 2177, endOrder: 2183, name: 'firstReceiptDate',
                currentTitle: this.labels.confirm.product.firstReceiptDate, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_RECEIPTCYCLE,
            {
                startOrder: 2177, endOrder: 2183, name: 'receiptCycle',
                currentTitle: this.labels.confirm.product.receiptCycle, pageIndex: ChartID.CON_APPLY_COMMON
            });
        // 積立金受取方法__受取日指定
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_RECEIPTDESIGNATEDDATE1,
            {
                startOrder: 2177, endOrder: 2183, name: 'receiptDesignatedDate1',
                currentTitle: this.labels.confirm.product.receiptDesignatedDate1, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.SMILE_PRODUCT_RECEIPTDESIGNATEDDATE2,
            {
                startOrder: 2177, endOrder: 2183, name: 'receiptDesignatedDate2',
                currentTitle: this.labels.confirm.product.receiptDesignatedDate2, pageIndex: ChartID.CON_APPLY_COMMON
            });

        // お子さま基本情報
        this.params.set(ConfirmPageComponentParamName.LOVE_CHILDRENNAME,
            {
                startOrder: 72, endOrder: 73, name: 'childrenName',
                currentTitle: 'おなまえ', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_CHILDRENBIRTHDATE,
            {
                startOrder: 74, endOrder: 74, name: 'childrenBirthdate',
                currentTitle: '生年月日', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_CHILDRENGENDER,
            {
                startOrder: 75, endOrder: 75, name: 'childrenGender',
                currentTitle: '性別', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_CHILDRENRELATIONSHIP,
            {
                startOrder: 761, endOrder: 763, name: 'childrenRelationship',
                currentTitle: '続柄', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_CHILDRENNUMBERS,
            {
                startOrder: 761, endOrder: 763, name: 'childrenNumbers',
                currentTitle: '子供人数', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_ENROLLINGSCHOOL,
            {
                startOrder: 78, endOrder: 78, name: 'enrollingSchool',
                currentTitle: '入学予定', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_ENROLLINGYEAR,
            {
                startOrder: 79, endOrder: 79, name: 'enrollingYear',
                currentTitle: '入学年', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_PRODUCT_NORMALMONTHTRANSFERDAY,
            {
                startOrder: 61, endOrder: 61, name: 'normalMonthTransferDay',
                currentTitle: '毎月振替日', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_PRODUCT_NORMALMONTHTRANSFERAMOUNT,
            {
                startOrder: 87, endOrder: 87, name: 'normalMonthTransferAmount',
                currentTitle: '毎月振替額', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_PRODUCT_SPECIFICTRANSFERMONTH1,
            {
                startOrder: 183, endOrder: 185, name: 'specificTransferMonth1',
                currentTitle: this.labels.confirm.product.specificTransferMonth, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_PRODUCT_SPECIFICTRANSFERAMOUNT1,
            {
                startOrder: 183, endOrder: 185, name: 'specificTransferAmount1',
                currentTitle: this.labels.confirm.product.specificTransferAmount, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_PRODUCT_SPECIFICTRANSFERMONTH2,
            {
                startOrder: 186, endOrder: 188, name: 'specificTransferMonth2',
                currentTitle: this.labels.confirm.product.specificTransferMonth, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.LOVE_PRODUCT_SPECIFICTRANSFERAMOUNT2,
            {
                startOrder: 186, endOrder: 188, name: 'specificTransferAmount2',
                currentTitle: this.labels.confirm.product.specificTransferAmount, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.ORANGE_PRODUCT_MONTHLY,
            {
                startOrder: 83, endOrder: 83, name: 'monthly',
                currentTitle: '通常月', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.ORANGE_PRODUCT_NORMALMONTHTRANSFERDAY,
            {
                startOrder: 84, endOrder: 84, name: 'normalMonthTransferDay',
                currentTitle: '通常月振替日', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.ORANGE_PRODUCT_NORMALMONTHTRANSFERAMOUNT,
            {
                startOrder: 85, endOrder: 85, name: 'normalMonthTransferAmount',
                currentTitle: '通常月振替額', pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.ORANGE_PRODUCT_SPECIFICTRANSFERMONTH1,
            {
                startOrder: 189, endOrder: 191, name: 'specificTransferMonth1',
                currentTitle: this.labels.confirm.product.specificTransferMonth, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.ORANGE_PRODUCT_SPECIFICTRANSFERAMOUNT1,
            {
                startOrder: 189, endOrder: 191, name: 'specificTransferAmount1',
                currentTitle: this.labels.confirm.product.specificTransferAmount, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.ORANGE_PRODUCT_SPECIFICTRANSFERMONTH2,
            {
                startOrder: 192, endOrder: 194, name: 'specificTransferMonth2',
                currentTitle: this.labels.confirm.product.specificTransferMonth, pageIndex: ChartID.CON_APPLY_COMMON
            });
        this.params.set(ConfirmPageComponentParamName.ORANGE_PRODUCT_SPECIFICTRANSFERAMOUNT2,
            {
                startOrder: 192, endOrder: 194, name: 'specificTransferAmount2',
                currentTitle: this.labels.confirm.product.specificTransferAmount, pageIndex: ChartID.CON_APPLY_COMMON
            });
        return this.params;
    }

    public getBankSavDepositAgentConfirmPageComponentParams() {
        const params: Map<string, any> = new Map();

        params.set(ConfirmPageComponentParamName.BASICINFO_AGENTNAME,
            {
                startOrder: 210, endOrder: 210, name: 'agentName',
                currentTitle: 'おなまえ', pageIndex: ChartID.AGENT_APPLY
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_AGENTNAMEFURIKANA,
            {
                startOrder: 211, endOrder: 211, name: 'agentNameFurikana',
                currentTitle: 'おなまえ(フリガナ)', pageIndex: ChartID.AGENT_APPLY
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_AGENTBIRTHDATE,
            {
                startOrder: 212, endOrder: 212, name: 'agentBirthdate',
                currentTitle: '生年月日', pageIndex: ChartID.AGENT_APPLY
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_HOLERNAME,
            {
                startOrder: 218, endOrder: 219, name: 'holderName',
                currentTitle: 'おなまえ', pageIndex: ChartID.AGENT_APPLY
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERNAMEFURIKANA,
            {
                startOrder: 219, endOrder: 219, name: 'holderNameFurigana',
                currentTitle: 'おなまえ(フリガナ)', pageIndex: ChartID.AGENT_APPLY
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERZIPCODE,
            {
                startOrder: 214, endOrder: 214, name: 'holderZipCode',
                currentTitle: '郵便番号', pageIndex: ChartID.AGENT_APPLY
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERADDRESSPREFECTURE,
            {
                startOrder: 2171, endOrder: 2175, name: 'holderAddressPrefecture',
                currentTitle: '住所', pageIndex: ChartID.AGENT_APPLY
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERADDRESSPREFECTUREFURIKANA,
            {
                startOrder: 2163, endOrder: 21771, name: 'holderAddressPrefectureFuriKana',
                currentTitle: '住所(フリガナ)', pageIndex: ChartID.AGENT_APPLY
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERBIRTHDATE,
            {
                startOrder: 220, endOrder: 220, name: 'holderBirthdate',
                currentTitle: '生年月日', pageIndex: ChartID.AGENT_APPLY
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_RELATIONSHIP,
            {
                startOrder: 23, endOrder: 23, name: 'relationship',
                currentTitle: '取引名義人との関係', pageIndex: ChartID.AGENT_APPLY
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_CANTCOMEREASON,
            {
                startOrder: 27, endOrder: 27, name: 'cantComeReason',
                currentTitle: '名義人が来店できない理由', pageIndex: ChartID.AGENT_APPLY
            });

        params.set(ConfirmPageComponentParamName.ACCOUNT_TYPE,
            {
                startOrder: 14, endOrder: 14, name: 'cardDesign',
                currentTitle: 'キャッシュカードデザイン', pageIndex: ChartID.APPLY_COMMON
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERGENDER,
            {
                startOrder: 1, endOrder: 1, name: 'holderGender',
                currentTitle: '性別', pageIndex: ChartID.APPLY_COMMON
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERMOBILENO,
            {
                startOrder: 2, endOrder: 6, name: 'holderMobileNo',
                currentTitle: '携帯電話番号', pageIndex: ChartID.APPLY_COMMON
            });
        params.set(ConfirmPageComponentParamName.BASICINFO_HOLDERTELEPHONENO,
            {
                startOrder: 5, endOrder: 6, name: 'holderTelephoneNo',
                currentTitle: 'ご自宅電話番号', pageIndex: ChartID.APPLY_COMMON
            });
        params.set(ConfirmPageComponentParamName.CARDRECEIPT_METHOD_SHOWCHARTPARAM,
            {
                startOrder: 1, endOrder: 1, name: 'receiptMethod',
                currentTitle: 'カードお受取方法', pageIndex: 4
            });
        params.set(ConfirmPageComponentParamName.CONFIRM_CONTRACT_STATUS_POINTSERVICE,
            {
                startOrder: 18, endOrder: 19, name: 'pointServiceExpectation',
                currentTitle: 'ポイントサービス', pageIndex: ChartID.APPLY_COMMON
            });
        params.set(ConfirmPageComponentParamName.CONFIRM_CONTRACT_STATUS_DIRECTAPPLY,
            {
                startOrder: 21, endOrder: 21, name: 'directApplyExpectation',
                currentTitle: 'いよぎんダイレクト', pageIndex: ChartID.APPLY_COMMON
            });
        params.set(ConfirmPageComponentParamName.OPENING_PURPOSE,
            {
                startOrder: 12, endOrder: 13, name: 'accountOpeningPurposeOtherDetail',
                currentTitle: '口座開設目的', pageIndex: ChartID.APPLY_COMMON
            });
        params.set(ConfirmPageComponentParamName.PASSBOOK_PASSBOOKTYPE,
            {
                startOrder: 17, endOrder: 17, name: 'passbookType',
                currentTitle: '通帳デザイン', pageIndex: ChartID.APPLY_COMMON
            });
        params.set(ConfirmPageComponentParamName.PASSBOOK_PASSBOOKPRINTMESSAGE,
            {
                startOrder: 172, endOrder: 172, name: 'passbookPrintMessage',
                currentTitle: '通帳に印刷する文字', pageIndex: ChartID.APPLY_COMMON
            });
        params.set(ConfirmPageComponentParamName.PASSWORD_CARDPASSWORD,
            {
                startOrder: 16, endOrder: 16, name: 'cardPassword',
                currentTitle: 'キャッシュカード暗証番号', pageIndex: ChartID.APPLY_COMMON
            });
        params.set(ConfirmPageComponentParamName.PASSWORD_CONFIRMPASSWORD,
            {
                startOrder: 232, endOrder: 232, name: 'confirmPassword',
                currentTitle: 'いよぎんダイレクト確認暗証番号', pageIndex: ChartID.APPLY_COMMON
            });
        return params;
    }

    public getCancelConfirmPageComponentParams() {
        const params: Map<string, any> = new Map();
        params.set(ConfirmPageComponentParamName.CANCELINFO_CANCELLIST,
            {
                startOrder: 8, endOrder: 9, name: 'cancelList',
                currentTitle: '解約商品選択', pageIndex: ChartID.CANCEL
            });
        params.set(ConfirmPageComponentParamName.CANCELINFO_CANCELAMOUNT,
            {
                startOrder: 1, endOrder: 4, name: 'cancelAmountList',
                currentTitle: '解約希望金額', pageIndex: ChartID.CANCEL_METHOD
            });
        return params;
    }

    // キャッシュカード
    public getCashCardConfirmPageComponentParams() {
        const params: Map<string, any> = new Map();
        params.set(ConfirmPageComponentParamName.CASHCARD_FAMILYNAME,
            {
                startOrder: 8, endOrder: 8, name: 'cashCardFamilyName',
                currentTitle: 'おなまえ', pageIndex: ChartID.CASHCARD_APPLY
            });
        params.set(ConfirmPageComponentParamName.CASHCARD_FAMILYNAMEFURIKANA,
            {
                startOrder: 9, endOrder: 9, name: 'cashCardFamilyNameFurikana',
                currentTitle: 'おなまえ(フリガナ)', pageIndex: ChartID.CASHCARD_APPLY
            });
        params.set(ConfirmPageComponentParamName.CASHCARD_FAMILYTYPE,
            {
                startOrder: 10, endOrder: 11, name: 'cashCardFamilyType',
                currentTitle: 'お客さまとの関係', pageIndex: ChartID.CASHCARD_APPLY
            });
        params.set(ConfirmPageComponentParamName.CASHCARD_FAMILYDESIGN,
            {
                startOrder: 13, endOrder: 13, name: 'cashCardFamilyDesign',
                currentTitle: '家族用カードデザイン', pageIndex: ChartID.CASHCARD_APPLY
            });
        params.set(ConfirmPageComponentParamName.CASHCARD_TYPE,
            {
                startOrder: 8, endOrder: 9, name: 'cashCardType',
                currentTitle: '発行対象', pageIndex: ChartID.CASHCARD_COMMON
            });
        params.set(ConfirmPageComponentParamName.CASHCARD_BRANCHNAMEKANJI,
            {
                startOrder: 11, endOrder: 11, name: 'branchNameKanji',
                currentTitle: '対象店舗', pageIndex: ChartID.CASHCARD_COMMON
            });
        params.set(ConfirmPageComponentParamName.CASHCARD_BRANCHNO,
            {
                startOrder: 12, endOrder: 12, name: 'cashCardBranchNo',
                currentTitle: '口座番号', pageIndex: ChartID.CASHCARD_COMMON
            });
        params.set(ConfirmPageComponentParamName.CASHCARD_DESIGN,
            {
                startOrder: 3, endOrder: 3, name: 'cashCardDesign',
                currentTitle: 'キャッシュカードデザイン', pageIndex: ChartID.CASHCARD_APPLY
            });
        params.set(ConfirmPageComponentParamName.CASHCARD_PASSWORD,
            {
                startOrder: 4, endOrder: 6, name: 'cashCardPassword',
                currentTitle: 'キャッシュカード暗証番号', pageIndex: ChartID.CASHCARD_APPLY
            });
        params.set(ConfirmPageComponentParamName.CASHCARD_FAMILY_PASSWORD,
            {
                startOrder: 14, endOrder: 15, name: 'cashCardFamilyPassword',
                currentTitle: '家族カード暗証番号', pageIndex: ChartID.CASHCARD_APPLY
            });
        return params;
    }
}
