import { Injectable } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';

@Injectable()
export class BackupDataService {
    private store: SavingsStore;

    constructor() {
        this.store = InjectionUtils.injector.get(SavingsStore);
    }

    /**
     * get checkedItem value
     * @param question checkedItem info
     */
    public getCheckedItemValue(question: string): string {
        if (question && question.indexOf('@NameKanaOCR') !== -1) {
            return this.store.getState().ocrEntity.firstNameKana + '　'
                + this.store.getState().ocrEntity.lastNameKana;
        }

        if (question && question.indexOf('@NameKana') !== -1) {
            return this.store.getState().submitData.firstNameKana + '　'
                + this.store.getState().submitData.lastNameKana;
        }

        if (question && question.indexOf('@AgentNameKana') !== -1) {
            return this.store.getState().submitData.agentFirstNameKana + '　'
                + this.store.getState().submitData.agentLastNameKana;
        }

        if (question && question.indexOf('@AddressKana') !== -1) {
            return this.store.getState().submitData.holderAddressPrefectureFuriKana +
                this.store.getState().submitData.holderAddressCountyUrbanVillageFuriKana +
                this.store.getState().submitData.getHolderAddressStreetNameFuriKana() +
                this.store.getState().submitData.holderAddressHouseNumberFuriKana;
        }

        if (question && question.indexOf('@AddressWithoutHouseKanaOCR') !== -1) {
            return this.store.getState().ocrEntity.prefectureKana +
            this.store.getState().ocrEntity.countyUrbanVillageKana +
            ((this.store.getState().ocrEntity.streetKana ? this.store.getState().ocrEntity.streetKana : '')
            ? (this.store.getState().ocrEntity.streetKana ? this.store.getState().ocrEntity.streetKana : '') : '') +
            this.store.getState().ocrEntity.houseNumberKana;
        }

        return null;
    }
}
