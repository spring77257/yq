import { Injectable, NgZone } from '@angular/core';
import { Action } from 'adep/flux';
import { AppProperties } from 'app.properties';
import { ReceptionInfoEntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/reception-info.entity';
import {
    API_URL, ApplyDate, ClearSavingImagesClickRecordType, CodeCategory, COMMON_CONSTANTS, Constants, HostErrorCodeReceptionNG, HostResultCode, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import {
    ReceptionLossCorruptionCheckRequest
} from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-request.entity';
import { FilteringParameterEntity } from 'dhdt/branch/shared/entity/filtering-parameter.entity';
import { RegionCodeSearchRequestEntity } from 'dhdt/branch/shared/entity/region-code.entity';
import { NewPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/new-password-rule-check.interface';
import { DocumentCategorySubjectData } from 'dhdt/branch/shared/modules/document-category/entity/document-category.entity';
import { DocumentCategoryObserverAction } from 'dhdt/branch/shared/modules/document-category/service/document-category.service';
import { HostErrorService } from 'dhdt/branch/shared/services/host-error.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { HttpService, HttpStatus } from 'dhdt/branch/shared/services/http.service';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';

export namespace SavingsActionType {
    export const SET_CHAT_FLOW_INFO: string = 'SavingsActionType_SET_CHAT_FLOW_INFO';
    export const GET_SAVING_QUESTION_TEMPLATE: string = 'SavingsActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const NEXT_CHAT: string = 'SavingsActionType_NEXT_CHAT';
    export const CLEAR: string = 'SavingsActionType_LOAD_TEMPLATE_CLEAR';
    export const CLEAR_SHOW_CHATS: string = 'SavingsActionType_CLEAR_SHOW_CHATS';
    export const BRANCH_STATUS_INSERT: string = 'SavingsActionType_BRANCH_STATUS_INSERT';
    export const BRANCH_STATUS_UPDATE: string = 'SavingsActionType_BRANCH_STATUS_UPDATE';
    export const SET_ANSWER: string = 'SavingsActionType_SET_ANSWER';
    export const EDIT_CHAT: string = 'SavingsActionType_EDIT_CHAT';
    export const SET_STATE_SUBMIT_DATA_VALUE: string = 'SavingsActionType_SET_STATE_SUBMIT_DATA_VALUE';
    export const GET_INFO_OCR: string = 'SavingsActionType_GET_INFO_OCR';
    export const SET_INFO_OCR: string = 'SavingsActionType_SET_INFO_OCR';
    export const VALIDATION_PASSWORD: string = 'SavingsActionType_VALIDATION_PASSWORD';
    export const SUBMIT_DATA_BACKUP: string = 'SavingsActionType_SUBMIT_DATA_BACKUP';
    export const UPDATA_SUBMIT_DATA_BACKUP = 'SavingsActionType_UPDATA_SUBMIT_DATA_BACKUP';
    export const RESET_SUBMIT_DATA: string = 'SavingsActionType_RESET_SUBMIT_DATA';
    export const RETRIEVE_DROP_LIST: string = 'SavingsActionType_RETRIEVE_DROP_LIST';
    export const GET_HOLDER_ZIP_CODE = 'SavingsActionType_GET_HOLDER_ZIP_CODE';
    export const BRANCH_INFO_INSERT: string = 'SavingsActionType_BRANCH_INFO_INSERT';
    export const UPLOAD_IMAGE = 'SAVINGSACTIONTYPE_UPLOAD_IMAGE';
    export const CHAT_FLOW_COMPELETE = 'SAVINGSACTIONTYPE_CHAT_FLOW_COMPELETE';
    export const CHAT_FLOW_RETURN = 'SAVINGSACTIONTYPE_CHAT_FLOW_RETURN';
    export const RESET_LAST_NODE = 'SAVINGSACTIONTYPE_RESET_LAST_NODE';
    export const RESET_SPECIAL_NODE = 'SAVINGSACTIONTYPE_RESET_SPECIAL_NODE';
    export const SUBMIT_TIME_SAVING_APPLY_INFO = 'SUBMIT_TIME_SAVING_APPLY_INFO';
    export const SET_BANKCLERK_ID: string = 'SET_BANKCLERK_ID';
    export const SET_BRANCH_INFO: string = 'SET_BRANCH_INFO';
    export const SET_AGENCY_BRANCH_INFO: string = 'SET_AGENCY_BRANCH_INFO';
    export const SET_INTEREST_COMPUTATION_METHOD: string = 'SET_INTEREST_COMPUTATION_METHOD';
    export const CLEAR_OPEN_ACCOUNT_PURPOSE: string = 'CLEAR_OPEN_ACCOUNT_PURPOSE';

    export const GET_CANCELABLE_ITEM_LIST = 'SavingsActionType_GET_CANCELABLE_ITEM_LIST';
    export const MODIFY_ID_CANCELABLE_ITEM_LIST = 'SavingsActionType_MODIFY_ID_CANCELABLE_ITEM_LIST';
    export const MODIFY_METHOD_CANCELABLE_ITEM_LIST = 'SavingsActionType_MODIFY_METHOD_CANCELABLE_ITEM_LIST';
    export const MODIFY_CANCEL_AMOUNT_CANCELABLE_ITEM_LIST = 'SavingsActionType_MODIFY_CANCEL_AMOUNT_CANCELABLE_ITEM_LIST';
    export const ITEM_COUNT = 'SavingsActionType_ITEM_COUNT';
    export const DELETE_ITEMS_FROM_CANCELABLE_ITEM_LIST = 'SavingsActionType.DELETE_ITEMS_FROM_CANCELABLE_ITEM_LIST';
    export const SUBMIT_TIME_SAVING_ORANGE_APPLY_INFO = 'SUBMIT_TIME_SAVING_ORANGE_APPLY_INFO';
    export const SUBMIT_TIME_SAVING_LOVE_APPLY_INFO = 'SUBMIT_TIME_SAVING_LOVE_APPLY_INFO';
    export const SUBMIT_TIME_SAVING_SMILE_APPLY_INFO = 'SUBMIT_TIME_SAVING_SMILE_APPLY_INFO';
    export const GET_INFO_QR = 'SavingsActionType_GET_INFO_QR';
    export const GET_CONFIRM_PAGE_TEMPLATE: string = 'GET_CONFIRM_PAGE_TEMPLATE';
    export const GET_ENROLLING_YEAR_TEXT: string = 'GET_ENROLLING_YEAR_TEXT';
    export const GET_DEPOSIT_PERIOD_YEAR_MONTH: string = 'GET_DEPOSIT_PERIOD_YEAR_MONTH';
    export const GET_RECEIPT_METHOD: string = 'GET_RECEIPT_METHOD';
    export const GET_TOWN: string = 'GET_TOWN';
    export const CLEAR_FOREIGN_ALL_DOCUMENT: string = 'CLEAR_FOREIGN_ALL_DOCUMENT';
    export const CLEAN_TOWNENTITIES: string = 'CLEAN_TOWNENTITIES';
    export const MODIFY_CHECKBOX_STATUS: string = 'MODIFY_CHECKBOX_STATUS';
    export const MODIFY_CHECKBOX_STATUS_FOREIGN: string = 'MODIFY_CHECKBOX_STATUS_FOREIGN';
    export const MODIFY_CONFIRMATION_CHECKBOX_STATUS_FALSE: string = 'MODIFY_CONFIRMATION_CHECKBOX_STATUS_FALSE';
    export const CLEAR_CONFIRM_PAGE_INFO: string = 'CLEAR_CONFIRM_PAGE_INFO';
    export const CLEAR_CREDIT_CARD_CONFIRM_PAGE_INFO: string = 'CLEAR_CREDIT_CARD_CONFIRM_PAGE_INFO';
    export const RESET_SPECIAL_TRANSFER_INFO: string = 'RESET_SPECIAL_TRANSFER_INFO';
    export const MODIFY_SPECIAL_TRANSFER_INFO_2: string = 'MODIFY_SPECIAL_TRANSFER_INFO_2';
    export const RESET_RECEIPT_RENEW_INFO: string = 'RESET_RECEIPT_RENEW_INFO';
    export const RESET_RECEIPT_SCHEDULE_INFO: string = 'RESET_RECEIPT_SCHEDULE_INFO';
    export const MODIFY_RECEIPT_SCHEDULE_INFO_2: string = 'MODIFY_RECEIPT_SCHEDULE_INFO_2';
    export const GET_ACCOUNT_OPENING_TYPE: string = 'GET_ACCOUNT_OPENING_TYPE';

    export const PASSBOOK_PRINT_MESSAGE_SKIP: string = 'PASSBOOK_PRINT_MESSAGE_SKIP';
    export const SET_SYSTEM_TIME: string = 'SavingsActionType_SET_SYSTEM_TIME';
    export const GET_NEW_PASSWORD_RULE = 'SavingsActionType_GET_NEW_PASSWORD_RULE';  // 暗証番号ルール適合性チェック(新規顧客)
    export const GET_SAME_HOLDER_INQUIRY = 'SavingsActionType_GET_SAME_HOLDER_INQUIRY';     // 同一名義人照会
    export const GET_TABLET_APPLY_COUNT = 'SavingsActionType_GET_TABLET_APPLY_COUNT';
    export const SET_ACCOUNT_TYPE_INFO = 'SavingsActionType_SET_ACCOUNT_TYPE_INFO';
    export const RESET_SHOW_CONFIRM = 'SavingsActionType_RESET_SHOW_CONFIRM';
    export const SET_CANT_COME_REASON = 'SavingsActionType_SET_CANT_COME_REASON'; // こどもが来店できない理由
    export const SET_DUPLICATE_ACCOUNT_INFO = 'SavingsActionType_SET_DUPLICATE_ACCOUNT_INFO';
    export const DELETE_PWD_6BITS = 'SavingsActionType_DELETE_PWD_6BITS';
    export const GET_DEFAULT_ADDRESS = 'SavingsActionType_GET_DEFAULT_ADDRESS';

    export const CLEAR_SUBMIT_DATA = 'SavingsActionType_CLEAR_SUBMIT_DATA';
    export const SET_DUE_DATE_AND_DEPOSIT_PERIOD_YEARMONTH = 'SavingsActionType_SET_DUE_DATE_AND_DEPOSIT_PERIOD_YEARMONTH';
    export const SET_DUE_DATE = 'SavingsActionType_SET_DUE_DATE';
    export const SET_DEPOSIT_PERIOD_YEARMONTH = 'SavingsActionType_SET_DEPOSIT_PERIOD_YEARMONTH';

    export const SET_DOCUMENT_TYPE = 'SavingsActionType_SET_DOCUMENT_TYPE';

    export const SET_DEFAULT_ZIP_CODE = 'SavingsActionType_SET_DEFAULT_ZIP_CODE'; // 郵便番号 default value
    export const MODIFY_AUTO_TRANSFER = 'SavingsActionType_MODIFY_AUTO_TRANSFER';
    export const SET_AUTOMATIC_TRANSFER_START_DATE = 'SavingsActionType_SET_AUTOMATIC_TRANSFER_START_DATE'; // 振替開始日

    export const GET_NEXT_BUSINESS_DAY = 'SavingsActionType_GET_NEXT_BUSINESS_DAY'; // #24401: 翌営業日を取得する。

    export const SET_CIF_INFO = 'SavingsActionType_SET_CIF_INFO';

    export const CLEAN_DOCUMENT_IMAGE = 'SavingsActionType_CLEAN_DOCUMENT_IMAGE';
    export const SAVE_DOCUMENT_IMAGE = 'SavingsActionType_SAVE_DOCUMENT_IMAGE';

    export const SET_TABLET_ID = 'SavingsActionType_SET_TABLET_ID';
    export const SET_USER_CARD_PAN = 'SavingsActionType_SET_USER_CARD_PAN';

    export const UPDATE_SAME_HOLDER_INQUIRY = 'SavingsActionType_UPDATE_SAME_HOLDER_INQUIRY';     // 同一名義人照会
    export const SET_EXISTING_ACCOUNT_INFO = 'SavingsActionType_SET_EXISTING_ACCOUNT_INFO';
    export const CHARACTER_CHECK = 'SavingsActionType_CHARACTER_CHECK';
    export const RECEPTION_CHECK = 'SavingsActionType_RECEPTION_CHECK';
    export const RECEPTION_CHECK_ALL_CIF = 'SavingsActionType_RECEPTION_CHECK_ALL_CIF';
    export const FILTERING_INQUIRY = 'SavingsActionType_FILTERING_INQUIRY';
    export const NAME_AGGREGATION = 'SavingActionType_NAME_AGGREGATION';
    export const SET_CUSTOMER_INFO = 'SavingActionType_SET_CUSTOMER_INFO';

    export const REMOVE_CHAT = 'SavingsActionType_REMOVE_CHAT';
    export const SET_HOLDER_AGE_FLAG = 'SavingsActionType_SET_HOLDER_AGE_FLAG';

    export const SET_BANK_CARD_FLAG = 'SavingsActionType_SET_BANK_CARD_FLAG';
    export const SET_STATE_DATA = 'SavingsActionType_SET_STATE_DATA';
    export const SET_SUBMIT_DATA = 'SavingsActionType_SET_SUBMIT_DATA';
    export const SET_STATE_DATA_FOR_BC = 'SavingsActionType_SET_STATE_DATA_FOR_BC';

    export const SET_IDENTIFICATION_DOCUMENT = 'SavingsActionType_SET_IDENTIFICATION_DOCUMENT';
    export const NEED_INPUT_PHONE_NO = 'SavingsActionType_NEED_INPUT_PHONE_NO';
    export const UP_DATE_BACK_UP = 'SavingsActionType_UP_DATE_BACK_UP';

    export const SET_IC_DATA = 'SavingsActionType_SET_IC_DATA';
    export const SET_LAST_FILTERING_PARAMS = 'SavingsActionType_SET_LAST_FILTERING_PARAMS';

    export const GET_ACCOUNT_EXISTING = 'SavingsActionType_GET_ACCOUNT_EXISTING';
    export const SELECT_CHANGE = 'SavingsActionType_SELECT_CHANGE';

    export const REMOVE_NOT_MASKING_CONFIRM_IMAGES = 'SavingsActionType_REMOVE_NOT_MASKING_CONFIRM_IMAGES';
    export const RESET_NOT_MASKING_CONFIRM_IMAGES = 'SavingsActionType_RESET_NOT_MASKING_CONFIRM_IMAGES';

    export const KEYS_ARY_BACKUP = 'SavingsActionType_KEYS_ARY_BACKUP';
    export const KEYS_ARY_ROLLBACK = 'SavingsActionType_KEYS_ARY_ROLLBACK';

    export const RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES = 'SavingsActionType_RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES';
    export const RECEPTION_LOSS_CORRUPTION_CHECK = 'SavingsActionType_RECEPTION_LOSS_CORRUPTION_CHECK';
    export const RECEPTION_LOSS_CORRUPTION_CHECK_ADD = 'SavingsActionType_RECEPTION_LOSS_CORRUPTION_CHECK_ADD';
    export const GET_ANSWER_ORDER = 'SavingsActionType_GET_ANSWER_ORDER';
    export const SAVE_CREDIT_CARD_DATA = 'SavingsActionType_SAVE_CREDIT_CARD_DATA';
    export const SAVE_TENBAN_BEFORE = 'SavingsActionType_SAVE_TENBAN_BEFORE';
    export const RECEPTION_CHANGE_NEW_ACCOUNT_JAPANES = 'SavingsActionType_RECEPTION_CHANGE_NEW_ACCOUNT_JAPANES';
    export const RECEPTION_CHANGE_NEW_ACCOUNT_FORGINER = 'SavingsActionType_RECEPTION_CHANGE_NEW_ACCOUNT_FORGINER';
    export const RECEPTION_CHANGE_EXISTING_ACCOUNT = 'SavingsActionType_RECEPTION_CHANGE_EXISTING_ACCOUNT';

    export const GO_BACK_RELATE_CHAT = 'SavingsActionType_GO_BACK_RELATE_CHAT';
    export const MODIFY_EXPIRY_DATE_EXISTS = 'SavingsActionType_MODIFY_EXPIRY_DATE_EXISTS';
    export const UNACCEPTABLES_NG = 'SavingsActionType_UNACCEPTABLES_NG';
}

@Injectable()
export class SavingsAction extends Action implements DocumentCategoryObserverAction {

    constructor(
        private httpService: HttpService,
        private logging: LoggingService,
        private hostErrorService: HostErrorService,
        private loginStore: LoginStore,
        private ngZone: NgZone,
    ) {
        super();
    }

    /**
     * 写真未確認状態管理オブジェクトから確認済内容を削除
     *
     * @param {{documentName: string, index: number}} maskingConfirmImgStatus
     * @memberof SavingsAction
     */
    public removeNotMaskingConfirmImages(maskingConfirmImgStatus: { documentName: string, index: number }) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES,
            data: maskingConfirmImgStatus
        });
    }

    /**
     * マスキング確認完了しないオブジェクトをリセット。
     *
     * @param {ClearSavingImagesClickRecordType} type リセットタイプ
     * @memberof SavingsAction
     */
    public resetNotMaskingConfirmImages(type: ClearSavingImagesClickRecordType) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RESET_NOT_MASKING_CONFIRM_IMAGES,
            data: type
        });
    }

    /**
     * マスキング確認完了しないオブジェクトをリセット。
     *
     * @param {ClearSavingImagesClickRecordType} type リセットタイプ
     * @memberof SavingsAction
     */
    public resetSpecialNotMaskingConfirmImages(specalDocumentName: string) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES,
            data: specalDocumentName
        });
    }

    public needInputPhoenNo() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.NEED_INPUT_PHONE_NO,
        });
    }

    /**
     * バンクカード申込フラグを設定
     * @param value value
     */
    public setBankCardFlag(value: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_BANK_CARD_FLAG,
            data: value
        });
    }

    public async validatePassword(params: any) {

        // ICログ
        try {
            this.logging.saveCustomOperationLog(
                'reception-password',
                'ic-data:' + (params.params.icCardInfo ? params.params.icCardInfo.length : 'null')
            );
        } catch (ex) {
            this.logging.saveCustomOperationLog('reception-password', 'Exception');
        }

        return new Promise((resolve, reject) => {
            this.httpService.post('/reception/get', params, null, SpinnerType.SHOW_TRANSPARENT, true)
                .pipe(tap((res) => this.setCifInfo(res)))
                .subscribe((result) => {
                    if (result.status === HttpStatus.SUCCESS) {
                        resolve(true);
                    } else if (result.status === HttpStatus.HOST_ERROR) {
                        if (result.errors.data &&
                            result.errors.data.resultCode &&
                            result.errors.data.resultCode === HostResultCode.RECEPTION_GET_ERROR) {
                            resolve(true);
                        } else {
                            this.hostErrorService.push({
                                resultCode: result.errors.data.resultCode,
                                errorCode: result.errors.data.errorCode,
                                message: result.errors.message,
                                handel: () => {
                                    resolve(false);
                                }
                            });
                        }
                    } else {
                        throw new HttpStatusError('/reception/get', result.status, result.errors);
                    }
                }, (error) => {
                    reject(error);
                });
        });
    }

    public changeOpenStore(data: any) {
        this.setStateSubmitDataValue({
            name: 'branchName',
            value: data.branchName || data.branchNameKanji
        });
        this.setStateSubmitDataValue({
            name: 'tenban',
            value: data.tenban || data.branchNo
        });
        this.setStateSubmitDataValue({
            name: 'existingAccount',
            value: undefined
        });
    }

    public changeExistingAccount(data: any) {
        this.setStateSubmitDataValue({
            name: 'existingAccount',
            value: data
        });
    }

    public setStateData(data: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_STATE_DATA,
            data: data
        });
    }

    public setData(submitData: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_STATE_DATA_FOR_BC,
            data: submitData
        });
    }

    /**
     * submitDataの値を変更する
     *
     * @param {*} data
     * @memberof SavingsAction
     */
    public editSomeDataInSubmitData(index: number, key: string, val: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_SUBMIT_DATA,
            data: {
                index: index,
                key: key,
                val: val
            }
        });
    }

    public getCategoryNameLogic() {
        return this.httpService.get('/categoryCodes/retrieve', { params: { categoryCode: '049' } })
            .pipe(map((res) => res.result));
    }

    public getCategoryNameLogicParams(params) {
        return this.httpService.get('/categoryCodes/retrieve', params)
            .pipe(map((res) => res.result));
    }

    /**
     * タブレットIDを保存
     * @param id タブレットID
     */
    public setTabletApplyId(id: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_TABLET_ID,
            data: id
        });
    }

    public setExistingAccountInfo(value: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_EXISTING_ACCOUNT_INFO,
            data: value
        });
    }

    /**
     * 本人確認書類画像をクリア
     */
    public cleanIdentityDocumentImage(category: Constants.IdentityDocumentCategory) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.CLEAN_DOCUMENT_IMAGE,
            data: category
        });
    }

    /**
     * 本人確認書類画像を保存
     */
    public saveIdentityDocumentImage(document: { image: string, category: Constants.IdentityDocumentCategory }) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SAVE_DOCUMENT_IMAGE,
            data: document
        });
    }

    /**
     * ユーザーカード番号を保存
     */
    public setPanApd(code: string) {
        if (AppProperties.DEV_MODE === String(false)
            && !InputUtils.isTrngEnvNoCard(this.loginStore.getState().cardReaderDeviceId)) {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.SET_USER_CARD_PAN,
                data: {
                    cardInfo: {
                        bankNo: code.substr(0, 4),                                  // 金融機関
                        // 店番号 左の'0'を外す ３桁足りない場合０を埋める
                        branchNo: StringUtils.padLeft(code.substr(4, 5).replace(/0+([1-9]+)/, '$1'), 3, '0'),
                        accountType: code.substr(9, 1) === '1' ? '12' : '99',       // 種目 （1）普通預金=(12)普通預金 上記以外 = (99)その他
                        // 口座番号 左の'0'を外す　７桁足りない場合０を埋める
                        accountNo: StringUtils.padLeft(code.substr(10, 8).replace(/0+([1-9]+)/, '$1'), 7, '0')
                    }
                }
            });
        } else {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.SET_USER_CARD_PAN,
                data: {
                    cardInfo: {
                        bankNo: '0138',      // 金融機関
                        branchNo: code.substr(0, 3),    // 店番号
                        accountType: '12',       // 種目 （1）普通預金=(12)普通預金 上記以外 = (99)その他
                        accountNo: code.substr(3)       // 口座番号
                    }
                }
            });
        }
    }

    /**
     * 本人確認書類typeをセット
     * @param data type情報
     */
    public setDocumentType(data: { name: COMMON_CONSTANTS.InsertDocument, value }) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_DOCUMENT_TYPE,
            data: data
        });
    }

    /**
     * submit dataを更新
     *
     * @param data 書類カテゴリと選択された書類
     * @param isHolderPage 本人確認画面フラグ
     * @param isHolder 本人フラグ
     */
    public setDocumentCategory(data: DocumentCategorySubjectData, isHolderPage: boolean, isHolder: boolean) {
        switch (data.code) {
            // 本人確認情報
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_TYPE:
                this.setStateSubmitDataValue({
                    name: isHolderPage ? SubmitDataKey.HOLDER_ID_DOC_TYPE : SubmitDataKey.AGENT_ID_DOC_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                });
                if (isHolder) {
                    this.setStateSubmitDataValue({
                        name: SubmitDataKey.RECEIPT_METHOD,
                        value: data.entity ? (data.entity.filler6 === CodeCategory.FACEID ?
                            CodeCategory.RECEIPT_METHOD_ISSUE : CodeCategory.RECEIPT_METHOD_MAIL) :
                            CodeCategory.RECEIPT_METHOD_MAIL
                    });
                }
                break;
            // 本人確認書類（顔写真ない）の補完書類の種類
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_PHOTOGRAPH_TYPE:
                this.setStateSubmitDataValue({
                    name: isHolderPage ? SubmitDataKey.HOLDER_ID_DOC_PHOTO_TYPE : SubmitDataKey.AGENT_ID_DOC_PHOTO_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                });
                break;
            // 本人確認書類（住所異なる）の補完書類の種類
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_ADDRESS_TYPE:
                this.setStateSubmitDataValue({
                    name: isHolderPage ? SubmitDataKey.HOLDER_ID_DOC_ADDRESS_TYPE : SubmitDataKey.AGENT_ID_DOC_ADDRESS_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                });
                break;
            // コピー徴求ができない理由
            case CodeCategory.CODE_CATEGORY_NO_COPY_REASON:
            // 住所が相違する理由
            case CodeCategory.CODE_CATEGORY_DIFFERENT_ADDRESS_REASON:
            // 遠隔地等住所等の場合の理由
            case CodeCategory.CODE_CATEGORY_FAR_ADDRESS_REASON:
                this.setStateSubmitDataValue({
                    name: data.key,
                    value: data.entity ? data.entity.data : null
                });
                break;
        }
    }

    /**
     * cif情報をセット
     * @param info cif情報
     */
    public setCifInfo(info: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_CIF_INFO,
            data: info
        });
    }

    /**
     * チャットフロー情報をセット
     * @param data チャットフロー情報
     */
    public setChatFlowInfo(data: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_CHAT_FLOW_INFO,
            data: data
        });
    }

    public setAgencyBranchInfo(branchNo: string) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_AGENCY_BRANCH_INFO,
            data: { branchNo: branchNo }
        });
    }

    public setBranchInfo(branchNameKanji, branchNo: string) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_BRANCH_INFO,
            data: {
                branchNameKanji: branchNameKanji,
                branchNo: branchNo
            }
        });
    }

    public setBankclerkId(bankclerkId: string) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_BANKCLERK_ID,
            data: { bankclerkId: bankclerkId }
        });
    }

    public clearSubmitData(choices: any[]) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.CLEAR_SUBMIT_DATA,
            data: choices
        });
    }

    public loadTemplate(file: string, pageIndex: number) {
        this.httpService.get('/chatflow/definition/' + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos,
                }
            });
        });
    }

    public branchStatusInsert(params: any, showTransparent: boolean = true) {
        const observable = showTransparent ?
            this.httpService.post('/branchInfo/tabletInfo/insert', params) :
            this.httpService.post('/branchInfo/tabletInfo/insert', params, null, SpinnerType.NO_SHOW);

        observable.subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.BRANCH_STATUS_INSERT,
                data: response.result
            });
        });
    }

    public uploadImage(params: any) {
        this.httpService.post('/files/fileAccess/save/json', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.UPLOAD_IMAGE,
                data: response.result
            });
        });
    }

    // get holderZipCode 郵便番号
    public getHolderZipCode(prefectureKanji: string, countyUrbanVillageKanji: string, streetKanji: string) {
        const params = {
            prefectureKanji: prefectureKanji,
            countyUrbanVillageKanji: countyUrbanVillageKanji,
            streetKanji: streetKanji
        };
        this.httpService.get('/address/zipCodeSearch', { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_HOLDER_ZIP_CODE,
                data: response.result.zipCode
            });
        }
        );
    }

    public branchStatusUpdate(params: any) {
        this.httpService.post(API_URL.BRANCH_STATUS_UPDATE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.BRANCH_STATUS_UPDATE,
                data: response.result
            });
        });
    }

    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    /**
     * 16歳以上年齢フラグ設定
     * @param params birthdate: 生年月日, today: システム日付
     */
    public setHolderAgeFlag(params: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_HOLDER_AGE_FLAG,
            data: params
        });
    }

    public clearStore() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.CLEAR
        });
    }

    public clearConfirmPageInfo(isResetMaskingCheckbox: boolean = true) {
        console.log('===isResetMaskingCheckbox===' + isResetMaskingCheckbox);
        this.dispatcher.dispatch({
            actionType: SavingsActionType.CLEAR_CONFIRM_PAGE_INFO,
            data: {
                isResetMaskingCheckbox: isResetMaskingCheckbox
            }
        });
    }

    public clearCreditCardConfirmPageInfo() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.CLEAR_CREDIT_CARD_CONFIRM_PAGE_INFO,
        });
    }

    public clearShowChats() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.CLEAR_SHOW_CHATS
        });
    }

    public setCustomerApplyStartDate() {
        this.setAsSystemTime(ApplyDate.CUSTOMER_APPLY_START_DATE);
    }

    /**
     * 顧客申し込み完了時間を設定する
     */
    public setCustomerApplyEndDate() {
        this.setAsSystemTime(ApplyDate.CUSTOMER_APPLY_END_DATE);
    }

    /**
     * 行員ログインが完了した時間
     */
    public setBankclerkAuthenticationStartDate() {
        this.setAsSystemTime(ApplyDate.BANKCLERK_AUTHENTICATION_START_DATE);
    }

    /**
     * 行員認証画面で認証ボタンをタップした時間
     */
    public setBankclerkAuthenticationEndDate() {
        this.setAsSystemTime(ApplyDate.BANKCLERK_AUTHENTICATION_END_DATE);
    }

    public editChart(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.EDIT_CHAT,
            data: { order: order, pageIndex: pageIndex, answerOrder: answerOrder, orderIndex: orderIndex }
        });
    }

    public setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_ANSWER,
            data: answer
        });
    }

    public setStateSubmitDataValue(param: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_STATE_SUBMIT_DATA_VALUE,
            data: param
        });
    }

    public getInfoFromOCR(params: any) {
        this.httpService.post('/ocr/analysis', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_INFO_OCR,
                data: response.result
            });
        });
    }

    /**
     * OCR 解析された情報を設定してする
     * @param params OCR情報
     */
    public setInfoFromOCR(params: any) {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
            const remainingPeriod = moment(params.dueDate, COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD)
                .diff(moment(response.result.value), COMMON_CONSTANTS.DATE_MONTH);
            this.dispatcher.dispatch({
                actionType: SavingsActionType.SET_INFO_OCR,
                data: {
                    ...params,
                    remainingPeriod
                }
            });
        });
    }

    public saveSubmitData(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/bankclerk-confirm-insert', params, {}, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.BRANCH_INFO_INSERT,
                data: response.result
            });
        });
    }

    public submitDataBackup() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SUBMIT_DATA_BACKUP
        });
    }

    public updateSubmitDataBackup(data) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.UPDATA_SUBMIT_DATA_BACKUP,
            data: data
        });
    }

    public resetSubmitData() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RESET_SUBMIT_DATA
        });
    }

    public upDateBackUp(params: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.UP_DATE_BACK_UP,
            data: params
        });
    }
    public retrieveDropList(params: any) {
        this.httpService.get('/categoryCodes/retrieve', params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.RETRIEVE_DROP_LIST,
                data: response.result
            });
        });
    }

    public getAccountOpeningType(params: any) {
        this.httpService.get('/categoryCodes/get-account-opening-type', params, false, SpinnerType.SHOW).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_ACCOUNT_OPENING_TYPE,
                data: response.result
            });
        });
    }

    public setTabletStartDate() {
        this.setAsSystemTime(ApplyDate.TABLET_START_DATE);
    }

    public chatFlowCompelete(nextChatName: string, options: any = null) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.CHAT_FLOW_COMPELETE,
            data: {
                name: nextChatName,
                options: options
            }
        });
    }

    public chatFlowReturn(nextChatName: string, options: any = null) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.CHAT_FLOW_RETURN,
            data: {
                name: nextChatName,
                options: options
            }
        });
    }

    public resetLastNode(params: { order: number, pageIndex: number }) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RESET_LAST_NODE,
            data: params
        });
    }

    public resetSpecialNode(params: { order: number, pageIndex: number }) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RESET_SPECIAL_NODE,
            data: params
        });
    }

    public submitTimeSavingApplyInfo(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/time-saving-apply-info-insert',
            params, {}, SpinnerType.SHOW).subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: SavingsActionType.SUBMIT_TIME_SAVING_APPLY_INFO,
                    data: response.result
                });
            });
    }

    public submitTimeSavingSmileApplyInfo(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/time-saving-smile-apply-info-insert',
            params, {}, SpinnerType.SHOW).subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: SavingsActionType.SUBMIT_TIME_SAVING_SMILE_APPLY_INFO,
                    data: response.result
                });
            });
    }

    public submitTimeSavingOrangeApplyInfo(params: any) {
        this.httpService.post(
            API_URL.ORDINARILY_ACCOUNT_INFO,
            params, {},
            SpinnerType.SHOW
        ).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.SUBMIT_TIME_SAVING_ORANGE_APPLY_INFO,
                data: response.result
            });
        });
    }

    public submitTimeSavingLoveApplyInfo(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/time-saving-love-apply-info-insert',
            params, {}, SpinnerType.SHOW).subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: SavingsActionType.SUBMIT_TIME_SAVING_LOVE_APPLY_INFO,
                    data: response.result
                });
            });
    }

    public loadConfirmPageTemplate(file: string, pageIndex: number) {
        this.httpService.get('/chatflow/definition/' + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_CONFIRM_PAGE_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                }
            });
        });
    }

    /**
     * 確認書類をクリア
     */
    public clearForeignIdentificationDocument() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.CLEAR_FOREIGN_ALL_DOCUMENT,
        });
    }

    /**
     * キャッシュカード発行
     * @param params
     */
    public saveCashcardData(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/cashcard-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.BRANCH_INFO_INSERT,
                data: response.result
            });
        });
    }

    // get 入学年 YYYY --> YYYY(平成XX)年
    public getEnrollingYearText(params: any) {
        this.httpService.get('/japaneseCalendar/birthday/convert-jp', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_ENROLLING_YEAR_TEXT,
                data: response.result
            });
        });
    }

    public getDepositPeriodYearMonth() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.GET_DEPOSIT_PERIOD_YEAR_MONTH,
            data: 'get depositPeriodYearMonth'
        });
    }

    // get カードお受取方法
    public getReceiptMethod(params: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.GET_RECEIPT_METHOD,
            data: params
        });
    }

    public getBranch(params: any) {
        this.httpService.get('/branchInfo/tabletInfo/branch-shortnames-bykana', params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_TOWN,
                data: response.result
            });
        }
        );
    }

    public cleanTownEntities() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.CLEAN_TOWNENTITIES,
            data: []
        });
    }

    // modify checkbox status -- カードお受取方法
    public modifyCheckboxStatus(name: string) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.MODIFY_CHECKBOX_STATUS,
            data: name
        });
    }

    // modify checkbox status -- カードお受取方法
    public modifyCheckboxStatusForeign(name: string) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.MODIFY_CHECKBOX_STATUS_FOREIGN,
            data: name
        });
    }

    // modify checkbox status -- 契約状況確認 チェックボックスの初期値   false
    public modifycConfirmationCheckboxStatusFalse() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.MODIFY_CONFIRMATION_CHECKBOX_STATUS_FALSE,
            data: name
        });
    }

    public setIdentificationDocument(data) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_IDENTIFICATION_DOCUMENT,
            data: data
        });
    }

    // Save Operation Log
    public saveOperationLog(logInfo: IOperationInfo) {
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }

    //  修正 毎月振替日とは別に特定振替日(年2回まで)を設定しますか？ 設定しない
    // reset 特定振替日1,特定振替額1 / 特定振替日2,特定振替額2
    public resetSpecialTransferInfo() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RESET_SPECIAL_TRANSFER_INFO,
            data: true
        });
    }

    // 修正 特定振替日(年2回まで)を追加で設定しますか？ 設定しない
    // modifySpecialTransferInfo2
    public modifySpecialTransferInfo2() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.MODIFY_SPECIAL_TRANSFER_INFO_2,
            data: true
        });
    }

    // サイクル指定
    public resetReceiptRenewInfo() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RESET_RECEIPT_RENEW_INFO,
            data: true
        });
    }

    // 受取日指定
    public resetReceiptScheduleInfo() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RESET_RECEIPT_SCHEDULE_INFO,
            data: true
        });
    }

    // 修正 受取日指定 追加で受取日2を指定しますか？ 指定しない
    // modifyReceiptScheduleInfo2
    public modifyReceiptScheduleInfo2() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.MODIFY_RECEIPT_SCHEDULE_INFO_2,
            data: true
        });
    }

    // 通帳に印刷する文字 skip
    public passbookPrintMessageSkip() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.PASSBOOK_PRINT_MESSAGE_SKIP,
            data: true
        });
    }

    // QRcode復号化APIを呼び出し
    public getInfoFromQR(qrCode: string) {
        const params = {
            decryptCode: qrCode
        };
        this.httpService.post(API_URL.QRCODE_DECRYPT, params).subscribe((response) => {
            const qrInfo: ReceptionInfoEntity = new ReceptionInfoEntity();
            qrInfo.setReceptionInfo(response.result.decryptedStringData ?
                (response.result.decryptedStringData as string).split(',') : null);

            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_INFO_QR,
                data: qrInfo
            });
        });
    }

    /**
     * set the item value as the current time of server
     * @param key the checbox item need to modify status
     */
    public setAsSystemTime(key: string, showTransparent: boolean = true) {
        const observable = showTransparent ?
            this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL) :
            this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL, null, null, SpinnerType.NO_SHOW);
        observable.subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.SET_SYSTEM_TIME,
                data: {
                    key: key,
                    systemTime: response.result.value
                }
            });
        });
    }

    /**
     * get system time
     */
    public getSystemTime() {
        return this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).pipe(
            map((response) => response.result.value)
        );
    }

    /**
     * 暗証番号ルール適合性チェック(新規顧客)
     * @param params 暗証番号ルール適合性チェック用パラメータ
     */
    public checkNewCustomerPasswordRule(params: NewPasswordRuleCheckInterface) {
        this.httpService.post(API_URL.CB_CHECK_NEW_PASSWORD_RULE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_NEW_PASSWORD_RULE,
                data: response.result
            });
        });
    }

    /**
     * 同一名義人照会
     * @param params 同一名義人照会用パラメータ
     * @param component 遷移先コンポーネント
     */
    public getSameHolderInquiry(params: any) {
        this.httpService.post('/core-banking/same-holder/inquiry', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_SAME_HOLDER_INQUIRY,
                data: { result: response.result }
            });
        });
    }

    public updateDuplicateAccountInfos(data: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.UPDATE_SAME_HOLDER_INQUIRY,
            data: data
        });
    }

    /**
     * QRコードの複数回スキャンを判断するため、タブレット申込情報照会を行う
     * @param params タブレット申込情報照会用パラメータ
     */
    public getApplyInfoInquiry(params: any, showTransparent: boolean = true) {
        const hasTabletObservable = showTransparent ?
            this.httpService.post(API_URL.HAS_TABLET_APPLY_COUNT, params) :
            this.httpService.post(API_URL.HAS_TABLET_APPLY_COUNT, params, null, SpinnerType.NO_SHOW);
        hasTabletObservable.subscribe((response) => {
            const isSecondApply = response.result;
            if (!isSecondApply) {
                // 顧客申し込み開始時間（サーバ時間）を取得
                const observable = showTransparent ?
                    this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL) :
                    this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL, null, null, SpinnerType.NO_SHOW);
                observable.subscribe((time) => {
                    this.dispatcher.dispatch({
                        actionType: SavingsActionType.GET_TABLET_APPLY_COUNT,
                        data: {
                            isSecondApply: isSecondApply,
                            systemTime: time.result.value
                        }
                    });
                });
                return;
            }

            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_TABLET_APPLY_COUNT,
                data: {
                    isSecondApply: isSecondApply,
                    systemTime: undefined
                }
            });
        });
    }

    /**
     * 選択した口座タイプをセット
     * @param params 選択した口座タイプ
     */
    public setAccountTypeInfo(params: string) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_ACCOUNT_TYPE_INFO,
            data: params
        });
    }

    /**
     * Reset showConfirm
     * @param showConfirm showConfirm
     */
    public resetShowConfirm(showConfirm: any, submitData: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RESET_SHOW_CONFIRM,
            data: { showConfirm, submitData }
        });
    }

    /**
     * こどもが来店できない理由
     */
    public getChildrenCantComeReason() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_CANT_COME_REASON,
        });
    }
    /**
     * delete firstPwd6bits
     */
    public deleteFirstPwd6bits() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.DELETE_PWD_6BITS,
            data: ''
        });
    }

    /**
     * Request default address
     * @param params params
     * @param entity entity
     * @param pageIndex pageIndex
     */
    public requestDefaultAddress(params, entity, pageIndex) {
        this.httpService.get(API_URL.DEFAULT_ADDRESS, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_DEFAULT_ADDRESS,
                data: {
                    result: response.result,
                    entity: entity,
                    pageIndex: pageIndex
                }
            });
        });
    }

    /*
     * 顧客申し込み開始時間を設定する
     */
    public setCustomerStartDate(showTransparent: boolean = true) {
        this.setAsSystemTime(ApplyDate.CUSTOMER_APPLY_START_DATE, showTransparent);
    }

    /**
     * 重複口座情報をセット
     * @param data 重複口座情報
     */
    public setDuplicateAccountInfo(data: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_DUPLICATE_ACCOUNT_INFO,
            data: data
        });
    }

    /**
     * 預入期間と満期日を設定する
     */
    public setDueDateAndDepositPeriodYearMonth() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_DUE_DATE_AND_DEPOSIT_PERIOD_YEARMONTH,
        });
    }

    /**
     * 満期日を設定する
     */
    public setDueDate() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_DUE_DATE,
        });
    }

    /**
     * 郵便番号　default value
     */
    public setDefaultZipCode() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_DEFAULT_ZIP_CODE,
        });
    }

    /**
     * 自動振替情報更新
     */
    public modifyAutoTransfer() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.MODIFY_AUTO_TRANSFER,
        });
    }

    /**
     * 振替開始日／初回振替開始日を設定する
     */
    public setAutomaticTransferStartDate(data: string) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_AUTOMATIC_TRANSFER_START_DATE,
            data: data
        });
    }

    /**
     * #24401
     * 翌営業日を取得する。
     */
    public getNextBusinessDay(params: any) {
        this.httpService.post(API_URL.GET_NEXT_BUSINESS_DAY, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.GET_NEXT_BUSINESS_DAY,
                data: { data: response.result }
            });
        });
    }

    /**
     * 地域コードを検索する(WebAPI呼び出し)
     * @param params 地域コード検索条件
     */
    public searchRegionCode(params: RegionCodeSearchRequestEntity): Observable<any> {
        return this.httpService.get(API_URL.REGION_CODE_SEARCH, { params: params });
    }

    /**
     * 文字チェック
     * @param params 文字チェックパラメータ
     */
    public characteCheck(params: any, handel?: any) {
        this.httpService.post(API_URL.CHARACTER_CHECK, params, null, SpinnerType.SHOW_TRANSPARENT, true)
            .subscribe((result) => {
                if (result.status === HttpStatus.SUCCESS) {
                    this.dispatcher.dispatch({
                        actionType: SavingsActionType.CHARACTER_CHECK,
                        data: result.result
                    });
                } else if (result.status === HttpStatus.HOST_ERROR) {
                    if (result.errors.data &&
                        result.errors.data.resultCode &&
                        result.errors.data.resultCode === HostResultCode.REENTER) {
                        this.hostErrorService.push({
                            resultCode: result.errors.data.resultCode,
                            errorCode: result.errors.data.errorCode,
                            message: result.errors.message,
                            handel: handel
                        });
                    }
                } else {
                    throw new HttpStatusError(API_URL.CHARACTER_CHECK, result.status, result.errors);
                }
            });
    }

    /**
     * 受付可否チェック
     * @param params 受付可否チェックパラメータ
     */
    public receptionCheck(params: any) {
        return this.httpService.post(API_URL.RECEPTION_CHECK, params).pipe(
            tap((response) => {
                this.dispatcher.dispatch({
                    actionType: SavingsActionType.RECEPTION_CHECK,
                    data: response.result
                });
            })
        );
    }

    /**
     * 受付可否チェック(全店CIF用)
     * @param params 受付可否チェックパラメータ
     */
    public receptionCheckAllCif(params: any) {
        this.httpService.post(API_URL.RECEPTION_CHECK, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.RECEPTION_CHECK_ALL_CIF,
                data: response.result
            });
        });
    }

    /**
     * 受付可否チェック(喪失・破損)APIを実行する
     * @param params 受付可否チェックパラメータ
     */
    public receptionLossCorruptionCheck(params: ReceptionLossCorruptionCheckRequest, name?: string) {
        this.receptionLossCorruptionCheckApi(params, name, SavingsActionType.RECEPTION_LOSS_CORRUPTION_CHECK);
    }

    /**
     * 受付可否チェック(喪失・破損)APIを実行する。エラー情報が存在した場合、前回実行時の結果に追記する。
     * @param params 受付可否チェックパラメータ
     */
    public receptionLossCorruptionCheckAdd(params: ReceptionLossCorruptionCheckRequest, name?: string) {
        this.receptionLossCorruptionCheckApi(params, name, SavingsActionType.RECEPTION_LOSS_CORRUPTION_CHECK_ADD);
    }

    /**
     * 受付可否チェック(喪失・破損)APIを実行する。実行後処理は呼び出し元に委任する。
     * @param params 受付可否チェックパラメータ
     */
    public receptionLossCorruptionCheckApi(params: ReceptionLossCorruptionCheckRequest, name: string, actionType: string) {
        this.httpService.post(API_URL.RECEPTION_LOSS_CORRUPTION_CHECK, params, undefined, undefined, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.RECEPTION_LOSS_CORRUPTION_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: actionType,
                        data: {
                            name: name,
                            data: response instanceof HttpStatusError ? response.errors.data : response.result,
                            requestParams: params
                        }
                    });
                }
            }
        );
    }

    /**
     * フィルタリングシステム検索
     * @param params フィルタリングシステム検索パラメーター
     */
    public filterInquiry(params: any) {
        this.httpService.post(API_URL.FILTERING_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.FILTERING_INQUIRY,
                data: response.result
            });
        });
    }

    /**
     * ICカードの認証処理を行う。
     * @param params ICカード情報
     */
    public cardIinfoCheck(params: any) {
        return new Promise((resolve, reject) => {
            this.httpService.post(API_URL.CARD_CERTIFICATION_CHECK, params).subscribe((res) => {
                resolve(true);
            });
        });
    }

    public updateApplyBizCategory(updateInfo) {
        this.httpService.post(API_URL.UPDATE_APPLY_BUSINESS_CATEGORY, updateInfo).subscribe((response) => {
            // do-nothing
        });
    }

    /**
     * ICカードの情報をstateに保存
     *
     * @param {string} data
     * @memberof SavingsAction
     */
    public setIcData(data: string) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_IC_DATA,
            data: data
        });
    }

    /**
     * フィルタリングシステムへの照会パラメータを保存
     *
     * @param {FilteringParameterEntity} curFilteringParamters
     * @memberof SavingsAction
     */
    public setLastFilteringParameters(curFilteringParamters: FilteringParameterEntity) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SET_LAST_FILTERING_PARAMS,
            data: curFilteringParamters
        });
    }

    /**
     * フィルタリングシステムへの照会結果を保存
     *
     * @param {*} data
     * @memberof SavingsAction
     */
    public setLastFilteringResult(data: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.FILTERING_INQUIRY,
            data: data
        });
    }

    /**
     * 全店名寄せ照会
     * @param params パラメータ
     */
    public nameAggregationInquiry(params: any) {
        this.httpService.post(API_URL.NAME_AGGREGATION, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.NAME_AGGREGATION,
                data: {
                    customerInfo: response.result.customerInfo,
                    customerSearchStatus: response.result.customerSearchStatus
                }
            });
        });
    }

    /**
     * 内部API: 顧客情報照会（複数件取得）
     * @param params
     */
    public getCustomerInfo(params: any) {
        this.httpService.post(API_URL.CB_CIF_INFOS_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: SavingsActionType.SET_CUSTOMER_INFO,
                data: response.result
            });
        });
    }

    /**
     * keysAryをバックアップ
     */
    public keysAryBackup() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.KEYS_ARY_BACKUP
        });
    }

    /**
     * 口座存在チェック
     * @param params 口座存在チェック用パラメータ
     */
    public checkAccountExisting(params: any, ressetdata) {
        this.httpService.post(API_URL.CB_CHECK_ACCOUNT_INFO, params, null, SpinnerType.SHOW_TRANSPARENT, true).subscribe((response) => {
            if (response.status === HttpStatus.SUCCESS) {
                this.dispatcher.dispatch({
                    actionType: SavingsActionType.GET_ACCOUNT_EXISTING,
                    data: {
                        result: response.result,
                        hasAccountExist: true,
                    }
                });
            } else if (response.status === HttpStatus.HOST_ERROR) {
                if (response.errors.data && response.errors.data.resultCode === HostResultCode.REENTER) {
                    this.dispatcher.dispatch({
                        actionType: SavingsActionType.GET_ACCOUNT_EXISTING,
                        data: {
                            hasAccountExist: false,
                        }
                    });
                } else if (response.errors && response.errors.data && this.isHostError(response.errors.data.errorCode)) {
                    // エラーコードが受付可否チェックのエラーコードに該当する場合、エラーメッセージ編集を行う
                    this.dispatcher.dispatch({
                        actionType: SavingsActionType.UNACCEPTABLES_NG,
                        data: response
                    });
                } else {
                    this.hostErrorService.push({
                        resultCode: response.errors.data.resultCode,
                        errorCode: response.errors.data.errorCode,
                        message: response.errors.message,
                        handel: () => {
                            this.resetLastNode(ressetdata);
                        }
                    });
                }
            } else {
                this.ngZone.runTask(() => {
                    throw new HttpStatusError(API_URL.CB_CHECK_ACCOUNT_INFO, response.status, response.errors);
                });
            }
        });
    }

    /**
     * 諸届選択時、申込業務を書換する。
     */
    public selectChange() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SELECT_CHANGE,
        });
    }

    /**
     * 旧姓認証失敗時、誕生日入力直後の状態にチャットを戻す。
     * @param name keysArr内の要素の位置を知りたい変数名
     */
    public getAnswerOrder(name: string) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.GET_ANSWER_ORDER,
            data: name
        });
    }

    /**
     * keysAryを戻す
     */
    public keysAryRollback() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.KEYS_ARY_ROLLBACK
        });
    }

    /**
     * BC複合取引情報を保存
     * @param params creditCardSubmitData
     */
    public saveCreditCardData(creditCardSubmitData: any) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SAVE_CREDIT_CARD_DATA,
            data: creditCardSubmitData
        });
    }

    /**
     * 修正前の口座開設店を保存する。
     * @param params creditCardSubmitData
     */
    public saveTenbanBefore(tenban: string) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.SAVE_TENBAN_BEFORE,
            data: tenban
        });
    }

    /**
     * 受付チャットから「純新規」後続業務に行くときに、
     * 後続業務をうまく実行するために、パラメータ変更を行います。
     * @param params
     */
    public receptionChangeNewAccountJapanes() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RECEPTION_CHANGE_NEW_ACCOUNT_JAPANES
        });
    }

    /**
     * 受付チャットから「外国人」後続業務に行くときに、
     * 後続業務をうまく実行するために、パラメータ変更を行います。
     * @param params
     */
    public receptionChangeNewAccountForginer() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RECEPTION_CHANGE_NEW_ACCOUNT_FORGINER
        });
    }

    /**
     * 受付チャットから「既存新規」後続業務に行くときに、
     * 後続業務をうまく実行するために、パラメータ変更を行います。
     * @param params
     */
    public receptionChangeExistingAccount() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.RECEPTION_CHANGE_EXISTING_ACCOUNT
        });
    }

    /**
     * OCR読取（運転免許証）の場合、本人確認チャットで
     * 運転経歴証明書を選択した際の確認チャットで「いいえ」回答時
     * 免許証or経歴証明書を選択させるため回答済チャットを削除する
     */
    public gobackRelateChat() {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.GO_BACK_RELATE_CHAT
        });
    }

    /**
     * 修正チャットで有効期限がクリア状態か判別するフラグを保存する。
     */
    public setModifyExpiryDateExists(value: boolean) {
        this.dispatcher.dispatch({
            actionType: SavingsActionType.MODIFY_EXPIRY_DATE_EXISTS,
            data: value
        });
    }

    // 返却されたエラーコードが、受付可否チェック検出対象かを確認する。
    public isHostError(errorCode: string): boolean {
        return (Object.keys(HostErrorCodeReceptionNG).some((key) => HostErrorCodeReceptionNG[key] === errorCode));
    }
}
