/**
 * select account type info from scan qrcode or reception menu.
 */
export interface ChatFlowInfoInterface {
    /** 来店目的 */
    purpose: string;
    /** 選択業務 */
    selectedFlow: string;
    /** Root遷移フラグ */
    root: boolean;
    /** 該当業務名称 */
    component: any;
    /** 0: スワイプなし, 1: スワイプあり, 2: 両方 */
    swipecif: string;
    /** 口座タイプ */
    accountType: string;
    /** 口座タイプタイトル */
    accountTypeText: string;
    /** 申込業務区分 */
    applyBusinessType: string;
    /** 行員認証画面 */
    confirmPage: any;
    /** 行員認証Sub画面 */
    confirmPageSub?: any;
    /** パラメータ */
    params?: any;
    /** 該当業務のページインデックス */
    pageIndex?: number;
    /** 本人確認チャット */
    checkComponent?: string;
    /** 本人確認チャット(代理人) */
    checkComponentSub?: string;
}
