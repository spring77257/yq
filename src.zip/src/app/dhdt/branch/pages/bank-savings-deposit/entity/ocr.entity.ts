import { JsonProperty } from 'adep/json';

export class OCREntity {
    public firstName: string;
    public lastName: string;
    public birthdayEng: string;
    public birthdayAge: string;
    public birthdayJap: string;
    public firstNameKana: string;
    public lastNameKana: string;
    public maskImg: string;
    public prefecture: string;
    public countyUrbanVillage: string;
    public street: string;
    public houseNumber: string;
    public prefectureKana: string;
    public countyUrbanVillageKana: string;
    public streetKana: string;
    public houseNumberKana: string;
    public postalNumber: string;
    public streetWork: string;
    public showStreet: string;
    public dueDate: string;
    public dueDateWareki: string;
}
