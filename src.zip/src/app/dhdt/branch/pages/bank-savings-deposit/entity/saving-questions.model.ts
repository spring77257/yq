import { JsonProperty } from 'adep/json';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import {
    ReceptionCheckAccountInfo
} from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-response.entity';

class ValidationRules {
    public min: { value: number } | string;
    public max: { value: number } | string;
    public required: { value: boolean };
}

export class SavingQuestionsModel {
    public order: number;
    public next: number;
    public type: string;
    public question: string;
    public example: string;
    public choices: any[];
    public name: string;
    public options: any;
    @JsonProperty({ clazz: ValidationRules })
    public validationRules: ValidationRules;
    public skip: number;
    public option: string;
    public other: any;
    public fullwidthHalfwidthDivisionCode: any;
    public answer: any;
}

export class PageQuestionsModel {
    public order: number;
    public next: number;
    public type: string;
    public example: string;
    public choices: any[];
    @JsonProperty({ clazz: ValidationRules })
    public validationRules: ValidationRules;
    public question: string;
    public name: string;
    public answer: { order: number, text: string, value: any };
    public pageIndex: number;
    public skip: number;
    public orderIndex: number;
}

export class SubmitEntity {
    [key: string]: any;

    public hasLicense: string;
    public hasConfirmFile: string;
    public addressDiffrentReason: string;
    public holderName: string;
    public holderNameFurikana: string;
    public firstName: string;
    public lastName: string;
    public holderGender: string;
    // public holderName: string;

    public isOCR: string;
    public remainingPeriod: string;

    // 本人確認種類
    public identificationCode: string;
    public bakupNotMaskingConfirmImages: any; // BC複合用マスキング未完了オブジェクトバックアップ

    // 職業選択（米軍）
    public isUSArmy: string;

    // お勤め先名称
    public isWorkPlaceCheck: string;
    // 通学先名称
    public isSchoolNameCheck: string;
    // 年齢
    public holderAgeFlag: string;

    // 国籍-本店所在地
    public nationalityCode: string;

    public sign: any;
    public category: number;
    public agentIdentificationDocument1: string;
    public agentIdentificationDocument1Text: string;
    public agentIdentificationDocument2Text: string;
    public isSsnWrite: string;
    public isSsnHave: string;

    public publishFlag: string;
    public identificationDocument1: string;
    public identificationDocument2: string;
    public identificationPattern: string;

    public identificationDocument1Images: string[];
    public identificationDocument2Images: string[];
    public identificationAddressImages: string[];

    public isDifferenceKanji: string;

    public firstNameKana: string;
    public lastNameKana: string;

    public firstNameAlphabet: string;
    public lastNameAlphabet: string;

    public firstNameKanji: string;
    public lastNameKanji: string;
    // public holderNameFuriKana: string;

    public holderBirthdate: string;
    public holderBirthdateOCR: string;
    public holderBirthdateText: string;

    public firstZipCode: string;
    public lastZipCode: string;
    public holderZipCode: string;
    public zipCode: string;

    public occBusiness: string;
    public gender: string;
    public subAddress: string;
    public subAddressKana: string;
    public countyUrbanVillage: string;
    public prefecture: string;
    public holderAddressPrefecture: string;
    public holderAddressPrefectureFuriKana: string;
    public holderAddressCountyUrbanVillage: string;
    public holderAddressCountyUrbanVillageFuriKana: string;
    public holderIdentityDocumentAddressReason: string;
    public holderIdentityDocumentPhotographType: string;
    public holderIdentityDocumentAddressType: string;
    public holderIdentityDocumentNoCopyReason: string;
    public holderIdentityDocumentType: string;
    public holderIdentityDocumentTypeFiller: string;
    public holderNoCopyReason: string;
    public holderPublisher: string;
    public holderPublishDate: string;
    public holderSignNo: string;
    public holderCardImageFront: string;
    public holderCardImageBack: string;
    public branchNo: string;
    public bankNo: string;
    public branchNameKanji: string;

    public holderAddressStreetNameSelect: string;
    public holderAddressStreetNameInput: string;
    // public holderAddressStreetName: string;

    public holderAddressStreetNameFuriKanaSelect: string;
    public holderAddressStreetNameFuriKanaInput: string;
    // public holderAddressStreetNameFuriKana: string;

    public holderAddressHouseNumber: string;
    public holderAddressHouseNumberFuriKana: string;
    public firstMobileNo: string;
    public secondMobileNo: string;
    public thirdMobileNo: string;
    public firstTel: string;
    public secondTel: string;
    public thirdTel: string;
    public holderCareer: string;
    public holderCareerOtherDetail: string;
    public holderWorkPlace: string;
    public holderRemoteAddressReason: string;
    public accountType: string;
    public accountTypeText: string;
    public cardDesign: string;
    public cardDesignImageSrc: string;
    public pointServiceExpectation: string;
    public directApplyExpectation: string;
    public cardPassword: string;
    public confirmPassword: string;
    public receiptMethod: string;
    public holderIdentityDocumentPublisher: string;
    public holderIdentityDocumentPublishDate: string;
    public holderIdentityDocumentSignNo: string;
    public passbookType: string;
    public firstPwd4bits: string;
    public firstPwd6bits: string;
    public passbookPrintMessage: string;
    public accountOpeningPurposeLivingExpenses: string;
    public accountOpeningPurposeBusinessExpenses: string;
    public accountOpeningPurposeSalary: string;
    public accountOpeningPurposeSavings: string;
    public accountOpeningPurposeLoan: string;
    public accountOpeningPurposeOverseasRemittance: string;
    public accountOpeningPurposeTrade: string;
    public accountOpeningPurposeOther: string;
    public accountOpeningPurposeOtherDetail: string;
    public agencyBranchNo: string;
    public accountOpeningBranchNo: string;
    public insertedImagesIds: string[];

    public isAgent: string;
    public agentHasConfirmFile: string;
    public relationship: string;
    public cantComeReason: string;
    public isCohabitation: string;
    public leaveType: string;
    public bankCardFlag: string;
    public bankCardGoldFlag: string;
    public bankCardSuicaFlag: string;

    // 代理人に関するそのた情報
    public agentCardImageFront: string;
    public agentCardImageBack: string;
    public agentHasLicense: string;
    // 代理人認証情報
    public agentFirstName: string;
    public agentLastName: string;
    public agentFirstNameKana: string;
    public agentLastNameKana: string;
    // 代理人基本情報
    public agentBirthdate: string;
    public agentBirthdateText: string;
    public agentBirthdateOCR: string;
    public agentName: string;
    public agentNameFurikana: string;
    public agentZipCode: string;
    public agentAddressPrefecture: string;
    public agentAddressCountyUrbanVillage: string;
    public agentAddressStreet: string;
    public agentAddressHouseNumber: string;
    public agentAddressPrefectureFurigana: string;
    public agentAddressCountyUrbanVillageFurigana: string;
    public agentAddressStreetFurigana: string;
    public agentAddressHouseNumberFurigana: string;
    public agentHolderRelationship: string;
    public addressConfirmationDocumentName: string;

    public agentHolderIsCohabited: string;
    // 代理人認証情報
    public agentNoVisitingReason: string;
    public agentIdentityDocumentType: string;
    public agentNoCopyReason: string;
    public agentPublisher: string;
    public agentPublishDate: string;
    public agentSignNo: string;
    public agentIdentityDocumentPhotographType: string;
    public agentIdentityDocumentAddressType: string;
    public agentIdentityDocumentNoCopyReason: string;
    public agentIdentityDocumentAddressReason: string;
    public agentIdentityDocumentPublisher: string;
    public agentIdentityDocumentPublishDate: string;
    public agentIdentityDocumentSignNo: string;

    public rqNo: string;
    public customerApplyEndDate: string;
    public bankclerkAuthenticationStartDate: string;
    public bankclerkAuthenticationEndDate: string;
    public bankclerkConfirmDate: string;

    // 相談要、申し込み業務区分
    public applyBusinessType: string;
    // 自動継続方法
    public automicRenewal: string;
    // 預入期間
    public depositPeriodYearMonth: string;
    public creditCardApplyExpectation: string;
    public sealSlipType: string;
    public commonSealStatus: string;
    public cardPublishIsApplied: string;
    public cardType: string;
    public status: string;
    public tabletApplyId: string;
    public userMngNo: string;
    public principalAgentCategory: string;
    public pensionType: string;

    // 定期預金の口座開設情報
    // 金額
    public amount: string;
    // 満期日
    public dueDate: string;
    // 利息計算方法
    public interestComputationMethod: string;
    public interestComputationMethodText: string;
    // 利息計算区分
    public interestComputationCategory: string;
    // 中間利息コード
    public intermediateInterestCode: string;
    // 利率コード
    public interestRateCode: string;
    public productConfirm: string;
    public regularPurpos: string;
    public accumlatePurpose: string;
    public amountOfMoney: string;
    public periodOfMoney: string;
    public selectProductType: string;
    public selectProductName: string;

    public specialTransferDate1Text: string;
    public specialTransferDate2Text: string;
    public specialTransferDate1: string;
    public specialTransferDate2: string;

    public childrenName: string;
    public childrenNameFurikana: string;
    public childrenFirstName: string;
    public childrenLastName: string;
    public childrenGender: string;
    public childrenFirstNamegana: string;
    public childrenLastNamegana: string;
    public childrenBirthdate: string;
    public childrenBirthdateText: string;
    public regionCode?: string;

    public childrenNumbersFlag: string; // お子様－続柄 flag

    public files: any[];

    // 既存CIFへの紐づけ
    public existingAccount: any;

    // 定期解約用変数追加
    public cancelableList: Array<{
        // 口座番号
        accountNo: string;
        // 預金金額
        amount: string;
        // 支店名
        branchName: string;
        // 満期日
        dueDate: string;
        // 商品名
        item: string;
        // 商品種別
        itemDetail: string;
        // 固有番号
        ownNo: string;
        // 利率
        rate: string;
        // 預入日
        startDate: string;
        // 期間
        term: string;
        // 解約対象か否かのチェック用
        id: boolean;
        // 一部か全部か
        method: boolean;
        // `解約希望金額
        cancelAmount: string;
        // 解約対象商品数、リストの上から昇順
        count: number;
    }>;

    // MVP2 Cash-card added@2018/07/03
    public businessType: string;                // 1、2、3、4
    public businessTypeText: string;            // 初めて発行、カード暗証番号忘れ、カード破損・磁気不良、カード紛失・盗難
    public cashCardType: string;                // 0、1、2
    public cashCardTypeText: string;            // 本人カードのみ、本人カード＋家族用カード、家族用カードのみ
    public cashCardHasConfirmFile: string;      // 本人確認書類を持っているか
    public cashCardNameFurikana: string;        // 口座名義人のカナ氏名
    public cashCardFirstNameKana: string;       // 口座名義人のFirstカナ氏名
    public cashCardLastNameKana: string;        // 口座名義人のLastカナ氏名
    // public cashCardBranchNameKanji: String;     // 口座のお取引店
    public cashCardBranchNo: string;            // 口座番号
    public cashCardDesign: string;              // 本人カードデザイン
    public cashCardPassword: string;            // 本人カードPassword
    public cashCardFirstPwd4bits: string;       // 本人カードPassword
    public cashCardFamilyName: string;          // 家族のおなまえ
    public cashCardFamilyFirstName: string;     // 家族のおなまえFirstName
    public cashCardFamilyLastName: string;      // 家族のおなまえLastName
    public cashCardFamilyNameFurikana: string;  // 家族のカナ氏名
    public cashCardFamilyFirstNameKana: string; // 家族のFirstカナ氏名
    public cashCardFamilyLastNameKana: string;  // 家族のLastカナ氏名
    public cashCardFamilyType: string;          // 家族関係:1(配偶者) 2(配偶者配偶者以外)
    public cashCardFamilyDesign: string;        // 家族カードデザイン
    public cashCardFamilyPassword: string;      // 家族カードPassword
    public cashCardFamilyFirstPwd4bits: string; // 家族カードPassword
    public cashCardReceiptMethod: string;       // キャッシュカードReceiptMethod
    public cashCardFamilyReceiptMethod: string; // 家族カードReceiptMethod
    public cardHolderBirthday: string;          // 生年月日
    // お子様－氏名
    // public  childrenName: String;
    // not null
    // お子様－氏名ー（フリガナ）
    // public  childrenNameFurigana: String;
    // not null
    // お子様－生年月日
    // public  childrenBirthdate: String;
    // not null
    // お子様－性別
    // public  childrenGender: String;
    // not null
    // お子様－続柄
    public childrenRelationship: string;
    // not null
    // お子様－人数
    public childrenNumbers: number;
    // not null
    // お子様－入学予定
    public enrollingSchool: string;
    // not null
    // お子様－入学年
    public enrollingYear: string;
    public enrollingYearText: string;

    // 積立定期口座開設用
    // お積み立て目的
    // @NotNull
    public fundingPurpose: string;
    // 満期日
    // @NotNull
    // public dueDate: String ;
    // 積立金受取方法
    // @NotNull
    public reservedFundReceiptType: string;
    // 初回受取日
    public firstReceiptDate: string;
    // 受取サイクル
    public receiptCycle: string;
    // 受取指定日1
    public receiptDesignatedDate1: string;
    // 追加の受取日2
    public setReceiptDate: string;
    // 受取指定日2
    public receiptDesignatedDate2: string;

    public normalMonthArray: string[];

    // 自動振替要否:自動振替する0、自動振替しない1
    public autoTransfer: string;

    // 口座自動振替情報
    // 口座開設時預入額
    public accountOpeningDepositAmount: number;
    // 自動振替開始日
    public automaticTransferStartDate: string;
    // 通常月ー毎月:選択なし／選択あり
    public monthly: string;
    // 通常月ー１月:選択なし／選択あり
    public normalMonthJan: string;
    // 通常月ー２月:選択なし／選択あり
    public normalMonthFeb: string;
    // 通常月ー３月:選択なし／選択あり
    public normalMonthMar: string;
    // 通常月ー４月:選択なし／選択あり
    public normalMonthApr: string;
    // 通常月ー５月:選択なし／選択あり
    public normalMonthMay: string;
    // 通常月ー６月:選択なし／選択あり
    public normalMonthJun: string;
    // 通常月ー７月:選択なし／選択あり
    public normalMonthJul: string;
    // 通常月ー８月:選択なし／選択あり
    public normalMonthAug: string;
    // 通常月ー９月:選択なし／選択あり
    public normalMonthSep: string;
    // 通常月ー１０月:選択なし／選択あり
    public normalMonthOct: string;
    // 通常月ー１１月:選択なし／選択あり
    public normalMonthNov: string;
    // 通常月ー１２月:選択なし／選択あり
    public normalMonthDec: string;
    // 通常月振替日
    public normalMonthTransferDay: string;
    // 通常月振替額
    public normalMonthTransferAmount: number;
    // 毎月振替日とは別に特定振替日(年2回まで)を設定しますか？ 設定する: '0' /  設定しない: '1'
    public setEveryMonthTransferDate: string;
    // 特定振替月日１
    public specificTransferMonth1: string;
    public specificTransferMonth1Text: string;
    // 特定振替額１
    public specificTransferAmount1: number;
    // 特定振替日(年2回まで)を追加で設定しますか？ 設定する: '0' /  設定しない: '1'
    public setAddEveryMonthTransferDate: string;
    // 特定振替月日２
    public specificTransferMonth2: string;
    public specificTransferMonth2Text: string;
    // 特定振替額２
    public specificTransferAmount2: number;
    // 定期口座タイプ-新型通帳/総合口座
    public timeSavingsAccountType: string;

    // chatFlow変更判定用フラグ
    public changeChatFlowFlg: String;
    // 町丁名（Work）
    public streetWork: String;
    // 町丁名（表示用）
    public showStreet: String;

    public receptionBranchNo: string;           // 受付店番
    public receptionNo: string;                 // 受付番号
    public receptionTime: string;               // 受付年月日時分秒
    public accountNo: string;
    public purpose: string;                     // 来店目的コード
    public swipeBranchNo: string;                // カード店番
    public swipeAccountType: string;             // カード科目
    public swipeAccountNo: string;               // カード口座番号
    public swipeCif: string;                   // 店別CIF

    public tabletStartDate: string;
    public customerApplyStartDate: string;

    public redundantReason: string;     // 重複口座の開設理由
    public hasComprehensive: boolean;   // 総合口座を持っているフラグ

    public cardInfo: any;
    public nameKana: string;
    public birthdate: string;
    public address: string;
    public nameKanji: string;
    public identificationDocument1Text: string;
    public idInfoDoc1Text: string;
    public idInfoDoc2Text: string;
    public identificationDocument2Text: string;
    public agentCountryText: string;
    public workPlaceText: string;
    public schoolNameText: string;
    public subAddressKanaText: string;
    public nameAlphabat: string;
    public storeChangeFlg: string;

    /** スワイプ有無 */
    public hasSwipeCard: boolean;
    /** 来店者が口座名義人であるか */
    public isAccountHolder: string;
    /** 普通預金口座のカード再発行・発見手続きが含まれるか */
    public containsReissueFindingOrdinaryAccountCard: boolean;
    /** 喪失届のみ可能かどうか（各判定で再発行・発見NGとなった場合にフラグを立てる） */
    public canLossReportOnly: boolean;

    public manualNameFurikana: string;
    public manualFirstNameKana: string;
    public manualLastNameKana: string;
    public manualBirthdate: string;

    /** 全店名寄せ照会.顧客検索結果 */
    public customerSearchStatus: string;
    /** 全店名寄せ照会.顧客情報 */
    public allCifInfos: CifInfo[];
    /** 全店名寄せ照会.採番後の支店名リスト */
    public branchNameList: string[];
    /** 全店名寄せ照会.採番後の支店名リスト(+顧客番号) */
    public branchNameListEntity: BranchNameListEntity[];

    /** スワイプなし時に手入力された店番号 */
    public inputBranchNo: string;
    /** スワイプなし時に手入力された科目 */
    public inputAccountType: string;
    /** スワイプなし時に手入力された口座番号 */
    public inputAccountNo: string;
    /** 受付画面 受付可否チェックのエラー表示用 */
    public responseForModal: Array<{customerId: string, accounts: ReceptionCheckAccountInfo}>;

    private _normalMonthValue?: string;

    public set normalMonthValue(value: string) {
        if (value) {
            const array = value.split(',');
            this.monthly = array[0];
            this.normalMonthJan = array[1];
            this.normalMonthFeb = array[2];
            this.normalMonthMar = array[3];
            this.normalMonthApr = array[4];
            this.normalMonthMay = array[5];
            this.normalMonthJun = array[6];
            this.normalMonthJul = array[7];
            this.normalMonthAug = array[8];
            this.normalMonthSep = array[9];
            this.normalMonthOct = array[10];
            this.normalMonthNov = array[11];
            this.normalMonthDec = array[12];
        }
        this._normalMonthValue = value;
    }

    public get normalMonthValue() {
        return this._normalMonthValue;
    }

    public getHolderMobileNo(): string {
        if (!this.firstMobileNo || !this.secondMobileNo || !this.thirdMobileNo) {
            return '';
        }
        return this.firstMobileNo + this.secondMobileNo + this.thirdMobileNo;
    }

    public getHolderTelephoneNo(): string {
        if (!this.firstTel || !this.secondTel || !this.thirdTel) {
            return '';
        }
        return this.firstTel + '-' + this.secondTel + '-' + this.thirdTel;
    }

    public getHolderZipCode(): string {
        return this.firstZipCode + this.lastZipCode;
    }

    public getHolderAddressStreetName(): string {
        if (this.holderAddressStreetNameSelect || this.holderAddressStreetNameInput) {
            return this.holderAddressStreetNameSelect
                ? this.holderAddressStreetNameSelect : this.holderAddressStreetNameInput;
        }

        return '';
    }

    public getHolderAddressStreetNameFuriKana(): string {
        if (this.holderAddressStreetNameFuriKanaSelect || this.holderAddressStreetNameFuriKanaInput) {
            return this.holderAddressStreetNameFuriKanaSelect
                ? this.holderAddressStreetNameFuriKanaSelect : this.holderAddressStreetNameFuriKanaInput;
        }

        return '';
    }

    public getAddressWithoutHouseOcr(): string {
        const prefecture = this.holderAddressPrefecture ? this.holderAddressPrefecture : '';
        const countyUrbanVillage = this.holderAddressCountyUrbanVillage ? this.holderAddressCountyUrbanVillage : '';
        const streetName = this.getHolderAddressStreetName();

        return prefecture + countyUrbanVillage + streetName;
    }

    public getAddressOcr(): string {
        const prefecture = this.holderAddressPrefecture ? this.holderAddressPrefecture : '';
        const countyUrbanVillage = this.holderAddressCountyUrbanVillage ? this.holderAddressCountyUrbanVillage : '';
        const streetName = this.showStreet ? this.showStreet : '';
        const houseNumber = this.holderAddressHouseNumber ? this.holderAddressHouseNumber : '';
        return prefecture + countyUrbanVillage + streetName + houseNumber;
    }
}

export class DropDownListEntity {
    public key: string;
    public value: string;
    public filler1: string;
    public filler2: string;
    public filler3: string;
    public filler5: string;
}

export class CheckboxStatusEntity {
    public receiptMethodStatus: boolean;  // カードお受取方法 checkbox
    public confirmationStatus: boolean;  // 契約状況確認
    public isAntisocialStatus: boolean;  // 反社会的勢力
    public isForeignPulicFiguresSatus: boolean;  // 外国の重要な公的地位にある者
    public isJapaneseResidentStatus: boolean;  // 日本居住者です
    public isRegulationStatus: boolean;
    public isAllMaskingStatus: boolean; // 写真マスキング
    public isAgentAllMaskingStatus: boolean; // 代理人写真マスキング
    public isCheckBranchStatus: boolean; // 開設店舗確認
}

/**
 * 全店名寄せ照会で取得した支店名を保持する。
 * 店舗が重複する場合、末尾に番号が付与される。(例：横浜駅前支店１)
 */
export class BranchNameListEntity {
    public branchName: string;
    public customerId: string;
}
