import { JsonProperty } from 'adep/json';

export class BranchEntity {
    public prefectureKanji: string;
    public countyUrbanVillageKanji: string;
    public streetKanji: string;
    public prefectureKana: string;
    public countyUrbanVillageKana: string;
    public streetKana: string;
    public code: string;
}

export class TownEntity {
    public branchName: string;
    public branchCode: string;
}
