export class OrdinarySavingAccountOpeningApplyParmsEntity {
    // タブレット申込管理ID
    public tabletApplyId: string;
    // 口座開設の取引目的
    public accountOpeningPurpose: string;
    // 口座開設の取引目的ー生活費決済
    public accountOpeningPurposeLivingExpenses: string;
    // 口座開設の取引目的ー事業費決済
    public accountOpeningPurposeBusinessExpenses: string;
    // 口座開設の取引目的ー給与・年金受取
    public accountOpeningPurposeSalary: string;
    // 口座開設の取引目的ー貯蓄・資産運用
    public accountOpeningPurposeSavings: string;
    // 口座開設の取引目的ー融資
    public accountOpeningPurposeLoan: string;
    // 口座開設の取引目的ー外国送金
    public accountOpeningPurposeOverseasRemittance: string;
    // 口座開設の取引目的ー貿易取引
    public accountOpeningPurposeTrade: string;
    // 口座開設の取引目的ーその他
    public accountOpeningPurposeOther: string;
    // 口座開設の取引目的ーその他詳細
    public accountOpeningPurposeOtherDetail: string;
    // 口座開設店番
    public branchNo: string;
    // カードデザイン
    public cardDesign: string;
    public pointServiceExpectation: string;
    // ダイレクト(インターネットバンキング)申込希望
    public directApplyExpectation: string;
    // 通帳種類
    public passbookType: string;
    // 通帳印刷メッセージ
    public passbookPrintMessage: string;
    // 金額
    public amount: string;
    // クレジットカード申込希望
    public creditCardApplyExpectation: string;
    // 印鑑票種別
    public sealSlipType: string;
    // 共通印提出ステータス
    public commonSealStatus: string;
    // カード発行申込有無
    public cardPublishIsApplied: string;
    // カード種類
    public cardType: string;
    // RQ番号
    public rqNo: string;
    // ステータス
    public status: string;
    // 行員ID
    public userMngNo: string;
    // お受取方法
    public receiptMethod: string;
}
