/**
 * QRコード受付情報Entity
 */
export class ReceptionInfoEntity {
    // 受付店番
    public receptionBranchNo: string;

    // 受付番号
    public receptionNo: string;

    // 受付年月日時分秒
    public receptionTime: string;

    // 来店目的コード
    public purpose: string;

    // カード店番
    public cardBranchNo: string;

    // カード科目
    public cardAccountType: string;

    // カード口座番号
    public cardAccountNo: string;

    // 店別CIF
    public branchCif: string;

    /**
     * 受付情報へセット
     * @param result 複合化後のQRコード情報
     */
    public setReceptionInfo(result: string[]) {
        if (result && result.length > 0) {
            this.receptionBranchNo = result[0];
            this.receptionNo = result[1];
            this.receptionTime = result[2];
            this.purpose = result[3];
            this.cardBranchNo = result[4];
            this.cardAccountType = result[5];
            this.cardAccountNo = result[6];
            this.branchCif = result[7];
        }
    }
}
