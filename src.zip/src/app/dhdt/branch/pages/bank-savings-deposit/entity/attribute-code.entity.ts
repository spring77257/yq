export class AttributeCodeEntity {
    /**
     * コードID。
     */
    public codeId: string;

    /**
     * カテゴリコード。
     */
    public categoryCode: string;

    /**
     * カテゴリ名(論理）。
     */
    public categoryNameLogic: string;

    /**
     * カテゴリ名(物理)。
     */
    public categoryNamePhysics: string;

    /**
     * コード値。
     */
    public codeValue: string;

    /**
     * データ。
     */
    public data: string;

    /**
     * filler1。
     */
    public filler1: string;

    /**
     * filler2。
     */
    public filler2: string;

    /**
     * filler3。
     */
    public filler3: string;
}
