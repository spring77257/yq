import { CurrencyPipe } from '@angular/common';
import { NgModule, Type } from '@angular/core';
import { HttpModule } from '@angular/http';
import { CommonBusinessModule } from 'dhdt/branch/pages/common-business/common-business.module';
import { LoginModule } from 'dhdt/branch/pages/common/login/login.module';
import { TopModule } from 'dhdt/branch/pages/common/top/top.module';
import { ExistingReserveAction } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { ExistingReserveChatComponent } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat.component';
import { ExistingReserveConfirmChatComponent } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-confirm-chat.component';
import { ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { ExistingRegularConfirmComponent } from 'dhdt/branch/pages/existing-reserve/view/existing-regular-confirm.component';
import { ExistingRegularInitConfirmComponent } from 'dhdt/branch/pages/existing-reserve/view/existing-regular-initconfirm.component';
import {
    ExistingReserveClerkConfirmationComponent
} from 'dhdt/branch/pages/existing-reserve/view/existing-reserve-clerk-confirmation.component';
import {
    ExistingReserveSelfConfirmationComponent
} from 'dhdt/branch/pages/existing-reserve/view/existing-reserve-self-confirmation.component';
import { AccountShopModule } from 'dhdt/branch/shared/components/account-shop/account-shop.module';
import { AddressModule } from 'dhdt/branch/shared/components/address/address.module';
import { BranchModule } from 'dhdt/branch/shared/components/branch/branch.module';
import { ConfirmPageCommonModule } from 'dhdt/branch/shared/components/confirmpage-common/confirmpage.common.module';
import { PickerModule } from 'dhdt/branch/shared/components/picker/picker.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';

@NgModule({
    imports: [
        LoginModule,
        TopModule,
        IonicModule,
        SharedModule,
        AddressModule,
        BranchModule,
        HttpModule,
        PickerModule,
        AccountShopModule,
        ConfirmPageCommonModule,
        CommonBusinessModule
    ],
    declarations: [
        ExistingReserveChatComponent,
        ExistingReserveSelfConfirmationComponent,
        ExistingReserveClerkConfirmationComponent,
        ExistingRegularInitConfirmComponent,
        ExistingRegularConfirmComponent,
        ExistingReserveConfirmChatComponent
    ],
    exports: [
        TopModule,
        ExistingReserveChatComponent,
        ExistingReserveConfirmChatComponent
    ],
    entryComponents: [
        ExistingReserveChatComponent,
        ExistingReserveSelfConfirmationComponent,
        ExistingReserveClerkConfirmationComponent,
        ExistingRegularInitConfirmComponent,
        ExistingRegularConfirmComponent,
        ExistingReserveConfirmChatComponent
    ],
    providers: [
        CurrencyPipe,
        ExistingReserveAction,
        ExistingReserveStore,
    ]
})
export class ExistingReserveModule {
}
