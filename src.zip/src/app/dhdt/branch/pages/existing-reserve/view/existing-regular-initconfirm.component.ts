import { Component, NgZone, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { CompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/completion.component';
import {
    DirectApplyExpectation,
    IdentificationCode, SsnHave, SsnWrite
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingReserveAction } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { ExistingReserveConfirmPageCommonService
 } from 'dhdt/branch/pages/existing-reserve/service/existing-reserve-confirmpage.common.service';
import { ExistingReserveState, ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ModalController, NavController } from 'ionic-angular';

/**
 * 申込内容確認（定期）
 */
@Component({
    selector: 'existing-regular-initconfirm-component',
    templateUrl: 'existing-regular-initconfirm.component.html'
})
export class ExistingRegularInitConfirmComponent extends BaseComponent implements OnInit {
    public state: ExistingReserveState;
    public saveShowChats: any = {};
    public passwordValid: boolean = true;
    public confirmPageCommonParams: Map<string, any> = null;
    public changeConfirmPageParams: Map<string, any> = null;
    public confirmPageCareerParams: Map<string, any> = null;
    public changeHolderMobileNoFlag: boolean = false;
    public isCareerShow: boolean = false;
    public isSignShow: boolean = false;
    public isW9Show: boolean = false;
    public isFatcaShow: boolean = false;

    constructor(
        private action: ExistingReserveAction,
        private store: ExistingReserveStore,
        private modalCtrl: ModalController,
        private navCtrl: NavController,
        private logging: LoggingService,
        private rsaEncryptService: RsaEncryptService,
        private loginStore: LoginStore,
        private zone: NgZone,
        private confirmPageService: ExistingReserveConfirmPageCommonService,
        private savingStore: SavingsStore
    ) {
        super();
        this.state = this.store.getState();
    }

    public ngOnInit() {
        this.state.showConfirm.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });

        this.confirmPageService.loadConfirmTemplate();
        this.confirmPageCareerParams = this.confirmPageService.getHolderCareerParams();
        this.action.setEditNameKanji();
        this.isCareerShow = this.state.submitData.identificationCode !== IdentificationCode.CODE_80;
        this.isSignShow = this.state.submitData.identificationCode === IdentificationCode.CODE_99;
        this.isW9Show = this.state.submitData.isSsnWrite === SsnWrite.YES;
        this.isFatcaShow = this.state.submitData.isSsnHave === SsnHave.NO || this.state.submitData.isTaxForAmerican === SsnHave.NO;
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.zone.run(() => this.action.modifyCheckboxStatus(checboxItem));
    }

    /**
     * footer button disable
     */
    public get disableFooterButton() {
        const checkboxTotalValid = this.checkboxValid();
        const passwordValid = this.passwordValid;
        return checkboxTotalValid && passwordValid;
    }

    public onModifying(data) {
        this.action.setStateSubmitDataValue(Object.keys(data).map((key) => {
            return {
                key,
                value: data[key]
            };
        }));
    }

    /**
     * click 'お申込み' button
     */
    public moveToNextPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo[0].screenId,
            this.labels.logging.InfoComfirm.ApplyButton,
        );

        const modal = this.modalCtrl.create(ModalPasswordComponent,
            {
                data: {
                    text: this.labels.password.inputPasswordAgainText,
                    subText: this.labels.password.inputPasswordAgainSubText,
                    units: 4,
                    needConfirm: false,
                    validation: (password) => this.action.cardIinfoCheck({
                        tabletApplyId: this.state.submitData.tabletApplyId, // タブレット申込管理ID
                        params: {
                            receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                            tenban: this.state.submitData.cardInfo.branchNo, // 店番
                            accountType: this.state.submitData.cardInfo.accountType, // 科目
                            accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                            icCardInfo: this.savingStore.getState().icData,  // カード情報を入れる
                            passcode: this.rsaEncryptService.encrypt(password)  // 暗証番号
                        }
                    })
                }
            },
            { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.onDidDismiss((value) => {
            if (value && value.result) {
                this.action.setCustomerApplyEndDate();
                this.navCtrl.push(CompletionComponent);
            }
        });
        modal.present();
    }

    /**
     * 変更項目を設定
     * @param data 変更項目
     */
    public handleItemChangedEmitter(data) {
        this.action.setStateSubmitData({
            ...data,
            holderName: data.holderName || data.holderNameKanji
        });
        this.state.showConfirm.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
    }

    public get isNoteMessageHide(): boolean {
        return !this.state.checkboxStatus.isAntisocialStatus &&
        this.state.checkboxStatus.isJapaneseResidentStatus &&
        this.state.checkboxStatus.isRegulationStatus &&
        (this.isCareerShow ? !this.state.checkboxStatus.isForeignPulicFiguresSatus : true);
    }

    public onChangeProduct(data) {
        this.action.setStateSubmitDataValue(data);
    }

    public refsState() {
        this.state.showConfirm.forEach((item) => {
            if (item.type !== 'judge') {
                this.saveShowChats[item.name] = item;
            }
        });
    }

    /**
     * show checkbox valid
     */
    private checkboxValid(): boolean {
        const preconditionsOK = this.isNoteMessageHide;

        const confirmationCheckedOK = this.state.submitData.directApplyExpectation === DirectApplyExpectation.APPLY
                && this.state.submitData.showDirectApply ?
            this.state.checkboxStatus.confirmationStatus : true;
        const checkboxTotalValid = confirmationCheckedOK && preconditionsOK;
        return checkboxTotalValid;
    }

}
