import { Component, NgZone, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { ConfirmPageCommonService } from 'dhdt/branch/pages/bank-savings-deposit/service/confirmpage.common.service';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { CompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/completion.component';
import { DirectApplyExpectation, IdentificationCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingReserveAction } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { ExistingReserveConfirmPageCommonService
 } from 'dhdt/branch/pages/existing-reserve/service/existing-reserve-confirmpage.common.service';
import { ExistingReserveState, ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ModalController, NavController } from 'ionic-angular';

@Component({
    selector: 'existing-reserve-self-confirmation',
    templateUrl: './existing-reserve-self-confirmation.component.html'
})
/**
 * 定期預金(積立)_本人確認画面
 */
export class ExistingReserveSelfConfirmationComponent extends BaseComponent implements OnInit {

    public state: ExistingReserveState;
    public confirmPageCommonParams: Map<string, any> = null;
    public confirmPageCareerParams: Map<string, any> = null;
    public saveShowChats: any = {};
    public changeHolderMobileNoFlag: boolean = false;
    public isW9Show: boolean = false;
    public isFatcaShow: boolean = false;
    public isCareerShow: boolean = false;
    public passwordValid: boolean = true;

    constructor(
        private action: ExistingReserveAction,
        private store: ExistingReserveStore,
        private loginStore: LoginStore,
        private logging: LoggingService,
        private rsaEncryptService: RsaEncryptService,
        private confirmPageCommonService: ConfirmPageCommonService,
        private modalCtrl: ModalController,
        private navCtrl: NavController,
        private confirmPageService: ExistingReserveConfirmPageCommonService,
        private zone: NgZone,
        private savingStore: SavingsStore
    ) {
        super();
        this.state = this.store.getState();
    }

    public ngOnInit() {
        this.confirmPageCommonService.loadConfirmTemplate();
        this.confirmPageCommonParams = this.confirmPageCommonService.getShowChatParams();
        this.confirmPageCareerParams = this.confirmPageService.getHolderCareerParams();
        this.state.showConfirm.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });

        this.isCareerShow = this.state.submitData.identificationCode !== IdentificationCode.CODE_80;
        this.isW9Show = this.state.submitData.identificationCode === IdentificationCode.CODE_99 && this.state.submitData.isSsnWrite === '1';
        this.isFatcaShow =  this.state.submitData.identificationCode === IdentificationCode.CODE_99
             && (this.state.submitData.isSsnHave === '2' || this.state.submitData.isTaxForAmerican === '2');
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.zone.run(() => this.action.modifyCheckboxStatus(checboxItem));
    }

    /**
     * 変更項目を設定
     * @param data 変更項目
     */
    public handleItemChangedEmitter(data) {
        this.action.setStateSubmitData({
            ...data,
            holderName: data.holderName || data.holderNameKanji
        });
        this.state.showConfirm.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
    }

    public refsState() {
        this.state.showConfirm.forEach((item) => {
            if (item.type !== 'judge') {
                this.saveShowChats[item.name] = item;
            }
        });
    }

    public get isNoteMessageHide(): boolean {
        return !this.state.checkboxStatus.isAntisocialStatus &&
        this.state.checkboxStatus.isJapaneseResidentStatus &&
        this.state.checkboxStatus.isRegulationStatus &&
        (this.isCareerShow ? !this.state.checkboxStatus.isForeignPulicFiguresSatus : true);
    }

    public onModifying(data) {
        this.action.setStateSubmitDataValue(Object.keys(data).map((key) => {
            return {
                key,
                value: data[key]
            };
        }));
    }

    /**
     * footer button disable
     */
    public get disableFooterButton() {
        const checkboxTotalValid = this.checkboxValid();
        const passwordValid = this.passwordValid;
        return checkboxTotalValid && passwordValid;
    }

    public moveToNextPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo[0].screenId,
            this.labels.logging.InfoComfirm.ApplyButton,
        );

        const modal = this.modalCtrl.create(ModalPasswordComponent,
            {
                data: {
                    text: this.labels.password.inputPasswordAgainText,
                    subText: this.labels.password.inputPasswordAgainSubText,
                    units: 4,
                    needConfirm: false,
                    validation: (password) => this.action.cardIinfoCheck({
                        tabletApplyId: this.state.submitData.tabletApplyId, // タブレット申込管理ID
                        params: {
                            receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                            tenban: this.state.submitData.cardInfo.branchNo, // 店番
                            accountType: this.state.submitData.cardInfo.accountType, // 科目
                            accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                            icCardInfo: this.savingStore.getState().icData,  // カード情報を入れる
                            passcode: this.rsaEncryptService.encrypt(password)  // 暗証番号
                        }
                    })
                }
            },
            { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.onDidDismiss((value) => {
            if (value && value.result) {
                this.action.setCustomerApplyEndDate();
                this.navCtrl.push(CompletionComponent);
            }
        });
        modal.present();
    }

    /**
     * show checkbox valid
     */
    public checkboxValid(): boolean {
        const preconditionsOK = this.isNoteMessageHide;

        const confirmationCheckedOK = this.state.submitData.directApplyExpectation === DirectApplyExpectation.APPLY
                && this.state.submitData.showDirectApply ?
            this.state.checkboxStatus.confirmationStatus : true;
        const checkboxTotalValid = confirmationCheckedOK && preconditionsOK;
        return checkboxTotalValid;
    }

}
