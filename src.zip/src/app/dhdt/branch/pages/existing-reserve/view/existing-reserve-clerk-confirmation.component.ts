import { Component, NgZone, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { LabelService } from 'adep/services';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { ConfirmPageCommonService } from 'dhdt/branch/pages/bank-savings-deposit/service/confirmpage.common.service';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CommonBusinessType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessChatComponent } from 'dhdt/branch/pages/common-business/view/common-business-chat.component';
import {
    ClearSavingImagesClickRecordType, COMMON_CONSTANTS,
    HostResultCode,
    IdentificationDocumentCode, IdentificationDocumentMethod, LicensePhotoType, MaskingCheckboxName
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ExistingReserveAction } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { ExistingReserveChatComponent } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat.component';
import { ExistingReserveSubmitEntity } from 'dhdt/branch/pages/existing-reserve/entity/existing-reserve-questions.model';
import {
    ExistingReserveSignal, ExistingReserveState, ExistingReserveStore
} from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import {
    ExistingReserveSelfConfirmationComponent
} from 'dhdt/branch/pages/existing-reserve/view/existing-reserve-self-confirmation.component';
import { IdentityDocumentConfirmComponent } from 'dhdt/branch/shared/components/confirmpage-common/identity-document-confirm.component';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ConfirmUtil } from 'dhdt/branch/shared/utils/confirm-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController } from 'ionic-angular';

@Component({
    selector: 'existing-reserve-clerk-confirmation',
    templateUrl: './existing-reserve-clerk-confirmation.component.html'
})
/**
 * 定期預金(積立)_行員確認画面
 */
export class ExistingReserveClerkConfirmationComponent extends BaseComponent implements OnInit {

    public state: ExistingReserveState;
    public confirmPageCommonParams: Map<string, any> = null;
    public saveShowChats: any = {};
    public changeHolderMobileNoFlag: boolean = false;
    public isW9Show: boolean = false;
    public isFatcaShow: boolean = false;
    // 本人確認を表示かどうか
    public isIdenticationShow: boolean = false;
    public isCareerShow: boolean = false;
    public isClerkConfirm: boolean = true;
    public passwordValid: boolean = true;
    public submitted: boolean = false;
    public isBackToCustomerConfirmPage = false;
    private originSubmitData: any;

    @ViewChild(IdentityDocumentConfirmComponent)
    private identityDocumentConfirmComponent: IdentityDocumentConfirmComponent;

    constructor(
        private action: ExistingReserveAction,
        private store: ExistingReserveStore,
        private savingsAction: SavingsAction,
        private cancelAction: CancelAction,
        private confirmPageCommonService: ConfirmPageCommonService,
        private modalCtrl: ModalController,
        private modalService: ModalService,
        private navCtrl: NavController,
        private logging: LoggingService,
        public loginStore: LoginStore,
        public confirmUtil: ConfirmUtil,
        private zone: NgZone,
        private labelService: LabelService,
        private errorMessageService: ErrorMessageService
    ) {
        super();
        this.state = this.store.getState();
        this.originSubmitData = Object.assign(new ExistingReserveSubmitEntity(), this.state.submitData);
    }

    public ngOnInit() {
        console.log('===AAA===ExistingReserveClerkConfirmationComponent');
        this.confirmPageCommonService.loadConfirmTemplate();
        this.confirmPageCommonParams = this.confirmPageCommonService.getShowChatParams();
        this.state.showConfirm.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
        this.isIdenticationShow = this.state.submitData.identificationCode !== '80' && this.state.submitData.identificationCode !== '90';
        this.isCareerShow = this.state.submitData.identificationCode !== '80';
        this.isW9Show = this.state.submitData.identificationCode === '99' && this.state.submitData.isSsnWrite === '1';
        this.isFatcaShow = this.state.submitData.identificationCode === '99'
            && (this.state.submitData.isSsnHave === '2' || this.state.submitData.isTaxForAmerican === '2');
        this.action.submitDataBackup();
    }

    public get headerTitle(): string {
        return this.labels.confirmationPage.title.existingReserve;
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.zone.run(() => this.action.modifyCheckboxStatus(checboxItem));
    }

    public changeHolderMobileNoEmitter(value) {
        this.changeHolderMobileNoFlag = value;
    }

    public onChangeReceptionNumber(data) {
        this.action.setStateSubmitDataValue(data);
        this.action.updateSubmitDataBackup(data);
    }

    /**
     * 郵便番号 emitter
     */
    public changePostSkipEmitterHandler() {
        // this.getHolderZipCode();
    }

    public get isNoteMessageHide(): boolean {
        return !this.state.checkboxStatus.isAntisocialStatus &&
            this.state.checkboxStatus.isJapaneseResidentStatus &&
            this.state.checkboxStatus.isRegulationStatus &&
            (this.isCareerShow ? !this.state.checkboxStatus.isForeignPulicFiguresSatus : true);
    }

    /**
     * password valid
     * @param passwordValid  password valid result
     */
    public passwordEmmiterHandler(passwordValid: boolean) {
        this.passwordValid = passwordValid;
    }

    /**
     * 入力チェック結果を返す
     */
    public get disableFooterButton(): boolean {
        // 認証ボタンは非活性の条件
        // 受付番号未登録　まだ　本人確認コンポネンがあるかつマスキングチェックボックス存在かつチェックしない
        return !this.state.submitData.receptionNumber
            || (this.identityDocumentConfirmComponent &&
                this.identityDocumentConfirmComponent.isShowCheckboxBlock() && !this.state.checkboxStatus.isAllMaskingStatus);
    }

    /**
     * データをサブミットする
     */
    public submit() {
        if (this.state.submitData.holderTelNo1 === null && this.state.submitData.holderTelNo2 === null
            && this.state.submitData.holderTelNo3 === null) {
            const buttonList = [
                { text: this.labels.common.dialog.ok, buttonValue: 'ok' }
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.registerPhone,
                buttonList,
                (item) => {
                    if (item.buttonValue === 'ok') {
                        this.saveSubmit();
                    }
                },
                null
            );
        } else {
            this.saveSubmit();
        }

        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo[0].screenId,
            this.labels.logging.AccountConfirm.confirmButton,
        );
    }

    /**
     * ボタンを押下するとAPI呼び出しを行う。
     */
    public saveSubmit() {
        this.submitted = true;
        this.store.registerSignalHandler(ExistingReserveSignal.SUCCESS_INSERT_INFO, (result) => {
            this.store.unregisterSignalHandler(ExistingReserveSignal.SUCCESS_INSERT_INFO);
            if (result.resultCode === HostResultCode.SUCCESS) {
                this.modalService.showCompleteModal().subscribe({
                    next: (event) => {
                        switch (event) {
                            case COMMON_CONSTANTS.BACK_TYPE_REAPPLY_MENU:
                                this.navCtrl.setRoot(ChatComponent, { reapplyFlg: true });
                                break;
                            default:
                                this.navCtrl.setRoot(TopComponent);
                        }
                    },
                    complete: () => {
                        this.action.clearStore();
                        this.savingsAction.clearStore();
                        this.cancelAction.clearStore();
                    }
                });
            } else {
                this.errorMessageService.showMessageModal(this.labelService.labels.common.error.host.applyErrorMessage, () => {
                    this.navCtrl.setRoot(TopComponent);
                    this.action.clearStore();
                    this.savingsAction.clearStore();
                    this.cancelAction.clearStore();
                });
            }
        });
        this.action.submitExistReserveData(this.processSubmitData());
    }

    /**
     * 前遷移画面を設定する
     */
    public backToInfoConfirmPage() {
        this.isBackToCustomerConfirmPage = true;
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    this.clearConfirmPageInfo();
                    // 申込画面に戻るので、マスキング未確認オブジェクトをクリア
                    this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.CLEAR);
                    this.navCtrl.setRoot(ExistingReserveSelfConfirmationComponent);
                    this.logging.saveCustomOperationLog(
                        this.state.submitData.fileInfo[0].screenId,
                        this.labels.logging.AccountConfirm.backConfirmButton,
                    );
                } else {
                    this.isBackToCustomerConfirmPage = false;
                }
            }
        );
    }

    /**
     * 申込内容確認へ戻る
     */
    public clearConfirmPageInfo() {
        this.state.submitData = this.originSubmitData;
        // 申込画面へ戻る時に、maskingチェックボックスをリセット
        this.clearMaskingCheckBox();
    }

    public onEditIdentityDocument() {
        const options = {
            component: 'ExistingCheckApplyComponent',
            process: -1,
            submitData: {
                ...this.state.copySubmitData,
                ...this.state.confirmPageChanges
            }
        };
        const modal = this.modalCtrl.create(ExistingReserveChatComponent,
            {
                options,
                isCurrentPage: true,
                currentTitle: '本人確認書類'
            },
            { cssClass: 'full-modal' });
        const backup = Object.assign(new ExistingReserveSubmitEntity(), this.state.submitData);
        modal.present();
        modal.onDidDismiss((state: any) => {
            if (state && state !== 'close') {
                // 本人確認画面が終わったら、maskingチェックボックスをリセット
                this.clearMaskingCheckBox();
                this.action.setStateData(state);
                // 最新の写真によってマスキング未確認データをセットする
                this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.DOCUMENT);
            } else {
                this.state.submitData = backup;
            }
        });

    }

    /**
     * 確認書類の写真だけを撮り直す
     *
     * @param {string} type
     * @memberof
     */
    public onReTakeIdentityDocument(params: { type: string, imgDocumentName: string }) {
        const config: any = {
            name: 'reimg',
            currentTitle: this._labels.confirm.reTakeDocument,
            pageIndex: 0,
            isCurrentPage: true
        };

        const modal = this.modalCtrl.create(CommonBusinessChatComponent, {
            businessType: CommonBusinessType.ReImg,
            ...config
        }, {
            cssClass: 'full-modal'
        });
        modal.present();
        modal.onDidDismiss((data) => {
            // 「戻る」以外によってダイアログを閉じる場合
            if (data !== 'close') {
                if (params.type === LicensePhotoType.DOCUMENT) {
                    // OCR以外の書類
                    // imgDocumentNameによって特定な写真を入れ替わる
                    this.action.editSomeDataInSubmitData(undefined,
                        params.imgDocumentName,
                        data.identityDocument);

                    this.clearMaskingCheckBox();
                    this.action.resetSpecialNotMaskingConfirmImages(params.imgDocumentName);
                }
            }
        });
    }

    /**
     * 画像をクリックしたら画像修正モーダル開き
     *
     * @param {{ index: number, fieldName: string, value: string }} data
     * @memberof AccountComponent
     */
    public onImageMaskingComplete(data: { index: number, fieldName: string, value: string }) {
        this.action.editSomeDataInSubmitData(data.index, data.fieldName, data.value);
    }

    public onMaskingConfirmEmmiterHandler(imageInfo: { documentName: string, index: number }) {
        this.action.removeNotMaskingConfirmImages(imageInfo);
    }

    /**
     * サブミットデータを加工する
     */
    private processSubmitData(): any {
        // 米国人示唆情報
        const fatcaStasus = this.confirmUtil.getFatcaStatusTextJp(
            this.state.submitData.isGreenCardHave, this.state.submitData.fatcaStatus);

        // dataの加工処理を実行する
        return {
            tabletApplyId: this.state.submitData.tabletApplyId,
            params: {
                menuCode: '02',
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                birthdate: this.state.submitData.birthdate,
                eyeCueNo: this.state.submitData.receptionNumber,
                bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
                operatorName: this.loginStore.getState().clerkInfo.operatorName,
                customerId: this.state.submitData.customerId,
                occBusiness: this.state.submitData.holderCareer ? this.state.submitData.holderCareer.split('、') : undefined,
                accountOpeningPurpose:
                    this.state.submitData.accountOpeningPurpose ? this.state.submitData.accountOpeningPurpose.split('、') : undefined,
                agentLetterType: this.state.submitData.agentLetterType,
                // 本人確認方法
                // 本人確認書類１がパスポート（所持欄記載なし）場合「04」を設定、以外の場合は既存通り
                idInfoMethod: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                    IdentificationDocumentMethod.PRESENT_ONE_ADDRESS_TYPE : this.state.submitData.idInfoMethod,
                idInfoDoc1: this.state.submitData.identificationDocument1,
                identityDocument1ExpirationDate: this.state.submitData.identificationDocument1ExpiryDate,
                identityDocument1Name: this.state.submitData.documentListName,
                // 本人確認書類２コード
                // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
                idInfoDoc2: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                    undefined : this.state.submitData.identificationDocument2,
                // 本人確認書類２有効期間
                // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
                identityDocument2ExpirationDate: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                    undefined : this.state.submitData.identificationDocument2ExpiryDate,
                // 本人確認書類２その他書類名
                // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
                identityDocument2Name: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                    undefined : this.state.submitData.documentListName2,
                // 住所確認書類の書類名
                // 本人確認書類１がパスポート（所持欄記載なし）場合 かつ　書類２がその他場合、入力書類名を設定。書類２が以外の場合、ボタン名を設定
                // 本人確認書類１がパスポート（所持欄記載なし）以外場合既存通り
                addressConfirmationDocumentName:
                    (this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1)
                        && !StringUtils.isEmpty(this.state.submitData.identificationDocument2)) ?
                        (this.isDocumentTwoOther(this.state.submitData.identificationDocument2) ?
                            this.state.submitData.documentListName2 :
                            this.state.submitData.identificationDocument2Text) :
                        this.state.submitData.addressConfirmationDocumentName,
                // 住所確認書類の有効期間
                // 本人確認書類１がパスポート（所持欄記載なし）場合「本人確認書類２の有効期間」を設定、以外の場合は既存通り
                addressConfirmationDocumentExpirationDate: (this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1)
                    && !StringUtils.isEmpty(this.state.submitData.identificationDocument2)) ?
                    this.state.submitData.identificationDocument2ExpiryDate :
                    this.state.submitData.identificationAddressExpiryDate,
                residenceCountryName: '0100',
                otherResidenceCountryName: this.state.submitData.agentCountry,
                nameDifferenceFlag: this.state.submitData.isDifferenceKanji === '1' ? '1' : '0',
                addressDifferenceFlag: this.state.submitData.addressDifferenceFlag,
                residenceFlagJapanOnly: this.state.submitData.isJapanLive,
                otherResidenceAddress: this.state.submitData.otherCountry,
                birthCountry: this.state.submitData.fatcaCountry,
                // w9
                w9NameAlphabet: this.state.submitData.nameEnglish,
                w9AddressAlphabet: this.state.submitData.addressEnglish,
                w9CityNameAlphabet: this.state.submitData.cityOrTown,
                w9PrefecturesAlphabet: this.state.submitData.province,
                w9CountryNameAlphabet: this.state.submitData.agentCountryEnglish,
                w9SocialSecurityNo:
                    this.state.submitData.socialSecurityNumber ? this.state.submitData.socialSecurityNumber.replace(/\-/g, '') : undefined,
                // 米国人示唆情報、　this.state.submitData.w9AmericanSuggestionInfo,の利用は廃止する。
                w9AmericanSuggestionInfo: fatcaStasus.americanSuggestionInfo,
                // 本人確認コード
                identificationCode: this.state.submitData.identificationCode,
                // 通帳区分
                transferPassbookType: this.state.submitData.transferAccountInfo.passbookInfoCode,
                // 反社に該当しないことの同意
                notAntisocialForceConsent: '1',
                // 本人確認書類（画像ファイル）
                imageDoc1: this.state.submitData.identificationDocument1Images,
                // 本人確認書類２画像
                // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
                imageDoc2: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                    undefined : this.state.submitData.identificationDocument2Images,
                // 住所確認書類画像
                // 本人確認書類１がパスポート（所持欄記載なし）場合「本人確認書類２の画像」を設定、以外の場合は既存通り
                imageAddressDoc: (this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1)
                    && !StringUtils.isEmpty(this.state.submitData.identificationDocument2)) ?
                    this.state.submitData.identificationDocument2Images :
                    this.state.submitData.identificationAddressImages,
                // サイン
                signatureCrs: this.state.submitData.sign,
                signatureFatca: this.state.submitData.signFatca,
                signatureOath: this.state.submitData.signOath,
                signatureAgree: this.state.submitData.signAgree,
                // 口座開設店番号
                accountOpeningBranchNo: this.state.submitData.cardInfo.branchNo,
                // 自積引落店情報
                transferBranchNo: this.state.submitData.transferAccountInfo.branchNo,
                transferAccountType: this.state.submitData.transferAccountInfo.accountType,
                transferAccountNo: this.state.submitData.transferAccountInfo.accountNo,
                // 積立定期預金口座開設項目
                transferDay: this.state.submitData.transferDay,
                transferAmount: this.state.submitData.transferAmount,
                addedTransferMonth1: this.state.submitData.addedTransferMonth1,
                addedTransferAmount1: this.state.submitData.addedTransferAmount1,
                addedTransferMonth2: this.state.submitData.addedTransferMonth2,
                addedTransferAmount2: this.state.submitData.addedTransferAmount2,
                addedTransferMonth3: this.state.submitData.addedTransferMonth3,
                addedTransferAmount3: this.state.submitData.addedTransferAmount3,
                addedTransferMonth4: this.state.submitData.addedTransferMonth4,
                addedTransferAmount4: this.state.submitData.addedTransferAmount4,
                name: this.state.submitData.nameKanjiBackup || this.state.submitData.nameKanji,
                nameKana: this.state.submitData.nameKana
            }
        };
    }

    private clearMaskingCheckBox() {
        // 本人確認画面が終わったら、maskingチェックボックスをリセット
        if (this.state.checkboxStatus.isAllMaskingStatus) {
            this.action.modifyCheckboxStatus(MaskingCheckboxName.MASKING_CHECKBOX_NAME);
        }
    }

    /**
     * 書類１はパスポート（所持欄記載なし）かどうかを判断
     *
     * @private
     * @param {string} identificationDocument1
     * @return {*}  {boolean}　true：パスポート（所持欄記載なし）　false：パスポート（所持欄記載なし）以外
     */
    private isDocumentOneNewPassport(identificationDocument1: string): boolean {
        return !StringUtils.isEmpty(identificationDocument1) && identificationDocument1
            === IdentificationDocumentCode.PASSPORT_WITHOUT_SELF_INPUT;
    }

    /**
     * 書類２はその他官公庁から発行された書類（顔写真なし）かどうかを判断
     *
     * @private
     * @param {string} identificationDocument2
     * @return {*}  {boolean}　true：他官公庁から発行された書類（顔写真なし）　false：他官公庁から発行された書類（顔写真なし）以外
     */
    private isDocumentTwoOther(identificationDocument2: string): boolean {
        return !StringUtils.isEmpty(identificationDocument2) && identificationDocument2
            === IdentificationDocumentCode.OTHER_IDENTIFICATION_NO_PHOTO_DOCUMENT;
    }
}
