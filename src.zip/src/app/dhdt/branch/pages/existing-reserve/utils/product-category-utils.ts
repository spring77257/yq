import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { Age, PensionRecipientType, PointServiceType } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';

export namespace PRODUCT_TYPE {
    export const SUPER = '01'; // スーパー定期
    export const BIG_MOUTH = '1'; // 大口定期
    export const CHILD = '2';
    export const MADONNA = '3';
    export const ORANGE = '4';
    export const SMILE = '5';
    export const LOVE = '6';
    export const HAPPINESS1 = '7';
    export const HAPPINESS2 = '8';
    export const POINT = '9';
}

/**
 * 商品表示Util (既存顧客・定期預金口座開設用).
 */
export class ProductCategoryUtils {
    /**
     * 商品情報「名前、簡単説明、詳細説明」リストを取得
     */
    public static getProductInfos(): any[] {
        const savingsStore = InjectionUtils.injector.get(ExistingReserveStore);
        const submitData = savingsStore.getState().submitData;

        const infos = new Array();
        if (submitData.productConfirm === undefined) {
            const types = this.getProductCategoryByCifInfo();
            types.forEach((type) => {
                infos.push(this.productInfo(type, false));
            });
            infos.push(this.productInfo('-1', false, false));
        } else if (submitData.productConfirm === '0') { // 商品分類選択画面
            const types = this.getProductCategory();
            types.forEach((type) => {
                infos.push(this.productInfo(type, false));
            });
        } else { // 商品絞込画面
            const types = this.getProductCategory();
            const partRegular = [PRODUCT_TYPE.SUPER, PRODUCT_TYPE.BIG_MOUTH, PRODUCT_TYPE.CHILD, PRODUCT_TYPE.MADONNA];
            const regular = partRegular.concat(this.getProductCategoryByCifInfo());
            const accRegular = [PRODUCT_TYPE.SMILE, PRODUCT_TYPE.ORANGE, PRODUCT_TYPE.LOVE];
            if (regular.indexOf(types[0]) !== -1) {
                regular.forEach((type) => {
                    infos.push(this.productInfo(type, types.indexOf(type) === -1));
                });
            } else {
                accRegular.forEach((type) => {
                    infos.push(this.productInfo(type, types.indexOf(type) === -1));
                });
            }
            infos.push(this.productInfo('-1', false));
        }
        return infos;
    }

    /**
     * 商品タイプリストを取得
     */
    public static getProductCategory(): string[] {
        const savingsStore = InjectionUtils.injector.get(ExistingReserveStore);
        const submitData = savingsStore.getState().submitData;

        if (submitData.productConfirm === '0') { // 商品分類選択画面
            if (submitData.regularPurpose === '0') { // 積立定期預金
                return [PRODUCT_TYPE.SMILE, PRODUCT_TYPE.ORANGE, PRODUCT_TYPE.LOVE];
            } else { // 定期預金
                const productArr = [PRODUCT_TYPE.SUPER, PRODUCT_TYPE.BIG_MOUTH, PRODUCT_TYPE.CHILD, PRODUCT_TYPE.MADONNA];
                const types = productArr.concat(this.getProductCategoryByCifInfo());
                return types;
            }
        } else { // 商品絞込画面
            if (submitData.regularPurpose === '0') { // これからお金を積立したい
                switch (submitData.accumlatePurpose) {
                    case '2': // 教育
                        return [PRODUCT_TYPE.SMILE, PRODUCT_TYPE.LOVE];
                    case '17': // 特に決めてない
                        return [PRODUCT_TYPE.ORANGE];
                    default:
                        return [PRODUCT_TYPE.SMILE];
                }
            } else { // 今ある資金を預金したい
                const exceptArr = [];
                if (submitData.amountOfMoney === '0') { // 100万円未満
                    switch (submitData.periodOfMoney) {
                        case '0': // 未定
                            exceptArr.push(PRODUCT_TYPE.SUPER);
                            break;
                        case '1': // 3年以内
                            exceptArr.push(PRODUCT_TYPE.CHILD);
                            break;
                        case '2': // 3年超
                            exceptArr.push(PRODUCT_TYPE.SUPER);
                            break;
                    }
                } else if (submitData.amountOfMoney === '1') { // 100万以上1,000万円未満
                    switch (submitData.periodOfMoney) {
                        case '0': // 未定
                            exceptArr.push(PRODUCT_TYPE.SUPER);
                            break;
                        case '1': // 3年以内
                            exceptArr.push(PRODUCT_TYPE.CHILD);
                            break;
                        case '2': // 3年超
                            exceptArr.push(PRODUCT_TYPE.MADONNA);
                            break;
                    }
                } else { // 1,000万円以上
                    exceptArr.push(PRODUCT_TYPE.BIG_MOUTH);
                }
                return exceptArr;
            }
        }
    }

    /**
     * CIF情報の項目によって商品タイプリストを取得する。具体的な判定対象項目は以下。
     * - 年金の当行受取者(pensionRecipient)
     */
    public static getProductCategoryByCifInfo(): string[] {
        const savingsStore = InjectionUtils.injector.get(ExistingReserveStore);
        const submitData = savingsStore.getState().submitData;
        const result = [];

        // 年金を当行で受け取る以外場合
        if (submitData.pensionRecipient === PensionRecipientType.NOT_ACCEPT) {
            if (InputUtils.validateAgeRange(submitData.holderBirthdate, Age.Age_65,
                Age.Age_57, savingsStore.getState().customerApplyStartDate) &&
                !InputUtils.validateAge(submitData.holderBirthdate, Age.Age_65,
                    savingsStore.getState().customerApplyStartDate)) {
                result.push(PRODUCT_TYPE.HAPPINESS1);
            }
        } else if (submitData.pensionRecipient === PensionRecipientType.ACCEPT) { // 年金を当行で受け取っている場合
            result.push(PRODUCT_TYPE.HAPPINESS2);
        }
        if (submitData.pointServiceType === PointServiceType.GOLD) {
            result.push(PRODUCT_TYPE.POINT);
        }

        return result;
    }

    /**
     * 商品タイプによって、商品の名前を取得する
     * @param type 商品タイプ
     */
    public static getProductName(type: string): string {
        const labelService = InjectionUtils.injector.get(LabelService);
        const labels = labelService.labels;
        switch (type) {
            case PRODUCT_TYPE.SUPER:
                return labels.product.superShowName;
            case PRODUCT_TYPE.BIG_MOUTH:
                return labels.product.bigMouthShowName;
            case PRODUCT_TYPE.CHILD:
                return labels.product.childShowName;
            case PRODUCT_TYPE.MADONNA:
                return labels.product.madonnaShowName;
            case PRODUCT_TYPE.SMILE:
                return labels.product.smileShowName;
            case PRODUCT_TYPE.ORANGE:
                return labels.product.orangeShowName;
            case PRODUCT_TYPE.LOVE:
                return labels.product.loveShowName;
            case PRODUCT_TYPE.HAPPINESS1:
                return labels.product.happiness1ShowName;
            case PRODUCT_TYPE.HAPPINESS2:
                return labels.product.happiness2ShowName;
            case PRODUCT_TYPE.POINT:
                return labels.product.pointShowName;
        }
    }

    /**
     * 商品タイプによって、商品の名前を取得する
     * @param type 商品タイプ
     * @param hidden 商品隠し（false：隠し、true：表示）
     */
    private static productInfo(type: string, hidden: boolean, showHiddenItems: boolean = true) {
        const labelService = InjectionUtils.injector.get(LabelService);
        const labels = labelService.labels;

        let title;
        let introduct;
        let file;
        switch (type) {
            case PRODUCT_TYPE.SUPER:
                title = labels.product.superTitle;
                introduct = labels.product.superInfo;
                file = 'img_teiki_super@2x.png';
                break;
            case PRODUCT_TYPE.BIG_MOUTH:
                title = labels.product.bigMouthTitle;
                introduct = labels.product.bigMouthInfo;
                file = 'img_teiki_ohguchi@2x.png';
                break;
            case PRODUCT_TYPE.CHILD:
                title = labels.product.childTitle;
                introduct = labels.product.childInfo;
                file = 'img_teiki_bocchan@2x.png';
                break;
            case PRODUCT_TYPE.MADONNA:
                title = labels.product.madonnaTitle;
                introduct = labels.product.madonnaInfo;
                file = 'img_teiki_madonna@2x.png';
                break;
            case PRODUCT_TYPE.SMILE:
                title = labels.product.smileTitle;
                introduct = labels.product.smileInfo;
                file = 'img_teiki_hohoemi@2x.png';
                break;
            case PRODUCT_TYPE.ORANGE:
                title = labels.product.orangeTitle;
                introduct = labels.product.orangeInfo;
                file = 'img_teiki_orange@2x.png';
                break;
            case PRODUCT_TYPE.LOVE:
                title = labels.product.loveTitle;
                introduct = labels.product.loveInfo;
                file = 'img_teiki_aijo@2x.png';
                break;
            case PRODUCT_TYPE.HAPPINESS1:
                title = labels.product.happiness1Title;
                introduct = labels.product.happiness1Info;
                file = 'img_teiki_shiawase_01@2x.png';
                break;
            case PRODUCT_TYPE.HAPPINESS2:
                title = labels.product.happiness2Title;
                introduct = labels.product.happiness2Info;
                file = 'img_teiki_shiawase_02@2x.png';
                break;
            case PRODUCT_TYPE.POINT:
                title = labels.product.pointTitle;
                introduct = labels.product.pointInfo;
                file = 'img_teiki_point@2x.png';
                break;
        }

        const product = {
            name: title,
            introduc: introduct,
            file: file,
            type: 'normal',
            hidden: hidden,
            category: type
        };
        const other = {
            name: labels.product.other,
            introduc: '',
            file: '',
            type: 'unnormal',
            hidden: hidden,
            category: type,
            showHiddenItems: showHiddenItems
        };

        return title ? product : other;
    }
}
