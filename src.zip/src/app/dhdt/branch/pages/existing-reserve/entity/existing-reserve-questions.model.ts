import { JsonProperty } from 'adep/json';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { PayoutAccountEntity } from 'dhdt/branch/shared/components/payout-account/entity/payout-account.entity';

class ValidationRules {
    public min: { value: number } | string;
    public max: { value: number };
    public required: { value: boolean };
}

export class ExistingReserveQuestionsModel {
    public order: number;
    public next: number;
    public type: string;
    public question: string;
    public example: string;
    public choices: any[];
    public name: string;
    public options: any;
    @JsonProperty({ clazz: ValidationRules })
    public validationRules: ValidationRules;
    public skip: number;
    public other: any;
    public maxColNum: any;
}

export class PageQuestionsModel {
    public order: number;
    public next: number;
    public type: string;
    public example: string;
    public choices: any[];
    @JsonProperty({ clazz: ValidationRules })
    public validationRules: ValidationRules;
    public question: string;
    public name: string;
    public options: any;
    public answer: { order: number, text: string, value: any };
    public pageIndex: number;
    public skip: number;
    public orderIndex: number;
}

export class ExistingReserveSubmitEntity {
    [key: string]: any;

    public fileInfo?: any;

    public hasLicense: string;
    public hasConfirmFile: string;
    public addressDiffrentReason: string;
    public holderName: string;
    public holderNameFurigana: string;
    public firstName: string;
    public lastName: string;
    public holderGender: string;
    public identificationDocument1: string;
    public identificationDocument2: string;
    public firstNameKana: string;
    public lastNameKana: string;
    public category: number;
    public address: string;
    public nameKanji: string;
    public customerId: string;
    public depositAccounts: any[];
    public agentCountry: string;
    public agentCountryText: string;
    public sign: any;

    public holderBirthdate: string;
    public holderBirthdateOCR: string;
    public holderBirthdateText: string;

    public firstZipCode: string;
    public lastZipCode: string;
    public holderZipCode: string;

    public holderAddressPrefecture: string;
    public holderAddressPrefectureFuriKana: string;
    public holderAddressCountyUrbanVillage: string;
    public holderAddressCountyUrbanVillageFuriKana: string;
    public holderIdentityDocumentAddressReason: string;
    public holderIdentityDocumentPhotographType: string;
    public holderIdentityDocumentAddressType: string;
    public holderIdentityDocumentNoCopyReason: string;
    public holderIdentityDocumentType: string;
    public holderNoCopyReason: string;
    public holderPublisher: string;
    public holderPublishDate: string;
    public holderSignNo: string;
    public holderCardImageFront: string;
    public holderCardImageBack: string;
    public branchNo: string;
    public branchNameKanji: string;

    public holderAddressStreetNameSelect: string;
    public holderAddressStreetNameInput: string;
    // public holderAddressStreetName: string;

    public holderAddressStreetNameFuriKanaSelect: string;
    public holderAddressStreetNameFuriKanaInput: string;
    // public holderAddressStreetNameFuriKana: string;
    // 本人確認種類
    public identificationCode: string;
    public identificationDocument1Text: string;
    public identificationDocument2Text: string;

    public holderAddressHouseNumber: string;
    public holderAddressHouseNumberFuriKana: string;
    public firstMobileNo: string;
    public secondMobileNo: string;
    public thirdMobileNo: string;
    public mobileNo: string;
    public firstTel: string;
    public secondTel: string;
    public thirdTel: string;
    public telephoneNo: string;
    public holderCareer: string;
    public holderCareerOtherDetail: string;
    public holderWorkPlace: string;
    public holderRemoteAddressReason: string;
    public accountType: string;
    public accountTypeText: string;
    public cardDesign: string;
    public cardDesignImageSrc: string;
    public pointServiceExpectation: string;
    public pointServiceType: string;
    public directApplyExpectation: string;
    public cardPassword: string;
    public confirmPassword: string;
    public receiptMethod: string;
    public holderIdentityDocumentPublisher: string;
    public holderIdentityDocumentPublishDate: string;
    public holderIdentityDocumentSignNo: string;
    public passbookType: string;
    public firstPwd4bits: string;
    public firstPwd6bits: string;
    public passbookPrintMessage: string;
    public accountOpeningPurposeLivingExpenses: string;
    public accountOpeningPurposeBusinessExpenses: string;
    public accountOpeningPurposeSalary: string;
    public accountOpeningPurposeSavings: string;
    public accountOpeningPurposeLoan: string;
    public accountOpeningPurposeOverseasRemittance: string;
    public accountOpeningPurposeTrade: string;
    public accountOpeningPurposeOther: string;
    public accountOpeningPurposeOtherDetail: string;
    public agencyBranchNo: string;
    public accountOpeningBranchNo: string;
    public insertedImagesIds: string[];

    public productConfirm: string;
    public regularPurpose: string;
    public accumlatePurpose: string;
    public amountOfMoney: string;
    public periodOfMoney: string;
    public selectProductType: string;
    public selectProductName: string;
    public selectCourseType: string;
    public selectCourseName: string;
    public pensionRecipient: string;
    public branchCif: string;

    public pensionYearMonth: string;
    public pensionYearMonthText: string;
    public pensionAge: string;
    public pensionType: string;
    public depositAccount: PayoutAccountEntity;
    public depositAccount2nd: PayoutAccountEntity;
    public depositMethod: string;
    public transferPayoutAccount: PayoutAccountEntity;

    public leaveType: string;

    public rqNo: string;
    public customerApplyStartDate: string;
    public customerApplyEndDate: string;
    public bankclerkAuthenticationStartDate: string;
    public bankclerkAuthenticationEndDate: string;

    public tabletApplyId: string;
    public userMngNo: string;
    // ご指定口座（普通預金）－口座番号
    public accountNo;

    // 相談要、申し込み業務区分
    public applyBusinessType: string;
    // 自動継続方法
    public automicRenewal: string;

    public chatScenario: string;
    // 預入期間
    public depositPeriodYearMonth: string;
    public creditCardApplyExpectation: string;
    public sealSlipType: string;
    public commonSealStatus: string;
    public cardPublishIsApplied: string;
    public cardType: string;
    public status: string;
    public principalAgentCategory: string;

    // 積立定期口座開設用
    // お積み立て目的
    // @NotNull
    public fundingPurpose: string;
    // 満期日
    // @NotNull
    public dueDate: String ;
    // 積立金受取方法
    // @NotNull
    public reservedFundReceiptType: string;
    // 初回受取日
    public firstReceiptDate: string;
    // 受取サイクル
    public receiptCycle: string;
    // 受取指定日1
    public receiptDesignatedDate1: string;
    // 追加の受取日2
    public setReceiptDate: string;
    // 受取指定日2
    public receiptDesignatedDate2: string;

    public normalMonthArray: string[];

    // 自動振替要否:自動振替する0、自動振替しない1
    public autoTransfer: string;

    // 口座自動振替情報
    // 口座開設時預入額
    public accountOpeningDepositAmount: number;
    // 自動振替開始日
    public automaticTransferStartDate: string;
    // 通常月ー毎月:選択なし／選択あり
    public monthly: string;
    // 通常月ー１月:選択なし／選択あり
    public normalMonthJan: string;
    // 通常月ー２月:選択なし／選択あり
    public normalMonthFeb: string;
    // 通常月ー３月:選択なし／選択あり
    public normalMonthMar: string;
    // 通常月ー４月:選択なし／選択あり
    public normalMonthApr: string;
    // 通常月ー５月:選択なし／選択あり
    public normalMonthMay: string;
    // 通常月ー６月:選択なし／選択あり
    public normalMonthJun: string;
    // 通常月ー７月:選択なし／選択あり
    public normalMonthJul: string;
    // 通常月ー８月:選択なし／選択あり
    public normalMonthAug: string;
    // 通常月ー９月:選択なし／選択あり
    public normalMonthSep: string;
    // 通常月ー１０月:選択なし／選択あり
    public normalMonthOct: string;
    // 通常月ー１１月:選択なし／選択あり
    public normalMonthNov: string;
    // 通常月ー１２月:選択なし／選択あり
    public normalMonthDec: string;
    // 通常月振替日
    public normalMonthTransferDay: string;
    // 通常月振替額
    public normalMonthTransferAmount: number;
    // 毎月振替日とは別に特定振替日(年2回まで)を設定しますか？ 設定する: '0' /  設定しない: '1'
    public setEveryMonthTransferDate: string;
    // 特定振替月日１
    public specificTransferMonth1: string;
    public specificTransferMonth1Text: string;
    // 特定振替額１
    public specificTransferAmount1: number;
    // 特定振替日(年2回まで)を追加で設定しますか？ 設定する: '0' /  設定しない: '1'
    public setAddEveryMonthTransferDate: string;
    // 特定振替月日２
    public specificTransferMonth2: string;
    public specificTransferMonth2Text: string;
    // 特定振替額２
    public specificTransferAmount2: number;
    // 定期口座タイプ-新型通帳/総合口座
    public timeSavingsAccountType: string;
    // 口座開設店舗
    public paymentSelection;

    public everyMonth: string;
    public everyMonthText: string;

    // お子様－入学年
    public enrollingYear: string;
    public enrollingYearText: string;

    // QRコード受付情報
    public swipeCif: string;        // スワイプ店CIF
    public swipeBranchNo: string;
    public swipeAccountNo: string;
    public swipeAccountType: string;

    public receptionBranchNo: string;        // 受付店番
    public receptionNo: string;        // 受付番号
    public receptionTime: string;        // 受付年月日時分秒

    public interestComputationMethod: string;   // 利息計算方法
    public regionCode?: string;

    public transferAccountNo: string;
    public transferAccountType: string;
    public transferBranchNo: string;
    public childrenRelationship: string; // お子様－続柄
    public childrenNumbersFlag: string;  // お子様－続柄 flag
    public childrenNumbers: number; // お子様－人数

    // 業務定義
    public businessClassification: string;
    public identityVerifiedFlag: string;
    public startUpVerifiedFlag: string;
    public nameNonConvert: string;
    public editNameKanji: string;

    public firstAccumulationDate: string;
    public transferDay: any;

    private _normalMonthValue?: string;

    private _socialSecurityNo: string;

    public set normalMonthValue(value: string) {
        if (value) {
            const array = value.split(',');
            this.monthly = array[0];
            this.normalMonthJan = array[1];
            this.normalMonthFeb = array[2];
            this.normalMonthMar = array[3];
            this.normalMonthApr = array[4];
            this.normalMonthMay = array[5];
            this.normalMonthJun = array[6];
            this.normalMonthJul = array[7];
            this.normalMonthAug = array[8];
            this.normalMonthSep = array[9];
            this.normalMonthOct = array[10];
            this.normalMonthNov = array[11];
            this.normalMonthDec = array[12];
        }
        this._normalMonthValue = value;
    }

    public get normalMonthValue() {
        return this._normalMonthValue;
    }

    /**
     * 社会保障番号
     */
    public get socialSecurityNo() {
        return this._socialSecurityNo;
    }

    public set socialSecurityNo(value: string) {
        this._socialSecurityNo = this.number1 && this.number2 && this.number3 ? this.number1 + this.number2 + this.number3 : undefined;
    }

    /**
     * 本人氏名を取得
     */
    public getHolderName(): string {
        if (!this.firstName || !this.lastName) {
            return this.holderName;
        }
        return this.firstName + COMMON_CONSTANTS.FULL_SPACE + this.lastName;
    }

    public getHolderMobileNo(): string {
        if (!this.firstMobileNo || !this.secondMobileNo || !this.thirdMobileNo) {
            return '';
        }
        return this.firstMobileNo + this.secondMobileNo + this.thirdMobileNo;
    }

    public getHolderTelephoneNo(): string {
        if (!this.firstTel || !this.secondTel || !this.thirdTel) {
            return '';
        }
        return this.firstTel + '-' + this.secondTel + '-' + this.thirdTel;
    }

    public getHolderZipCode(): string {
        return this.firstZipCode + this.lastZipCode;
    }
}

export class DropDownListEntity {
    public key: string;
    public value: string;
    public filler1: string;
    public filler2: string;
    public filler3: string;
    public filler5: string;
}
