/**
 * 定期預金残高照会情報
 */
export class TimeBalanceEntity {
    public pointService: number;
    public happyOne: number;
    public happlyTwo: number;
    public hasHappyOne: boolean;
}
