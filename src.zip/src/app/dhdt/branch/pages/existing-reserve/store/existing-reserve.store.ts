import { Injectable, NgZone } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { AppProperties } from 'app.properties';
import {
    AccountType, ChatScenario, ClassificationConvert, ClearSavingImagesClickRecordType,
    COMMON_CONSTANTS, Constants, IdentificationDocumentCode, NameNonConvert, PassbookInfoCode,
    PassbookType, PassbookTypeConvert, SetEveryMonthTransferDate, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ExistingReserveActionType } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { CheckboxStatusEntity } from 'dhdt/branch/pages/existing-reserve/entity/checbox-status.entity';
import {
    DropDownListEntity, ExistingReserveQuestionsModel, ExistingReserveSubmitEntity, PageQuestionsModel
} from 'dhdt/branch/pages/existing-reserve/entity/existing-reserve-questions.model';
import { TimeBalanceEntity } from 'dhdt/branch/pages/existing-reserve/entity/time-balance.entity';
import {
    ChatControlPattern, CompoundAccountStatus,
    TransferControlPattern
} from 'dhdt/branch/pages/existing-reserve/existing-reserve-consts';
import { PayoutAccountEntity } from 'dhdt/branch/shared/components/payout-account/entity/payout-account.entity';
import { CifInfoInquiryResponseEntity } from 'dhdt/branch/shared/entity/cif-info-inquiry-response.entity';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { CifInformationUtils } from 'dhdt/branch/shared/utils/cif-information-utils';
import { PRODUCT_TYPE } from 'dhdt/branch/shared/utils/product-category-utils';
import { RegularSavingsLogicUtil } from 'dhdt/branch/shared/utils/regular-savings-logic-util';
import * as moment from 'moment';
import { Observable } from 'rxjs/Observable';

export interface ExistingReserveState extends State {
    customerApplyStartDate: string;
    questions: ExistingReserveQuestionsModel[][];
    showChats: PageQuestionsModel[];
    showConfirm: PageQuestionsModel[];
    submitData: ExistingReserveSubmitEntity;
    tabletStartDate: string;
    hasComprehensive: boolean;
    tabletApplyId: number;
    identityDocuments: string[];
    additionalInfoDocuments: string[];
    agentIdentityDocuments: string[];
    agentAdditionalInfoDocuments: string[];
    copySubmitData: ExistingReserveSubmitEntity;
    dropDownList: DropDownListEntity[];
    savingAccountInfo: PayoutAccountEntity[];
    accountInfo2nd: PayoutAccountEntity[];
    checkboxStatus: CheckboxStatusEntity;
    cifInfoInquiryList: CifInfoInquiryResponseEntity[];
    currentFileInfo: any;
    timeBalance: TimeBalanceEntity;
    confirmPageChanges: any;
    // 各書類の画像について、masking確認完了されたない画像のIndexを格納するオブジェクト
    notMaskingConfirmImages: {
        identificationDocument1Images: number[],    // 本人確認書類１
        identificationDocument2Images: number[],    // 本人確認書類２
        identificationAddressImages: number[],   // 住所確認書類
    };
}

export const ExistingReserveSignal = {
    SEND_ANSWER: 'SEND_ANSWER',
    GET_QUESTION: 'GET_QUESTION',
    SUCCESS_VALIDATION: 'SUCCESS_VALIDATION',
    FAILED_VALIDATION: 'FAILED_VALIDATION',
    SUCCESS_INSERT_INFO: 'SUCCESS_INSERT_INFO',
    CHAT_FLOW_COMPELETE: 'CHAT_FLOW_COMPELETE',
    SUCCESS_INSERT_IMAGES_INFO: 'SUCCESS_INSERT_IMAGES_INFO',  // イメージアップロードAPIが正しく実行完了
    SUCCESS_INSERT_TIME_SAVINGS_APPLY: 'SUCCESS_INSERT_TIME_SAVINGS_APPLY',  // イメージアップロードAPIが正しく実行完了

    CANCEL_COMPLETE: 'CANCEL_COMPLETE',
    GET_LIST_COMPLETE: 'GET_LIST_COMPLETE',
    TABLET_APPLY_INSERT_SUCCESS: 'TABLET_APPLY_INSERT_SUCCESS',

    SET_CIF_INFORMATION: 'ExistingSavingsSignal_SET_CIF_INFORMATION',
    ACCOUNT_INFO: 'ExistingReserveSignal_ACCOUNT_INFO',

    SET_TIME_BALANCE: 'ExistingReserveSignal_SET_TIME_BALANCE',

    SHOULD_UPDATE_DUE_DATE: 'ExistingReserveSignal_SHOULD_UPDATE_DUEDATE',

    FIRST_TRANSFER_DAY: 'ExistingReserveSignal_FIRST_TRANSFER_DAY',

    GET_EXISTING_ACCOUNT_INFO: 'ExistingReserveSignal_GET_EXISTING_ACCOUNT_INFO',
    GET_ORDINARILY_ACCOUNT_INFO: 'ExistingReserveSignal_GET_ORDINARILY_ACCOUNT_INFO',

    SET_ANSWER: 'ExistingReserveSignal_SET_ANSWER',
    WILL_PUSH_FOOTER: 'ExistingReserveSignal_WILL_PUSH_FOOTER',
    WILL_DISMISS_FOOTER: 'ExistingReserveSignal_WILL_DISMISS_FOOTER',
    RECEPTION_CHECK: 'ExistingReserveSignal_RECEPTION_CHECK',

    RECEPTION_CHECK_TRANSFER: 'ExistingReserveSignal_RECEPTION_CHECK_TRANSFER',
    RECEPTION_CHECK_DEPOSIT: 'ExistingReserveSignal_RECEPTION_CHECK_DEPOSIT',
    RECEPTION_CHECK_DEPOSIT_TRANSFER: 'ExistingReserveSignal_RECEPTION_CHECK_DEPOSIT_TRANSFER',
    CHAT_FLOW_RETURN: 'ExistingReserveSignal_CHAT_FLOW_RETURN',
};

@Injectable()
export class ExistingReserveStore extends Store<ExistingReserveState> {
    public documentMap: Map<number, string>;
    private keysArr: any[] = [];
    private replaceValues: Array<{ key: string, value: string }>;
    private regularSavingsLogicUtil: RegularSavingsLogicUtil;

    constructor(
        private ngZone: NgZone,
        private editService: EditService,
        private labelService: LabelService,
    ) {
        super();
        this.regularSavingsLogicUtil = InjectionUtils.injector.get(RegularSavingsLogicUtil);
        this.state = {
            customerApplyStartDate: null,
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new ExistingReserveSubmitEntity(),
            tabletStartDate: '',
            tabletApplyId: -1,
            identityDocuments: [],
            additionalInfoDocuments: [],
            agentIdentityDocuments: [],
            agentAdditionalInfoDocuments: [],
            copySubmitData: null,
            hasComprehensive: false,
            dropDownList: [],
            savingAccountInfo: [],
            accountInfo2nd: [],
            checkboxStatus: {
                receiptMethodStatus: false,  // カードお受取方法 checkbox
                confirmationStatus: false,  // 契約状況確認
                isAntisocialStatus: true, // 反社会的勢力
                isForeignPulicFiguresSatus: true,  // 外国の重要な公的地位にある者
                isJapaneseResidentStatus: false,  // 日本居住者です
                isRegulationStatus: false,
                isAllMaskingStatus: false, // 写真マスキング
            },
            cifInfoInquiryList: new Array<CifInfoInquiryResponseEntity>(),
            currentFileInfo: {},
            timeBalance: new TimeBalanceEntity(),
            confirmPageChanges: {},
            notMaskingConfirmImages: {
                identificationDocument1Images: [],
                identificationDocument2Images: [],
                identificationAddressImages: []
            }
        };
        this.setDocumentMap();
    }

    @ActionBind(ExistingReserveActionType.SET_BRANCH_INFO)
    private setBranchInfo(params: any) {
        this.setSubmitData('branchNameKanji', params.branchNameKanji);
        this.setSubmitData('branchNo', params.branchNo);
    }

    @ActionBind(ExistingReserveActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.saveCurrentYamlInfo(params.fileInfo[0]);

            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(ExistingReserveSignal.GET_QUESTION, params.pageIndex);

        }
    }

    @ActionBind(ExistingReserveActionType.BRANCH_STATUS_INSERT)
    private branchStatusInsert(data: any) {
        if (data) {
            this.state.tabletApplyId = data;
            this.setSubmitData('tabletApplyId', data);
            this.sendSignal(ExistingReserveSignal.TABLET_APPLY_INSERT_SUCCESS);
        }
    }

    @ActionBind(ExistingReserveActionType.CLEAR)
    private clearStore() {
        this.state = {
            customerApplyStartDate: null,
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new ExistingReserveSubmitEntity(),
            tabletStartDate: '',
            tabletApplyId: -1,
            identityDocuments: [],
            additionalInfoDocuments: [],
            agentIdentityDocuments: [],
            agentAdditionalInfoDocuments: [],
            copySubmitData: null,
            hasComprehensive: false,
            savingAccountInfo: [],
            accountInfo2nd: [],
            dropDownList: [],
            checkboxStatus: {
                receiptMethodStatus: false,  // カードお受取方法 checkbox
                confirmationStatus: false,  // 契約状況確認
                isAntisocialStatus: true, // 反社会的勢力
                isForeignPulicFiguresSatus: true,  // 外国の重要な公的地位にある者
                isJapaneseResidentStatus: false,  // 日本居住者です
                isRegulationStatus: false,
                isAllMaskingStatus: false, // 写真マスキング
            },
            cifInfoInquiryList: new Array<CifInfoInquiryResponseEntity>(),
            currentFileInfo: {},
            timeBalance: new TimeBalanceEntity(),
            confirmPageChanges: {},
            notMaskingConfirmImages: {
                identificationDocument1Images: [],
                identificationDocument2Images: [],
                identificationAddressImages: []
            }
        };
        this.keysArr = [];
    }

    @ActionBind(ExistingReserveActionType.SET_STATE_DATA)
    private setStateData(data) {
        this.state.submitData = Object.assign(new ExistingReserveSubmitEntity(), data.submitData);
    }

    @ActionBind(ExistingReserveActionType.CLEAR_DOCUMENTS)
    private clearStoreDocuments() {
        // 本人確認書類
        this.setSubmitData('holderIdentityDocumentType', null);
        // 本人確認書類をクリアする
        this.state.identityDocuments = [];
        // 本人確認補完書類をクリアする
        this.state.additionalInfoDocuments = [];
        // コピー徴求ができない理由
        this.setSubmitData('holderIdentityDocumentNoCopyReason', null);
        // 発行元
        this.setSubmitData('holderIdentityDocumentPublisher', null);
        // 発行日
        this.setSubmitData('holderIdentityDocumentPublishDate', null);
        // 記号番号
        this.setSubmitData('holderIdentityDocumentSignNo', null);
        // 顔写真のない本人確認書類の場合の補完書類
        this.setSubmitData('holderIdentityDocumentPhotographType', null);
        // 本人確認書類の住所と現住所が異なる場合の補完書類
        this.setSubmitData('holderIdentityDocumentAddressType', null);
        // 住所が相違する理由
        this.setSubmitData('holderIdentityDocumentAddressReason', null);
        this.setSubmitData('addressDiffrentReason', null);
        // コピー徴求ができない理由
        this.setSubmitData('holderNoCopyReason', null);
        // 発行元
        this.setSubmitData('holderPublisher', null);
        // 発行日
        this.setSubmitData('holderPublishDate', null);
        // 記号番号
        this.setSubmitData('holderSignNo', null);
        // 遠隔地等住所等の場合の理由
        this.setSubmitData('holderRemoteAddressReason', null);
    }

    @ActionBind(ExistingReserveActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: { order: number, pageIndex: number }, other = null, options = null) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<ExistingReserveQuestionsModel>(this.state.questions[pageIndex])
                    .min<ExistingReserveQuestionsModel>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus = new PageQuestionsModel();
                        qus.order = item.order;
                        qus.next = item.next;
                        qus.type = item.type;
                        qus.options = item.options;
                        qus.question = this.replaceParams(item.question);
                        qus.name = item.name;
                        qus.skip = item.skip;
                        qus.pageIndex = pageIndex;
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        this.sendSignal(ExistingReserveSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<ExistingReserveQuestionsModel>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        if (options) {
                            item.options = options;
                        }
                        const qus = new PageQuestionsModel();
                        qus.order = item.order;
                        qus.next = item.next;
                        qus.type = item.type;
                        qus.options = item.options;
                        qus.question = this.replaceParams(item.question);
                        qus.name = item.name;
                        qus.skip = item.skip;
                        qus.pageIndex = pageIndex;
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        const repeatOrderArr = this.state.showChats.filter((filterItem) => filterItem.order === order);
                        // orderは繰り返しの場合、orderIndexを追加する。
                        (repeatOrderArr && repeatOrderArr.length > 0) ? qus.orderIndex = repeatOrderArr.length : qus.orderIndex = 0;
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        if (other) {
                            item.other = other;
                        }
                        this.sendSignal(ExistingReserveSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => { console.log('Outside Done!'); });
        });
    }

    private replaceParams(str: string): string {
        if (str.indexOf('@') === -1) {
            return str;
        }

        this.replaceValues = [
            {
                key: '@Doc2SkipLabel',
                value: this.state.submitData.identificationDocument1 === IdentificationDocumentCode.PASSPORT_WITHOUT_SELF_INPUT ?
                    '' : this.labelService.labels.confirm.identityDocumentConfirm.doc2SkipLabel
            },
            { key: '@Name',
              value: this.state.submitData.nameKanjiBackup !== undefined ? this.state.submitData.nameKanjiBackup :
                        this.state.submitData.nameKanji !== undefined ? this.state.submitData.nameKanji : this.state.submitData.nameKana
            },
            { key: '@ProductName', value: this.state.submitData.selectProductName },
            { key: '@CourseName', value: this.state.submitData.selectCourseName },
            { key: '@SpecificTransferMonth1', value: this.state.submitData.specificTransferMonth1Text },
            { key: '@SpecificTransferMonth2', value: this.state.submitData.specificTransferMonth2Text },
            { key: '@HolderNameFurigana', value: this.state.submitData.holderNameFurigana },
            { key: '@Address', value: this.state.submitData.address },
            {
                key: '@identificationDocument1', value: this.state.submitData.identificationDocument1Text
            },
            {
                key: '@identificationDocument2', value: this.state.submitData.identificationDocument2Text
            },
            {
                key: '@firstAccumulationDate', value: moment(this.state.submitData.firstAccumulationDate).format('YYYY年M月D日')
            },
            {
                key: '@addedTransferMonth1', value: this.state.submitData.addedTransferMonth1
            },
            {
                key: '@addedTransferMonth2', value: this.state.submitData.addedTransferMonth2
            },
            {
                key: '@addedTransferMonth3', value: this.state.submitData.addedTransferMonth3
            },
            {
                key: '@addedTransferMonth4', value: this.state.submitData.addedTransferMonth4
            },
            {
                key: '@agentCountry',
                value: this.state.submitData.agentCountryText
            }
        ];

        let result = str;
        const documentNameKeyArr = ['@identificationDocument1', '@identificationDocument2'];
        this.replaceValues.forEach((element) => {
            if (result.indexOf(element.key) !== -1) {
                let identificationDocumentName;
                const propertyName = documentNameKeyArr[documentNameKeyArr.indexOf(element.key)];
                if ((this.state.submitData.accountType === AccountType.EXISTING_RESERVE) &&
                    element.key === propertyName) {
                    // 定期預金のお手続き（スワイプあり）の場合
                    // 本人確認書類１/２ && 記載ありの場合、chatFlowのorder繰り返し運用する、バグ修正する。
                    const qus = this.state.showChats.forEach((item, index) => {
                        if (propertyName.replace('@', '') === item.name) {
                            // 文言のパラメータはshowChatsからです
                            identificationDocumentName = (item.answer && item.answer.text) ? item.answer.text : null;
                        }
                    });

                    /**
                     * 「本人確認書類１/２選択 && 本人確認書類１/２名はブランク」 or
                     * if   「submitDataの本人確認書類１/２名」は「showChatsの本人確認書類１/２名」と違う の場合、表示の文言のパラメータはshowChatsからです、
                     * else 表示の文言のパラメータはsubmitDataからです
                     */
                    result = ((element.value === undefined || identificationDocumentName !== element.value)
                        && identificationDocumentName !== null) ?
                        result.replace(element.key, identificationDocumentName) :
                        result.replace(element.key, element.value);
                } else {
                    result = result.replace(element.key, element.value);
                }
            }
        });

        return result;
    }

    private setDocumentMap() {
        this.documentMap = new Map<number, string>();
        this.documentMap.set(Constants.IdentityDocumentCategory.Document1, 'identificationDocument1Images');
        this.documentMap.set(Constants.IdentityDocumentCategory.Document2, 'identificationDocument2Images');
        this.documentMap.set(Constants.IdentityDocumentCategory.Address, 'identificationAddressImages');
        this.documentMap.set(Constants.IdentityDocumentCategory.AgentDocument1, 'identificationDocument1AgentImages');
        this.documentMap.set(Constants.IdentityDocumentCategory.AgentDocument2, 'identificationDocument2AgentImages');
        this.documentMap.set(Constants.IdentityDocumentCategory.AgentAddress, 'identificationAddressAgentImages');
    }

    /**
     * 本人確認書類画像を保存
     */
    @ActionBind(ExistingReserveActionType.SAVE_DOCUMENT_IMAGE)
    private saveIdentityDocumentImage(document: any) {
        const { image, category } = document;
        const submitKey = this.documentMap.get(category);
        this.setSubmitData(
            submitKey,
            this.state.submitData[submitKey] ?
                [...this.state.submitData[submitKey], image] : [image]
        );
    }

    @ActionBind(ExistingReserveActionType.SET_IDENTIFICATION_DOCUMENT)
    private setIdentificationDocument(data) {
        const { submitData } = data;
        this.state.submitData = submitData;
    }

    /**
     * 本人確認書類画像をクリア
     */
    @ActionBind(ExistingReserveActionType.CLEAN_DOCUMENT_IMAGE)
    private cleanIdentityDocumentImage(category: Constants.IdentityDocumentCategory) {
        const submitKey = this.documentMap.get(category);
        this.setSubmitData(submitKey, null);
    }

    /**
     * サーバーのシステム時間を取得
     */
    @ActionBind(ExistingReserveActionType.FIRST_TRANSFER_DAY)
    private getFirstAccumulationDate(date) {
        const lastDay = Math.min(
            moment(date).endOf('month').date(),
            Number(this.state.submitData.transferDay)
        );

        if (lastDay > moment(date).date()) {
            this.setSubmitData('firstAccumulationDate', moment(date).date(lastDay).format('YYYYMMDD'));
        } else {
            const day = Math.min(
                moment(date).add('month', 1).endOf('month').date(),
                Number(this.state.submitData.transferDay)
            );
            this.setSubmitData('firstAccumulationDate', moment(date).add('month', 1).date(day).format('YYYYMMDD'));
        }
        this.sendSignal(ExistingReserveSignal.FIRST_TRANSFER_DAY);
    }

    @ActionBind(ExistingReserveActionType.EDIT_CHAT)
    private editChat(params: any) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;
        const orderIndex = params.orderIndex;

        let i = -1;
        let index = -1;
        if (orderIndex !== null && orderIndex !== undefined) {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order && message.orderIndex === orderIndex) {
                    index = i;
                }
            });
        } else {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order) {
                    index = i;
                }
            });
        }

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }
        this.cleanSubmitData(answerOrder);
        this.resetIdentificationDocument(order, pageIndex);
    }

    @ActionBind(ExistingReserveActionType.SET_ANSWER)
    private setAnswer(answer: { order: number, text: string, value: Array<{ key: string, value: any }> }) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        answer.order = this.getTopOrder();
        chat.answer = answer;
        if (answer.value) {
            answer.value.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    private getTopOrder() {
        return this.keysArr.length;
    }

    @ActionBind(ExistingReserveActionType.SET_STATE_SUBMIT_DATA_VALUE)
    private setStateSubmitDataValues(datas: Array<{ key: string, value: string }>) {
        if (datas && datas.length > 0) {
            datas.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    @ActionBind(ExistingReserveActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    // get holderZipCode 郵便番号
    @ActionBind(ExistingReserveActionType.GET_HOLDER_ZIP_CODE)
    private getHolderZipCode(data: any) {
        this.setSubmitData('firstZipCode', data.substring(0, 3));
        this.setSubmitData('lastZipCode', data.substring(3, 7));
    }

    @ActionBind(ExistingReserveActionType.RETRIEVE_DROP_LIST)
    private retrieveDropList(data) {
        this.state.dropDownList = data;
    }

    @ActionBind(ExistingReserveActionType.BRANCH_INFO_INSERT)
    private branchInfoInsert(data) {
        this.sendSignal(ExistingReserveSignal.SUCCESS_INSERT_INFO);
    }

    @ActionBind(ExistingReserveActionType.CHAT_FLOW_COMPELETE)
    private chatFlowCompelete(nextChatName: string) {
        this.sendSignal(ExistingReserveSignal.CHAT_FLOW_COMPELETE, nextChatName);
    }

    @ActionBind(ExistingReserveActionType.RESET_LAST_NODE)
    private resetLastNode(params: { order: number, pageIndex: number }) {
        this.getState().showChats.pop();
        this.getNextChatByAnswer(params);
    }

    @ActionBind(ExistingReserveActionType.SUBMIT_TIME_SAVING_APPLY_INFO)
    private timeSavingApplyInfoInsert(data) {
        this.sendSignal(ExistingReserveSignal.SUCCESS_INSERT_INFO);
    }

    @ActionBind(ExistingReserveActionType.SET_BANKCLERK_ID)
    private setBankclerkId(params: any) {
        this.setSubmitData('userMngNo', params.bankclerkId);
    }

    @ActionBind(ExistingReserveActionType.GET_CONFIRM_PAGE_TEMPLATE)
    private loadConfirmTemplate(params: any) {
        if (params) {
            this.state.questions[params.pageIndex] = params.data;
            this.state.submitData.fileInfo = params.fileInfo;
        }
    }

    /**
     * Reset showChats
     * @param data origin showChats
     */
    @ActionBind(ExistingReserveActionType.RESET_SHOWCHATS)
    private resetShowChats(data: any) {
        this.state.showChats = data;
    }

    /**
     * modify checkbox status
     * @param name the checbox item need to modify status
     */
    @ActionBind(ExistingReserveActionType.MODIFY_CHECKBOX_STATUS)
    private modifyCheckboxStatus(name: string) {
        this.state.checkboxStatus[name] = !this.state.checkboxStatus[name];
    }

    /**
     * CIF情報照会設定
     * @param data response data
     */
    @ActionBind(ExistingReserveActionType.SET_CIF_INFORMATION)
    private setCifInformation(params: any) {
        this.state.cifInfoInquiryList = params.data.cifInfoInquiryResponseList;

        this.settingCifInformation(params.data.cifInfoInquiryResponse);
        this.sendSignal(ExistingReserveSignal.SET_CIF_INFORMATION,
            { nextOrder: params.nextOrder, pageIndex: params.pageIndex });
    }

    /**
     * Submit result
     */
    @ActionBind(ExistingReserveActionType.SUBMIT_EXIST_SAVING_APPLY_INFO)
    private submitExistSavingsData(params: any) {
        this.sendSignal(ExistingReserveSignal.SUCCESS_INSERT_INFO, params);
    }

    /**
     * 積立定期
     * @param params params
     */
    @ActionBind(ExistingReserveActionType.SUBMIT_EXIST_RESERVE_APPLY_INFO)
    private submitExistReserveData(params: any) {
        this.sendSignal(ExistingReserveSignal.SUCCESS_INSERT_INFO, params);
    }

    /**
     * Save yaml file Information
     */
    private saveCurrentYamlInfo(params: any) {
        this.state.currentFileInfo.yamlId = params.id;
        this.state.currentFileInfo.screenId = params.screenId;
        this.state.currentFileInfo.screenName = params.screenName;
    }

    /**
     * SubmitDataに本人基本情報設定を行う
     * @param entity CIF情報エンティティ
     */
    private settingCifInformation(entity: CifInfoInquiryResponseEntity) {
        // 基本情報を設定する
        CifInformationUtils.setCifBasicInfoForExistings(this.state.submitData, this.keysArr, entity);

        // 年金を当行で受け取っている場合1、それ以外は0
        this.setSubmitData('pensionRecipient', entity.pensionRecipient);
        this.setSubmitData('timeSavingsAccountType', this.regularSavingsLogicUtil.getTimeSavingsAccountType(entity.birthday));
        // undefind: 新規 other: 既存
        this.setSubmitData('branchCif', entity.branchCif);
        this.setSubmitData('pointServiceType', entity.pointServiceType);
        // スワイプした店舗名
        this.setSubmitData('branchName', entity.branchName);
        // regionCode
        this.setSubmitData('regionCode', entity.regionCode);
    }

    /**
     * 通帳に印刷する文字 skip
     */
    @ActionBind(ExistingReserveActionType.PASSBOOK_PRINT_MESSAGE_SKIP)
    private passbookPrintMessageSkip() {
        this.setSubmitData('passbookPrintMessage', null);
    }

    private cleanSubmitData(remain: number) {
        this.keysArr = this.keysArr.slice(0, remain);

        for (const item in this.state.submitData) {
            if (item.startsWith('get')) {
                continue;
            }
            if (item === '_normalMonthValue' || item === 'socialSecurityNo') {
                continue;
            }
            if (this.keysArr.indexOf(item) < 0 && item !== SubmitDataKey.LOG_FILE_INFO) {
                this.state.submitData[item] = undefined;
            }
        }
    }

    /**
     * set SubmitData
     * @param key key
     * @param value value
     */
    private setSubmitData(key, value) {
        if (key !== undefined) {
            this.state.submitData[key] = value;
            this.keyPush(key, value);
        }
    }

    /**
     * keyPush
     * @param key key
     * @param value value
     */
    private keyPush(key: any, value: any) {
        if (value === null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                this.keysArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1) {
            this.keysArr.push(key);
        } else {
            const index = this.keysArr.indexOf(key);
            this.keysArr[index] = moment().format('YYYYMMDDHHmmss');
            this.keysArr.push(key);
        }
    }

    /**
     * get 入学年 YYYY --> YYYY(平成XX)年
     * @param params submitData.enrollingYear
     */
    @ActionBind(ExistingReserveActionType.GET_ENROLLING_YEAR_TEXT)
    private getEnrollingYearText(data: any) {
        this.setSubmitData('enrollingYearText', data.jpBirthday);
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param data QRコード受付情報
     */
    @ActionBind(ExistingReserveActionType.SET_SWIPE_INFO)
    private setSwipeInfo(data: any) {
        // QRコードを読み込む場合
        if (data.swipeInfo) {
            this.setSubmitData('swipeCif', data.swipeInfo.branchCif);
            this.setSubmitData('swipeBranchNo', data.swipeInfo.cardBranchNo);
            this.setSubmitData('swipeAccountNo', data.swipeInfo.cardAccountNo);
            this.setSubmitData('swipeAccountType', data.swipeInfo.cardAccountType);

            this.setSubmitData('receptionBranchNo', data.swipeInfo.receptionBranchNo);
            this.setSubmitData('receptionNo', data.swipeInfo.receptionNo);
            this.setSubmitData('receptionTime', data.swipeInfo.receptionTime);
        }

        this.state.tabletApplyId = data.tabletApplyId;
        this.setSubmitData('tabletApplyId', data.tabletApplyId);
    }

    /**
     * Requtst account info
     * @param accountInfo response of the request
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @ActionBind(ExistingReserveActionType.ACCOUNT_INFO)
    private requestAccountInfo({ accountInfo, entity, pageIndex }) {
        if (accountInfo.length > 0) {
            let result = accountInfo;
            if (this.state.submitData.selectProductType === PRODUCT_TYPE.ORANGE
                || this.state.submitData.selectProductType === PRODUCT_TYPE.SMILE
                || this.state.submitData.selectProductType === PRODUCT_TYPE.LOVE) {
                result = accountInfo.filter((element) => {
                    return element.accountType === COMMON_CONSTANTS.AccountTypeCode.ordinary;
                });
            }
            this.getNextChatByAnswer({ order: entity.next, pageIndex: pageIndex }, result);
        } else {
            this.getNextChatByAnswer({ order: entity.skip, pageIndex: pageIndex });
        }
    }

    /**
     * 口座情報照会(預入2回目)
     * @param result response of the request
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @ActionBind(ExistingReserveActionType.ACCOUNT_INFO_2ND)
    private requestAccountInfo2nd({ result, entity, pageIndex }) {
        if (result.depositPossiblePassbookInfo.length > 0) {
            switch (this.state.submitData.depositAccount.passbookType) {
                case PassbookType.NOMRAL:
                    this.setSubmitData('chatScenario', ChatScenario.TYPE_B);
                    break;
                case PassbookType.ALL:
                    this.setSubmitData('chatScenario', ChatScenario.TYPE_D);
                    break;
                case PassbookType.NEW_ALL:
                    this.setSubmitData('chatScenario', ChatScenario.TYPE_F);
                    break;
            }
        } else {
            switch (this.state.submitData.depositAccount.passbookType) {
                case PassbookType.NOMRAL:
                    this.setSubmitData('chatScenario', ChatScenario.TYPE_A);
                    break;
                case PassbookType.ALL:
                    this.setSubmitData('chatScenario', ChatScenario.TYPE_C);
                    break;
                case PassbookType.NEW_ALL:
                    const type = result.hasComprehensive ? ChatScenario.TYPE_A : ChatScenario.TYPE_E;
                    this.setSubmitData('chatScenario', type);
                    break;
            }
        }
        this.state.accountInfo2nd = result.depositPossiblePassbookInfo;
        this.state.hasComprehensive = result.hasComprehensive;
        this.getNextChatByAnswer({ order: entity.next, pageIndex: pageIndex }, result.depositPossiblePassbookInfo);
    }

    /**
     * Requtst saving account info
     * @param accountInfo response of the request
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @ActionBind(ExistingReserveActionType.SAVING_ACCOUNT_INFO)
    private requestSavingAccountInfo({ accountInfo, entity, pageIndex }) {
        this.state.savingAccountInfo = accountInfo;
        if (accountInfo.length > 0) {
            this.getNextChatByAnswer({ order: entity.next, pageIndex: pageIndex }, accountInfo);
        } else {
            this.getNextChatByAnswer({ order: entity.skip, pageIndex: pageIndex });
        }
    }

    /**
     * Requtst selected account info
     * @param accountInfo response of the request
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @ActionBind(ExistingReserveActionType.SELECTED_ACCOUNT_INFO)
    private requestSelectedAccountInfo({ accountInfo, entity, pageIndex }) {
        if (accountInfo.length > 0) {
            this.getNextChatByAnswer({ order: entity.next, pageIndex: pageIndex }, accountInfo);
        } else {
            this.getNextChatByAnswer({ order: entity.skip, pageIndex: pageIndex });
        }
    }

    /**
     * 取次店番を設定する
     * @param params 支店番号
     */
    @ActionBind(ExistingReserveActionType.SET_AGENCY_BRANCH_INFO)
    private setAgencyBranchInfo(params: any) {
        this.setSubmitData('agencyBranchNo', params.branchNo);
    }

    /**
     * Reset showConfirm and submitData
     * @param param showConfirm and submitData
     */
    @ActionBind(ExistingReserveActionType.RESET_SHOW_CONFIRM)
    private resetShowConfirm({ showConfirm, submitData }) {
        this.state.showConfirm = showConfirm;
        this.state.submitData = submitData;
    }

    /**
     * Request default address
     * @param result default address
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @ActionBind(ExistingReserveActionType.GET_DEFAULT_ADDRESS)
    private requestDefaultAddress({ result, entity, pageIndex }) {
        const order = (result.branchNameKanji && result.branchNo) ? entity.next : entity.skip;
        this.getNextChatByAnswer({ order: order, pageIndex: pageIndex }, null, result);
    }

    /**
     * reset 特定振替日1,特定振替額1 / 特定振替日2,特定振替額2
     */
    @ActionBind(ExistingReserveActionType.RESET_SPECIAL_TRANSFER_INFO)
    private resetSpecialTransferInfo() {
        this.setSubmitData('specificTransferMonth1', null);
        this.setSubmitData('specificTransferAmount1', null);

        if (this.state.submitData.setAddEveryMonthTransferDate === SetEveryMonthTransferDate.SET) { // 特定振替日2設定する
            // modify 特定振替日1設定しない to 特定振替日1設定する
            this.setSubmitData('setEveryMonthTransferDate', SetEveryMonthTransferDate.SET);
            this.setSubmitData('specificTransferMonth1', this.state.submitData.specificTransferMonth2);
            this.setSubmitData('specificTransferAmount1', this.state.submitData.specificTransferAmount2);
            // modify 特定振替日2設定する to 特定振替日2設定しない
            this.setSubmitData('setAddEveryMonthTransferDate', SetEveryMonthTransferDate.UNSET);
            this.setSubmitData('specificTransferMonth2', null);
            this.setSubmitData('specificTransferAmount2', null);
        }
    }

    /**
     * 修正button 特定振替日(年2回まで)を追加で設定しますか？ 設定しない
     * clear specialTransferInfo2
     */
    @ActionBind(ExistingReserveActionType.CLEAR_SPECIAL_TRANSFER_INFO_2)
    private ClearSpecialTransferInfo2() {
        this.setSubmitData('specificTransferMonth2', null);
        this.setSubmitData('specificTransferAmount2', null);
    }

    /* 商品タイプを設定する
    * @param data 商品タイプ
    */
    @ActionBind(ExistingReserveActionType.SET_PRODUCT_TYPE)
    private setProductType(data: string) {
        this.setSubmitData('selectProductType', data);
    }

    /**
     * Request default address
     * @param result default address
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @ActionBind(ExistingReserveActionType.SET_TIME_BALANCE)
    private setTimeBalance({ result }) {
        if (result === null) {
            return;
        }
        this.state.timeBalance.happyOne = result.happyOne;
        this.state.timeBalance.happlyTwo = result.happlyTwo;
        this.state.timeBalance.pointService = result.pointService;
        this.state.timeBalance.hasHappyOne = result.hasHappyOne;

        this.sendSignal(ExistingReserveSignal.SET_TIME_BALANCE);
    }

    /**
     * 業務定義をstateに設定する
     */
    @ActionBind(ExistingReserveActionType.SET_BUSINESS_INFO)
    private setBusinessInfo() {
        if (this.state.submitData.depositAccount2nd) {
            // 通帳種別
            this.setSubmitData('passbookType', this.convertPassbookInfoCode(
                this.state.submitData.depositAccount2nd.passbookInfoCode));
            // 業務定義
            this.setSubmitData('businessClassification', this.convertClassification(
                this.state.submitData.depositAccount2nd.branchNo));
        } else {
            this.setSubmitData('passbookType', PassbookTypeConvert.NEW);
            this.setSubmitData('businessClassification', ClassificationConvert.NEW_ACCOUNT);
        }
    }
    /**
     * 重複口座Cif情報設定
     * @param result default address
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @ActionBind(ExistingReserveActionType.SET_SAMEHOLDER_CIF_INFORMATION)
    private setSameHolderCifInfo(result: any) {
        if (result && result.data && result.data.cifInfoInquiryResponse) {
            this.setSubmitData('branchCif', result.data.cifInfoInquiryResponse.branchCif);
            this.setSubmitData('accountOpeningBranchNo', result.data.cifInfoInquiryResponse.tenban);
            this.setSubmitData('commonSealStatus', result.data.cifInfoInquiryResponse.sharedSignetType);
            this.setSubmitData('identityVerifiedFlag', result.data.cifInfoInquiryResponse.identityVerified);
            this.setSubmitData('startUpVerifiedFlag', result.data.cifInfoInquiryResponse.startUpVerified);
        }
    }

    /**
     * API用通帳情報コード転換
     */
    private convertPassbookInfoCode(type: string): string {
        if (type === PassbookInfoCode.ALL || type === PassbookInfoCode.NEW_ALL) {
            return PassbookTypeConvert.All;
        }
        return PassbookTypeConvert.NEW;
    }
    /**
     * API用業務定義コード転換
     */
    private convertClassification(branchNo: string): string {
        if (branchNo === undefined) {
            return ClassificationConvert.NEW_ACCOUNT;
        }
        return ClassificationConvert.SAVING_2ND;
    }

    /**
     * cif情報をセット
     * @param cifInfo cif情報
     */
    @ActionBind(ExistingReserveActionType.SET_CIF_INFO)
    private setCifInfo(cifInfo: any) {
        Object.keys(cifInfo).forEach((key) => {
            this.setSubmitData(key, cifInfo[key]);
        });
    }

    /**
     * 満期日を設定する
     */
    @ActionBind(ExistingReserveActionType.SET_DUE_DATE)
    private setDueDate() {
        this.setSubmitData('dueDate', this.regularSavingsLogicUtil.getDueDate(this.getState().submitData));
        this.sendSignal(ExistingReserveSignal.SHOULD_UPDATE_DUE_DATE);
    }

    /**
     * 預入期間(満期日)設定
     */
    @ActionBind(ExistingReserveActionType.SET_DUE_DATE_AND_DEPOSIT_PERIOD_YEARMONTH)
    private setDueDateAndDepositPeriodYearMonth() {
        if (this.getState().submitData.selectProductType === PRODUCT_TYPE.HAPPINESS1) {
            this.setSubmitData('depositPeriodYearMonth',
                this.regularSavingsLogicUtil.getHappinessOneDepositPeriodYearMonth(this.getState().submitData)
                + this.labelService.labels.common.year);
        } else if (this.state.submitData.selectProductType === PRODUCT_TYPE.HAPPINESS2
            || this.state.submitData.selectProductType === PRODUCT_TYPE.POINT) {
            this.setSubmitData('depositPeriodYearMonth', this.labelService.labels.timeDeposit.OneYear);
        } else if (this.state.submitData.selectProductType === PRODUCT_TYPE.CHILD) {
            this.setSubmitData('depositPeriodYearMonth', this.labelService.labels.timeDeposit.ThreeYear);
        }
        this.setSubmitData('dueDate', this.regularSavingsLogicUtil.getDueDate(this.getState().submitData));
        this.sendSignal(ExistingReserveSignal.SHOULD_UPDATE_DUE_DATE);
    }

    /**
     * Set the item as the current time of server
     * @param data system time and the key of item
     */
    @ActionBind(ExistingReserveActionType.SET_SYSTEM_TIME)
    private setAsSystemTime(data: any) {
        this.setSubmitData(data.key, data.systemTime);
    }

    /*
     * 口座残高照会
     * @param data 口座残高照会のリスポンス
     */
    @ActionBind(ExistingReserveActionType.INQUIRE_ACCOUNT_BALANCE)
    private inquireAccountBalance(data: any) {
        this.setSubmitData('swipeCardType', data.result.responseList[0].holderCardType);
    }

    /**
     * 顧客開始時間を設定する
     * @param date システム日付
     */
    @ActionBind(ExistingReserveActionType.SET_CUSTOMER_APPLY_START_DATE)
    private setCustomerApplyStartDate(date: string) {
        this.state.customerApplyStartDate = date;
        this.setSubmitData('customerApplyStartDate', date);
    }

    /**
     * 漢字名修正フラグ
     */
    @ActionBind(ExistingReserveActionType.SET_ONLY_NAME_KANJI_EDIT_FLG)
    private setEditNameKanji(date: string) {
        this.setSubmitData('editNameKanji', this.state.submitData.nameNonConvert === NameNonConvert.ON);
    }

    /**
     * 積立金受取方法を修正して、新た値が設定する前に、積立金受取方法に関連する値をサイクル指定
     */
    @ActionBind(ExistingReserveActionType.RESET_RECEIPT_RENEW_INFO)
    private resetReceiptRenewInfo() {
        // 初回受取日
        this.setSubmitData('firstReceiptDate', null);
        // 受取サイクル
        this.setSubmitData('receiptCycle', null);
    }

    /**
     * 積立金受取方法を修正して、新た値が設定する前に、積立金受取方法に関連する値を受取日指定
     */
    @ActionBind(ExistingReserveActionType.RESET_RECEIPT_SCHEDULE_INFO)
    private resetReceiptScheduleInfo() {
        // 受取指定日1
        this.setSubmitData('receiptDesignatedDate1', null);
        // 受取指定日2
        this.setSubmitData('receiptDesignatedDate2', null);
    }

    /**
     * 預入先口座と振替元口座取得
     */
    @ActionBind(ExistingReserveActionType.GET_EXISTING_ACCOUNT_INFO)
    private getExistingAccountInfo(data: any) {
        this.setSubmitData('chatControlPattern', data.chatControlPattern);
        this.setSubmitData('depositAccounts', data.depositAccounts);
        this.setSubmitData('transferAccounts', data.transferAccounts);
        this.setDepositPattern(data.chatControlPattern, data.depositAccounts);
        this.setTransferControlPattern(data.transferAccounts);
        this.sendSignal(ExistingReserveSignal.GET_EXISTING_ACCOUNT_INFO, data);
    }

    /**
     * 預入先口座と振替元口座取得
     */
    @ActionBind(ExistingReserveActionType.GET_ORDINARILY_ACCOUNT_INFO)
    private getOrdinarilyAccountInfo(data: any) {
        this.setSubmitData('transferAccounts', data.accountInfos);
        this.setTransferControlPattern(data.accountInfos);
        this.sendSignal(ExistingReserveSignal.GET_ORDINARILY_ACCOUNT_INFO, data);
    }

    @ActionBind(ExistingReserveActionType.SET_SUBMIT_DATA)
    private editSubmitData(data: { index, key, val }) {
        if (data.key) {
            // indexが存在するときに、配列のフィルドに値を入れる。
            // indexが存在しないときに、配列ではないフィルドに値を入れる
            (data.index !== undefined && data.index !== null) ?
                this.state.submitData[data.key][data.index] = data.val :
                this.state.submitData[data.key] = data.val;
        }
    }

    private setDepositPattern(chatControlPattern: string, depositAccounts: any[]) {
        switch (chatControlPattern) {
            case ChatControlPattern.PATTERN_TWO:
            case ChatControlPattern.PATTERN_FOUR:
            case ChatControlPattern.PATTERN_FIVE: {
                this.setSubmitData('depositAccountInfo', depositAccounts[0]);
                break;
            }
            case ChatControlPattern.PATTERN_SIX: {
                const depositInfo = {
                    branchNo: this.state.submitData.cardInfo.branchNo,
                    accountType: this.state.submitData.cardInfo.accountType,
                    accountTypeName: this.labelService.labels.existingReserve.depositAccount.reserveAccountType,
                    passbookTypeName: this.labelService.labels.existingReserve.depositAccount.reserve
                };
                this.setSubmitData('depositAccountInfo', depositInfo);
                break;
            }
        }
    }

    private setTransferControlPattern(transferAccounts: any[]) {
        let pattern;
        if (transferAccounts.length >= 2) {
            pattern = TransferControlPattern.ORDINARY_MULIT;
        }
        if (transferAccounts.length === 1) {
            pattern = transferAccounts[0].compoundAccountStatus === CompoundAccountStatus.YES
                ? TransferControlPattern.COMPOUND_FLAG_YES : TransferControlPattern.COMPOUND_FLAG_NO;
            this.setSubmitData('transferAccountInfo', transferAccounts[0]);
        }
        this.setSubmitData('transferControlPattern', pattern);
    }

    /**
     * 振替開始日／初回振替開始日を設定する（引数で渡された日付の翌日を設定する）
     * @param data 日付文字列
     */
    @ActionBind(ExistingReserveActionType.SET_AUTOMATIC_TRANSFER_START_DATE)
    private setAutomaticTransferStartDate(data: string) {
        const automaticTransferStartDate = moment(data).add(1, COMMON_CONSTANTS.DATE_DAY)
            .format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
        this.setSubmitData('automaticTransferStartDate', automaticTransferStartDate);
    }

    /**
     * 受付可否チェック。
     */
    @ActionBind(ExistingReserveActionType.RECEPTION_CHECK)
    private receptionCheck(data: any) {
        Object.keys(data).forEach((key) => {
            this.setSubmitData(key, data[key]);
        });
        this.sendSignal(ExistingReserveSignal.RECEPTION_CHECK);
    }

    @ActionBind(ExistingReserveActionType.RECEPTION_CHECK_TRANSFER)
    private receptionCheckTransfer(data: any) {
        Object.keys(data).forEach((key) => {
            this.setSubmitData(key, data[key]);
        });
        this.sendSignal(ExistingReserveSignal.RECEPTION_CHECK_TRANSFER);
    }

    @ActionBind(ExistingReserveActionType.RECEPTION_CHECK_DEPOSIT)
    private receptionCheckDeposit(data: any) {
        Object.keys(data).forEach((key) => {
            this.setSubmitData(key, data[key]);
        });
        this.sendSignal(ExistingReserveSignal.RECEPTION_CHECK_DEPOSIT);
    }

    @ActionBind(ExistingReserveActionType.RECEPTION_CHECK_DEPOSIT_TRANSFER)
    private receptionCheckDepositTransfer(data: any) {
        Object.keys(data.depositResponse).forEach((key) => {
            this.setSubmitData(key, data[key]);
        });
        Object.keys(data.transferResponse).forEach((key) => {
            this.setSubmitData(key, data[key]);
        });
        this.sendSignal(ExistingReserveSignal.RECEPTION_CHECK_DEPOSIT_TRANSFER);
    }

    /**
     * #24401
     * 翌営業日を取得する。
     */
    @ActionBind(ExistingReserveActionType.GET_NEXT_BUSINESS_DAY)
    private getNextBusinessDay(data: any) {
        const d = moment(data.data.nextBusinessDay).format('YYYY-MM-DD');
        this.setSubmitData('dueDate', d);
    }

    @ActionBind(ExistingReserveActionType.SUBMIT_DATA_BACKUP)
    private submitDataBackup() {
        this.state.copySubmitData = Object.assign(new ExistingReserveSubmitEntity(), this.state.submitData);
        this.state.confirmPageChanges = {};
    }

    @ActionBind(ExistingReserveActionType.UPDATA_SUBMIT_DATA_BACKUP)
    private updateSubmitDataBackup(datas: Array<{ key: string, value: string }>) {
        if (datas && datas.length > 0) {
            datas.forEach((item) => {
                this.state.confirmPageChanges[item.key] = item.value;
            });
        }
    }

    private resetIdentificationDocument(order, pageIndex) {
        const chat = this.state.questions[pageIndex].find((item) => item.order === order);
        // 本人確認書類が「住民票の写し（原本）」を選択された場合、「記載あり」→「記載なし」変更された時に、本人確認書類が「null」になることを対応
        if (chat && /@\S+にマイナンバーは記載されていますか？/.test(chat.question)) {
            const name = 'identificationDocument' + chat.question.replace(/@\S+(\d{1})\S+/, '$1');
            const filter = this.state.showChats.filter((show) => show.name === name);
            if (filter && filter.length > 0) {
                const answer = filter[filter.length - 1].answer;
                answer.value.forEach((element) => {
                    this.setSubmitData(element.key, element.value);
                });
                this.setSubmitData(name + 'Text', answer.text);
            }
        }
    }

    /**
     * マスキング未確認データから確認済の写真を削除する
     *
     * @private
     * @param {*} data
     * @memberof SavingsStore
     */
    @ActionBind(ExistingReserveActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES)
    private removeNotMaskingConfirmImages(data: any) {
        const {documentName, index} = data;
        this.state.notMaskingConfirmImages[documentName].splice(index, 1);
    }

    @ActionBind(ExistingReserveActionType.RESET_NOT_MASKING_CONFIRM_IMAGES)
    private resetNotMaskingConfirmImages(type: ClearSavingImagesClickRecordType) {
        const _documentResetFn = (documentName: string) => {
            this.state.notMaskingConfirmImages[documentName] = [];

            if (this.state.submitData[documentName]) {
                this.state.submitData[documentName].forEach(
                    (item, index) => {
                        this.state.notMaskingConfirmImages[documentName].push(index);
                    }
                );
            }
        };

        switch (type) {
            case ClearSavingImagesClickRecordType.DOCUMENT:
                // 既存写真によって、マスキング未確認データをリセット
                Object.keys(this.state.notMaskingConfirmImages).forEach(
                    (atrribute) => {
                        _documentResetFn(atrribute);
                    }
                );
                break;
            case ClearSavingImagesClickRecordType.CLEAR:
                // 本人確認書類１、本人確認書類２、住所確認書類をクリア
                Object.keys(this.state.notMaskingConfirmImages).forEach(
                    (atrribute) => {
                        this.state.notMaskingConfirmImages[atrribute] = [];
                    }
                );
                break;
            default:
                break;
        }
    }

    @ActionBind(ExistingReserveActionType.RESET_SUBMIT_DATA)
    private resetSubmitData() {
        this.state.submitData = this.state.copySubmitData;
        this.state.copySubmitData = null;
    }

    @ActionBind(ExistingReserveActionType.RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES)
    private resetSpecialNotMaskingConfirmImages(specalDocumentName: string) {
        const _documentResetFn = (documentName: string) => {
            this.state.notMaskingConfirmImages[documentName] = [];

            if (this.state.submitData[documentName]) {
                this.state.submitData[documentName].forEach(
                    (item, index) => {
                        this.state.notMaskingConfirmImages[documentName].push(index);
                    }
                );
            }
        };

        _documentResetFn(specalDocumentName);
    }

    @ActionBind(ExistingReserveActionType.CHAT_FLOW_RETURN)
    private chatFlowReturn(next: any) {
        this.sendSignal(ExistingReserveSignal.CHAT_FLOW_RETURN, next);
    }
}
