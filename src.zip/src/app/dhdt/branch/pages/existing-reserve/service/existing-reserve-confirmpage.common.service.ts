import { Injectable } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { InjectionUtils } from 'adep/utils';
import { ConfirmPageComponentParamName } from 'dhdt/branch/pages/bank-savings-deposit/service/confirmpage.common.service';
import { ChangeConfirmComponentParamName } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import { ExistingReserveAction } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { PRODUCT_TYPE } from 'dhdt/branch/shared/utils/product-category-utils';

export enum ExistingReserveConfirmType {

    TIME_TRANS_DESIGNATED_DATE = 'ExistingReserveConfirmType_TIME_TRANS_DESIGNATED_DATE',

    TIME_AMOUNT = 'ExistingReserveConfirmType_TIME_AMOUNT',
    TIME_DURATION = 'ExistingReserveConfirmType_TIME_DURATION',
    TIME_TYPE = 'ExistingReserveConfirmType_TIME_TYPE',
    TIME_PENSION_DATE = 'ExistingReserveConfirmType_TIME_PENSION_DATE',
    TIME_PENSION_AGE = 'ExistingReserveConfirmType_TIME_PENSION_AGE',
    TIME_PENSION_TYPE = 'ExistingReserveConfirmType_TIME_PENSION_TYPE',
    TIME_POSITION = 'ExistingReserveConfirmType_TIME_POSITION',
    TIME_BRANCH_NAME = 'ExistingReserveConfirmType_TIME_BRANCH_NAME',

    ORANGE_PRODUCT_NORMALMONTHTRANSFERDAY = 'ExistingReserve_ORANGE_PRODUCT_NORMALMONTHTRANSFERDAY',  // 毎月振替日 / 通常月振替日
    ORANGE_PRODUCT_NORMALMONTHTRANSFERAMOUNT = 'ExistingReserve_ORANGE_PRODUCT_NORMALMONTHTRANSFERAMOUNT',  // 毎月振替額 / 通常月振替額
    ORANGE_PRODUCT_SPECIFICTRANSFERMONTH1 = 'ExistingReserve_ORANGE_PRODUCT_SPECIFICTRANSFERMONTH1',  // 特定振替日1
    ORANGE_PRODUCT_SPECIFICTRANSFERAMOUNT1 = 'ExistingReserve_ORANGE_PRODUCT_SPECIFICTRANSFERAMOUNT1',  // 特定振替額1
    ORANGE_PRODUCT_SPECIFICTRANSFERMONTH2 = 'ExistingReserve_ORANGE_PRODUCT_SPECIFICTRANSFERMONTH2',  // 特定振替日2
    ORANGE_PRODUCT_SPECIFICTRANSFERAMOUNT2 = 'ExistingReserve_ORANGE_PRODUCT_SPECIFICTRANSFERAMOUNT2',  // 特定振替額2
    ORANGE_PRODUCT_MONTHLY = 'ExistingReserve_ORANGE_PRODUCT_MONTHLY',  // 通常月
    ORANGE_POSITION = 'ExistingReserve_ORANGE_POSITION',

    // 積立
    HOLDER_CAREER = 'ExistingReserve_HOLDER_CAREER',   // ご職業
    HOLDER_WORK_PLACE = 'ExistingReserve_HOLDER_WORK_PLACE',   // お勤め先名称
    DEPOSIT_INFO = 'ExistingReserve_DEPOSIT_INFO',  // 預入情報
    RESERVE_TRANSFER_DAY = 'ExistingReserve_RESERVE_TRANSFER_DAY',   // 毎月振替日
    RESERVE_TRANSFER_AMOUNT = 'ExistingReserve_RESERVE_TRANSFER_AMOUNT',   // 毎月振替金額
    RESERVE_ADD_TRANSFER_MONTH1 = 'ExistingReserve_RESERVE_ADD_TRANSFER_MONTH1',   // 積立金額の増額月①
    RESERVE_ADD_TRANSFER_AMOUNT1 = 'ExistingReserve_RESERVE_ADD_TRANSFER_AMOUNT1',   // 増額月積立金額①
    RESERVE_ADD_TRANSFER_MONTH2 = 'ExistingReserve_RESERVE_ADD_TRANSFER_MONTH2',   // 積立金額の増額月②
    RESERVE_ADD_TRANSFER_AMOUNT2 = 'ExistingReserve_RESERVE_ADD_TRANSFER_AMOUNT2',   // 増額月積立金額②
    RESERVE_ADD_TRANSFER_MONTH3 = 'ExistingReserve_RESERVE_ADD_TRANSFER_MONTH3',   // 積立金額の増額月③
    RESERVE_ADD_TRANSFER_AMOUNT3 = 'ExistingReserve_RESERVE_ADD_TRANSFER_AMOUNT3',   // 増額月積立金額③
    RESERVE_ADD_TRANSFER_MONTH4 = 'ExistingReserve_RESERVE_ADD_TRANSFER_MONTH4',   // 積立金額の増額月④
    RESERVE_ADD_TRANSFER_AMOUNT4 = 'ExistingReserve_RESERVE_ADD_TRANSFER_AMOUNT4',   // 増額月積立金額④
    RESERVE_ACCOUNT_OPENING_PURPOSE = 'ExistingReserve_RESERVE_ACCOUNT_OPENING_PURPOSE',   // 口座開設目的
    RESERVE_TRANSFER_ACCOUNT = 'ExistingReserve_RESERVE_TRANSFER_ACCOUNT',   // 振替元口座情報

    AMOUNT = 'ExistingReserve_AMOUNT',
    DUE_DATE = 'ExistingReserve_DUE_DATE',
    PASSBOOK_TYPE_NAME = 'ExistingReserve_PASSBOOK_TYPE_NAME',
    ACCOUNT_OPENING_PURPOSE = 'ExistingReserve_ACCOUNT_OPENING_PURPOSE',
    ORDINARY = 'ExistingReserve_ORDINARY',

}

@Injectable()
export class ExistingReserveConfirmPageCommonService extends BaseComponent {

    private action: ExistingReserveAction;
    private store: ExistingReserveStore;
    private timeDepositPageIndex: number = 98;
    private reserveDepositPageIndex: number = 99;
    private holderCareerPageIndex: number = 100;
    private periodicPageIndex: number = 101;

    constructor() {
        super();
        this.action = InjectionUtils.injector.get(ExistingReserveAction);
        this.store = InjectionUtils.injector.get(ExistingReserveStore);
    }

    /**
     * Load template
     * @param existing existing or not
     */
    public loadConfirmTemplate(isTimeDeposit: boolean = false) {
        if (isTimeDeposit) {
            this.action.loadConfirmPageTemplate('chat-flow-def-time-deposit-modify.yml', this.timeDepositPageIndex);
        } else {
            this.action.loadConfirmPageTemplate('chat-flow-def-reserve-deposit-modify.yml', this.reserveDepositPageIndex);
        }
        this.action.loadConfirmPageTemplate('chat-flow-def-holder-career-modify.yml', this.holderCareerPageIndex);
        this.action.loadConfirmPageTemplate('chat-flow-def-existing-regular-select-product-confirmation.yml', this.periodicPageIndex);
    }

    // time
    public getTimeParams() {
        const params: Map<string, any> = new Map();
        const info = this.getAmountInfo();

        // 処理日
        params.set(ExistingReserveConfirmType.TIME_TRANS_DESIGNATED_DATE,
            {
                startOrder: 100, endOrder: 101, name: 'transDesignatedDate',
                currentTitle: this.labels.confirm.transDesignatedDate, pageIndex: this.timeDepositPageIndex
        });

        // 支店名
        params.set(ExistingReserveConfirmType.TIME_BRANCH_NAME,
            {
                startOrder: 111, endOrder: 119, name: 'branchName',
                currentTitle: this.labels.confirm.product.branchName, pageIndex: this.timeDepositPageIndex
            });
        // 口座開設店舗
        params.set(ConfirmPageComponentParamName.OPENSTORE_SHOWCHART,
            {
                startOrder: 9950, endOrder: 9953, name: 'branchNameKanji',
                currentTitle: this.labels.selectBranch.branchName, pageIndex: this.timeDepositPageIndex
            });
        // ご職業
        params.set(ExistingReserveConfirmType.HOLDER_CAREER,
            {
                startOrder: 108, endOrder: 110, name: 'holderCareer',
                currentTitle: this.labels.confirm.customerInfo.career, pageIndex: this.timeDepositPageIndex
            });

        // 預入情報
        params.set(ExistingReserveConfirmType.DEPOSIT_INFO,
            {
                startOrder: 1061, endOrder: 1063, name: 'depositMethod',
                currentTitle: this.labels.confirm.deposit.method, pageIndex: this.timeDepositPageIndex
            });

        // 口座開設時預金額
        params.set(ExistingReserveConfirmType.AMOUNT,
            {
                startOrder: 330, endOrder: 330, name: 'amount',
                currentTitle: this.labels.existingReserve.depositInfo.amount, pageIndex: this.periodicPageIndex
            });

        // 預入期間（満期日）
        params.set(ExistingReserveConfirmType.DUE_DATE,
            {
                startOrder: 349, endOrder: 349, name: 'depositPeriodYearMonth',
                currentTitle: this.labels.existingReserve.depositInfo.dueDate, pageIndex: this.periodicPageIndex
            });

        // 通帳種類
        params.set(ExistingReserveConfirmType.PASSBOOK_TYPE_NAME,
            {
                startOrder: 160, endOrder: 280, name: 'depositAccountInfo',
                currentTitle: this.labels.existingReserve.depositInfo.accountName, pageIndex: this.periodicPageIndex
            });

        // 口座開設目的
        params.set(ExistingReserveConfirmType.ACCOUNT_OPENING_PURPOSE,
            {
                startOrder: 90, endOrder: 90, name: 'accountOpeningPurpose',
                currentTitle: this.labels.confirm.accountInfo.accountPurpose, pageIndex: this.holderCareerPageIndex
            });

        // 振替元口座情報ー通帳種類
        params.set(ExistingReserveConfirmType.ORDINARY,
            {
                startOrder: 270, endOrder: 300, name: 'transferAccountInfo',
                currentTitle: this.labels.existingReserve.depositInfo.accountName, pageIndex: this.periodicPageIndex
            });

        return params;
    }

    // existing 積立
    public getExistingParams() {
        const params: Map<string, any> = new Map();

        /** --------------------積立預金----------------------- */
        // 毎月振替日
        params.set(ExistingReserveConfirmType.RESERVE_TRANSFER_DAY,
            {
                startOrder: 20, endOrder: 23, name: 'transferDay',
                currentTitle: this.labels.existingReserve.depositInfo.transferDay, pageIndex: this.reserveDepositPageIndex
            });
        // 毎月振替金額
        params.set(ExistingReserveConfirmType.RESERVE_TRANSFER_AMOUNT,
            {
                startOrder: 30, endOrder: 160, name: 'addedTransferMonth1',
                currentTitle: this.labels.existingReserve.depositInfo.transferAmount, pageIndex: this.reserveDepositPageIndex
            });
        // 積立金額の増額月①
        params.set(ExistingReserveConfirmType.RESERVE_ADD_TRANSFER_MONTH1,
            {
                startOrder: 30, endOrder: 160, name: 'addedTransferMonth1',
                currentTitle: this.labels.existingReserve.depositInfo.addedTransferMonth1, pageIndex: this.reserveDepositPageIndex
            });
        // 口座開設目的
        params.set(ExistingReserveConfirmType.RESERVE_ACCOUNT_OPENING_PURPOSE,
            {
                startOrder: 170, endOrder: 170, name: 'accountOpeningPurpose',
                currentTitle: this.labels.confirm.accountInfo.accountPurpose, pageIndex: this.reserveDepositPageIndex
            });
        // 振替元口座情報
        params.set(ExistingReserveConfirmType.RESERVE_TRANSFER_ACCOUNT,
            {
                startOrder: 270, endOrder: 280, name: 'transferAccountInfo',
                currentTitle: this.labels.existingReserve.depositInfo.transferAccountInfo, pageIndex: this.reserveDepositPageIndex
            });

        return params;
    }

    public getHolderCareerParams() {
        const params = new Map();
        params.set(ChangeConfirmComponentParamName.HOLDER_CAREER,
            {
                startOrder: 80, endOrder: 81, name: 'holderCareer',
                currentTitle: this.labels.confirm.customerInfo.career, pageIndex: this.holderCareerPageIndex
            });
        return params;
    }

    /**
     * Get amount info
     */
    private getAmountInfo(): any | null {
        let startOrder;
        const type = this.store.getState().submitData.selectProductType || null;
        if (!type) {
            return null;
        }
        switch (type) {
            case PRODUCT_TYPE.SUPER: {
                startOrder = { amount: 1001, duration: 10211, type: 103 };
                break;
            }
            case PRODUCT_TYPE.BIG_MOUTH: {
                startOrder = { amount: 1002, duration: 10211, type: 103 };
                break;
            }
            case PRODUCT_TYPE.CHILD: {
                startOrder = { amount: 2015, type: 103 };
                break;
            }
            case PRODUCT_TYPE.MADONNA: {
                startOrder = { amount: 1003, duration: 10212, type: 103 };
                break;
            }
            case PRODUCT_TYPE.HAPPINESS1: {
                startOrder = { amount: 4001, pensionDate: 4002, pensionAge: 4003, pensionType: [4004, 4005] };
                break;
            }
            case PRODUCT_TYPE.HAPPINESS2: {
                startOrder = { amount: 5001 };
                break;
            }
            case PRODUCT_TYPE.POINT: {
                startOrder = { amount: 6001 };
                break;
            }
        }
        return startOrder;
    }
}
