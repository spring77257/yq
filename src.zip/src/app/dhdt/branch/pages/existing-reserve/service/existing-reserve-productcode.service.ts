import { Injectable } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { COMMON_CONSTANTS } from '../../common/branch-tablet-consts';

@Injectable()
export class ExistingReserveProductcodeService {

    private store: ExistingReserveStore;

    constructor() {
        this.store = InjectionUtils.injector.get(ExistingReserveStore);
    }

    /**
     * 商品コードを取得する
     * @returns
     */
    public getProductCode() {

        // 選択商品
        const product = this.store.getState().submitData.selectProductType;

        if ('01' === product) {
            // 申込商品が 01:スーパー定期預金
            return this.getSuperCode();
        } else if ('02' === product) {
            // 申込商品が 02:退職金専用プラン
            return this.getSeverancePayCode();
        } else if ('03' === product) {
            // 申込商品が 03:資産運用パッケージ
            return this.getAssetManagementCode();
        } else if ('04' === product) {
            // 申込商品が 04:相続定期預金
            return this.getInheritanceTimeDepositCode();
        } else if ('05' === product) {
            // 申込商品が 05:お誕生日定期
            return this.getBirthdayTimeDepositCode();
        } else if ('06' === product) {
            // 申込商品が 06:株主優待
            // 1132:株主優待 特別金利定期
            return '1132';
        }

        return '';
    }

    /**
     * 入金金額が10Mを超えてないことをチェック。
     *
     * @param value
     * @returns
     */
    private checkLess10M(value) {
        return 10000000 > value;
    }

    /**
     * 「スーパー定期預金」の商品コードを返却。
     */
    private getSuperCode() {
        return '1101';
    }

    /**
     * 「退職金専用プラン」の商品コードを返却。
     * @returns
     */
    private getSeverancePayCode() {

        // 投信購入金額（退職金専用プランのみ）
        const investOver5M = this.store.getState().submitData.isInvestmentTrustOver5m;
        // 預入金額
        const depositAmount = this.store.getState().submitData.amount;

        // 申込商品が 02:退職金専用プラン
        if ('1' === investOver5M && this.checkLess10M(depositAmount)) {
            // 500万円以上 10,000,000円未満 1152
            return '1152';
        } else if ('1' === investOver5M && !this.checkLess10M(depositAmount)) {
            // 500万円以上 10,000,000円以上 1153
            return '1153';
        } else {
            // 500万円未満 金額問わず 1172
            return '1172';
        }
    }

    /**
     * 「資産運用パッケージ」の商品コードを返却。
     *
     * @returns
     */
    private getAssetManagementCode() {
        // 選択コース
        const course = this.store.getState().submitData.applicationCourseAssetMgmt;
        // 預入金額
        const depositAmount = this.store.getState().submitData.amount;

        if ('03' === course) {
            // 申込コース（資産運用パッケージ）が 03:投信自動積立コース
            // 1164:資産運用パッケージ 投信自動積立コース
            return '1164';
        } else if ('04' === course) {
            // 申込コース（資産運用パッケージ）が 04:基本コース
            // 1160:資産運用パッケージ 基本コース
            return '1160';
        } else if ('05' === course && this.checkLess10M(depositAmount)) {
            // 申込コース（資産運用パッケージ）が 05:大口コース
            // 入金金額が「10,000,000」未満の場合、
            // 1168:資産運用パッケージ 大口コース（10M未満）
            return '1168';
        } else if ('05' === course && !this.checkLess10M(depositAmount)) {
            // 申込コース（資産運用パッケージ）が 05:大口コース
            // 入金金額が「10,000,000」以上の場合、
            // 1169:資産運用パッケージ 大口コース（10M以上）
            return '1169';
        } else if ('06' === course && this.checkLess10M(depositAmount)) {
            // 申込コース（資産運用パッケージ）が 06:ご新規大口コース
            // 入金金額が「10,000,000」未満の場合、
            // 1170:資産運用パッケージ ご新規大口コース（10M未満）
            return '1170';
        } else if ('06' === course && !this.checkLess10M(depositAmount)) {
            // 申込コース（資産運用パッケージ）が 06:ご新規大口コース
            // 入金金額が「10,000,000」以上の場合、大口定期、
            // 1171:資産運用パッケージ ご新規大口コース（10M以上）
            return '1171';
        }
        return '';
    }

    /**
     * 「相続定期預金」の商品コードを返却。
     *
     * @returns
     */
    private getInheritanceTimeDepositCode() {

        // 預入金額
        const depositAmount = this.store.getState().submitData.amount;

        if (this.checkLess10M(depositAmount)) {
            // 入金金額が「10,000,000」未満の場合、
            // 1140:相続定期預金（10M未満）
            return '1140';
        } else {
            // 入金金額が「10,000,000」以上の場合、大口定期、
            // 1141:相続定期預金（10M以上）
            return '1141';
        }
    }

    /**
     * 「お誕生日定期」の商品コードを返却。
     *
     * @returns
     */
    private getBirthdayTimeDepositCode() {
        // 選択コース
        const course = this.store.getState().submitData.applicationCourseBirthday;
        if ('01' === course) {
            // 申込コース（お誕生日定期）が 01:公的年金を受給中の方
            // 1121:お誕生日定期 公的年金を受給中の方
            return '1121';
        } else if ('02' === course) {
            // 申込コース（お誕生日定期）が 02:公的年金を受給前の方
            // 1122:お誕生日定期 公的年金を受給前の方
            return '1122';
        } else if ('03' === course) {
            // 申込コース（お誕生日定期）が 03:その他の方
            // 1123:お誕生日定期 その他の方
            return '1123';
        }
        return '';
    }
}
