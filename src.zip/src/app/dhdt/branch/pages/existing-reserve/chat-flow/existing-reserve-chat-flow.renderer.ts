import { EventEmitter, Output, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { InjectionUtils } from 'adep/utils';
import { ExistingReserveAction } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { ExistingReserveQuestionsModel } from 'dhdt/branch/pages/existing-reserve/entity/existing-reserve-questions.model';
import { ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { Content } from 'ionic-angular';

export interface OnRenderer {
    onText?(entity: ExistingReserveQuestionsModel, pageIndex: number): void;
    onButton?(entity: ExistingReserveQuestionsModel, pageIndex: number): void;
    onKeybord?(entity: ExistingReserveQuestionsModel, pageIndex: number): void;
    onNumberKeybord?(entity: ExistingReserveQuestionsModel, pageIndex: number): void;
    onRoute?(entity: ExistingReserveQuestionsModel, pageIndex: number): void;
    onJudge?(entity: ExistingReserveQuestionsModel, pageIndex: number): void;
}

/**
 * chat flow renderer.
 */
export abstract class ExistingReserveChatFlowRenderer extends BaseComponent implements OnRenderer {
    public abstract processType: number;
    public _action: ExistingReserveAction;
    public _store: ExistingReserveStore;
    @Output() public nextChatEvent = new EventEmitter();
    @ViewChild(Content) public content: Content;

    constructor() {
        super();
        this._action = InjectionUtils.injector.get(ExistingReserveAction);
        this._store = InjectionUtils.injector.get(ExistingReserveStore);
    }

    public abstract loadTemplate(pageIndex: number);

    public onText(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        this.getNextChat(entity.next, pageIndex);
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onButton');
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onKeybord');
    }

    /**
     * Numberキーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onNumberKeybord(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onNumberKeybord');
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onJudge');
    }

    /**
     * Called when message type is 'picker'
     * Should be override in sub classes
     * @param entity params
     * @param pageIndex index in current chat flow
     */
    public onPicker(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onPicker');
    }

    /**
     * Called when message type is 'select street'
     * Should be override in sub classes
     * @param entity params
     * @param pageIndex index in current chat flow
     */
    public onSelectStreet(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onSelectStreet');
    }

    /**
     * Called when message type is 'needpassword'
     * Should be override in sub classes
     * @param entity params
     * @param pageIndex index in current chat flow
     */
    public onPassword(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onPassword');
    }

    /**
     * チャットのtype属性についてハンドリング。
     * @param question チャットの質問
     * @param pageIndex ページ番号
     */
    public rendererComponents(question: ExistingReserveQuestionsModel, pageIndex: number) {
        switch (question.type) {
            case 'text': {
                this.onText(question, pageIndex);
                break;
            }
            case 'button': {
                this.onButton(question, pageIndex);
                break;
            }
            case 'image': {
                this.getNextChat(question.next, pageIndex);
                break;
            }
            case 'judge': {
                this.onJudge(question, pageIndex);
                break;
            }
            case 'keybord': {
                this.onKeybord(question, pageIndex);
                break;
            }
            case 'numberKeybord': {
                this.onNumberKeybord(question, pageIndex);
                break;
            }
            case 'route': {
                this.chatFlowCompelete(question.example);
                this.getNextChat(question.next, pageIndex);
                break;
            }
            case 'selectStreet': {
                this.onSelectStreet(question, pageIndex);
                break;
            }
            case 'prefecturePicker':
            case 'countyUrbanVillagePicker': {
                this.onPicker(question, pageIndex);
                break;
            }
            case 'needpassword': {
                this.onPassword(question, pageIndex);
                break;
            }
        }
    }

    protected getNextChat(order: number, pageIndex: number, nextChatDelay?: number) {
        this.nextChatEvent.emit({ order: order, pageIndex: pageIndex, nextChatDelay: nextChatDelay });
    }

    protected setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this._action.setAnswer(answer);
    }

    protected chatFlowCompelete(nextChatName?: string) {
        this._action.chatFlowCompelete(nextChatName);
    }
}
