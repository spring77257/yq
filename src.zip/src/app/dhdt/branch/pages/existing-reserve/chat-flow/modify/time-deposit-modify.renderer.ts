import { ViewContainerRef } from '@angular/core';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ExistingReserveChatFlowAccessor } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.accessor';
import { ExistingReserveChatFlowRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.renderer';
import { ExistingReserveQuestionsModel } from 'dhdt/branch/pages/existing-reserve/entity/existing-reserve-questions.model';
import { ExistingReserveState, ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import * as moment from 'moment';

export class TimeDepositModifyRenderer extends ExistingReserveChatFlowRenderer {
    public processType = -1;

    private state: ExistingReserveState;

    constructor(
        private chatFlowAccessor: ExistingReserveChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: ExistingReserveStore) {
        super();
        this.state = this.store.getState();

    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadConfirmPageTemplate('chat-flow-def-time-deposit-modify.yml', pageIndex);
    }

    /**
     * チャットのtype属性についてハンドリング。
     * @param question チャットの質問
     * @param pageIndex ページ番号
     */
    public rendererComponents(question: ExistingReserveQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'datepicker': {
                this.onPicker(question, pageIndex);
                break;
            }
        }
    }

    public onPicker(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }

        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData,
            today: customerApplyStartDate
        };
        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }
}
