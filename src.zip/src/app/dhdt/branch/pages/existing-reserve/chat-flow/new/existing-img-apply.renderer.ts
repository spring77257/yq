import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { DeviceService } from 'dhd/common/services/device.service';
import { ChangeConfirmComponent } from 'dhdt/branch/pages/change/view/change-confirm.component';
import { COMMON_CONSTANTS, Constants, CoreBankingConst } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingReserveChatFlowAccessor } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.accessor';
import { ExistingReserveChatFlowRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.renderer';
import { ExistingReserveQuestionsModel } from 'dhdt/branch/pages/existing-reserve/entity/existing-reserve-questions.model';
import { Consts } from 'dhdt/branch/pages/existing-reserve/existing-reserve-consts';
import {
    ExistingReserveState,
    ExistingReserveStore
} from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { ProductCategoryUtils } from 'dhdt/branch/pages/existing-reserve/utils/product-category-utils';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { SelectProductComponent } from 'dhdt/branch/shared/components/select-product/select-product.component';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { ModalController, NavController } from 'ionic-angular';
import { ButtonCameraComponent } from '../../../../shared/components/button-group/button-camera.component';

/**
 * Self Check apply component(情報入力画面（本人確認書類聴取）).
 */
export class ExistingImgapplyRenderer extends ExistingReserveChatFlowRenderer {

    public processType = -1;
    public options: {
        category: number
    } = {category: 0};

    private loginStore: LoginStore;
    private state: ExistingReserveState;
    private modalService: ModalService;

    constructor(private chatFlowAccessor: ExistingReserveChatFlowAccessor,
                private footerContent: ViewContainerRef,
                private store: ExistingReserveStore,
                private navCtrl: NavController,
                private deviceService: DeviceService,
                private modalCtrl: ModalController) {
        super();
        this.state = this.store.getState();
        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.modalService = InjectionUtils.injector.get(ModalService);
        this.options.category = this.state.submitData.category;
    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-existing-imgapply.yml', pageIndex);
    }

    /**
     * チャットのtype属性についてハンドリング。
     * @param question チャットの質問
     * @param pageIndex ページ番号
     */
    public rendererComponents(question: ExistingReserveQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'cameraButton': {
                this.onCameraButton(question, pageIndex);
                break;
            }
        }
    }

    public onCameraButton(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options: any = {
            saveFrontPhotoKey: 'holderCardImageFront',
            saveBackPhotoKey: 'holderCardImageBack',
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        // 写真を取ろうする書類の格納変数の値を取得
        const currentImg = this.state.submitData[this._store.documentMap.get(this.options.category)];
        // 書類に写真が存在する場合は、skipを渡す
        if (currentImg && currentImg.length > 0 && entity.skip) {
            options.skip = entity.skip;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonCameraComponent, this.footerContent, options
            ).subscribe((answer: any) => {
            if (answer === 'skip') {
                this.setAnswer({
                    text: 'スキップ',
                    value: undefined
                });

                this.chatFlowAccessor.clearComponent();
                this.getNextChat(entity.skip, pageIndex);
            } else {
                if (answer.image) {
                    this._action.saveIdentityDocumentImage({
                        image: answer.image,
                        category: this.options.category
                    });
                }

                if (answer.chatFlowChoice.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.chatFlowChoice.next, pageIndex);
                }
            }
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                if (entity.name === 'addIdentityDocumentImg' && answer.value === '1') {
                    const choice = entity.choices ? entity.choices.find((item) => item.value === answer.value) : undefined;
                    this._action.resetLastNode({
                        order: choice ? choice.next : entity.order,
                        pageIndex: pageIndex
                    });
                } else {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * 商品選択コンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSelectProduct(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(this.labels.product.data, SelectProductComponent, this.footerContent, options)
            .subscribe((answer) => {
                this.setAnswer({
                    text: answer.name,
                    value: [
                        { key: entity.name, value: answer.category },
                        { key: Consts.SELECT_PRODUCT_NAME, value: ProductCategoryUtils.getProductName(answer.category) }
                    ]
                });
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });

                        const resetResultList = InputUtils.holderNameReset(entity.name, this.state.submitData);
                        if (resetResultList) {
                            this._action.setStateSubmitDataValue(resetResultList);
                        }
                        this.getNextChat(entity.next, pageIndex);
                    });
                }
            });
    }

    /**
     * メモリにの値を判断する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        if (entity.name === 'checkDocumentCategory') {
            const choice = entity.choices.find((item) => item.value === this.options.category);
            if (choice) {
                this.getNextChat(choice.next, pageIndex);
            }
        } else if (entity.name === 'checkDocumentType') {
            const choice = entity.choices.find((item) => {
                if (this.options.category === Constants.IdentityDocumentCategory.Document1) {
                    if (this.state.submitData.identificationDocument1 === Constants.MyNumberCard) {
                        return item.value;
                    }
                }
                return !item.value;
            });
            if (choice) {
                this.getNextChat(choice.next, pageIndex);
            }
        }
    }

    /**
     * パスワードモーダルを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onPassword(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            terminalNo: this.deviceService.getDeviceId(),
            accountNo: this.state.submitData.swipeAccountNo,
            tenban: this.state.submitData.swipeBranchNo,
            accountType: this.state.submitData.swipeAccountType
        };

        this.modalService.showModal(COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_VERIFICATION,
            {
                text: this.labels.password.inputPasswordText,
                subText: this.labels.password.inputPasswordSubText,
                units: 4,
                needConfirm: false,
                cashcardParams: param
            }, (result) => {
                if (result) {
                    this.showConfirmPage(entity.next, pageIndex, result, entity.skip);
                }
            });
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            const info = {
                passwordType: this.labels.existingSavings.passwordModalInfo1,
                subPasswordType: this.labels.existingSavings.passwordModalInfo
            };
            this.modalService.showModal(action.value, info, (result) => {
                this.showConfirmPage(choice.next, pageIndex, result);
            });
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }

    /**
     * 確認ページを表示する
     * @param next 次ノードのオーダー
     * @param pageIndex ページ番号
     */
    private showConfirmPage(next: number, pageIndex: number, result: any, skip?: number) {
        // CIF情報照会ハンドル
        const cifParam: SimpleCifInfoInquiryInterface = {
            path: CoreBankingConstants.ApiPathConsts.CIF_INFO_INQUIRY,
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            params: {
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                tenban: this.state.submitData.swipeBranchNo,
                accountNo: this.state.submitData.swipeAccountNo,
                accountType: this.state.submitData.swipeAccountType
            }
        };

        const inputParams = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            swipeCif: this.state.submitData.swipeCif || '1234567',
            branchNo: this.state.submitData.swipeBranchNo || '123',
            accountNo: this.state.submitData.swipeAccountNo || '1234567',
            accountType: this.state.submitData.swipeAccountType,
            receptionBranchNo: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            receptionTime: this.state.submitData.receptionTime,
            password: result,
        };

        this.chatFlowAccessor.clearComponent();
        this.navCtrl.push(
            ChangeConfirmComponent,
            {
                type: COMMON_CONSTANTS.BusinessFlowType.ExistingReserve,
                processType: COMMON_CONSTANTS.ProcessType.RequiredInput,
                cifParam: cifParam,
                inputParams: inputParams,
                callBack: () => {
                    this._action.getCifInformation(cifParam, inputParams, next, pageIndex, skip);
                }
            },
            { animate: false }
        );
    }
}
