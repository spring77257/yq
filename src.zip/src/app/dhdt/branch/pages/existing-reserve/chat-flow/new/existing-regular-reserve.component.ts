import { ViewContainerRef } from '@angular/core';
import { COMMON_CONSTANTS, RequestType, YearCalculation } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingReserveChatFlowAccessor } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.accessor';
import { ExistingReserveChatFlowRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.renderer';
import { ExistingReserveQuestionsModel } from 'dhdt/branch/pages/existing-reserve/entity/existing-reserve-questions.model';
import {
    ExistingReserveSignal, ExistingReserveState, ExistingReserveStore
} from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import {
    ExistingReserveSelfConfirmationComponent
} from 'dhdt/branch/pages/existing-reserve/view/existing-reserve-self-confirmation.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { MonthInputComponent } from 'dhdt/branch/shared/components/month-input/month-input.component';
import { PayoutAccountComponent } from 'dhdt/branch/shared/components/payout-account/view/payout-account.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { QuantityInputComponent } from 'dhdt/branch/shared/components/quantity-input/quantity-input.component';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { PRODUCT_TYPE } from 'dhdt/branch/shared/utils/product-category-utils';
import { NavController } from 'ionic-angular';
import * as moment from 'moment';

/**
 * Regular reserve component(情報入力画面（積立定期預金）).
 */
export class ExistingRegularReserveComponent extends ExistingReserveChatFlowRenderer {
    public processType = 1;

    private state: ExistingReserveState;
    private readonly TRANSFER: string = '03';

    constructor(
        private chatFlowAccessor: ExistingReserveChatFlowAccessor, private footerContent: ViewContainerRef,
        private store: ExistingReserveStore, private modalService: ModalService,
        public navCtrl: NavController, private loginStore: LoginStore) {
        super();
        this.state = this.store.getState();
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-existing-regular-reserve.yml', pageIndex);
    }

    public rendererComponents(question: ExistingReserveQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'buttonThreeCols': {
                this.onButton(question, pageIndex);
                break;
            }
            case 'yearPicker':
            case 'monthpicker':
            case 'daypicker':
            case 'datepicker':
            case 'picker': {
                this.onPicker(question, pageIndex);
                break;
            }
            case 'selectMonth': {
                this.onSelectMonth(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_NUMBER_THOUSAND: {
                this.onQuantityInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_REQUEST: {
                this.onRequest(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECT_PAYOUT_ACCOUNT: {
                this.onSelectPayoutAccount(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_ACCOUNTSHOP: {
                this.getNextChat(question.next, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_COMPLETE: {
                this.onComplete(question, pageIndex);
                break;
            }
        }
    }

    public onComplete(entity: ExistingReserveQuestionsModel, pageIndex: number) {
        this.navCtrl.setRoot(ExistingReserveSelfConfirmationComponent);
    }

    /**
     * 口座表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onSelectPayoutAccount(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(
            { data: this.state.submitData[entity.example] || [] },
            PayoutAccountComponent,
            this.footerContent,
            options
        ).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            if (answer) {
                this.setAnswer({
                    text: answer.text,
                    value: [{
                        key: entity.name,
                        value: answer.value
                    },
                    ]
                });
            }
            this._store.registerSignalHandler(ExistingReserveSignal.RECEPTION_CHECK, () => {
                this._store.unregisterSignalHandler(ExistingReserveSignal.RECEPTION_CHECK);
                this.getNextChat(entity.next, pageIndex);
            });
            const param = {
                tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                params: {
                    receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                    tenban: answer.value.branchNo, // 店番
                    accountType: answer.value.accountType, // 科目
                    accountNo: answer.value.accountNo, // 口座番号
                    businessCode: entity.options.businessCode, // 業務コード
                }
            };
            this._action.receptionCheck(param);
        });
    }

    /**
     * Send request
     * @param entity entity
     * @param pageIndex pageIndex
     */
    public onRequest(entity: ExistingReserveQuestionsModel, pageIndex: number) {
        switch (entity.name) {
            // 普通預金口座情報照会取得
            case RequestType.EXISTING_ACCOUNT_LIST: {
                this.getOrdinarilyAccountInfo(entity, pageIndex);
                break;
            }
        }
    }

    /**
     * 普通預金口座情報照会取得
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public getOrdinarilyAccountInfo(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        this._store.registerSignalHandler(ExistingReserveSignal.RECEPTION_CHECK, () => {
            this._store.unregisterSignalHandler(ExistingReserveSignal.RECEPTION_CHECK);
            this.getNextChat(entity.next, pageIndex, 0);
            return;
        });
        this.store.registerSignalHandler(ExistingReserveSignal.GET_ORDINARILY_ACCOUNT_INFO, (data) => {
            this.store.unregisterSignalHandler(ExistingReserveSignal.GET_ORDINARILY_ACCOUNT_INFO);
            if (data.accountInfos.length === 1) {
                const params = {
                    tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                    params: {
                        receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                        tenban: data.accountInfos[0].branchNo, // 店番
                        accountType: data.accountInfos[0].accountType, // 科目
                        accountNo: data.accountInfos[0].accountNo, // 口座番号
                        businessCode: this.TRANSFER, // 業務コード
                    }
                };
                this._action.receptionCheck(params);
            } else {
                this._store.unregisterSignalHandler(ExistingReserveSignal.RECEPTION_CHECK);
                this.getNextChat(entity.next, pageIndex, 0);
            }
            return;
        });
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                customerId: this.state.submitData.customerId
            }
        };
        this._action.getOrdinarilyAccountInfo(param);
    }

    public onButton(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            maxColNum: (entity.type === 'buttonThreeCols') ? 3 : entity.maxColNum,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        const monthly: string[] = ['addedTransferMonth1', 'addedTransferMonth2', 'addedTransferMonth3', 'addedTransferMonth4'];

        if (monthly.indexOf(entity.name) > 0) {
            entity.choices.forEach((item: any) => {
                // 状態をクリア
                item.options = undefined;
                monthly.forEach((selectMonth: any) => {
                    if (this.state.submitData[selectMonth] === item.value) {
                        item.options = {
                            cssClass: 'disabled-button',
                        };
                    }
                });
            });
        }

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
            .subscribe((answer) => {
                if (entity.name.length > 0 && answer.value.length > 0) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.text }
                        ]
                    });
                }

                if (answer.action.type.length > 0) {
                    this.configAction(answer);
                } else if (answer.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.next, pageIndex);
                }
            });
    }

    public onPicker(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else if (entity.name === COMMON_CONSTANTS.CHILDERN_BIRTHDATE
            && this.state.submitData.selectProductType === PRODUCT_TYPE.LOVE) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .startOf(COMMON_CONSTANTS.DATE_YEAR)
                    .endOf(COMMON_CONSTANTS.DATE_MONTH)
                    .subtract(YearCalculation.LOVE_MAX_AGE, COMMON_CONSTANTS.DATE_YEAR)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                max: moment(customerApplyStartDate)
                    .add(1, COMMON_CONSTANTS.DATE_DAY)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }
        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            currentYear: Number(moment(customerApplyStartDate).format(COMMON_CONSTANTS.DATE_FORMAT_YYYY)),
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData
        };
        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onKeybord(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    this.getNextChat(entity.next, pageIndex);
                });
            });
    }

    public onJudge(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        if (entity.name === 'getFirstAccumulationDate') {
            this._store.registerSignalHandler(ExistingReserveSignal.FIRST_TRANSFER_DAY, () => {
                this._store.unregisterSignalHandler(ExistingReserveSignal.FIRST_TRANSFER_DAY);
                this.getNextChat(entity.next, pageIndex, 0);
            });
            this._action.getFirstAccumulationDate();
        } else if (entity.choices) {
            // choiceに当たる内容あるかどうかフラグ true:ある　fasle:なし
            let hasChoiceFlg = false;

            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.getNextChat(choice.next, pageIndex, 0);
                    hasChoiceFlg = true;
                    return;
                }
            });

            // judgeが失敗しました、当たらないです
            // chat entityの名前はtransferControlPatternの場合、アラートを出します
            if (entity.name === 'transferControlPattern' && !hasChoiceFlg) {
                const buttonList = [
                    { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
                ];
                this.modalService.showWarnAlert(
                    this.labels.alert.noTransferAccount,
                    buttonList, () => {
                        // 何もしない
                    }
                );
            }
        }
    }

    public onSelectMonth(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, MonthInputComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer({
                text: answer.text,
                value: entity.choices.map((choice) => {
                    return { key: choice.name, value: answer.value[choice.name] };
                })
            });
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * 千円以上の金額入力コンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onQuantityInput(entity: ExistingReserveQuestionsModel, pageIndex: number): void {

        const options = {
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            title: entity.options ? entity.options.title : undefined,
            unit: entity.options ? entity.options.unit : undefined,
            validationRules: entity.validationRules
        };

        let data: any[] = entity.choices;
        if (entity.name.includes('addedTransferAmount')) {
            data = [{
                name: entity.choices[0].name,
                placeholder: entity.choices[0].placeholder,
                validationRules: {
                    required: entity.choices[0].validationRules.required,
                    regex: entity.choices[0].validationRules.regex,
                    max: entity.choices[0].validationRules.max,
                    min: entity.choices[0].validationRules.min,
                    maxValue: entity.choices[0].validationRules.maxValue,
                    minValue: Number(this.state.submitData.transferAmount) + 1
                }
            }];
        }

        this.chatFlowAccessor.addComponent(data, QuantityInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    private configAction(choice: any) {
        const action = choice.action;
        if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }

}
