import {
    AfterViewChecked, animate, ChangeDetectorRef,
    Component, ElementRef, OnDestroy, OnInit, state,
    style, transition, trigger, ViewChild, ViewContainerRef
} from '@angular/core';
import { BaseComponent } from 'adep/components';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import { Age, ChatFlowChoicesValue, COMMON_CONSTANTS, Constants,
    CoreBankingConst, OtherProductFlag } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ExistingReserveAction } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { ExistingReserveChatFlowAccessor } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.accessor';
import { ExistingReserveChatFlowRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.renderer';
import {
    ExistingAddressIdentificationRenderer
} from 'dhdt/branch/pages/existing-reserve/chat-flow/new/existing-address-identification.renderer';
import { ExistingCheckApplyRender } from 'dhdt/branch/pages/existing-reserve/chat-flow/new/existing-check-apply.render';
import {
    ExistingIdentificationDocumentOneRender
} from 'dhdt/branch/pages/existing-reserve/chat-flow/new/existing-identification-documentOne.render';
import {
    ExistingIdentificationDocumentTwoRender
} from 'dhdt/branch/pages/existing-reserve/chat-flow/new/existing-identification-documentTwo.render';
import { ExistingImgapplyRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/new/existing-img-apply.renderer';
import { ExistingRegularDoubleLiveRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/new/existing-regular-double-live.renderer';
import {
    ExistingRegularSelectProductRenderer
} from 'dhdt/branch/pages/existing-reserve/chat-flow/new/existing-regular-select-product.renderer';
import {
    ExistingReserveVerificationRenderer
} from 'dhdt/branch/pages/existing-reserve/chat-flow/new/existing-reserve-verification.renderer';
import { Consts } from 'dhdt/branch/pages/existing-reserve/existing-reserve-consts';
import {
    ExistingReserveSignal, ExistingReserveState, ExistingReserveStore
} from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { ProductCategoryUtils } from 'dhdt/branch/pages/existing-reserve/utils/product-category-utils';
import {
    AccountModalPasswordComponent
} from 'dhdt/branch/shared/components/modal/modal-password/view/account-modal-password.component';
import {
    ModalPlanConfirmationComponentProvider
} from 'dhdt/branch/shared/components/modal/modal-plan-confirmation/modal-plan-confirmation.component';
import { AccountBalanceInquiryInterface } from 'dhdt/branch/shared/interface/account-balance-inquiry.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { LicenseService } from 'dhdt/branch/shared/services/license.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { Content, ModalController, NavController, NavParams, ViewController } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';
import { ExistingRegularReserveComponent } from './new/existing-regular-reserve.component';

@Component({
    selector: 'existing-reserve-chat-component',
    templateUrl: 'existing-reserve-chat.component.html',
    animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateY(0)' })),
            state('out', style({ transform: 'translateY(0)' })),
            transition('out => in', [
                style({ transform: 'translateY(100%)' }),
                animate('0.3s  ease-in')
            ]),
            transition('in => out', [
                style({ transform: 'translateY(-100%)' }),
                animate('0.3s  ease-in')
            ])
        ])
    ]
})

/**
 * 定期＆積立預金チャット
 */
export class ExistingReserveChatComponent extends BaseComponent implements AfterViewChecked, OnInit, OnDestroy {
    @ViewChild(Content) public content: Content;
    @ViewChild('footerContent', { read: ViewContainerRef }) public footerContent: ViewContainerRef;
    @ViewChild('topBlockView', { read: ElementRef }) public topBlockView: ElementRef;
    @ViewChild('bottomBlockView', { read: ElementRef }) public bottomBlockView: ElementRef;

    public chatFlowAccessor: ExistingReserveChatFlowAccessor;
    public state: ExistingReserveState;
    // is current page
    public isCurrentPage: boolean;
    public currentTitle: string;
    public needPassword: boolean = true;
    public footerState = 'out';

    private currentPageComponent: ExistingReserveChatFlowRenderer;
    private currentPageIndex: number;
    private pageComponentList: ExistingReserveChatFlowRenderer[];

    private startOrder: number;
    private endOrder: number;
    private cifInfo: any;

    private licenseSubscribe;
    private options?: {
        component: string;
        title: string;
        process: number;
        clear: boolean;
        submitData: any;
    };

    constructor(
        private store: ExistingReserveStore, private action: ExistingReserveAction,
        private modalService: ModalService, private audioService: AudioService,
        private navCtrl: NavController, public changeDetectorRef: ChangeDetectorRef,
        private params: NavParams, public viewCtrl: ViewController,
        private modalCtrl: ModalController, private licenseService: LicenseService,
        private modalProvider: ModalPlanConfirmationComponentProvider,
        private deviceService: DeviceService, private editService: EditService, private loginStore: LoginStore) {
        super();
        this.pageComponentList = [];
        this.state = this.store.getState();
        this.chatFlowAccessor = new ExistingReserveChatFlowAccessor();
        this.options = params.get('options');

        if (this.options && this.options.submitData) {
            this.action.clearShowChats();
            this.action.setStateData(this.options);
        } else {
            this.action.setCustomerApplyStartDate(this.params.data.customerApplyStartDate);
        }
    }

    public ngOnInit() {
        this.startOrder = this.params.get('startOrder');
        this.endOrder = this.params.get('endOrder');
        this.currentPageIndex = this.params.get('pageIndex');
        this.isCurrentPage = this.params.get('isCurrentPage') ? true : false;
        this.currentTitle = this.params.get('isCurrentPage') ? this.params.get('currentTitle') : '';
        this.needPassword = this.params.get('needPassword') ? false : true;

        if (!this.options) {
            this.cifInfo = this.params.get('submitData');

            const cardInfo = this.params.get('cardInfo');
            this.action.setStateSubmitDataValue([{
                key: 'cardInfo',
                value: cardInfo
            }]);

            // cif情報をセット
            if (this.cifInfo) {
                this.action.setCifInfo(this.cifInfo);
            }

            // 読み込むQRコード情報をこのフローに設定する
            this.action.setSwipeInfo({
                tabletApplyId: this.params.get('tabletApplyId'),
                accountType: this.params.get('accountType'),
            });
        }

        this.currentPageIndex = 0;
        this.currentPageComponent = this.options ?
            this.getPageComponent(0, this.options.component) : this.getPageComponent(0);

        setTimeout(() => {
            this.currentPageComponent.loadTemplate(0);
        }, 600);

        this.store.registerSignalHandler(ExistingReserveSignal.CHAT_FLOW_COMPELETE, (nextChatName) => {
            if (nextChatName === undefined) {
                this.branchStatusUpdate();
            } else if (nextChatName === 'top') {
                Observable.timer(Constants.PageConsts.backToTopStayTime).subscribe(() => {
                    this.branchStatusUpdate();
                    this.navCtrl.setRoot(TopComponent);
                    this.chatFlowAccessor.clearComponent();
                });
            } else if (nextChatName === 'compelete') {
                this.viewCtrl.dismiss({
                    ...this.state
                });
            } else if (nextChatName === ChatFlowChoicesValue.BACK_TO_TOP) {
                Observable.timer(Constants.ZERO).subscribe(() => {
                    this.navCtrl.setRoot(TopComponent);
                    this.chatFlowAccessor.clearComponent();
                });
            } else {
                this.currentPageIndex += 1;
                this.currentPageComponent = this.getPageComponent(this.currentPageIndex, nextChatName);
                Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                    this.currentPageComponent.loadTemplate(this.currentPageIndex);
                });
                this.chatFlowAccessor.clearComponent();
            }
        });
        this.store.registerSignalHandler(ExistingReserveSignal.SET_CIF_INFORMATION, (params) => {
            let otherProductFlag = OtherProductFlag.NOT_SELECT;
            if (ProductCategoryUtils.getProductCategoryByCifInfo().length === 0) {
                // その他の商品タイプを設定する
                this.action.setProductType(Consts.OTHER_PRODUCT_TYPE);
                otherProductFlag = OtherProductFlag.SELECT;
            }
            this.action.setStateSubmitDataValue([{
                key: 'otherProductFlag',
                value: otherProductFlag
            }]);

            // 口座残高情報照会を呼び出す
            const accountParam: AccountBalanceInquiryInterface = {
                path: CoreBankingConstants.ApiPathConsts.ACCOUNT_BALANCE_INQUIRY,
                tabletApplyId: this.loginStore.getState().tabletApplyId,
                userMngNo: this.loginStore.getState().bankclerkId,
                params: {
                    bankNo: CoreBankingConst.bankNo,                                 // 銀行番号
                    receptionTenban: this.state.submitData.receptionBranchNo,  // 受付店番
                    receptionNo: this.state.submitData.receptionNo,            // 受付番号
                    terminalNo: this.deviceService.getDeviceId(),            // 端末番号
                    accountInfoList: [{
                        tenban: this.state.submitData.swipeBranchNo,
                        accountNo: this.state.submitData.swipeAccountNo,
                        accountType: COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL
                    }]
                }
            };
            this.action.inquireAccountBalance(accountParam);
            this.getNextAnswer(params.nextOrder, params.pageIndex);
        });

        this.store.registerSignalHandler(ExistingReserveSignal.CHAT_FLOW_RETURN, (next) => {
            const copyShowChats = Array.from(this.state.showChats);
            const item = copyShowChats.reverse().find(
                (qus) => {
                    return qus.name === next.name && qus.type !== 'judge';
                }
            );

            this.toEditChat(item.order, item.pageIndex, item.answer.order, item.orderIndex);
        });

        this.store.registerSignalHandler(ExistingReserveSignal.SET_ANSWER, () => this.changeDetectorRef.detectChanges());
        this.store.registerSignalHandler(ExistingReserveSignal.WILL_PUSH_FOOTER, () => this.footerState = 'in');
        this.store.registerSignalHandler(ExistingReserveSignal.WILL_DISMISS_FOOTER, () => this.footerState = 'out');
    }

    public ngOnDestroy() {
        this.chatFlowAccessor.destroy();
        this.store.unregisterSignalHandler(ExistingReserveSignal.CHAT_FLOW_COMPELETE);
        this.store.unregisterSignalHandler(ExistingReserveSignal.SET_CIF_INFORMATION);
        this.store.unregisterSignalHandler(ExistingReserveSignal.CHAT_FLOW_RETURN);
        this.store.unregisterSignalHandler(ExistingReserveSignal.SET_ANSWER);
        this.store.unregisterSignalHandler(ExistingReserveSignal.WILL_PUSH_FOOTER);
        this.store.unregisterSignalHandler(ExistingReserveSignal.WILL_DISMISS_FOOTER);
    }

    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    public beforeAlert() {
        this.chatFlowAccessor.clearComponent();
    }
    public afterAlert() {
        const lastNode = this.state.showChats[this.state.showChats.length - 1];
        this.action.resetLastNode({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    /**
     * 修正ボタンクリックしたらのCallback
     * @param order メッセージの番号
     * @param pageIndex ページ番号
     * @param answerOrder 応答順
     */
    public editCallBack(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.editService.startEdit();
        this.beforeAlert();
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.editBtn, buttonValue: 'edit' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.editTitle,
            buttonList,
            (item) => {
                const preventedItem = this.editService.endEdit();
                if (item.buttonValue === 'edit') {
                    this.action.editChart(order, pageIndex, answerOrder, orderIndex);
                    this.chatFlowAccessor.clearComponent();
                    this.currentPageIndex = pageIndex;
                    this.currentPageComponent = this.getPageComponent(pageIndex);
                    this.getNextAnswer(order, pageIndex);
                    const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
                    this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
                } else {
                    if (preventedItem) {
                        this.getNextAnswer(preventedItem.order, preventedItem.pageIndex);
                    } else {
                        this.afterAlert();
                    }
                }
            },
            this.labels.alert.editSubTitle
        );
    }

    /**
     * ヘッダータイトル取得
     */
    public get headerTitle(): string {
        return this.options ? this.options.title : this._labels.existingReserve.title;
    }

    /**
     * processType取得
     */
    public get processType(): number {
        return this.currentPageComponent.processType;
    }

    /**
     * キャンセルボタンクリックしたらのCallback
     */
    public handleCancelClickEmitter(value) {
        // タイトルが「本人確認書類」の場合、ポップアップを表示。※本人確認チャット
        if (this.headerTitle === '本人確認書類') {
            const buttonList = [
                { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
                { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.backToConfirmTitle,
                buttonList,
                (item) => {
                    if (item.buttonValue === 'back') {
                        this.viewCtrl.dismiss(value);
                    }
                }
            );
        } else {
            this.viewCtrl.dismiss(value);
        }
    }

    /**
     * 本人確認チャットの場合は、ボタン名を「申込確認へ戻る」以外の場合は「行員呼び出し」
     *
     * @readonly
     * @memberof
     */
    public get leftHeadTitle() {
        return (this.headerTitle === '本人確認書類') ? this.labels.common.leftSubTitle.backConfirm : this.labels.header.leftSubTitle;
    }

    /**
     * 次のノードを取得する
     * @param order オーダー
     * @param pageIndex ページ番号
     * @param nextChatDelay ディレイ時間
     */
    private getNextAnswer(order: number, pageIndex: number, nextChatDelay?: number) {
        if (this.startOrder != null && this.endOrder != null && order > this.endOrder) {
            if (this.needPassword) {
                const modal = this.modalCtrl.create(AccountModalPasswordComponent,
                    { data: 'キャッシュカードの暗証番号を入力してください。' },
                    { cssClass: 'settings-modal', enableBackdropDismiss: false });
                modal.onDidDismiss((value) => this.viewCtrl.dismiss(value));
                modal.present();
            } else {
                this.viewCtrl.dismiss();
            }
            return;
        }

        const speed = (nextChatDelay === undefined) ? Number(AppProperties.CHAT_SPEED) : nextChatDelay;
        Observable.timer(speed).subscribe(() => {
            this.action.getNextChatByAnswer(order, pageIndex);
        });
    }

    /**
     * コンポーネントタイプにより、各レンダラをマッピング
     * @param componentType コンポーネントタイプ
     */
    private mappingComponentList(componentType: string): ExistingReserveChatFlowRenderer {
        let render: ExistingReserveChatFlowRenderer;
        if (componentType === 'ExistingReserveComponent' || componentType === undefined) {
            render = new ExistingReserveVerificationRenderer(this.chatFlowAccessor,
                this.footerContent, this.store, this.audioService, this.navCtrl, this.deviceService);
        } else if (componentType === 'ExistingRegularSelectProductComponent') {
            render = new ExistingRegularSelectProductRenderer(this.chatFlowAccessor,
                this.footerContent, this.store, this.loginStore, this.navCtrl, this.modalProvider, this.modalService);
        } else if (componentType === 'ExistingCheckApplyComponent') {
            render = new ExistingCheckApplyRender(this.chatFlowAccessor, this.footerContent, this.store,
                this.navCtrl, this.deviceService, this.modalCtrl);
        } else if (componentType === 'ExistingAddressIdentificationComponent') {
            render = new ExistingAddressIdentificationRenderer(this.chatFlowAccessor, this.footerContent, this.store,
                this.navCtrl, this.deviceService);
        } else if (componentType === 'ExistingIdentificationDocumentOneComponent') {
            render = new ExistingIdentificationDocumentOneRender(this.chatFlowAccessor, this.footerContent, this.store,
                this.navCtrl, this.deviceService);
        } else if (componentType === 'ExistingIdentificationDocumentTwoComponent') {
            render = new ExistingIdentificationDocumentTwoRender(this.chatFlowAccessor, this.footerContent, this.store,
                this.navCtrl, this.deviceService);
        } else if (componentType === 'ExistingImgapplyComponent') {
            render = new ExistingImgapplyRenderer(this.chatFlowAccessor, this.footerContent, this.store,
                this.navCtrl, this.deviceService, this.modalCtrl);
        } else if (componentType === 'ExistingRegularDoubleLiveRenderer') {
            render = new ExistingRegularDoubleLiveRenderer(this.chatFlowAccessor, this.footerContent, this.store,
                this.modalService, this.audioService, this.navCtrl, this.action);
        } else if (componentType === 'ExistingRegularReserveComponent') {
            render = new ExistingRegularReserveComponent(this.chatFlowAccessor, this.footerContent, this.store,
                this.modalService, this.navCtrl, this.loginStore);
        }
        return render;
    }

    private getPageComponent(pageIndex: number, componentType?: string): ExistingReserveChatFlowRenderer {
        if (this.pageComponentList[pageIndex] == null) {
            this.pageComponentList[pageIndex] = this.mappingComponentList(componentType);
            this.pageComponentList[pageIndex].nextChatEvent.subscribe((params) => {
                this.getNextAnswer(params.order, params.pageIndex, params.nextChatDelay);
            });
        }

        if (this.chatFlowAccessor) {
            this.chatFlowAccessor.setRenderer(this.pageComponentList[pageIndex]);
            this.chatFlowAccessor.setContent(this.content);
        }
        return this.pageComponentList[pageIndex];
    }

    private branchStatusUpdate() {
        let leaveReason = '';
        let status = '';

        switch (this.state.submitData.leaveType) {
            case 'agentNoConfirmFile':
                leaveReason = Constants.DBConsts.leaveReason.agentNoConfirmFile;
                status = Constants.DBConsts.updateStatus.agentNoConfirmFile;
                break;
            case 'noCohabitation':
                leaveReason = Constants.DBConsts.leaveReason.noCohabitation;
                status = Constants.DBConsts.updateStatus.noCohabitation;
                break;
            case 'noConfirmFile':
                leaveReason = Constants.DBConsts.leaveReason.noConfirmFile;
                status = Constants.DBConsts.updateStatus.noConfirmFile;
                break;
        }

        const params = {
            tabletApplyId: this.store.getState().tabletApplyId,
            leaveReason: leaveReason,
            status: status,
            userMngNo: this.loginStore.getState().bankclerkId
        };

        this.action.branchStatusUpdate(params);
    }

    private toEditChat(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.beforeAlert();
        this.action.editChart(order, pageIndex, answerOrder, orderIndex);
        this.chatFlowAccessor.clearComponent();
        this.currentPageIndex = pageIndex;
        this.currentPageComponent = this.getPageComponent(pageIndex);
        this.getNextAnswer(order, pageIndex);
        const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
        this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
    }
}
