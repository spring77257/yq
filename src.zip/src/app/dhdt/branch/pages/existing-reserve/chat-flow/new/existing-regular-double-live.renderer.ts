import { ViewContainerRef } from '@angular/core';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ExistingReserveAction } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { ExistingReserveChatFlowAccessor } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.accessor';
import { ExistingReserveChatFlowRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.renderer';
import { ExistingReserveQuestionsModel } from 'dhdt/branch/pages/existing-reserve/entity/existing-reserve-questions.model';
import { RegularPurpose } from 'dhdt/branch/pages/existing-reserve/existing-reserve-consts';
import { ExistingReserveState, ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { ExistingRegularInitConfirmComponent } from 'dhdt/branch/pages/existing-reserve/view/existing-regular-initconfirm.component';
import {
    ExistingReserveSelfConfirmationComponent
} from 'dhdt/branch/pages/existing-reserve/view/existing-reserve-self-confirmation.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { SignatureComponent } from 'dhdt/branch/shared/components/signature/signature.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { NavController } from 'ionic-angular';

/**
 * ExistingRegularDoubleLiveRenderer 情報入力画面（定期・積立の二重居住）.
 */
export class ExistingRegularDoubleLiveRenderer extends ExistingReserveChatFlowRenderer {

    public processType = 1;

    private state: ExistingReserveState;

    constructor(private chatFlowAccessor: ExistingReserveChatFlowAccessor, private footerContent: ViewContainerRef,
                private store: ExistingReserveStore, private modalService: ModalService, private audioService: AudioService,
                public navCtrl: NavController, private action: ExistingReserveAction) {
        super();
        this.state = this.store.getState();
    }

    /**
     * YMLファイル読み込み
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate('chat-flow-def-existing-reserve-double-live.yml', pageIndex);
    }

    public rendererComponents(question: ExistingReserveQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'categoryNameLogicPicker': {
                this.onCategoryNameLogicPicker(question, pageIndex, 'data');
                break;
            }
            case 'categoryNamePhysicsPicker': {
                this.onCategoryNameLogicPicker(question, pageIndex, 'filler1');
                break;
            }
            case 'sign': {
                this.onSignature(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SAVE_SUBMIT: {
                this.onSaveSubmit(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_COMPLETE: {
                this.onComplete(question, pageIndex);
                break;
            }
        }
    }

    /**
     * 固定値を保存する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSaveSubmit(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            this._action.setStateSubmitDataValue(entity.choices);
            this.getNextChat(entity.next, pageIndex);
        }
    }

    public onComplete(entity: ExistingReserveQuestionsModel, pageIndex: number) {
        switch (this.state.submitData.regularPurpose) {
            // 定期
            case RegularPurpose.REGULAR: {
                this.navCtrl.setRoot(ExistingRegularInitConfirmComponent);
                break;
            }
            // 積立
            case RegularPurpose.RESERVE: {
                this.navCtrl.setRoot(ExistingReserveSelfConfirmationComponent);
                break;
            }
        }
    }

    public onSignature(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData
        };
        this.chatFlowAccessor.addComponent(entity.choices, SignatureComponent, this.footerContent, options).subscribe((answer) => {
            this.setAnswer({
                text: answer.text,
                value: [{
                    key: entity.name, value: answer.value
                }]
            });
            this.chatFlowAccessor.clearComponent();
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     * @param entryName 表示用column名
     */
    public onCategoryNameLogicPicker(entity: ExistingReserveQuestionsModel, pageIndex: number, entryName?: any) {
        const options = {
            type: entity.type,
            validationRules: entity.validationRules,
            applyBizCategory: this.state.submitData.applyBizCategory,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
        };
        this.action.getCategoryNameLogic().subscribe((data) => {
            this.chatFlowAccessor.addComponent(
                data.map((item) => {
                    return {
                        text: item[entryName],
                        value: item.codeValue
                    };
                }),
                PickerCommonComponent,
                this.footerContent,
                options
            ).subscribe((answer) => {
                this.setAnswer({
                    text: answer.text,
                    value: [{
                        key: entity.name, value: answer.value[0].value
                    }, {
                        key: entity.name + 'Text', value: answer.text
                    }]
                });
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(entity.next, pageIndex);
            });
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (answer.action && answer.action.value && answer.action.value === 'pdfModal') {
                const title = answer.action.type === 'crs' ? this.labels.signature.crsExplanationTitle
                : this.labels.signature.fatcaTitle;
                this.modalService.showModal(answer.action.value, {pdfSrc: answer.action.imgSrc, title: title});
                return;
            }
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.text }
                    ]
                });
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    public onNumberKeybord(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                } else {
                    this.setAnswer(answer);
                    this.setAnswer({
                        text: answer.text,
                        value: [{
                            key: entity.name,
                            value: answer.text
                        }]
                    });
                }

                this.getNextChat(entity.next, pageIndex);
            });
    }

    public onKeybord(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === 'skip') {
                    this.setAnswer({ text: 'スキップ', value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        this.getNextChat(entity.next, pageIndex);
                    });
                }
            });
    }

    public onJudge(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            const choice = entity.choices.find((item) => {
                return item.value === this.state.submitData[entity.name];
            });
            this.getNextChat(choice ? choice.next : entity.next, pageIndex, 0);
        }
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     */
    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }

}
