import { ViewContainerRef } from '@angular/core';
import { COMMON_CONSTANTS, RequestType } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingReserveChatFlowAccessor } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.accessor';
import { ExistingReserveChatFlowRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.renderer';
import { ExistingReserveQuestionsModel } from 'dhdt/branch/pages/existing-reserve/entity/existing-reserve-questions.model';
import {
    ExistingReserveSignal, ExistingReserveState, ExistingReserveStore
} from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { ExistingRegularInitConfirmComponent } from 'dhdt/branch/pages/existing-reserve/view/existing-regular-initconfirm.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import {
    ModalPlanConfirmationComponentProvider
} from 'dhdt/branch/shared/components/modal/modal-plan-confirmation/modal-plan-confirmation.component';
import { PayoutAccountComponent } from 'dhdt/branch/shared/components/payout-account/view/payout-account.component';
import { QuantityInputComponent } from 'dhdt/branch/shared/components/quantity-input/quantity-input.component';
import { SelectProductComponent } from 'dhdt/branch/shared/components/select-product/select-product.component';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { NavController } from 'ionic-angular';

/**
 * Existing Regular select product component(既存_定期預金 商品選択画面).
 */
export class ExistingRegularSelectProductRenderer extends ExistingReserveChatFlowRenderer {
    public processType = 1;

    private state: ExistingReserveState;

    private readonly DEPOSIT: string = '04';
    private readonly TRANSFER: string = '03';

    constructor(
        private chatFlowAccessor: ExistingReserveChatFlowAccessor, private footerContent: ViewContainerRef,
        private store: ExistingReserveStore, private loginStore: LoginStore, private navCtrl: NavController,
        private modalProvider: ModalPlanConfirmationComponentProvider, private modalService: ModalService) {
        super();
        this.state = this.store.getState();
    }

    /**
     * YMLファイル読み込み
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(COMMON_CONSTANTS.YML_CHAT_FLOW_EXISTING_RESERVE_SELECT_PRODUCT, pageIndex);
    }

    /**
     * チャットのtype属性についてハンドリング。
     * @param question チャットの質問
     * @param pageIndex ページ番号
     */
    public rendererComponents(question: ExistingReserveQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECT_PRODUCT: {
                this.onSelectProduct(question, pageIndex, { key: COMMON_CONSTANTS.ELEMENT_TYPE_SELECT_PRODUCT_NAME, name: 'data' });
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE_MODAL: {
                this.onJudgeModal(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECT_COURSE: {
                this.onSelectCourse(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_REQUEST: {
                this.onRequest(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECT_PAYOUT_ACCOUNT: {
                this.onSelectPayoutAccount(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_NUMBER_THOUSAND: {
                this.onDepositInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_ACCOUNTSHOP: {
                this.getNextChat(question.next, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON: {
                this.onButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_COMPLETE: {
                this.onComplete(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SAVE_SUBMIT: {
                this.onSaveSubmit(question, pageIndex);
                break;
            }
        }
    }

    public onComplete(entity: ExistingReserveQuestionsModel, pageIndex: number) {
        this.navCtrl.setRoot(ExistingRegularInitConfirmComponent);
    }

    public onSaveSubmit(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            this._action.setStateSubmitDataValue(entity.choices);
            this.getNextChat(entity.next, pageIndex);
        }
    }

    /**
     * Send request
     * @param entity entity
     * @param pageIndex pageIndex
     */
    public onRequest(entity: ExistingReserveQuestionsModel, pageIndex: number) {
        switch (entity.name) {
            // 預入先口座と振替元口座取得
            case RequestType.EXISTING_ACCOUNT_LIST: {
                this.getExistingAccountList(entity, pageIndex);
                break;
            }
        }
    }

    /**
     * 預入先口座と振替元口座取得
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public getExistingAccountList(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        this.store.registerSignalHandler(ExistingReserveSignal.GET_EXISTING_ACCOUNT_INFO, (data) => {
            this.store.unregisterSignalHandler(ExistingReserveSignal.GET_EXISTING_ACCOUNT_INFO);

            if (data.depositAccounts.length === 1 && data.transferAccounts.length === 1) {

                this.store.registerSignalHandler(ExistingReserveSignal.RECEPTION_CHECK_DEPOSIT_TRANSFER, () => {
                    this.clearSignals();
                    this.getNextChat(entity.next, pageIndex, 0);
                    return;
                });

                const transferParams = {
                    tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                    params: {
                        receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                        tenban: data.transferAccounts[0].branchNo, // 店番
                        accountType: data.transferAccounts[0].accountType, // 科目
                        accountNo: data.transferAccounts[0].accountNo, // 口座番号
                        businessCode: this.TRANSFER, // 業務コード
                    }
                };
                const depositParams = {
                    tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                    params: {
                        receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                        tenban: data.depositAccounts[0].branchNo, // 店番
                        accountType: data.depositAccounts[0].accountType, // 科目
                        accountNo: data.depositAccounts[0].accountNo, // 口座番号
                        businessCode: this.DEPOSIT, // 業務コード
                    }
                };
                this._action.receptionCheckDepositTransfer(depositParams, transferParams);

            } else if (data.depositAccounts.length === 1 && data.transferAccounts.length !== 1) {

                this.store.registerSignalHandler(ExistingReserveSignal.RECEPTION_CHECK_DEPOSIT, () => {
                    this.clearSignals();
                    this.getNextChat(entity.next, pageIndex, 0);
                    return;
                });
                const params = {
                    tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                    params: {
                        receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                        tenban: data.depositAccounts[0].branchNo, // 店番
                        accountType: data.depositAccounts[0].accountType, // 科目
                        accountNo: data.depositAccounts[0].accountNo, // 口座番号
                        businessCode: this.DEPOSIT, // 業務コード
                    }
                };
                this._action.receptionCheckDeposit(params);

            } else if (data.depositAccounts.length !== 1 && data.transferAccounts.length === 1) {

                this.store.registerSignalHandler(ExistingReserveSignal.RECEPTION_CHECK_TRANSFER, () => {
                    this.clearSignals();
                    this.getNextChat(entity.next, pageIndex, 0);
                    return;
                });
                const params = {
                    tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                    params: {
                        receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                        tenban: data.transferAccounts[0].branchNo, // 店番
                        accountType: data.transferAccounts[0].accountType, // 科目
                        accountNo: data.transferAccounts[0].accountNo, // 口座番号ß
                        businessCode: this.TRANSFER, // 業務コード
                    }
                };
                this._action.receptionCheckTransfer(params);

            } else {

                this.clearSignals();
                this.getNextChat(entity.next, pageIndex, 0);
                return;

            }
        });
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                customerId: this.state.submitData.customerId,
                birthdate: this.state.submitData.birthdate
            }
        };
        this._action.getExistingAccountInfo(param);
    }

    /**
     * 商品選択コンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSelectProduct(entity: ExistingReserveQuestionsModel, pageIndex: number, entry: any): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            cssClass: entity.options && entity.options.cssClass,
            courseName: entry.name
        };
        this.chatFlowAccessor.addComponent(this.labels.product[entry.name],
            SelectProductComponent, this.footerContent, options)
            .subscribe((answer) => {
                const valueArr = [
                    { key: entity.name, value: answer.value },
                    {
                        key: entry.key,
                        value: answer.name
                    }
                ];
                this.setAnswer({
                    text: answer.name,
                    value: [...valueArr]
                });
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        if (entity.name === 'amount') {
            const choice = entity.choices ?
                entity.choices.find((item) => Number(this.state.submitData.amount) >= Number(item.value)) : undefined;
            this.getNextChat(choice ? choice.next : entity.next, pageIndex, 0);
        } else {
            const choice = entity.choices ? entity.choices.find((item) => this.state.submitData[entity.name] === item.value) : undefined;

            // 振替元口座が存在しない場合は、アラートを出します
            if (entity.name === 'transferControlPattern' && !choice) {
                const buttonList = [
                    { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
                ];
                this.modalService.showWarnAlert(
                    this.labels.alert.noTransferAccount,
                    buttonList, () => {
                        this.getNextChat(choice ? choice.next : entity.next, pageIndex, 0);
                    }
                );
            } else {
                this.getNextChat(choice ? choice.next : entity.next, pageIndex, 0);
            }
        }
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudgeModal(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.modalProvider.presend({ title: choice.title, image: choice.img }, () =>
                        this.getNextChat(choice.next, pageIndex, 0)
                    );
                }
            });
        }
    }

    /**
     * YMLファイル分岐判断
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onSelectCourse(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.onSelectProduct(choice, pageIndex, { key: COMMON_CONSTANTS.ELEMENT_TYPE_SELECT_COURSE_NAME, name: choice.type });
                }
            });
        }
    }

    /**
     * 口座表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onSelectPayoutAccount(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(
            { data: this.state.submitData[entity.example] || [] },
            PayoutAccountComponent,
            this.footerContent,
            options
        ).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            if (answer) {
                this.setAnswer({
                    text: answer.text,
                    value: [{
                        key: entity.name,
                        value: answer.value
                    },
                    ]
                });
            }
            this._store.unregisterSignalHandler(ExistingReserveSignal.RECEPTION_CHECK);
            this._store.registerSignalHandler(ExistingReserveSignal.RECEPTION_CHECK, () => {
                this._store.unregisterSignalHandler(ExistingReserveSignal.RECEPTION_CHECK);
                this.getNextChat(entity.next, pageIndex);
            });
            const param = {
                tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                params: {
                    receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                    tenban: answer.value.branchNo, // 店番
                    accountType: answer.value.accountType, // 科目
                    accountNo: answer.value.accountNo, // 口座番号
                    businessCode: entity.options.businessCode, // 業務コード
                }
            };
            this._action.receptionCheck(param);
        });
    }

    /**
     * 金額入力コンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onDepositInput(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        let validationRules;
        if (entity.choices[0]) {
            entity.choices[0].choices.forEach((choice) => {
                if (this.state.submitData.selectProductType === choice.selectProductType) {
                    if (!choice.selectCourseType) {
                        validationRules = choice.validationRules;
                    } else {
                        const selectCourseType =
                            this.state.submitData.applicationCourseSeverancePay ||
                            this.state.submitData.applicationCourseAssetMgmt ||
                            this.state.submitData.applicationCourseBirthday;
                        if (choice.selectCourseType === selectCourseType) {
                            validationRules = choice.validationRules;
                        }
                    }
                }
            });
        }

        entity.choices[0].validationRules = validationRules;

        const options = {
            type: entity.type,
            name: entity.name,
            unit: entity.options.unit,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, QuantityInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            maxColNum: (entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON) ? 3 : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
            .subscribe((answer) => {
                if (entity.name.length > 0 && answer.value.length > 0) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.text }
                        ]
                    });
                }

                if (entity.name === 'depositPeriodYearMonth') {
                    this._action.setDueDate();
                }

                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            });
    }

    private clearSignals() {
        this.store.unregisterSignalHandler(ExistingReserveSignal.RECEPTION_CHECK);
        this.store.unregisterSignalHandler(ExistingReserveSignal.RECEPTION_CHECK_TRANSFER);
        this.store.unregisterSignalHandler(ExistingReserveSignal.RECEPTION_CHECK_DEPOSIT);
    }
}
