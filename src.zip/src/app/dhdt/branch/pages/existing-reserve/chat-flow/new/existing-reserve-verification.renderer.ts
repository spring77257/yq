import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { DeviceService } from 'dhd/common/services/device.service';
import { ChangeConfirmComponent } from 'dhdt/branch/pages/change/view/change-confirm.component';
import { COMMON_CONSTANTS, CoreBankingConst } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingReserveChatFlowAccessor } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.accessor';
import { ExistingReserveChatFlowRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.renderer';
import { ExistingReserveQuestionsModel } from 'dhdt/branch/pages/existing-reserve/entity/existing-reserve-questions.model';
import { Consts } from 'dhdt/branch/pages/existing-reserve/existing-reserve-consts';
import {
    ExistingReserveState,
    ExistingReserveStore
} from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { ProductCategoryUtils } from 'dhdt/branch/pages/existing-reserve/utils/product-category-utils';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { MultiButtonGroupComponent } from 'dhdt/branch/shared/components/multi-button-group/multi-button-group.component';
import { SelectProductComponent } from 'dhdt/branch/shared/components/select-product/select-product.component';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { NavController } from 'ionic-angular';

/**
 * 定期＆積立預金 共通_入力画面
 */
export class ExistingReserveVerificationRenderer extends ExistingReserveChatFlowRenderer {

    public processType = 1;

    private loginStore: LoginStore;
    private state: ExistingReserveState;
    private modalService: ModalService;

    constructor(private chatFlowAccessor: ExistingReserveChatFlowAccessor,
                private footerContent: ViewContainerRef,
                private store: ExistingReserveStore,
                private audioService: AudioService,
                private navCtrl: NavController,
                private deviceService: DeviceService) {
        super();
        this.state = this.store.getState();
        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.modalService = InjectionUtils.injector.get(ModalService);

    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(COMMON_CONSTANTS.YML_CHAT_FLOW_EXISTING_RESERVE_VARIFICATION, pageIndex);
    }

    /**
     * チャットのtype属性についてハンドリング。
     * @param question チャットの質問
     * @param pageIndex ページ番号
     */
    public rendererComponents(question: ExistingReserveQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECT_PRODUCT: {
                this.onSelectProduct(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_MULIT_BUTTON: {
                this.onMulitButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SAVE_SUBMIT: {
                this.onSaveSubmit(question, pageIndex);
                break;
            }
        }
    }

    /**
     * 固定値を保存する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSaveSubmit(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            this._action.setStateSubmitDataValue(entity.choices);
            this.getNextChat(entity.next, pageIndex);
        }
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onMulitButton(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxLength: entity.validationRules.max
        };
        this.chatFlowAccessor.addComponent(entity.choices, MultiButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }                    ]
                });
            }

            this.chatFlowAccessor.clearComponent();

            let next = answer.next.split('、')[0];
            if (entity.name === COMMON_CONSTANTS.HOLDER_CAREER) {
                answer.next.split('、').forEach((order) => {
                    if (order === COMMON_CONSTANTS.ExistingSavings.CareerNextOrder) {
                        next = order;
                    }
                });
            }
            this.getNextChat(Number.parseInt(next), pageIndex);
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value }
                    ]
                });
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * 商品選択コンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSelectProduct(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(this.labels.product.data, SelectProductComponent, this.footerContent, options)
            .subscribe((answer) => {
                this.setAnswer({
                    text: answer.name,
                    value: [
                        { key: entity.name, value: answer.category },
                        { key: Consts.SELECT_PRODUCT_NAME, value: ProductCategoryUtils.getProductName(answer.category) }
                    ]
                });
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });

                        const resetResultList = InputUtils.holderNameReset(entity.name, this.state.submitData);
                        if (resetResultList) {
                            this._action.setStateSubmitDataValue(resetResultList);
                        }
                        this.getNextChat(entity.next, pageIndex);
                    });
                }
            });
    }

    /**
     * メモリにの値を判断する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onJudge(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    /**
     * パスワードモーダルを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onPassword(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            terminalNo: this.deviceService.getDeviceId(),
            accountNo: this.state.submitData.swipeAccountNo,
            tenban: this.state.submitData.swipeBranchNo,
            accountType: this.state.submitData.swipeAccountType
        };

        this.modalService.showModal(COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_VERIFICATION,
            {
                text: this.labels.password.inputPasswordText,
                subText: this.labels.password.inputPasswordSubText,
                units: 4,
                needConfirm: false,
                cashcardParams: param
            }, (result) => {
                if (result) {
                    this.showConfirmPage(entity.next, pageIndex, result, entity.skip);
                }
            });
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            const info = {
                imgSrc: action.imgSrc
            };
            this.modalService.showModal(action.value, info);
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        } else if (action.type === 'admin') {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        }
    }

    /**
     * 確認ページを表示する
     * @param next 次ノードのオーダー
     * @param pageIndex ページ番号
     */
    private showConfirmPage(next: number, pageIndex: number, result: any, skip?: number) {
        // CIF情報照会ハンドル
        const cifParam: SimpleCifInfoInquiryInterface = {
            path: CoreBankingConstants.ApiPathConsts.CIF_INFO_INQUIRY,
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            params: {
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                tenban: this.state.submitData.swipeBranchNo,
                accountNo: this.state.submitData.swipeAccountNo,
                accountType: this.state.submitData.swipeAccountType
            }
        };

        const inputParams = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            swipeCif: this.state.submitData.swipeCif || '1234567',
            branchNo: this.state.submitData.swipeBranchNo || '123',
            accountNo: this.state.submitData.swipeAccountNo || '1234567',
            accountType: this.state.submitData.swipeAccountType,
            receptionBranchNo: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            receptionTime: this.state.submitData.receptionTime,
            password: result,
        };

        this.chatFlowAccessor.clearComponent();
        this.navCtrl.push(
            ChangeConfirmComponent,
            {
                type: COMMON_CONSTANTS.BusinessFlowType.ExistingReserve,
                processType: COMMON_CONSTANTS.ProcessType.RequiredInput,
                cifParam: cifParam,
                inputParams: inputParams,
                callBack: () => {
                    this._action.getCifInformation(cifParam, inputParams, next, pageIndex, skip);
                }
            },
            { animate: false }
        );
    }
}
