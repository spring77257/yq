import { ViewContainerRef } from '@angular/core';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingReserveChatFlowAccessor } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.accessor';
import { ExistingReserveChatFlowRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.renderer';
import { ExistingReserveQuestionsModel } from 'dhdt/branch/pages/existing-reserve/entity/existing-reserve-questions.model';
import {
    ExistingReserveSignal, ExistingReserveState, ExistingReserveStore
} from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { MultiButtonGroupComponent } from 'dhdt/branch/shared/components/multi-button-group/multi-button-group.component';
import { PayoutAccountComponent } from 'dhdt/branch/shared/components/payout-account/view/payout-account.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { QuantityInputComponent } from 'dhdt/branch/shared/components/quantity-input/quantity-input.component';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import * as moment from 'moment';

export class ReserveDepositModifyRenderer extends ExistingReserveChatFlowRenderer {
    public processType = -1;

    private state: ExistingReserveState;

    constructor(
        private chatFlowAccessor: ExistingReserveChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private loginStore: LoginStore,
        private store: ExistingReserveStore) {
        super();
        this.state = this.store.getState();

    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadConfirmPageTemplate('chat-flow-def-reserve-deposit-modify.yml', pageIndex);
    }

    /**
     * チャットのtype属性についてハンドリング。
     * @param question チャットの質問
     * @param pageIndex ページ番号
     */
    public rendererComponents(question: ExistingReserveQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'daypicker':
            case 'datepicker': {
                this.onPicker(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_NUMBER_THOUSAND: {
                this.onQuantityInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECT_PAYOUT_ACCOUNT: {
                this.onSelectPayoutAccount(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_MULIT_BUTTON: {
                this.onMulitButton(question, pageIndex);
                break;
            }
        }
    }

    public onPicker(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }

        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData,
            today: customerApplyStartDate
        };
        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * 口座表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onSelectPayoutAccount(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(
            { data: this.state.submitData[entity.example] || [] },
            PayoutAccountComponent,
            this.footerContent,
            options
        ).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            if (answer) {
                this.setAnswer({
                    text: answer.text,
                    value: [{
                        key: entity.name,
                        value: answer.value
                    },
                    ]
                });
            }
            this._store.registerSignalHandler(ExistingReserveSignal.RECEPTION_CHECK, () => {
                this._store.unregisterSignalHandler(ExistingReserveSignal.RECEPTION_CHECK);
                this.getNextChat(entity.next, pageIndex);
            });
            const param = {
                tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                params: {
                    receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                    tenban: answer.value.branchNo, // 店番
                    accountType: answer.value.accountType, // 科目
                    accountNo: answer.value.accountNo, // 口座番号
                    businessCode: entity.options.businessCode, // 業務コード
                }
            };
            this._action.receptionCheck(param);
        });
    }

    public onButton(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            maxColNum: (entity.type === 'buttonThreeCols') ? 3 : entity.maxColNum,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        const monthly: string[] = ['addedTransferMonth1', 'addedTransferMonth2', 'addedTransferMonth3', 'addedTransferMonth4'];

        if (monthly.indexOf(entity.name) >= 0) {
            entity.choices.forEach((item: any) => {
                item.options = undefined;
                monthly.forEach((selectMonth: any) => {
                    if (this.state.submitData[selectMonth] === item.value) {
                        item.options = {
                            cssClass: 'disabled-button',
                        };
                    }
                });
            });
        }

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
            .subscribe((answer) => {
                if (entity.name.length > 0 && answer.value.length > 0) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.text }
                        ]
                    });
                }

                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            });
    }

    public onKeybord(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                    this.setAnswer({ text: answer.text, value: results });
                    this.getNextChat(entity.next, pageIndex);
                });
            });
    }

    /**
     * 千円以上の金額入力コンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onQuantityInput(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            title: entity.options ? entity.options.title : undefined,
            unit: entity.options ? entity.options.unit : undefined,
            validationRules: entity.validationRules
        };

        let data: any[] = entity.choices;
        if (entity.name.includes('addedTransferAmount')) {
            data = [{
                name: entity.choices[0].name,
                placeholder: entity.choices[0].placeholder,
                validationRules: {
                    required: entity.choices[0].validationRules.required,
                    regex: entity.choices[0].validationRules.regex,
                    max: entity.choices[0].validationRules.max,
                    min: entity.choices[0].validationRules.min,
                    maxValue: entity.choices[0].validationRules.maxValue,
                    minValue: Number(this.state.submitData.transferAmount) + 1
                }
            }];
        }

        this.chatFlowAccessor.addComponent(data, QuantityInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onMulitButton(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxLength: entity.validationRules.max
        };
        this.chatFlowAccessor.addComponent(entity.choices, MultiButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }                    ]
                });
            }

            this.chatFlowAccessor.clearComponent();

            let next = answer.next.split('、')[0];
            if (entity.name === COMMON_CONSTANTS.HOLDER_CAREER) {
                answer.next.split('、').forEach((order) => {
                    if (order === COMMON_CONSTANTS.ExistingSavings.CareerNextOrder) {
                        next = order;
                    }
                });
            }
            this.getNextChat(Number.parseInt(next), pageIndex);
        });
    }

    public onJudge(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        if (entity.name === 'getFirstAccumulationDate') {
            this._store.registerSignalHandler(ExistingReserveSignal.FIRST_TRANSFER_DAY, () => {
                this._store.unregisterSignalHandler(ExistingReserveSignal.FIRST_TRANSFER_DAY);
                this.getNextChat(entity.next, pageIndex, 0);
            });
            this._action.getFirstAccumulationDate();
        } else if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.getNextChat(choice.next, pageIndex, 0);
                    return;
                }
            });
        }
    }

    public onText(entity: ExistingReserveQuestionsModel, pageIndex: number): void {
        this.getNextChat(entity.next, pageIndex);
    }
}
