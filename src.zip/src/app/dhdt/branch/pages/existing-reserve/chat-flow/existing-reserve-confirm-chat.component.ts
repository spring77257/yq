import {
    AfterViewChecked, animate, ChangeDetectorRef, Component, ElementRef,
    OnDestroy, OnInit, state, style, transition, trigger, ViewChild, ViewContainerRef
} from '@angular/core';
import { BaseComponent } from 'adep/components';
import { ObjectUtils } from 'adep/utils';
import { AppProperties } from 'app.properties';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingReserveAction } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { ExistingReserveChatFlowAccessor } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.accessor';
import { ExistingReserveChatFlowRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.renderer';
import { HolderCareerModifyRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/modify/holder-career-modify.renderer';
import { ReserveDepositModifyRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/modify/reserve-deposit-modify.renderer';
import { TimeDepositModifyRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/modify/time-deposit-modify.renderer';
import {
    ExistingRegularSelectProductRenderer
} from 'dhdt/branch/pages/existing-reserve/chat-flow/new/existing-regular-select-product.renderer';
import {
    ExistingReserveSignal, ExistingReserveState, ExistingReserveStore
} from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import {
    ModalPlanConfirmationComponentProvider
} from 'dhdt/branch/shared/components/modal/modal-plan-confirmation/modal-plan-confirmation.component';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { Content, NavController, NavParams, ViewController } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';

@Component({
    selector: 'existing-reserve-confirm-chat-component',
    templateUrl: 'existing-reserve-chat.component.html',
    animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateY(0)' })),
            state('out', style({ transform: 'translateY(0)' })),
            transition('out => in', [
                style({ transform: 'translateY(100%)' }),
                animate('0.3s  ease-in')
            ]),
            transition('in => out', [
                style({ transform: 'translateY(-100%)' }),
                animate('0.3s  ease-in')
            ])
        ])
    ]
})

/**
 * control all chat page.
 */
export class ExistingReserveConfirmChatComponent extends BaseComponent implements AfterViewChecked, OnInit, OnDestroy {
    @ViewChild(Content) public content: Content;
    @ViewChild('footerContent', { read: ViewContainerRef }) public footerContent: ViewContainerRef;
    @ViewChild('topBlockView', { read: ElementRef }) public topBlockView: ElementRef;
    @ViewChild('bottomBlockView', { read: ElementRef }) public bottomBlockView: ElementRef;

    public chatFlowAccessor: ExistingReserveChatFlowAccessor;
    public state: ExistingReserveState;
    // is current page
    public isCurrentPage: boolean;
    public currentTitle: string;
    public needPassword: boolean = true;
    public footerState = 'out';

    private currentPageComponent: ExistingReserveChatFlowRenderer;
    private currentPageIndex: number;
    private pageComponentList: ExistingReserveChatFlowRenderer[];

    private startOrder: number;
    private endOrder: number;

    private originShowChats: any[];
    private originShowConfirm: any[];
    private originSubmitData: any;
    private originName: any;

    /**
     * title
     */
    public get headerTitle(): string {
        return this.currentTitle;
    }

    /**
     * process type
     */
    public get processType(): number {
        return this.currentPageComponent.processType;
    }

    constructor(
        private store: ExistingReserveStore, private action: ExistingReserveAction,
        private modalService: ModalService, public changeDetectorRef: ChangeDetectorRef,
        private params: NavParams, public viewCtrl: ViewController,
        private loginStore: LoginStore,
        private editService: EditService,
        private modalProvider: ModalPlanConfirmationComponentProvider,
        private navCtrl: NavController
    ) {
        super();
        this.pageComponentList = [];
        this.state = this.store.getState();
        this.chatFlowAccessor = new ExistingReserveChatFlowAccessor();
        this.originShowChats = [...this.state.showChats];
        this.originShowConfirm = [...this.state.showConfirm];
        this.originSubmitData = ObjectUtils.clone(this.state.submitData);
        this.originName = this.params.get('name');
    }

    public ngOnInit() {
        if (this.originName === 'addedTransferMonth1') {
            this.state.submitData.addedTransferMonth1 = undefined;
            this.state.submitData.addedTransferAmount1 = undefined;
            this.state.submitData.addedTransferMonth2 = undefined;
            this.state.submitData.addedTransferAmount2 = undefined;
            this.state.submitData.addedTransferMonth3 = undefined;
            this.state.submitData.addedTransferAmount3 = undefined;
            this.state.submitData.addedTransferMonth4 = undefined;
            this.state.submitData.addedTransferAmount4 = undefined;
        }
        this.currentTitle = this.params.get('isCurrentPage') ? this.params.get('currentTitle') : '';
        this.startOrder = this.params.get('startOrder');
        this.endOrder = this.params.get('endOrder');
        this.currentPageIndex = this.params.get('pageIndex');
        this.isCurrentPage = true;
        this.needPassword = this.params.get('needPassword') ? false : true;
        this.initializeChatComponent();

        this.topBlockView.nativeElement.style.height = '0';
        this.store.registerSignalHandler(ExistingReserveSignal.WILL_PUSH_FOOTER, () => this.footerState = 'in');
        this.store.registerSignalHandler(ExistingReserveSignal.WILL_DISMISS_FOOTER, () => this.footerState = 'out');
    }

    public ngOnDestroy() {
        this.chatFlowAccessor.destroy();
        this.action.resetShowChats(this.originShowChats);
        this.store.unregisterSignalHandler(ExistingReserveSignal.WILL_PUSH_FOOTER);
        this.store.unregisterSignalHandler(ExistingReserveSignal.WILL_DISMISS_FOOTER);
    }

    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    /**
     * beforeAlert
     */
    public beforeAlert() {
        this.chatFlowAccessor.clearComponent();
    }

    /**
     * afterAlert
     */
    public afterAlert() {
        const lastNode = this.state.showChats[this.state.showChats.length - 1];
        this.action.resetLastNode({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    /**
     * Edit action
     * @param order order
     * @param pageIndex pageIndex
     */
    public editCallBack(order: number, pageIndex: number, answer: any) {
        this.editService.startEdit();
        this.beforeAlert();
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.editBtn, buttonValue: 'edit' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.editTitle,
            buttonList,
            (item) => {
                const preventedItem = this.editService.endEdit();
                if (item.buttonValue === 'edit') {
                    this.action.editChart(order, pageIndex, answer);
                    this.chatFlowAccessor.clearComponent();
                    this.currentPageIndex = pageIndex;
                    this.currentPageComponent = this.getPageComponent(pageIndex);
                    this.getNextAnswer(order, pageIndex);
                    const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
                    this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
                } else {
                    if (preventedItem) {
                        this.getNextAnswer(preventedItem.order, preventedItem.pageIndex);
                    } else {
                        this.afterAlert();
                    }
                }
            },
            this.labels.alert.editSubTitle
        );
    }

    /**
     * Cancel action
     * @param value result
     */
    public handleCancelClickEmitter(value) {
        this.action.resetShowConfirm(this.originShowConfirm, this.originSubmitData);
        this.viewCtrl.dismiss(value);
    }

    /**
     * Initialize
     */
    private initializeChatComponent() {
        this.action.clearShowChats();
        if (this.currentPageIndex === 99) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, 'ReserveDepositModifyRenderer');
        } else if (this.currentPageIndex === 98) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, 'TimeDepositModifyRenderer');
        } else if (this.currentPageIndex === 100) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, 'HolderCareerModifyRenderer');
        } else if (this.currentPageIndex === 101) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, 'ExistingRegularSelectProductComponent');
        }
        this.getNextAnswer(this.startOrder, this.currentPageIndex);
    }

    /**
     * Get next answer
     * @param order next order
     * @param pageIndex pageIndex
     */
    private getNextAnswer(order: number, pageIndex: number) {
        if (this.startOrder != null && this.endOrder != null && (order > this.endOrder || order < this.startOrder)) {
            this.viewCtrl.dismiss(this.state.submitData);
            return;
        }
        Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
            this.action.getNextChatByAnswer(order, pageIndex);
        });
    }

    /**
     * Create render
     * @param componentType type
     */
    private mappingComponentList(componentType: string): ExistingReserveChatFlowRenderer {
        let render: ExistingReserveChatFlowRenderer;
        if (componentType === 'ReserveDepositModifyRenderer' || componentType === undefined) {
            render = new ReserveDepositModifyRenderer(this.chatFlowAccessor,
                this.footerContent, this.loginStore, this.store);
        } else if (componentType === 'TimeDepositModifyRenderer') {
            render = new TimeDepositModifyRenderer(this.chatFlowAccessor,
                this.footerContent, this.store);
        } else if (componentType === 'HolderCareerModifyRenderer') {
            render = new HolderCareerModifyRenderer(this.chatFlowAccessor,
                this.footerContent, this.store);
        } else if (componentType === 'ExistingRegularSelectProductComponent') {
            render = new ExistingRegularSelectProductRenderer(this.chatFlowAccessor,
                this.footerContent, this.store, this.loginStore, this.navCtrl, this.modalProvider, this.modalService);
        }
        return render;
    }

    /**
     * Get page component
     * @param pageIndex pageIndex
     * @param componentType type
     */
    private getPageComponent(pageIndex: number, componentType?: string): ExistingReserveChatFlowRenderer {
        if (this.pageComponentList[pageIndex] == null) {
            this.pageComponentList[pageIndex] = this.mappingComponentList(componentType);
            this.pageComponentList[pageIndex].nextChatEvent.subscribe((params) => {
                this.getNextAnswer(params.order, params.pageIndex);
            });
        }

        if (this.chatFlowAccessor) {
            this.chatFlowAccessor.setRenderer(this.pageComponentList[pageIndex]);
            this.chatFlowAccessor.setContent(this.content);
        }
        return this.pageComponentList[pageIndex];
    }

}
