import {
    ComponentFactory,
    ComponentFactoryResolver, ComponentRef,
    EventEmitter,
    NgZone
} from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { AppProperties } from 'app.properties';
import { ExistingReserveAction } from 'dhdt/branch/pages/existing-reserve/action/existing-reserve.action';
import { ExistingReserveChatFlowRenderer } from 'dhdt/branch/pages/existing-reserve/chat-flow/existing-reserve-chat-flow.renderer';
import { ExistingReserveSignal, ExistingReserveStore } from 'dhdt/branch/pages/existing-reserve/store/existing-reserve.store';
import { ComponentProvider } from 'dhdt/branch/shared/components/component-provider';
import { Content } from 'ionic-angular';
import { Observable } from 'rxjs';

/**
 * chat flow accessor.
 */
export class ExistingReserveChatFlowAccessor {

    protected action: ExistingReserveAction;
    protected store: ExistingReserveStore;

    private _chatFlowRenderer: ExistingReserveChatFlowRenderer;

    private factory: ComponentFactory<ComponentProvider>;
    private qf: ComponentRef<ComponentProvider>;
    private componentFactoryResolver: ComponentFactoryResolver;
    private ngZone: NgZone;

    constructor(public chatFlowRenderer?: ExistingReserveChatFlowRenderer) {

        this.action = InjectionUtils.injector.get(ExistingReserveAction);
        this.store = InjectionUtils.injector.get(ExistingReserveStore);
        this.componentFactoryResolver = InjectionUtils.injector.get(ComponentFactoryResolver);
        this.ngZone = InjectionUtils.injector.get(NgZone);
        this._chatFlowRenderer = chatFlowRenderer;
        this.addListioner();
    }

    /**
     * component add
     */
    public addComponent(datas: any, from: any, to: any, options: any = {}): EventEmitter<any> {
        this.factory = this.componentFactoryResolver.resolveComponentFactory(from);
        this.qf = to.createComponent(this.factory);
        this.qf.instance.datas = datas;
        this.qf.instance.options = options;
        this.qf.instance.content = this._chatFlowRenderer.content;
        this.qf.instance.footer = to;
        this.store.sendSignal(ExistingReserveSignal.WILL_PUSH_FOOTER);
        if (this.qf.instance.refresh) {
            this.qf.instance.refresh.subscribe(() => {
                this.resize();
            });
        }
        return this.qf.instance.launch;
    }

    /**
     * Resize view
     * Called whenever view change
     */
    public resize() {
        this._chatFlowRenderer.content.resize();
        setTimeout(() => {
            if (this._chatFlowRenderer.content && this._chatFlowRenderer.content._scroll !== null) {
                this._chatFlowRenderer.content.scrollToBottom();
            }
        }, 400);
    }

    /**
     * component clear
     */
    public clearComponent() {
        if (this.qf) {
            this.qf.destroy();
            this.store.sendSignal(ExistingReserveSignal.WILL_DISMISS_FOOTER);
        }
    }

    /**
     * Signal destroy
     */
    public destroy(): void {
        this.unregisterSignal();
    }

    /**
     * set content to chatFlowRenderer
     */
    public setContent(content: Content) {
        this._chatFlowRenderer.content = content;
    }

    /**
     * Listioner added and Signal unregistered
     */
    public setRenderer(chatFlowRenderer?: ExistingReserveChatFlowRenderer) {
        this._chatFlowRenderer = chatFlowRenderer;
        this.unregisterSignal();
        this.addListioner();
    }

    /**
     * Listioner added
     */
    private addListioner() {
        this.store.registerSignalHandler(ExistingReserveSignal.GET_QUESTION, (pageIndex: number) => {
            // show first message
            this.clearComponent();
            this.action.getNextChatByAnswer(0, pageIndex);
        });
        this.store.registerSignalHandler(ExistingReserveSignal.SEND_ANSWER, (datas) => {
            const question = datas.question;
            const pageIndex = datas.pageIndex;
            this.clearComponent();
            switch (question.type) {
                case 'text':
                case 'judge':
                case 'route':
                case 'image': {
                    this._chatFlowRenderer.rendererComponents(question, pageIndex);
                    break;
                }
                default: {
                    Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                        this.ngZone.run(() => {
                            this._chatFlowRenderer.rendererComponents(question, pageIndex);
                        });
                    });
                }
            }
        });
    }

    /**
     * Unregister signal
     */
    private unregisterSignal() {
        this.store.unregisterSignalHandler(ExistingReserveSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(ExistingReserveSignal.SEND_ANSWER);
    }
}
