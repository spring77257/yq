import { AppProperties } from 'app.properties';

/**
 * DBに格納する指定文言
 */
export class DBConsts {
    public static readonly deviceId = '111';

    public static readonly applyBusinessType = '01'; // 申込業務区分
    public static readonly insertStatus = '00'; // ステータス
}

export class FileSrcConsts {
    // 自動継続方法の説明画像
    public static readonly AUTOMIC_RENEWAL_IMAGE_SRC = AppProperties.IMG_ROOT + 'information/img_information_automatic_continuation@3x.png';
}

export enum TransferControlPattern {
    // 1. 普通預金口座：あり、総合口座普通預金口座：あり
    ORDINARY_MULIT = '1',
    // 2. 普通預金口座：あり、総合口座普通預金口座：なし
    COMPOUND_FLAG_NO = '2',
    // 3. 普通預金口座：なし、総合口座普通預金口座：あり
    COMPOUND_FLAG_YES = '3',
}

export enum ChatControlPattern {
    // 1. 総合口座普通預金口座：あり、総合口座定期預金口座：あり、普通定期預金口座：あり
    PATTERN_ONE = '1',
    // 2. 総合口座普通預金口座：あり、総合口座定期預金口座：あり、普通定期預金口座：なし
    PATTERN_TWO = '2',
    // 3. 総合口座普通預金口座：あり、総合口座定期預金口座：なし、普通定期預金口座：あり
    PATTERN_THREE = '3',
    // 4. 総合口座普通預金口座：あり、総合口座定期預金口座：なし、普通定期預金口座：なし
    PATTERN_FOUR = '4',
    // 5. 総合口座普通預金口座：なし、総合口座定期預金口座：なし、普通定期預金口座：あり（１件）
    PATTERN_FIVE = '5',
    // 6. 総合口座普通預金口座：なし、総合口座定期預金口座：なし、普通定期預金口座：な
    PATTERN_SIX = '6',
    // 7. 総合口座普通預金口座：なし、総合口座定期預金口座：なし、普通定期預金口座：あり（2件以上）
    PATTERN_SEVEN = '7',
}

export enum RegularPurpose {
    REGULAR = '1',  // 定期
    RESERVE = '0',  // 積立
}

export enum CompoundAccountStatus {
    // 総合口座普通預金口座：あり
    YES = '1',
    // 総合口座普通預金口座：なし
    NO = '0',
}

export const Consts = {
    // 顧客申込完了時間
    CUSTOMER_APPLY_ENDDATE: 'customerApplyEndDate',
    // 行員確認スタート時間
    BANKCLERK_AUTHENTICATION_START_DATE: 'bankclerkAuthenticationStartDate',
    // 選択された商品の名前
    SELECT_PRODUCT_NAME: 'selectProductName',
    // その他の商品
    OTHER_PRODUCT_TYPE: '-1',
};

export const Relationship = {
    OTHER_CODE: '5'
};
