import { HttpClient } from '@angular/common/http';
import { Injectable, NgZone } from '@angular/core';
import { Action } from 'adep/flux';
import { LabelService } from 'adep/services';
import { API_URL, ApplyDate, ClearSavingImagesClickRecordType,
    CodeCategory, Constants, HostResultCode, SubmitDataKey } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { AccountBalanceInquiryInterface } from 'dhdt/branch/shared/interface/account-balance-inquiry.interface';
import { AccountInfoInquiryInterface } from 'dhdt/branch/shared/interface/account-info-inquiry.interface';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { TimeBalanceInquiryInterface } from 'dhdt/branch/shared/interface/time-balance-inquiry.interface';
import { DocumentCategorySubjectData } from 'dhdt/branch/shared/modules/document-category/entity/document-category.entity';
import { DocumentCategoryObserverAction } from 'dhdt/branch/shared/modules/document-category/service/document-category.service';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { HostErrorService } from 'dhdt/branch/shared/services/host-error.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { HttpService, HttpStatus } from 'dhdt/branch/shared/services/http.service';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { App } from 'ionic-angular';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export namespace ExistingReserveActionType {
    export const GET_SAVING_QUESTION_TEMPLATE: string = 'ExistingReserveActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const NEXT_CHAT: string = 'ExistingReserveActionType_NEXT_CHAT';
    export const CLEAR: string = 'ExistingReserveActionType_LOAD_TEMPLATE_CLEAR';
    export const CLEAR_DOCUMENTS: string = 'ExistingReserveActionType_CLEAR_DOCUMENTS';
    export const CLEAR_SHOW_CHATS: string = 'ExistingReserveActionType_CLEAR_SHOW_CHATS';
    export const BRANCH_STATUS_INSERT: string = 'ExistingReserveActionType_BRANCH_STATUS_INSERT';
    export const BRANCH_STATUS_UPDATE: string = 'ExistingReserveActionType_BRANCH_STATUS_UPDATE';
    export const SET_SYSTEM_TIME: string = 'ExistingReserveActionType_SET_SYSTEM_TIME';
    export const SET_CUSTOMER_APPLY_START_DATE: string = 'ExistingReserveActionType_SET_CUSTOMER_APPLY_START_DATE';
    export const SET_ANSWER: string = 'ExistingReserveActionType_SET_ANSWER';
    export const EDIT_CHAT: string = 'ExistingReserveActionType_EDIT_CHAT';
    export const SET_STATE_SUBMIT_DATA_VALUE: string = 'ExistingReserveActionType_SET_STATE_SUBMIT_DATA_VALUE';
    export const RETRIEVE_DROP_LIST: string = 'ExistingReserveActionType_RETRIEVE_DROP_LIST';
    export const GET_HOLDER_ZIP_CODE = 'ExistingReserveActionType_GET_HOLDER_ZIP_CODE';
    export const BRANCH_INFO_INSERT: string = 'ExistingReserveActionType_BRANCH_INFO_INSERT';
    export const CHAT_FLOW_COMPELETE = 'ExistingReserveActionType_CHAT_FLOW_COMPELETE';
    export const RESET_LAST_NODE = 'ExistingReserveActionType_RESET_LAST_NODE';
    export const SUBMIT_TIME_SAVING_APPLY_INFO = 'ExistingReserveActionType_SUBMIT_TIME_SAVING_APPLY_INFO';
    export const SET_CUSTOMER_APPLY_END_DATE: string = 'ExistingReserveActionType_SET_CUSTOMER_APPLY_END_DATE';
    export const SET_BANKCLERK_CONFIRM_START_DATE: string = 'ExistingReserveActionType_SET_BANKCLERK_CONFIRM_START_DATE';
    export const SET_BANKCLERK_CONFIRM_END_DATE: string = 'ExistingReserveActionType_SET_BANKCLERK_CONFIRM_END_DATE';
    export const SET_BANKCLERK_ID: string = 'ExistingReserveActionType_SET_BANKCLERK_ID';
    export const SET_BRANCH_INFO: string = 'ExistingReserveActionType_SET_BRANCH_INFO';
    export const SET_AGENCY_BRANCH_INFO: string = 'ExistingReserveActionType_SET_AGENCY_BRANCH_INFO';
    export const SET_INTEREST_COMPUTATION_METHOD: string = 'ExistingReserveActionType_SET_INTEREST_COMPUTATION_METHOD';
    export const CLEAR_OPEN_ACCOUNT_PURPOSE: string = 'ExistingReserveActionType_CLEAR_OPEN_ACCOUNT_PURPOSE';

    export const GET_CANCELABLE_ITEM_LIST = 'ExistingReserveActionType_GET_CANCELABLE_ITEM_LIST';
    export const MODIFY_ID_CANCELABLE_ITEM_LIST = 'ExistingReserveActionType_MODIFY_ID_CANCELABLE_ITEM_LIST';
    export const MODIFY_METHOD_CANCELABLE_ITEM_LIST = 'ExistingReserveActionType_MODIFY_METHOD_CANCELABLE_ITEM_LIST';
    export const MODIFY_CANCEL_AMOUNT_CANCELABLE_ITEM_LIST = 'ExistingReserveActionType_MODIFY_CANCEL_AMOUNT_CANCELABLE_ITEM_LIST';
    export const ITEM_COUNT = 'ExistingReserveActionType_ITEM_COUNT';
    export const DELETE_ITEMS_FROM_CANCELABLE_ITEM_LIST = 'ExistingReserveActionType.DELETE_ITEMS_FROM_CANCELABLE_ITEM_LIST';
    export const SUBMIT_TIME_SAVING_ORANGE_APPLY_INFO = 'ExistingReserveActionType_SUBMIT_TIME_SAVING_ORANGE_APPLY_INFO';
    export const SUBMIT_TIME_SAVING_LOVE_APPLY_INFO = 'ExistingReserveActionType_SUBMIT_TIME_SAVING_LOVE_APPLY_INFO';
    export const SUBMIT_TIME_SAVING_SMILE_APPLY_INFO = 'ExistingReserveActionType_SUBMIT_TIME_SAVING_SMILE_APPLY_INFO';
    export const SUBMIT_EXIST_RESERVE_APPLY_INFO = 'ExistingReserveActionType_SUBMIT_EXIST_RESERVE_APPLY_INFO';
    export const GET_CONFIRM_PAGE_TEMPLATE: string = 'ExistingReserveActionType_GET_CONFIRM_PAGE_TEMPLATE';
    export const RESET_SHOWCHATS = 'ExistingReserveActionType_RESET_SHOWCHATS';
    export const MODIFY_CHECKBOX_STATUS: string = 'ExistingReserveActionType_MODIFY_CHECKBOX_STATUS';
    export const GET_DEPOSIT_PERIOD_YEAR_MONTH: string = 'ExistingReserveActionType_GET_DEPOSIT_PERIOD_YEAR_MONTH';
    export const SET_CIF_INFORMATION = 'ExistingReserveActionType_SET_CIF_INFORMATION';  // CIF情報照会
    export const SUBMIT_EXIST_SAVING_APPLY_INFO = 'ExistingReserveActionType_SUBMIT_EXIST_SAVING_APPLY_INFO';
    export const GET_ENROLLING_YEAR_TEXT: string = 'GET_ENROLLING_YEAR_TEXT';

    export const PASSBOOK_PRINT_MESSAGE_SKIP: string = 'PASSBOOK_PRINT_MESSAGE_SKIP';
    export const SET_SWIPE_INFO: string = 'ExistingReserveActionType_SET_SWIPE_INFO';
    export const ACCOUNT_INFO: string = 'ExistingReserveActionType_ACCOUNT_INFO';
    export const ACCOUNT_INFO_2ND: string = 'ExistingReserveActionType_ACCOUNT_INFO_2ND';
    export const SAVING_ACCOUNT_INFO: string = 'ExistingReserveActionType_SAVING_ACCOUNT_INFO';
    export const SELECTED_ACCOUNT_INFO: string = 'ExistingReserveActionType_SELECTED_ACCOUNT_INFO';
    export const RESET_SHOW_CONFIRM: string = 'ExistingReserveActionType_RESET_SHOW_CONFIRM';
    export const GET_DEFAULT_ADDRESS: string = 'ExistingReserveActionType_GET_DEFAULT_ADDRESS';
    export const RESET_SPECIAL_TRANSFER_INFO: string = 'ExistingReserveActionType_RESET_SPECIAL_TRANSFER_INFO';
    export const CLEAR_SPECIAL_TRANSFER_INFO_2: string = 'ExistingReserveActionType_CLEAR_SPECIAL_TRANSFER_INFO_2';
    export const SET_PRODUCT_TYPE: string = 'ExistingReserveActionType_SET_PRODUCT_TYPE';
    export const SET_TIME_BALANCE: string = 'ExistingReserveActionType_SET_TIME_BALANCE';
    export const SET_BUSINESS_INFO: string = 'ExistingReserveActionType_SET_BUSINESS_INFO';
    export const SET_SAMEHOLDER_CIF_INFORMATION: string = 'ExistingReserveActionType_SET_SAMEHOLDER_CIF_INFORMATION';
    export const SET_DUE_DATE: string = 'ExistingReserveActionType_SET_DUE_DATE';
    export const SET_DUE_DATE_AND_DEPOSIT_PERIOD_YEARMONTH: string = 'ExistingReserveActionType_SET_DUE_DATE_AND_DEPOSIT_PERIOD_YEARMONTH';
    export const SET_DEPOSIT_PERIOD_YEARMONTH: string = 'ExistingReserveActionType_SET_DEPOSIT_PERIOD_YEARMONTH';
    export const INQUIRE_ACCOUNT_BALANCE: string = 'ExistingReserveActionType_INQUIRE_ACCOUNT_BALANCE';
    export const SET_ONLY_NAME_KANJI_EDIT_FLG: string = 'ExistingReserveActionType_SET_ONLY_NAME_KANJI_EDIT_FLG';
    export const RESET_RECEIPT_RENEW_INFO: string = 'ExistingReserveActionType_RESET_RECEIPT_RENEW_INFO';
    export const RESET_RECEIPT_SCHEDULE_INFO: string = 'ExistingReserveActionType_RESET_RECEIPT_SCHEDULE_INFO';
    export const SET_AUTOMATIC_TRANSFER_START_DATE: string = 'ExistingReserveActionType_SET_AUTOMATIC_TRANSFER_START_DATE';

    export const GET_NEXT_BUSINESS_DAY = 'ExistingReserveActionType_GET_NEXT_BUSINESS_DAY';
    export const GET_EXISTING_ACCOUNT_INFO = 'ExistingReserveActionType_GET_EXISTING_ACCOUNT_INFO';
    export const GET_ORDINARILY_ACCOUNT_INFO = 'ExistingReserveActionType_GET_ORDINARILY_ACCOUNT_INFO';
    export const SAVE_DOCUMENT_IMAGE = 'ExistingReserveActionType_SAVE_DOCUMENT_IMAGE';
    export const CLEAN_DOCUMENT_IMAGE = 'ExistingReserveActionType_CLEAN_DOCUMENT_IMAGE';
    export const SET_CIF_INFO = 'ExistingReserveActionType_SET_CIF_INFO';

    export const FIRST_TRANSFER_DAY = 'ExistingReserveActionType_FIRST_TRANSFER_DAY';

    export const REMOVE_CHAT = 'ExistingReserveActionType_REMOVE_CHAT';
    export const RECEPTION_CHECK = 'ExistingReserveActionType_RECEPTION_CHECK';
    export const SET_STATE_SUBMIT_DATA = 'ExistingReserveActionType_SET_STATE_SUBMIT_DATA';
    export const SET_STATE_DATA = 'ExistingReserveActionType_SET_STATE_DATA';
    export const SUBMIT_DATA_BACKUP = 'ExistingReserveActionType_SUBMIT_DATA_BACKUP';
    export const UPDATA_SUBMIT_DATA_BACKUP = 'ExistingReserveActionType_UPDATA_SUBMIT_DATA_BACKUP';
    export const SET_IDENTIFICATION_DOCUMENT = 'ExistingReserveActionType_SET_IDENTIFICATION_DOCUMENT';

    export const RECEPTION_CHECK_TRANSFER = 'ExistingReserveActionType_RECEPTION_CHECK_TRANSFER';
    export const RECEPTION_CHECK_DEPOSIT = 'ExistingReserveActionType_RECEPTION_CHECK_DEPOSIT';
    export const RECEPTION_CHECK_DEPOSIT_TRANSFER = 'ExistingReserveActionType_RECEPTION_CHECK_DEPOSIT_TRANSFER';

    export const SET_SUBMIT_DATA = 'ExistingReserveActionType_SET_SUBMIT_DATA';

    export const REMOVE_NOT_MASKING_CONFIRM_IMAGES = 'ExistingReserveActionType_REMOVE_NOT_MASKING_CONFIRM_IMAGES';
    export const RESET_NOT_MASKING_CONFIRM_IMAGES = 'ExistingReserveActionType_RESET_NOT_MASKING_CONFIRM_IMAGES';

    export const RESET_SUBMIT_DATA = 'ExistingReserveActionType_RESET_SUBMIT_DATA';

    export const RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES = 'ExistingReserveActionType_RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES';
    export const CHAT_FLOW_RETURN = 'ExistingReserveActionType_CHAT_FLOW_RETURN';
}

@Injectable()
export class ExistingReserveAction extends Action implements DocumentCategoryObserverAction {
    constructor(
        private httpService: HttpService,
        private httpClient: HttpClient,
        private hostErrorService: HostErrorService,
        private ngZone: NgZone,
        private labelService: LabelService,
        private appCtrl: App,
        private errorMessageService: ErrorMessageService
    ) {
        super();
    }

    /**
     * 写真未確認状態管理オブジェクトから確認済内容を削除
     *
     * @param {{documentName: string, index: number}} maskingConfirmImgStatus
     * @memberof SavingsAction
     */
    public removeNotMaskingConfirmImages(maskingConfirmImgStatus: {documentName: string, index: number}) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES,
            data: maskingConfirmImgStatus
        });
    }

    /**
     * マスキング確認完了しないオブジェクトをリセット。
     *
     * @param {ClearSavingImagesClickRecordType} type リセットタイプ
     * @memberof SavingsAction
     */
    public resetNotMaskingConfirmImages(type: ClearSavingImagesClickRecordType) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.RESET_NOT_MASKING_CONFIRM_IMAGES,
            data: type
        });
    }

    /**
     * マスキング確認完了しないオブジェクトをリセット。
     *
     * @param {ClearSavingImagesClickRecordType} type リセットタイプ
     * @memberof
     */
    public resetSpecialNotMaskingConfirmImages(specalDocumentName: string) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.RESET_SPECIAL_NOT_MASKING_CONFIRM_IMAGES,
            data: specalDocumentName
        });
    }

    /**
     * ICカードの認証処理を行う。
     * @param params ICカード情報
     */
    public cardIinfoCheck(params: any) {
        return new Promise((resolve, reject) => {
            this.httpService.post('/card-info/check', params, null, SpinnerType.SHOW_TRANSPARENT, true)
                .subscribe((result) => {
                    if (result.status === HttpStatus.SUCCESS) {
                        resolve(true);
                    } else if (result.status === HttpStatus.HOST_ERROR) {
                        this.hostErrorService.push({
                            resultCode: result.errors.data.resultCode,
                            errorCode: result.errors.data.errorCode,
                            message: result.errors.message,
                            handel: () => {
                                resolve(false);
                            }
                        });
                    } else {
                        throw new HttpStatusError('/card-info/check', result.status, result.errors);
                    }
                }, (error) => {
                    reject(error);
                });
        });
    }

    /**
     * サーバーのシステム時間で、自動振替開始日を取得
     */
    public getFirstAccumulationDate() {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((res) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.FIRST_TRANSFER_DAY,
                data: res.result.value
            });
        });
    }

    public setStateSubmitData(data) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_STATE_SUBMIT_DATA,
            data
        });
    }

    public setIdentificationDocument(data) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_IDENTIFICATION_DOCUMENT,
            data: data
        });
    }

    /**
     * cif情報をセット
     * @param cifInfo cif情報
     */
    public setCifInfo(cifInfo: any) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_CIF_INFO,
            data: cifInfo
        });
    }

    /**
     * submit dataを更新
     *
     * @param data 書類カテゴリと選択された書類
     * @param isHolderPage 本人確認画面フラグ
     * @param isHolder 本人フラグ
     */
    public setDocumentCategory(data: DocumentCategorySubjectData, isHolderPage: boolean, isHolder: boolean) {
        switch (data.code) {
            // 本人確認情報
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_TYPE:
                const infos = isHolder ? [{
                    key: isHolderPage ? SubmitDataKey.HOLDER_ID_DOC_TYPE : SubmitDataKey.AGENT_ID_DOC_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                }, {
                    key: SubmitDataKey.RECEIPT_METHOD,
                    value: data.entity ? (data.entity.filler6 === CodeCategory.FACEID ?
                        CodeCategory.RECEIPT_METHOD_ISSUE : CodeCategory.RECEIPT_METHOD_MAIL) :
                        CodeCategory.RECEIPT_METHOD_MAIL
                }] : [{
                    key: isHolderPage ? SubmitDataKey.HOLDER_ID_DOC_TYPE : SubmitDataKey.AGENT_ID_DOC_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                }];
                this.setStateSubmitDataValue(infos);
                break;
            // 本人確認書類（顔写真ない）の補完書類の種類
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_PHOTOGRAPH_TYPE:
                this.setStateSubmitDataValue([{
                    key: isHolderPage ? SubmitDataKey.HOLDER_ID_DOC_PHOTO_TYPE : SubmitDataKey.AGENT_ID_DOC_PHOTO_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                }]);
                break;
            // 本人確認書類（住所異なる）の補完書類の種類
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_ADDRESS_TYPE:
                this.setStateSubmitDataValue([{
                    key: isHolderPage ? SubmitDataKey.HOLDER_ID_DOC_ADDRESS_TYPE : SubmitDataKey.AGENT_ID_DOC_ADDRESS_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                }]);
                break;
            // コピー徴求ができない理由
            case CodeCategory.CODE_CATEGORY_NO_COPY_REASON:
            // 住所が相違する理由
            case CodeCategory.CODE_CATEGORY_DIFFERENT_ADDRESS_REASON:
            // 遠隔地等住所等の場合の理由
            case CodeCategory.CODE_CATEGORY_FAR_ADDRESS_REASON:
                this.setStateSubmitDataValue([{
                    key: data.key,
                    value: data.entity ? data.entity.data : null
                }]);
                break;
        }
    }

    /**
     * 取次店番を設定する
     * @param branchNo 支店番号
     */
    public setAgencyBranchInfo(branchNo: string) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_AGENCY_BRANCH_INFO,
            data: { branchNo: branchNo }
        });
    }

    public getCategoryNameLogic() {
        return this.httpService.get('/categoryCodes/retrieve', { params: { categoryCode: '049' } })
            .pipe(map((res) => res.result));
    }

    /**
     * 支店情報設定
     * @param branchNameKanji 支店名
     * @param branchNo 支店番号
     */
    public setBranchInfo(branchNameKanji, branchNo: string) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_BRANCH_INFO,
            data: {
                branchNameKanji: branchNameKanji,
                branchNo: branchNo
            }
        });
    }

    /**
     * 行員IDを設定する
     * @param bankclerkId 行員ID
     */
    public setBankclerkId(bankclerkId: string) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_BANKCLERK_ID,
            data: { bankclerkId: bankclerkId }
        });
    }

    /**
     * チャットテンプレートをロードする
     * @param file yamlファイル名
     * @param pageIndex ページインデックス
     */
    public loadTemplate(file: string, pageIndex: number) {
        this.httpService.get('/chatflow/definition/' + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos
                }
            });
        });
    }

    /**
     * タブレット申し込み情報にデータをインサートする
     * @param params タブレット申し込み情報
     */
    public branchStatusInsert(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.BRANCH_STATUS_INSERT,
                data: response.result
            });
        });
    }

    /**
     * 郵便番号を取得する
     * @param prefectureKanji 県名漢字
     * @param countyUrbanVillageKanji 市区町村漢字
     * @param streetKanji 町丁名漢字
     */
    public getHolderZipCode(prefectureKanji: string, countyUrbanVillageKanji: string, streetKanji: string) {
        const params = {
            prefectureKanji: prefectureKanji,
            countyUrbanVillageKanji: countyUrbanVillageKanji,
            streetKanji: streetKanji
        };
        this.httpService.get(API_URL.ADDRESS_ZIP_CODE_SEARCH, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.GET_HOLDER_ZIP_CODE,
                data: response.result.zipCode
            });
        }
        );
    }

    /**
     * タブレット申し込み情報にデータを更新する
     * @param params タブレット申し込み情報
     */
    public branchStatusUpdate(params: any) {
        this.httpService.post(API_URL.BRANCH_STATUS_UPDATE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.BRANCH_STATUS_UPDATE,
                data: response.result
            });
        });
    }

    /**
     * 次のステップを取得する
     * @param order オーダー
     * @param pageIndex ページインデックス
     */
    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    /**
     * ストアをクリアする
     */
    public clearStore() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.CLEAR
        });
    }

    /**
     * Document情報をクリアする
     */
    public clearStoreDocuments() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.CLEAR_DOCUMENTS
        });
    }

    /**
     * チャットの表示内容をクリアする
     */
    public clearShowChats() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.CLEAR_SHOW_CHATS
        });
    }

    /**
     * 顧客開始時間を設定する
     * @param date システム日付
     */
    public setCustomerApplyStartDate(date?: string) {
        if (date) {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.SET_CUSTOMER_APPLY_START_DATE,
                data: date
            });
        } else {
            this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: ExistingReserveActionType.SET_CUSTOMER_APPLY_START_DATE,
                    data: response.result.value
                });
            });
        }
    }

    /**
     * 顧客申し込み完了時間を設定する
     */
    public setCustomerApplyEndDate() {
        this.setAsSystemTime(ApplyDate.CUSTOMER_APPLY_END_DATE);
    }

    /**
     * 行員認証開始時間を設定する
     */
    public setBankclerkAuthenticationStartDate() {
        this.setAsSystemTime(ApplyDate.BANKCLERK_AUTHENTICATION_START_DATE);
    }

    /**
     * set the item value as the current time of server
     * @param key the checbox item need to modify status
     */
    public setAsSystemTime(key: string) {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.SET_SYSTEM_TIME,
                data: {
                    key: key,
                    systemTime: response.result.value
                }
            });
        });
    }

    /**
     * チャット内容を編集する
     *
     * @param order オーダー
     * @param pageIndex ページインデックス
     * @param answerOrder 応答順
     */
    public editChart(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.EDIT_CHAT,
            data: { order: order, pageIndex: pageIndex, answerOrder: answerOrder, orderIndex: orderIndex }
        });
    }

    /**
     * 回答を設定する
     *
     * @param answer 回答
     */
    public setAnswer(answer: { text: string, value: Array<{ key: string, value: any }> }) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_ANSWER,
            data: answer
        });
    }

    /**
     * サブミットデータに値を設定する
     *
     * @param param 項目値
     */
    public setStateSubmitDataValue(param: Array<{ key: string, value: string }>) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_STATE_SUBMIT_DATA_VALUE,
            data: param
        });
    }

    public setSubmitData(submitData: any) {
        Object.keys(submitData).forEach((key) => {
            this.setStateSubmitDataValue([{
                key: key,
                value: submitData[key]
            }]);
        });
    }

    /**
     * 行員認証情報をサブミットする
     *
     * @param params データ
     */
    public saveSubmitData(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/bankclerk-confirm-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.BRANCH_INFO_INSERT,
                data: response.result
            });
        });
    }

    /**
     * コードマスタの情報を取得する
     *
     * @param params
     */
    public retrieveDropList(params: any) {
        this.httpService.get('/categoryCodes/retrieve', params).subscribe((response: any) => {
            // this.httpClient.get('./assets/datas/drop-down-list-account.json', params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.RETRIEVE_DROP_LIST,
                data: response.result
            });
        });
    }

    /**
     * チャットが完了
     * @param nextChatName 次のチャットの名
     */
    public chatFlowCompelete(nextChatName: string) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.CHAT_FLOW_COMPELETE,
            data: nextChatName
        });
    }

    /**
     * 最後のノードをチェックする
     * @param params パラメーター
     */
    public resetLastNode(params: { order: number, pageIndex: number }) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.RESET_LAST_NODE,
            data: params
        });
    }

    /**
     * 行員認証情報（定期）をサブミットする
     *
     * @param params データ
     */
    public submitTimeSavingApplyInfo(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/time-saving-apply-info-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.SUBMIT_TIME_SAVING_APPLY_INFO,
                data: response.result
            });
        });
    }

    /**
     * 行員認証情報をサブミットする
     *
     * @param params データ
     */
    public submitTimeSavingSmileApplyInfo(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/time-saving-smile-apply-info-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.SUBMIT_TIME_SAVING_SMILE_APPLY_INFO,
                data: response.result
            });
        });
    }

    /**
     * 行員認証情報をサブミットする
     *
     * @param params データ
     */
    public submitTimeSavingOrangeApplyInfo(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/time-saving-orange-apply-info-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.SUBMIT_TIME_SAVING_ORANGE_APPLY_INFO,
                data: response.result
            });
        });
    }

    /**
     * 行員認証情報をサブミットする
     *
     * @param params データ
     */
    public submitTimeSavingLoveApplyInfo(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/time-saving-love-apply-info-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.SUBMIT_TIME_SAVING_LOVE_APPLY_INFO,
                data: response.result
            });
        });
    }

    /**
     * 修正用テンプレートをロードする
     * @param params パラメーター
     */
    public loadConfirmPageTemplate(file: string, pageIndex: number) {
        this.httpService.get('/chatflow/definition/' + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.GET_CONFIRM_PAGE_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos,
                }
            });
        });
    }

    /**
     * Reset showChats to origin
     * @param originShowChats originShowChats
     */
    public resetShowChats(originShowChats: any[]) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.RESET_SHOWCHATS,
            data: originShowChats
        });
    }

    /**
     * modify checkbox status
     * @param name the checbox item need to modify status
     */
    public modifyCheckboxStatus(name: string) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.MODIFY_CHECKBOX_STATUS,
            data: name
        });
    }

    public getDepositPeriodYearMonth() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.GET_DEPOSIT_PERIOD_YEAR_MONTH,
            data: 'get depositPeriodYearMonth'
        });
    }

    /**
     * CIF情報照会
     * @param params CIF情報照会用パラメータ
     */
    public getCifInformation(cifParams: SimpleCifInfoInquiryInterface, inputParams: any, nextOrder, pageIndex, skip?) {
        this.httpService.post(API_URL.CB_GET_CIF_INFORMATION, cifParams).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.SET_CIF_INFORMATION,
                data: {
                    data: response.result,
                    inputParams: inputParams,
                    nextOrder: nextOrder,
                    pageIndex: pageIndex,
                    skip: skip
                }
            });
        });
    }

    /**
     * 重複口座CIF情報取得
     * @param params CIF情報照会用パラメータ
     */
    public getSameHolderCifInformation(cifParams: SimpleCifInfoInquiryInterface) {
        this.httpService.post(API_URL.CB_GET_SIMPLE_CIF_INFORMATION, cifParams).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.SET_SAMEHOLDER_CIF_INFORMATION,
                data: {
                    data: response.result,
                }
            });
        });
    }

    /**
     * 行員確認画面 submit
     * @param params params
     */
    public submitExistSavingsData(params: any) {
        this.httpService.post(
            API_URL.TIME_DEPOSIT_ACCOUNT_INFO,
            params,
            null,
            SpinnerType.SHOW
        ).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.SUBMIT_EXIST_SAVING_APPLY_INFO,
                data: response.result
            });
        });
    }

    /**
     * 積立定期
     * @param params params
     */
    public submitExistReserveData(params: any) {
        this.httpService.post(
            API_URL.INSTALLMENT_TIME_DEPOSIT_ACCOUNT_INFO,
            params,
            null,
            SpinnerType.SHOW
        ).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.SUBMIT_EXIST_RESERVE_APPLY_INFO,
                data: response.result
            });
        });
    }

    /**
     * 通帳に印刷する文字 skip
     */
    public passbookPrintMessageSkip() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.PASSBOOK_PRINT_MESSAGE_SKIP,
            data: true
        });
    }

    /**
     * get 入学年 YYYY --> YYYY(平成XX)年
     * @param params submitData.enrollingYear
     */
    public getEnrollingYearText(params: any) {
        this.httpService.get('/japaneseCalendar/birthday/convert-jp', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.GET_ENROLLING_YEAR_TEXT,
                data: response.result
            });
        });
    }

    /**
     * Request account info
     * @param params AccountInfoInquiryInterface
     * @param entity entity
     * @param pageIndex pageIndex
     */
    public requestAccountInfo(params: AccountInfoInquiryInterface, entity, pageIndex) {
        this.httpService.post(API_URL.CB_GET_ACCOUNT_INFORMATION, params)
            .subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: ExistingReserveActionType.ACCOUNT_INFO,
                    data: {
                        accountInfo: (response.result.accountInfo || []),
                        entity: entity,
                        pageIndex: pageIndex
                    }
                });
            });
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param params QRコード受付情報
     */
    public setSwipeInfo(params: any) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_SWIPE_INFO,
            data: params
        });
    }

    /**
     * 預入2回目の口座情報を取得する
     * @param params any
     * @param entity entity
     * @param pageIndex pageIndex
     */
    public requestAccountInfo2nd(params: any, entity, pageIndex) {
        this.httpService.post(API_URL.CB_GET_ACCOUNT_INFORMATION_2ND, params)
            .subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: ExistingReserveActionType.ACCOUNT_INFO_2ND,
                    data: {
                        result: (response.result || []),
                        entity: entity,
                        pageIndex: pageIndex
                    }
                });
            });
    }
    /**
     * Request saving account info
     * @param params AccountInfoInquiryInterface
     * @param entity entity
     * @param pageIndex pageIndex
     */
    public requestSavingAccountInfo(params: AccountInfoInquiryInterface, entity, pageIndex) {
        this.httpService.post(API_URL.GET_SAVING_ACCOUNT_INFO, params)
            .subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: ExistingReserveActionType.SAVING_ACCOUNT_INFO,
                    data: {
                        accountInfo: response.result.responseList,
                        entity: entity,
                        pageIndex: pageIndex
                    }
                });
            });
    }

    /**
     * 振替の払出口座取得
     * @param data any
     * @param entity entity
     * @param pageIndex pageIndex
     */
    public getSelectAccountInfo(data: any, entity, pageIndex) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SELECTED_ACCOUNT_INFO,
            data: {
                accountInfo:
                    (data || []),
                entity: entity,
                pageIndex: pageIndex
            }
        });
    }
    /**
     * Reset showConfirm and submitData
     * @param showConfirm showConfirm
     * @param submitData submitData
     */
    public resetShowConfirm(showConfirm: any, submitData: any) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.RESET_SHOW_CONFIRM,
            data: { showConfirm, submitData }
        });
    }

    /**
     * Request default address
     * @param params params
     * @param entity entity
     * @param pageIndex pageIndex
     */
    public requestDefaultAddress(params, entity, pageIndex) {
        this.httpService.get(API_URL.DEFAULT_ADDRESS, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.GET_DEFAULT_ADDRESS,
                data: {
                    result: response.result,
                    entity: entity,
                    pageIndex: pageIndex
                }
            });
        });
    }

    /**
     * 修正button 毎月振替日とは別に特定振替日(年2回まで)を設定しますか？ 設定しない
     * reset 特定振替日1,特定振替額1 / 特定振替日2,特定振替額2
     */
    public resetSpecialTransferInfo() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.RESET_SPECIAL_TRANSFER_INFO,
            data: true
        });
    }

    /* 商品タイプを設定
    * @param data 商品タイプ
    */
    public setProductType(data: string) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_PRODUCT_TYPE,
            data: data
        });
    }

    /**
     * 修正button 特定振替日(年2回まで)を追加で設定しますか？ 設定しない
     * clear specialTransferInfo2
     */
    public clearSpecialTransferInfo2() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.CLEAR_SPECIAL_TRANSFER_INFO_2,
            data: true
        });
    }

    /* 定期預金残高照会情報を取得する
    * @param params params
    */
    public getTimeBalance(params: TimeBalanceInquiryInterface) {
        this.httpService.post(API_URL.CB_GET_TIME_BALANCE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.SET_TIME_BALANCE,
                data: {
                    result: response.result,
                }
            });
        });
    }

    /**
     * 本人確認書類画像をクリア
     */
    public cleanIdentityDocumentImage(category: Constants.IdentityDocumentCategory) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.CLEAN_DOCUMENT_IMAGE,
            data: category
        });
    }

    /**
     * 本人確認書類画像を保存
     */
    public saveIdentityDocumentImage(document: { image: string, category: Constants.IdentityDocumentCategory }) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SAVE_DOCUMENT_IMAGE,
            data: document
        });
    }

    /**
     * 業務定義をstateにセット。
     */
    public setBusinessInfo() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_BUSINESS_INFO
        });
    }
    /**
     * 満期日を設定する
     */
    public setDueDate() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_DUE_DATE,
        });
    }

    /**
     * 預入期間(満期日)設定
     */
    public setDueDateAndDepositPeriodYearMonth() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_DUE_DATE_AND_DEPOSIT_PERIOD_YEARMONTH,
        });
    }

    /**
     * 登録不可漢字先が漢字氏名を入力した際、申込内容確認画面で修正ボタンが表示する
     */
    public setEditNameKanji() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_ONLY_NAME_KANJI_EDIT_FLG,
        });
    }

    /**
     * 口座残高照会
     * @param params 口座残高照会用パラメータ
     * @param nextOrder 次のオーダー
     * @param pageIndex ページインデックス
     */
    public inquireAccountBalance(params: AccountBalanceInquiryInterface) {
        this.httpService.post(API_URL.CB_GET_ACCOUNT_BALANCE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.INQUIRE_ACCOUNT_BALANCE,
                data: { result: response.result }
            });
        });
    }

    // サイクル指定
    public resetReceiptRenewInfo() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.RESET_RECEIPT_RENEW_INFO,
            data: true
        });
    }

    /**
     * 預入先口座と振替元口座取得
     */
    public getExistingAccountInfo(params: any) {
        this.httpService.post(API_URL.GET_DEPOSIT_ACCOUNT_INFO, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.GET_EXISTING_ACCOUNT_INFO,
                data: response.result
            });
        });
    }

    /**
     * 預入先口座と振替元口座取得
     */
    public getOrdinarilyAccountInfo(params: any) {
        this.httpService.post(API_URL.GET_ORDINARILY_ACCOUNT_INFO, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.GET_ORDINARILY_ACCOUNT_INFO,
                data: response.result
            });
        });
    }

    // 受取日指定
    public resetReceiptScheduleInfo() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.RESET_RECEIPT_SCHEDULE_INFO,
            data: true
        });
    }

    /**
     * 振替開始日／初回振替開始日を設定する
     */
    public setAutomaticTransferStartDate(data: string) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_AUTOMATIC_TRANSFER_START_DATE,
            data: data
        });
    }

    /**
     * #24401
     * 翌営業日を取得する。
     */
    public getNextBusinessDay(params: any) {
        this.httpService.post(API_URL.GET_NEXT_BUSINESS_DAY, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.GET_NEXT_BUSINESS_DAY,
                data: { data: response.result }
            });
        });
    }

    /**
     * 受付可否チェック
     * @param params 受付可否チェックパラメータ
     */
    public receptionCheck(params: any) {
        this.httpService.post(API_URL.RECEPTION_CHECK, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.RECEPTION_CHECK,
                data: response.result
            });
        });
    }

    public receptionCheckTransfer(params: any) {
        this.httpService.post(API_URL.RECEPTION_CHECK, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.RECEPTION_CHECK_TRANSFER,
                data: response.result
            });
        });
    }

    public receptionCheckDeposit(params: any) {
        this.httpService.post(API_URL.RECEPTION_CHECK, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.RECEPTION_CHECK_DEPOSIT,
                data: response.result
            });
        });
    }

    public receptionCheckDepositTransfer(depositParams: any, transferParams: any) {
        const depositRequest: Observable<any> = this.httpService.post(API_URL.RECEPTION_CHECK, depositParams);
        const transferRequest: Observable<any> = this.httpService.post(API_URL.RECEPTION_CHECK, transferParams);

        Observable.forkJoin(depositRequest, transferRequest).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingReserveActionType.RECEPTION_CHECK_DEPOSIT_TRANSFER,
                data: {
                    depositResponse: response[0].result,
                    transferResponse: response[1].result
                }
            });
        });
    }

    public setStateData(data) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_STATE_DATA,
            data: data
        });
    }
    public submitDataBackup() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SUBMIT_DATA_BACKUP
        });
    }

    public updateSubmitDataBackup(data) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.UPDATA_SUBMIT_DATA_BACKUP,
            data: data
        });
    }

    /**
     * submitDataの値を変更する
     *
     * @param {*} data
     * @memberof SavingsAction
     */
    public editSomeDataInSubmitData(index: number, key: string, val: any) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.SET_SUBMIT_DATA,
            data: {
                index: index,
                key: key,
                val: val
            }
        });
    }

    // データ初期化
    public resetSubmitData() {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.RESET_SUBMIT_DATA
        });
    }

    public chatFlowReturn(nextChatName: string, options: any = null) {
        this.dispatcher.dispatch({
            actionType: ExistingReserveActionType.CHAT_FLOW_RETURN,
            data: {
                name: nextChatName,
                options: options
            }
        });
    }
}
