// レスポンス
/**
 * 保有通帳・カード・印鑑情報照会レスポンス
 *
 * @export
 * @class MediumInfosResponse
 */
export class MediumInfosResponse {
    /** 結果コード */
    public resultCode: string;
    /** エラー種類 */
    public errorType: string;
    /** エラー理由 */
    public errorCode: string;
    /** 複数CIFバンクカード保有表示 */
    public doubleBc: string;
    /** 複数CIFワンセットカード保有表示 */
    public doubleOs: string;
    /** 媒体情報 */
    public mediumInfo: MediumInfo[];
}

/**
 * 媒体情報
 *
 * @export
 * @class MediumInfo
 */
export class MediumInfo {
    /** 顧客番号 */
    public customerId: string;
    /** 顧客開設日 */
    public customerOpeningDate: string;
    /** 一括与信停止 */
    public bulkCreditSuspension: string;
    /** カード利用停止 */
    public cardUsageLimitation: string;
    /** BC更新エラー表示 */
    public bcUpdateErrorStatus: string;
    /** 通帳預り情報 */
    public custodyPassbookInfo: CustodyPassbookInfo;
    /** 口座情報 */
    public accountInfo: AccountInfo[];
    /** 国内預金口座検索結果 */
    public domesticAccountSearchStatus: string;
    /** 外貨預金口座検索結果 */
    public forexAccountSearchStatus: string;
}

/**
 * 口座情報
 *
 * @export
 * @class AccountInfo
 */
export class AccountInfo {
    /** 店番 */
    public tenban: string;
    /** 店名 */
    public branchName: string;
    /** 科目 */
    public accountType: string;
    /** 口座番号 */
    public accountNo: string;
    /** 口座開設日 */
    public openingDate: string;
    /** 商品コード */
    public productCode: string;
    /** 通貨コード */
    public currencyCode: string;
    /** 残高 */
    public balance: string;
    /** 残高（円貨） */
    public yenBalance: string;
    /** 残高（外貨） */
    public forexBalance: string;
    /** 通帳証書区分 */
    public passbookCategory: string;
    /** カード事故混在表示 */
    public multiAccidentStatus: string;
    /** MC表示 */
    public mcStatus: string;
    /** IC表示 */
    public icStatus: string;
    /** BC表示 */
    public bcStatus: string;
    /** ワンセット表示 */
    public osStatus: string;
    /** WEB口座表示 */
    public webAccountStatus: string;
    /** IB情報 */
    public ibInfo: IbInfo;
    /** 保有通帳情報 */
    public passbookInfo: PassbookInfo;
    /** 事故注意情報 */
    public unacceptableInfo: UnacceptableInfo;
    /** 保有カード情報 */
    public holdingCardInfo: HoldingCardInfo[];
    /** BC情報 */
    public bcInfo: BcInfo;
    /** CL振替口座情報 */
    public loanAccountInfo: LoanAccountInfo;
    /** 定期預入明細情報 */
    public depositDetailsInfo: DepositDetailsInfo[];

}

/**
 * IB情報
 *
 * @export
 * @class IbInfo
 */
export class IbInfo {
    /** IB契約区分 */
    public ibCategory: string;
    /** サービス利用区分 */
    public serviceCategory: string;
}

/**
 * 保有通帳情報
 *
 * @export
 * @class PassbookInfo
 */
export class PassbookInfo {
    /** 重要用紙種類コード */
    public passbookTypeCode: string;
    /** 通帳残高 */
    public passbookBalance: string;
    /** 外貨通帳残高 */
    public forexPassbookBalance: string;
    /** 通帳再発行回次 */
    public passbookTimes: string;
    /** 通帳発行日 */
    public passbookDate: string;
    /** 未記帳明細件数 */
    public nonbookTimes: string;
    /** 総合口座情報 */
    public compoundAccountInfo: CompoundAccountInfo;
}

/**
 * 総合口座情報
 *
 * @export
 * @class CompoundAccountInfo
 */
export class CompoundAccountInfo {
    /** 複合通帳情報 */
    public compoundPassbookInfo: CompoundPassbookInfo[];
    /** 別冊総合口座表示 */
    public separateCompoundAccountStatus: string;
    /** 別冊総合口座情報 */
    public separateCompoundAccountInfo: SeparateCompoundAccountInfo[];
}

/**
 * 複合通帳情報
 *
 * @export
 * @class CompoundPassbookInfo
 */
export class CompoundPassbookInfo {
    /** 複合通帳情報-総合口座表示 */
    public compoundAcountStatus: string;
    /** 複合通帳情報-店番号 */
    public passbookBranchCode: string;
    /** 複合通帳情報-科目コード */
    public passbookSubjectCode: string;
    /** 複合通帳情報-口座番号 */
    public passbookBankAccountId: string;
    /** 複合通帳情報-口座閉鎖表示 */
    public closedStatus: string;
}

/**
 * 別冊総合口座情報
 *
 * @export
 * @class SeparateCompoundAccountInfo
 */
export class SeparateCompoundAccountInfo {
    /** 店番号 */
    public separateCompoundBranchCode: string;
    /** 科目コード */
    public separateCompoundSubjectCode: string;
    /** 口座番号 */
    public separateCompoundBankAccountId: string;
    /** 重要用紙種類コード */
    public separateCompoundPassbookTypeCode: string;
    /** 閉鎖済み表示 */
    public separateCompoundClosedStatus: string;
}

/**
 * 事故注意情報
 *
 * @export
 * @class UnacceptableInfo
 */
export class UnacceptableInfo {
    /** 通帳喪失表示 */
    public missingPassbookStatus: string;
    /** 通帳盗難表示 */
    public stolenPassbookStatus: string;
    /** 印鑑喪失表示 */
    public missingSealStatus: string;
    /** 印鑑盗難表示 */
    public stolenSealStatus: string;
    /** 印鑑レス口座表示 */
    public noSealStatus: string;
}

/**
 * 通帳預り情報
 *
 * @export
 * @class CustodyPassbookInfo
 */
export class CustodyPassbookInfo {
    /** 通帳預り表示 */
    public custodyPassbookStatus: string;
    /** 注意情報 */
    public attentionSettingInfo: AttentionSettingInfo[];
}

/**
 * 注意情報
 *
 * @export
 * @class CustodyPassbookInfo
 */
export class AttentionSettingInfo {
    /** 注意コード */
    public attentionCode: string;
    /** 注意文言 */
    public attentionMessage: string;
}

/**
 * 保有カード情報
 *
 * @export
 * @class HoldingCardInfo
 */
export class HoldingCardInfo {
    /** カード分類 */
    public cardClass: string;
    /** カード種類 */
    public cardType: string;
    /** 状態表示 */
    public status: string;
    /** カードIC表示 */
    public icCardCategory: string;
    /** 本人代理人区分 */
    public principalAgentCategory: string;
    /** 発行予約区分 */
    public reservationStatus: string;
    /** 本人・代理人名 */
    public principalAgentName: string;
    /** ローマ字氏名 */
    public romanName: string;
    /** カード再発行回次 */
    public cardTimes: string;
    /** 有効期限 */
    public expirationDate: string;
    /** 企業コード */
    public companyCode: string;
    /** 社員コード */
    public employeeCode: string;
    /** カード預り表示 */
    public custodyCardStatus: string;
    /** ETCカード保有有無 */
    public etcCardStatus: string;
    /** カード事故注意情報 */
    public unacceptableInfo: CardUnacceptableInfo;
    /** 暗証誤り上限表示 */
    public passwordErrorLimitStatus: string;
}

/**
 * カード事故注意情報
 *
 * @export
 * @class CardUnacceptableInfo
 */
export class CardUnacceptableInfo {
    /** 本人カード喪失表示 */
    public lossCardStatus: string;
    /** 本人カード盗難表示 */
    public theftCardStatus: string;
    /** 事故設定日 */
    public accidentSettingDate: string;
}

/**
 * BC情報
 *
 * @export
 * @class BcInfo
 */
export class BcInfo {
    /** BC延滞表示 */
    public delayStatus: string;
    /** キャッシング残高 */
    public cashingBalance: string;
}

/**
 * CL振替口座情報
 *
 * @export
 * @class LoanAccountInfo
 */
export class LoanAccountInfo {
    /** 店番号（CL振替口座） */
    public branchCode: string;
    /** 科目コード（CL振替口座） */
    public subjectCode: string;
    /** 口座番号（CL振替口座） */
    public bankAccountId: string;
    /** ローン残高（CL振替口座） */
    public loanBalance: string;
}

/**
 * 定期預入明細情報
 *
 * @export
 * @class DepositDetailsInfo
 */
export class DepositDetailsInfo {
    /** 預入番号 */
    public depositNo: string;
    /** 定期商品コード */
    public productCode: string;
    /** 重要用紙種類コード */
    public passbookTypeCode: string;
    /** 預入金額 */
    public depositAmount: string;
}
