import { CifInfo, DomesticAccountInfo, ForexAccountInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';

// リクエスト
/**
 * 保有通帳・カード・印鑑情報照会リクエスト
 *
 * @export
 * @class MediumInfosRequest
 */
export class MediumInfosRequest {
    /** タブレット申込管理ID */
    public tabletApplyId: number;
    /** パラメータ部 */
    public params: MediumInfosRequestParam;

    /**
     * 全店名寄せ照会APIの戻り値「顧客情報」より、リクエストを生成
     * @param {number} tabletApplyId タブレット申込管理ID
     * @param {number} receptionTenban 取次店番
     * @param {CifInfo[]} cifInfos 顧客情報リスト
     */
    constructor(tabletApplyId: number, receptionTenban: string, cifInfos: CifInfo[]) {
        this.tabletApplyId = tabletApplyId;
        this.params = {
            receptionTenban: receptionTenban,
            customerInfo: cifInfos.map((cif: CifInfo): CustomerInfo => ({
                customerId: cif.customerId,
                openingDate: cif.openingDate,
                // 口座情報として、国内口座情報（＆国内口座情報.IB契約情報）、外貨預金口座情報を設定する
                // 国内口座情報を設定
                accountInfo: cif.domesticAccountInfo.map((domesticAccountInfo: DomesticAccountInfo): AccountInfo => ({
                    branchCode: domesticAccountInfo.branchCode,
                    subjectCode: domesticAccountInfo.subjectCode,
                    bankAccountId: domesticAccountInfo.bankAccountId,
                    openingDate: domesticAccountInfo.openingDate,
                    ibContractInfo: {
                        contractCategory: domesticAccountInfo.ibContractInfo.contractCategory,
                        serviceCategory: domesticAccountInfo.ibContractInfo.serviceCategory
                    }
                })).concat(
                    // 外貨預金口座情報を設定
                    cif.forexAccountInfo.map((forexAccountInfo: ForexAccountInfo): AccountInfo => ({
                        branchCode: forexAccountInfo.branchCode,
                        subjectCode: forexAccountInfo.subjectCode,
                        bankAccountId: forexAccountInfo.bankAccountId,
                        openingDate: null,
                        ibContractInfo: null
                    }))
                )
            }))
        };
    }
}

/**
 * 保有通帳・カード・印鑑情報照会リクエスト パラメータ部
 *
 * @export
 * @class MediumInfosRequestParam
 */
export interface MediumInfosRequestParam {
    /** 取次店番 */
    receptionTenban: string;
    /** 顧客情報 */
    customerInfo: CustomerInfo[];
}

/**
 * 顧客情報
 *
 * @export
 * @class CustomerInfo
 */
export interface CustomerInfo {
    /** 顧客番号 */
    customerId: string;
    /** 顧客開設日 */
    openingDate: string;
    /** 口座情報 */
    accountInfo: AccountInfo[];
}

/**
 * 口座情報
 *
 * @export
 * @class AccountInfo
 */
export interface AccountInfo {
    /** 店番号 */
    branchCode: string;
    /** 科目コード */
    subjectCode: string;
    /** 口座番号 */
    bankAccountId: string;
    /** 口座開設日 */
    openingDate?: string;
    /** IB契約情報 */
    ibContractInfo?: IbContractInfo;
}

/**
 * IB契約情報
 *
 * @export
 * @class IbContractInfo
 */
export interface IbContractInfo {
    /** 契約区分 */
    contractCategory?: string;
    /** サービス利用区分 */
    serviceCategory?: string;
}
