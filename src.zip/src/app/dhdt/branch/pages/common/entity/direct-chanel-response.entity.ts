// レスポンス
/**
 * ダイレクトチャネル契約内容照会レスポンス
 *
 * @export
 * @class DirectChannelResponse
 */
export class DirectChannelResponse {
    /** 結果コード */
    public resultCode: string;
    /** エラー種類 */
    public errorType: string;
    /** エラー理由 */
    public errorCode: string;
    /** 契約情報 */
    public contractInfo: ContractInfo;
}

/**
 * 契約情報
 *
 * @export
 * @class ContractInfo
 */
export class ContractInfo {
    /** 代表口座情報 */
    public primaryAccountInfo: PrimaryAccountInfo;
    /** 関連口座情報 */
    public secondaryAccountInfo: SecondaryAccountInfo[];
}

/**
 * 代表口座情報
 *
 * @export
 * @class PrimaryAccountInfo
 */
export class PrimaryAccountInfo {
    /** 全店顧客番号 */
    public customerId: string;
    /** 店番号 */
    public branchCode: string;
    /** 店名 */
    public branchName: string;
    /** 科目コード */
    public subjectCode: string;
    /** 口座番号 */
    public bankAccountId: string;
}

/**
 * 関連口座情報
 *
 * @export
 * @class SecondaryAccountInfo
 */
export class SecondaryAccountInfo {
    /** 店番号 */
    public branchCode: string;
    /** 店名 */
    public branchName: string;
    /** 科目コード */
    public subjectCode: string;
    /** 口座番号 */
    public bankAccountId: string;
}
