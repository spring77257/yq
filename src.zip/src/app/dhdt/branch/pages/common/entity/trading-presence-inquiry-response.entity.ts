// レスポンス
/**
 * 取引有無照会レスポンス
 *
 * @export
 * @class TradingPresenceInquiryResponse
 */
 export class TradingPresenceInquiryResponse {
    /** 結果コード */
    public resultCode: string;
    /** エラー種類 */
    public errorType: string;
    /** エラー理由 */
    public errorCode: string;
    /** 顧客情報 */
    public customerInfo: CustomerInfo[];
}

/**
 * 顧客情報
 *
 * @export
 * @class CustomerInfo
 */
 export class CustomerInfo {
    /** 顧客番号 */
    public customerId: string;
    /** 事故・取引禁止・注意コード情報 */
    public unacceptableCodeInfo: UnacceptableCodeInfo[];
    /** 事故・取引禁止・注意コード情報（表示用） */
    public dispUnacceptableCodeInfo: string[];
}

/**
 * 事故・取引禁止・注意コード情報
 *
 * @export
 * @class UnacceptableCodeInfo
 */
 export class UnacceptableCodeInfo {
    /** 顧客単位情報 */
    public customerInfo: CustomerUnitInfo;
    /** 口座・明細単位情報 */
    public accountDetailsInfo: AccountDetailsInfo;
}

/**
 * 顧客単位情報
 *
 * @export
 * @class CustomerUnitInfo
 */
 export class CustomerUnitInfo {
    /** 顧客番号 */
    public customerInfo: string;
    /** 事故・取引禁止・注意コード */
    public unacceptableCode: string;
}

/**
 * 口座・明細単位情報
 *
 * @export
 * @class AccountDetailsInfo
 */
 export class AccountDetailsInfo {
    /** 店番号 */
    public branchCode: string;
    /** 科目コード */
    public subjectCode: string;
    /** 口座番号 */
    public bankAccountId: string;
    /** 預入番号 */
    public depositNo: string;
    /** 事故・取引禁止・注意コード */
    public unacceptableCode: string;
}
