// リクエスト
/**
 * ダイレクトチャネル契約内容照会リクエスト
 *
 * @export
 * @class DirectChannelRequest
 */
export class DirectChannelRequest {
    /** タブレット申込管理ID */
    public tabletApplyId: string;
    /** パラメータ部 */
    public params: DirectChannelRequestParam;
}

/**
 * ダイレクトチャネル契約内容照会リクエスト パラメータ部
 *
 * @export
 * @class DirectChannelRequestParam
 */
export class DirectChannelRequestParam {
    /** 取次店番 */
    public receptionTenban: string;
    /** 店番 */
    public tenban: string;
    /** 科目コード */
    public accountType: string;
    /** 口座番号 */
    public accountNo: string;

}
