import { JsonProperty } from 'adep/json';

/**
 * 顧客情報
 *
 * @export
 * @class CifInfo
 */
export class CifInfo {
    /** 個人名寄せ ID */
    public personalId: string;
    /** 全店顧客番号 */
    public customerId: string;
    /** 顧客管理店番号 */
    public customerManagementBranchCode: string;
    /** 顧客管理店名 */
    public customerManagementBranchName: string;
    /** 顧客開設日 */
    public openingDate: string;
    /** カナ氏名 */
    public kanaName: string;
    /** 漢字氏名情報 */
    public kanjiNameInfo: KanjiNameInfo;
    /** 英文氏名 */
    public englishName: string;
    /** 人格コード */
    public personalityCode: string;
    /** 性別コード */
    public genderCode: string;
    /** 生年月日 */
    public birthDate: string;
    /** 第一電話番号 */
    public phoneNo1: string;
    /** 第二電話番号 */
    public phoneNo2: string;
    /** 第三電話番号 */
    public phoneNo3: string;
    /** 代表者情報 */
    public representativeInfo: RepresentativeInfo;
    /** 国籍-本店所在国 */
    public nationality: string;
    /** 本人確認コード */
    public identificationCode: string;
    /** 住所情報 */
    public addressInfo: AddressInfo;
    /** 第二住所情報 */
    public address2Info: Address2Info;
    /** 国内口座情報 */
    public domesticAccountInfo: DomesticAccountInfo[];
    /** 外貨預金口座情報 */
    public forexAccountInfo: ForexAccountInfo[];
    /** 融資基本口座 */
    public loanAccountInfo: LoanAccountInfo[];
    /** マイナンバー登録有無 */
    public myNoEntryStatus: string;
    /** 郵便不着 */
    public nonDelivery: string;
}

/**
 * 漢字氏名情報
 *
 * @export
 * @class KanjiNameInfo
 */
export class KanjiNameInfo {
    /** 漢字氏名 */
    public kanjiName: string;
    /** 変換不可文字有無 */
    public unconvertibleCharStatus: string;

}

/**
 * 代表者情報
 *
 * @export
 * @class RepresentativeInfo
 */
export class RepresentativeInfo {
    /** 代表者名登録有無 */
    public nameEntryStatus: string;
    /** 代表者名 */
    public representativeName: string;
    /** 変換不可文字有無 */
    public unconvertibleCharStatus: string;
}

/**
 * 住所情報
 *
 * @export
 * @class AddressInfo
 */
export class AddressInfo {
    /** 郵便番号 */
    public postCode: string;
    /** 住所コード */
    public addressCode: string;
    /** 住所コード該当有無 */
    public notExistingAddressCodeStatus: string;
    /** カナ住所 */
    public kanaAddress: string;
    /** 漢字住所 */
    public kanjiAddress: string;
    /** カナ補助住所 */
    public kanaAuxiliaryAddress: string;
    /** 変換不可文字有無 */
    public unconvertibleCharStatus: string;
    /** 補助住所に変換不可文字有無 1: ある 0,null: なし */
    public isAuxiliaryAddressUnconvert: string;

}

/**
 * 第二住所情報
 *
 * @export
 * @class Address2Info
 */
export class Address2Info {
    /** 第二郵便番号 */
    public postCode2: string;
    /** 第二カナ住所 */
    public kanaAddress2: string;
    /** 第二漢字住所 */
    public kanjiAddress2: string;
    /** 変換不可文字有無 */
    public unconvertibleCharStatus: string;
}

/**
 * 国内口座情報
 *
 * @export
 * @class DomesticAccountInfo
 */
export class DomesticAccountInfo {
    /** 店番号 */
    public branchCode: string;
    /** 店名 */
    public branchName: string;
    /** 科目コード */
    public subjectCode: string;
    /** 口座番号 */
    public bankAccountId: string;
    /** 口座開設日 */
    public openingDate: string;
    /** IB契約情報 */
    public ibContractInfo: IbContractInfo;

}

/**
 * IB契約情報
 *
 * @export
 * @class IbContractInfo
 */
export class IbContractInfo {
    /** 契約区分 */
    public contractCategory: string;
    /** サービス利用区分 */
    public serviceCategory: string;
}

/**
 * 外貨預金口座情報
 *
 * @export
 * @class ForexAccountInfo
 */
export class ForexAccountInfo {
    /** 店番号 */
    public branchCode: string;
    /** 科目コード */
    public subjectCode: string;
    /** 口座番号 */
    public bankAccountId: string;
}

/**
 * 融資基本口座
 *
 * @export
 * @class LoanAccountInfo
 */
export class LoanAccountInfo {
    /** 店番号 */
    public branchCode: string;
    /** 口座番号 */
    public bankAccountId: string;

}

// レスポンス
/**
 * 全店名寄せ照会レスポンス
 *
 * @export
 * @class AllCifInfosResponse
 */
export class AllCifInfosResponse {
    /** 結果コード */
    public resultCode: string;
    /** エラー種類 */
    public errorType: string;
    /** エラー理由 */
    public errorCode: string;
    /** 顧客情報 */
    public customerInfo: CifInfo[];
}
