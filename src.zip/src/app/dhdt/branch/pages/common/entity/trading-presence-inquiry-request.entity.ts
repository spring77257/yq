// リクエスト
/**
 * 取引有無照会リクエスト
 *
 * @export
 * @class TradingPresenceInquiryRequest
 */
export interface TradingPresenceInquiryRequest {
    /** タブレット申込管理ID */
    tabletApplyId: number;
    /** パラメータ部 */
    params: TradingPresenceInquiryRequestParam;
}

/**
 * 取引有無照会リクエスト パラメータ部
 *
 * @export
 * @class TradingPresenceInquiryRequestParam
 */
export interface TradingPresenceInquiryRequestParam {
    /** 取次店番 */
    receptionTenban: string;
    /** 顧客情報 */
    customerInfo: TradingPresenceInquiryCustomerInfo[];
}

/**
 * 取引有無照会リクエスト 顧客情報
 *
 * @export
 * @class TradingPresenceInquiryRequestParam
 */
export interface TradingPresenceInquiryCustomerInfo {

    /** 顧客番号 */
    customerId: string;
    /** 国籍コード */
    nationalityCode: string;
}
