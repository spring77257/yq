import { AppProperties } from 'app.properties';

/**
 * Common Constans.
 */
export namespace Constants {
    export const BRIGHT_PARAMETER = 60;
    export const NO_WAITING_TIME = 0;
    export const NO_CARD_READER = 'NOT';

    // 研修環境判断ラーベル
    export const TRNG_ENV_LABEL = '/trng/';
    // export const TRNG_ENV_LABEL = '/dhd/';   // test

    export const ZERO = 0;

    export class PageConsts {
        public static readonly backToTopStayTime = 5000;
        public static readonly height = '88px';
        public static readonly zero = '0';
    }

    /**
     * 本人確認書類
     */
    export enum IdentityDocumentCategory {
        Address = 0,      // 現住所確認書類
        Document1 = 1,    // 本人確認書類1
        Document2 = 2,    // 本人確認書類2
        AgentAddress = 3,      // 代理人現住所確認書類
        AgentDocument1 = 4,    // 代理人確認書類1
        AgentDocument2 = 5,    // 代理人確認書類2
        EnrollmentCertificate = 6, // 在籍確認書類（勤務先）
        StudentId = 7, // 学生証
        SchoolName = 8, // 在籍確認書類(通学先)
    }

    // マイナンバーカード
    export const MyNumberCard = '08';
    export const DriveCard = '01';

    /**
     * DBに格納する指定文言
     */
    export class DBConsts {
        public static readonly imgContentType = 'image/jpeg';

        public static readonly deviceId = '111';

        public static readonly applyBusinessType = '03'; // 申込業務区分
        public static readonly insertStatus = '00'; // ステータス
        public static leaveReason = { // 普通預金離脱理由
            corporation: '001', // 法人の場合（離脱）
            against: '002', // 反社の場合（離脱）
            importantForeigner: '003', // 外国の重要な公的地位（離脱）
            notInJapan: '004', // 居住地が日本以外（離脱)
            agentNoConfirmFile: '005', // 代理人が本人確認資料未所持（離脱）
            noCohabitation: '006', // 代理人が同居の親族ではない（離脱）
            noConfirmFile: '007', // 本人が本人確認資料未所持（離脱）
            pointServiceApplied: '008',
            directBankingApplied: '009'
        };
        public static updateStatus = { // ステータス
            applyCompleted: '01', // 未印刷(申込完了)
            corporation: '90', // 法人の場合（離脱）
            against: '90', // 反社の場合（離脱）
            importantForeigner: '90', // 外国の重要な公的地位（離脱）
            notInJapan: '90', // 居住地が日本以外（離脱)
            agentNoConfirmFile: '90', // 代理人が本人確認資料未所持（離脱）
            noCohabitation: '90', // 代理人が同居の親族ではない（離脱）
            noConfirmFile: '90', // 本人が本人確認資料未所持（離脱）
            pointServiceApplied: '90',
            directBankingApplied: '90',
            exception: '99', // 異常終了
            start: '00', // 申込開始
        };

        public static PrincipalAgentCategory = {
            HOLDER: '0', // 本人
            AGENT: '1', // 代理人・家族会員1
            FAMILY2: '2' // 家族会員2
        };

        public static PrincipalapplicantCategory = {
            APPLICANT: '0', // 本人
        };

        public static IdentityApplicantDocumentCategory = {
            APPLICANT_IDENTITY_DOCUMENT: '0', // 本人確認書類
        };

        public static IdentityDocumentCategory = {
            HOLDER_IDENTITY_DOCUMENT: '0', // 本人確認書類
            HOLDER_ADDITIONAL_IDENTITY_DOCUMENT: '1', // 代理人確認書類
            AGENT_IDENTITY_DOCUMENT: '2', // 代理人確認の補完書類
            AGENT_ADDITIONAL_IDENTITY_DOCUMENT: '3' // 代理人確認の補完書類
        };

        public static IdentityDocumentType = {
            DRIVER_LISENCE: '31', // 運転免許証
            FAMILY_REGISTER_COPY: '41', // 戸籍謄本・抄本(ただし、戸籍の附票の写しが添付されているもの)
            RESIDENT_CERTIFICATE: '43', // 住民票の記載事項証明書
        };
    }

    /**
     * キャッシュカード指定文言
     */
    export class CashCard {
        public static readonly ZERO = '0';
        public static readonly ONE = '1';
        public static readonly TWO = '2';
        public static readonly THREE = '3';
        public static readonly SEVEN = '7';
        public static readonly NINE = '9';
        public static readonly ELEVEN = '11';
        public static readonly THIRTEEN = '13';
        public static readonly FOURTEEN = '14';
        public static readonly AOUNT_ONE = '1080';
        public static readonly AOUNT_TWO = '2160';
    }

    export const CASH_CARD_SWIPED = 'hasCashCardSwiped';
    export const CHECK_ACCOUNT_EXISTING = 'checkAccountExisting';
    export const CHECK_CARD_TYPE = 'checkCardType';
    export const WARNING_MODAL = 'warningModal';

    // 汎用コード定義 - 科目
    export const SUBJECT_CODE = '008';

    // 汎用コード定義 - 来店者ー被相続人との関係
    export const APPLICANT_RELATIONSHIP = '081';

    // 口座照会
    export const INHERIT_ACCOUNTS_PROPERTIES = 'INHERIT_ACCOUNTS_PROPERTIES';

    // 休眠口座照会
    export const INHERIT_INACTIVE_ACCOUNTS_PROPERTIES = 'INHERIT_INACTIVE_ACCOUNTS_PROPERTIES';

    export const ADD_INACTIVE_ACCOUNT = 'addInactiveAccount';

    // マイナンバーカード
    export const HAS_EXISTS_MOBILE_NO = '1';
    export const NO_EXISTS_MOBILE_NO = '0';
    // 携帯電話正規表現ハイフあり
    export const REGEXP_MOBILE_WITH_DASH = /^(090|080|070)-[0-9]{4}-[0-9]{4}$/;
}

// スワイプ可能カードの一覧
export namespace MediumCardTypes {
    export const swipableCard = ['03', '41', '42', '43', '51', '53', '61', '63'];
}

/**
 * 流動性預金科目コード
 * 11：当座預金（一般当座貸越含む）
 * 12：普通預金（総合口座貸越、普通預金貸越含む）
 * 13：貯蓄預金
 * 14：納税準備預金
 * 16：通知預金
 * 19：別段預金
 */
export namespace LiquidityDeposit {
    export const LD_SUBJECT_CODE = ['11', '12', '13', '14', '16', '19'];
}

/**
 * 国内預金科目コード
 * 11：当座預金（一般当座貸越含む）
 * 12：普通預金（総合口座貸越、普通預金貸越含む）
 * 13：貯蓄預金
 * 14：納税準備預金
 * 16：通知預金
 * 20：定期預金
 * 26：積立定期預金（財形預金含む）
 * 34：譲渡性預金
 * 35：債券
 * 48：貸越専用カードローン
 */
export namespace DomesticDeposit {
    export const DD_SUBJECT_CODE = ['11', '12', '13', '14', '16', '20', '26', '34', '35', '48'];
}

/**
 * 外貨預金科目コード
 * 71:外貨普通預金
 * 72:外貨通知預金
 * 73:外貨定期預金
 */
export namespace ForeignCurrencyDeposits {
    export const FCD_SUBJECT_CODE = ['71', '72', '73'];
}

/**
 * 取引振り
 * (投信（08,09）,金地金（29）,貸金庫（31）あり)
 */
export namespace SpecTransactionCode {
    export const SP_TR_CODE = ['08', '29', '31'];
}

/**
 * 印鑑レス口座表示
 */
export enum NoSealStatus {
    /** 印鑑レス口座あり */
    noseal = '1'
}

/**
 * 外国人居住コード
 */
export namespace ForeignResidenceCode {
    export const PermanentResident = '01';    // 永住者
    export const AdvancedProfession2 = '14';   // 高度専門職2号
}

/**
 * ご職業ーリストー資格外活動許可無し
 */
export namespace OutsideQualificat {
    export const OutsideQualificatWork = '0';
}

/**
 * 米国人示唆情報
 */
export namespace AmericanInformation {
    export const AmericanSuggesInfor = '1';
    export const AmericanSuggesInformation = '4';
}

/**
 * SSN所持有無
 */
export namespace IsHaveSsnWrite {
    export const IsSsnWrite = '1';
    export const IsNotSsnWrite = '2';
}

export namespace ResourcePath {
    export const PERSONAL_INFO = AppProperties.IMG_ROOT + 'doc/personal-information';
}

export class ProductType {
    // スーパー定期
    //     新型通帳　－元加式
    public static readonly SUPER_NEW_PB_COMPOUND_INTEREST = 'SUPER_NEW_PB_COMPOUND_INTEREST';
    //     新型通帳　－利払式
    public static readonly SUPER_NEW_PB_PAY_INTEREST = 'SUPER_NEW_PB_PAY_INTEREST';
    //     総合口座　－元加式
    public static readonly SUPER_UNIVERSAL_PB_COMPOUND_INTEREST = 'SUPER_UNIVERSAL_PB_COMPOUND_INTEREST';
    //     総合口座　－利払式
    public static readonly SUPER_UNIVERSAL_PB_PAY_INTEREST = 'SUPER_UNIVERSAL_PB_PAY_INTEREST';
    // 大口預金
    //     新型通帳　－元加式
    public static readonly LARGE_NEW_PB_COMPOUND_INTEREST = 'LARGE_NEW_PB_COMPOUND_INTEREST';
    //     新型通帳　－利払式
    public static readonly LARGE_NEW_PB_PAY_INTEREST = 'LARGE_NEW_PB_PAY_INTEREST';
    //     総合口座　－元加式
    public static readonly LARGE_UNIVERSAL_PB_COMPOUND_INTEREST = 'LARGE_UNIVERSAL_PB_COMPOUND_INTEREST';
    //     総合口座　－利払式
    public static readonly LARGE_UNIVERSAL_PB_PAY_INTEREST = 'LARGE_UNIVERSAL_PB_PAY_INTEREST';
    //     新型通帳　－元加式
    public static readonly CHILDREN_NEW_PB_COMPOUND_INTEREST = 'CHILDREN_NEW_PB_COMPOUND_INTEREST';
    //     新型通帳　－利払式
    public static readonly CHILDREN_NEW_PB_PAY_INTEREST = 'CHILDREN_NEW_PB_PAY_INTEREST';
    //     総合口座　－元加式
    public static readonly CHILDREN_UNIVERSAL_PB_COMPOUND_INTEREST = 'CHILDREN_UNIVERSAL_PB_COMPOUND_INTEREST';
    //     総合口座　－利払式
    public static readonly CHILDREN_UNIVERSAL_PB_PAY_INTEREST = 'CHILDREN_UNIVERSAL_PB_PAY_INTEREST';
    // 	   新型通帳　－元加式
    public static readonly MADONNA_NEW_PB_COMPOUND_INTEREST = 'MADONNA_NEW_PB_COMPOUND_INTEREST';
    //     新型通帳　－利払式
    public static readonly MADONNA_NEW_PB_PAY_INTEREST = 'MADONNA_NEW_PB_PAY_INTEREST';
    //     総合口座　－元加式
    public static readonly MADONNA_UNIVERSAL_PB_COMPOUND_INTEREST = 'MADONNA_UNIVERSAL_PB_COMPOUND_INTEREST';
    //     総合口座　－利払式
    public static readonly MADONNA_UNIVERSAL_PB_PAY_INTEREST = 'MADONNA_UNIVERSAL_PB_PAY_INTEREST';
}

export class RqnoValues {
    // スーパー定期
    //     新型通帳　－元加式
    public static readonly SUPER_NEW_PB_COMPOUND_INTEREST = '1329';
    //     新型通帳　－利払式
    public static readonly SUPER_NEW_PB_PAY_INTEREST = '1351';
    //     総合口座　－元加式
    public static readonly SUPER_UNIVERSAL_PB_COMPOUND_INTEREST = '1331';
    //     総合口座　－利払式
    public static readonly SUPER_UNIVERSAL_PB_PAY_INTEREST = '1353';
    // 大口預金
    //     新型通帳　－元加式
    public static readonly LARGE_NEW_PB_COMPOUND_INTEREST = '1326';
    //     新型通帳　－利払式
    public static readonly LARGE_NEW_PB_PAY_INTEREST = '1347';
    //     総合口座　－元加式
    public static readonly LARGE_UNIVERSAL_PB_COMPOUND_INTEREST = '1330';
    //     総合口座　－利払式
    public static readonly LARGE_UNIVERSAL_PB_PAY_INTEREST = '1352';
    //     新型通帳　－元加式
    public static readonly CHILDREN_NEW_PB_COMPOUND_INTEREST = '1337';
    //     新型通帳　－利払式
    public static readonly CHILDREN_NEW_PB_PAY_INTEREST = '1385';
    //     総合口座　－元加式
    public static readonly CHILDREN_UNIVERSAL_PB_COMPOUND_INTEREST = '1338';
    //     総合口座　－利払式
    public static readonly CHILDREN_UNIVERSAL_PB_PAY_INTEREST = '1386';
    // 	   新型通帳　－元加式
    public static readonly MADONNA_NEW_PB_COMPOUND_INTEREST = '1391';
    //     新型通帳　－利払式
    public static readonly MADONNA_NEW_PB_PAY_INTEREST = '1388';
    //     総合口座　－元加式
    public static readonly MADONNA_UNIVERSAL_PB_COMPOUND_INTEREST = '1392';
    //     総合口座　－利払式
    public static readonly MADONNA_UNIVERSAL_PB_PAY_INTEREST = '1389';

    public static readonly RQNO_HAPPINESS1_NEW_PB_COMPOUND_INTEREST = '1368';

    public static readonly RQNO_HAPPINESS2_NEW_PB_PAY_INTEREST = '1368';
    public static readonly RQNO_HAPPINESS2_UNIVERSAL_PB_PAY_INTEREST = '1369';
}
// 利息計算区分
export class InterestCalculatedTypeKeys {
    // スーパー定期
    //     新型通帳　－元加式
    public static readonly SUPER_NEW_PB_COMPOUND_INTEREST = 'SUPER_NEW_PB_COMPOUND_INTEREST';
    //     新型通帳　－利払式
    public static readonly SUPER_NEW_PB_PAY_INTEREST = 'SUPER_NEW_PB_PAY_INTEREST';
    //     総合口座　－元加式
    public static readonly SUPER_UNIVERSAL_PB_COMPOUND_INTEREST = 'SUPER_UNIVERSAL_PB_COMPOUND_INTEREST';
    //     総合口座　－利払式
    public static readonly SUPER_UNIVERSAL_PB_PAY_INTEREST = 'SUPER_UNIVERSAL_PB_PAY_INTEREST';
}
// 利息計算区分
export class InterestCalculatedTypeValues {
    // スーパー定期
    //     新型通帳　－元加式
    public static readonly SUPER_NEW_PB_COMPOUND_INTEREST = '1';
    //     新型通帳　－利払式
    public static readonly SUPER_NEW_PB_PAY_INTEREST = '1';
    //     総合口座　－元加式
    public static readonly SUPER_UNIVERSAL_PB_COMPOUND_INTEREST = '1';
    //     総合口座　－利払式
    public static readonly SUPER_UNIVERSAL_PB_PAY_INTEREST = '1';
}

// 中間利息コード
export class IntermediateInteretestCode {
    // 子定期作成
    public static readonly CREATE_SUB_SAVINGS_TIME = '1';
    // 他科目振替
    public static readonly OTHER_ACCOUNT_TRANSFER = '0';

}

// 利率コード
export class InterestRateCodeKeys {
    // スーパー定期
    //     新型通帳　－元加式
    public static readonly LARGE_NEW_PB_COMPOUND_INTEREST = 'LARGE_NEW_PB_COMPOUND_INTEREST';
    //     新型通帳　－利払式
    public static readonly LARGE_NEW_PB_PAY_INTEREST = 'LARGE_NEW_PB_PAY_INTEREST';
    //     総合口座　－元加式
    public static readonly LARGE_UNIVERSAL_PB_COMPOUND_INTEREST = 'LARGE_UNIVERSAL_PB_COMPOUND_INTEREST';
    //     総合口座　－利払式
    public static readonly LARGE_UNIVERSAL_PB_PAY_INTEREST = 'LARGE_UNIVERSAL_PB_PAY_INTEREST';
}
// 利率コード
export class InterestRateCodeValues {
    // 大口預金
    //     新型通帳　－元加式
    public static readonly LARGE_NEW_PB_COMPOUND_INTEREST = '5';
    //     新型通帳　－利払式
    public static readonly LARGE_NEW_PB_PAY_INTEREST = '5';
    //     総合口座　－元加式
    public static readonly LARGE_UNIVERSAL_PB_COMPOUND_INTEREST = '5';
    //     総合口座　－利払式
    public static readonly LARGE_UNIVERSAL_PB_PAY_INTEREST = '5';
}

// カード種類
export class CardTypes {
    // 普通預金
    public static readonly ORDINARY_DEPOSIT = '1';
    // 貯蓄預金
    public static readonly SAVINGS_DEPOSIT = '9';
}
// カード発行申込有無
export class CardPublishIsApplied {
    // 申込まない
    public static readonly CARD_PUBLISH_IS_NOT_APPLIED = '0';
    // 申込
    public static readonly CARD_PUBLISH_IS_APPLIED = '1';
}

// 共通印提出ステータス
export class CommonSealStatus {
    // 新規
    public static readonly NEW = '0';
    // 提出済み
    public static readonly CREATED = '1';
}

// 印鑑票種別
export class SealSlipType {
    // 個別
    public static readonly INDIVIDUAL = '1';
    // 共通
    public static readonly COMMON = '2';
}

// クレジットカード申込希望
export class CreditCardApplyExpectation {
    // 申込まない
    public static readonly IS_NOT_APPLIED = '0';
    // 申込
    public static readonly IS_APPLIED = '1';
}

// MultiButtonの選択の場合
export class ButtonSelect {
    // 未選択
    public static readonly BUTTON_IS_NOT_SELECT = '0';
    // 選択した
    public static readonly BUTTON_IS_SELECT = '1';
}

// 普通預金登録用RqNo
export class OrdinarySavingsRqNo {
    // 普通預金
    public static readonly ORDINARY_DEPOSIT = '1010';
    // 普通預金（総合口座通帳）
    public static readonly ORDINARY_DEPOSIT_UNIVERSAL = '1011';
    public static readonly CHILDREN_DEPOSIT = '1014';
    // 貯蓄預金
    public static readonly SAVINGS_DEPOSIT = '1025';
}

// タブレット申込管理 ステータス
export class TabletApplyStatus {
    // 申込開始
    public static readonly START = '01';
    // 未印刷
    public static readonly NOT_PRINTED = '00';
    // 印刷済
    public static readonly PRINTED = '02';
    // 途中離脱
    public static readonly QUIET_MIDWAY = '90';
    // 異常終了
    public static readonly OBNORMAL_END = '99';
}

// 申込業務区分
export class ApplyBusinessType {
    // 普通預金口座開設
    public static readonly ORDINARY_DEPOSIT = '01';
    public static readonly ORDINARY_DEPOSIT_CHILDREN = '02';
    // 普通預金口座開設（貯蓄預金）
    public static readonly ORDINARY_DEPOSIT_SAVINGS_DIPOSIT = '03';
    // 定期預金口座開設（スーパー定期）
    public static readonly REGULAR_DEPOSIT_SUPER = '04';
    public static readonly REGULAR_DEPOSIT_ORANGE = '05';
    public static readonly REGULAR_DEPOSIT_SMILE = '06';
    public static readonly REGULAR_DEPOSIT_LOVE = '07';
    public static readonly REGULAR_DEPOSIT_CHILDREN_FREE_TIME = '08';
    public static readonly REGULAR_DEPOSIT_MADONNA = '09';
    // 定期預金口座開設（大口定期）
    public static readonly REGULAR_DEPOSIT_LARGE_SAVINGS = '10';
    public static readonly REGULAR_DEPOSIT_HAPPINESS1 = '11';
    public static readonly REGULAR_DEPOSIT_HAPPINESS2 = '12';

    // 氏名・住所変更
    public static readonly CHANGE_NAME_ADDRESS = '20';

    // キャッシュカード発行（初発行）
    public static readonly CASHCARD_FIRST_PUBLISH = '30';
    // キャッシュカード発行（暗証番号忘れ）
    public static readonly CASHCARD_PASSWORD = '31';
    // キャッシュカード発行（盗難・紛失）
    public static readonly CASHCARD_LOST = '32';
    // キャッシュカード発行（破損・磁気不良）
    public static readonly CASHCARD_BROKEN = '33';

    // （既存）普通預金口座開設
    public static readonly EXISTING_ORDINARY_DEPOSIT = '61';
    // （既存）普通預金口座開設（貯蓄預金）
    public static readonly EXISTING_ORDINARY_DEPOSIT_SAVINGS_DIPOSIT = '63';
    // （既存）定期預金口座開設（スーパー定期）
    public static readonly EXISTING_REGULAR_DEPOSIT_SUPER = '64';
    public static readonly EXISTING_REGULAR_DEPOSIT_ORANGE = '65';
    public static readonly EXISTING_REGULAR_DEPOSIT_SMILE = '66';
    public static readonly EXISTING_REGULAR_DEPOSIT_LOVE = '67';
    public static readonly EXISTING_REGULAR_DEPOSIT_CHILDREN_FREE_TIME = '68';
    public static readonly EXISTING_REGULAR_DEPOSIT_MADONNA = '69';
    public static readonly EXISTING_REGULAR_DEPOSIT_LARGE_SAVINGS = '70';
    public static readonly EXISTING_REGULAR_DEPOSIT_HAPPINESS1 = '71';
    public static readonly EXISTING_REGULAR_DEPOSIT_HAPPINESS2 = '72';
    public static readonly EXISTING_REGULAR_DEPOSIT_POINT = '73';
    public static readonly STUDENT_NEW = '80';
    public static readonly STUDENT_CHANGE = '81';
    // 定期・財形預金解約
    public static readonly CANCELLATION = '91';
    // 相続
    public static readonly INHERIT = '99';
    public static readonly POINT_SERVICE = '97';
    public static readonly DIRECT_BANKING = '98';
    // 自動振込
    public static readonly AUTOMATIC_TRANSFER = '95';
    // 定期預金書替
    public static readonly TIME_DEPOSIT_REWRITING = '96';
    // 普通預金口座開設(外国人申込用)
    public static readonly ORDINARY_DEPOSIT_FOREIGN = '97';

    // 普通預金口座開設（BC複合）
    public static readonly BANKCARD_COMPOSIT = '08';
    // 普通預金口座開設（諸届複合）
    public static readonly CHANGE_COMPOSIT = '09';
    // 普通預金口座開設（BC＋諸届複合）
    public static readonly BANKCARD_CHANGE_COMPOSIT = '10';

    // 喪失届
    public static readonly LOSS = '11';
    // 喪失届＋再発行・発見
    public static readonly LOSS_REISSUE_FINDING = '12';
    // 喪失届＋再発行・発見（諸届複合）
    public static readonly LOSS_CHANGE_REISSUE_FINDING = '13';
    // 再発行・発見
    public static readonly REISSUE_FINDING = '14';
    // 再発行・発見（諸届複合）
    public static readonly CHANGE_REISSUE_FINDING = '15';

    // 解約（CC少額預金解約）
    public static readonly ACTIVE = '16';
    // 解約（CC睡眠・休眠預金解約）
    public static readonly INACTIVE = '17';
    // 口座状態照会（行員操作）
    public static readonly CLERK_ACCOUNT_STATUS_INQUIRY = '90';

    // 解約（店頭）
    public static readonly INACTIVE_COUNTER = '18';
    // 解約（店頭少額預金解約）
    public static readonly COUNTER_ACTIVE = '19';
    // 解約（店頭睡眠・休眠預金解約）
    public static readonly COUNTER_INACTIVE = '20';

    // カード差替
    public static readonly REPLACEMENT = '21';
    // カード差替（諸届複合）
    public static readonly CHANGE_REPLACEMENT = '22';
    // カード差替（暗証忘れ）
    public static readonly FORGOT_PASSWORD_REPLACEMENT = '23';
    // カード差替（暗証忘れ＋諸届複合）
    public static readonly FORGOT_PASSWORD_CHANGE_REPLACEMENT = '24';

    // マイナンバー
    public static readonly MYNUMBER = '29';
    // カード新規発行
    public static readonly NEWEST = '25';
    // カード新規発行（諸届複合）
    public static readonly CHANGE_NEWEST = '26';
}
// 商品区分
export class ApplyProductType {
    public static readonly EXISTING_REGULAR_DEPOSIT_POINT = '93';
    public static readonly EXISTING_REGULAR_DEPOSIT_HAPPINESS1 = '94';
    public static readonly EXISTING_REGULAR_DEPOSIT_HAPPINESS2 = '95';
}

// 自動継続方法
export class AutomicRenewal {
    // 元加式
    public static readonly COMPOUND_INTEREST = '0';
    // 利払式
    public static readonly PAY_INTEREST = '1';
}

// 定期口座タイプ
export class TimeSavingsAccountType {
    // 新型通帳
    public static readonly NEW = '0';
    // 総合口座
    public static readonly UNIVERSAL = '1';
}

export class CancelIdentificationDocument {
    public static readonly ADD_IDENTITY_DOCUMENT_IMG = 'addIdentificationDocImg';
}

// 預入期間
export class SavingsTime {
    // 預入期間が3年以上
    public static readonly MORE_THREE_YEAR = '3';
    // 預入期間が2年
    public static readonly TWO_YEAR = '2';
    // 預入期間が2年以上
    public static readonly MORE_TWO_YEAR = '1';
}

export class CardDesign {
    public static readonly GREEN = '11';
    public static readonly WINE = '12';
    public static readonly BLUE = '13';
}

export class AccountOpenPurpose {
    public static readonly NO_SELECTED = '0';
}

export class AccountType {
    // 普通預金口座開設
    public static readonly ORDINARY_DEPOSIT = '1';
    public static readonly ORDINARY_DEPOSIT_CHILDREN = '2';
    // 普通預金口座開設（貯蓄預金）
    public static readonly ORDINARY_DEPOSIT_SAVINGS_DIPOSIT = '3';
    // 定期預金口座開設
    public static readonly TIME_SAVING = '4';
    // キャッシュカードの発行・再発行
    public static readonly CASH_CARD = '5';
    public static readonly CREDIT_CARD = '6';
    // 定期預金払い戻し
    public static readonly CANCEL = '7';
    // 届出内容の変更
    public static readonly CHANGE = '8';
    // 既存・普通預金口座開設
    public static readonly EXISTING_SAVINGS = '9';
    public static readonly STUDENT_NEW = '10';
    // 既存・積立定期預金
    public static EXISTING_RESERVE = '11';
    public static readonly STUDENT_CHANGE = '12';
    // 相続
    public static readonly INHERIT = '99';
    // 既存・普通預金口座開設（貯蓄預金）
    public static readonly EXISTING_STORAGE = '13';
    public static readonly POINT_DIRECT = '97';
    // 定期預金書替
    public static readonly TIME_DEPOSIT_REWRITING = '96';
    // 自動振込
    public static readonly AUTOMATIC_TRANSFER = '95';
    // 普通口座開設(外国人申込用)
    public static readonly FOREIGN_SAVINGS = '14';
    // 喪失・再発行・発見
    public static readonly LOSS_REISSUE_FINDING = '15';
    // 解約
    public static readonly TERMINATE = '16';
    // 口座状態照会
    public static readonly CLERK_ACCOUNT_STATUS_INQUIRY = '90';
    // カード差替
    public static readonly REPLACEMENT = '18';
    // マイナンバー
    public static readonly MYNUMBER = '29';
    // カード新規発行
    public static readonly NEWEST = '19';
}

// 定期預金の開設目的
export class RegularOpenPur {
    // 定期預金
    public static readonly TIMG_SAVING = '1';
    // 積立定期
    public static readonly INSTALLMENT = '0';
}

// 定期預金の預入期間
export class AdvancePeroid {
    // １年
    public static readonly ONE_YEAR = '1年';
    // ２年
    public static readonly TWO_YEAR = '2年';
}

export class SavingAccountType {
    // 普通預金
    public static readonly ORDINARY = '0';
    // 貯蓄預金
    public static readonly SAVINGS = '1';
}

export class PrincipalAgentCategory {
    // 本人
    public static readonly HOLDER = '0';
    // 代理人
    public static readonly AGENT = '1';
    // 外国人
    public static readonly FOREIGNER = '2';
}

/**
 * 共通用定数
 */
export namespace COMMON_CONSTANTS {
    export const LABLE_REPLACE_KEY = '{$}';
    /** 全角スペース */
    export const FULL_SPACE = '　';
    /** 全角読点 */
    export const FULL_PAUSE = '、';
    /** 全角： */
    export const FULL_COLON = '：';
    /** 半角hyphen */
    export const HALF_HYPHEN = '-';
    /** 全角hyphen */
    export const FULL_HYPHEN = '－';
    /** 全角読点 */
    export const HALF_PAUSE = '、';
    /** 半角ドット */
    export const HALF_POINT = '. ';
    /** 半角ドット(スペース無し) */
    export const HALF_POINT_NO_SPACE = '.';
    /** 全角ドット */
    export const FULL_POINT = '．';
    /** 全角カンマ */
    export const HALF_COMMA = ',';
    /** 漢字　年 */
    export const KANJI_YEAR = '年';
    /** 漢字　月 */
    export const KANJI_MONTH = '月';
    /** 漢字　日 */
    export const KANJI_DAY = '日';
    /** Skip */
    export const SIGN_SKIP = 'skip';
    /** Skip Text */
    export const SKIP_TEXT = 'スキップ';
    /** Send Text */
    export const SEND_TEXT = '送信';
    /** url */
    export const TYPE_URL = 'url';
    /** uppercase */
    export const UPPERCASE_OK = 'OK';
    /** lowercase */
    export const LOWERCASE_OK = 'ok';
    /** text */
    export const TEXT = 'Text';
    /** close */
    export const CLOSE = 'close';
    /** clear */
    export const CLEAR = 'clear';
    /** uppercase JPY */
    export const UPPERCASE_JPY = 'JPY';
    /** 半角スペース */
    export const SPACE = ' ';
    /** スラッシュ */
    export const SLASH = '/';
    /** <br/> */
    export const NEW_LINE = '<br/>';
    /** @ */
    export const HALF_AT = '@';
    /** px */
    export const UNIT_PX = 'px';
    /** 固定文言：さまのお子さま */
    export const CHILD_SUFFIX = 'さまのお子さま';
    /** standard time zone */
    export const STANDARD_TIME_ZONE = '+0000';
    /** 口座科目(普通) */
    export const ACCOUNT_TYPE_NORMAL = '1';
    /** 完了コード(CODE) OK */
    export const PROCESS_CODE_OK = 'OK';
    /** 完了コード(CODE) NG */
    export const PROCESS_CODE_NG = 'NG';
    /** 全角括弧 */
    export const FULL_PARENTHESES_LEFT = '（';
    export const FULL_PARENTHESES_RIGHT = '）';
    /** パーセント */
    export const PERCENT = '%';
    /** 半角括弧 */
    export const PARENTHESES_LEFT = '(';
    export const PARENTHESES_RIGHT = ')';
    /** YML type: general：はい・いいえ */
    export const YML_GENERAL_YES = '0';
    export const YML_GENERAL_NO = '1';

    export const POINT = '・';

    export const PASSWORD_MODAL_UNITS = 4;

    /** 愛媛県 */
    export const PREFECTURE_EHIME = '愛媛県';
    /** 松山市 */
    export const CITY_MATSUYAMA = '松山市';

    export const PICKER_TITLE_HEIGHT = 64;

    export const DEFAULT_EXPIRY_DATE = '20871111';

    /** YML */
    export const YML_CHAT_FLOW_STUDENT_NEW_SELF_APPLY = 'chat-flow-def-student-new-self-apply.yml';
    export const YML_CHAT_FLOW_STUDENT_NEW_INIT = 'chat-flow-def-student-new-init.yml';
    export const YML_CHAT_FLOW_STUDENT_NEW_INIT_CONFIRM = 'chat-flow-def-student-new-init-confirm.yml';
    export const YML_CHAT_FLOW_STUDENT_NEW_PRINCIPAL_AGENT = 'chat-flow-def-student-new-principal-agent.yml';
    export const YML_CHAT_FLOW_STUDENT_NEW_AGENT_APPLY = 'chat-flow-def-student-new-agent-apply.yml';
    export const YML_CHAT_FLOW_EXISTING_SAVINGS_VARIFICATION = 'chat-flow-def-existing-savings-varification.yml';
    export const YML_CHAT_FLOW_EXISTING_SAVINGS_PURPOSE = 'chat-flow-def-existing-savings-purpose.yml';
    export const YML_CHAT_FLOW_EXISTING_SAVINGS_CHANGE_DIFFERENCIAL_CONFIRMATION =
        'chat-flow-def-existing-savings-change-differencial-confirmation.yml';
    export const YML_CHAT_FLOW_EXISTING_SAVINGS_CHANGE_NAME = 'chat-flow-def-existing-savings-change-name.yml';
    export const YML_CHAT_FLOW_EXISTING_SAVINGS_CHANGE_ADDRESS = 'chat-flow-def-existing-savings-change-address.yml';
    export const YML_CHAT_FLOW_EXISTING_SAVINGS_CHANGE_TEL = 'chat-flow-def-existing-savings-change-tel.yml';
    export const YML_CHAT_FLOW_EXISTING_RESERVE_VARIFICATION = 'chat-flow-def-existing-reserve-varification.yml';
    export const YML_CHAT_FLOW_EXISTING_RESERVE_SELECT_PRODUCT = 'chat-flow-def-existing-regular-select-product.yml';
    export const YML_CHAT_FLOW_EXISTING_SAVINGS_CHANGE_DOCUMENT_CONFIRM = 'chat-flow-def-existing-savings-change-document-confirm.yml';
    export const YML_CHAT_FLOW_EXISTING_SAVINGS_CREDIT_DOCUMENT_CONFIRM = 'chat-flow-def-existing-savings-creditcard-document-confirm.yml';
    export const YML_CHAT_FLOW_EXISTING_SAVINGS_CREDIT_STUFF_CONFIRM = 'chat-flow-def-existing-savings-creditcard-stuff-confirm.yml';

    /** relationship css */
    export const BOTTOM_LINE_IS = 'bottom-line';
    export const BOTTOM_LINE_NONE = 'none-bottom-line';
    export const ANIMATION_NOMAL = '.nomal';
    export const ANIMATION_POINT = '.point';
    export const SETTINGS_MODAL = 'settings-modal';

    /** picker type */
    export const PICKER_TYPE_PICKER = 'picker';
    export const PICKER_TYPE_YEARMONTH = 'yearMonth';
    export const PICKER_TYPE_DAY = 'day';
    export const PICKER_TYPE_DATE = 'date';
    export const PICKER_TYPE_TODAY = 'today';
    export const PICKER_TYPE_YESTERDAY = 'yesterday';
    export const PICKER_TYPE_RESIDENCE = 'residence';

    /** Back Button Type */
    export const BACK_TYPE_TOP = 'backTop';
    export const BACK_TYPE_REAPPLY_MENU = 'backReapplyMenu';
    export const BACK_TYPE_PREV = 'back';

    /** loginfo */
    export const TYPE_LOGINFO = 'logInfo';
    export const TYPE_AGENT = '(代理人)';
    /** mobile type */
    export const HOLDER_MOBILE_NO = 'holderMobileNo';
    export const HOLDER_TEL_NO = 'holderTelephoneNo';
    /** existing mobile type */
    export const EXISTING_HOLDER_MOBILE_NO = 'existingChangeHolderMobileNo';
    export const EXISTING_HOLDER_TEL_NO = 'existingChangeHolderTelephoneNo';
    /** career */
    export const HOLDER_CAREER = 'holderCareer';

    /** 相続人代表ある・ない */
    export const REPRESENTATIVE_FALSE = '0';
    export const REPRESENTATIVE_TRUE = '1';

    export const RELATIONSHIP_OTHER = '07';

    /******************************************************
     * Date Format
     ******************************************************/
    export const DATE_FORMAT_YYYYMMDD = 'YYYYMMDD';
    export const DATE_FORMAT_YYYYMMDD_PIPE = 'yyyyMMdd';
    export const DATE_FORMAT_YYYYMMDDHHMMSS_PIPE = 'yyyyMMddHHmmss';
    export const DATE_FORMAT_YYYYMMDDHHMMSS = 'YYYYMMDDHHmmss';
    export const DATE_FORMAT_YYYY = 'YYYY';
    export const DATE_FORMAT_YYYYMM = 'YYYYMM';
    export const DATE_FORMAT_YYYY_MM = 'YYYY-MM';
    export const DATE_FORMAT_YMD_HMS = 'YYYY-MM-DDTHH:mm:ss';
    export const DATE_FORMAT_YYYY_MM_DD = 'YYYY-MM-DD';
    export const DATE_FORMAT_YYYY_MM_DD_SPRIT = 'YYYY/MM/DD';
    export const DATE_FORMAT_YYYY_MM_SPRIT = 'YYYY/MM';
    export const DATE_FORMAT_YYYY_MM_JP = 'YYYY年MM月';
    export const DATE_YEARS = 'years';
    export const DATE_YEAR = 'year';
    export const DATE_DAY = 'day';
    export const DATE_MONTH = 'month';

    export const CHILDERN_BIRTHDATE = 'childrenBirthdate';
    export const HOLDER_BIRTHDATE = 'holderBirthdate';
    export const PENSION_YEAR_MONTH = 'pensionYearMonth';

    /******************************************************
     * Japan Eras Name
     ******************************************************/
    export const JPN_ERAS_TAISHO_15 = '（大正15）年';
    export const JPN_ERAS_SHOWA_ZERO = '（昭和元）年';
    export const JPN_ERAS_SHOWA_64 = '（昭和64）年';
    export const JPN_ERAS_SHOWA = '昭和';
    export const JPN_ERAS_HEISEI_ZERO = '（平成元）年';
    export const JPN_ERAS_HEISEI = '平成';
    export const JPN_ERAS_MAN = '満';
    export const JPN_ERAS_AGE = '歳';
    export const JPN_ERAS_UNDER_18_AGE = '（18歳未満）';

    /******************************************************
     * Flow Type
     ******************************************************/
    /** action type */
    export const ACTION_TYPE_MODAL = 'modal';
    export const ACTION_TYPE_ROUTE = 'route';
    export const ACTION_TYPE_ADMIN = 'admin';
    export const ACTION_TYPE_RETURN_TO_CHAT = 'returnToChat';
    export const ACTION_TYPE_EDIT = 'edit';

    /** action value */
    export const ACTION_TYPE_AUTHENTICATION = 'authentication';

    /** flow type */
    export const FLOW_TYPE_INIT_CONFIRM = 'init-confirm';
    export const FLOW_TYPE_CREDIT_CARD = 'credit-card';
    export const FLOW_TYPE_CHANGE_NORMAL = 'change-normal';
    export const FLOW_TYPE_CHANGE_NAME = 'change-name';
    export const FLOW_TYPE_WITHOUT_AUTHENTICATION = 'without-authentication';

    /** flow next */
    export const FLOW_TYPE_NUMBER_NEXT = '-1';

    /** button type */
    export const BUTTON_TYPE_GENERAL = 'general';
    export const BUTTON_TYPE_NARROW = 'narrow';
    export const BUTTON_TYPE_CONTINUE = 'continue';

    /******************************************************
     * Element Type
     ******************************************************/
    /** picker */
    export const ELEMENT_TYPE_PICKER = 'picker';
    export const ELEMENT_TYPE_DATE_PICKER = 'datepicker';
    export const ELEMENT_TYPE_YEAR_PICKER = 'yearPicker';
    export const ELEMENT_TYPE_YEAR_PICKER_IYOCA = 'yearPickerIyoca';
    export const ELEMENT_TYPE_YEARMONTH_PICKER = 'yearMonthPicker';
    export const ELEMENT_TYPE_MONTH_PICKER = 'monthpicker';
    export const ELEMENT_TYPE_DAY_PICKER = 'daypicker';
    export const ELEMENT_TYPE_SELECTADDRESS = 'selectAddress';
    export const ELEMENT_TYPE_SELECTSTREET = 'selectStreet';
    export const ELEMENT_TYPE_PREFECTURE_PICKER = 'prefecturePicker';
    export const ELEMENT_TYPE_COUNTYURBANVILLAGE_PICKER = 'countyUrbanVillagePicker';
    export const ELEMENT_TYPE_RESIDENCE_YEAR_PICKER = 'residenceYearPicker';
    export const ELEMENT_TYPE_CURRENCY_PICKER = 'currencyCodePicker';
    export const ELEMENT_TYPE_CATEGORY_NAME_LOGIC_PICKER = 'categoryNameLogicPicker';

    /** button */
    export const ELEMENT_TYPE_BUTTON = 'button';
    export const ELEMENT_TYPE_TITLE_BUTTON = 'titleButton';
    export const ELEMENT_TYPE_THREECOLS_BUTTON = 'buttonThreeCols';
    export const ELEMENT_TYPE_TWOCOLS_BUTTON = 'buttonTwoCols';
    export const ELEMENT_TYPE_CARD_BUTTON = 'cardbutton';
    export const ELEMENT_TYPE_CAMERA_BUTTON = 'cameraButton'; // カメラの起動ボタン
    export const ELEMENT_TYPE_RADIO_BUTTON = 'radioButton';
    export const ELEMENT_TYPE_MULTI_BUTTON = 'multiButton';

    /** keyboard */
    export const ELEMENT_TYPE_KEYBORD = 'keybord';
    export const ELEMENT_TYPE_PRINTNAME = 'printName';
    export const ELEMENT_TYPE_TEXT = 'text';
    export const ELEMENT_TYPE_NUMBER = 'numberKeybord';
    export const ELEMENT_TYPE_DEPOSIT_TENTHOUSAND = 'tenThousandDepositInput';
    export const ELEMENT_TYPE_NUMBER_THOUSAND = 'numberThousand';
    export const ELEMENT_TYPE_NUMBER_PEOPLE = 'peopleCountInput';

    /** password */
    export const ELEMENT_TYPE_PASSWORD = 'needpassword';
    export const ELEMENT_TYPE_PASSWORD_BITS4 = 'password4bits';
    export const ELEMENT_TYPE_PASSWORD_BITS6 = 'password6bits';
    export const ELEMENT_TYPE_PASSWORD_VERIFICATION = 'passwordVerification';
    export const ELEMENT_TYPE_PASSWORD_CREDIT_FAMILY = 'creditCardFamilyPwd';

    /** card */
    export const ELEMENT_TYPE_CARD = 'card';

    /** image */
    export const ELEMENT_TYPE_IMAGE = 'image';
    export const ELEMENT_TYPE_IMAGE_SRC = 'ImageSrc';

    /** judge */
    export const ELEMENT_TYPE_JUDGE = 'judge';
    export const ELEMENT_TYPE_JUDGE_URL = 'url';
    export const ELEMENT_TYPE_JUDGE_UNDEFINE = 'undefine';
    export const ELEMENT_TYPE_JUDGE_OTHER = 'other';
    export const ELEMENT_TYPE_JUDGE_DOUBLE = 'judgeDouble';

    /** modal */
    export const ELEMENT_TYPE_MODAL_AGREED = 'agreedModal';
    export const ELEMENT_TYPE_MODAL_CONFIRM = 'confirmModal';
    export const ELEMENT_TYPE_MODAL_NOTICE = 'noticeModal';
    export const ELEMENT_TYPE_MODAL_PASSWORD = 'passwordVerification';

    /** payout account */
    export const ELEMENT_TYPE_SELECT_PAYOUT_ACCOUNT = 'selectPayoutAccount';
    export const ELEMENT_TYPE_SELECT_PAYOUT_ACCOUNT_OTHER = 'selectPayoutAccountOther';
    export const ELEMENT_TYPE_ACCOUNT_INFO = 'accountInfo';

    /** route */
    export const ELEMENT_TYPE_ROUTE = 'route';
    export const ELEMENT_TYPE_ROUTE_DISMISS_SELF = 'DismissSelf';
    export const ELEMENT_TYPE_BASICINFO = 'basicinfo';
    export const ELEMENT_TYPE_ACCOUNTSHOP = 'accountshop';
    export const ELEMENT_TYPE_COMPLETE = 'complete';
    export const ELEMENT_TYPE_BUTTON_TWO_COLS = 'buttonTwoCols';
    export const ELEMENT_TYPE_BUTTON_THREE_COLS = 'buttonThreeCols';
    export const ELEMENT_TYPE_CONFIRMATION = 'confirmation';

    /** saveSubmit */
    export const ELEMENT_TYPE_SAVE_SUBMIT = 'saveSubmit';

    /** question type */
    export const ELEMENT_TYPE_SELECT_PRODUCT = 'selectProduct';
    export const ELEMENT_TYPE_JUDGE_MODAL = 'judgeModal';
    export const ELEMENT_TYPE_SELECT_COURSE = 'selectCourse';
    export const ELEMENT_TYPE_NORMAL_DEPOSIT_INPUT = 'normalDepositInput';
    export const ELEMENT_TYPE_THOUSAND_DEPOSIT_INPUT = 'thousandDepositInput';
    export const ELEMENT_TYPE_SELECT_MONTH = 'selectMonth';

    /** key value */
    export const ELEMENT_TYPE_SELECT_PRODUCT_NAME = 'selectProductName';
    export const ELEMENT_TYPE_SELECT_COURSE_NAME = 'selectCourseName';
    export const ELEMENT_TYPE_SELECT_BRANCH = 'selectbranch';
    export const ELEMENT_TYPE_HOLDER_BIRTHDATE = 'holderBirthdate';
    export const ELEMENT_TYPE_DEATH_DAY = 'deathDay';
    export const ELEMENT_TYPE_TIME_SAVING_ACCOUNT_TYPE = 'timeSavingsAccountType';
    export const ELEMENT_TYPE_REQUEST = 'request';
    export const ELEMENT_TYPE_TEMP = 'temp';
    export const ELEMENT_TYPE_MULIT_BUTTON = 'mulitButton';
    export const ELEMENT_TYPE_ACCOUNT_OPENING_DEPOSIT_AMOUNT = 'accountOpeningDepositAmount';
    export const ELEMENT_TYPE_NAME_AGGREGATION = 'nameAggregation';
    export const ELEMENT_TYPE_CIF_INFOS_INQUIRY = 'cifInfosInquiry';

    /******************************************************
     * Regular expression
     ******************************************************/
    /** 全角・半角 */
    export const REGEX_FULL_HALF_WIDTH = '^[^｡-ﾟ\t]+$';

    /** key */
    export const KEY_HOLDER_ADDRESS_STREET = 'holderAddressStreetNameSelect';
    export const KEY_HOLDER_ADDRESS_STREET_FURIKANA = 'holderAddressStreetNameFuriKanaSelect';
    export const KEY_STREET_WORK = 'streetWork';
    export const KEY_SHOW_STREET = 'showStreet';
    export const KEY_HOLDER_CARD_IMAGE_FRONT = 'holderCardImageFront';
    export const KEY_HOLDER_CARD_IMAGE_BACK = 'holderCardImageBack';
    export const KEY_AGENT_CARD_IMAGE_FRONT = 'agentCardImageFront';
    export const KEY_AGENT_CARD_IMAGE_BACK = 'agentCardImageBack';
    export const KEY_IS_AGENT = 'isAgent';
    export const KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW = 'holderAddressHouseNumberForShow';
    export const KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FURIKANA_FOR_SHOW = 'holderAddressHouseNumberFuriKanaForShow';
    export const KEY_PARENTAL_ADDRESS_HOUSE_NUMBER_FOR_SHOW = 'parentalAddressHouseNumberForShow';
    export const KEY_PARENTAL_ADDRESS_HOUSE_NUMBER_FURIKANA_FOR_SHOW = 'parentalAddressHouseNumberFuriKanaForShow';
    export const KEY_CHILDREN_NUMBERS = 'childrenNumbers';
    export const KEY_CHILDREN_RELATIONSHIP = 'childrenRelationship';
    export const KEY_HOLDER_ADDRESS_STREET_NAME_INPUT = 'holderAddressStreetNameInput';
    export const KEY_HOLDER_ADDRESS_HOUSE_NUMBER = 'holderAddressHouseNumber';

    /** name */
    export const NAME_ACCOUNT_TYPE = 'accountType';
    export const NAME_ACCOUNT_TYPE_TEXT = 'accountTypeText';
    export const NAME_APPLY_BIZ_CATEGORY = 'applyBizCategory';
    export const NAME_BUSINESS_CODE = 'businessCode';
    export const NAME_CHAT_FLOW_NAME = 'chatFlowName';
    export const NAME_TABLET_APPLY_ID = 'tabletApplyId';
    export const NAME_INPUT_ACCOUNT_TYPE = 'inputAccountType';

    /** 本人の電話 */
    export const HOLDER_MPBILE_NO = 'holderMobileNo';
    export const HOLDER_TELEPHONE_NO = 'holderTelephoneNo';

    /** camera */
    export const CAMERA_PICTURE = 'picture';

    /** simpleness-operators-component */
    export const SIMPLENESS_COMPONENT = 'overPage';

    /** data:image */
    export const DATA_IMAGE_JPEG = 'data:image/jpeg;base64,';

    /** data:png */
    export const DATA_IMAGE_PNG = '.png';

    /** data:cardImage */
    export const DATA_IMAGE_CARD_IMAGE = 'CardImage';

    /** changeChatFlowFlg */
    export const CHANGE_CHAT_FLOW_FLG = 'changeChatFlowFlg';

    /** close chatflow */
    export const DIMISS_CLOSE_VALUE = 'close';
    /** confirm page */
    export const CONFIRM_PRINT_MESSAGE = 'passbookPrintMessage';
    export const CONFIRM_PASSBOOK_TYPE = 'passbookType';
    export const CONFIRM_DEPOSIT_PERIOD_YEAR_MONTH = 'depositPeriodYearMonth';
    export const CONFIRM_RESERVED_FUND_RECEIPT_TYPE = 'reservedFundReceiptType';

    export const ZIP_CODE = 'getAddressFromZipcode';
    export const STREET = 'getStreetInitialsKana';
    export const STREET_PARENTAL = 'getStreetInitialsKanaParental';

    /** config url */
    export const CONFIG_URL = 'configUrl';

    /** 相続png */
    export const INHERIT_INHERITANCE_PROCEDURES = AppProperties.IMG_ROOT + 'modal/img_inherit_inheritance_procedures.png';

    /** ライン公式アカウントpng */
    export const LINE_OFFICIAL_ACCOUNT = AppProperties.IMG_ROOT + 'modal/img_line_account.png';
    export const LINE_OFFICIAL_ACCOUNT_CHANGE = AppProperties.IMG_ROOT + 'modal/img_line_account_change.png';

    /** BankCardの紹介画像 */
    export const BC_INTRODUCE = AppProperties.IMG_ROOT + 'modal/img_bc_introduce.png';

    /** pdf */
    /** 01 普通預金口座開設（新規） */
    export const REGULATIONS_SHINKI_FUTSUU = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_futsuu';
    export const REGULATIONS_SHINKI_KODOMO = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_kodomo';
    export const REGULATIONS_SHINKI_CHOCHIKU = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_chochiku';
    export const REGULATIONS_SHINKI_GAKUSEI = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_gakusei';
    export const REGULATIONS_KOUZA_TOKUCHOU = AppProperties.IMG_ROOT + 'modal/img_regulations_kouza_tokuchou.png';

    /** 02 定期預金口座開設（新規） */
    export const REGULATIONS_SHINKI_SUPER = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_super';
    export const REGULATIONS_SHINKI_OOGUCHI = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_ooguchi';
    export const REGULATIONS_SHINKI_BOCHAN = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_bochan';
    export const REGULATIONS_SHINKI_MADONNA = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_madonna';
    export const REGULATIONS_SHINKI_SHIAWASE_01 = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_shiawase_01';
    export const REGULATIONS_SHINKI_SHIAWASE_02 = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_shiawase_02';
    export const REGULATIONS_SHINKI_ORANGE = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_orange';
    export const REGULATIONS_SHINKI_HOHOEMI = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_hohoemi';
    export const REGULATIONS_SHINKI_AIJO = AppProperties.IMG_ROOT + 'doc/img_regulations_shinki_aijo';

    /** 03 普通預金口座開設（既存） */
    export const REGULATIONS_KIZON_FUTSUU = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_futsuu';
    export const REGULATIONS_KIZON_CHOCHIKU = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_chochiku';
    export const REGULATIONS_KIZON_GAKUSEI = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_gakusei';

    /** 04 定期預金口座開設（既存） */
    export const REGULATIONS_KIZON_SUPER = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_super';
    export const REGULATIONS_KIZON_OOGUCHI = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_ooguchi';
    export const REGULATIONS_KIZON_BOCHAN = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_bochan';
    export const REGULATIONS_KIZON_MADONNA = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_madonna';
    export const REGULATIONS_KIZON_SHIAWASE_01 = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_shiawase_01';
    export const REGULATIONS_KIZON_SHIAWASE_02 = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_shiawase_02';
    export const REGULATIONS_KIZON_POINT = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_point_service_teiki';
    export const REGULATIONS_KIZON_ORANGE = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_orange';
    export const REGULATIONS_KIZON_HOHOEMI = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_hohoemi';
    export const REGULATIONS_KIZON_AIJO = AppProperties.IMG_ROOT + 'doc/img_regulations_kizon_aijo';

    export const IYOCA_DC_PDF_FILE = AppProperties.IMG_ROOT + 'doc/img_regulations_iyoca_dc';
    export const IYOCA_JCB_PDF_FILE = AppProperties.IMG_ROOT + 'doc/img_regulations_iyoca_jcb';

    /** 自動振込 */
    export const AUTOMATIC_TRANSFER_PDF_FILE = AppProperties.IMG_ROOT + 'doc/img_regulations_automatic_transfer';
    export const AUTOMATIC_TRANSFER_IYO_STUDENT = '1';
    export const AUTOMATIC_TRANSFER_CONTENT_DEFAULT_OTHER = 'ｿｳｷﾝ'; // 振込資金の内容（その他）のデフォルト値
    export const AUTOMATIC_TRANSFER_DEFAULT_END_DATE = '999912';

    export const REGULATIONS_POINT_SERVICE = AppProperties.IMG_ROOT + 'doc/img_regulations_point_service';
    export const REGULATIONS_DIRECT_BANKING = AppProperties.IMG_ROOT + 'doc/img_regulations_direct_banking';

    /** 積立定期口座解約のフラグ */
    export const PAYMENT_EQUAL_LEDGER_FLAG = '1'; // 元帳残高と概算支払金額相同時

    /** その他国名定数 */
    export const OTHER_COUNTRY_NAME = '2';

    /** 属性不一致 */
    export const ATTRIBUTE_MISMATCH = '1';
    /** イメージタイプ */
    export enum imageType {
        typeA = 'A',
        typeB = 'B',
        typeC = 'C',
        typeD = 'D',
        typeE = 'E',
        typeF = 'F',
        typeG = 'G',
        typeCommon = '-'
    }
    /**
     * 画像・テキスト登録
     */
    export enum inheritType {
        typeApi = '1',
        typeSkip = '2',
        typeInput = '3'
    }
    /**
     * 普通預金 既存_普通預金口座開設
     */
    export enum ExistingSavings {
        // order定数
        CareerNextOrder = '11'
    }

    /**
     * Business Flow Type
     */
    export enum BusinessFlowType {
        CashCard = '5',
        CreditCard = '6',
        Change = '8',
        Cancel = '7',
        ExistingSavings = '9',
        Student = '10',
        ExistingReserve = '11',
        Inherit = '12',
        ExistingStorage = '13',
        PointService = '14',
        DirectBanking = '15',
        AutomaticTransfer = '16',
        TimeDepositRewriting = '17'
    }

    /**
     *   相続方法
     */
    export enum inheritanceMethodType {
        TYPE_01 = '01',
        TYPE_02 = '02',
        TYPE_03 = '03',
        TYPE_04 = '04',
        TYPE_05 = '05',
        TYPE_06 = '06',
        TYPE_07 = '07',
        TYPE_08 = '08',
        TYPE_09 = '09',
        TYPE_10 = '10'
    }

    export enum Gender {
        Male = '1',
        Female = '2',
        Other = '0'
    }

    /**
     * 口座開設目的
     */
    export enum AccountPurpose {
        Select = '1',
        NoSelect = '0'
    }

    /**
     * Process Type
     */
    export enum ProcessType {
        /** 確認事項 */
        Assumption = 0,
        /** 必要情報入力 */
        RequiredInput = 1,
        /** 申込内容確認 */
        ApplyInfoConfirm = 2,
        /** 行員確認 */
        BankClerkConfirm = 3,
        /** 完了 */
        ApplyCompletion = 4,
    }

    export const INHERIT_CHAT_COMPONENT = 'InheritChatComponent';
    /**
     * EQPurpose Type
     */
    export enum EQPurposeType {
        /** 新規-普通預金 */
        OrdinaryDeposit = '11100',
        ChildrenDeposit = '11200',
        StudentDeposit = '11300',
        /** 新規-貯蓄預金 */
        StorageDeposit = '11400',
        /** 新規-定期性預金(ご新規・お預入れ) */
        TimeDepositNew = '11500',
        /** 新規-定期性預金（ご継続） */
        TimeDepositContinue = '11600',
        /** 各種お手続き(変更・自動振り込み等)-住所変更 */
        ChangeAddress = '12100',
        /** 各種お手続き(変更・自動振り込み等)-氏名変更 */
        ChangeName = '12200',
        /** キャッシュカード-初発行 */
        CashCardFirstPublish = '13100',
        /** キャッシュカード-暗証忘れ */
        CashCardPassword = '13200',
        /** キャッシュカード-破損・磁気不良 */
        CashCardBroken = '13300',
        /** キャッシュカード-紛失・盗難 */
        CashCardLost = '31000',
        /** クレジットカード-発行 */
        CreditCardFistPublish = '14100',
        /** クレジットカード-再発行 */
        CreditCardRePublish = '14200',
        /** クレジットカード-その他 */
        CreditCardOther = '14300',
        /** ご解約-ご解約(普通預金) */
        CancellationNormal = '15100',
        /** ご解約-ご解約(定期性預金等) */
        CancellationReserve = '15200',
        /** ご解約-その他 */
        CancellationOther = '15300',
        /** マイナンバー */
        MyNumber = '15400',
        /** 相続 */
        Inherit = '16200',
        PointDirect = '12500',
        /** 自動振込 */
        AutomaticTransfer = '12400',
        /** 口座状態照会（行員操作） */
        ClerkAccountStatusInquiry = '99999'
    }

    export enum InheritProcessType {
        /** 必要情報入力 */
        RequiredInput = 0,
        /** 入力内容確認 */
        ApplyInfoConfirm = 1,
        /** 行員確認・簡素化判定 */
        BankClerkConfirm = 2,
        /** 相続人確認 */
        HeirConfirm = 3,
        /** 手続き案内 */
        ProcedureGuide = 4
    }

    /**
     * Swipe Card Type
     */
    export enum SwipeCardType {
        /** スワイプなし */
        SwipeNoCard = '0',
        /** スワイプあり */
        SwipeCard = '1',
        /** スワイプあり・なし */
        SwipeCardOrNot = '2',
    }

    /**
     * Passcode Type
     */
    export enum PasscodeType {
        /** 暗証番号4桁 */
        password4bits = '1',
        /** 暗証番号6桁 */
        password6bits = '2',
    }

    /**
     * 口座科目コード
     */
    export enum AccountTypeCode {
        /** 普通 */
        ordinary = '1',
        /** 当座 */
        current = '2',
    }

    /**
     * 口座科目コード（勘定系の返却値に対応）
     */
    export enum AccountTypeCodeCoreBanking {
        /** 普通 */
        ordinary = '12',
        /** 貯蓄 */
        savings = '13',
        /** 納税準備預金 */
        taxpaying = '14',
        /** 通知預金 */
        notification = '16',
        /** 定期 */
        timeDeposit = '20',
        /** 積立定期 */
        installment = '26',
        /** 公共債 */
        publicBond = '35',
        /** カードローン */
        cardLoan = '48'
    }

    /**
     * 預入方法
     */
    export enum DepositMethod {
        /** 振替 */
        transfer = '6',
        /** 現金 */
        cash = '7',
    }

    /**
     * 画像・テキスト登録
     */
    export enum InsertImageType {
        /** 画像登録 */
        image = '1',
        /** テキスト登録 */
        text = '2',
    }

    /**
     * 登録確認書類
     */
    export enum InsertDocument {
        Holder = 'holder',
        HolderAdditional = 'holderAdditional',
        Agent = 'agent',
        AgentAdditional = 'agentAdditional'
    }

    /**
     * CIF情報氏名判定
     */
    export enum CifInfoResult {
        JAPANESE = '1',
        FOREIGN_KANJI = '2',
        FOREIGN = '3',
    }

    /**
     * 勘定エラー理由
     */
    export enum ErrReason {
        /** Q00126 */
        CODE_Q00126 = 'Q00126',
        /** Q00056 */
        CODE_Q00056 = 'Q00056',
        /** Q00057 */
        CODE_Q00057 = 'Q00057',
        /** Q00058 */
        CODE_Q00058 = 'Q00058',
        /** Q00097 */
        CODE_Q00097 = 'Q00097',
        /** Q00046 */
        CODE_Q00046 = 'Q00046',
    }

    /**
     * 内部エラーコード
     */
    export enum ErrCode {
        /** MAINTENANCE */
        CODE_MAINTENANCE = 'Maintenance',
        /** Default システム */
        CODE_E00001 = 'E00001',
        /** システム コードある */
        CODE_E00002 = 'E00002',
        /** ネットワークエラー コードある */
        CODE_E00003 = 'E00003',
    }

    /**
     * HandleType
     */
    export enum HandleType {
        /** 業務エラー（ダイアログ表示） */
        TYPE_POPUP = '01',
        /** 業務エラー（行員呼出） */
        TYPE_CALL = '02',
        /** 処理継続: */
        TYPE_CONTINUE = '03',
        /** システムエラー: */
        TYPE_SYSTEM = '04',
    }

    /**
     * 無効地域コード000000
     */
    export const ADDRESS_NOT_REGISTED = '000000';

    /**
     * 無効地域コード999999
     */
    export const NO_REGION_CODE = '999999';

    export const CSS_MODAL_W_480 = 'modal-w480';

    export const IYO_BANK_NAME = '伊予銀行';

    /**
     * 受取口座の口座名義人半角カナの最大桁数
     */
    export const BENEFICIARY_NAME_MAX_LENGTH = 25;

    /**
     * 全店名寄せ照会：顧客検索結果
     */
    export enum CustomerSearchStatus {
        /** 未出力明細あり */
        NOT_ALL_OUTPUT = '1'
    }

    /**
     * 全店名寄せ照会：住所コード該当有無
     */
    export enum NotExistingAddressCodeStatus {
        /** 該当なし */
        NOT_APPLICABLE = '1'
    }
}

/**
 * APIをアクセスするためのURL
 */
export namespace API_URL {

    /******************************************************
     * CreditCard
     ******************************************************/
    // export const GET_CHATFLOW_TEMPLATE = '/chatflow/definition/';
    export const BRANCH_STATUS_INSERT = '/branchInfo/tabletInfo/insert';
    export const BRANCH_STATUS_UPDATE = '/branchInfo/tabletInfo/update';
    export const BRANCH_NAME = '/branch-info/tabletInfo/branch-name-get';
    export const CREDITCARD_INFO_INSERT = '/card-info/tablet-info/creditcard-insert';
    export const GET_CREDITCARD_INFO = '/card-info/creditcard-basic-info';
    export const GET_CONSUMPTION_TAX = '/calculation-tax/consumption-tax';
    export const BC_APPLY_CHECK = '/reception/bc-apply/check';

    /******************************************************
     * サーバーのシステム時間
     ******************************************************/
    export const SERVER_SYSTEM_TIME_URL = '/time/system-time';

    /******************************************************
     * 相続
     ******************************************************/
    export const INHERIT_INFO_UPDATE_URL = '/core-banking/inherit/inherit-info/register';
    export const CB_CHECK_ACCOUNT_INFO = '/core-banking/account-info/check';

    /******************************************************
     * 既存普通預金
     ******************************************************/
    export const EXISTING_SAVINGS_INSERT = '/existing-savings/insert';

    export const STUDENT_NEW_INSERT = '/student/new/insert';
    export const STUDENT_CHANGE_INSERT = '/student/change/insert';
    export const STUDENT_LIMIT = '/japaneseCalendar/student-card-time-limit/retrieve';

    /******************************************************
     *  相続のお手続き
     ******************************************************/
    export const JAPANESE_CALENDAR = '/japaneseCalendar/convert-date/age-addition';

    /******************************************************
     *  日付の変換
     ******************************************************/
    export const INHERIT_INFO_CONVERTDATE_URL = '/japaneseCalendar/date/convert';
    export const BIRTHDAY_CONVERTDATE_URL = '/japaneseCalendar/birthday/convert';
    /******************************************************
     *  定期預金
     ******************************************************/
    export const GET_SAVING_ACCOUNT_INFO = '/account-info/ordinary-deposit-balance/inquiry';
    export const GET_NEXT_BUSINESS_DAY = '/business-day/get-next';
    export const GET_DEPOSIT_ACCOUNT_INFO = '/core-banking/deposit-transfer-account-info/inquiry';
    export const GET_ORDINARILY_ACCOUNT_INFO = '/core-banking/ordinarily-account-info/inquiry';
    /******************************************************
     *  定期解約
     ******************************************************/
    export const GET_CANCEI_RATE_INFO = '/core-banking/time-deposit-account-interest-transfer/check-inquiry';
    export const CANCELABLE_CHECK = '/core-banking/installment-time-deposit-account-cancelable-info/check';
    export const CANCEL_INSERT = '/core-banking/time-deposit-accounts/cancel';

    export const INSERT_POINT_SERVICE_INFO = '/point-service/new/insert';
    export const INSERT_DIRECT_BANKING_INFO = '/direct-banking/new/insert';

    /******************************************************
     * 定期預金書
     ******************************************************/
    // 定期預金書申込情報登録
    export const INSERT_TIME_DEPOSIT_REWRITING_INFO = '/time-deposit-rewriting-apply/insert';

    /******************************************************
     * 勘定系API
     ******************************************************/
    export const CB_CHECK_ACCOUNT_EXISTING = '/core-banking/account-exist/check';
    export const CB_GET_CIF_INFORMATION = '/core-banking/cif-info/inquiry';
    export const CB_GET_SIMPLE_CIF_INFORMATION = '/core-banking/simple-cif-info/inquiry';
    // 名寄せリスト
    export const CUSTOMER_INFOS_LIST = '/core-banking/customerInfos-list/inquiry';
    /** 全店名寄せ照会 */
    export const NAME_AGGREGATION = '/core-banking/name-aggregation/inquiry';
    export const CB_CHECK_EXISTING_PASSWORD_RULE = '/core-banking/existing-password-rule/check';
    export const CB_CHECK_NEW_PASSWORD_RULE = '/core-banking/new-password-rule/check';
    export const CB_CHECK_PASSWORD_AUTH = '/core-banking/password/auth';
    export const CB_GET_ACCOUNT_INFORMATION = '/core-banking/account-info/inquiry';
    export const CB_GET_ACCOUNT_INFORMATION_2ND = '/core-banking/deposit-possible-passbook-info/inquiry';
    export const CB_GET_ACCOUNT_BALANCE = '/core-banking/account-balance/inquiry';
    export const CB_UPDATE_NAME = '/core-banking/name/change';
    export const CB_UPDATE_ADDRESS = '/core-banking/address/change';
    export const CB_UPDATE_TELEPHONE = '/core-banking/telephone/change';
    export const CB_UPDATE_NAME_ADDRESS = '/core-banking/name-address/change';
    export const CB_UPDATE_NAME_TEL = '/core-banking/name-tel/change';
    export const CB_UPDATE_ADDRESS_TEL = '/core-banking/address-tel/change';
    export const CB_UPDATE_NAME_ADDRESS_TEL = '/core-banking/name-address-tel/change';
    export const CB_SAME_HOLDER_INQUIRY = '/core-banking/same-holder/inquiry';
    export const CB_DEAL_CONDITION = '/core-banking/deal-condition/inquiry';
    export const CB_GET_TIME_BALANCE = '/core-banking/time-balance/inquiry';
    export const CB_ANCESTOR_ACCOUNT_INFO_CIF_INQUIRY = '/core-banking/ancestor-account-with-cif/inquiry';
    // L01-R-API016_口座残高照会_預金
    export const CB_SECURITY_ACCOUNT_LIST_INQUIRY = '/core-banking/security-account-list/inquiry';
    export const CB_SECURITY_ACCOUNT_ADD = '/core-banking/security-account/add';
    export const CB_GET_ACCOUNT_WITHOUT_CARD = '/core-banking/account-without-card/inquiry';
    export const CB_GET_REWRITE_PRODUCT_INFO = '/core-banking/rewrite-product-info/inquiry';
    export const CB_GET_REVISE_ACCOUNT_INFO = '/core-banking/revise-account-info/inquiry';
    export const CB_CIF_INFOS_INQUIRY = '/core-banking/cif-infos/inquiry';

    // 口座残高照会_預金
    export const DOMESTIC_LOAN_ACCOUNTS_BALANCE = '/core-banking/domestic-loan-accounts-balance/inquiry';
    // 口座残高照会_外貨預金
    export const FOREX_ACCOUNTS_BALANCE = '/core-banking/forex-accounts-balance/inquiry';
    // 口座残高照会_投資信託
    export const INVESTMENT_TRUST_ACCOUNTS_BALANCE = '/core-banking/investment-trust-accounts-balance/inquiry';
    // 口座残高照会_公共債
    export const BOND_ACCOUNTS_BALANCE = '/core-banking/bond-accounts-balance/inquiry';
    // 口座残高照会_バンクカード
    export const BANK_CARD_ACCOUNTS_BALANCE = '/core-banking/bank-card-accounts-balance/inquiry';
    // 口座残高照会_MEJAR管理外
    export const INACTIVE_ACCOUNTS_BALANCE = '/core-banking/inactive-accounts-balance/inquiry';
    // 簡素化判定
    export const SIMPLIFIED_JUDGMENT_CHECK = '/core-banking/inherit/simplified-judgment/check';
    // 相続受付情報登録
    export const INHERIT_INFO_REGISTER = '/core-banking/inherit/inherit-info/register';

    /******************************************************
     * 住変
     ******************************************************/
    // 住所変更受付可否チェックAPI
    export const ADDRESS_CHANGE_CHECK = '/reception/address-change/check';
    // 同一名義人API
    export const CB_SAME_CUSTOMERS = '/core-banking/same-holder/inquiry';
    // カード認証API
    export const CARD_CERTIFICATION_CHECK = '/card-info/check';

    /******************************************************
     * 喪失・再発行・発見 破損・暗証失念
     ******************************************************/
    // 受付可否チェック（喪失・破損）
    export const RECEPTION_LOSS_CORRUPTION_CHECK = '/reception/loss-apply/check';
    // 喪失
    export const UNACCEPTABLE_CODE_CONTRACT = '/core-banking/unacceptable/code-contract';
    // 発見・再発行
    export const MEDIUM_DISCOVERY_REISSU = '/core-banking/medium/discovery-reissu';

    /******************************************************
     *  カード差替
     ******************************************************/
    // カード差替
    export const CARD_REPLACEMENT = '/core-banking/medium/card-replacement';

    /******************************************************
     * 解約
     ******************************************************/
    /** 口座状態照会 */
    export const ACCOUNT_STATUS_INFO_INQUIRY = '/core-banking/account-status-info/inquiry';
    /** 少額預金口座付帯サービス情報取得 */
    export const INCIDENTAL_INFO_INQUIRY = '/core-banking/incidental-info/inquiry';
    /** 睡眠・休眠情報照会 */
    export const DORMANT_DEPOSIT_INFO_INQIRY = '/core-banking/dormant-deposit-info/inqiry';
    /** 不活動口座照会 */
    export const INACTIVE_ACCOUNT_INFO_INQUIRY = '/core-banking/inactive-account-info/inquiry';
    /** 振込先口座確認 */
    export const PAYEE_ACCOUNT_CHECK = '/core-banking/payee-account/check';
    /** 少額預金解約 */
    export const ACTIVE_ACCOUNTS_CANCEL = '/core-banking/active-accounts/cancel';
    /** 睡眠預金解約 */
    export const INACTIVE_ACCOUNTS_CANCEL = '/core-banking/inactive-accounts/cancel';
    /** マイナンバー登録情報 */
    export const REGISTER_MYNUMBER_INFO = '/core-banking/register-mynumber/information';
    /******************************************************
     * 共通
     ******************************************************/
    export const CATEGORY_CODES_RETRIEVE = '/categoryCodes/retrieve';
    export const ADDRESS_ZIPCODE_SEARCH = '/address/zipCodeSearch';
    export const TABLET_INFO_UPDATE = '/tabletInfo/update';
    export const ACCOUNT_SEARCHBYADDR = '/account/searchbyaddr';
    export const CHATFLOW_DEFINITION = '/chatflow/definition/';
    export const OCR_ANALYSIS = '/ocr/analysis';
    export const DEFAULT_ADDRESS = '/branchInfo/branch-info-get';
    export const QRCODE_DECRYPT = '/qrcode/decrypt';
    export const HAS_TABLET_APPLY_COUNT = '/branchInfo/tablet-info/has-tablet-apply-info';
    export const ADDRESS_ZIP_CODE_SEARCH = '/address/zipCodeSearch';
    export const BANKCLERK_CONFIRM_INSERT = '/branchInfo/tabletInfo/bankclerk-confirm-insert';
    export const JAPANESECALENDAR_DEATHDAY_URL = '/japaneseCalendar/years/get';

    export const CONTRACT_INFO = '/contract/contract-info/inquiry';
    export const AUTOMATIC_TRANSFER_INSERT = '/automatic-transfer/insert';
    export const CARD_READER_DEIVCE_ID = '/device/cardReader/deviceId';

    /** 自動振込振替手数料取得 */
    export const TRANSFER_FEE = '/transfer-fee/get';

    /** 銀行名（漢字・カナ）の存在チェック */
    export const BANK_EXIST_CHECK = '/bank-info/bank-exist/check';

    /** 支店名（漢字・カナ）の存在チェック */
    export const BRANCH_EXIST_CHECK = '/bank-info/branch-exist/check';

    /** 営業日チェック */
    export const BUSINESS_DAY_CHECK = '/business-day/check';
    export const REGION_CODE_SEARCH = '/region-code/search';

    /** Apiのバージョンを取得する */
    export const GET_API_VERSION = '/contents/version.json';

    /** 文字チェック */
    export const CHARACTER_CHECK = '/character/check';

    /** 受付チェック */
    export const RECEPTION_CHECK = '/reception/check';

    /** 受付可否チェック（少額・睡眠解約／定期・通知明細） */
    export const RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK = '/reception/cancel-account-apply/check';

    /** フィルタリングシステム検索 */
    export const FILTERING_INQUIRY = '/filtering/inquiry';

    /** 店舗カナ頭文字情報取得 */
    export const BRANCH_KANA_LIST = '/branch-info/branch-kana-list-get';

    /** 相続の店舗カナ頭文字情報取得 */
    export const INHERIT_BRANCH_KANA_LIST = '/branch-info/branch-kana-list-get-inherit';

    /** 喪失の店舗カナ頭文字情報取得 */
    export const LOSS_BRANCH_KANA_LIST = '/branch-info/branch-kana-list-get-loss';

    /** 店舗カナ頭文字より店舗リスト取得。 */
    export const BRANCH_LIST = '/branch-info/branch-list/get-by-kana';

    /** 相続の店舗カナ頭文字より店舗リスト取得。 */
    export const INHERIT_BRANCH_LIST = '/branch-info/branch-list/get-by-kana-inherit';

    /** 喪失の店舗カナ頭文字より店舗リスト取得。 */
    export const LOSS_BRANCH_LIST = '/branch-info/branch-list/get-by-kana-loss';

    /** 普通預金口座開設 */
    export const ORDINARILY_ACCOUNT_INFO = '/core-banking/ordinarily-account-info/opening';

    /** 定期預金口座開設 */
    export const TIME_DEPOSIT_ACCOUNT_INFO = '/core-banking/time-deposit-account-info/opening-deposit';

    /** 積立定期預金口座開設 */
    export const INSTALLMENT_TIME_DEPOSIT_ACCOUNT_INFO = '/core-banking/installment-time-deposit-account-info/opening';

    export const UPDATE_APPLY_BUSINESS_CATEGORY = '/branch-info/tablet-info/apply-biz-category/update';

    /** BC申込 */
    export const BANKCARD_BC_APPLICATION = '/core-banking/bankcard/bc-application';

    /** 保有通帳・カード・印鑑情報照会 */
    export const MEDIUM_INFO_INQUIRY = '/core-banking/medium-info/inquiry';

    /** 住所コードを取得 */
    export const GET_ADDRESS_CODE = '/address/addresscode-get';

    /** 取引有無照会 */
    export const TRADING_PRESENCE_INQUIRY = '/core-banking/trading-presence/inquiry';

    /** ダイレクトチャネル契約内容照会 */
    export const DIRECT_CHANNEL_INQUIRY = '/core-banking/directchannel/inquiry';

    /** 金融機関カナ頭文字取得 */
    export const INITIAL_BANKNAME_KANA = '/bankinfo/initial-banknamekana-get';

    /** 金融機関支店名カナ頭文字取得 */
    export const INITIAL_BRANCHNAME_KANA = '/bankinfo/initial-branchnamekana-get';

    /** 金融機関名情報一覧取得 */
    export const BANK_NAME_INFO = '/bankinfo/bankNameInfo-get';

    /** 支店名情報一覧取得 */
    export const BRANCH_NAME_INFO = '/bankinfo/branchNameInfo-get';

    /** 入力した店番号をキーに支店名情報を取得 */
    export const BRANCH_NAME_INFOS = '/bankinfo/branchNameInfos-get';
}

/**
 * Template File Url
 */
export namespace TEMPLATE_FILE {

    /******************************************************
     * CreditCard
     ******************************************************/
    export const CREDIT_CARD_COMMON = '/chatflow/definition/chat-flow-def-creditcard-common.yml';
    export const CREDIT_CARD_COMPOSIT = '/chatflow/definition/chat-flow-def-creditcard-composit.yml';
    export const CREDIT_CARD_DC = '/chatflow/definition/chat-flow-def-creditcard-dc.yml';

    export const CREDIT_CARD_DISPATCH = '/chatflow/definition/chat-flow-def-creditcard-dispatch.yml';
    export const CREDIT_CARD_SECONDMENT = '/chatflow/definition/chat-flow-def-creditcard-secondment.yml';
    export const CREDIT_CARD_EMPLOYMENT = '/chatflow/definition/chat-flow-def-creditcard-employment.yml';
    export const CREDIT_CARD_BANK_CARD = '/chatflow/definition/chat-flow-def-creditcard-bankcard.yml';
    export const CREDIT_CARD_TYPE = '/chatflow/definition/chat-flow-def-creditcard-type.yml';
    export const CREDIT_CARD_STUDENT = '/chatflow/definition/chat-flow-def-creditcard-student.yml';

    export const CREDIT_CARD_JCB_EMPLOYMENT = '/chatflow/definition/chat-flow-def-creditcard-jcb-employment.yml';
    export const CREDIT_CARD_JCB_DISPATCH = '/chatflow/definition/chat-flow-def-creditcard-jcb-dispatch.yml';
    export const CREDIT_CARD_JCB_FAMILY = '/chatflow/definition/chat-flow-def-creditcard-jcb-family.yml';
    export const CREDIT_CARD_JCB_TYPE = '/chatflow/definition/chat-flow-def-creditcard-jcb-type.yml';
    export const CREDIT_CARD_JCB_STUDENT = '/chatflow/definition/chat-flow-def-creditcard-jcb-student.yml';
    export const CREDIT_CARD_JCB_GUARDIAN = '/chatflow/definition/chat-flow-def-creditcard-jcb-guardian.yml';
    export const CREDIT_CARD_JCB = '/chatflow/definition/chat-flow-def-creditcard-jcb.yml';

    export const CREDIT_CARD_CONFIRMPAGE_COMMON = '/chatflow/definition/chat-flow-def-creditcard-confirmpage-common.yml';
    // export const CREDIT_CARD_CONFIRMPAGE_DC_OTHER = '/chatflow/definition/chat-flow-def-creditcard-confirmpage-dc-other.yml';
    export const CREDIT_CARD_CONFIRMPAGE_JCB_COM = '/chatflow/definition/chat-flow-def-creditcard-confirmpage-jcb-com.yml';
    // export const CREDIT_CARD_CONFIRMPAGE_JCB_OTHER = '/chatflow/definition/chat-flow-def-creditcard-confirmpage-jcb-other.yml';

    export const CREDIT_CARD_ADDRESS_IDENTIFICATION = '/chatflow/definition/chat-flow-def-creditcard-address-identification.yml';
    export const CREDIT_CARD_CHECKAPPLY = '/chatflow/definition/chat-flow-def-creditcard-checkapply.yml';
    export const CREDIT_CARD_IDENTIFICATION_DOCUMENT_ONE = '/chatflow/definition/chat-flow-def-creditcard-identification-document-one.yml';
    export const CREDIT_CARD_IDENTIFICATION_DOCUMENT_TWO = '/chatflow/definition/chat-flow-def-creditcard-identification-document-two.yml';
    export const CREDIT_CARD_IDENTIFICATION_LICENSE_NO = '/chatflow/definition/chat-flow-def-creditcard-identification-license-no.yml';
    export const CREDIT_CARD_IMGAPPLY = '/chatflow/definition/chat-flow-def-creditcard-imgapply.yml';
    export const CREDIT_CARD_STUFFCONFIRM = '/chatflow/definition/chat-flow-def-creditcard-stuffconfirm.yml';
    export const CREDIT_CARD_STUDENT_IDENTIFICATION = '/chatflow/definition/chat-flow-def-creditcard-student-identification.yml';

    export const CHANGE_EDIT_PAGE = 'chat-flow-def-change-edit-page.yml';

    export const PRODUCT_CATEGORY_CONFIG = 'dhdt/branch/pages/existing-reserve/utils/product-category-config.yaml';

    /******************************************************
     * TimeDeposit
     ******************************************************/
    export const TIME_DEPOSIT_VERIFICATION = 'chat-flow-def-time-deposit-verification.yml';
    export const STUDENT_EDIT_PAGE = 'chat-flow-def-student-confirmpage.yml';
}

/**
 * 利息計算方法
 */
export class InterestComputationMethod {
    // 利息計算方法 複利型
    public static readonly COMPOUND_INTEREST = '1';

    // 利息計算方法 単利型
    public static readonly PAY_INTEREST = '0';

    // 預入期間 = 3年
    public static readonly THREE_YEAR = 3;

    // 定年までの期日 = 2年
    public static readonly DEPOSITTERM = 200;
}

export class ConfirmChatPageIndex {
    // 個人情報
    public static readonly SELF_INFO = 98;
    // 申請情報共通
    public static readonly APPLY_COMMON = 99;
    public static readonly APPLY_COMMON_OTHER = 88;
}

export class ConfirmChatPageId {
    // 個人情報
    public static readonly SELF_INFO = 'ConfirmSelfApplyComponent';
    // 申請情報共通
    public static readonly APPLY_COMMON = 'ConfirmApplyCommonComponent';
    public static readonly APPLY_COMMON_OTHER = 'ApplyCommonComponent';
}

/**
 * 積立金受取方法
 */
export class ReservedFundReceiptType {
    // 積立受取方法を指定しない
    public static readonly NO_SCHEDULE = '0';
    // サイクル設定
    public static readonly RENEW = '5';
    // 受取日指定
    public static readonly SCHEDULE = '6';
}

/**
 * ライセンスが持っているコンスタント
 */
export class HasLicense {
    // 免許証を持っていない
    public static readonly HAS_NOT_LICENSE = '0';
}

/**
 *
 */
export class ChatOption {
    // 免許証を持っている
    public static readonly VALIDATION_ON = 'validationOn';
}

export class ChatFlowName {
    public static readonly AGENT_HASCONFIRMFILE = 'agentHasConfirmFile';
    public static readonly HASCONFIRMFILE = 'hasConfirmFile';
    public static readonly CASHCARD_HASCONFIRMFILE = 'cashCardHasConfirmFile';
    public static readonly CANCEL_HASCONFIRMFILE = 'cancelHasConfirmFile';
    public static readonly CHANGE_ITEM = 'changeitem';
    public static readonly IS_COHABITATION = 'isCohabitation';
}

export class ChatFlowChoicesText {
    public static readonly AGENT_HASCONFIRMFILE_TEXT = '持っている';
    public static readonly HASCONFIRMFILE_TEXTTHREE = '本人確認書類を不所持';
    public static readonly HOLDER_HAS = '本人確認書類を持っている';

}

export class ChatFlowChoicesValue {
    public static readonly AGENT_HASCONFIRMFILE_VALUE = '1';
    public static readonly HASCONFIRMFILE_VALUE = 'noConfirmFile';
    public static readonly BACK_TO_TOP = 'backToTop';
    public static readonly BACK_TO_TOP_NOT_FROM_ROOT = 'backToTopNotFromRoot';
    public static readonly HAS_PHOTO_CONFIRM_FILE_VALUE = '0';
    public static readonly HAS_NO_PHOTO_CONFIRM_FILE_VALUE = '1';
    public static readonly IS_COHABITATION_VALUE = '1';
}

export class DirectApplyExpectation {
    public static readonly NOT_APPLY = '0';
    public static readonly APPLY = '1';
}

/**
 * カードお受取方法
 */
export class ReceiptMethod {
    public static readonly HOME = '0';
    public static readonly ISSUE = '9';

    public static readonly PUBLISH_ISSUE = '1';
    public static readonly PUBLISH_MAIL = '0';
}

/**
 * カテゴリコード
 */
export class CategoryCode {
    // 本人確認書類
    public static readonly CATEGORY_CODE_IDENTITY_DOCUMENT_TYPE = '104';
    // 顔写真なし補足資料
    public static readonly CATEGORY_CODE_HOLDER_IDENTITY_DOCUMENT_ADD_TYPE = '225';
    // 在留資格
    public static readonly CATEGORY_CODE_STATUS_OF_RESIDENCE = '019';
}

/**
 * 本人確認書類タイプ
 */
export class IdentityDocumentType {
    // 本人確認書類の書類
    public static readonly IDENTITY_DOCUMENT_TYPE_PHOTOGRAPH = '0';
    // 本人確認書類の補完書類
    public static readonly IDENTITY_DOCUMENT_TYPE_ADDRESS = '1';
    // 本人確認書類の書類 キー
    public static readonly HOLDER_IDENTITY_DOCUMENT_TYPE = 'holderIdentityDocumentType';
    // 本人確認書類の補完書類
    public static readonly HOLDER_IDENTITY_DOCUMENT_PHOTO_TYPE = 'holderIdentityDocumentPhotographType';
    // 本人確認書類の補完書類
    public static readonly HOLDER_IDENTITY_DOCUMENT_ADDRESS_TYPE = 'holderIdentityDocumentAddressType';
    // 代理人本人確認書類の書類 キー
    public static readonly AGENT_IDENTITY_DOCUMENT_TYPE = 'agentIdentityDocumentType';
    // 本人確認書類有効期限
    public static readonly AGENT_IDENTITY_DOCUMENT_EXPIRY_DATE = 'identificationDocument1ExpiryDate';
    public static readonly AGENT_DOCUMENT_EXPIRY_DATE = 'agentIdentificationDocument1ExpiryDate';
}
export class CoreBankingConst {
    public static readonly bankNo = '0138';
}

/**
 * 来店者住所入力フロー
 */
export class InheritOption {
    public static readonly APPLICATION_ZIPCODE = 'applicantZipCode';
    public static readonly REPRESENTATIVE_HEIR_ZIPCODE = 'representativeHeirZipCode';
    public static readonly ANCESTOR_ZIPCODE = 'ancestorZipCode';
}

/**
 * 被相続人情報入力画面
 */
export class InheritName {
    public static readonly INHERIT_FIX = 'fix';
    public static readonly INHERIT_HAS_ACCOUNT_FIX = 'hasAccountFix';
    public static readonly INHERIT_ANCESTOR_DEATH_DATE = 'ancestorDeathDate';
    public static readonly INHERIT_ANCESTOR_DEATH_DATE_START = 'dateOfDeathStart';
    public static readonly INHERIT_ANCESTOR_DEATH_DATE_END = 'dateOfDeath';
    public static readonly INHERIT_SELECT_CURRENCY_CODE = 'selectCurrencyCode';
    public static readonly INHERIT_CONFIRM_ACCOUNT_STATUS = 'confirmAccountStatus';
    public static readonly INHERIT_ANCESTOR_ACCOUNT_INFO_REENTER = 'ancesterAccountInfoReenter';
    public static readonly INHERIT_INPUT_RECEPTION_BRANCH_REENTER = 'inputReceptionBranchReenter';
}

/**
 * 申込時間
 */
export class ApplyDate {
    // 顧客申込開始時間
    public static readonly CUSTOMER_APPLY_START_DATE = 'customerApplyStartDate';
    // 顧客申込完了時間
    public static readonly CUSTOMER_APPLY_END_DATE = 'customerApplyEndDate';
    // 行員確認スタート時間
    public static readonly BANKCLERK_AUTHENTICATION_START_DATE = 'bankclerkAuthenticationStartDate';
    // 行員確認完了時間
    public static readonly BANKCLERK_AUTHENTICATION_END_DATE = 'bankclerkAuthenticationEndDate';
    // 申込開始時間
    public static readonly TABLET_START_DATE = 'tabletStartDate';
    // Login時間
    public static readonly APPLY_DATE = 'applyDate';
}

/**
 * 画像情報
 */
export class ImageInfoConsts {
    // 本人基本情報
    public static readonly IDENTITY_DOCUMENTS = 'identityDocuments';
    // 本人基本情報イメージ
    public static readonly IDENTITY_DOCUMENTS_IMAGE = 'identityDocumentsImage';
    // 本人基本補足情報
    public static readonly ADDITIONAL_INFO_DOCUMENTS = 'additionalInfoDocuments';
    // 本人基本補足情報イメージ
    public static readonly ADDITIONAL_INFO_DOCUMENTS_IMAGE = 'additionalInfoDocumentsImage';
    // 本人基本情報イメージフロント
    public static readonly HOLDER_CARD_IMAGE_FRONT_JPG = 'holderCardImageFront.jpg';
    // 本人基本情報イメージバック
    public static readonly HOLDER_CARD_IMAGE_BACK_JPG = 'holderCardImageBack.jpg';
    // 代理人基本情報イメージフロント
    public static readonly AGENT_CARD_IMAGE_FRONT_JPG = 'agentCardImageFront.jpg';
    // 代理人基本情報イメージバック
    public static readonly AGENT_CARD_IMAGE_BACK_JPG = 'agentCardImageBack.jpg';
    // JPG
    public static readonly EXTENSION_JPG = '.jpg';
    // 画像
    public static readonly PICTURE = 'picture';
    // base64
    public static readonly IMAGE_BASE64 = 'data:image/jpeg;base64,';
    // 本人確認情報
    public static readonly SELECT_HOLDERID_PHOTO_TYPE = '0';
    // 代理人基本補足情報
    public static readonly AGENT_IDENTITY_DOCUMENTS = 'agentIdentityDocuments';
    // 代理人基本補足情報イメージ
    public static readonly AGENT_ADDITIONAL_INFO_DOCUMENTS = 'agentAdditionalInfoDocuments';
    // alertイメージフロント
    public static readonly ALERT_IMAGE_PNG = 'icon_alert@2x.png';
}

/**
 * コードカテゴリ
 */
export class CodeCategory {
    // 本人確認情報
    public static readonly CODE_CATEGORY_IDENTITY_DOC_TYPE = '104';
    // 本人確認書類（顔写真ない）の補完書類の種類
    public static readonly CODE_CATEGORY_IDENTITY_DOC_PHOTOGRAPH_TYPE = '105';
    // 本人確認書類（住所異なる）の補完書類の種類
    public static readonly CODE_CATEGORY_IDENTITY_DOC_ADDRESS_TYPE = '106';
    // 顔写真なし補足資料
    public static readonly CODE_CATEGORY_HOLDER_IDENTITY_DOC_ADD_TYPE = '225';

    /** 重複口座の開設理由 */
    public static readonly CODE_CATEGORY_DUPLICATION_REASON = '246';
    /** 重複口座の開設理由 その他 */
    public static readonly CODE_CATEGORY_DUPLICATION_REASON_OTHER = '4';
    /** 遠隔地等住所等の場合の理由 */
    public static readonly CODE_CATEGORY_FAR_ADDRESS_REASON = '248';
    /** 遠隔地等住所等の場合の理由 その他 */
    public static readonly CODE_CATEGORY_FAR_ADDRESS_REASON_OTHER = '05';
    /** コピー徴求ができない理由 */
    public static readonly CODE_CATEGORY_NO_COPY_REASON = '249';
    /** 住所が相違する理由 */
    public static readonly CODE_CATEGORY_DIFFERENT_ADDRESS_REASON = '250';
    /** 住所が相違する理由 その他 */
    public static readonly CODE_CATEGORY_DIFFERENT_ADDRESS_REASON_OTHER = '04';

    public static readonly RECEIPT_METHOD_MAIL = '1';
    public static readonly RECEIPT_METHOD_ISSUE = '3';

    public static readonly FACEID = '1';
}

/**
 * CSSスタイル
 */
export class CssConsts {
    // css-full-modal
    public static readonly CSS_CLASS_FULL_MODAL = 'full-modal';
    // css-two-inputs
    public static readonly CSS_CLASS_TWO_INPUTS = 'two-inputs';

    public static readonly CSS_CLASS_HALF_MODAL = 'half-modal';
    public static readonly CSS_CLASS_WARNING_MODAL = 'settings-warning-modal';
    public static readonly CSS_CLASS_CONFIRM_MODAL = 'settings-confirm-modal';
    public static readonly CSS_CLASS_HALF_MODAL_NORMAL = 'half-modal-normal';
    public static readonly CSS_CLASS_HALF_MODAL_TITLE = 'half-modal-title';

    // css-alert-modal
    public static readonly CSS_CLASS_ALERT_MODAL = 'settings-alert-modal';

    public static readonly CSS_CLASS_HALF_MODAL_SMALL = 'half-modal-small';
    public static readonly CSS_CLASS_PDF_MODAL = 'pdf-modal';

    public static readonly CSS_CLASS_TABLE_ITEM_FONT_20 = 'table-view-item-font-20';
    public static readonly CSS_CLASS_TABLE_ITEM_FONT_14 = 'table-view-item-font-14';
    public static readonly CSS_CLASS_TABLE_VIEW_WIDTH = 'table-view-width-840';
    public static readonly CSS_CLASS_TABLE_VIEW_ROW_PADDING = 'table-view-row-padding-18';
    public static readonly CSS_CLASS_TABLE_ITEM_RIGHT = 'table-view-item-right';
    public static readonly CSS_CLASS_TABLE_ITEM_LINE_HEIGHT = 'table-view-item-line-height-3';
    public static readonly CSS_CLASS_TABLE_ITEM_LINE_HEIGHT_1_5 = 'table-view-item-line-height-1-5';
    public static readonly CSS_CLASS_TABLE_TRANSFER_BANK = 'table-view-item-transfer-bank';

    public static readonly CSS_CLASS_TABLE_ITEM_INFO = 'table-view-item-account-info';
    public static readonly CSS_CLASS_TABLE_ITEM_RATE = 'table-view-item-rate';
    public static readonly CSS_CLASS_TABLE_ITEM_DEPOSIT_PERIOD = 'table-view-item-deposit-period';
    public static readonly CSS_CLASS_TABLE_ITEM_AMOUNT = 'table-view-item-amount';
}

/**
 * Notification type
 */
export class EventsType {
    public static readonly AUDIO_PLAY = 'EventsType_AUDIO_PLAY';
}

/**
 * submit data key
 */
export class SubmitDataKey {
    // 名義人ー本人確認書類の種類
    public static readonly HOLDER_ID_DOC_TYPE = 'holderIdentityDocumentType';
    // 名義人ー本人確認書類（顔写真ない）の補完書類の種類
    public static readonly HOLDER_ID_DOC_PHOTO_TYPE = 'holderIdentityDocumentPhotographType';
    // 名義人ー本人確認書類（住所異なる）の補完書類の種類
    public static readonly HOLDER_ID_DOC_ADDRESS_TYPE = 'holderIdentityDocumentAddressType';

    // 代理人 本人確認書類
    public static readonly AGENT_ID_DOC_TYPE = 'agentIdentityDocumentType';
    // 代理人 顔写真のない本人確認資料の場合の補完資料
    public static readonly AGENT_ID_DOC_PHOTO_TYPE = 'agentIdentityDocumentPhotographType';
    // 代理人 本人確認資料の住所と現住所が異なる場合の補完資料
    public static readonly AGENT_ID_DOC_ADDRESS_TYPE = 'agentIdentityDocumentAddressType';

    // お受取方法
    public static readonly RECEIPT_METHOD = 'receiptMethod';
    public static readonly HOLDER_NO_COPY_REASON = 'holderNoCopyReason';
    public static readonly AGENT_NO_COPY_REASON = 'agentNoCopyReason';
    public static readonly HOLDER_IDENTITY_DOCUMENT_NO_COPY_REASON = 'holderIdentityDocumentNoCopyReason';
    public static readonly AGENT_IDENTITY_DOCUMENT_NO_COPY_REASON = 'agentIdentityDocumentNoCopyReason';
    public static readonly ADDRESS_DIFFERENT_REASON = 'addressDiffrentReason';
    public static readonly HOLDER_REMOTE_ADDRESS_REASON = 'holderRemoteAddressReason';
    public static readonly HOLDER_IDENTITY_DOCUMENT_ADDRESS_REASON = 'holderIdentityDocumentAddressReason';
    public static readonly AGENT_IDENTITY_DOCUMENT_ADDRESS_REASON = 'agentIdentityDocumentAddressReason';

    public static readonly HOLDER_ID_DOC_TYPE_FILLER = 'holderIdentityDocumentTypeFiller';
    public static readonly CASH_CARD_RECEIPT_METHOD = 'cashCardReceiptMethod';

    // log
    public static readonly LOG_FILE_INFO = 'fileInfo';

    public static readonly KEY_TABLET_APPLY_ID = 'tabletApplyId';

    public static readonly KANA_DETAIL = 'kanaDetail';

    public static readonly WIRE_TRANSFER_CONTENTS = 'wireTransferContents';

    public static readonly BENEFICIARY_NAME = 'beneficiaryName';

    public static readonly WITHDRAWAL_BANK_NAME = 'withdrawalBankName'; // 申込人引落銀行
    public static readonly WITHDRAWAL_BRANCH_NO = 'withdrawalBranchNo'; // 申込人引落店番
    public static readonly WITHDRAWAL_BRANCH_NAME = 'withdrawalBranchName'; // 申込人引落店名

    public static readonly WITHDRAWAL_ACCOUNT_ITEM = 'withdrawalAccountItem'; // 申込人引落科目
    public static readonly WITHDRAWAL_ACCOUNT_NO = 'withdrawalAccountNo'; // 申込人引落口座番号

    public static readonly MONTHLY_TRANSFER_DATE = 'monthlyTransferDate';
    public static readonly MONTHLY_TRANSFER_AMOUNT = 'monthlyTransferAmount';

    public static readonly SPECIFIED_TRANSFER_MONTH_1 = 'specifiedTransferMonth1';
    public static readonly SPECIFIED_TRANSFER_MONTH_2 = 'specifiedTransferMonth2';

    public static readonly SPECIFIED_TRANSFER_AMOUNT1 = 'specifiedTransferAmount1';
    public static readonly SPECIFIED_TRANSFER_AMOUNT2 = 'specifiedTransferAmount2';

    public static readonly MONTHLY_EXCHANGE_FEE = 'monthlyExchangeFee';

    public static readonly SPECIFIED_EXCHANGE_FEE_1 = 'specifiedExchangeFee1';
    public static readonly SPECIFIED_EXCHANGE_FEE_2 = 'specifiedExchangeFee2';

    public static readonly TRANSFER_DESTINATION_BANK = 'transferDestinationBank';       // 振込先銀行
    public static readonly TRANSFER_DESTINATION_BRANCH = 'transferDestinationBranch';   // 振込先支店名
    public static readonly TRANSFER_DESTINATION_ACCOUNT_NO = 'receiptAccountNo';        // 振込先受取口座の口座番号
    public static readonly TRANSFER_DESTINATION_ACCOUNT_ITEM = 'receiptAccountItem';        // 受取口座科目
    public static readonly HANDLING_FEE = 'handlingFee';    // 取扱手数料
    public static readonly TRANSFER_START_DATE = 'transferStartDate'; // 振込開始月
    public static readonly TRANSFER_END_DATE = 'transferEndDate'; // 振込終了年月
    public static readonly TRANSFER_LAST_DATE = 'transferLastDate'; // 振込終了年月

    public static readonly HANDLING_NO = 'handlingNo'; // 取扱番号
    // 書替
    public static readonly HAS_REWRITING_PRODUCT = 'hasRewritingProduct';
    // 相続人関連リスト
    public static readonly RELATIONSHIP_LIST = 'relationshipList';

    // 併記された普通預金口座
    public static readonly DEPOSIT_ACCOUNT = 'depositAccount';

    // 休眠口座
    public static readonly INACTIVE_ACCOUNT_INFO = 'inactiveAccountInfo';

    // 諸届け変更
    public static readonly NAME_IDENTI_IMAGE_FLAG = 'nameIdentiImageFlag';
    public static readonly PROPERTIES_CONFIRM_IMAGE_FLAG = 'propertiesConfrimImageFlag';
    public static readonly ADD_IDENTITY_DOCUMENT_IMG = 'addIdentityDocumentImg';
}

/**
 * 本人確認書類フィラー
 */
export class HolderIdDocFillerType {
    public static readonly HOLDER_ID_DOC_TYPE_FILLER_FACE = '1';

    public static readonly HOLDER_ID_DOC_TYPE_FILLER_NO_FACE = '2';
}

/**
 * student status
 */
export class StudentType {
    public static readonly IS_STUDENT = '0';

    public static readonly IS_NOT_STUDENT = '1';
}

/**
 * holder career code
 */
export class HolderCareerCode {
    public static readonly OTHER = '00';

    public static readonly STUDENT = '08';
    // 主婦（主夫）05
    public static readonly HOUSEWIFE = '05';
    // 年金生活者06
    public static readonly ANNUITY_PENSION = '06';
    // 退職された方09
    public static readonly RETIRED = '09';
    // 無職の方10
    public static readonly UNEMPLOYED = '10';
}
export class ExistingHolderCareerCode {
    // 主婦
    public static readonly HOUSEWIFE = '07';
    // 学生（小学生以上）
    public static readonly STUDENT = '08';
    // なし（乳幼児/退職された方/無職の方等）
    public static readonly NO_WORK = '09';

}

export class ForeignHolderCareerCode {
    // 会社役員
    public static readonly OFFICER = '01';
    // 専門職
    public static readonly PROFESSION = '02';
    // 会社員
    public static readonly EMPLOYEE = '03';
    // 公務員
    public static readonly PUBLIC_EMPLOYEE = '04';
    // 個人事業主
    public static readonly SELF_EMPLOYEE = '05';
    // パート
    public static readonly PART = '06';
    // 米軍
    public static readonly US_TROOPS = '19';
    // 主婦
    public static readonly HOUSEWIFE = '07';
    // なし（乳幼児/退職された方/無職の方等）
    public static readonly NO_WORK = '09';

    // 学生（小学生以上）
    public static readonly STUDENT = '08';
}
/**
 * 勤務先と通学先の聴取結果
 */
export class CommuteToSchoolOrCompany {
    // 勤務地＋学校
    public static readonly SCHOOL_AND_COMPANY = '01';
    // 学校
    public static readonly SCHOOL_ONLY = '02';
    // 勤務地
    public static readonly COMPANY_ONLY = '03';
    // 聴取なし
    public static readonly NO_COMMUTE = '04';
}

/**
 * お勤め先、通学先名称の入力チェック
 */
export class IsWorkPlaceOrSchool {
    // お勤め先、通学先
    public static readonly SCHOOL_AND_COMPANY = '01';
    // お勤め先
    public static readonly COMPANY_ONLY = '02';
    // 通学先
    public static readonly SCHOOL_ONLY = '03';
    // 本人確認書類
    public static readonly IDIFO_DOC_CHECK = '04';
}

/**
 * 在籍証明資料
 */
export class CertificateOfEnrollment {
    // 勤務先確認書類
    public static readonly WOPK_PLACE_CERTIFICATE = '01';
    // 通学先確認書類
    public static readonly SCHOOL_CERTIFICATE = '02';
    // 勤務先通学先両方
    public static readonly SCHOOL_AND_WOPK_PLACE_CERTIFICATE = '03';
    // 米軍ID
    public static readonly USARMYID = '04';
    // 米軍ID＋勤務先
    public static readonly USARMYID_WOPK_PLACE = '05';
    // 米軍ID＋通学先
    public static readonly USARMYID_SCHOOL = '06';
    // 米軍ID＋通学先+勤務先
    public static readonly USARMYID_SCHOOL_WOPK_PLACE = '07';
}

/**
 * license service status
 */
export class LicenseServiceStatus {
    public static readonly GET_OCR = 'getOCR';

    public static readonly OVER_OCR = 'overOCR';

    public static readonly COMPLETE = 'complete';

}

/**
 * license photo type
 */
export class LicensePhotoType {
    public static readonly CARD_FRONT_AND_BACK = 'cardFrontAndBack';

    public static readonly CARD_FRONT = 'cardFront';
    public static readonly DOCUMENT = 'document';
    public static readonly DOCUMENT_WITH_TRIM = 'documentWithTrim';
}

/**
 * OCR Analysis status
 */
export class OcrAnalysisStatus {
    // 正常
    public static readonly NORMAL: number = 0;
    // OCR処理失敗
    public static readonly ANALYSIS_FAILED: number = -2;
    // 免許証フォーマット不備
    public static readonly INCORRECT_FORMAT: number = -201;
    // チェックディジットエラー
    public static readonly CHECK_DIGIT_ERROR: number = -301;
    // 免許証有効期限切れ
    public static readonly OUT_OF_DATE: number = -401;
    // 写真のサイズが不備
    public static readonly OUT_OF_MEMORY_OR_ILLEGAL_SIZE = -10;
}

/**
 * ログサービス イベントタイプ
 */
export class LogServiceEventType {
    // 正常
    public static readonly OCR = 'OCR';
}

/**
 * 簡素化判定実施結果
 */
export class JudgeCanSimplifyResult {
    public static readonly CAN_NOT = '0';
    public static readonly CAN = '1';
    public static readonly CHAT = '2';
}

/**
 * 簡素化判定結果
 */
export class SimplifyResult {
    public static readonly THIRTY = '1';  // 超簡易手続き
    public static readonly THREE_HUNDRED = '2';  // 簡易手続200
    public static readonly FIVE_HUNDRED = '3';  // 簡易手続300
    public static readonly ORDINARY = '4';  // 一般手続き
}

/**
 * 相続人代表と死亡者の関係
 */
export class InheritRelationship {
    public static readonly SPOUSE = '01';
    public static readonly CHILD = '02';
    public static readonly GRANDCHILDREN = '03';
    public static readonly PARENT = '04';
    public static readonly GRANDPARENT = '05';
    public static readonly SIBLING = '06';
    public static readonly NEPHEW_NIECE = '07';
}

/**
 * 来店者が相続人代表である
 */
export class HeirIsApplicantResult {
    public static readonly DIFF = '0';
    public static readonly SAME = '1';
}

export class PointServiceExpectation {
    // 申込まない
    public static readonly NOT_APPLY = '0';
    // 申し込む
    public static readonly APPLY = '1';
}

export class PointServiceType {
    // 未加入
    public static readonly NOJOIN = '0';
    // ステージなし
    public static readonly NOSTAGE = '1';
    // ブロンズ
    public static readonly BRONZE = '2';
    // シルバー
    public static readonly SILVER = '3';
    // ゴールド
    public static readonly GOLD = '4';
}
/**
 * Password validation type
 */
export class PasswordValidationType {
    public static readonly PASSWORD_4BITS = '1';
    public static readonly PASSWORD_6BITS = '2';
}

/**
 * Confirm page common(Dropdown List Modal).
 * Item type
 */
export enum ModalDropDownItemType {
    big = '2'
}

/**
 * 債券／投資信託区分
 */
export class BondMutualfundType {
    public static readonly BOND = '1';
    public static readonly MUTUALFUND = '2';
}

export class DirectApplyExpectationType {
    public static readonly APPLY = '1';
    public static readonly NO_APPLY = '0';
}

/**
 * API転換用通帳情報コード
 */
export class PassbookTypeConvert {
    // 0:総合口座
    public static readonly All = '0';
    // 1:新型通帳
    public static readonly NEW = '1';
    // 2:総合口座
    public static readonly SYNTHESIZE = '2';
    // 3:新総合口座
    public static readonly SYNTHESIZE_NEW = '3';
}

/**
 * API転換用業務定義コード
 */
export class ClassificationConvert {
    // 0:口座開設
    public static readonly NEW_ACCOUNT = '0';
    // 1:預入二回目
    public static readonly SAVING_2ND = '1';
}

/**
 * Request type
 */
export enum RequestType {
    ACCOUNT_INFO = 'accountInfo',
    ACCOUNT_INFO_NORMAL = 'accountInfo_normal',
    DEFAULT_ADDRESS = 'defaultAddress',
    SAVING_ACCOUNT_INFO = 'savingAccountInfo',
    ACCOUNT_INFO_2ND = 'accountInfo2nd',
    EXISTING_ACCOUNT_LIST = 'existingAccountList',
    CANCELABLE_LIST = 'cancelableList',
    CANCEL_RATE_LIST = 'cancelRateList',
    RECEPTION_CHECK_TRANSFER = 'receptionCheckTransfer',
}

/**
 * 利払相手先口座登録に使うRQ
 */
export class InterestPaymentRQ {
    // デフォルト
    public static readonly DEFAULT = '5224';
}

/**
 * 普通預金出金に使うRQ
 */
export class DemandDepositsRQ {
    // デフォルト
    public static readonly DEFAULT = '3010';
}

/**
 * 年齢
 */
export enum Age {
    // 16歳
    Age_16 = 16,
    // 17歳
    Age_17 = 17,
    // 18歳
    Age_18 = 18,
    // 19歳
    Age_19 = 19,
    // 20歳
    Age_20 = 20,
    // 57歳
    Age_57 = 57,
    // 65歳
    Age_65 = 65,
    // 66歳
    Age_66 = 66,
    // 70歳
    Age_70 = 70,
}

/**
 * 年齢区分 受付APIにて受信する値
 */
export class AgeClassification {
    // 満18歳未満
    public static readonly U_18 = '1';
    // 満18以上-20歳未満
    public static readonly BETWEEN_18_TO_20 = '2';
    // 満20歳以上-満65歳以下
    public static readonly BETWEEN_20_TO_65 = '3';
    // 満66歳以上
    public static readonly OVER_66 = '4';
}

/**
 * 外国人の確認書類type
 */
export enum DocType {
    // 在留カード
    ResidenceCard = '01',
    // 特別永住者証明書
    SpecialPermanent = '02',
    // 米軍IDとパスポート
    UsArmy = '03',
}

/**
 * 外国人の在留カードに記載の在留資格を選択
 */
export enum ResidenceStatusChoise {
    // 永住者
    residenceCode = '01',
}

export enum HolderAgeRange {
    BELOW_16 = '0',
    ABOVE_16 = '1'
}

/**
 * 金額
 */
export enum Money {
    // 0円
    MONEY_0 = 0,
    // 1円
    MONEY_1 = 1,
    // 1千万円
    MONEY_TEN_MILLION = 10000000
}

/**
 * 年金を当行で受け取っている状態
 */
export class PensionRecipientType {
    public static readonly NOT_ACCEPT = '0'; // 年金を当行で受け取る以外場合
    public static readonly ACCEPT = '1'; // 年金を当行で受け取っている場合
}

/**
 * 学生切替Flag
 */
export class ChangeFlag {
    public static readonly CAN_CHANGE = '1';
    public static readonly CAN_NOT_CHANGE = '0';
}

/**
 * 通帳情報タイプ
 */
export class PassbookType {
    // 普通預金通帳
    public static readonly NOMRAL = '1';
    // 総合通帳
    public static readonly ALL = '2';
    // 新総合通帳
    public static readonly NEW_ALL = '3';
}

export class PassbookTypeLove {
    // オリジナルキャラクター通帳
    public static readonly ORIGINAL_CHARACTER = '1';
    // オリジナルフォト通帳
    public static readonly ORIGINAL_PHOTO = '2';
}

/**
 * 通帳情報コード
 */
export class PassbookInfoCode {
    // 新総合口座通帳
    public static readonly NEW_ALL = '0';
    // 総合口座通帳
    public static readonly ALL = '1';
    // そのほか
    public static readonly OTHER = '2';
}

/**
 * チャットシナリオ
 */
export class ChatScenario {
    // タイプA(普通預金種別あり、定期預金なし、新規定期預金通帳発行)
    public static readonly TYPE_A = 'A';
    // タイプB(普通預金種別あり、定期預金あり、定期預入二回目以降)
    public static readonly TYPE_B = 'B';
    // タイプC(総合口座あり、定期預金なし、総合口座に預入)
    public static readonly TYPE_C = 'C';
    // タイプD(総合口座あり、定期預金あり、定期預入二回目以降)
    public static readonly TYPE_D = 'D';
    // タイプE(新総合口座あり、定期預金なし、新規定期預金通帳発行)
    public static readonly TYPE_E = 'E';
    // タイプF(新総合口座あり、定期預金あり、定期預入二回目以降)
    public static readonly TYPE_F = 'F';
}

/**
 * 名義人が来店できない理由
 */
export enum AgentNoVistingReason {
    TOO_YOUNG = '3',
}

/**
 * 漢字名表示フラグ
 */
export class HolderNameShowFlag {
    public static readonly ON = '1';
    public static readonly OFF = '0';
}

/**
 * 漢字登録不可フラグ
 */
export class NameNonConvert {
    public static readonly ON = '0';
    public static readonly OFF = '1';
}
/**
 * 取引時確認済み
 */
export class StartUpVerified {
    public static readonly VERIFIED = '1'; // 済
    public static readonly NOT_VERIFIED = '0'; // 未済
}

/*
 * 口座存在チェック
 */
export enum AccountExistingCheck {
    // 口座存在
    ACCOUNT_EXISTING = '0'
}

/**
 * 本人カードタイプ。
 *
 */
export class HolderCardTypeCode {
    // 未発行
    public static readonly UN_PUBLISH = '0';
    // 一般カード
    public static readonly GENERAL_CARD = '1';
    // カードローン
    public static readonly CARD_LOAN = '2';
    // 法人キャッシュカード
    public static readonly CORPORATION_CASH_CARD = '8';
    // 貯蓄預金カード
    public static readonly DEPOSIT_CARD = '9';
    // デザイン・キャラクターカード
    public static readonly DESIGN_CHARACTER_CARD = 'A';
    // 一体型カード
    public static readonly INTEGRATED_CARD = 'B';
}

/**
 * お子さまとの続柄
 */
export enum ChildrenRelationship {
    FATHER = '1',           // 父
    MOTHER = '2',           // 母
    GRAND_FATHER = '3',     // 祖父
    GRAND_MOTHER = '4',     // 祖母
}

/**
 * 扶養されているお子さまの人数
 */
export enum childrenNumbersFlag {
    CHILDREN_NUMBER_NOT_NEXT = '0',       // 父から母へ、母から父、祖父から祖母、祖母から祖父へ修正した場合は子供人数を修正しない
    CHILDREN_NUMBER_NEXT = '1',           // 「祖父or祖母」から「父or母」に修正した場合、続けて子供人数も修正させる
    CHILDREN_NUMBER_NOT_NEXT_TWO = '2',   // 「父or母」から「祖父or祖母」に修正した場合、子供人数を消去する
}

/**
 * 特定振替日設定
 */
export class SetEveryMonthTransferDate {
    // 設定
    public static readonly SET = '0';
    // 設定しない
    public static readonly UNSET = '1';
}

/**
 * Student init render
 */
export class StudentNewInit {
    public static readonly GRADUATE_DATE = 'graduateDate';
}

/**
 * 相続RequestType
 */
export enum InheritRequestType {
    GET_ANCESTOR_CIF_INFO = '0',
    GET_APPLICANT_SWIPE_INFO = '1',
    INACTIVE_ACCOUNT_LIST = 'inactiveAccountList',
}

/**
 * 相続人の確認 page tree member status
 * 1 ご健在の方  2, 3 お亡くなりの方  4 被相続人  5 未入力  6 入力不要
 */
export enum InheritTreeMemberStatus {
    ALIVE = 1,
    DEAD_BEFORE = 2,
    DEAD_AFTER = 3,
    INHERITOR = 4,
    NODATA = 5,
    NOUSE = 6
}

export enum ModifyRepresentHeirInfo {
    REPRESENT_MOBILENO_FIRST = 'representativeHeirMobileNoFirst',
    REPRESENT_TELFIRST_NO = 'representativeHeirTelFirst',
    REPRESENT_ADDRESS_INFO = 'representativeHeirAddressInfo',
    REPRESENT_NAME = 'representativeHeirName',
    REPRESENT_ZIPCODE = 'representativeHeirZipCode'
}

/**
 * その他の商品フラグ
 */
export class OtherProductFlag {
    public static readonly SELECT = '1';
    public static readonly NOT_SELECT = '0';
}

/**
 * Inherit Modify
 */
export class InheritModify {
    public static readonly APPLICANT_TELFIRST = 'applicantTelFirst';
    public static readonly APPLICANT_MOBILENO_FIRST = 'applicantMobileNoFirst';
    public static readonly APPLICANT_ADDRESS_INFO = 'applicantAddressInfo';
    public static readonly ANCESTOR_ADDRESS_INFO = 'ancestorAddressInfo';
}

/**
 * 追加で受取日を指定
 */
export enum SetReceiptDate {
    SELECT = '0',   // 設定する
    UNSELECT = '1'  // 設定しない
}

/**
 * 携帯電話非空フラグ
 */
export class HolderMobileNoFlag {
    public static readonly BLANK = '0';
    public static readonly NOT_BLANK = '1';
}

/**
 * 本人カードデザイン
 */
export class HolderCardDesign {
    public static readonly IYOCA_DC_VISA = '41';
    public static readonly IYOCA_DC_MASTER = '42';
    public static readonly IYOCA_BC_VISA = '43';
    public static readonly IYOCA_DC_VISA_GOLD = '51';
    public static readonly IYOCA_DC_MASTER_GOLD = '52';
    public static readonly IYOCA_BC_VISA_GOLD = '53';
    public static readonly BANK_CARD = '91';
}

/**
 * clerk login errorMessageCode
 */
export enum ClerkLoginErrorCode {
    LOCKED = '1',   // アカウントがロックされています。
    DEFAULT = '2',  // パスワードに誤りがあります。
    EXPIRED = '3',  // パスワードの有効期限が切れています。パスワードを変更してください。
    RESET = '4',    // パスワードがリセットされています。パスワードを変更してください。
    NOT_BELONG_TO_BANK = '5',   // 所属する店舗以外で行員認証はできません。
    ID_ERROR = '6'  // 行員IDに誤りがあります。
}

/**
 * clerk login flag
 */
export enum ClerkLoginFlag {
    SUCCESS = 'Z',
    IGNORE = 'C',
    FAILURE = '1'
}

/*
 * 郵便番号 デフォルトの値
 */
export class ZipCode {
    public static readonly FIRST_ZIP_CODE = '000';
    public static readonly LAST_ZIP_CODE = '0000';
}

/**
 * 受取予定の年金種類
 */
export class PensionType {
    // 国民年金
    public static readonly NATIONAL_ANNUITY = '1';
    // 厚生年金
    public static readonly EMPLOYEE_PENSION = '2';
    // 共済年金
    public static readonly MUTUAL_PENSION = '3';
    // その他
    public static readonly OTHER_DETAIL = '4';
}

/**
 * 年限定計算用
 */
export class YearCalculation {
    public static readonly ADD_YEAR_ZERO = 0;
    public static readonly ADD_YEAR_TWO = 2;
    public static readonly ADD_YEAR_THREE = 3;

    public static readonly HAPPINESS1_MIN_AGE = 57;
    public static readonly HAPPINESS1_MAX_AGE = 65;

    public static readonly LOVE_MAX_AGE = 16;
}

/**
 * 月計算用
 */
export class MonthCalculation {
    public static readonly JAN = 0;
}

/**
 * 自動振込口座フラグ
 */
export class AutomaticTransferAccountFlag {
    public static readonly CURRENT = '0';
    public static readonly OTHER = '1';
    public static readonly CAN_SELECT = '0';

    public static readonly SCHOOL = '1';    // 学資
    public static readonly RENT = '2';      // 家賃
    public static readonly OTHER_FUND = '9'; // その他

    public static readonly RE_TRANSFER = '2'; // 汎用コードマスタ（再振込処理）１：依頼しない、2：依頼する
    public static readonly HANDLING_PER_DAY = '1'; // 汎用コードマスタ（休日取扱）0：翌営業日、1：前営業日

    public static readonly CANCEL_CONFIRM = 'automaticTransferCancelConfirm';

    public static readonly BUSINESS_PER_DAY = '1'; // 営業日計算、過去日計算指示
    public static readonly BUSINESS_NEXT_DAY = '2'; // 営業日計算、未来日計算指示

    public static readonly CANCEL_LIST_IS_EMPTY = '0'; // 解約可能な契約があり
    public static readonly CANCEL_LIST_NO_EMPTY = '1';  // 解約可能な契約がない

    public static readonly NOT_SELECT_SPECIFIED_TRANSFER_MONTH = '0'; // 特定の月を指定しない
    public static readonly IYO_BANK = '0';
    public static readonly OTHER_BANK = '1';    // その他銀行
}

// 自動継続方法の説明画像
export class FileSrcConsts {
    public static readonly AUTOMIC_RENEWAL_IMAGE_SRC = AppProperties.IMG_ROOT + 'modal/img_time_deposit_rewriting_principal@3x.png';
}

/**
 * 定期預金書替-書替後のお預入期間は書替前と同じflag
 */
export class UseOldDepositPeriodFlag {
    public static readonly SAME = '0';
    public static readonly DIFF = '1';
}

/**
 * 定期預金書替-書替可否flag
 */
export class CanRewritingFlag {
    public static readonly CAN = '2';
    public static readonly CANNT = '1';
}

/**
 * 自動振込
 */
export class AutomaticTransferAccount {
    public static readonly CURRENT = '0';
    public static readonly OTHER = '1';
}

/**
 * 自動振込種目
 * 汎用コードマスタ（取引種別のfiller2）1：普通、2：当座、4：貯蓄、３：納準
 */
export class AutomaticTransferAccountItem {
    /** 普通 */
    public static readonly ORDINARY = '1';
    /** 当座 */
    public static readonly CURRENT = '2';
    /** 貯蓄 */
    public static readonly SAVINGS = '4';
    /** 納準 */
    public static readonly DEPOSITS_TAX_PAYMENT = '3';
}

/**
 * 自動振込登録区分
 */
export class AutomaticTransferRegisterCategory {
    // 新規
    public static readonly TRANSFER = '1';
    // 解約
    public static readonly CANCEL = '3';
}

/**
 * 自動振込エンティティの名
 */
export class AutomaticTransferEntityName {
    public static readonly WITHDRAWAL_ACCOUNT = 'withdrawalAccount';
    public static readonly STUDENT_DEPOSIT_TYPE = 'studentDepositType';
    public static readonly SPECIFIED_TRANSFER_MONTH_SECLECT = 'specifiedTransferMonthSeclect';
    public static readonly TRANSFER_CANCEL_LIST = 'transferCancelList';
    /** 修正用手数料 */
    public static readonly WITHDRAWAL_FEE = 'withdrawalFee';
    public static readonly CHECK_IYO_BANK = 'checkIyoBank';
}

export class AutomaticTransferStudentDepositType {
    public static readonly STUDENT = '1';
    public static readonly NOT_STUDENT = '0';
}

/**
 * 手数料区分
 */
export class AutomaticTransferCommissionType {
    public static readonly HANDLING = '1';  // 取扱手数料
    public static readonly TRANSFER = '2';  // 振込手数料

    public static readonly FREE = '0';
    public static readonly PAY = '1';

    public static readonly EXCHANGE_FREE = 0;
}

/**
 * 自動振込エラーコード
 */
export enum AutomaticTransferErrorCode {
    Q00026 = 'Q00026',
    Q00027 = 'Q00027'
}

/**
 * 定期預金書替－利息の取扱
 */
export class InterestHandlingType {
    public static readonly genka = '1'; // 元加書替
    public static readonly ribarai = '3'; // 利払書替
}

/**
 * 定期預金書替-書替商品
 */
export class TimeDepositRewritingProductType {
    public static readonly super = '01'; // スーパー定期
    public static readonly free = '02'; // 自由金利型定期預金
    public static readonly madonna = '03';
    public static readonly child = '04';
    public static readonly floatingRate = '05'; // 変動金利定期預金
    public static readonly point = '06';
}

/**
 * 自動振込-Swipe口座を選択されたフラグ
 */
export class AutomaticUseSwipeAccountFlag {
    public static readonly TRUE = '1';
}

/**
 * 定期預金書替-修正種類
 */
export class TimeDepositRewritingModifyType {
    public static readonly product = 3; // 書替商品
    public static readonly peroid = 0; // 書替後のお預入期間
    public static readonly interestHandling = 2; // 書替方法
    public static readonly account = 1; // 書替前利息の受取口座
}

/**
 * 自動振替するかどうか
 */
export class AutoTransfer {
    public static readonly DO = '0';
    public static readonly NOT_DO = '1';
}

export class AddressMaxLength {
    public static readonly ADDRESS_MAX_LENGTH = 50;
    public static readonly ADDRESSKANA_MAX_LENGTH = 84;
}

/**
 * 地域コード判定方法
 */
export enum RegionCodeDeterminationMethod {
    WITHOUT_STREET = '1',
    WITH_STREET = '0'
}

/**
 * 預入期間年
 */
export enum DepositPeriodYear {
    ONE_YEAR = 1,
    THREE_YEAR = 3,
    FOUR_YEAR = 4,
    TEN_YEAR = 10
}

/**
 * Password verify status
 * '0' -> Success
 * '1' -> Failure
 */
export enum PasswordVerify {
    SUCCESS = '0',
    FAILURE = '1'
}

/**
 * 本人確認種類
 */
export enum IdentificationCode {
    CODE_80 = '80',
    CODE_90 = '90',
    CODE_99 = '99',
}

/**
 * 本人確認種類
 */
export enum SsnWrite {
    YES = '1',
    NO = '2',
}

/**
 * 本人確認種類
 */
export enum SsnHave {
    YES = '1',
    NO = '2',
}

/**
 * IPAファイルのステータス
 */
export class IPAFileStatus {
    // 正常
    public static readonly SUCCESS = 200;
}

/**
 * IPA URL バージョン置換文
 */
export class IPAUrlReplacedTag {
    // 正常
    public static readonly TAG = '[IPA_Tag]';
}

/**
 * IPA URL バージョン置換文
 */
export class IPAUrlIndexSuffix {
    // インデックス
    public static readonly INDEX = 'index.html';
}

/**
 * Modalコンポーネント種別
 */
export class ModalComponentType {
    public static readonly IPA_DOWNLOAD_URL = 'ipaDownloadUrl';
    public static readonly IMAGE_MASKING = 'imageMasking';
}

export class CardReadStatus {
    // 正常
    public static readonly NORMAL: string = '0';
    // スキャン処理失敗
    public static readonly SCAN_FAILED: string = '-101';
    // 端末接続失敗
    public static readonly DEVICE_CONNECT_FAILED: string = '-201';
    // 端末認証失敗
    public static readonly DEVICE_AUTHENTICATE_FAILED: string = '-301';
    // 端末PowerOn失敗
    public static readonly DEVICE_POWERON_FAILED: string = '-401';
    // データ読み込みコマンド失敗
    public static readonly APDU_COMMAND_FAILED: string = '-501';
}

export class CardInsertStatus {
    // 正常
    public static readonly NORMAL: string = '0';
    // スキャン処理失敗
    public static readonly ABSENT: string = '1';
    // 端末接続失敗
    public static readonly PRESENT: string = '2';
    // 端末認証失敗
    public static readonly POWEROFF: string = '99';
}

export class CardApduCommands {
    // ICカードからICアプリを選ぶ
    public static readonly SELECT_APP: string = '00 A4 04 00 0A D3920010612A0A01 0138 00';
    // 顧客PANを含むデータを読む
    public static readonly READ_PAN: string = '00 B2 01 14 00';
    // GET PROCESSING OPTIONコマンドを発行
    public static readonly GET_PROCESSING_OPTION: string = '80 A8 00 00 03 83 01 03 00';
}

export class CardStatus {
    public static readonly CARD_STATUS_UNKNOW = '0';

    public static readonly CARD_STATUS_ABSENT = '1';

    public static readonly CARD_STATUS_PRESENT = '2';

    public static readonly CARD_STATUS_POWERED = '3';

    public static readonly CARD_STATUS_POWER_SAVING_MODE = '255';
}

/**
 * apduResponseから取得したい項目値のタグを定義する
 *
 * 大文字限定
 *
 * @export
 * @class CardItemTags
 */
export class CardItemTags {
    public static readonly TAG_PAN = '5A';
}

export enum SearchMode {
    ORDINARY = '1',
    ADDRESS_CHANGE = '2',
}

export class ChatComponentType {
    public static readonly fatcaCountry = 'fatcaCountry';
    public static readonly signFatca = 'signFatca';
}

/**
 * 本人確認書類_種類(FrontEnd)
 */
export class IdInfoDocType {
    // 在留カード
    public static readonly TYPE_RESIDENCE_CARD = '01';
    // 特別永住者証明書
    public static readonly TYPE_PERMANENT_RESIDENT = '02';
    // 米軍IDとパスポート
    public static readonly TYPE_US_TROOPS = '03';
}

/**
 * 本人確認書類(BackEnd)
 */
export class IdInfoDoc {
    // 在留カード、特別永住者証明書
    public static readonly TYPE_RESIDENCE_CARD = '06';
    // 米軍IDとパスポート
    public static readonly TYPE_US_TROOPS = '07';
}

/**
 * 書類撮影区分
 */
export class DocShootingStatus {
    // 0：なし
    public static readonly SHOOTING_NO_IMG = '0';
    // 1：勤務先撮影あり
    public static readonly SHOOTING_IMG_OFFICE = '1';
    // 2：通学先撮影あり
    public static readonly SHOOTING_IMG_SCHOOL = '2';
    // 3：通学先・勤務先撮影あり
    public static readonly SHOOTING_IMG_SCHOOL_AND_OFFICE = '3';
}

export enum BusinessCode {
    // 共通
    COMMON = '00',
    // 普通預金口座開設
    SAVING_ACCOUNT = '01',
    // 定期預金のお手続き
    EXISTING_REGULAR = '02',
    // 定期預金のお手続き（振替元口座）
    EXISTING_REGULAR_TRANSFER = '03',
    // 定期預金のお手続き（振替先口座）
    EXISTING_REGULAR_DEPOSIT = '04',
    /** 定期預金のお手続き（解約） */
    EXISTING_CANCEL = '06',
    /** クレカ発行(CIF) */
    BC_APPLY = '29',
    /** クレカ発行(口座) */
    BC_APPLY_ACCOUNT = '12',
    /** クレカ発行(複合) */
    BC_COMPLEX_APPLY = '18',
    /** 相続（相続人） */
    INHERIT = '13',
    /** 相続（被相続人）のお手続き（名寄せ時） */
    INHERIT_DUPLICATE = '15',
    /** 業務共通のNGチェック */
    COMMON_NG = '22',
    /** 再発行・発見 */
    LOSS_REISSUE_FINDING = '23',
    // 届出事項変更（氏名変更メニュー選択時）
    NAME_MENU_CHANGE = '19',
    // 届出事項変更（氏名変更を含まない住所変更・電話番号変更メニュー選択時）
    ADDRESS_TEL_MENU_CHANGE = '24',
    // 手入力カード認証
    MANUAL_CARD_AUTHENTICATION = '20',
    // カード差替
    CARD_REPLACEMENT = '39',
    // カード新規発行
    CARD_NEWEST = '45'
}

export enum ApplyBizCategory {
    // 普通預金口座開設（日本国籍）
    JAPANESE_NATIONALITY = '01',
    // 普通預金口座開設（外国籍）
    FOREIGN_NATIONALITY = '04',
}

export enum OutStatus {
    ON = '1',           // 該当あり
    OFF = '0'           // 該当なし
}

export enum OutStatusText {
    ON = 'B',           // 該当あり
    OFF = 'A'           // 該当なし
}

export enum CountryCode {
    American = '0600',
    Japan = '0100',
}

export enum AmericanLive {
    YES = '4',
    NO = '1'
}

export enum HostResultCode {
    REENTER = 'A',  // A：業務エラー（顧客再入力）
    SUPPORT = 'B',  // B：業務エラー（行員サポート）
    IGNORE = 'C',   // C：業務エラー（無視）
    SYSERR = 'D',   // D：システムエラー
    SUCCESS = 'Z',  // Z：正常
    RECEPTION_GET_ERROR = 'G_S',  // G_S：受付エラー
}

export enum HostErrorCode {
    B_STR_006 = 'B-STR-006'
}

/**
 * 受付可否チェックでNGとするエラーコード
 */
export enum HostErrorCodeReceptionNG {
    B_STR_004 = 'B-STR-004', // 業務コードエラー
    B_STR_005 = 'B-STR-005', // 人格コードエラー
    B_STR_006 = 'B-STR-006', // 事故取引禁止注意コードエラー
    B_STR_007 = 'B-STR-007', // 電話番号エラー
    B_STR_008 = 'B-STR-008', // 国籍エラー
    B_STR_017 = 'B-STR-017', // 漢字印字不可設定あり
    B_STR_020 = 'B-STR-020', // 入力項目エラー
    B_STR_021 = 'B-STR-021', // 基準期間経過後取引先
    B_STR_026 = 'B-STR-026', // 生年月日未登録エラー
    B_STR_027 = 'B-STR-027', // 性別コード未登録エラー
    B_STR_999 = 'B-STR-999', // 上記以外のエラー
}

export enum InheritAccountInquiryResult {
    Success = 0,
    Fail = 1
}

export enum UnacceptableInfo {
    UNACCEPTABLE_CODE_101 = '101',
    UNACCEPTABLE_NAME_101 = '本人死亡'
}

export enum InheritCustomerStatus {
    CUSTOMER_STATUS_01 = '01',
    CUSTOMER_STATUS_02 = '02',
    CUSTOMER_STATUS_03 = '03'
}

export enum AntiSocietyAnswer {
    YES = '1',  // 「はい」の値
    NO = '2'    // 「いいえ」の値
}

export enum AcceptCheckKeyType {
    ACCOUNT = '1',  // 口座番号
    CUSTOMERID = '2'    // 顧客番号
}

export enum BusinessCode {
    OPEN_BANK_CARD = 12
}
// 相続人代表者フラグ
export enum RepresentativeFlg {
    No = '0',  // 0:来店者が相続人代表でない
    YES = '1'    // 1:来店者が相続人代表である
}

// 受付票起票店（本部店番店名）
export enum InputReceptionBranchNumber {
    HeadquartersNumber = '100',  // 本部店番
    HeadquartersName = '本部',  // 本部店番名
    InheritSupportCenterNumber = '162',  // 相続SC店番
    InheritSupportCenterName = '相続サポートセンター'  // 相続SC店名
}

/**
 * 追加で撮影しますか
 */
export enum AddCarema {
    YES = '1', // はい
    N0 = '0'   // いいえ
}

/**
 * 同一人確認
 */
export enum SameProperties {
    YES = '1', // はい
    NO = '0'   // いいえ
}

// 郵便不着フラグの解除
export class UnsetNonDeliveryStatus {
    public static readonly SET_STATUS = '1';
}

// カード保有有無
export class CardHoldingStatus {
    public static readonly CARD_HOLDING_STATUS_NO = '0';
    public static readonly CARD_HOLDING_STATUS_YES = '1';
}

export enum EstimatedPaymentStatus {
    OK = '0',  // 0:概算支払可
    NG_DETAILS_OVER = '1',  // 1：概算支払不可-支払明細数超過
    NG_PRICE_OVER = '2',  // 2：概算支払不可-金額階層跨り
}

/**
 * 年収
 */
export enum Income {
    // 100万
    Income_100 = 100,
    // 150万
    Income_150 = 150,
    // 300万
    Income_300 = 300,
}

/**
 * 10進数
 */
export enum Decimal {
    // 10進数
    Decimal_10 = 10,
}

export class AcceptCheck {
    public static readonly EXIST = 'exist';
    public static readonly NOT_EXIST = 'notExist';
    public static readonly ALL_EXIST = 'allExist';
}

export enum MaskingCheckboxName {
    MASKING_CHECKBOX_NAME = 'isAllMaskingStatus',
    STUDENT_CHECKBOX_NAME = 'isStudentMaskingStatus',
    AGENT_MASKING_CHECKBOX_NAME = 'isAgentAllMaskingStatus'
}

/**
 * 番地以降の最大桁数
 */
export enum AddressMaxLengthArr {
    holderAddressStreetNameInput = 83,
    holderAddressHouseNumber = 84,
    applicantAddressStreetNameInput = 83,
    applicantAddressHouseNumber = 84,
    representativeHeirAddressStreetNameInput = 83,
    representativeHeirAddressHouseNumber = 84,
    ancestorAddressStreetNameInput = 83,
    ancestorAddressHouseNumber = 84
}

// 受付状態
export class ReceptionStatus {
    // 受付不可
    public static readonly NO = '1';
    // 受付可能
    public static readonly YES = '0';
}

export class JudgeResultStatus {
    public static readonly RESULT_0 = '0';
    public static readonly RESULT_1 = '1';
    public static readonly RESULT_2 = '2';
    public static readonly RESULT_3 = '3';
}

/**
 * 届出事項の変更選択時のパラメーター
 */
export class SelectChangeParam {
    public static readonly ACCOUNT_TYPE = '8';
    public static readonly APPLY_BIZ_CATEGORY = '03';
    public static readonly BUSINESS_CODE = '05';
}

/**
 * カード分類
 */
export class CardClass {
    // キャッシュカード
    public static readonly CASH_CARD = '1';
    // ローンカード
    public static readonly LOAN_CARD = '2';
    // バンクカード
    public static readonly BANK_CARD = '3';
}

/**
 * カード種類
 */
export class CardType {
    // キャッシュカード
    public static readonly CASH_CARD = '01';
    // キャッシュカード(キャラクター)
    public static readonly CHAS_CARD_CHARACTER = '02';
    // ICキャッシュカード
    public static readonly IC_CASH_CARD = '03';
    // ワンセットカード
    public static readonly ONE_SET_CARD = '04';
    // 競馬カード
    public static readonly HORSE_RACE_CARD = '05';
    // フォトIDカード
    public static readonly PHOTO_ID_CARD = '06';
    // 貯蓄預金カード
    public static readonly DEPOSIT_CARD = '21';
    // 貯蓄預金カード(キャラクター)
    public static readonly DEPOSIT_CARD_CHARACTER = '22';
    // IC貯蓄預金カード
    public static readonly IC_DEPOSIT_CARD = '23';
    // マイタウンカード
    public static readonly MY_TOWN_CARD = '76';

    // カードローンカード
    public static readonly CARD_LOAN_CARD = '31';

    // 横浜バンクカードVISA
    public static readonly BC_VISA = '41';
    // 横浜バンクカードMastercard
    public static readonly BC_MASTERCARD = '42';
    // バンクカードSuica
    public static readonly BC_SUICA = '43';
    // バンクカードヤングゴールドVISA
    public static readonly BC_YOUNG_GOLD_VISA = '51';
    // バンクカードヤングゴールドSUICA
    public static readonly BC_YOUNG_GOLD_SUICA = '53';
    // バンクカードゴールド
    public static readonly BC_GOLD = '61';
    // バンクカードゴールドSUICA
    public static readonly BC_SUICA_GOLD = '63';
}

/**
 * チャットフロー上で「続ける」と「申込内容確認へ戻る」ボタンの値にマッピング
 */
export enum ContinueOrBackToConfirm {
    CONTINUE = '1',
    BACK_TO_CONFIRM = '0'
}

/**
 * 本人確認書類コード
 */
export enum IdentificationDocumentCode {
    // その他官公庁から発行された書類（写真付）
    OTHER_IDENTIFICATION_DOCUMENT = '09',
    // パスポート（所持人記入欄なし）
    PASSPORT_WITHOUT_SELF_INPUT = '26',
    // 国税・地方税・公共料金の領収書
    NATIONAL_RURAL_PUBLIC_RECEIPT = '27',
    // その他官公庁から発行された書類（顔写真なし）
    OTHER_IDENTIFICATION_NO_PHOTO_DOCUMENT = '17'
}

/**
 * 本人確認書類方法
 */
export enum IdentificationDocumentMethod {
    // １種類提示
    PRESENT_ONE_TYPE = '01',
    // 提示＋現住所確認
    PRESENT_ONE_ADDRESS_TYPE = '04'
}

/**
 * 運転経歴証明書を持っている
 */
export enum HasDriversCareerLicense {
    YES = '1',
    NO = '0'
}

export enum StoreChanged {
    YES = '1'
}

export enum ClearChangeImagesClickRecordType {
    ALL = '0',
    CHANGE_DOCUMENT = '1',
    NAME_IDENTITY = '2',
    CLEAR = '3',
    ADD_IDENTITY = '4'
}

export enum ClearSavingImagesClickRecordType {
    DOCUMENT = '1',
    CLEAR = '3',
    DOCUMENT_1 = '10',
    DOCUMENT_2 = '20',
}

/**
 * 通帳必要かどうか
 *
 * @export
 * @enum {number}
 */
export enum IsNeedPassBookType {
    YES = '1', // 通帳が必要
    NO = '0' // 通帳がいらない
}

export enum ClearWorkOrCrs {
    WORK = '1', // 通帳が必要
    CRS = '0' // 通帳がいらない
}

/**
 * BC申込
 */
export enum ApplyBC {
    YES = '01',
    NO = '00'
}

/**
 * BC保有有無
 */
export enum HasBankCard {
    YES = '1'
}

/**
 * 専門家案内要否
 */
export enum ExpertIntroductionNecessity {
    NoIntroduce = '紹介不要',
    NeedIntroduce = '紹介要',
    NeedContact = '連絡希望',
    NoContact = '希望しない',
    NeedManual = 'パンフレット送付',
}

/**
 * 反社に該当しないことの同意
 */
export class NotAntisocialForceConsent {
    // 同意
    public static readonly Agree = '1';
}
/**
 * 届出事項変更区分
 */
export enum CHANGECATEGORY {
    CHANGE = '1',
    NOTCHANGE = '0',
}

/**
 * 取引時確認要否
 */
export enum IDENTIFICATIONCATEGORY {
    YES = '1',
    NO = '0',
}

/**
 * ワンセットカード保有有無
 */
export enum ONESETSTATUS {
    HAVE = '1',
    NOTHAVE = '0',
}

/**
 * カード利用停止
 */
export class CardUsageLimitation {
    // カード利用停止有
    public static readonly YES = '1';
}

/**
 * 普通口座開設区分
 */
export class AccountCategory {
    // 普通口座開設の取引要
    public static readonly YES = '1';
    // 普通口座開設の取引不要
    public static readonly NO = '0';
}

/**
 * 日本のみ居住フラグ
 */
export class ResidenceFlagJapanOnly {
    public static readonly YES = '1';
    public static readonly NO = '0';
}

/**
 * カード事故注意情報
 */
export class CardUnacceptableInfo {
    // カード喪失表示
    public static readonly LOSS_CARD_STATUS_YES = '1';
    // カード盗難表示
    public static readonly THEFT_CARD_STATUS_YES = '1';

}

/** IB契約情報　契約区分 */
export enum ContractCategory {
    /** 代表口座 */
    primary = '1',
    /** 関連口座 */
    relation = '2'
}

/** IB契約情報　サービス利用区分 */
export enum ServiceCategory {
    /** TBのみ */
    TB_ONLY = '0',
    /** IB契約 */
    IB = '1',
    /** TB/IB/MB */
    TB_IB_MB = '2'
}

/**
 * AGENT内部エラー
 */
export class AgentInternalError {
    /** 全店名寄せ顧客件数超過エラー */
    public static readonly ERROR_CODE_N_001 = 'N-001';
    /** 全店名寄せ国籍相違エラー */
    public static readonly ERROR_CODE_N_002 = 'N-002';
    /** 全店名寄せ外国籍漢字氏名未登録エラー */
    public static readonly ERROR_CODE_N_003 = 'N-003';
    /** 全店名寄せ二重CIFエラー */
    public static readonly ERROR_CODE_N_004 = 'N-004';
    /** 氏名および補助住所に変換不可文字があるため差分変更不可 */
    public static readonly ERROR_CODE_N_005 = 'N-005';
    /** 住所コード該当なしエラー */
    public static readonly ERROR_CODE_N_006 = 'N-006';
    /** 全店名寄せIB/TB契約状況エラー */
    public static readonly ERROR_CODE_N_007 = 'N-007';
    /** IB/TB契約、媒体事故残存エラー */
    public static readonly ERROR_CODE_N_008 = 'N-008';
    /** BC延滞ありエラー */
    public static readonly ERROR_CODE_N_009 = 'N-009';
    /** PID配下に一括与信停止ありエラー */
    public static readonly ERROR_CODE_N_010 = 'N-010';
    /** 個人以外受付対象外 */
    public static readonly ERROR_CODE_N_011 = 'N-011';
    /** 個人・個人事業主以外受付対象外 */
    public static readonly ERROR_CODE_N_012 = 'N-012';
    /** 証書式受付対象外 */
    public static readonly ERROR_CODE_N_013 = 'N-013';
    /** 活動／休眠・雑益混在は受付対象外 */
    public static readonly ERROR_CODE_N_014 = 'N-014';
    /** 雑益／休眠混在は受付対象外 */
    public static readonly ERROR_CODE_N_015 = 'N-015';
    /** 課税コード受付対象外 */
    public static readonly ERROR_CODE_N_016 = 'N-016';
    /** 金額がゼロ円受付対象外 */
    public static readonly ERROR_CODE_N_017 = 'N-017';
    /** 支払済のため受付対象外 */
    public static readonly ERROR_CODE_N_018 = 'N-018';
    /** 商品コード受付対象外 */
    public static readonly ERROR_CODE_N_019 = 'N-019';
    /** リーフ口／媒体不発行　受付対象外 */
    public static readonly ERROR_CODE_N_020 = 'N-020';
    /** 通帳種類受付対象外 */
    public static readonly ERROR_CODE_N_021 = 'N-021';
    /** カード種類受付対象外 */
    public static readonly ERROR_CODE_N_022 = 'N-022';
    /** 便宜扱い有り */
    public static readonly ERROR_CODE_N_023 = 'N-023';
    /** 振替口番種類コード受付対象外 */
    public static readonly ERROR_CODE_N_024 = 'N-024';
    /** リスク商品の代金受払口座 */
    public static readonly ERROR_CODE_N_025 = 'N-025';
    /** 集金収納契約あり */
    public static readonly ERROR_CODE_N_026 = 'N-026';
    /** ANSER契約あり */
    public static readonly ERROR_CODE_N_027 = 'N-027';
    /** FB契約あり */
    public static readonly ERROR_CODE_N_028 = 'N-028';
    /** 手数料後納契約あり */
    public static readonly ERROR_CODE_N_029 = 'N-029';
    /** 資金化未確定の他店券あり */
    public static readonly ERROR_CODE_N_030 = 'N-030';
    /** 未収普通貸越利息あり */
    public static readonly ERROR_CODE_N_031 = 'N-031';
    /** 融資残高あり */
    public static readonly ERROR_CODE_N_032 = 'N-032';
    /** 普通貸越契約あり */
    public static readonly ERROR_CODE_N_033 = 'N-033';
    /** 残高エラー */
    public static readonly ERROR_CODE_N_034 = 'N-034';
    /** 科目コードエラー */
    public static readonly ERROR_CODE_N_035 = 'N-035';
    /** その他エラー */
    public static readonly ERROR_CODE_N_036 = 'N-036';
    /** 雑益繰入取消/不活動繰入取消済みは受付対象外 */
    public static readonly ERROR_CODE_N_037 = 'N-037';
    /** 投信指定口座先は受付対象外 */
    public static readonly ERROR_CODE_N_038 = 'N-038';
    /** 通貨複数保有先は受付対象外 */
    public static readonly ERROR_CODE_N_039 = 'N-039';
    /** ステータス保有なしは受付対象外 */
    public static readonly ERROR_CODE_N_044 = 'N-044';
    /** 解約/移管/取消済混在は受付対象外 */
    public static readonly ERROR_CODE_N_045 = 'N-045';
    /** 雑益処理時、異例対応先 */
    public static readonly ERROR_CODE_N_042 = 'N-042';
    /** 大量明細保有先（26明細以上保有） */
    public static readonly ERROR_CODE_N_046 = 'N-046';
    /** 振込先店番号該当なし */
    public static readonly ERROR_CODE_N_047 = 'N-047';
    /** スワイプしたカードがPID配下になし */
    public static readonly ERROR_CODE_N_043 = 'N-043';
    /** 発行規制期間該当可能性あり */
    public static readonly ERROR_CODE_N_048 = 'N-048';
    /** 更新エラー先の可能性あり */
    public static readonly ERROR_CODE_N_049 = 'N-049';
    /** CIF情報国籍相違エラー */
    public static readonly ERROR_CODE_N_050 = 'N-050';
    /** 本人確認コード受付対象外 */
    public static readonly ERROR_CODE_N_051 = 'N-051';
}

/**
 * 回答値(Y/N)
 */
export enum YesNoAnswer {
    YES = 'Y',
    NO = 'N',
}

/**
 * 金融機関種類
 */
export enum BankCategory {
    /** すべて */
    All = '00',
    /** 銀行 */
    Bank = '01',
    /** 信用金庫 */
    ShinkinBank = '02',
    /** 信用組合 */
    CreditUnion = '03',
    /** 労働金庫 */
    LaborBank = '04',
    /** 農協・漁協 */
    Cooperative = '05',
}

export enum ProductCode {
    OrdinaryDeposit = '2101'
}

export enum IsModifyJudge {
    // 修正チャット
    IsModify = '1',
    // 本チャット
    IsNotModify = '2'
}

export enum ReferenceFlg {
    Confrim = '0'
}

export enum NoSwipeFlag {
    ON = '1'
}

export enum InputByKanaOrAlphabet {
    Kana = 'かな入力',
    Alphabet = '英数字入力'
}

/**
 * 国名
 * 国籍pickerのデフォルト値に使用
 */
export enum CountryName {
    /** 日本 */
    JAPAN = '日本',
    /** アメリカ合衆国 */
    USA = 'アメリカ合衆国'
}

/**
 * 融資保有明細有無フラグ
 */
export class HasLoanAccountHoldingDetails {
    /** 保有あり */
    public static readonly YES = '1';
    /** 保有なし */
    public static readonly NO = '0';
}
