import { NgModule } from '@angular/core';
import { LoginAction } from 'dhdt/branch/pages/common/login/action/login.action';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { LoginComponent } from 'dhdt/branch/pages/common/login/view/login.component';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { Config } from 'ionic-angular';
import { IonicModule } from 'ionic-angular/module';

@NgModule({
    declarations: [
        LoginComponent
    ],
    imports: [
        IonicModule,
        SharedModule
    ],
    exports: [
        LoginComponent,
    ],
    entryComponents: [
        LoginComponent
    ],
    providers: [
        LoginAction,
        LoginStore
    ]
})
export class LoginModule {
    constructor(private config: Config) {
        this.config.set('hideCaretOnScroll', false);
    }
}
