import { Injectable } from '@angular/core';
import { Action } from 'adep/flux';
import { API_URL } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { HttpService } from 'dhdt/branch/shared/services/http.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';

// Action type
export const LoginActionType = {
    LOGIN_ACTION_TYPE_LOGIN: 'LoginActionType_LOGIN',
    SET_SYSTEM_TIME: 'LoginActionType_SET_SYSTEM_TIME',
    GET_API_VERSION: 'LoginActionType_GET_API_VERSION',
    GET_BRANCH_INFO_ADDRESS: 'LoginActionType_GET_BRANCH_INFO_ADDRESS',
    SET_STATE_INFO: 'LoginActionType_SET_STATE_INFO',
    SET_CLERK_INFO: 'LoginActionType_SET_CLERK_INFO',
    SAVE_TABLET_APPLY_ID: 'LoginActionType_SAVE_TABLET_APPLY_ID',
    GET_IPA_DOWNLOAD_URL: 'LoginActionType_GET_IPA_DOWNLOAD_URL',
    CARD_READER_DEVICE_ID: 'LoginActionType_CARD_READER_DEVICE_ID'
};

@Injectable()
export class LoginAction extends Action {

    constructor(
        private httpService: HttpService,
        public loggingService: LoggingService) {
        super();
    }

    public login(params: any) {
        this.operationLogging({
            screenName: params.screenName,
            value: params.value
        });
        this.httpService.post('auth/login', params).subscribe((response) => {
            this.httpService.setAuthToken(response.result.authToken);
            this.dispatcher.dispatch({
                actionType: LoginActionType.LOGIN_ACTION_TYPE_LOGIN,
                data: {...response.result, cardReaderDeviceId: params.cardReaderDeviceId}
            });
        });
    }

    /**
     * ICカードリーダーの端末IDを取得する
     *
     * @memberof LoginAction
     */
    public getCardReaderDeviceId() {
        this.httpService.post(API_URL.CARD_READER_DEIVCE_ID, undefined).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: LoginActionType.CARD_READER_DEVICE_ID,
                data: response.result
            });
        });
    }

    /**
     * set the item value as the current time of server
     * @param key the checbox item need to modify status
     */
    public setAsSystemTime(key: string) {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: LoginActionType.SET_SYSTEM_TIME,
                data: {
                    key: key,
                    systemTime: response.result.value
                }
            });
        });
    }

    public saveTabletApplyId(tabletApplyId: string) {
        this.httpService.setTabletApplyId(tabletApplyId);
        this.dispatcher.dispatch({
            actionType: LoginActionType.SAVE_TABLET_APPLY_ID,
            data: tabletApplyId
        });
    }

    public errorLogging(params: any) {
        this.loggingService.log(this.loggingService.generalErrorParams(params.eventType, params.eventValue));
    }

    public operationLogging(params: any) {
        this.loggingService.log(this.loggingService.generalOperationParams(params));
    }

    public resetLogginIndex() {
        this.loggingService.resetLogginIndex();
    }

    /**
     * branch.apiのバージョンを取得する
     */
    public getApiVersion() {
        this.httpService.getApiVersion(API_URL.GET_API_VERSION).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: LoginActionType.GET_API_VERSION,
                data: {
                    version: response.version
                }
            });
        });
    }

    public getBranchInfoAddress(params: any) {
        this.httpService.post('branch-info/tablet-info/address-get', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: LoginActionType.GET_BRANCH_INFO_ADDRESS,
                data: response.result
            });
        });
    }

    public setStateInfo(data: any) {
        this.dispatcher.dispatch({
            actionType: LoginActionType.SET_STATE_INFO,
            data: data
        });
    }

    public setClerkInfo(params) {
        this.dispatcher.dispatch({
            actionType: LoginActionType.SET_CLERK_INFO,
            data: params
        });
    }

    /**
     * IPAのダウンロードURLが有効であるかどうかをチェックする
     * @param ipaDownloadUrl IPAのダウンロードURL
     */
    public isValidIPADownloadUrl(ipaDownloadUrl: string) {
        this.httpService.getIPAFileStatus(ipaDownloadUrl).subscribe((status) => {
            this.dispatcher.dispatch({
                actionType: LoginActionType.GET_IPA_DOWNLOAD_URL,
                data: {
                    status: status
                }
            });
        });
    }
}
