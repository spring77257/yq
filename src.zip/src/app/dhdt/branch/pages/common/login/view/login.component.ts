import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { BaseComponent } from 'adep/components';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import { ApplyDate, Constants, IPAFileStatus } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginAction } from 'dhdt/branch/pages/common/login/action/login.action';
import { LoginSignal, LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { CardService } from 'dhdt/branch/shared/services/card.service';
import { HttpService } from 'dhdt/branch/shared/services/http.service';
import { IPADownloadUrlService } from 'dhdt/branch/shared/services/ipa-download-url.service';
import { LicenseService } from 'dhdt/branch/shared/services/license.service';
import { LoggingService, TabletApplyIdKey } from 'dhdt/branch/shared/services/logging.service';
import { validator_equalLength, validator_lettersAndNumbers } from 'dhdt/branch/shared/validators/common.validator';
import { NavController } from 'ionic-angular';
import { Platform } from 'ionic-angular/platform/platform';
import { Observable } from 'rxjs';
import { interval } from 'rxjs/observable/interval';
import { merge, take } from 'rxjs/operators';
declare let cordova: any;

@Component({
    selector: 'login-component',
    templateUrl: 'login.component.html'
})

/**
 * Login component(ログイン画面).
 */
export class LoginComponent extends BaseComponent implements OnInit {
    @ViewChild('userId') public input;

    // error message
    public userIDErrorMessage = '';
    public deviceIDErrorMessage = '';
    public passwordErrorMessage = '';

    // form
    public loginFormGroup: FormGroup;
    public userIDControl: FormControl;
    public passwordControl: FormControl;
    public deviceIdControl: FormControl;

    // error show
    public userIDErrorShow = false;
    public passwordErrorShow = false;
    public deviceIdErrorShow = false;

    // ログイン button タン押下時の二重リクエスト防止
    public isLanding = false;

    // IPAダウンロードボタン活性、非活性制御
    public canBeSetActivicated = false;
    // LoginStateをHTMLとバインディング
    public state: LoginState;

    // IPAファイルのバージョン
    private ipaVersion = '';

    // branch.apiのバージョン
    private apiVersion = '';

    // IOS バンドル ID
    private iosBundleId = '';

    private readonly connectFailedSignal = 'NotConnectDevice';

    constructor(
        public navCtrl: NavController,
        private action: LoginAction,
        private store: LoginStore,
        private deviceService: DeviceService,
        private loggingService: LoggingService,
        private platform: Platform,
        private cardService: CardService,
        private ipaADownloadUrlService: IPADownloadUrlService,
        private liceneseService: LicenseService,
        private httpService: HttpService
    ) {
        super();
    }

    public ngOnInit(): void {
        // init
        this.state = this.store.getState();
        this.deviceService.subject.subscribe(
            (status) => {
                if (status) {
                    // DeviceSericeの初期化完了時にipad名をhttpServiceに保存
                    this.httpService.setDeviceName(this.deviceService.getDeviceName());
                    this.action.getCardReaderDeviceId();
                }
            }
        );
        // create form
        const fb = new FormBuilder();
        this.loginFormGroup = fb.group({
            userID: ['', [Validators.required, validator_lettersAndNumbers, validator_equalLength(8)]],
            deviceId: ['', [Validators.required, validator_lettersAndNumbers]],
            password: ['', [Validators.required, Validators.maxLength(255), Validators.minLength(8), validator_lettersAndNumbers]]
        });

        // subscribe the input valuechange
        this.userIDControl = this.loginFormGroup.get('userID') as FormControl;
        this.deviceIdControl = this.loginFormGroup.get('deviceId') as FormControl;
        this.passwordControl = this.loginFormGroup.get('password') as FormControl;
        this.userIDControl.valueChanges.subscribe(
            (value) => {
                this.userIDErrorShow = false;
            }
        );
        this.deviceIdControl.valueChanges.subscribe(
            (value) => {
                this.deviceIdErrorShow = false;
            }
        );
        this.passwordControl.valueChanges.subscribe(
            (value) => {
                this.passwordErrorShow = false;
            }
        );

        // subscribe success signal from store
        this.store.registerSignalHandler(LoginSignal.LOGIN_COMPLETE, () => {
            const flag = this.store.getState().flag;
            switch (flag) {
                case '0':
                    this.action.setAsSystemTime(ApplyDate.APPLY_DATE);

                    this.store.registerSignalHandler(LoginSignal.GET_BRANCH_INFO_ADDRESS, () => {
                        this.navCtrl.setRoot(TopComponent);
                    });

                    this.action.getBranchInfoAddress({
                        branchNo: this.store.getState().belongToBranchNo
                    });
                    break;
                case '1':
                    this.userIDErrorShow = true;
                    this.isLanding = false;
                    this.userIDErrorMessage = this._labels.login.loginErrorMessage.userIDHasError;
                    this.action.errorLogging({
                        eventType: this._labels.logging.UserLogin.ObjectName,
                        eventValue: this._labels.login.loginErrorMessage.userIDHasError
                    });
                    break;
                case '2':
                    this.passwordErrorShow = true;
                    this.isLanding = false;
                    this.passwordErrorMessage = this._labels.login.loginErrorMessage.passwordHasError;
                    this.action.errorLogging({
                        eventType: this._labels.logging.UserLogin.ObjectName,
                        eventValue: this._labels.login.loginErrorMessage.passwordHasError
                    });
                    break;
                default:
                    break;
            }
        });

        this.store.registerSignalHandler(LoginSignal.GET_API_VERSION, () => {
            this.apiVersion = this.store.getState().version;
        });

        this.action.resetLogginIndex();
        setTimeout(() => {
            this.input.setFocus();
        }, 1500);

        setTimeout(() => {
            // 初期化ICカードリーダー
            this.cardService.initOnceTime();
            // ログイン画面が表示するときに、カメラの使用権限を求める
            // 既に許可された場合は何もしない
            this.liceneseService.authorizeCamera();
        });

        this.action.getApiVersion();
        // IPAバージョン取得
        if (this.platform.is('cordova')) {
            this.platform.ready().then(() => {
                cordova.getAppVersion.getVersionNumber().then(
                    (res) => {
                        this.ipaVersion = res;
                    }
                );
                cordova.getAppVersion.getPackageName().then(
                    (res) => {
                        this.iosBundleId = res;
                        // 新IPAあるかどうかチェック
                        this.showIPADownloadUrlDialogOnInit();
                    }
                );
            });
        }

        // ログに格納されたTabletApplyIdを消除
        Reflect.deleteProperty(this.loggingService, TabletApplyIdKey);
    }

    // login button
    public loginClick() {
        this.isLanding = true;
        this.userIDErrorShow = false;
        this.passwordErrorShow = false;
        // フロント側のエラーチェック
        if (this.loginFormGroup.valid) {
            // 端末IDが’NOT’の場合はICカードリーダー接続不要です
            if (this.deviceIdControl.value.toUpperCase() === Constants.NO_CARD_READER) {
                this.login();
            } else {
                // CardReaderと接続
                this.connectCardReaderDevice(this.deviceIdControl.value).subscribe(
                    (data) => {
                        if (data === this.connectFailedSignal) {
                            // 接続失敗したらエラーを表示
                            this.deviceIdErrorShow = true;
                            this.isLanding = false;
                            this.deviceIDErrorMessage = this._labels.login.loginErrorMessage.canNotConnectCardReader;
                            this.action.errorLogging({
                                eventType: this._labels.logging.UserLogin.ObjectName,
                                eventValue: this._labels.login.loginErrorMessage.canNotConnectCardReader
                            });
                        } else {
                            // 接続成功したらログインする
                            this.login();
                        }

                    }
                );
            }
        } else {
            this.isLanding = false;
            if (this.userIDControl.invalid) {
                this.userIDErrorShow = true;
                this.userIDErrorMessage = this._labels.login.loginErrorMessage.userIDHasError;
            } else if (this.passwordControl.invalid) {
                this.passwordErrorShow = true;
                this.passwordErrorMessage = this._labels.login.loginErrorMessage.passwordHasError;
            } else if (this.deviceIdControl.invalid) {
                this.deviceIdErrorShow = true;
                this.deviceIDErrorMessage = this._labels.login.loginErrorMessage.deviceIDHasError;
            }
        }
    }

    /**
     * IPA URL表示ダイアログを呼び出す.
     */
    public showIPADownloadUrlDialog() {
        if (this.ipaADownloadUrlService.isNeedToUpdate(this.ipaVersion)) {
            this.store.unregisterSignalHandler(LoginSignal.GET_IPA_FILE_STATUS);
            this.store.registerSignalHandler(LoginSignal.GET_IPA_FILE_STATUS, (status) => {
                this.canBeSetActivicated = false;
                this.ipaADownloadUrlService.showNeedUpdateIPADialog(status, this.ipaVersion, this.iosBundleId);
            });
            this.canBeSetActivicated = true;
            this.action.isValidIPADownloadUrl(this.ipaADownloadUrlService.getIPAResourceUrl(this.iosBundleId));
        } else {
            this.ipaADownloadUrlService.showNotNeedUpdateIPADialog(this.ipaVersion);
        }
    }

    /**
     * ログイン画面が立ち上がる時に、新バージョンかつPlistファイルが用意した場合
     * 自動的にIPAダウンロードダイアログを表示
     *
     * @memberof LoginComponent
     */
    public showIPADownloadUrlDialogOnInit() {
        if (this.ipaADownloadUrlService.isNeedToUpdate(this.ipaVersion)) {
            this.store.unregisterSignalHandler(LoginSignal.GET_IPA_FILE_STATUS);
            this.store.registerSignalHandler(LoginSignal.GET_IPA_FILE_STATUS, (status) => {
                this.canBeSetActivicated = false;
                // Plistが準備できたら、ダウンロードダイアログを表示
                if (IPAFileStatus.SUCCESS === status) {
                    this.ipaADownloadUrlService.showNeedUpdateIPADialog(status, this.ipaVersion, this.iosBundleId);
                }
            });
            this.canBeSetActivicated = true;
            this.action.isValidIPADownloadUrl(this.ipaADownloadUrlService.getIPAResourceUrl(this.iosBundleId));
        }
    }

    public get deviceId() {
        return this.deviceService.getDeviceId();
    }

    public get currentVersion() {
        if (this.apiVersion) {
            return this.ipaVersion + '-' + AppProperties.APP_VERSION
                + '-' + this.apiVersion + '-' + AppProperties.LOGIC_VERSION;
        }

        return this.ipaVersion + '-' + AppProperties.APP_VERSION
            + '-' + AppProperties.LOGIC_VERSION;
    }

    /**
     * * CardServiceを初期化
     * * CardReaderと接続する
     *
     * @private
     * @param {string} deviceId
     * @returns {Observable<string>}
     * @memberof LoginComponent
     */
    private connectCardReaderDevice(deviceId: string): Observable<string> {
        return this.cardService.connectDeviceWithId(deviceId).pipe(
            merge(
                interval(5000).map(() => this.connectFailedSignal)
            ),
            take(1));
    }

    private login() {
        const params = {
            bankclerkId: this.userIDControl.value,
            password: this.passwordControl.value,
            cardReaderDeviceId: this.deviceIdControl.value,
            screenName: this._labels.logging.UserLogin.ScreenName,
            value: this._labels.logging.UserLogin.ObjectName,
            ipadName: this.deviceService.getDeviceName()
        };
        this.action.login(params);
    }

}
