import { Injectable } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { LoginActionType } from 'dhdt/branch/pages/common/login/action/login.action';
import { LoggingService, TabletApplyIdKey } from 'dhdt/branch/shared/services/logging.service';

export interface LoginState extends State {
    clerkInfo: any;
    authToken: string;
    bankclerkKanji: string;
    bankclerkKana: string;
    belongToBranchNo: string;
    belongToBranchName: string;
    flag: string;
    applyDate: string;
    bankclerkId: string;
    receptionTenban: string;
    version: string;
    prefectureKanji: string;
    countyUrbanVillageKanji: string;
    operatorName: undefined;
    authorityInfo: undefined;
    tabletApplyId: string;
    cardReaderDeviceId: string;
}

export const LoginSignal = {
    LOGIN_COMPLETE: 'LOGIN_COMPLETE',
    GET_SERVE_TIME: 'LoginSignal_GET_SERVE_TIME',
    GET_API_VERSION: 'LoginSignal_GET_API_VERSION',
    GET_BRANCH_INFO_ADDRESS: 'LoginSignal_GET_BRANCH_INFO_ADDRESS',
    GET_IPA_FILE_STATUS: 'LoginSignal_GET_IPA_FILE_STATUS'
};

@Injectable()
export class LoginStore extends Store<LoginState> {
    constructor(private loggingService: LoggingService) {
        super();
        this.state = {
            clerkInfo: undefined,
            authToken: undefined,
            bankclerkKanji: undefined,
            bankclerkKana: undefined,
            belongToBranchNo: undefined,
            belongToBranchName: undefined,
            flag: undefined,
            applyDate: undefined,
            bankclerkId: undefined,
            receptionTenban: undefined,
            version: undefined,
            prefectureKanji: undefined,
            countyUrbanVillageKanji: undefined,
            operatorName: undefined,
            authorityInfo: undefined,
            tabletApplyId: undefined,
            cardReaderDeviceId: ''
        };
    }

    @ActionBind(LoginActionType.LOGIN_ACTION_TYPE_LOGIN)
    private login(data: any) {
        this.state.authToken = data.authToken;
        // this.state.bankclerkKanji = data.bankclerkKanji;
        // this.state.bankclerkKana = data.bankclerkKana;
        this.state.belongToBranchNo = data.belongToBranchNo;
        this.state.belongToBranchName = data.belongToBranchName;
        this.state.bankclerkId = data.bankclerkId;
        this.state.receptionTenban = data.receptionTenban;
        this.state.flag = data.flag;
        this.state.cardReaderDeviceId = data.cardReaderDeviceId;
        this.sendSignal(LoginSignal.LOGIN_COMPLETE);
    }

    @ActionBind(LoginActionType.CARD_READER_DEVICE_ID)
    private deviceId(data: any) {
        if (data.cardReaderDeviceId) {
            this.state.cardReaderDeviceId = data.cardReaderDeviceId;
        }
    }

    /**
     * Set the item as the current time of server
     * @param data system time and the key of item
     */
    @ActionBind(LoginActionType.SET_SYSTEM_TIME)
    private setAsSystemTime(data: any) {
        this.state[data.key] = data.systemTime;
        this.sendSignal(LoginSignal.GET_SERVE_TIME);
    }

    /**
     * branch.apiのバージョンを設定する
     * @param data Apiバージョン情報
     */
    @ActionBind(LoginActionType.GET_API_VERSION)
    private setApiVersion(data: any) {
        this.state.version = data.version;
        this.sendSignal(LoginSignal.GET_API_VERSION);
    }

    /**
     * branch.apiのバージョンを設定する
     * @param data Apiバージョン情報
     */
    @ActionBind(LoginActionType.GET_BRANCH_INFO_ADDRESS)
    private getBranchInfoAddress(data: any) {
        this.state.version = data.version;
        this.state.prefectureKanji = data.prefectureKanji;
        this.state.countyUrbanVillageKanji = data.countyUrbanVillageKanji;
        this.sendSignal(LoginSignal.GET_BRANCH_INFO_ADDRESS);
    }

    /**
     * branch.apiのレスポンスを設定する
     * @param data Apiバージョン情報
     */
    @ActionBind(LoginActionType.SET_STATE_INFO)
    private setStateInfo(data: any) {
        Object.keys(data).forEach((key) => {
            this.state[key] = data[key];
        });
    }

    @ActionBind(LoginActionType.SET_CLERK_INFO)
    private setClerkInfo(data) {
        this.state.clerkInfo = data;
    }

    @ActionBind(LoginActionType.SAVE_TABLET_APPLY_ID)
    private saveTabletApplyId(tabletApplyId: string) {
        Reflect.deleteProperty(this.loggingService, TabletApplyIdKey);
        this.state.tabletApplyId = tabletApplyId;
        Reflect.defineProperty(this.loggingService, TabletApplyIdKey, {
            value: tabletApplyId
        });
    }

    /**
     * IPA ファイルのステータスを取得する
     * @param data IPA ファイルステータス
     */
    @ActionBind(LoginActionType.GET_IPA_DOWNLOAD_URL)
    private getIPAFileStatus(data: any) {
        this.sendSignal(LoginSignal.GET_IPA_FILE_STATUS, data === null ? null : data.status);
    }
}
