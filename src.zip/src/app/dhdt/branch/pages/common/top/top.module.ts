import { NgModule } from '@angular/core';
import { TopAction } from 'dhdt/branch/pages/common/top/action/top.action';
import { TopStore } from 'dhdt/branch/pages/common/top/store/top.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';

@NgModule({
    declarations: [
        TopComponent
    ],
    imports: [
        IonicModule,
        SharedModule
    ],
    exports: [
        TopComponent,
    ],
    entryComponents: [
        TopComponent
    ],
    providers: [
        TopAction,
        TopStore
    ]
})
export class TopModule {
}
