import { Injectable } from '@angular/core';
import { Action } from 'adep/flux';
import { JsonTypeMapper } from 'adep/json/';
import { TopListEntity } from 'dhdt/branch/pages/common/top/entity/top.entity';
import { HttpService } from 'dhdt/branch/shared/services/http.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export namespace TopActionType {
    export const SHOW_INFO: string = 'TopActionType_SHOW_INFO';
}

@Injectable()
export class TopAction extends Action {
    constructor(private http: HttpService, private loggingService: LoggingService) {
        super();
    }

    public retrieveTopInfo() {
        this.http.get('http://www.google.co.jp').subscribe(
            (data) => {
                console.log('test');
            }
        );
        this.dispatcher.dispatch(
            {
                actionType: TopActionType.SHOW_INFO,
                data: JsonTypeMapper.parse(TopListEntity, dummyJson)
            }
        );
    }

    public operationLogging(params: any) {
        this.loggingService.log(this.loggingService.generalOperationParams(params));
    }

    public resetLogginIndex() {
        this.loggingService.resetLogginIndex();
    }

    /**
     * タブレット申込管理情報登録。
     */
    public tabletInfoInsert(params: any): Observable<string> {
        return this.http.post('/branch-info/tabletInfo/insert', params)
            .pipe(
                map((res: any) => res.result)
            );
    }
}

const dummyJson: TopListEntity = {
    teamName: 'supportTeam-A',
    tops: [
        {
            email: 'support@team.com',
            name: 'general support'
        },
        {
            email: 'tech-support@team.com',
            name: 'tech support'
        }
    ]
};
