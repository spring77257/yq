import { animate, state, style, transition, trigger } from '@angular/animations';

/**
 * Top button animation.
 */
export const topButtonAnimation = trigger('topButtonClicked', [
    state('normal', style({ transform: 'scale(1)', opacity: 1 })),
    // state('clicked', style({transform: 'scale(3)', opacity: 0})),
    state('clicked', style({ transform: 'scale(50)', opacity: 0, background: 'white' })),
    // transition('normal => clicked', animate('600ms cubic-bezier(0, .65, .34, .32)')),
    transition('normal => clicked', [
        style({ transform: 'scale(5)', opacity: 0.1, width: 100, height: 100, background: 'rgb(240, 240, 240)' }),
        animate('250ms ease-in')
    ])
]);
