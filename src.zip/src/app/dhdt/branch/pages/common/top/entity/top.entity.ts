import { JsonProperty } from 'adep/json/';

class Top {
    public email: string;
    public name: string;

    constructor() {
        this.email = undefined;
        this.name = undefined;
    }
}

export class TopListEntity {
    public teamName: string;
    @JsonProperty({ clazz: Top })
    public tops: Top[];

    constructor() {
        this.teamName = undefined;
        this.tops = [];
    }
}
