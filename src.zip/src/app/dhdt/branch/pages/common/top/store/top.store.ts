import { Injectable } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { TopActionType } from 'dhdt/branch/pages/common/top/action/top.action';
import { TopListEntity } from 'dhdt/branch/pages/common/top/entity/top.entity';

export interface TopState extends State {
    email: string;
    person: string;
}

@Injectable()
export class TopStore extends Store<TopState> {
    constructor() {
        super();
        this.state = {
            email: undefined,
            person: undefined
        };
    }

    @ActionBind(TopActionType.SHOW_INFO)
    private setContactInfo(data: TopListEntity) {
        const targetTop = data.tops[0];
        this.state.email = targetTop.email;
        this.state.person = targetTop.name;
    }

}
