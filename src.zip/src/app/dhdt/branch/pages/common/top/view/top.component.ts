import { Component } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { DeviceService } from 'dhd/common/services/device.service';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { TabletApplyStatus } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginAction } from 'dhdt/branch/pages/common/login/action/login.action';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopAction } from 'dhdt/branch/pages/common/top/action/top.action';
import { topButtonAnimation } from 'dhdt/branch/pages/common/top/top-button.animation';
import { CardService } from 'dhdt/branch/shared/services/card.service';
import { LoggingService, TabletApplyIdKey } from 'dhdt/branch/shared/services/logging.service';
import { NavController } from 'ionic-angular';

@Component({
    selector: 'page-top',
    templateUrl: 'top.component.html',
    animations: [
        topButtonAnimation
    ]
})

/**
 * Top component(トップ画面).
 */
export class TopComponent extends BaseComponent {
    public topButtonClickedState = this._labels.topPage.clickStatus.unclicked;
    public title = '';
    public needToJump = false;

    // ログインボタン押下時の二重リクエスト防止
    public isStarting = false;

    constructor(
        public navCtrl: NavController,
        private action: TopAction,
        private savingsAction: SavingsAction,
        private cancelAction: CancelAction,
        private loginStore: LoginStore,
        private loginAction: LoginAction,
        private deviceService: DeviceService,
        private cardService: CardService,
        private loggingService: LoggingService
    ) {
        super();
        this.savingsAction.setTabletStartDate();
        this.title = this.labels.topPage.button;

        this.cancelAction.clearStore();
    }

    public pushPage() {
        this.action.tabletInfoInsert({
            deviceId: this.deviceService.getDeviceId(),   // 作成端末ID
            agencyBranchNo: this.loginStore.getState().belongToBranchNo,    // 取次店番
            userMngNo: this.loginStore.getState().bankclerkId,               // 行員ID
            status: TabletApplyStatus.START
        }).subscribe((tabletApplyId: string) => {
            this.isStarting = true;
            this.title = '';
            this.needToJump = true;
            this.cardService.reset();
            this.savingsAction.clearStore();
            this.topButtonClickedState = this._labels.topPage.clickStatus.clicked;

            // tabletApplyIdをloggingServiceに格納する
            if (Reflect.defineProperty(this.loggingService, TabletApplyIdKey, {
                value: tabletApplyId
            })) {
                this.action.operationLogging({
                    screenName: this._labels.logging.Top.ScreenName,
                    value: this._labels.logging.Top.ObjectName,
                });
            }

            this.loginAction.saveTabletApplyId(tabletApplyId);
            this.navCtrl.setRoot(ChatComponent, { tabletApplyId });
        });
    }

}
