import { NgModule } from '@angular/core';
import { ApplyCompletionComponent } from 'dhdt/branch/pages/common/apply-completion/view/apply-completion.component';
import { ModalDigitalModule } from 'dhdt/branch/shared/components/modal/modal-digital/modal-digital.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';

@NgModule({
    declarations: [
        ApplyCompletionComponent
    ],
    imports: [
        IonicModule,
        SharedModule,
        ModalDigitalModule
    ],
    exports: [
        ApplyCompletionComponent
    ],
    entryComponents: [
        ApplyCompletionComponent
    ],
    providers: []
})
export class ApplyCompletionModule {
}
