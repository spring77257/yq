import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { InjectionUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { NavController, NavParams } from 'ionic-angular';

@Component({
    selector: 'apply-completion-component',
    templateUrl: 'apply-completion.component.html'
})

/**
 * Apply completion component(申込完了画面).
 */
export class ApplyCompletionComponent extends BaseComponent implements OnInit {
    protected readonly action: SavingsAction;
    private showByRow: boolean = false;

    constructor(private navCtrl: NavController, private modalService: ModalService, public navParams: NavParams) {
        super();
        this.action = InjectionUtils.injector.get(SavingsAction);
    }

    public ngOnInit() {
        this.action.clearStore();
        this.presentModal();
    }

    public presentModal() {
        const buttonList = [
            { text: this.labels.alert.backToTopBtn, buttonValue: COMMON_CONSTANTS.BACK_TYPE_TOP }
        ];

        this.modalService.showInfoAlert(this.labels.alert.applyCompletionTitle, buttonList, () => {
            this.navCtrl.setRoot(TopComponent);
        },
            null,
            false,
            COMMON_CONSTANTS.CSS_MODAL_W_480
        );
    }
}
