import { Injectable, NgZone } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { LabelService } from 'adep/services';
import { CashCardActionType } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { BusinessType, CashCardType } from 'dhdt/branch/pages/cashcard/cashcard-consts';
import {
    CashCardSubmitEntity,
    DropDownListEntity
} from 'dhdt/branch/pages/cashcard/entity/cashcard-questions.model';
import { COMMON_CONSTANTS, HolderCardTypeCode, SubmitDataKey } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfoInquiryResponseEntity } from 'dhdt/branch/shared/entity/cif-info-inquiry-response.entity';
import {
    ChatFlowMessageInterface,
    ChatFlowMessageWithPageIndexInterface
} from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { CifInformationUtils } from 'dhdt/branch/shared/utils/cif-information-utils';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { Observable } from 'rxjs/Observable';

export interface CashCardState extends State {
    questions: ChatFlowMessageInterface[][];
    showChats: ChatFlowMessageWithPageIndexInterface[];
    showConfirm: ChatFlowMessageWithPageIndexInterface[];
    submitData: CashCardSubmitEntity;
    tabletStartDate: string;
    customerApplyStartDate: string;
    tabletApplyId: number;
    identityDocuments: string[];
    additionalInfoDocuments: string[];
    agentIdentityDocuments: string[];
    agentAdditionalInfoDocuments: string[];
    copySubmitData: CashCardSubmitEntity;
    dropDownList: DropDownListEntity[];
    dropDownListForName: DropDownListEntity[];
    cifInfoInquiryList: CifInfoInquiryResponseEntity[];
    currentFileInfo: any;
}

export const CashCardSignal = {
    SEND_ANSWER: 'SEND_ANSWER',
    GET_QUESTION: 'GET_QUESTION',
    GET_INFO_OCR_COMPLETE: 'GET_INFO_OCR_COMPLETE',
    SUCCESS_VALIDATION: 'SUCCESS_VALIDATION',
    FAILED_VALIDATION: 'FAILED_VALIDATION',
    SUCCESS_INSERT_INFO: 'SUCCESS_INSERT_INFO',
    CHAT_FLOW_COMPELETE: 'CHAT_FLOW_COMPELETE',
    SUCCESS_INSERT_IMAGES_INFO: 'SUCCESS_INSERT_IMAGES_INFO',  // イメージアップロードAPIが正しく実行完了
    SUCCESS_INSERT_TIME_SAVINGS_APPLY: 'SUCCESS_INSERT_TIME_SAVINGS_APPLY',  // イメージアップロードAPIが正しく実行完了

    CANCEL_COMPLETE: 'CANCEL_COMPLETE',
    GET_LIST_COMPLETE: 'GET_LIST_COMPLETE',
    GET_CHECK_ACCOUNT_EXISTING: 'GET_CHECK_ACCOUNT_EXISTING',              // 口座存在チェック結果
    GET_ACCOUNT_BALANCE: 'CashCardSignal_GET_ACCOUNT_BALANCE',
    GET_CIF_INFO: 'CashCardSignal_GET_CIF_INFO',

    GET_PASSWORD_RULE: 'GET_NEW_PASSWORD_RULE',              // 暗証番号ルール適合性チェック結果
    SET_CIF_ACCOUNT_BALANCE_INFO: 'SET_CIF_ACCOUNT_BALANCE_INFO',
    GET_NEXT_CHAT_MESSAGE: 'GET_NEXT_CHAT_MESSAGE',
};

@Injectable()
export class CashCardStore extends Store<CashCardState> {
    private replaceValues: Array<{ key: string, value: string }>;
    private keysArr: any[] = [];

    constructor(private ngZone: NgZone, private labelService: LabelService, private editService: EditService) {
        super();
        this.state = {
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new CashCardSubmitEntity(),
            tabletStartDate: '',
            customerApplyStartDate: '',
            tabletApplyId: -1,
            identityDocuments: [],
            additionalInfoDocuments: [],
            agentIdentityDocuments: [],
            agentAdditionalInfoDocuments: [],
            copySubmitData: null,
            dropDownList: [],
            cifInfoInquiryList: new Array<CifInfoInquiryResponseEntity>(),
            currentFileInfo: {},
            dropDownListForName: [],
        };
    }

    public hasCashCardSwiped(): boolean {
        return (this.state.submitData.accountNo && this.state.submitData.accountNo.length > 0) &&
            (this.state.submitData.accountType && this.state.submitData.accountType.length > 0) &&
            (this.state.submitData.branchNo && this.state.submitData.branchNo.length > 0);
    }

    /*
     * 初発行の場合、
        * 本人カードタイプ　「holderCardType＝0」発行可
        * 本人カード＆家族用カード　「holderCardType＝0 && agentCardType＝0」発行可
        * 家族用カード　「holderCardType＝1 && agentCardType＝0」発行可
     * 初発行以外の場合、
        * 本人カードタイプ　「holderCardType＝1 or 2 or 9」発行可
        * 本人カード＆家族用カード　「holderCardType＝1 or 2 or 9　＆＆　agentCardType＝1 or 2 or 9」発行可
        * 家族用カード　「agentCardType＝1 or 2 or 9」発行可
    */
    public checkCashCardType(): boolean {
        switch (this.state.submitData.cashCardType) {
            case CashCardType.SELF:
                return this.checkSelfCardType();
            case CashCardType.FAMILY:
                return this.checkFamilyCardType(true);
            default:
                return this.checkSelfCardType() && this.checkFamilyCardType();
        }
    }

    /**
     * 口座残高情報
     * @param info 口座残高情報
     */
    @ActionBind(CashCardActionType.GET_ACCOUNT_BALANCE)
    private getAccountBalanceInfo(info) {
        if (info && info.responseList[0]) {
            this.setSubmitData('swipeCardType', info.responseList[0].holderCardType);
            this.setSubmitData('savingAccountType', info.responseList[0].savingAccountType);
            this.setSubmitData('holderCardType', info.responseList[0].holderCardType);
            this.setSubmitData('agentCardType', info.responseList[0].agentCardType);
            this.setSubmitData('holderCardMsIcType', info.responseList[0].holderCardMsIcType);
            this.setSubmitData('agentCardMsIcType', info.responseList[0].agentCardMsIcType);
        }

        this.sendSignal(CashCardSignal.GET_ACCOUNT_BALANCE);
    }

    /**
     * CIF情報照会を行う
     * @param data CIF情報照会
     */
    @ActionBind(CashCardActionType.GET_CIF_INFO)
    private getCifInfo(data) {
        this.setSubmitData('swipeCif', data.branchCif);
        this.settingCifInformation(data.cifInfoInquiryResponse as CifInfoInquiryResponseEntity);
    }

    /**
     * 支店情報を設定する
     * @param params 支店情報
     */
    @ActionBind(CashCardActionType.SET_BRANCH_INFO)
    private setBranchInfo(params: any) {
        this.setSubmitData('branchNameKanji', params.branchNameKanji);
        this.setSubmitData('branchNo', params.branchNo);
    }

    @ActionBind(CashCardActionType.GET_BRANCH_NAME)
    private getBranchName(params: any) {
        this.setSubmitData('branchNameKanji', params.branchName);
        this.setSubmitData('branchKanji', params.branchName);
    }

    /**
     * チャットテンプレートをロードする
     * @param params yamlファイルにかんする情報
     */
    @ActionBind(CashCardActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.saveCurrentYamlInfo(params.fileInfo[0]);

            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(CashCardSignal.GET_QUESTION, params.pageIndex);
        }
    }

    /**
     * タブレット申し込み情報にデータをインサートする
     * @param data タブレット申し込み情報
     */
    @ActionBind(CashCardActionType.BRANCH_STATUS_INSERT)
    private branchStatusInsert(data: any) {
        if (data) {
            this.state.tabletApplyId = data;
            this.setSubmitData('tabletApplyId', data);
        }
    }

    @ActionBind(CashCardActionType.UPLOAD_IMAGE)
    private uploadImage(data: any) {
        if (data) {
            this.sendSignal(CashCardSignal.SUCCESS_INSERT_IMAGES_INFO);
        }
    }

    @ActionBind(CashCardActionType.CLEAR)
    private clearStore() {
        this.keysArr = [];
        this.state = {
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new CashCardSubmitEntity(),
            tabletStartDate: '',
            customerApplyStartDate: '',
            tabletApplyId: -1,
            identityDocuments: [],
            additionalInfoDocuments: [],
            agentIdentityDocuments: [],
            agentAdditionalInfoDocuments: [],
            copySubmitData: null,
            dropDownList: [],
            cifInfoInquiryList: new Array<CifInfoInquiryResponseEntity>(),
            currentFileInfo: {},
            dropDownListForName: [],
        };
    }

    /**
     * 本人確認書類データをクリアする
     */
    @ActionBind(CashCardActionType.CLEAR_DOCUMENTS)
    private clearStoreDocuments() {
        // 本人確認書類をクリアする
        this.state.identityDocuments = [];
        // コピー徴求ができない理由
        this.setSubmitData('holderNoCopyReason', null);
        // 発行元
        this.setSubmitData('holderPublisher', null);
        // 発行日
        this.setSubmitData('holderPublishDate', null);
        // 記号番号
        this.setSubmitData('holderSignNo', null);
    }

    /**
     * 次のステップを取得する
     * @param params 当ステップ情報
     */
    @ActionBind(CashCardActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: { order: number, pageIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .min<ChatFlowMessageInterface>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: this.replaceParams(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                        };
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        this.sendSignal(CashCardSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: this.replaceParams(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                        };
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        this.sendSignal(CashCardSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => { console.log('Outside Done!'); });
        });
    }

    private replaceParams(str: string): string {
        if (str.indexOf('@') === -1) {
            return str;
        }

        this.replaceValues = [
            { key: '@consumptionTax', value: InputUtils.priceChange(this.state.submitData.consumptionTax.toString()) },
        ];

        let result = str;
        this.replaceValues.forEach((element) => {
            if (result.indexOf(element.key) !== -1) {
                result = result.replace(element.key, element.value);
            }
        });

        return result;
    }

    /**
     * チャット内容を編集する
     *
     * @param params チャット情報
     */
    @ActionBind(CashCardActionType.EDIT_CHAT)
    private editChat(params: any) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;

        let i = -1;
        let index = -1;
        this.state.showChats.forEach((message) => {
            i += 1;
            if (message.pageIndex === pageIndex && message.order === order) {
                index = i;
            }
        });

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }

        this.cleanSubmitData(answerOrder);
    }

    /**
     * 回答を設定する
     * @param params 回答
     */
    @ActionBind(CashCardActionType.SET_ANSWER)
    private setAnswer(answer: { order: number, text: string, value: Array<{ key: string, value: string }> }) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        answer.order = this.getTopOrder();
        chat.answer = answer;
        if (answer.value) {
            answer.value.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    /**
     * Submitデータ設定
     *
     * @param data 回答
     */
    @ActionBind(CashCardActionType.SET_STATE_SUBMIT_DATA_VALUE)
    private setStateSubmitDataValue(data: any) {
        if (data) {
            this.setSubmitData(data.name, data.value);
        }
    }

    /**
     * チャットの表示内容をクリアする
     */
    @ActionBind(CashCardActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    // get holderZipCode 郵便番号
    @ActionBind(CashCardActionType.GET_HOLDER_ZIP_CODE)
    private getHolderZipCode(data: any) {
        console.log(data);
        this.setSubmitData('firstZipCode', data.substring(0, 3));
        this.setSubmitData('lastZipCode', data.substring(3, 7));
    }

    @ActionBind(CashCardActionType.VALIDATION_PASSWORD)
    private validationPassword(params: any) {
        if (params.type === 'SUCCESS') {
            this.sendSignal(CashCardSignal.SUCCESS_VALIDATION);
        } else {
            this.sendSignal(CashCardSignal.FAILED_VALIDATION);
        }
    }

    @ActionBind(CashCardActionType.SUBMIT_DATA_BACKUP)
    private submitDataBackup() {
        this.state.copySubmitData = Object.assign(new CashCardSubmitEntity(), this.state.submitData);
    }

    @ActionBind(CashCardActionType.RESET_SUBMIT_DATA)
    private resetSubmitData() {
        this.state.submitData = this.state.copySubmitData;
        this.state.copySubmitData = null;
    }

    @ActionBind(CashCardActionType.RETRIEVE_DROP_LIST)
    private retrieveDropList(data) {
        this.state.dropDownList = data;
    }

    @ActionBind(CashCardActionType.RETRIEVE_DROP_LIST_FOR_NAME)
    private retrieveDropListForName(data) {
        this.state.dropDownListForName = data;
    }

    @ActionBind(CashCardActionType.BRANCH_INFO_INSERT)
    private branchInfoInsert(data) {
        this.sendSignal(CashCardSignal.SUCCESS_INSERT_INFO);
    }

    @ActionBind(CashCardActionType.CHAT_FLOW_COMPELETE)
    private chatFlowCompelete(nextChatName: string) {
        this.sendSignal(CashCardSignal.CHAT_FLOW_COMPELETE, nextChatName);
    }

    @ActionBind(CashCardActionType.RESET_LAST_NODE)
    private resetLastNode(params: { order: number, pageIndex: number }) {
        const lastNode = this.getState().showChats.pop();
        this.getNextChatByAnswer({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    @ActionBind(CashCardActionType.SUBMIT_TIME_SAVING_APPLY_INFO)
    private timeSavingApplyInfoInsert(data) {
        this.sendSignal(CashCardSignal.SUCCESS_INSERT_INFO);
    }

    /**
     * 行員IDを設定する
     * @param bankclerkId 行員ID
     */
    @ActionBind(CashCardActionType.SET_BANKCLERK_ID)
    private setBankclerkId(params: any) {
        this.setSubmitData('userMngNo', params.bankclerkId);
    }

    @ActionBind(CashCardActionType.GET_CONFIRM_PAGE_TEMPLATE)
    private loadConfirmTemplate(params: any) {
        if (params) {
            this.state.questions[params.pageIndex] = params.data;
            this.state.submitData.fileInfo = params.fileInfo;
        }
    }

    /**
     * Reset showChats
     * @param data origin showChats
     */
    @ActionBind(CashCardActionType.RESET_SHOWCHATS)
    private resetShowChats(data: any) {
        this.state.showChats = data.originShowChats;
        if (data.originSubmitData) {
            this.state.submitData = data.originSubmitData;
        }
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param data QRコード受付情報
     */
    @ActionBind(CashCardActionType.SET_SWIPE_INFO)
    private setSwipeInfo(data: any) {
        // QRコードを読み込む場合
        if (data.swipeInfo) {
            switch (data.swipeInfo.purpose) {
                // 初発行
                case COMMON_CONSTANTS.EQPurposeType.CashCardFirstPublish:
                    this.setSubmitData('businessType', '0');
                    this.setSubmitData('businessTypeText', this.labelService.labels.cashcard.reason.first);
                    break;
                // 暗証忘れ
                case COMMON_CONSTANTS.EQPurposeType.CashCardPassword:
                    this.setSubmitData('businessType', '2');
                    this.setSubmitData('businessTypeText', this.labelService.labels.cashcard.reason.pswLost);
                    break;
                // 破損・磁気不良
                case COMMON_CONSTANTS.EQPurposeType.CashCardBroken:
                    this.setSubmitData('businessType', '3');
                    this.setSubmitData('businessTypeText', this.labelService.labels.cashcard.reason.damaged);
                    break;
                // 喪失・再発行
                case COMMON_CONSTANTS.EQPurposeType.CashCardLost:
                    this.setSubmitData('businessType', '1');
                    this.setSubmitData('businessTypeText', this.labelService.labels.cashcard.reason.lost);
                    break;
            }

            this.setSubmitData('branchNo', data.swipeInfo.cardBranchNo);
            this.setSubmitData('accountNo', data.swipeInfo.cardAccountNo);
            this.setSubmitData('accountType', data.swipeInfo.cardAccountType);

            this.setSubmitData('swipeBranchNo', data.swipeInfo.cardBranchNo);
            this.setSubmitData('swipeAccountNo', data.swipeInfo.cardAccountNo);
            this.setSubmitData('swipeAccountType', data.swipeInfo.cardAccountType);
            this.setSubmitData('swipeCif', data.swipeInfo.branchCif);

            this.setSubmitData('receptionBranchNo', data.swipeInfo.receptionBranchNo);
            this.setSubmitData('receptionNo', data.swipeInfo.receptionNo);
            this.setSubmitData('receptionTime', data.swipeInfo.receptionTime);
            this.setSubmitData('purpose', data.swipeInfo.purpose);
        }

        this.state.tabletApplyId = data.tabletApplyId;
        this.setSubmitData('tabletApplyId', data.tabletApplyId);
    }

    /**
     * 口座存在チェック結果設定
     * @param data response data
     */
    @ActionBind(CashCardActionType.GET_ACCOUNT_EXISTING)
    private signalAccountExistenceCheckResult(data: any) {
        // 完了コード(CODE)=NGの場合、口座番号をクリアする
        if (data.response.wsp_res.code === COMMON_CONSTANTS.PROCESS_CODE_NG) {
            this.setSubmitData('accountNo', null);
        }

        // 口座存在チェック結果を発送する
        this.sendSignal(CashCardSignal.GET_CHECK_ACCOUNT_EXISTING, data);
    }

    /**
     * CIF情報と口座残高情報の設定
     * @param results response data
     */
    @ActionBind(CashCardActionType.SET_CIF_ACCOUNT_BALANCE_INFO)
    private setCifAccountBalanceInfo(results: any) {
        // CIF情報照会
        const cifInfo = results.data[0];
        // 口座残高情報照会
        const accountInfo = results.data[1];

        this.state.cifInfoInquiryList = cifInfo.result.cifInfoInquiryResponseList;
        this.settingCifInformation(cifInfo.result.cifInfoInquiryResponse);
        if (accountInfo && accountInfo.result && accountInfo.result.responseList[0]) {
            this.setSubmitData('swipeCardType', accountInfo.result.responseList[0].holderCardType);
            this.setSubmitData('holderCardType', accountInfo.result.responseList[0].holderCardType);
            this.setSubmitData('agentCardType', accountInfo.result.responseList[0].agentCardType);
            this.setSubmitData('holderCardMsIcType', accountInfo.result.responseList[0].holderCardMsIcType);
            this.setSubmitData('agentCardMsIcType', accountInfo.result.responseList[0].agentCardMsIcType);
        }

        this.sendSignal(CashCardSignal.CHAT_FLOW_COMPELETE, results.nextChatName);
    }

    /**
     * 暗証番号ルール適合性チェック(初めて発行)結果設定
     * @param data response data
     */
    @ActionBind(CashCardActionType.GET_EXISTING_PASSWORD_RULE)
    private signalExistingCustomerPasswordCheckResult(data: any) {
        // 暗証番号ルール適合性チェック結果を発送する
        this.sendSignal(CashCardSignal.GET_PASSWORD_RULE, data);
    }

    /**
     * CIF情報照会設定(Simple)
     * @param data response data
     */
    @ActionBind(CashCardActionType.SET_SIMPLE_CIF_ACCOUNT_BALANCE_INFO)
    private setSimpleCifInformation(results: any) {
        // CIF情報照会
        const cifInfo = results.data[0];
        // 口座残高情報照会
        const accountInfo = results.data[1];

        this.settingCifInformation(cifInfo.result.cifInfoInquiryResponse as CifInfoInquiryResponseEntity);

        if (accountInfo && accountInfo.result && accountInfo.result.responseList[0]) {
            this.setSubmitData('swipeCardType', accountInfo.result.responseList[0].holderCardType);
            this.setSubmitData('holderCardType', accountInfo.result.responseList[0].holderCardType);
            this.setSubmitData('agentCardType', accountInfo.result.responseList[0].agentCardType);
            this.setSubmitData('holderCardMsIcType', accountInfo.result.responseList[0].holderCardMsIcType);
            this.setSubmitData('agentCardMsIcType', accountInfo.result.responseList[0].agentCardMsIcType);
        }
        this.sendSignal(CashCardSignal.GET_NEXT_CHAT_MESSAGE, results.params);
    }

    /**
     * SubmitDataに本人基本情報設定を行う
     * @param entity CIF情報エンティティ
     */
    private settingCifInformation(entity: CifInfoInquiryResponseEntity) {
        // 基本情報を設定する
        CifInformationUtils.setCifBasicInfoForCommon(this.state.submitData, this.keysArr, entity);

        // CIF
        this.setSubmitData('swipeCif', entity.branchCif);
    }

    /**
     * 消費税を設定する
     * @param data 消費税
     */
    @ActionBind(CashCardActionType.GET_CONSUMPTION_TAX)
    private setConsumptionTaxValue(data: any) {
        if (data) {
            this.setSubmitData('consumptionTax', data);
        }
    }

    // Save yaml file Information
    private saveCurrentYamlInfo(params: any) {
        this.state.currentFileInfo.yamlId = params.id;
        this.state.currentFileInfo.screenId = params.screenId;
        this.state.currentFileInfo.screenName = params.screenName;
    }
    /**
     * Reset showConfirm
     * @param showConfirm showConfirm
     */
    @ActionBind(CashCardActionType.RESET_SHOW_CONFIRM)
    private resetShowConfirm(showConfirm) {
        this.state.showConfirm = showConfirm;
    }

    /**
     * submit dataをセットする
     *
     * @param key キー
     * @param value 値
     */
    private setSubmitData(key, value) {
        if (key !== undefined) {
            this.state.submitData[key] = value;
            this.keyPush(key, value);
        }
    }

    /**
     * キーを配列に保存する
     *
     * @param key キー
     * @param value 値
     */
    private keyPush(key: any, value: any) {
        if (value === null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                this.keysArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1) {
            this.keysArr.push(key);
        }
    }

    /**
     * submit dataをクリーンする
     * @param remain
     */
    private cleanSubmitData(remain: number) {
        this.keysArr = this.keysArr.slice(0, remain);

        for (const item in this.state.submitData) {
            if (item.startsWith('get')) {
                continue;
            }
            if (this.keysArr.indexOf(item) < 0 && item !== SubmitDataKey.LOG_FILE_INFO) {
                this.state.submitData[item] = undefined;
            }
        }
    }

    private getTopOrder() {
        return this.keysArr.length;
    }

    /**
     * Set the item as the current time of server
     * @param data system time and the key of item
     */
    @ActionBind(CashCardActionType.SET_SYSTEM_TIME)
    private setAsSystemTime(data: any) {
        this.setSubmitData(data.key, data.systemTime);
    }

    /**
     * 本人カードタイプの場合、来店の目的によって離脱か判断
     */
    private checkSelfCardType() {
        switch (this.state.submitData.businessType) {
            case BusinessType.FIRST_ISSUE:
                return this.state.submitData.holderCardType === HolderCardTypeCode.UN_PUBLISH;
            default:
                return this.state.submitData.holderCardType === HolderCardTypeCode.GENERAL_CARD
                    || this.state.submitData.holderCardType === HolderCardTypeCode.CARD_LOAN
                    || this.state.submitData.holderCardType === HolderCardTypeCode.DEPOSIT_CARD;
        }
    }

    /**
     * 家族用カードタイプの場合、来店の目的によって離脱か判断
     * @param onlyFamily 家族だけの判定
     */
    private checkFamilyCardType(onlyFamily?: boolean) {
        switch (this.state.submitData.businessType) {
            case BusinessType.FIRST_ISSUE:
                // 家族カードのみを発行する場合に、本人にカードを発行していない場合は、家族カードのみを発行できないようにする
                // 本人カード、家族カードの両方を発行する場合に、家族カードの方は、「agentCardType＝0」発行可をチェックする
                return onlyFamily ?
                    (this.state.submitData.holderCardType === HolderCardTypeCode.GENERAL_CARD
                        && this.state.submitData.agentCardType === HolderCardTypeCode.UN_PUBLISH)
                    : this.state.submitData.agentCardType === HolderCardTypeCode.UN_PUBLISH;
            default:
                return this.state.submitData.agentCardType === HolderCardTypeCode.GENERAL_CARD
                    || this.state.submitData.agentCardType === HolderCardTypeCode.CARD_LOAN
                    || this.state.submitData.agentCardType === HolderCardTypeCode.DEPOSIT_CARD;
        }
    }
}
