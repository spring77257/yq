// 申込業務区分
export class ApplyBusinessType {
    // キャッシュカード発行（初発行）
    public static readonly FIRST_ISSUE = '30';
    // キャッシュカード発行（初発行・家族あり）
    public static readonly FIRST_ISSUE_FAMILY = '31';
    // キャッシュカード発行（初発行・家族のみ）
    public static readonly FIRST_ISSUE_FAMILY_ONLY = '32';
    // キャッシュカード発行（暗証忘れ）
    public static readonly FORGET_PASSWORD = '33';
    // キャッシュカード発行（暗証忘れ・家族あり）
    public static readonly FORGET_PASSWORD_FAMILY = '34';
    // キャッシュカード発行（暗証忘れ・家族のみ）
    public static readonly FORGET_PASSWORD_FAMILY_ONLY = '35';
    // キャッシュカード発行（破損・磁気不良）
    public static readonly BROKEN = '33';
    // キャッシュカード発行（破損・磁気不良・家族あり）
    public static readonly BROKEN_FAMILY = '37';
    // キャッシュカード発行（破損・磁気不良・家族のみ）
    public static readonly BROKEN_FAMILY_ONLY = '38';
    // キャッシュカード発行（喪失・再発行）
    public static readonly LOST_REISSUE = '30';
    // キャッシュカード発行（喪失・再発行・家族あり）
    public static readonly LOST_REISSUE_FAMILY = '40';
    // キャッシュカード発行（喪失・再発行・家族のみ）
    public static readonly LOST_REISSUE_FAMILY_ONLY = '41';

    // キャッシュカード発行(初発行)
    public static readonly FIRST = '30';
    // キャッシュカード発行(切替)
    public static readonly CHANGE = '31';
    // キャッシュカード発行(再発行)
    public static readonly RE = '32';

}
// 初めて発行、カード暗証番号忘れ、カード破損・磁気不良、カード紛失・盗難
export class BusinessType {
    // 初めて発行
    public static readonly FIRST_ISSUE = '0';
    // カード暗証番号忘れ
    public static readonly FORGET_PASSWORD = '2';
    // カード破損・磁気不良
    public static readonly BROKEN = '3';
    // カード紛失・盗難
    public static readonly LOST = '1';
}
// 発行対象
export class CashCardType {
    // 本人カードのみ
    public static readonly SELF = '0';
    // 本人カード＋家族用カード
    public static readonly SELF_FAMILY = '1';
    // 家族用カードのみ
    public static readonly FAMILY = '2';
}
export class Const {
    public static groupA = ['31', '36', '55', '51', '26', '28', '29', '30', '35', '53', '52'];
    public static groupB = ['06', '16', '17', '18', '19', '44'];
    public static groupB2 = ['41', '43'];
    public static groupC = ['1', '2', '3', '4', '5', '6'];
}

/**
 * キャッシュカード指定文言
 */
export class CashCard {
    public static readonly ZERO = '0';
    public static readonly ONE = '1';
    public static readonly TWO = '2';
    public static readonly THREE = '3';
    public static readonly SEVEN = '7';
    public static readonly NINE = '9';
    public static readonly ELEVEN = '11';
    public static readonly THIRTEEN = '13';
    public static readonly FOURTEEN = '14';
    public static readonly AOUNT_ONE = '1080';
    public static readonly AOUNT_TWO = '2160';
}
