import { NgModule, Type } from '@angular/core';
import { HttpModule } from '@angular/http';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CashCardCommonInputHandler } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-common.input-handler';
import { CashCardCommonRenderer } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-common.renderer';
import { CashCardConfirmPageInputHandler } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-confirmpage.input-handler';
import { CashCardConfirmPageRenderer } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-confirmpage.renderer';
import { CashCardFamilyInputHandler } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-family.input-handler';
import { CashCardFamilyRenderer } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-family.renderer';
import { CashCardMenuInputHandler } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-menu.input-handler';
import { CashCardMenuRenderer } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-menu.renderer';
import { CashCardPasswordInputHandler } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-password.input-handler';
import { CashCardPasswordRenderer } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-password.renderer';
import { CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { CashCardAccountComponent } from 'dhdt/branch/pages/cashcard/view/cashcard-account.component';
import { CashCardChatComponent } from 'dhdt/branch/pages/cashcard/view/cashcard-chat.component';
import { CashCardConfirmPageChatComponent } from 'dhdt/branch/pages/cashcard/view/cashcard-confirmpage-chat.component';
import { CashCardInitConfirmComponent } from 'dhdt/branch/pages/cashcard/view/cashcard-initconfirm.component';
import { LoginModule } from 'dhdt/branch/pages/common/login/login.module';
import { TopModule } from 'dhdt/branch/pages/common/top/top.module';
import { AccountShopModule } from 'dhdt/branch/shared/components/account-shop/account-shop.module';
import { AddressModule } from 'dhdt/branch/shared/components/address/address.module';
import { BranchModule } from 'dhdt/branch/shared/components/branch/branch.module';
import { ConfirmPageCommonModule } from 'dhdt/branch/shared/components/confirmpage-common/confirmpage.common.module';
import { ModalPasswordModule } from 'dhdt/branch/shared/components/modal/modal-password/modal-password.module';
import { PickerModule } from 'dhdt/branch/shared/components/picker/picker.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';

export const SHARED_FORM_COMPONENT: Array<Type<any>> = [
    CashCardInitConfirmComponent,
    CashCardAccountComponent
];

@NgModule({
    imports: [
        LoginModule,
        TopModule,
        IonicModule,
        SharedModule,
        AddressModule,
        BranchModule,
        HttpModule,
        PickerModule,
        ConfirmPageCommonModule,
        ModalPasswordModule,
        AccountShopModule
    ],
    declarations: [
        SHARED_FORM_COMPONENT,
        CashCardChatComponent,
        CashCardConfirmPageChatComponent
    ],
    exports: [
        SHARED_FORM_COMPONENT,
        TopModule,
        CashCardChatComponent,
        CashCardConfirmPageChatComponent
    ],
    entryComponents: [
        SHARED_FORM_COMPONENT,
        CashCardChatComponent,
        CashCardConfirmPageChatComponent
    ],
    providers: [
        CashCardAction,
        CashCardStore,
        CashCardMenuInputHandler,
        CashCardCommonInputHandler,
        CashCardFamilyInputHandler,
        CashCardPasswordInputHandler,
        CashCardConfirmPageInputHandler,
        CashCardMenuRenderer,
        CashCardCommonRenderer,
        CashCardFamilyRenderer,
        CashCardPasswordRenderer,
        CashCardConfirmPageRenderer,
    ]
})
export class CashCardModule {
}
