
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
class ValidationRules {
    public min: { value: number };
    public max: { value: number };
    public required: { value: boolean };
}

// export class PageQuestionsModel {
//     public order: number;
//     public next: number;
//     public type: string;
//     public example: string;
//     public choices: any[];
//     @JsonProperty({ clazz: ValidationRules })
//     public validationRules: ValidationRules;
//     public question: string;
//     public name: string;
//     public answer: { text: string, value: any };
//     public pageIndex: number;
//     public skip: number;
// }

export class CashCardSubmitEntity {

    public holderName: string;
    public holderNameFurigana: string;
    public holderGender: string;
    public holderBirthdate: string;
    public holderAddressPrefecture: string;
    public holderAddressCountyUrbanVillage: string;
    public holderAddressStreetNameSelect: string; // selected street
    public holderAddressHouseNumber: string;
    public holderAddressPrefectureFuriKana: string;
    public holderAddressCountyUrbanVillageFuriKana: string;
    public holderAddressStreetNameFuriKanaSelect: string; // selected street
    public holderAddressHouseNumberFuriKana: string;
    public holderMobileNo: string;           // 携帯電話No
    public holderTelephoneNo: string;        // 自宅電話No
    public holderZipCode: string;            // 郵便番号
    public nameNonConvert: string;

    public hasLicense: string;
    public addressDiffrentReason: string;

    public firstNameKana: string;
    public lastNameKana: string;

    public firstZipCode: string;
    public lastZipCode: string;

    public holderAddressPrefectureCode: string;
    public holderAddressCountyUrbanVillageCode: string;
    public holderIdentityDocumentPhotographType: string;
    public holderIdentityDocumentAddressType: string;
    public holderIdentityDocumentNoCopyReason: string;
    public holderIdentityDocumentType: string;
    public holderNoCopyReason: string;
    public holderPublisher: string;
    public holderPublishDate: string;
    public holderSignNo: string;
    public branchNo: string;
    public branchNameKanji: string;

    public swipeCif: string;        // スワイプ店CIF
    public receptionBranchNo: string;        // 受付店番
    public receptionNo: string;        // 受付番号
    public receptionTime: string;        // 受付年月日時分秒
    public swipeBranchNo: string;
    public swipeAccountNo: string;
    public swipeAccountType: string;

    public firstMobileNo: string;
    public secondMobileNo: string;
    public thirdMobileNo: string;
    public firstTel: string;
    public secondTel: string;
    public thirdTel: string;
    public accountType: string;
    public accountTypeText: string;

    public holderIdentityDocumentPublisher: string;
    public holderIdentityDocumentPublishDate: string;
    public holderIdentityDocumentSignNo: string;

    public leaveType: string;

    public rqNo: string;
    public customerApplyEndDate: string;
    public bankclerkAuthenticationStartDate: string;
    public bankclerkAuthenticationEndDate: string;

    public tabletApplyId: string;
    public userMngNo: string;

    // MVP2 Cash-card added@2018/07/03
    public businessType: string;                // 0、1、2、3
    public businessTypeText: string;            // 初めて発行、カード暗証番号忘れ、カード破損・磁気不良、カード紛失・盗難
    public cashCardType: string;                // 0、1、2
    public cashCardTypeText: string;            // 本人カードのみ、本人カード＋家族用カード、家族用カードのみ
    public cashCardHasConfirmFile: string;      // 本人確認書類を持っているか
    public cashCardNameFurikana: string;        // 口座名義人のカナ氏名
    public cashCardFirstNameKana: string;       // 口座名義人のFirstカナ氏名
    public cashCardLastNameKana: string;        // 口座名義人のLastカナ氏名
    // public cashCardBranchNameKanji: String;     // 口座のお取引店
    public accountNo: string;                   // 口座番号
    public cashCardDesign: string;              // 本人カードデザイン
    public cashCardPassword: string;            // 本人カードPassword
    public cashCardFirstPwd4bits: string;       // 本人カードPassword
    public cashCardFamilyName: string;          // 家族のおなまえ
    public cashCardFamilyFirstName: string;     // 家族のおなまえFirstName
    public cashCardFamilyLastName: string;      // 家族のおなまえLastName
    public cashCardFamilyNameFurikana: string;  // 家族のカナ氏名
    public cashCardFamilyFirstNameKana: string; // 家族のFirstカナ氏名
    public cashCardFamilyLastNameKana: string;  // 家族のLastカナ氏名
    public familyRelationship: string;          // 家族関係:1(配偶者) 2(配偶者配偶者以外)
    public cashCardFamilyDesign: string;        // 家族カードデザイン
    public cashCardFamilyPassword: string;      // 家族カードPassword
    public cashCardFamilyFirstPwd4bits: string; // 家族カードPassword
    public cashCardReceiptMethod: string;       // キャッシュカードReceiptMethod
    public cashCardFamilyReceiptMethod: string; // 家族カードReceiptMethod
    public cardHolderBirthday: string;          // 生年月日
    public purpose: string;                     // 来店目的
    public agentCardGender: string;             // 家族の性別

    public consumptionTax: string;              // 消費税

    public fileInfo?: any;

    public holderCardType: string;
    public agentCardType: string;

    public getHolderMobileNo(): string {
        if (!this.firstMobileNo || !this.secondMobileNo || !this.thirdMobileNo) {
            return '';
        }
        return this.firstMobileNo + this.secondMobileNo + this.thirdMobileNo;
    }

    public getHolderTelephoneNo(): string {
        if (!this.firstTel || !this.secondTel || !this.thirdTel) {
            return '';
        }
        return this.firstTel + '-' + this.secondTel + '-' + this.thirdTel;
    }

    public getHolderZipCode(): string {
        return this.firstZipCode + this.lastZipCode;
    }

    public getCashCardNameFurigana(): string {
        return this.cashCardFirstNameKana + '　' + this.cashCardLastNameKana;
    }

    public getFamilyName(): string {
        if (this.cashCardFamilyFirstName && this.cashCardFamilyLastName) {
            return this.cashCardFamilyFirstName + COMMON_CONSTANTS.FULL_SPACE + this.cashCardFamilyLastName;
        }
        return '';
    }
    public getFamilyNameFurigana(): string {
        if (this.cashCardFamilyFirstNameKana && this.cashCardFamilyLastNameKana) {
            return this.cashCardFamilyFirstNameKana + ' ' + this.cashCardFamilyLastNameKana;
        }
        return '';
    }
}

export class DropDownListEntity {
    public key: string;
    public codeValue: string;
    public filler1: string;
    public filler2: string;
    public filler3: string;
    public filler5: string;
}
