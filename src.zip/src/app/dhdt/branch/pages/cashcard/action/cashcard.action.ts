import { Injectable } from '@angular/core';
import { Action } from 'adep/flux';
import { HttpService } from 'dhdt/branch/shared/services/http.service';

import { HttpClient } from '@angular/common/http';
import { API_URL, ApplyDate, CodeCategory, SubmitDataKey } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { AccountBalanceInquiryInterface } from 'dhdt/branch/shared/interface/account-balance-inquiry.interface';
import { AccountExistCheckInterface } from 'dhdt/branch/shared/interface/account-exist-check.interface';
import { ExistingPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/existing-password-rule-check.interface';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { ChatFlowActionInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-action.interface';
import { DocumentCategorySubjectData } from 'dhdt/branch/shared/modules/document-category/entity/document-category.entity';
import { Observable } from 'rxjs/Observable';

export namespace CashCardActionType {
    export const GET_SAVING_QUESTION_TEMPLATE: string = 'CashCardActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const NEXT_CHAT: string = 'CashCardActionType_NEXT_CHAT';
    export const CLEAR: string = 'CashCardActionType_LOAD_TEMPLATE_CLEAR';
    export const CLEAR_DOCUMENTS: string = 'CLEAR_DOCUMENTS';
    export const CLEAR_SHOW_CHATS: string = 'CashCardActionType_CLEAR_SHOW_CHATS';
    export const BRANCH_STATUS_INSERT: string = 'CashCardActionType_BRANCH_STATUS_INSERT';
    export const BRANCH_STATUS_UPDATE: string = 'CashCardActionType_BRANCH_STATUS_UPDATE';
    export const SET_ANSWER: string = 'CashCardActionType_SET_ANSWER';
    export const EDIT_CHAT: string = 'CashCardActionType_EDIT_CHAT';
    export const SET_STATE_SUBMIT_DATA_VALUE: string = 'CashCardActionType_SET_STATE_SUBMIT_DATA_VALUE';
    export const GET_INFO_OCR: string = 'CashCardActionType_GET_INFO_OCR';
    export const VALIDATION_PASSWORD: string = 'CashCardActionType_VALIDATION_PASSWORD';
    export const SUBMIT_DATA_BACKUP: string = 'CashCardActionType_SUBMIT_DATA_BACKUP';
    export const RESET_SUBMIT_DATA: string = 'CashCardActionType_RESET_SUBMIT_DATA';
    export const RETRIEVE_DROP_LIST: string = 'CashCardActionType_RETRIEVE_DROP_LIST';
    export const RETRIEVE_DROP_LIST_FOR_NAME: string = 'CashCardActionType_RETRIEVE_DROP_LIST_FOR_NAME';
    export const GET_HOLDER_ZIP_CODE = 'CashCardActionType_GET_HOLDER_ZIP_CODE';
    export const BRANCH_INFO_INSERT: string = 'CashCardActionType_BRANCH_INFO_INSERT';
    export const UPLOAD_IMAGE = 'CashCardACTIONTYPE_UPLOAD_IMAGE';
    export const CHAT_FLOW_COMPELETE = 'CashCardACTIONTYPE_CHAT_FLOW_COMPELETE';
    export const RESET_LAST_NODE = 'CashCardACTIONTYPE_RESET_LAST_NODE';
    export const SUBMIT_TIME_SAVING_APPLY_INFO = 'SUBMIT_TIME_SAVING_APPLY_INFO';
    export const GET_BRANCH_NAME = 'CashCardActionType_GET_BRANCH_NAME';
    export const SET_CUSTOMER_APPLY_END_DATE: string = 'CashCardActionType_SET_CUSTOMER_APPLY_END_DATE';
    export const SET_BANKCLERK_CONFIRM_START_DATE: string = 'SET_BANKCLERK_CONFIRM_START_DATE';
    export const SET_BANKCLERK_CONFIRM_END_DATE: string = 'SET_BANKCLERK_CONFIRM_END_DATE';
    export const SET_BANKCLERK_ID: string = 'SET_BANKCLERK_ID';
    export const SET_BRANCH_INFO: string = 'SET_BRANCH_INFO';
    export const SET_AGENCY_BRANCH_INFO: string = 'SET_AGENCY_BRANCH_INFO';
    export const SET_INTEREST_COMPUTATION_METHOD: string = 'SET_INTEREST_COMPUTATION_METHOD';
    export const CLEAR_OPEN_ACCOUNT_PURPOSE: string = 'CLEAR_OPEN_ACCOUNT_PURPOSE';

    export const GET_CANCELABLE_ITEM_LIST = 'CashCardActionType_GET_CANCELABLE_ITEM_LIST';
    export const MODIFY_ID_CANCELABLE_ITEM_LIST = 'CashCardActionType_MODIFY_ID_CANCELABLE_ITEM_LIST';
    export const MODIFY_METHOD_CANCELABLE_ITEM_LIST = 'CashCardActionType_MODIFY_METHOD_CANCELABLE_ITEM_LIST';
    export const MODIFY_CANCEL_AMOUNT_CANCELABLE_ITEM_LIST = 'CashCardActionType_MODIFY_CANCEL_AMOUNT_CANCELABLE_ITEM_LIST';
    export const ITEM_COUNT = 'CashCardActionType_ITEM_COUNT';
    export const DELETE_ITEMS_FROM_CANCELABLE_ITEM_LIST = 'CashCardActionType.DELETE_ITEMS_FROM_CANCELABLE_ITEM_LIST';
    export const SUBMIT_TIME_SAVING_ORANGE_APPLY_INFO = 'SUBMIT_TIME_SAVING_ORANGE_APPLY_INFO';
    export const SUBMIT_TIME_SAVING_LOVE_APPLY_INFO = 'SUBMIT_TIME_SAVING_LOVE_APPLY_INFO';
    export const SUBMIT_TIME_SAVING_SMILE_APPLY_INFO = 'SUBMIT_TIME_SAVING_SMILE_APPLY_INFO';
    export const GET_CONFIRM_PAGE_TEMPLATE: string = 'GET_CONFIRM_PAGE_TEMPLATE';

    export const RESET_SHOWCHATS = 'CashCardActionType_RESET_SHOWCHATS';

    export const SET_SWIPE_INFO: string = 'CashCardActionType_SET_SWIPE_INFO';      // set account info from qr scan result
    export const GET_ACCOUNT_EXISTING = 'CashCardActionType_GET_ACCOUNT_EXISTING';  // 口座存在チェック
    export const SET_CIF_ACCOUNT_BALANCE_INFO = 'CashCardActionType_SET_CIF_ACCOUNT_BALANCE_INFO';
    export const SET_SIMPLE_CIF_ACCOUNT_BALANCE_INFO = 'CashCardActionType_SET_SIMPLE_CIF_ACCOUNT_BALANCE_INFO';
    export const GET_EXISTING_PASSWORD_RULE = 'CashCardActionType_GET_EXISTING_PASSWORD_RULE';  // 暗証番号ルール適合性チェック(初めて発行)

    export const GET_CONSUMPTION_TAX = 'CashCardActionType_GET_CONSUMPTION_TAX'; // 消費税
    export const SET_SYSTEM_TIME = 'CashCardActionType_SET_SYSTEM_TIME'; // get systemtime from api
    export const RESET_SHOW_CONFIRM = 'CashCardActionType_RESET_SHOW_CONFIRM';

    export const GET_ACCOUNT_BALANCE = 'CashCardActionType_GET_ACCOUNT_BALANCE';
    export const GET_CIF_INFO = 'CashCardActionType_GET_CIF_INFO';
}

@Injectable()
export class CashCardAction extends Action implements ChatFlowActionInterface {
    constructor(
        private httpService: HttpService,
        private httpClient: HttpClient
    ) {
        super();
    }

    public getBranchName(params: any) {
        this.httpService.get(API_URL.BRANCH_NAME, params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.GET_BRANCH_NAME,
                data: response.result
            });
        });
    }

    public setAgencyBranchInfo(branchNo: string) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.SET_AGENCY_BRANCH_INFO,
            data: { branchNo: branchNo }
        });
    }

    public setBranchInfo(branchNameKanji, branchNo: string) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.SET_BRANCH_INFO,
            data: {
                branchNameKanji: branchNameKanji,
                branchNo: branchNo
            }
        });
    }

    public setBankclerkId(bankclerkId: string) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.SET_BANKCLERK_ID,
            data: { bankclerkId: bankclerkId }
        });
    }

    public loadTemplate(file: string, pageIndex: number) {
        // this.httpClient.get('./assets/datas/' + file).subscribe((response: any) => {

        this.httpService.get('/chatflow/definition/' + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos,
                }
            });
        });
    }

    public branchStatusInsert(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.BRANCH_STATUS_INSERT,
                data: response.result
            });
        });
    }

    public uploadImage(params: any) {
        this.httpService.post('/files/fileAccess/save/json', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.UPLOAD_IMAGE,
                data: response.result
            });
        });
    }

    // get holderZipCode 郵便番号
    public getHolderZipCode(prefectureKanji: string, countyUrbanVillageKanji: string, streetKanji: string) {
        const params = {
            prefectureKanji: prefectureKanji,
            countyUrbanVillageKanji: countyUrbanVillageKanji,
            streetKanji: streetKanji
        };
        this.httpService.get(API_URL.ADDRESS_ZIP_CODE_SEARCH, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.GET_HOLDER_ZIP_CODE,
                data: response.result.zipCode
            });
        }
        );
    }

    /**
     * submit dataを更新
     *
     * @param data 書類カテゴリと選択された書類
     * @param isHolderPage 本人確認画面フラグ
     * @param isHolder 本人フラグ
     */
    public setDocumentCategory(data: DocumentCategorySubjectData) {
        switch (data.code) {
            // コピー徴求ができない理由
            case CodeCategory.CODE_CATEGORY_NO_COPY_REASON:
            // 住所が相違する理由
            case CodeCategory.CODE_CATEGORY_DIFFERENT_ADDRESS_REASON:
                this.setStateSubmitDataValue({
                    name: data.key,
                    value: data.entity ? data.entity.data : null
                });
                break;
        }
    }

    public branchStatusUpdate(params: any) {
        this.httpService.post(API_URL.BRANCH_STATUS_UPDATE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.BRANCH_STATUS_UPDATE,
                data: response.result
            });
        });
    }

    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    public clearStore() {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.CLEAR
        });
    }

    public clearStoreDocuments() {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.CLEAR_DOCUMENTS
        });
    }

    public clearShowChats() {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.CLEAR_SHOW_CHATS
        });
    }

    /**
     * 回答内容を編集する
     *
     * @param order オーダー
     * @param pageIndex ページインデックス
     * @param answerOrder 回答順
     */
    public editAnswer(order: number, pageIndex: number, answerOrder: number) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.EDIT_CHAT,
            data: { order: order, pageIndex: pageIndex, answerOrder: answerOrder }
        });
    }

    public setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.SET_ANSWER,
            data: answer
        });
    }

    public setStateSubmitDataValue(param: any) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.SET_STATE_SUBMIT_DATA_VALUE,
            data: param
        });
    }

    public getInfoFromOCR(params: any) {
        this.httpService.post('/ocr/analysis', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.GET_INFO_OCR,
                data: response.result
            });
        });
    }

    public saveSubmitData(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/bankclerk-confirm-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.BRANCH_INFO_INSERT,
                data: response.result
            });
        });
    }

    public validationPassword(param) {
        // this.httpService.post('branch/info-insert', params).subscribe((response) => {
        this.httpClient.get('./assets/datas/password.json', param.password).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.VALIDATION_PASSWORD,
                data: response.result
            });
        });
    }

    public submitDataBackup() {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.SUBMIT_DATA_BACKUP
        });
    }

    public resetSubmitData() {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.RESET_SUBMIT_DATA
        });
    }

    public retrieveDropList(params: any) {
        this.httpService.get('/categoryCodes/retrieve', params).subscribe((response: any) => {
            // this.httpClient.get('./assets/datas/drop-down-list-account.json', params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.RETRIEVE_DROP_LIST,
                data: response.result
            });
        });
    }

    /**
     * 本人確認書類情報取得
     * @param params categoryCode
     */
    public retrieveDropListForName(params: any) {
        this.httpService.get('/categoryCodes/retrieve', params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.RETRIEVE_DROP_LIST_FOR_NAME,
                data: response.result
            });
        });
    }

    public chatFlowCompelete(nextChatName: string) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.CHAT_FLOW_COMPELETE,
            data: nextChatName
        });
    }

    public resetLastNode() {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.RESET_LAST_NODE
        });
    }

    public submitTimeSavingApplyInfo(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/time-saving-apply-info-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.SUBMIT_TIME_SAVING_APPLY_INFO,
                data: response.result
            });
        });
    }

    // set 利息計算方法 複利型/単利型
    public setInterestComputationMethod(params: string) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.SET_INTEREST_COMPUTATION_METHOD,
            data: params
        });
    }

    public submitTimeSavingSmileApplyInfo(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/time-saving-smile-apply-info-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.SUBMIT_TIME_SAVING_SMILE_APPLY_INFO,
                data: response.result
            });
        });
    }

    public submitTimeSavingOrangeApplyInfo(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/time-saving-orange-apply-info-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.SUBMIT_TIME_SAVING_ORANGE_APPLY_INFO,
                data: response.result
            });
        });
    }

    public submitTimeSavingLoveApplyInfo(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/time-saving-love-apply-info-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.SUBMIT_TIME_SAVING_LOVE_APPLY_INFO,
                data: response.result
            });
        });
    }
    /**
     * キャッシュカード発行
     * @param params
     */
    public saveCashcardData(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/cashcard-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.BRANCH_INFO_INSERT,
                data: response.result
            });
        });
    }

    public loadConfirmPageTemplate(file: string, pageIndex: number) {

        this.httpService.get('/chatflow/definition/' + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.GET_CONFIRM_PAGE_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos,
                }
            });
        });
    }

    /**
     * Reset showChats to origin
     * @param originShowChats originShowChats
     */
    public resetShowChats(originShowChats: any[], originSubmitData?: any) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.RESET_SHOWCHATS,
            data: { originShowChats, originSubmitData }
        });
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param params QRコード受付情報
     */
    public setSwipeInfo(params: any) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.SET_SWIPE_INFO,
            data: params
        });
    }

    /**
     * CIF情報照会と口座残高照会を行う
     * @param cifParams CIF情報照会用パラメータ
     * @param accountParam 口座残高照会用パラメータ
     * @param nextChatName 次のチャット名
     */
    public getCifAccountBalanceInfo(cifParams: SimpleCifInfoInquiryInterface, accountParam: AccountBalanceInquiryInterface,
                                    nextChatName: string) {
        const cifRequest: Observable<any> = this.httpService.post(API_URL.CB_GET_CIF_INFORMATION, cifParams);
        const accountRequest: Observable<any> = this.httpService.post(API_URL.CB_GET_ACCOUNT_BALANCE, accountParam);

        Observable.forkJoin(cifRequest, accountRequest).subscribe((data) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.SET_CIF_ACCOUNT_BALANCE_INFO,
                data: { data: data, nextChatName: nextChatName }
            });
        });
    }

    /**
     * 暗証番号ルール適合性チェック(初めて発行場合)
     * @param params 暗証番号ルール適合性チェック用パラメータ
     */
    public checkExistingCustomerPasswordRule(params: ExistingPasswordRuleCheckInterface) {
        this.httpService.post(API_URL.CB_CHECK_EXISTING_PASSWORD_RULE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.GET_EXISTING_PASSWORD_RULE,
                data: response.result
            });
        });
    }

    /**
     * CIF情報照会(Simple)と口座残高照会を行う
     * @param cifParams CIF情報照会用パラメータ
     * @param accountParam 口座残高照会用パラメータ
     * @param nextChatName 次のチャット名
     */
    public getSimpleCifInformation(cifParams: SimpleCifInfoInquiryInterface, accountParam: AccountBalanceInquiryInterface,
                                   nextOrder, pageIndex) {
        const cifRequest: Observable<any> = this.httpService.post(API_URL.CB_GET_SIMPLE_CIF_INFORMATION, cifParams);
        const accountRequest: Observable<any> = this.httpService.post(API_URL.CB_GET_ACCOUNT_BALANCE, accountParam);

        Observable.forkJoin(cifRequest, accountRequest).subscribe((data) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.SET_SIMPLE_CIF_ACCOUNT_BALANCE_INFO,
                data: { data: data, params: { nextOrder: nextOrder, pageIndex: pageIndex } }
            });
        });
    }

    /**
     * 消費税を取得する
     */
    public getConsumptionTax() {
        this.httpService.get('/calculation-tax/consumption-tax').subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.GET_CONSUMPTION_TAX,
                data: response.result
            });
        });
    }

    /**
     * 口座存在チェック
     * @param param 口座存在チェック用パラメータ
     */
    public getAccountExistInfo(param: AccountExistCheckInterface) {
        this.httpService.post(API_URL.CB_CHECK_ACCOUNT_EXISTING, param)
            .subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: CashCardActionType.GET_ACCOUNT_EXISTING,
                    data: response.result
                });
            });
    }

    /**
     * 口座残高情報
     * @param param 口座残高情報用パラメータ
     */
    public getAccountBlanceInfo(param: AccountBalanceInquiryInterface) {
        this.httpService.post(API_URL.CB_GET_ACCOUNT_BALANCE, param)
            .subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: CashCardActionType.GET_ACCOUNT_BALANCE,
                    data: response.result
                });
            });
    }

    /**
     * CIF情報照会を行う
     * @param cifParams CIF情報照会用パラメータ
     */
    public getCifInfo(param: SimpleCifInfoInquiryInterface) {
        this.httpService.post(API_URL.CB_GET_CIF_INFORMATION, param)
            .subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: CashCardActionType.GET_CIF_INFO,
                    data: response.result
                });
            });
    }

    /**
     * 顧客申し込み開始時間を設定する
     */
    public setCustomerApplyStartDate() {
        this.setAsSystemTime(ApplyDate.CUSTOMER_APPLY_START_DATE);
    }

    /**
     * 顧客申し込み完了時間を設定する
     */
    public setCustomerApplyEndDate() {
        this.setAsSystemTime(ApplyDate.CUSTOMER_APPLY_END_DATE);
    }

    /**
     * 行員認証開始時間を設定する
     */
    public setBankclerkAuthenticationStartDate() {
        this.setAsSystemTime(ApplyDate.BANKCLERK_AUTHENTICATION_START_DATE);
    }

    /**
     * set the item value as the current time of server
     * @param key the checbox item need to modify status
     */
    public setAsSystemTime(key: string) {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CashCardActionType.SET_SYSTEM_TIME,
                data: {
                    key: key,
                    systemTime: response.result.value
                }
            });
        });
    }

    /**
     * Reset showConfirm
     * @param showConfirm showConfirm
     */
    public resetShowConfirm(showConfirm: any) {
        this.dispatcher.dispatch({
            actionType: CashCardActionType.RESET_SHOW_CONFIRM,
            data: showConfirm
        });
    }
}
