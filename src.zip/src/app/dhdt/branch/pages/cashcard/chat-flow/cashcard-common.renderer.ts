import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CashCardCommonInputHandler } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-common.input-handler';
import { CashCardChatFlowQuestionTypes } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard.chat-flow-question-types';
import { CashCardSignal, CashCardState, CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { COMMON_CONSTANTS, Constants, CoreBankingConst } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { AccountBalanceInquiryInterface } from 'dhdt/branch/shared/interface/account-balance-inquiry.interface';
import { AccountExistCheckInterface } from 'dhdt/branch/shared/interface/account-exist-check.interface';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

export const CASH_CARD_COMMON_RENDERER_TYPE = 'CashCardCommonComponent';

@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CASH_CARD_COMMON_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-cashcard-common.yml'
})
export class CashCardCommonRenderer extends DefaultChatFlowRenderer {
    public processType = 1;
    private state: CashCardState;
    private readonly notFound: string = '1';

    constructor(private action: CashCardAction,
                private store: CashCardStore,
                inputHandler: CashCardCommonInputHandler,
                private loginStore: LoginStore,
                private deviceService: DeviceService,
                private modalService: ModalService,
                private errorService: ErrorMessageService,
                private labelService: LabelService) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    @Renderer([CashCardChatFlowQuestionTypes.BUTTON_THREE_COLS])
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number): void {
        super.onButtonDefaultRenderer(entity, pageIndex);
    }

    /**
     * キャッシュカード口座入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(CashCardChatFlowQuestionTypes.NUMBER_KEYBORD)
    public onNumberKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules, skip: entity.skip, type: entity.type, name: entity.name,
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: NumberInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CashCardChatFlowQuestionTypes.SELECT_BRANCH)
    public onSelectBranch(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = [{
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        }];
        this.emitRenderEvent({
            class: SelectBranchComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * keyboardコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    @Renderer(CashCardChatFlowQuestionTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getCashCardDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CashCardChatFlowQuestionTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        if (entity.choices && entity.choices.length > 0) {
            switch (entity.name) {
                case Constants.CASH_CARD_SWIPED:
                    this.emitMessageRetrivalEvent(
                        this.store.hasCashCardSwiped() ? entity.choices[0].swiped : entity.choices[0].next,
                        pageIndex, 0);
                    break;
                case Constants.CHECK_ACCOUNT_EXISTING:
                    this.store.registerSignalHandler(CashCardSignal.GET_CHECK_ACCOUNT_EXISTING, (data) => {
                        this.store.unregisterSignalHandler(CashCardSignal.GET_CHECK_ACCOUNT_EXISTING);

                        // 完了コード(CODE)=OK、checkResult=1の場合
                        if (data.response.wsp_res.code === COMMON_CONSTANTS.PROCESS_CODE_OK
                            && data.response.values.checkResult === this.notFound) {
                                this.emitMessageRetrivalEvent(entity.choices[0].failure, pageIndex, 0);
                        } else if (data.response.wsp_res.code === COMMON_CONSTANTS.PROCESS_CODE_NG) {
                            // 完了コード(CODE)=NGの場合、当該errReasonが返って表示する
                            this.errorService.handleExternalErrorByReason(data.response.values.errReason, undefined, () => {
                                this.emitMessageRetrivalEvent(entity.choices[0].failure, pageIndex, 0);
                            });
                        } else {
                            this.emitMessageRetrivalEvent(entity.choices[0].success, pageIndex, 0);
                        }
                    });
                    this.action.getAccountExistInfo(this.accountExistCheckParam);
                    break;
                case Constants.CHECK_CARD_TYPE:
                    // カード発行チェック
                    this.store.registerSignalHandler(CashCardSignal.GET_ACCOUNT_BALANCE, () => {
                        if (this.store.checkCashCardType()) {
                            // chashカードについてスワップ無しだからcif情報を取得が必要
                            this.action.getCifInfo(this.accountCifParam);
                            this.emitMessageRetrivalEvent(entity.choices[0].success, pageIndex, 0);
                        } else {
                            this.emitMessageRetrivalEvent(entity.choices[0].failure, pageIndex, 0);
                        }
                        this.store.unregisterSignalHandler(CashCardSignal.GET_ACCOUNT_BALANCE);
                    });
                    this.action.getAccountBlanceInfo(this.accountInfoParam);
                    break;
                default:
                    entity.choices.forEach((choice) => {
                        if (this.state.submitData[entity.name] === choice.value) {
                            this.emitMessageRetrivalEvent(choice.next, pageIndex, 0);
                        }
                    });
            }
        }
    }

    /**
     * アカウントショップコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    @Renderer(CashCardChatFlowQuestionTypes.ACCOUNT_SHOP)
    public onAccountShop(entity: ChatFlowMessageInterface, pageIndex: number): void {
        this.emitMessageRetrivalEvent(entity.next, pageIndex, 0);
    }

    private get accountExistCheckParam(): AccountExistCheckInterface {
        return {
            tabletApplyId: this.state.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            path: CoreBankingConstants.ApiPathConsts.ACCOUNT_EXIST_CHECK,
            params: {
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                tenban: this.state.submitData.branchNo,
                accountNo: this.state.submitData.accountNo,
                accountType: COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL,
                nameKana: StringUtils.convertZankaku2Hankaku(
                    this.state.submitData.getCashCardNameFurigana())
            }
        };
    }

    private get accountInfoParam(): AccountBalanceInquiryInterface {
        return {
            path: CoreBankingConstants.ApiPathConsts.ACCOUNT_BALANCE_INQUIRY,
            tabletApplyId: this.state.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            params: {
                bankNo: CoreBankingConst.bankNo,                                 // 銀行番号
                receptionTenban: this.state.submitData.receptionBranchNo,  // 受付店番
                receptionNo: this.state.submitData.receptionNo,            // 受付番号
                terminalNo: this.deviceService.getDeviceId(),            // 端末番号
                accountInfoList: [{
                    tenban: this.state.submitData.branchNo,
                    accountNo: this.state.submitData.accountNo,
                    accountType: COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL
                }]
            }
        };
    }

    private get accountCifParam(): SimpleCifInfoInquiryInterface {
        return {
            tabletApplyId: this.state.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            path: CoreBankingConstants.ApiPathConsts.CIF_INFO_INQUIRY,
            params: {
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                tenban: this.state.submitData.branchNo,
                accountNo: this.state.submitData.accountNo,
                accountType: COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL
            }
        };
    }

    private showWarningModal() {
        const buttonList = [
            { text: 'OK', buttonValue: 'ok' },
        ];
        this.modalService.showAlert(
            this.labelService.labels.cashcard.accountNotFound, null, 'icon_alert@2x.png', buttonList, 'settings-alert-modal'
        );
    }
}
