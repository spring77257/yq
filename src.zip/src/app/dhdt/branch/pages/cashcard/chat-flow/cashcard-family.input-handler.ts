import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services/label.service';
import { DeviceService } from 'dhd/common/services/device.service';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CashCardChatFlowQuestionTypes } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard.chat-flow-question-types';
import { CashCardSignal, CashCardState, CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { CashCardInitConfirmComponent } from 'dhdt/branch/pages/cashcard/view/cashcard-initconfirm.component';
import { Constants, CoreBankingConst } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/existing-password-rule-check.interface';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { App, NavController } from 'ionic-angular';

@Injectable()
export class CashCardFamilyInputHandler extends DefaultChatFlowInputHandler {

    private state: CashCardState;
    private navCtrl: NavController;

    constructor(private action: CashCardAction, private store: CashCardStore, private loginStore: LoginStore,
                private deviceService: DeviceService, private modalService: ModalService, app: App,
                private labelService: LabelService) {
        super(action);
        this.state = this.store.getState();
        this.navCtrl = app.getActiveNavs()[0];
    }

    private configAction(choice: any) {
        const action = choice.action;
        if (action.type === 'route') {
            this.navCtrl.setRoot(CashCardInitConfirmComponent);
        }
    }

    @InputHandler(CashCardChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.value }
                ]
            });
        }
        if (answer.action.type.length > 0) {
            this.configAction(answer);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler((CashCardChatFlowQuestionTypes.NUMBER_KEYBORD))
    private onNumberKeybordHandler(entity, pageIndex, answer) {
        super.simpleHandler(entity, pageIndex, answer);
    }

    @InputHandler(CashCardChatFlowQuestionTypes.PASSWORD_4BITS)
    private onPasswordInputHandler(entity, pageIndex, answer) {
        // 暗証番号ルール適合性チェックハンドルを追加
        this.store.registerSignalHandler(CashCardSignal.GET_PASSWORD_RULE, (data) => {
            this.store.unregisterSignalHandler(CashCardSignal.GET_PASSWORD_RULE);
            if (data.response.values.result === '1') {
                const buttonList = [
                    { text: 'OK', buttonValue: 'ok' },
                ];
                this.modalService.showAlert(
                    this.labelService.labels.error.passwordError,
                    null, 'icon_alert@2x.png', buttonList, 'settings-alert-modal',
                    () => {
                        this.action.resetLastNode();
                    },
                );
            } else {
                this.setAnswer(answer);
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            }
        });

        // 暗証番号ルール適合性チェックを行う
        const param: ExistingPasswordRuleCheckInterface = {
            tabletApplyId: this.state.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            path: CoreBankingConstants.ApiPathConsts.PASSWORD_RULE_CHECK,
            params: {
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                passcodeType: '1',
                passcode: answer.value[0].value,
                tenban: this.state.submitData.branchNo,
                accountNo: this.state.submitData.accountNo,
                branchCif: this.state.submitData.swipeCif
            }
        };
        this.action.checkExistingCustomerPasswordRule(param);
    }

    @InputHandler(CashCardChatFlowQuestionTypes.CARD)
    private onCardHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        this.setAnswer({
            text: answer.text,
            value: [
                { key: entity.name, value: answer.value }
            ]
        });
        this.emitMessageRetrivalEvent(answer.next, pageIndex);
    }

    @InputHandler(CashCardChatFlowQuestionTypes.KEYBOARD)
    private onKeybordHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
            this.setAnswer({ text: answer.text, value: results });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
    }
}
