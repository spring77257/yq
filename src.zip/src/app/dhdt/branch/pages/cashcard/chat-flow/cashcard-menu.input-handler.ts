import { Injectable } from '@angular/core';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CashCardChatFlowQuestionTypes } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard.chat-flow-question-types';
import { CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { ComponentType } from 'dhdt/branch/shared/entity/logging-operation.entity';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';

@Injectable()
export class CashCardMenuInputHandler extends DefaultChatFlowInputHandler {

    constructor(action: CashCardAction,
                private store: CashCardStore,
                private logging: LoggingService) {
        super(action);
    }

    @InputHandler(CashCardChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer: any) {
        const options = {
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.saveOperationLog(options, answer.value);
        if (entity.name === 'businessType') {
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: 'businessType', value: answer.value },
                    { key: 'businessTypeText', value: answer.text }
                ]
            });
        }

        if (answer.action.type === 'route') {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value }
                ]
            });
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    /**
     * add operation log
     */
    private saveOperationLog(options: any, item: string) {
        if (options && options.logInfo) {
            const logInfo: IOperationInfo = {
                screenName: options.logInfo.screenName,
                yamlId: options.logInfo.yamlId,
                yamlOrder: options.logInfo.yamlOrder,
                comType: ComponentType.MONTHINPUT,
                value: item
            };
            this.logging.log(this.logging.generalOperationParams(logInfo));
        }
    }
}
