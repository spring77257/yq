import { ChatFlowQuestionTypes } from 'dhdt/branch/shared/modules/chat-flow/chat-flow-question-types';

export class CashCardChatFlowQuestionTypes extends ChatFlowQuestionTypes {
    public static readonly BUTTON_THREE_COLS = 'buttonThreeCols';
    public static readonly SELECT_BRANCH = 'selectbranch';
    public static readonly CARD = 'card';
    public static readonly PASSWORD_4BITS = 'password4bits';
    public static readonly SELECT_STREET = 'selectStreet';
    public static readonly PREFECTURE_PICKER = 'prefecturePicker';
    public static readonly COUNTRY_URBAN_VILLAGE_PICKER = 'countyUrbanVillagePicker';
    public static readonly NEED_PASSWORD = 'needpassword';
    public static readonly ACCOUNT_SHOP = 'accountshop';
}
