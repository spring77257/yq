import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { BusinessType } from 'dhdt/branch/pages/cashcard/cashcard-consts';
import { CashCardPasswordInputHandler } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-password.input-handler';
import { CashCardChatFlowQuestionTypes } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard.chat-flow-question-types';
import { CashCardState, CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { ChangeConfirmComponent } from 'dhdt/branch/pages/change/view/change-confirm.component';
import { COMMON_CONSTANTS, Constants, CoreBankingConst } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { AccountBalanceInquiryInterface } from 'dhdt/branch/shared/interface/account-balance-inquiry.interface';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { App, ModalController, NavController } from 'ionic-angular';

export const CASH_CARD_PASSWORD_RENDERER_TYPE = 'CashCardPasswordComponent';

@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CASH_CARD_PASSWORD_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-cashcard-password.yml'
})
export class CashCardPasswordRenderer extends DefaultChatFlowRenderer {
    public processType = 1;
    private state: CashCardState;
    private navCtrl: NavController;
    private subPwdText: string;

    constructor(private action: CashCardAction, private store: CashCardStore, private loginStore: LoginStore,
                private modalCtrl: ModalController, private labelService: LabelService,
                private deviceService: DeviceService, app: App, inputHandler: CashCardPasswordInputHandler) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.navCtrl = app.getActiveNavs()[0];
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * パスワードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(CashCardChatFlowQuestionTypes.NEED_PASSWORD)
    public onPassword(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const param = {
            tabletApplyId: this.state.tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            terminalNo: this.deviceService.getDeviceId(),
            accountNo: this.state.submitData.accountNo,
            tenban: this.state.submitData.branchNo,
            accountType: this.state.submitData.swipeCif ?
                this.state.submitData.accountType : COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL
        };

        if (this.state.submitData.businessType === BusinessType.BROKEN) {
            this.subPwdText = this.labelService.labels.password.subTextBroken;
        } else if (this.state.submitData.businessType === BusinessType.LOST) {
            this.subPwdText = this.labelService.labels.password.subTextLost;
        } else {
            this.subPwdText = this.labelService.labels.password.subText;
        }

        const modal = this.modalCtrl.create(ModalPasswordComponent,
            {
                data: {
                    text: this.labelService.labels.password.text,
                    subText: this.subPwdText,
                    units: 4,
                    errorMessage: this.labelService.labels.password.errMessage,
                    needConfirm: false,
                    cashcardParams: param
                }
            },
            { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.onDidDismiss((value) => {
            // 暗証番号認証後、諸届変更画面へ遷移する
            if (value) {
                if (this.state.submitData.businessType === BusinessType.FIRST_ISSUE
                    || this.state.submitData.businessType === BusinessType.FORGET_PASSWORD) {
                    this.emitMessageRetrivalEvent(entity.next, pageIndex, 0);
                } else {
                    // 複合業務へ遷移し、自業務に戻る時CIF情報照会と口座残高照会を行う
                    this.navigateChangeConfirm(value);
                }
            }
        });
        modal.present();
    }

    /**
     * Judge 判定
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(CashCardChatFlowQuestionTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (entity.name === Constants.CASH_CARD_SWIPED) {
                    this.emitMessageRetrivalEvent(this.store.hasCashCardSwiped() ? choice.swiped : choice.next, pageIndex, 0);
                } else if (this.state.submitData[entity.name] === choice.value) {
                    this.emitMessageRetrivalEvent(choice.next, pageIndex, 0);
                }
            });
        }
    }

    /**
     * 複合業務へ遷移し、自業務に戻る時CIF情報照会と口座残高照会を行う
     * @param passcode パスワード
     */
    private navigateChangeConfirm(passcode: string) {
        // CIF情報照会ハンドル
        const cifParam: SimpleCifInfoInquiryInterface = {
            path: CoreBankingConstants.ApiPathConsts.CIF_INFO_INQUIRY,
            tabletApplyId: this.state.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            params: {
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                tenban: this.state.submitData.branchNo,
                accountNo: this.state.submitData.accountNo,
                accountType:
                    this.state.submitData.swipeCif && this.state.submitData.accountType && this.state.submitData.accountType.length > 0 ?
                    this.state.submitData.accountType : COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL,
            }
        };

        const inputParams = {
            tabletApplyId: this.state.tabletApplyId,
            swipeCif: this.state.submitData.swipeCif,
            branchNo: this.state.submitData.branchNo,
            accountNo: this.state.submitData.accountNo,
            accountType: this.state.submitData.accountType,
            receptionBranchNo: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            receptionTime: this.state.submitData.receptionTime,
            password: passcode,
        };

        // 口座残高情報照会
        const accountParam: AccountBalanceInquiryInterface = {
            path: CoreBankingConstants.ApiPathConsts.ACCOUNT_BALANCE_INQUIRY,
            tabletApplyId: this.state.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            params: {
                bankNo: CoreBankingConst.bankNo,                                 // 銀行番号
                receptionTenban: this.state.submitData.receptionBranchNo,  // 受付店番
                receptionNo: this.state.submitData.receptionNo,            // 受付番号
                terminalNo: this.deviceService.getDeviceId(),            // 端末番号
                accountInfoList: [{
                    tenban: this.state.submitData.branchNo,
                    accountNo: this.state.submitData.accountNo,
                    accountType: COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL
                }]
            }
        };

        this.navCtrl.push(
            ChangeConfirmComponent,
            {
                type: COMMON_CONSTANTS.BusinessFlowType.CashCard,
                processType: COMMON_CONSTANTS.ProcessType.RequiredInput,
                cifParam: cifParam,
                inputParams: inputParams,
                callBack: () => {
                    this.action.getCifAccountBalanceInfo(cifParam, accountParam, 'CashCardFamilyComponent');
                }
            },
            { animate: false }
        );
    }

}
