import { Injectable } from '@angular/core';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CashCardMenuInputHandler } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-menu.input-handler';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

export const CASH_CARD_MENU_RENDERER_TYPE = 'CashCardMenuComponent';

@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CASH_CARD_MENU_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-cashcard-menu.yml'
})
export class CashCardMenuRenderer extends DefaultChatFlowRenderer {
    public processType = 1;

    constructor(action: CashCardAction, inputHandler: CashCardMenuInputHandler) {
        super(action, inputHandler);
    }

    protected get userAnswers(): any {
        // OnJudgeへの分岐が無いため、呼び出された場合はエラーとする。
        throw new Error('this method should not be called.');
    }

}
