import { Injectable } from '@angular/core';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { BusinessType } from 'dhdt/branch/pages/cashcard/cashcard-consts';
import { CashCardChatFlowQuestionTypes } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard.chat-flow-question-types';
import { CashCardState, CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import {
    ChatFlowChoicesText, ChatFlowName, COMMON_CONSTANTS, Constants, CoreBankingConst
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { AccountBalanceInquiryInterface } from 'dhdt/branch/shared/interface/account-balance-inquiry.interface';
import { AccountExistCheckInterface } from 'dhdt/branch/shared/interface/account-exist-check.interface';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class CashCardCommonInputHandler extends DefaultChatFlowInputHandler {

    private state: CashCardState;
    private accountBalanceParam: AccountBalanceInquiryInterface;

    constructor(private action: CashCardAction, private store: CashCardStore, private loginStore: LoginStore,
                private audioService: AudioService, private deviceService: DeviceService, private modalService: ModalService) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler([
        CashCardChatFlowQuestionTypes.BUTTON,
        CashCardChatFlowQuestionTypes.BUTTON_THREE_COLS])
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.value }
                ]
            });
        }
        if (entity.name === 'cashCardType') {
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: 'cashCardType', value: answer.value },
                    { key: 'cashCardTypeText', value: answer.text }
                ]
            });
        }

        if (entity.name === ChatFlowName.CASHCARD_HASCONFIRMFILE &&
            answer.text === ChatFlowChoicesText.HOLDER_HAS) {
            this.updateTabletApplyInfo();
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        } else if (answer.action.type.length > 0) {
            this.configAction(answer, pageIndex);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(CashCardChatFlowQuestionTypes.NUMBER_KEYBORD)
    private onNumberKeyboardHandler(entity, pageIndex, answer) {
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(CashCardChatFlowQuestionTypes.SELECT_BRANCH)
    private onSelectBranchHandler(entity, pageIndex, answer) {
        this.setAnswer(answer);

        if (answer.value) {
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        } else {
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        }
    }

    /**
     * 回答の登録と次のメッセージの取得のみを行うハンドラ。
     *
     * @private
     * @param {*} entity
     * @param {number} pageIndex
     * @param {*} answer
     * @memberof CashCardConfirmPageRenderer
     */
    @InputHandler(CashCardChatFlowQuestionTypes.ACCOUNT_SHOP)
    private onAccountShopHandler(entity: any, pageIndex: number, answer: any) {
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'admin') {
            this.audioService.audioSubject.next(true);
            Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                this.action.resetLastNode();
            });
            this.chatFlowCompelete();
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }

    private getCifInfoParams(swipeCif: string, accountNo?: string): SimpleCifInfoInquiryInterface {
        // CIF情報照会ハンドル
        const cifParam: SimpleCifInfoInquiryInterface = {
            tabletApplyId: this.state.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            path: CoreBankingConstants.ApiPathConsts.CIF_INFO_INQUIRY,
            params: {
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                tenban: this.state.submitData.branchNo,
                accountNo: accountNo || this.state.submitData.accountNo,
                accountType: COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL
            }
        };

        return cifParam;
    }

    private getAccountBalanceParams() {
        this.accountBalanceParam = {
            path: CoreBankingConstants.ApiPathConsts.ACCOUNT_BALANCE_INQUIRY,
            tabletApplyId: this.state.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            params: {
                bankNo: CoreBankingConst.bankNo,                                 // 銀行番号
                receptionTenban: this.state.submitData.receptionBranchNo,  // 受付店番
                receptionNo: this.state.submitData.receptionNo,            // 受付番号
                terminalNo: this.deviceService.getDeviceId(),            // 端末番号
                accountInfoList: [{
                    tenban: this.state.submitData.branchNo,
                    accountNo: this.state.submitData.accountNo,
                    accountType: COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL
                }]
            }
        };
    }

    /**
     * update tablet_apply information
     */
    private updateTabletApplyInfo() {
        const params = {
            tabletApplyId: this.store.getState().tabletApplyId,
            leaveReason: null,
            status: Constants.DBConsts.updateStatus.start,
            userMngNo: this.loginStore.getState().bankclerkId
        };

        this.action.branchStatusUpdate(params);
    }
}
