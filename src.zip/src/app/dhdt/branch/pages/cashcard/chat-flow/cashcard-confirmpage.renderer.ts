import { Injectable } from '@angular/core';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CashCardConfirmPageInputHandler } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-confirmpage.input-handler';
import { CashCardChatFlowQuestionTypes } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard.chat-flow-question-types';
import { CashCardState, CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { CardListComponent } from 'dhdt/branch/shared/components/card-list/card-list.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';

export const CASH_CARD_CONFIRM_PAGE_RENDERER_TYPE = 'CashCardConfirmPageComponent';

@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CASH_CARD_CONFIRM_PAGE_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-cashcard-confirmpage.yml'
})
export class CashCardConfirmPageRenderer extends DefaultChatFlowRenderer {
    public processType = 1;
    private state: CashCardState;

    constructor(private action: CashCardAction, private store: CashCardStore, private audioService: AudioService,
                inputHandler: CashCardConfirmPageInputHandler) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    @Renderer(CashCardChatFlowQuestionTypes.CARD)
    public onCard(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            type: entity.type,
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: CardListComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CashCardChatFlowQuestionTypes.BUTTON_THREE_COLS)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number): void {
        super.onButtonDefaultRenderer(entity, pageIndex);
    }

    @Renderer(CashCardChatFlowQuestionTypes.NUMBER_KEYBORD)
    public onNumberKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: NumberInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CashCardChatFlowQuestionTypes.PASSWORD_4BITS)
    public onPasswordInput(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: PasswordInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CashCardChatFlowQuestionTypes.SELECT_BRANCH)
    public onSelectBranch(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: SelectBranchComponent,
            data: entity.type,
            options: options
        }, entity, pageIndex);
    }

    /**
     * Show picker
     * @param entity params
     * @param pageIndex index in current chat flow
     */
    @Renderer([
        CashCardChatFlowQuestionTypes.PREFECTURE_PICKER,
        CashCardChatFlowQuestionTypes.COUNTRY_URBAN_VILLAGE_PICKER])
    public onPicker(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            defaultIndex: entity.options ? entity.options.defaultIndex : undefined,
            validationRules: entity.validationRules,
            submitData: this.state.submitData,
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: PickerCommonComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * Select street
     * @param entity params
     * @param pageIndex index in current chat flow
     */
    @Renderer(CashCardChatFlowQuestionTypes.SELECT_STREET)
    public onSelectStreet(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const params = {
            prefectureKanji: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillageKanji: this.state.submitData.holderAddressCountyUrbanVillage,
        };

        const options = {
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: SelectStreetComponent,
            data: params,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * onKeybord
     * @param entity params
     * @param pageIndex index in current chat flow
     */
    @Renderer(CashCardChatFlowQuestionTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getCashCardDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

}
