import { Injectable } from '@angular/core';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CashCardFamilyInputHandler } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-family.input-handler';
import { CashCardChatFlowQuestionTypes } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard.chat-flow-question-types';
import { CashCardState, CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { CardListComponent } from 'dhdt/branch/shared/components/card-list/card-list.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';

export const CASH_CARD_FAMILY_RENDERER_TYPE = 'CashCardFamilyComponent';

@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CASH_CARD_FAMILY_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-cashcard-family.yml'
})
export class CashCardFamilyRenderer extends DefaultChatFlowRenderer {
    public processType = 1;
    private state: CashCardState;

    constructor(private action: CashCardAction, private store: CashCardStore, inputHandler: CashCardFamilyInputHandler) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    @Renderer(CashCardChatFlowQuestionTypes.NUMBER_KEYBORD)
    public onNumberKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: NumberInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * パスワードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(CashCardChatFlowQuestionTypes.PASSWORD_4BITS)
    public onPasswordInput(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: PasswordInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CashCardChatFlowQuestionTypes.CARD)
    public onCard(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: CardListComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CashCardChatFlowQuestionTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getCashCardDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }
}
