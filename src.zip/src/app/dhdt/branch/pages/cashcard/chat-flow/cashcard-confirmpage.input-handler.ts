import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services/label.service';
import { DeviceService } from 'dhd/common/services/device.service';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CashCardChatFlowQuestionTypes } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard.chat-flow-question-types';
import { CashCardSignal, CashCardState, CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { CoreBankingConst, PasswordValidationType } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/existing-password-rule-check.interface';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';

@Injectable()
export class CashCardConfirmPageInputHandler extends DefaultChatFlowInputHandler {

    private state: CashCardState;

    constructor(private action: CashCardAction, private audioService: AudioService, private store: CashCardStore,
                private loginStore: LoginStore, private deviceService: DeviceService, private modalService: ModalService,
                private labelService: LabelService) {
        super(action);
        this.state = this.store.getState();
    }

    /**
     * 回答の登録と次のメッセージの取得のみを行うハンドラ。
     *
     * @private
     * @param {*} entity
     * @param {number} pageIndex
     * @param {*} answer
     * @memberof CashCardConfirmPageRenderer
     */
    @InputHandler(CashCardChatFlowQuestionTypes.NUMBER_KEYBORD)
    protected simpleHandler(entity: any, pageIndex: number, answer: any) {
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(CashCardChatFlowQuestionTypes.CARD)
    private onCardHandler(entity: any, pageIndex: number, answer: any): void {
        this.setAnswer({
            text: answer.text,
            value: [
                { key: entity.name, value: answer.value }
            ]
        });
        this.emitMessageRetrivalEvent(answer.next, pageIndex);
    }

    @InputHandler([
        CashCardChatFlowQuestionTypes.BUTTON,
        CashCardChatFlowQuestionTypes.BUTTON_THREE_COLS])
    private onButtonHandler(entity: any, pageIndex: number, answer: any): void {
        if (entity.name.length > 0 && answer.value.length > 0) {
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.value }
                ]
            });
        }
        if (entity.name === 'cashCardType') {
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: 'cashCardType', value: answer.value },
                    { key: 'cashCardTypeText', value: answer.text }
                ]
            });
        }
        if (answer.action.type.length > 0) {
            this.configAction(answer, pageIndex);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(CashCardChatFlowQuestionTypes.SELECT_BRANCH)
    private onSelectBranchHandler(entity: any, pageIndex: number, answer: any) {
        this.setAnswer(answer);

        if (answer.value) {
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        } else {
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        }
    }

    @InputHandler([
        CashCardChatFlowQuestionTypes.PREFECTURE_PICKER,
        CashCardChatFlowQuestionTypes.COUNTRY_URBAN_VILLAGE_PICKER])
    private onPickerHandler(entity: any, pageIndex: number, answer: any) {
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(CashCardChatFlowQuestionTypes.SELECT_STREET)
    private onSelectStreetHandler(entity: any, pageIndex: number, result: { isSkip: boolean, text: string, value: any }) {
        const answer = {
            text: result.text,
            value: [
                { key: 'holderAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                { key: 'holderAddressStreetNameFuriKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) }
            ]
        };
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(result.isSkip ? entity.skip : entity.next, pageIndex);
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'admin') {
            this.audioService.subject.next(true);
            this.chatFlowCompelete();
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }

    @InputHandler(CashCardChatFlowQuestionTypes.KEYBOARD)
    private onKeybordHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
            this.setAnswer({ text: answer.text, value: results });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
    }

    @InputHandler(CashCardChatFlowQuestionTypes.PASSWORD_4BITS)
    private onPasswordInputHandler(entity: any, pageIndex: number, answer: any) {
        // 暗証番号ルール適合性チェックハンドルを追加
        this.store.registerSignalHandler(CashCardSignal.GET_PASSWORD_RULE, (data) => {
            this.store.unregisterSignalHandler(CashCardSignal.GET_PASSWORD_RULE);
            if (data.response.values.result === '1') {
                const buttonList = [
                    { text: 'OK', buttonValue: 'ok' },
                ];
                this.modalService.showAlert(
                    this.labelService.labels.error.passwordError,
                    null, 'icon_alert@2x.png', buttonList, 'settings-alert-modal',
                    () => {
                        this.action.resetLastNode();
                    }
                );
            } else {
                this.setAnswer(answer);
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            }
        });

        // 暗証番号ルール適合性チェックを行う
        const param: ExistingPasswordRuleCheckInterface = {
            tabletApplyId: this.state.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            path: CoreBankingConstants.ApiPathConsts.PASSWORD_RULE_CHECK,
            params: {
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                passcodeType: PasswordValidationType.PASSWORD_4BITS,
                passcode: answer.value[0].value,
                tenban: this.state.submitData.branchNo,
                accountNo: this.state.submitData.accountNo,
                branchCif: this.state.submitData.swipeCif
            }
        };
        this.action.checkExistingCustomerPasswordRule(param);
    }
}
