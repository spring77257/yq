import { Injectable } from '@angular/core';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CashCardChatFlowQuestionTypes } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard.chat-flow-question-types';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';

@Injectable()
export class CashCardPasswordInputHandler extends DefaultChatFlowInputHandler {

    constructor(action: CashCardAction) {
            super(action);
    }

    @InputHandler(CashCardChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        if (answer.action.type === 'route') {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }
}
