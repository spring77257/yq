import { Injectable } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { InjectionUtils } from 'adep/utils';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';

export namespace ConfirmPageComponentParamName {
    // キャッシュカード
    export const CASHCARD_FAMILYNAME: string = 'CASHCARD_FAMILYNAME';
    export const FAMILY_RELATIONSHIP: string = 'FAMILY_RELATIONSHIP';
    export const CASHCARD_FAMILYDESIGN: string = 'CASHCARD_FAMILYDESIGN';
    export const CASHCARD_TYPE: string = 'CASHCARD_TYPE';
    export const CASHCARD_BRANCHNAMEKANJI: string = 'CASHCARD_BRANCHNAMEKANJI';
    export const ACCOUNT_NO: string = 'ACCOUNT_NO';
    export const CASHCARD_DESIGN: string = 'CASHCARD_DESIGN';
    export const CASHCARD_PASSWORD: string = 'CASHCARD_PASSWORD';
    export const CASHCARD_FAMILY_PASSWORD: string = 'CASHCARD_FAMILY_PASSWORD';
}

export namespace ChartID {
    // キャッシュカード
    export const CASHCARD_CONFIRM: Number = 99;
}

@Injectable()
export class CashCardConfirmPageCommonService extends BaseComponent {
    private params: Map<string, any>;
    private action: CashCardAction;

    constructor() {
        super();
        this.action = InjectionUtils.injector.get(CashCardAction);
        this.params = new Map();
    }

    public loadConfirmTemplate() {
        this.action.loadConfirmPageTemplate('chat-flow-def-cashcard-confirmpage.yml', 99);
    }

    // キャッシュカード
    public getCashCardConfirmPageComponentParams() {
        const params: Map<string, any> = new Map();
        // おなまえ
        params.set(ConfirmPageComponentParamName.CASHCARD_FAMILYNAME,
            {
                startOrder: 1, endOrder: 2, name: 'cashCardFamilyName',
                currentTitle: this.labels.cashcard.family.name, pageIndex: ChartID.CASHCARD_CONFIRM
            });
        // お客さまとの関係
        params.set(ConfirmPageComponentParamName.FAMILY_RELATIONSHIP,
            {
                startOrder: 3, endOrder: 4, name: 'familyRelationship',
                currentTitle: this.labels.cashcard.family.relation, pageIndex: ChartID.CASHCARD_CONFIRM
            });
        // 家族用カードデザイン
        params.set(ConfirmPageComponentParamName.CASHCARD_FAMILYDESIGN,
            {
                startOrder: 13, endOrder: 13, name: 'cashCardFamilyDesign',
                currentTitle: this.labels.cashcard.family.cardDesign, pageIndex: ChartID.CASHCARD_CONFIRM
            });
        // 発行対象
        params.set(ConfirmPageComponentParamName.CASHCARD_TYPE,
            {
                startOrder: 5, endOrder: 6, name: 'cashCardType',
                currentTitle: this.labels.cashcard.selfCard.cardType, pageIndex: ChartID.CASHCARD_CONFIRM
            });
        // 対象店舗
        params.set(ConfirmPageComponentParamName.CASHCARD_BRANCHNAMEKANJI,
            {
                startOrder: 7, endOrder: 7, name: 'branchNameKanji',
                currentTitle: this.labels.cashcard.selfCard.shop, pageIndex: ChartID.CASHCARD_CONFIRM
            });
        // 口座番号
        params.set(ConfirmPageComponentParamName.ACCOUNT_NO,
            {
                startOrder: 8, endOrder: 8, name: 'accountNo',
                currentTitle: this.labels.cashcard.selfCard.accountNo, pageIndex: ChartID.CASHCARD_CONFIRM
            });
        // 本人用カードデザイン
        params.set(ConfirmPageComponentParamName.CASHCARD_DESIGN,
            {
                startOrder: 9, endOrder: 9, name: 'cashCardDesign',
                currentTitle: this.labels.cashcard.selfCard.cardDesign, pageIndex: ChartID.CASHCARD_CONFIRM
            });
        // 本人用カード暗証番号
        params.set(ConfirmPageComponentParamName.CASHCARD_PASSWORD,
            {
                startOrder: 10, endOrder: 11, name: 'cashCardPassword',
                currentTitle: this.labels.cashcard.password.selfCard, pageIndex: ChartID.CASHCARD_CONFIRM
            });
        // 家族カード暗証番号
        params.set(ConfirmPageComponentParamName.CASHCARD_FAMILY_PASSWORD,
            {
                startOrder: 14, endOrder: 15, name: 'cashCardFamilyPassword',
                currentTitle: this.labels.cashcard.password.familyCard, pageIndex: ChartID.CASHCARD_CONFIRM
            });
        return params;
    }
}
