import { AfterViewChecked, Component, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CASH_CARD_COMMON_RENDERER_TYPE } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-common.renderer';
import { CASH_CARD_FAMILY_RENDERER_TYPE } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-family.renderer';
import { CASH_CARD_MENU_RENDERER_TYPE } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-menu.renderer';
import { CashCardSignal, CashCardState, CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { COMMON_CONSTANTS, Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import {
    AbstractChatFlowControlComponent
} from 'dhdt/branch/shared/modules/chat-flow/components/abstract-chat-flow-control.component';
import {
    ChatFlowHeaderInterfaces,
    ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { Content, NavParams } from 'ionic-angular';

/**
 * CashCardに関わるChatFlowを制御する。
 *
 * @export
 * @class CashCardChatComponent
 * @extends {AbstractChatFlowControlComponent}
 * @implements {OnInit}
 * @implements {OnDestroy}
 */
@Component({
    selector: 'cashcard-chat-component',
    templateUrl: 'cashcard-chat.component.html'
})
export class CashCardChatComponent extends AbstractChatFlowControlComponent implements OnInit, OnDestroy, AfterViewChecked {
    @ViewChild(Content) public content: Content;
    public state: CashCardState;
    public headerOptions: ChatFlowHeaderInterfaces.Options;

    constructor(private store: CashCardStore, private action: CashCardAction, private loginStore: LoginStore,
                injector: Injector) {
        super(action, injector);

        action.getConsumptionTax();

        this.state = this.store.getState();
    }

    /**
     * 初期化処理として以下を行う。
     * * `AbstractChatFlowControlComponent`の初期化メソッド(`initChatFlowControl`)を実行する。
     * * `ChatFlowHeaderComponent`用のオプションをセットアップする。
     * * Storeからのシグナルを登録する。
     *
     * @memberof CashCardChatComponent
     */
    public ngOnInit() {
        this.initChatFlowControl();
        this.setupHeaderOptions();

        // 読み込むQRコード情報をこのフローに設定する
        this.action.setSwipeInfo({
            swipeInfo: this.chatFlowNavParam.swipeInfo,
            tabletApplyId: this.chatFlowNavParam.tabletApplyId
        });

        if (this.chatFlowNavParam.swipeInfo && this.chatFlowNavParam.swipeInfo.cardBranchNo) {
            this.action.getBranchName({params: {
                branchCode: this.chatFlowNavParam.swipeInfo.cardBranchNo
            }});
        }

        this.store.registerSignalHandler(CashCardSignal.CHAT_FLOW_COMPELETE, (nextComponentType) => {
            this.onChatFlowComplete(nextComponentType, TopComponent);
        });
        this.store.registerSignalHandler(CashCardSignal.GET_QUESTION, (pageIndex: number) => {
            this.onYamlDidLoad(pageIndex);
        });
        this.store.registerSignalHandler(CashCardSignal.SEND_ANSWER, (data) => {
            this.onNextMessage(data);
        });
        this.store.registerSignalHandler(CashCardSignal.GET_NEXT_CHAT_MESSAGE, ({ nextOrder, pageIndex }) => {
            this.getNextChatMessage(nextOrder, pageIndex);
        });
    }

    /**
     * クリーンアップ処理として以下を行う。
     * * `AbstractChatFlowControlComponent`のクリーンアップメソッド(`destoyChatFlowControl`)を実行する。
     * * Storeシグナルの登録を解除する。
     *
     * @memberof CashCardChatComponent
     */
    public ngOnDestroy() {
        this.destoyChatFlowControl();
        this.store.unregisterSignalHandler(CashCardSignal.CHAT_FLOW_COMPELETE);
        this.store.unregisterSignalHandler(CashCardSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(CashCardSignal.SEND_ANSWER);
        this.store.unregisterSignalHandler(CashCardSignal.GET_NEXT_CHAT_MESSAGE);
    }

    /**
     * ViewCheck後（Viewが変更された後）にメッセージコンテナを最下部へスクロールする。
     *
     * @memberof CashCardChatComponent
     */
    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    public get headerTitle(): string {
        return this.labels.cashcard.title;
    }

    public get processItems() {
        return [
            {
                type: COMMON_CONSTANTS.ProcessType.RequiredInput,
                value: this.labels.processType.requiredInput
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyInfoConfirm,
                value: this.labels.processType.applyInfoConfirm,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.BankClerkConfirm,
                value: this.labels.processType.bankClerkConfirm,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
                value: this.labels.processType.completion,
            }
        ];
    }

    /**
     * update tablet_apply information
     */
    public updateTabletApplyInfo() {
        const params = {
            status: Constants.DBConsts.updateStatus.exception,
            numberTag: this.state.submitData.receptionNo,
            numberTagPublishDate: this.state.submitData.receptionTime ?
                this.state.submitData.receptionTime.substring(0, 14) : '',
            agencyBranchNo: this.state.submitData.receptionBranchNo,
            userMngNo: this.loginStore.getState().bankclerkId
        };
        this.action.branchStatusUpdate(params);
    }

    protected getRendererNameByIndex(index: number) {
        const componentNameMap = {
            1: CASH_CARD_COMMON_RENDERER_TYPE,
            3: CASH_CARD_FAMILY_RENDERER_TYPE
        };
        let componentName = componentNameMap[index];
        if (!componentName) {
            componentName = this.state.submitData.businessType ? CASH_CARD_COMMON_RENDERER_TYPE : CASH_CARD_MENU_RENDERER_TYPE;
        }
        return componentName;
    }

    protected branchStatusUpdate() {
        const leaveType = this.state.submitData.leaveType;
        const leaveReason = Constants.DBConsts.leaveReason[leaveType];
        const status = Constants.DBConsts.updateStatus[leaveType];

        const params = {
            tabletApplyId: this.store.getState().tabletApplyId,
            leaveReason: leaveReason,
            status: status,
            userMngNo: this.loginStore.getState().bankclerkId
        };

        this.action.branchStatusUpdate(params);
    }

    private setupHeaderOptions() {
        if (!this.chatFlowNavParam.isCurrentPage) {
            this.headerOptions = {
                showReturnTopButton: true,
                topComponent: TopComponent,
                title: this.headerTitle,
                needTwoBtnInLeftButton: true,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.CALL_CLERK
            };
        } else {
            this.headerOptions = {
                showReturnTopButton: false,
                title: this.chatFlowNavParam.currentTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
            };
        }
    }
}
