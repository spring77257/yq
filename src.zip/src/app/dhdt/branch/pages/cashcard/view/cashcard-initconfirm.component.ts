import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { DeviceService } from 'dhd/common/services/device.service';
import { CompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/completion.component';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { BusinessType, CashCardType } from 'dhdt/branch/pages/cashcard/cashcard-consts';
import { CashCardConfirmPageCommonService } from 'dhdt/branch/pages/cashcard/service/cashcard-confirmpage.common.service';
import { CashCardState, CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { COMMON_CONSTANTS, Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalController, NavController } from 'ionic-angular';

/**
 * 申込内容確認画面（キャッシュカード）
 */
@Component({
    selector: 'cashcard-initconfirm-component',
    templateUrl: 'cashcard-initconfirm.component.html'
})
export class CashCardInitConfirmComponent extends BaseComponent implements OnInit {
    public processType = 2;
    public open: boolean = true;
    public state: CashCardState;
    public confirmPageCommonParams: Map<string, any> = null;
    public changeHolderMobileNoFlag: boolean = false;
    public saveShowChats: any = {};

    public isSelfApplyConfirm: boolean = false;  // distinguish 申込内容確認 from (行員確認用)ご本人確認
    public receiptMethodOK: boolean = false; // カードお受取方法 checkbox validate result
    public pwdText: string;
    public firstAndForget: boolean = false;

    constructor(
        private navCtrl: NavController,
        private store: CashCardStore,
        private confirmPageCommonService: CashCardConfirmPageCommonService,
        private modalCtrl: ModalController,
        private deviceService: DeviceService,
        private action: CashCardAction,
        private logging: LoggingService,
    ) {
        super();
        this.state = this.store.getState();
    }

    public ngOnInit() {
        this.action.setCustomerApplyStartDate();
        this.confirmPageCommonService.loadConfirmTemplate();
        // get 修正 detail
        this.confirmPageCommonParams = this.confirmPageCommonService.getCashCardConfirmPageComponentParams();
        // chat
        this.state.showConfirm.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
        // 初めて発行と暗証番号忘れの場合、本人基本情報にカナ氏名しか表示しない
        this.firstAndForget = this.state.submitData.businessType === BusinessType.FIRST_ISSUE
                || this.state.submitData.businessType === BusinessType.FORGET_PASSWORD;
    }

    public get familyDisable() {
        if (this.state.submitData.cashCardType === CashCardType.SELF) {
            return false;
        }
        return true;
    }

    // カードお受取方法 emitter
    public receiptMethodCheckedEmitterHandler(receiptMethodOK: boolean) {
        this.receiptMethodOK = receiptMethodOK;
    }

    // footer button disable
    public footerBtnDisable() {
        // console.log('receiptMethodOK: ' + this.receiptMethodOK);
        // const btnValidate = this.receiptMethodOK;
        // return btnValidate;
        // 本人カードのみ申請する場合

        if (this.state.submitData.cashCardType === CashCardType.SELF) {
            if (!this.state.submitData.cashCardDesign
                || !this.state.submitData.cashCardFirstPwd4bits) {
                return true;
            }
        }

        // 本人カード＋家族カード申請する場合
        if (this.state.submitData.cashCardType === CashCardType.SELF_FAMILY) {
            if (!this.state.submitData.cashCardDesign
                || !this.state.submitData.cashCardFirstPwd4bits
                || !this.state.submitData.getFamilyName()
                || !this.state.submitData.getFamilyNameFurigana()
                || !this.state.submitData.familyRelationship
                || !this.state.submitData.cashCardFamilyDesign
                || !this.state.submitData.cashCardFamilyFirstPwd4bits) {
                return true;
            }
        }

        // 家族カードのみ申請する場合
        if (this.state.submitData.cashCardType === CashCardType.FAMILY) {
            if (!this.state.submitData.getFamilyName()
                || !this.state.submitData.getFamilyNameFurigana()
                || !this.state.submitData.familyRelationship
                || !this.state.submitData.cashCardFamilyDesign
                || !this.state.submitData.cashCardFamilyFirstPwd4bits) {
                return true;
            }
        }
    }

    // click 'お申込み' button
    public moveToNextPage() {
        const param = {
            tabletApplyId: this.state.tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            terminalNo: this.deviceService.getDeviceId(),
            accountNo: this.state.submitData.accountNo,
            tenban: this.state.submitData.branchNo,
            accountType: this.state.submitData.accountType
        };

        if (this.state.submitData.businessType === BusinessType.BROKEN) {
            this.pwdText = this.labels.cashcard.brokenPwdTitle;
        } else if (this.state.submitData.businessType === BusinessType.LOST) {
            this.pwdText = this.labels.cashcard.lostPwdTitle;
        } else {
            this.pwdText = this.labels.cashcard.passwordTitle;
        }

        const data: any = {
            text: this.labels.cashcard.pwdTitle,
            subText: this.pwdText,
            units: 4,
            needConfirm: false,
            cashcardParams: param,
            inputPassword: undefined
        };

        // スワイプなし、かつ初めて発行と暗証番号忘れの場合、お先にCIF情報照会を取得する
        if (!this.state.submitData.swipeAccountNo
            && (this.state.submitData.businessType === BusinessType.FIRST_ISSUE
                || this.state.submitData.businessType === BusinessType.FORGET_PASSWORD)
            && this.state.submitData.cashCardType !== CashCardType.FAMILY) {
            data.needConfirm = true;
            data.inputPassword = this.state.submitData.cashCardFirstPwd4bits;
        }

        const modal = this.modalCtrl.create(ModalPasswordComponent,
            {
                data: data
            },
            { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.onDidDismiss((value, responseValues: any) => {
            if (!value) {
                return;
            }

            if (!data.needConfirm) {
                if (!responseValues) {
                    return;
                }
            }

            this.action.setCustomerApplyEndDate();
            this.navCtrl.push(CompletionComponent);
        });
        modal.present();
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo[0].screenId,
            this.labels.logging.InfoComfirm.ApplyButton,
        );
    }

}
