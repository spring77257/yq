import { Component, OnDestroy, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { ApplyBusinessType, BusinessType, CashCardType } from 'dhdt/branch/pages/cashcard/cashcard-consts';
import { CashCardConfirmPageCommonService } from 'dhdt/branch/pages/cashcard/service/cashcard-confirmpage.common.service';
import { CashCardSignal, CashCardState, CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { CashCardInitConfirmComponent } from 'dhdt/branch/pages/cashcard/view/cashcard-initconfirm.component';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ModalDigitalStore } from 'dhdt/branch/shared/components/modal/modal-digital/store/modal-digital.store';
import { DocumentCategoryService } from 'dhdt/branch/shared/modules/document-category/service/document-category.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { CashCardPrepareDataUtil } from 'dhdt/branch/shared/utils/cashcard-prepare-data-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { NavController } from 'ionic-angular';
import { ViewController } from 'ionic-angular/navigation/view-controller';

@Component({
    selector: 'cashcard-account-component',
    templateUrl: 'cashcard-account.component.html'
})

/**
 * CashCardAccount component(行員確認画面).
 */
export class CashCardAccountComponent extends BaseComponent implements OnInit, OnDestroy {
    public processType = 3;
    public state: CashCardState;
    public confirmPageCommonParams: Map<string, any> = null;
    public saveShowChats: any = {};
    public receiptMethodOK: boolean = false; // カードお受取方法 checkbox validate result
    // #22427: 暗証忘れと破損・磁気不良の場合に、チェックボックスをチェックされていないと「認証する」ボタンが活性化されない
    public selected = false;

    private insertImageType: string = COMMON_CONSTANTS.InsertImageType.image;

    constructor(
        private navCtrl: NavController,
        private store: CashCardStore,
        private confirmPageCommonService: CashCardConfirmPageCommonService,
        private cashCardPrepareDataUtil: CashCardPrepareDataUtil,
        private action: CashCardAction,
        private modalDigitalStore: ModalDigitalStore,
        private modalService: ModalService,
        private savingsAction: SavingsAction,
        private cancelAction: CancelAction,
        private categoryService: DocumentCategoryService,
        private viewCtrl: ViewController,
        private logging: LoggingService,
    ) {
        super();
        this.state = this.store.getState();
        this.viewCtrl.willEnter.subscribe(() => this.categoryService.addObserver((data) => {
            this.action.setDocumentCategory(data);
        }, this));

        this.viewCtrl.willLeave.subscribe(() => this.categoryService.removeObserver(this));
    }
    public ngOnInit() {
        this.action.setBankclerkAuthenticationStartDate();
        this.getApplyBusinessType();
        // get 修正 detail
        this.confirmPageCommonParams = this.confirmPageCommonService.getCashCardConfirmPageComponentParams();
        // chat
        this.state.showConfirm.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
        this.pushNextPage();
    }
    public ngOnDestroy(): void {
        this.unregisterSignalHandlers();
        this.clearMemory();
    }
    public pushNextPage() {
        this.store.registerSignalHandler(CashCardSignal.SUCCESS_INSERT_INFO, () => {
            this.modalService.showCompleteModal().subscribe({
                next: (event) => {
                    switch (event) {
                        case COMMON_CONSTANTS.BACK_TYPE_REAPPLY_MENU:
                            this.navCtrl.setRoot(ChatComponent, { reapplyFlg: true });
                            break;
                        default:
                            this.navCtrl.setRoot(TopComponent);
                    }
                },
                complete: () => {
                    this.savingsAction.clearStore();
                    this.cancelAction.clearStore();
                }
            });
        });
    }

    public updataSubmitData(item) {
        this.action.setStateSubmitDataValue(item);
    }

    /**
     * 申込内容確認へ戻る
     */
    public returnBack() {
        this.action.clearStoreDocuments();
        this.navCtrl.push(CashCardInitConfirmComponent);
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo[0].screenId,
            this.labels.logging.AccountConfirm.backConfirmButton,
        );
    }

    public get familyDisable() {
        if (this.state.submitData.cashCardType === CashCardType.SELF) {
            return false;
        }
        return true;
    }

    public submit() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo[0].screenId,
            this.labels.logging.AccountConfirm.confirmButton,
        );
        // キャッシュカード発行
        this.action.saveCashcardData(this.processSubmitData());
    }
    public processSubmitData(): any {
        // 行員登録画面に遷移するとき、入力する行員IDを記録する
        this.action.setBankclerkId(this.modalDigitalStore.getState().bankclerkId);
        return this.cashCardPrepareDataUtil.prepareCashcardSavingsSubmitData(this.state);
    }

    public unregisterSignalHandlers() {
        this.store.unregisterSignalHandler(CashCardSignal.SUCCESS_INSERT_INFO);
    }

    public get disabledNextButton() {
        if (!(this.state.submitData.businessType === '1') || this.state.submitData.holderIdentityDocumentType) {
            return false;
        }
        return true;
    }

    /**
     * validation check
     */
    public checkInputValidation() {
        // #22427: 暗証忘れと破損・磁気不良の場合に、チェックボックスをチェックされていないと「認証する」ボタンが活性化されない
        if (this.showCheckBox() && !this.selected) {
            return false;
        }

        if (this.state.identityDocuments && this.state.identityDocuments.length > 0) {
            return true;
        }

        if (this.state.submitData.holderNoCopyReason || this.state.submitData.holderPublisher ||
            this.state.submitData.holderPublishDate || this.state.submitData.holderSignNo) {
            if (this.state.submitData.holderNoCopyReason) {
                return StringUtils.validateZenkaku(this.state.submitData.holderNoCopyReason);
            }
            return true;
        }

        return false;
    }

    /**
     * 顔写真のある本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedEmitter(event?: any) {
        this.insertImageType = event || this.insertImageType;
    }

    /**
     * カードお受取方法 emitter
     * @param receiptMethodOK flag for checkbox
     */
    public receiptMethodCheckedEmitterHandler(receiptMethodOK: boolean) {
        this.receiptMethodOK = receiptMethodOK;
    }

    /**
     * #22427: 暗証忘れと破損・磁気不良の場合に、チェックボックスをチェックされていないと「認証する」ボタンが活性化されない
     * @returns true: show
     */
    public showCheckBox(): boolean {
        return (this.state.submitData.businessType === BusinessType.FORGET_PASSWORD) ||
            (this.state.submitData.businessType === BusinessType.BROKEN);
    }

    // 申込業務区分 取得
    private getApplyBusinessType() {
        let applyBusinessType = ApplyBusinessType.RE;
        switch (this.state.submitData.businessType) {
            case BusinessType.FIRST_ISSUE: {

                applyBusinessType = ApplyBusinessType.FIRST;
                break;
            }
            case BusinessType.FORGET_PASSWORD: {
                applyBusinessType = ApplyBusinessType.CHANGE;
                break;
            }
            case BusinessType.BROKEN: {
                applyBusinessType = ApplyBusinessType.BROKEN;
                break;
            }
        }
        this.action.setStateSubmitDataValue({ name: 'applyBusinessType', value: applyBusinessType });
    }

    private clearMemory() {
        this.action.clearStore();
    }
}
