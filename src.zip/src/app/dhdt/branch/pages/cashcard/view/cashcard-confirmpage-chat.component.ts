import { AfterViewChecked, Component, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ObjectUtils } from 'adep/utils';
import { CashCardAction } from 'dhdt/branch/pages/cashcard/action/cashcard.action';
import { CASH_CARD_CONFIRM_PAGE_RENDERER_TYPE } from 'dhdt/branch/pages/cashcard/chat-flow/cashcard-confirmpage.renderer';
import { CashCardSubmitEntity } from 'dhdt/branch/pages/cashcard/entity/cashcard-questions.model';
import { CashCardSignal, CashCardState, CashCardStore } from 'dhdt/branch/pages/cashcard/store/cashcard.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import {
    AbstractChatFlowControlComponent
} from 'dhdt/branch/shared/modules/chat-flow/components/abstract-chat-flow-control.component';
import {
    ChatFlowHeaderInterfaces,
    ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { Content } from 'ionic-angular';

@Component({
    selector: 'cashcard-confirmpage-chat-component',
    templateUrl: 'cashcard-chat.component.html'
})

/**
 * control all chat page.
 */
export class CashCardConfirmPageChatComponent extends AbstractChatFlowControlComponent implements OnInit, OnDestroy, AfterViewChecked {
    @ViewChild(Content) public content: Content;
    public state: CashCardState;
    public headerOptions: ChatFlowHeaderInterfaces.Options;

    private originShowChats: any[];
    private originShowConfirm: any[];
    private originSubmitData: CashCardSubmitEntity;
    private processHidden: -1;

    constructor(private store: CashCardStore, private action: CashCardAction, injector: Injector) {
        super(action, injector);
        this.state = this.store.getState();
        this.originShowChats = [...this.state.showChats];
        this.originShowConfirm = [...this.state.showConfirm];
        this.originSubmitData = ObjectUtils.clone(this.state.submitData);
    }

    public ngOnInit() {
        this.initChatFlowControl();
        this.chatFlowNavParam.needPassword = false;
        this.setupHeaderOptions();
        this.initializeChatComponent();
        this.store.registerSignalHandler(CashCardSignal.SEND_ANSWER, (data) => {
            this.onNextMessage(data);
        });
    }

    public ngOnDestroy() {
        this.destoyChatFlowControl();
        this.action.resetShowChats(this.originShowChats);
        this.store.unregisterSignalHandler(CashCardSignal.SEND_ANSWER);
    }

    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    public get headerTitle(): string {
        return this.labels.cashcard.title;
    }

    public get processType() {
        return this.chatFlowNavParam.isCurrentPage ? this.processHidden : this.processType;
    }

    public get processItems() {
        return this.chatFlowNavParam.isCurrentPage ? [] : [
            {
                type: COMMON_CONSTANTS.ProcessType.RequiredInput,
                value: this.labels.processType.requiredInput
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyInfoConfirm,
                value: this.labels.processType.applyInfoConfirm
            },
            {
                type: COMMON_CONSTANTS.ProcessType.BankClerkConfirm,
                value: this.labels.processType.bankClerkConfirm
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
                value: this.labels.processType.completion
            }
        ];
    }

    public cancelEmitterHandler() {
        super.cancelEmitterHandler();
        this.action.resetShowConfirm(this.originShowConfirm);
        this.action.resetShowChats(this.originShowChats, this.originSubmitData);
    }

    /**
     * update tablet_apply information
     */
    public updateTabletApplyInfo() {
        return;
    }

    protected getRendererNameByIndex(index: number): string {
        return index === 99 ? CASH_CARD_CONFIRM_PAGE_RENDERER_TYPE : undefined;
    }
    protected branchStatusUpdate(): void {
        throw new Error('Method not implemented.');
    }

    private initializeChatComponent() {
        this.action.submitDataBackup();
        this.action.clearShowChats();
    }

    private setupHeaderOptions() {
        if (!this.chatFlowNavParam.isCurrentPage) {
            this.headerOptions = {
                showReturnTopButton: true,
                topComponent: TopComponent,
                title: this.headerTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.CALL_CLERK
            };
        } else {
            this.headerOptions = {
                showReturnTopButton: false,
                title: this.chatFlowNavParam.currentTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
            };
        }
    }
}
