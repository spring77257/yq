import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ChatFlowHeaderInterfaces } from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';

/**
 * 解約用ツールクラス Utilities.
 */
@Injectable()
export class ClerkUtil {
    private labelService: LabelService;
    private labels: any;

    constructor(
    ) {
        this.labelService = InjectionUtils.injector.get(LabelService);
        this.labels = this.labelService.labels;
    }

    /**
     * Navigationを取得する。
     */
    public getProcessItems(): ChatFlowHeaderInterfaces.ProcessItemInput[] {
        return [
            {
                type: COMMON_CONSTANTS.ProcessType.RequiredInput,
                value: this.labels.processType.requiredInput,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.BankClerkConfirm,
                value: this.labels.processType.bankClerkConfirm,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
                value: this.labels.processType.completion,
            }
        ];
    }

}
