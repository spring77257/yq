/**
 * 解約用定数 Constants.
 */
export namespace ClerkConsts {

    /**
     * チャット番号
     */
    export enum ChatOrder {
        /** TOPに戻る */
        BACK_TO_TOP = 9900,
    }

    /**
     * 業務コード
     */
    export enum BussinessCode {
        /** CC少額預金解約 */
        active = '18',
        /** CC睡眠預金解約 */
        inActive = '19',
        /** 受付対象外 */
        notAccepted = '99'
    }

    /**
     * 入力可能な解約口座科目
     */
    export enum AvailableAccountType {
        /** 当座 */
        current = '11',
        /** 普通 */
        savings = '12',
        /** 貯蓄 */
        deposit = '13',
        /** 納税準備 */
        taxPrepare = '14',
        /** 通知 */
        notification = '16',
        /** 別段 */
        separateDeposit = '19',
        /** 定期 */
        fixedDeposit = '20',
        /** 積立定期 */
        installmentDeposit = '26',
        /** 外貨普通（勘定系） */
        foreignCurrencySavingsForSystem = '32',
        /** 外貨定期（勘定系） */
        foreignCurrencyFixedDepositForSystem = '34',
        /** 外貨普通（タブレット用） */
        foreignCurrencySavings = '71',
        /** 外貨定期（タブレット用） */
        foreignCurrencyFixedDeposit = '73',
        /** 普通・貯蓄（CRM整理済口座情報） */
        savingsOrDeposit = '99'
    }

    /**
     * 課税コード
     */
    export enum TaxationCode {
        /** 分離課税 */
        separation = '02',
        /** 課税 */
        taxation = '98'
    }

    /**
     * 商品コード
     */
    export enum ProductCode {
        /** 普通預金 */
        savings = '2101',
        /** 決済用普通預金 */
        settlement = '2301',
        /** 目的預金専用普通預金 */
        purpose = '2114',
        /** 競馬電話投票専用普通預金 */
        spat4 = '2104',
        /** 貯蓄預金 */
        deposit = '3101',
        /** 納税準備預金 */
        taxPrepare = '4101'
    }

    /**
     * 通帳証書区分
     */
    export enum PassbookCategory {
        /** 通帳 */
        passbook = '1',
        /** 証書 */
        certificate = '2',
        /** リーフ口 */
        leaf = '3',
        /** 媒体不発行 */
        web = '9'
    }

    /**
     * 受付対象の重要用紙種類コード
     */
    export enum PassbookTypeCode {
        /** 普通預金通帳（新） */
        savingsNew = '1201',
        /** 普通預金通帳（旧） */
        savingsOld = '1281',
        /** 普通預金通帳（継） */
        savingsCarry = '1291',
        /** 総合口座通帳（新） */
        multipurposeAccountNew = '1202',
        /** 総合口座通帳（旧） */
        multipurposeAccountOld = '1282',
        /** 総合口座通帳（継） */
        multipurposeAccountCarry = '1292',
        /** ワンセット通帳（新） */
        onesetNew = '1203',
        /** ワンセット通帳（継） */
        onesetCarry = '1293',
        /** 貯蓄預金通帳（新） */
        depositNew = '1301',
        /** 貯蓄預金通帳（旧） */
        depositOld = '1381',
        /** 貯蓄預金通帳（継） */
        depositCarry = '1391',
        /** 納税準備預金通帳（新） */
        taxPrepareNew = '1401',
        /** 納税準備預金通帳（旧） */
        taxPrepareOld = '1481',
        /** 納税準備預金通帳（継） */
        taxPrepareCarry = '1491',
        /** 定期預金通帳（新） */
        timeDepositNew = '2001',
        /** 別冊式定期預金通帳（新） */
        separateTimeDepositNew = '2002',
        /** 定期預金通帳（旧） */
        timeDepositOld = '2081',
        /** 別冊式定期預金通帳（旧） */
        separateTimeDepositOld = '2082',
        /** 定期預金通帳（継） */
        timeDepositCarry = '2091',
        /** 別冊式定期預金通帳（継） */
        separateTimeDepositCarry = '2092',
        /** 積立定期預金通帳（新） */
        installmentDepositNew = '2601',
        /** 積立定期預金通帳（旧） */
        installmentDepositOld = '2681',
        /** 積立定期預金通帳（継） */
        installmentDepositCarry = '2691',
        /** 積立スーパーステップ通帳（継） */
        superStepCarry = '2693',
        /** 積立型自由期間通帳（継） */
        freePeriodCarry = '2694',
        /** スーパーロイヤルプラン積立定期預金通帳（継） */
        superRoyalPlanCarry = '2692',
        /** 積立預金型・積立定期預金通帳（新） */
        accumulationTypeInstallmentDepositNew = '2645',
        /** 積立預金型・積立定期預金通帳（旧） */
        accumulationTypeInstallmentDepositOld = '2685',
        /** 積立預金型・積立定期預金通帳（継） */
        accumulationTypeInstallmentDepositCarry = '2695',
    }

    /**
     * カード区分
     */
    export enum CardClass {
        /** キャッシュカード */
        CASH = '1',
        /** ローンカード */
        LOAN = '2',
        /** バンクカード */
        BC = '3'
    }

    /**
     * 受付対象のカード種類
     */
    export enum CardType {
        /** 普通預金磁気キャッシュカード */
        magneticCash = '01',
        /** 普通預金磁気キャッシュカード（デザイン） */
        magneticCashDesign = '02',
        /** 普通預金ICキャッシュカード */
        icCash = '03',
        /** ワンセットカード */
        oneSet = '04',
        /** 競馬カード */
        horserace = '05',
        /** フォトIDカード */
        photoID = '06',
        /** 貯蓄預金磁気キャッシュカード */
        magneticDeposit = '21',
        /** 貯蓄預金磁気キャッシュカード（デザイン） */
        magneticDepositDesign = '22',
        /** 貯蓄預金ICキャッシュカード */
        icDepositDesign = '23',
        /** 横浜バンクカードVISA */
        bcVISA = '41',
        /** 横浜バンクカードマスター */
        bcMaster = '42',
        /** 横浜バンクカードヤングゴールド20s */
        bcYoungGold = '51',
        /** 横浜バンクカードゴールド */
        bcGold = '61',
    }

    /**
     * 受付対象外の振替口番種類コード
     */
    export enum TransferAccountTypeCode {
        /** 住宅金融公庫顧客 */
        housingLoanCorporationCustomer = '20',
        /** 定期利息振替口座 */
        fixedInterestTransferAccount = '30',
        /** 積定年金振替口座 */
        installmentPensionTransferAccount = '41',
        /** 積定自動解約口座 */
        installmentAutomaticCancellationAccount = '42',
        /** 債券利金償還金口座 */
        bondInterestRedemptionMoneyAccount = '43',
        /** 投信解約金口座 */
        investmentTrustCancellationMoneyAccount = '45',
        /** 財形資金決済口座 */
        propertySettlementAccount = '46',
        /** 資金集中配分振替口座 */
        fundConcentrationAllocationTransferAccount = '67',
        /** 融資振替口座 */
        loanTransferAccount = '70',
        /** カードローン振替口座、ATMCL振替口座 */
        cardLoanTransferAccount = '80',
        /** 外為取引先振替口座 */
        externalAttractionTransferAccount = '81',
        /** 外貨定額自動振替口座 */
        foreignCurrencyAutomaticTransferAccount = '82'
    }

    /**
     * 受付対象の振替口番種類名
     */
    export enum AvailableTransferAccountType {
        /** バンクカードローン */
        BankCardLoan = 'バンクカードローン',
        /** 定期総合口座 */
        fixedCompoundAccount = '定期総合口座'
    }

    /**
     * フラグ表示
     */
    export enum Status {
        ON = '1',
        OFF = '0',
        SECOND = '2'
    }

    export enum ReceptionCheckBusinessCode {
        /** 業務共通のNGチェック(MVP4) */
        NG = '30',
        /** CC少額預金解約 */
        ACTIVE_ACCOUNTS_CANCEL = '31',
        /** CC窓口睡眠解約 */
        INACTIVE_ACCOUNTS_CANCEL = '32',
        /** CC少額預金解約 - 普通・貯蓄・納準 */
        ACTIVE_ACCOUNTS_CANCEL_ORDINARY = '33',
        /** CC少額預金解約 - 総合定期・総合積定 */
        ACTIVE_ACCOUNTS_CANCEL_TIME_DEPOSIT = '34',
        /** CC睡眠解約 - 普通・貯蓄・納準 */
        INACTIVE_ACCOUNTS_CANCEL_ORDINARY = '35',
        /** CC睡眠解約 - 当座・別段 */
        INACTIVE_ACCOUNTS_CANCEL_CURRENT = '36',
        /** CC睡眠解約 - 通知・定期・積定 */
        INACTIVE_ACCOUNTS_CANCEL_TIME_DEPOSIT = '37',
        /** CC睡眠解約 - 通知・定期（明細） */
        INACTIVE_ACCOUNTS_CANCEL_DEPOSITNO = '38',
        /** 店頭睡眠解約 */
        COUNTER_INACTIVE_ACCOUNTS_CANCEL = '44',
        /** 店頭睡眠解約 - 普通・貯蓄・納準 */
        COUNTER_INACTIVE_ACCOUNTS_CANCEL_ORDINARY = '40',
        /** 店頭睡眠解約 - 当座・別段 */
        COUNTER_INACTIVE_ACCOUNTS_CANCEL_CURRENT = '41',
        /** 店頭睡眠解約 - 通知・定期・積定 */
        COUNTER_INACTIVE_ACCOUNTS_CANCEL_TIME_DEPOSIT = '42',
        /** 店頭睡眠解約 - 通知・定期（明細） */
        COUNTER_INACTIVE_ACCOUNTS_CANCEL_DEPOSITNO = '43',
    }

    export enum UnacceptableCode {
        // エラーモーダルの1行に表示する注意コード最大数
        UNACCEPTABLE_CODE_MAX = 3,
    }

    /**
     * 口座状態
     */
    export enum AccountStatus {
        /** 活動中 */
        Active = '00',
        /** 閉鎖済または解約済 */
        Closed = '01',
        /** 雑益繰入済または休眠移管済 */
        Dormant = '05',
        /** 雑益繰入解約 */
        IncomeCancellation = '51',
        /** 不活動繰入解約 */
        InactiveCancellation = '52',
    }

    /**
     * 雑益繰入／休眠移管区分
     */
    export enum DormantDepositStatus {
        /** 雑益繰入済 */
        IncomeTransferred = '1',
        /** 休眠移管済 */
        DormantTransferred = '2',
        /** 雑益繰入支払済 */
        IncomePaid = '3',
        /** 休眠移管支払済 */
        DormantPaid = '4',
    }

    /**
     * 人格コード
     */
    export enum PersonalityCode {
        /** 個人 */
        Individual = '11',
        /** 個人事業主 */
        BusinessOwner = '13',
    }

    /**
     * RQ番号
     */
    export enum RequestNo {
        /** 通帳式定期解約 */
        PassbookFixedDeposit = '04410',
        /** 証書式定期解約 */
        CertificateFixedDeposit = '04400',
        /** 証書式通知解約 */
        CertificateNotification = '05400',
    }

    /**
     * 不活動口座検索結果
     */
    export enum InactiveAccountSearchStatus {
        // CRM元帳に口座あり
        Yes = '1',
    }

    /**
     * 店番
     */
    export enum BranchCode {
        /** CC（業務サポートオフィス） */
        CC = '186',
        /** 相続店 */
        INHERIT = '162'
    }

    /**
     * 複数通貨保有コード
     */
    export enum MultipleCurrencyCode {
        /** 複数通貨保有先の場合の通貨コード */
        MultipleCode = '99',
    }

    /**
     * 表示パターン
     */
    export enum Pattern {
        /** 少額預金解約 */
        ACTIVE = 'active',
        /** 雑益繰入/不活動繰入の外貨普通 */
        DORMANT_FOREIGN_CURRENCY_SAVINGS = 'dormantForeignCurrencySavings',
        /** 索引情報 */
        DORMANT = 'dormant',
        /** CRM整理済口座情報 */
        CRM = 'crm',
        /** 勘定系・CRM該当なし */
        NOT_APPLICABLE = 'notApplicable',
        /** CRM整理済口座情報（単科目定期） */
        CRM_FIXED_DEPOSIT = 'crmFixedDeposit',
    }
}
