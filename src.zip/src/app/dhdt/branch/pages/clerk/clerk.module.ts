import { NgModule, Type } from '@angular/core';
import { HttpModule } from '@angular/http';
import { ClerkAction } from 'dhdt/branch/pages/clerk/action/clerk.action';
import {
    AccountStatusInquiryCheckAcceptanceInputHandler
} from 'dhdt/branch/pages/clerk/chat-flow/account-status-inquiry-check-acceptance.input-handler';
import {
    AccountStatusInquiryCheckAcceptanceRenderer
} from 'dhdt/branch/pages/clerk/chat-flow/account-status-inquiry-check-acceptance.renderer';
import { AccountStatusInquiryOpeningInputHandler } from 'dhdt/branch/pages/clerk/chat-flow/account-status-inquiry-opening.input-handler';
import { AccountStatusInquiryOpeningRenderer } from 'dhdt/branch/pages/clerk/chat-flow/account-status-inquiry-opening.renderer';
import { ClerkInitInputHandler } from 'dhdt/branch/pages/clerk/chat-flow/clerk-init.input-handler';
import { ClerkInitRenderer } from 'dhdt/branch/pages/clerk/chat-flow/clerk-init.renderer';
import { ClerkStore } from 'dhdt/branch/pages/clerk/store/clerk.store';
import { ClerkUtil } from 'dhdt/branch/pages/clerk/utils/clerk-util';
import { ClerkChatComponent } from 'dhdt/branch/pages/clerk/view/clerk-chat.component';
import { LoginModule } from 'dhdt/branch/pages/common/login/login.module';
import { TopModule } from 'dhdt/branch/pages/common/top/top.module';
import { ConfirmPageCommonModule } from 'dhdt/branch/shared/components/confirmpage-common/confirmpage.common.module';
import { ModalPasswordModule } from 'dhdt/branch/shared/components/modal/modal-password/modal-password.module';
import { PickerModule } from 'dhdt/branch/shared/components/picker/picker.module';
import { SelectBankBranchModule } from 'dhdt/branch/shared/components/select-bank-branch/select-bank-branch.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular';

export const SHARED_FORM_COMPONENT: Array<Type<any>> = [
];

@NgModule({
    imports: [
        LoginModule,
        TopModule,
        IonicModule,
        SharedModule,
        HttpModule,
        PickerModule,
        ConfirmPageCommonModule,
        ModalPasswordModule,
        SelectBankBranchModule,
    ],
    declarations: [
        SHARED_FORM_COMPONENT,
        ClerkChatComponent,
    ],
    exports: [
        SHARED_FORM_COMPONENT,
        TopModule,
        ClerkChatComponent,
    ],
    entryComponents: [
        SHARED_FORM_COMPONENT,
        ClerkChatComponent,
    ],
    providers: [
        ClerkAction,
        ClerkStore,
        ClerkUtil,
        ClerkInitRenderer,
        AccountStatusInquiryOpeningRenderer,
        AccountStatusInquiryCheckAcceptanceRenderer,
        ClerkInitInputHandler,
        AccountStatusInquiryOpeningInputHandler,
        AccountStatusInquiryCheckAcceptanceInputHandler,
    ]
})
export class ClerkModule {
}
