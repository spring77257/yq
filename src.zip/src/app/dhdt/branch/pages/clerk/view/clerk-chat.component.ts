import { AfterViewChecked, Component, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ClerkAction } from 'dhdt/branch/pages/clerk/action/clerk.action';
import { ClerkInitRenderer } from 'dhdt/branch/pages/clerk/chat-flow/clerk-init.renderer';
import { ClerkSignal, ClerkState, ClerkStore } from 'dhdt/branch/pages/clerk/store/clerk.store';
import { ClerkUtil } from 'dhdt/branch/pages/clerk/utils/clerk-util';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { AbstractChatFlowControlComponent } from 'dhdt/branch/shared/modules/chat-flow/components/abstract-chat-flow-control.component';
import {
    ChatFlowHeaderInterfaces, ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { Content } from 'ionic-angular';
import { NavParams } from 'ionic-angular/navigation/nav-params';

/**
 * control all chat page.
 */
@Component({
    selector: 'clerk-chat-component',
    templateUrl: 'clerk-chat.component.html'
})
export class ClerkChatComponent extends AbstractChatFlowControlComponent implements OnInit, OnDestroy, AfterViewChecked {
    @ViewChild(Content) public content: Content;
    public state: ClerkState;
    public processItems: ChatFlowHeaderInterfaces.ProcessItemInput[];
    public headerOptions: ChatFlowHeaderInterfaces.Options;
    public clerkFlg: boolean = true;
    /** メッセージコンテナが最下部へスクロールされるのを抑止するか */
    private preventScrollToBottom: boolean = false;

    constructor(
        private store: ClerkStore,
        private action: ClerkAction,
        private clerkUtil: ClerkUtil,
        private navParams: NavParams,
        injector: Injector
    ) {
        super(action, injector);
        this.state = this.store.getState();
    }

    /**
     * 初期化処理として以下を行う。
     * * `AbstractChatFlowControlComponent`の初期化メソッド(`initChatFlowControl`)を実行する。
     * * `ChatFlowHeaderComponent`用のオプションをセットアップする。
     * * Storeからのシグナルを登録する。
     *
     * @memberof ClerkChatComponent
     */
    public ngOnInit() {
        this.initChatFlowControl();
        this.setupHeaderOptions();
        this.store.registerSignalHandler(ClerkSignal.CHAT_FLOW_COMPLETE, (nextComponentType: string) => {
            if (nextComponentType === COMMON_CONSTANTS.ELEMENT_TYPE_COMPLETE) {
                this.viewCtrl.dismiss({
                    ...this.state
                });
            } else {
                this.onChatFlowComplete(nextComponentType, TopComponent);
            }
        });
        this.store.registerSignalHandler(ClerkSignal.GET_QUESTION, (pageIndex: number) => {
            this.onYamlDidLoad(pageIndex);
        });
        this.store.registerSignalHandler(ClerkSignal.SEND_ANSWER, (data) => {
            this.onNextMessage(data);
        });
    }

    /**
     * クリーンアップ処理として以下を行う。
     * * `AbstractChatFlowControlComponent`のクリーンアップメソッド(`destoyChatFlowControl`)を実行する。
     * * Storeシグナルの登録を解除する。
     *
     * @memberof ClerkChatComponent
     */
    public ngOnDestroy() {
        this.destoyChatFlowControl();
        this.store.unregisterSignalHandler(ClerkSignal.CHAT_FLOW_COMPLETE);
        this.store.unregisterSignalHandler(ClerkSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(ClerkSignal.SEND_ANSWER);
    }

    /**
     * ViewCheck後（Viewが変更された後）にメッセージコンテナを最下部へスクロールする。
     *
     * @memberof ClerkChatComponent
     */
    public ngAfterViewChecked(): void {
        if (this.preventScrollToBottom) {
            this.preventScrollToBottom = false;
            return;
        }
        this.content.scrollToBottom();
    }

    /**
     * 戻るボタンクリックHandler
     */
    public cancelEmitterHandler() {
        super.cancelEmitterHandler();
        this.action.resetSubmitData();
    }

    /**
     * ProcessTypeを取得する。
     *
     * @memberof ClerkChatComponent
     */
    public get processType(): number {
        return this.chatFlowNavParam.isCurrentPage ? -1 : this.currentRenderer.processType;
    }

    protected getRendererNameByIndex(index: number) {
        const componentNameMap = {
            0: ClerkInitRenderer.name,
        };
        let componentName = componentNameMap[index];
        if (!componentName) {
            componentName = componentNameMap[0];
        }
        return componentName;
    }

    protected branchStatusUpdate(): void {
        // do-nothing
    }

    private setupHeaderOptions() {
        this.processItems = this.clerkUtil.getProcessItems();
        if (!this.chatFlowNavParam.isCurrentPage) {
            this.headerOptions = {
                showReturnTopButton: true,
                topComponent: TopComponent,
                title: this.labels.clerk.headerTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.CALL_CLERK
            };
        } else {
            this.headerOptions = {
                showReturnTopButton: false,
                title: this.chatFlowNavParam.currentTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
            };
        }
    }
}
