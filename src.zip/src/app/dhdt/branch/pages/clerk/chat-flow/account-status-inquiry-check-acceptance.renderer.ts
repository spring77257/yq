import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { ClerkAction } from 'dhdt/branch/pages/clerk/action/clerk.action';
import {
    AccountStatusInquiryCheckAcceptanceInputHandler
} from 'dhdt/branch/pages/clerk/chat-flow/account-status-inquiry-check-acceptance.input-handler';
import { ClerkChatFlowQuestionTypes } from 'dhdt/branch/pages/clerk/chat-flow/clerk.chat-flow-question-types';
import { ClerkConsts } from 'dhdt/branch/pages/clerk/clerk-consts';
import { ClerkSubmitEntity } from 'dhdt/branch/pages/clerk/entity/clerk-submit.entity';
import { ClerkSignal, ClerkState, ClerkStore } from 'dhdt/branch/pages/clerk/store/clerk.store';
import { AgentInternalError, COMMON_CONSTANTS, HostErrorCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { PartnerAccountInfo as PartnerAccountInfo2 } from 'dhdt/branch/pages/terminate/entity/account-status-info-inquiry-response.entity';
import {
    DepositDetailsInfo,
    ReceptionCancelAccountApplyCheckAccount
} from 'dhdt/branch/pages/terminate/entity/reception-cancel-account-apply-check-account.entity';
import {
    ReceptionCancelAccountApplyCheckResponse, ReceptionCheckAccountInfo
} from 'dhdt/branch/pages/terminate/entity/reception-cancel-account-apply-check-response.entity';
import { TerminateUtil } from 'dhdt/branch/pages/terminate/utils/terminate-util';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { TerminateConsts } from '../../terminate/terminate-consts';

/**
 * 口座状態照会【03_口座受付可否確認】renderer
 *
 * @export
 * @class AccountStatusInquiryCheckAcceptanceRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: AccountStatusInquiryCheckAcceptanceRenderer.name,
    templateYaml: 'chat-flow-def-account-status-inquiry-check-acceptance.yml'
})
export class AccountStatusInquiryCheckAcceptanceRenderer extends DefaultChatFlowRenderer {
    public processType = COMMON_CONSTANTS.ProcessType.RequiredInput;
    private state: ClerkState;

    constructor(
        private action: ClerkAction,
        private store: ClerkStore,
        private terminateUtil: TerminateUtil,
        private modalService: ModalService,
        private labelService: LabelService,
        private loginStore: LoginStore,
        inputHandler: AccountStatusInquiryCheckAcceptanceInputHandler,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): ClerkSubmitEntity {
        return this.state.submitData;
    }

    @Renderer(ClerkChatFlowQuestionTypes.JUDGE)
    private onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        let judgeResult: boolean;
        switch (entity.name) {
            case 'isActiveAccount':
                // ・解約する口座が活動中（少額預金解約）の場合、true
                // ・上記以外の場合、false
                if (this.state.submitData.bussinessCode === ClerkConsts.BussinessCode.active
                    || (this.state.submitData.bussinessCode === ClerkConsts.BussinessCode.notAccepted
                        && this.state.submitData.accountStatusInfo
                        && this.state.submitData.accountStatusInfo.accountStatus === ClerkConsts.AccountStatus.Active)) {
                    judgeResult = true;
                    break;
                } else {
                    judgeResult = false;
                    break;
                }
            case 'checkForTaxationCode':
                // 取扱店が186 または 162以外の場合は、課税コードのチェックをおこなう
                if (this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.CC
                    && this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.INHERIT) {
                    // 課税コードのチェック
                    // ・OKの場合、true
                    // ・NGの場合、エラーモーダル表示
                    judgeResult = true;
                    // 外貨預金の場合
                    if (this.state.submitData.accountStatusInfo.subjectCode === ClerkConsts.AvailableAccountType.foreignCurrencySavings) {
                        if (this.state.submitData.accountSearchStatus === ClerkConsts.Status.ON
                            && this.state.submitData.accountStatusInfo.taxationCode !== ClerkConsts.TaxationCode.taxation) {
                            this.showErrorModal(
                                AgentInternalError.ERROR_CODE_N_016, this.labelService.labels.terminate.errorMessage.N_016,
                                this.labelService.labels.alert.terminateTradingStatusMessage, pageIndex
                            );
                            return;
                        }
                    } else {
                        // 預金科目の場合
                        if (this.state.submitData.dormantDepositSearchStatus === ClerkConsts.Status.ON) {
                            if (this.state.submitData.dormantDepositInfo.accountInfo
                                && this.state.submitData.dormantDepositInfo.accountInfo.length > 0) {
                                for (const account of this.state.submitData.dormantDepositInfo.accountInfo) {
                                    // 雑益繰入済み または 休眠移管済みの場合を対象とする
                                    if (account.dormantDepositStatus === ClerkConsts.DormantDepositStatus.IncomeTransferred
                                        || account.dormantDepositStatus === ClerkConsts.DormantDepositStatus.DormantTransferred) {
                                        if (account.taxationCode && account.taxationCode !== ClerkConsts.TaxationCode.separation) {
                                            this.showErrorModal(
                                                AgentInternalError.ERROR_CODE_N_016, this.labelService.labels.terminate.errorMessage.N_016,
                                                this.labelService.labels.alert.terminateTradingStatusMessage, pageIndex
                                            );
                                            return;
                                        }
                                    }
                                }
                            }
                            if (this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo
                                && this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo.length > 0) {
                                for (const partnerAccount of this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo) {
                                    // 雑益繰入済み または 休眠移管済みの場合を対象とする
                                    if (partnerAccount.dormantDepositStatus === ClerkConsts.DormantDepositStatus.IncomeTransferred
                                        || partnerAccount.dormantDepositStatus === ClerkConsts.DormantDepositStatus.DormantTransferred) {
                                        if (partnerAccount.taxationCode
                                            && partnerAccount.taxationCode !== ClerkConsts.TaxationCode.separation) {
                                            this.showErrorModal(
                                                AgentInternalError.ERROR_CODE_N_016, this.labelService.labels.terminate.errorMessage.N_016,
                                                this.labelService.labels.alert.terminateTradingStatusMessage, pageIndex
                                            );
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    judgeResult = true;
                }
                break;
            case 'isForeignCurrencySavings':
                // 取扱店が186 または 162以外の場合は、外貨繰入時元金のチェックをおこなう
                // ・解約口座の科目コードが「71:外貨普通」の場合、true
                // ・上記以外の場合、false
                if (this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.CC
                    && this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.INHERIT) {
                    judgeResult =
                        this.state.submitData.accountSearchStatus === ClerkConsts.Status.ON
                        && this.state.submitData.accountStatusInfo.subjectCode === ClerkConsts.AvailableAccountType.foreignCurrencySavings;
                    break;
                } else {
                    // 取扱店が186 または 162の場合は、外貨繰入時元金のチェックは不要とする
                    judgeResult = false;
                    break;
                }
            case 'checkForPrincipalOnTransfer':
                // 取扱店が186 または 162以外の場合は、繰入移管時元金のチェックをおこなう
                if (this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.CC
                    && this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.INHERIT) {
                    // 繰入移管時元金のチェック
                    // ・OKの場合、true
                    // ・NGの場合、エラーモーダル表示
                    judgeResult = true;
                    let checkPrincipalOnTransferResult = {
                        errorCode: '',
                        errorMessage: ''
                    };
                    if (this.state.submitData.dormantDepositSearchStatus === ClerkConsts.Status.ON) {
                        // 睡眠・休眠情報照会にて情報を保有している場合
                        checkPrincipalOnTransferResult =
                            this.terminateUtil.checkForPrincipalOnTransferDormantDepositInfoOfCounter(
                                this.state.submitData.dormantDepositInfo);
                    } else if (this.state.submitData.inactiveAccountSearchStatus === ClerkConsts.Status.ON
                        && this.state.submitData.inactiveAccountInfo) {
                        // 不活動口座情報がある場合は、不活動口座情報の取引明細より繰入時元金がわかるものはチェック
                        // 口座状態照会APIで取得した口座情報リスト
                        const accountStatusInfoList: Array<{
                            branchCode: string, subjectCode: string, bankAccountId: string, passbookTypeCode: string
                        }> =
                            [{
                                branchCode: this.state.submitData.accountStatusInfo.branchCode,
                                subjectCode: this.state.submitData.accountStatusInfo.subjectCode,
                                bankAccountId: this.state.submitData.accountStatusInfo.bankAccountId,
                                passbookTypeCode: this.state.submitData.accountStatusInfo.passbookTypeCode
                            }];
                        if (this.state.submitData.accountStatusInfo.partnerAccountInfo
                            && this.state.submitData.accountStatusInfo.partnerAccountInfo.length) {
                            this.state.submitData.accountStatusInfo.partnerAccountInfo.forEach((e) => accountStatusInfoList.push({
                                branchCode: e.branchCode,
                                subjectCode: e.subjectCode,
                                bankAccountId: e.bankAccountId,
                                passbookTypeCode: e.passbookTypeCode
                            }));
                        }
                        this.action.setStateSubmitDataValue({ name: 'accountStatusInfoList', value: accountStatusInfoList });
                        // 不活動口座照会APIで取得した口座情報リスト
                        const inactiveAccountInfoList: Array<{ branchCode: string, subjectCode: string, bankAccountId: string }> = [];
                        if (this.state.submitData.inactiveAccountInfo.accountInfo
                            && this.state.submitData.inactiveAccountInfo.accountInfo.length) {
                            this.state.submitData.inactiveAccountInfo.accountInfo.forEach((e) => inactiveAccountInfoList.push({
                                branchCode: e.branchCode,
                                subjectCode: e.subjectCode,
                                bankAccountId: e.bankAccountId
                            }));
                        }
                        if (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo
                            && this.state.submitData.inactiveAccountInfo.secondaryAccountInfo.length) {
                            this.state.submitData.inactiveAccountInfo.secondaryAccountInfo.forEach((e) => inactiveAccountInfoList.push({
                                branchCode: e.branchCode,
                                subjectCode: e.subjectCode,
                                bankAccountId: e.bankAccountId
                            }));
                        }
                        this.action.setStateSubmitDataValue({ name: 'inactiveAccountInfoList', value: inactiveAccountInfoList });
                        // 入力した店科口情報
                        const inputAccountInfo = {
                            branchCode: this.state.submitData.terminateAccountBranchNo,
                            subjectCode: this.state.submitData.terminateAccountType,
                            bankAccountId: this.state.submitData.terminateAccountNo
                        };
                        // 主口座と関連口座を結合
                        const margedInactiveAccountInfo =
                            this.state.submitData.inactiveAccountInfo.accountInfo
                                .concat(this.state.submitData.inactiveAccountInfo.secondaryAccountInfo);
                        checkPrincipalOnTransferResult =
                            this.terminateUtil.checkForPrincipalOnTransferInactiveAccountInfoOfCounter(
                                this.state.submitData.accountSearchStatus, this.state.submitData.inactiveAccountInfo,
                                accountStatusInfoList, this.state.submitData.inactiveAccountInfoList,
                                inputAccountInfo, margedInactiveAccountInfo);
                    }
                    if (checkPrincipalOnTransferResult.errorCode) {
                        this.showErrorModal(checkPrincipalOnTransferResult.errorCode, checkPrincipalOnTransferResult.errorMessage,
                            this.labelService.labels.alert.terminateCounterDepositAmountMessage, pageIndex);
                        return;
                    }
                } else {
                    judgeResult = true;
                }
                break;
            case 'isFixedDepositOrNotification':
                // ・解約口座の科目コードが「20:定期」または「16:通知」の場合、true
                // ・上記以外の場合、false
                judgeResult = this.state.submitData.accountStatusInfo.subjectCode === ClerkConsts.AvailableAccountType.fixedDeposit
                    || this.state.submitData.accountStatusInfo.subjectCode === ClerkConsts.AvailableAccountType.notification
                    || (this.state.submitData.accountStatusInfo.partnerAccountInfo || [])
                        .some((account) => account.subjectCode === ClerkConsts.AvailableAccountType.fixedDeposit
                            || account.subjectCode === ClerkConsts.AvailableAccountType.notification);
                break;
        }
        for (const choice of entity.choices) {
            if (choice.value === judgeResult) {
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
                return;
            }
        }
    }

    @Renderer(ClerkChatFlowQuestionTypes.REQUEST)
    private onReuqest(entity: ChatFlowMessageInterface, pageIndex: number) {
        // 取扱店が186 または 162以外の場合は、業務受付可否チェックをおこなう
        if (this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.CC
            && this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.INHERIT) {
            switch (entity.name) {
                // 業務受付可否チェック（少額預金解約）
                case 'receptionCancelAccountApplyCheck':
                    this.receptionCancelAccountApplyCheck(entity, pageIndex);
                    break;
                // 業務受付可否チェック（睡眠・休眠預金解約）
                case 'receptionCancelAccountApplyCheckForDormantDeposit':
                    this.receptionCancelAccountApplyCheckForDormantDeposit(entity, pageIndex);
                    break;
                // 業務受付可否チェック（通知・定期明細）
                case 'receptionCancelAccountApplyCheckForDepositDetailsInfo':
                    this.receptionCancelAccountApplyCheckForDepositDetailsInfo(entity, pageIndex);
                    break;
                default:
                    break;
            }
        } else {
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    /**
     * 受付可否チェック（少額預金解約）
     * @param entity
     * @param pageIndex
     */
    private receptionCancelAccountApplyCheck(entity: ChatFlowMessageInterface, pageIndex: number) {
        const accounts: ReceptionCancelAccountApplyCheckAccount[] = []; // 口座情報リスト

        if (this.state.submitData.customerInfo) {
            // 顧客番号ありの場合
            if (this.state.submitData.customerInfo.customerId) {
                // 業務コード：３０、　３１で業務受付可否チェックAPIの呼出しをする
                accounts.push(this.setAccountInfo(null, null, null, this.state.submitData.customerInfo.customerId, [],
                    ClerkConsts.ReceptionCheckBusinessCode.NG));
                accounts.push(this.setAccountInfo(null, null, null, this.state.submitData.customerInfo.customerId, [],
                    ClerkConsts.ReceptionCheckBusinessCode.ACTIVE_ACCOUNTS_CANCEL));
            }
            if (this.state.submitData.accountStatusInfo) {
                const accountStatusInfo = this.state.submitData.accountStatusInfo;
                // 主口座有かつ口座状態：活動中の場合
                if (accountStatusInfo.accountStatus === ClerkConsts.AccountStatus.Active) {
                    accounts.push(this.setAccountInfo(accountStatusInfo.branchCode, accountStatusInfo.subjectCode,
                        accountStatusInfo.bankAccountId, null, [], this.setActiveAccountBusinessCode(accountStatusInfo.subjectCode)));
                }
                // 相手口座有の場合
                if (accountStatusInfo.partnerAccountInfo && accountStatusInfo.partnerAccountInfo.length > 0) {
                    accountStatusInfo.partnerAccountInfo.forEach((partnerAccountInfo) => {
                        // 口座状態：活動中の場合
                        if (partnerAccountInfo.accountStatus === ClerkConsts.AccountStatus.Active) {
                            accounts.push(this.setAccountInfo(partnerAccountInfo.branchCode, partnerAccountInfo.subjectCode,
                                partnerAccountInfo.bankAccountId, null, [],
                                this.setActiveAccountBusinessCode(partnerAccountInfo.subjectCode)));
                        }
                    });
                }
            }
        }

        // 受付可否チェック対象口座ありの場合、APIに投げる
        if (accounts.length > 0) {
            this.receptionCheck(accounts, entity.next, pageIndex);
        } else {
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }

    }

    /**
     * 業務受付可否チェック（睡眠・休眠預金解約）
     * @param entity
     * @param pageIndex
     */
    private receptionCancelAccountApplyCheckForDormantDeposit(entity: ChatFlowMessageInterface, pageIndex: number) {
        // 外貨預金の場合
        if (this.state.submitData.accountStatusInfo.subjectCode === ClerkConsts.AvailableAccountType.foreignCurrencySavings) {
            let errorInfoOfReceptionCheck: ReceptionCheckAccountInfo[];

            // ①顧客番号ありの場合、業務受付チェックAPIに投げる
            if (this.state.submitData.customerInfo.customerId) {
                const accounts: ReceptionCancelAccountApplyCheckAccount[] = []; // 口座情報リスト
                // 業務コード：４４で業務受付可否チェックAPIの呼出しをする
                accounts.push(this.setAccountInfo(null, null, null, this.state.submitData.customerInfo.customerId, [],
                    ClerkConsts.ReceptionCheckBusinessCode.COUNTER_INACTIVE_ACCOUNTS_CANCEL));

                const param = {
                    tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                    params: {
                        receptionTenban: this.loginStore.getState().belongToBranchNo,  // 取次店番
                        accounts: accounts // 口座情報リスト
                    }
                };

                this.store.registerSignalHandler(ClerkSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
                    // 事故取引禁止注意エラーの場合、注意コードを取得の上エラーモーダルを表示する
                    this.store.unregisterSignalHandler(ClerkSignal.UNACCEPTABLES_NG);
                    errorInfoOfReceptionCheck = response.errors.data.accounts;
                    // ②口座状態照会.外貨預金事故情報をチェックする
                    this.checkErrorCodeForForexAccount(errorInfoOfReceptionCheck, entity.next, pageIndex);
                    return;
                });

                this.store.registerSignalHandler(ClerkSignal.RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK, () => {
                    this.store.unregisterSignalHandler(ClerkSignal.RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK);
                    this.store.unregisterSignalHandler(ClerkSignal.UNACCEPTABLES_NG);
                    // ②口座状態照会.外貨預金事故情報をチェックする
                    this.checkErrorCodeForForexAccount(errorInfoOfReceptionCheck, entity.next, pageIndex);
                    return;
                });

                // 業務受付可否チェック
                this.action.receptionCancelAccountApplyCheck(param);
            } else {
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            }

        } else {
            // 預金科目の場合、業務受付チェックAPIに投げる
            if (this.state.submitData.bussinessCode === ClerkConsts.BussinessCode.inActive) {
                // 索引情報検索結果）が1:索引ありの場合
                if (this.state.submitData.dormantDepositSearchStatus === ClerkConsts.Status.ON) {
                    const accounts: ReceptionCancelAccountApplyCheckAccount[] = []; // 口座情報リスト

                    if (this.state.submitData.dormantDepositInfo) {
                        // 顧客番号ありの場合
                        if (this.state.submitData.dormantDepositInfo.customerId) {
                            // 業務コード：４４で業務受付可否チェックAPIの呼出しをする
                            accounts.push(this.setAccountInfo(null, null, null, this.state.submitData.dormantDepositInfo.customerId, [],
                                ClerkConsts.ReceptionCheckBusinessCode.COUNTER_INACTIVE_ACCOUNTS_CANCEL));
                        }
                        // 主口座有の場合
                        if (this.state.submitData.dormantDepositInfo.accountInfo) {
                            const mainAccountInfo = this.state.submitData.dormantDepositInfo.accountInfo;
                            mainAccountInfo.forEach((accountInfo) => {
                                // 雑益繰入済／休眠移管済の場合
                                if (accountInfo.dormantDepositStatus === ClerkConsts.DormantDepositStatus.IncomeTransferred ||
                                    accountInfo.dormantDepositStatus === ClerkConsts.DormantDepositStatus.DormantTransferred) {
                                    // 同じ口座が複数件ありの場合、１件目の情報の口座とする。
                                    if (!accounts.some((selectedItem) =>
                                        selectedItem.accountType === accountInfo.subjectCode &&
                                        selectedItem.accountNo === accountInfo.bankAccountId)) {
                                        accounts.push(this.setAccountInfo(accountInfo.branchCode, accountInfo.subjectCode,
                                            accountInfo.bankAccountId, null, [],
                                            this.setInactiveAccountBusinessCode(accountInfo.subjectCode)));
                                    }
                                }
                            });
                        }
                        // 相手口座有の場合
                        if (this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo &&
                            this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo.length > 0) {
                            const partnerDormantAccountInfo = this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo;
                            partnerDormantAccountInfo.forEach((dormantAccountInfo) => {
                                // 雑益繰入済／休眠移管済の場合
                                if (dormantAccountInfo.dormantDepositStatus === ClerkConsts.DormantDepositStatus.IncomeTransferred ||
                                    dormantAccountInfo.dormantDepositStatus === ClerkConsts.DormantDepositStatus.DormantTransferred) {
                                    // 同じ口座が複数件ありの場合、１件目の情報の口座とする。
                                    if (!accounts.some((selectedItem) =>
                                        selectedItem.accountType === dormantAccountInfo.subjectCode &&
                                        selectedItem.accountNo === dormantAccountInfo.bankAccountId)) {
                                        accounts.push(this.setAccountInfo(dormantAccountInfo.branchCode, dormantAccountInfo.subjectCode,
                                            dormantAccountInfo.bankAccountId, null, [],
                                            this.setInactiveAccountBusinessCode(dormantAccountInfo.subjectCode)));
                                    }
                                }
                            });
                        }
                    }

                    // 受付可否チェック対象口座ありの場合、APIに投げる
                    if (accounts.length > 0) {
                        this.receptionCheck(accounts, entity.next, pageIndex);
                    } else {
                        this.emitMessageRetrivalEvent(entity.next, pageIndex);
                    }
                } else if (this.state.submitData.inactiveAccountSearchStatus === ClerkConsts.InactiveAccountSearchStatus.Yes) {
                    // 不活動口座検索結果が1:CRM元帳に口座ありの場合
                    const accounts: ReceptionCancelAccountApplyCheckAccount[] = []; // 口座情報リスト
                    // 勘定系顧客元帳がある場合、顧客単位の業務受付可否チェックをおこなう
                    // 業務コード：４４で業務受付可否チェックAPIの呼出しをする.
                    if (!StringUtils.isEmpty(this.state.submitData.customerInfo.customerId)) {
                        accounts.push(this.setAccountInfo(null, null, null, this.state.submitData.customerInfo.customerId, [],
                            ClerkConsts.ReceptionCheckBusinessCode.COUNTER_INACTIVE_ACCOUNTS_CANCEL));
                    }

                    // 勘定系口座元帳がある場合、口座単位の業務受付可否チェックをおこなう
                    // 但し、口座元帳照会の店科口と不活動口座情報照会の店科口が一致する先のみとする
                    if (this.state.submitData.accountSearchStatus === ClerkConsts.Status.ON) {
                        const inactiveAccountInfo = this.state.submitData.inactiveAccountInfo;

                        const activeAccountTenKaKo = {
                            branchCode: this.state.submitData.accountStatusInfo.branchCode,
                            subjectCode: this.state.submitData.accountStatusInfo.subjectCode,
                            bankAccountId: this.state.submitData.accountStatusInfo.bankAccountId
                        };

                        if (inactiveAccountInfo.accountInfo && inactiveAccountInfo.accountInfo.length > 0) {
                            inactiveAccountInfo.accountInfo.forEach((accountInfo) => {
                                // 不活動口座情報照会API.主口座.取引明細情報がある場合
                                // 口座状態照会の店番号、科目、口座番号と不活動口座情報照会の店番号、科目、口座番号が一致する場合、かつ
                                // 主口座情報の雑益繰入取消済が”１”ではなく、「長」か「セ」が”１”の先の場合
                                const inactiveAccountTenKaKo = {
                                    branchCode: accountInfo.branchCode,
                                    subjectCode: accountInfo.subjectCode,
                                    bankAccountId: accountInfo.bankAccountId
                                };
                                if (accountInfo.transactionDetailsInfo && accountInfo.transactionDetailsInfo.length > 0 &&
                                    this.checkTenKaKo(inactiveAccountTenKaKo, activeAccountTenKaKo) &&
                                    this.terminateUtil.checkInactiveAccountStatus(accountInfo.dormantAccountStatus,
                                        accountInfo.centerClosedStatus, accountInfo.deleteStatus)) {
                                    accounts.push(this.setAccountInfo(accountInfo.branchCode, accountInfo.subjectCode,
                                        accountInfo.bankAccountId, null, [],
                                        this.setInactiveAccountBusinessCode(accountInfo.subjectCode)));
                                }
                            });
                        }

                        // 不活動口座情報照会API.相手口座有の場合
                        if (inactiveAccountInfo.secondaryAccountInfo && inactiveAccountInfo.secondaryAccountInfo.length > 0) {
                            inactiveAccountInfo.secondaryAccountInfo.forEach((secondaryAccountInfo) => {
                                // 不活動口座情報照会API.相手口座.取引明細情報がある場合
                                // 口座状態照会の店番号（相手）、科目（相手）、口座番号（相手）と不活動口座情報照会の店番号（相手）、科目（相手）、口座番号（相手）が一致する場合、かつ
                                // 「長」か「セ」が”１”の先の場合
                                const secondaryAccountTenKaKo = {
                                    branchCode: secondaryAccountInfo.branchCode,
                                    subjectCode: secondaryAccountInfo.subjectCode,
                                    bankAccountId: secondaryAccountInfo.bankAccountId
                                };
                                if (secondaryAccountInfo.transactionDetailsInfo
                                    && secondaryAccountInfo.transactionDetailsInfo.length > 0 &&
                                    this.checkTenKaKoForPartnerAccount(secondaryAccountTenKaKo,
                                        this.state.submitData.accountStatusInfo.partnerAccountInfo) &&
                                    this.terminateUtil.checkInactiveAccountStatus(secondaryAccountInfo.dormantAccountStatus,
                                        secondaryAccountInfo.centerClosedStatus, secondaryAccountInfo.deleteStatus)) {
                                    accounts.push(this.setAccountInfo(secondaryAccountInfo.branchCode, secondaryAccountInfo.subjectCode,
                                        secondaryAccountInfo.bankAccountId, null, [],
                                        this.setInactiveAccountBusinessCode(secondaryAccountInfo.subjectCode)));
                                }
                            });
                        }
                    }

                    // 受付可否チェック対象口座ありの場合、APIに投げる
                    if (accounts.length > 0) {
                        this.receptionCheck(accounts, entity.next, pageIndex);
                    } else {
                        this.emitMessageRetrivalEvent(entity.next, pageIndex);
                    }
                } else {
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                }
            }
        }

    }

    /**
     * 受付可否チェック（通知・定期明細）
     * @param entity
     * @param pageIndex
     */
    private receptionCancelAccountApplyCheckForDepositDetailsInfo(entity: ChatFlowMessageInterface, pageIndex: number) {
        const accounts: ReceptionCancelAccountApplyCheckAccount[] = []; // 口座情報リスト

        // 主口座有の場合
        if (this.state.submitData.dormantDepositInfo.accountInfo) {
            const mainAccountInfo = this.state.submitData.dormantDepositInfo.accountInfo;
            mainAccountInfo.forEach((accountInfo) => {
                // 通知・定期口座、かつ雑益繰入済／休眠移管済の場合
                if ((accountInfo.subjectCode === COMMON_CONSTANTS.AccountTypeCodeCoreBanking.notification
                    || accountInfo.subjectCode === COMMON_CONSTANTS.AccountTypeCodeCoreBanking.timeDeposit)
                    && (accountInfo.dormantDepositStatus === ClerkConsts.DormantDepositStatus.IncomeTransferred ||
                        accountInfo.dormantDepositStatus === ClerkConsts.DormantDepositStatus.DormantTransferred)
                    && !StringUtils.isEmpty(accountInfo.depositNo)
                    && StringUtils.isEmpty(accountInfo.secondaryDepositNo)) {
                    const depositDetailsInfo: DepositDetailsInfo = new DepositDetailsInfo(); // 預入明細情報
                    const depositDetailsInfoList = [];
                    const index: number = accounts.findIndex((selectedItem) => selectedItem.accountNo === accountInfo.bankAccountId
                        && selectedItem.accountType === accountInfo.subjectCode);
                    if (index !== -1) {
                        // 口座情報リストの配下、既に口座番号ありの場合、明細を追加
                        depositDetailsInfo.depositNo = accountInfo.depositNo;
                        accounts[index].depositDetailsInfo.push(depositDetailsInfo);
                    } else {
                        depositDetailsInfo.depositNo = accountInfo.depositNo;
                        depositDetailsInfoList.push(depositDetailsInfo);
                        accounts.push(this.setAccountInfo(accountInfo.branchCode, accountInfo.subjectCode, accountInfo.bankAccountId,
                            null, depositDetailsInfoList,
                            ClerkConsts.ReceptionCheckBusinessCode.COUNTER_INACTIVE_ACCOUNTS_CANCEL_DEPOSITNO));
                    }
                }
            });
        }

        // 相手口座有の場合
        if (this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo &&
            this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo.length > 0) {
            const partnerDormantAccountInfo = this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo;
            partnerDormantAccountInfo.forEach((dormantAccountInfo) => {
                // 定期口座、かつ雑益繰入済／休眠移管済の場合
                if (dormantAccountInfo.subjectCode === COMMON_CONSTANTS.AccountTypeCodeCoreBanking.timeDeposit
                    && (dormantAccountInfo.dormantDepositStatus === ClerkConsts.DormantDepositStatus.IncomeTransferred ||
                        dormantAccountInfo.dormantDepositStatus === ClerkConsts.DormantDepositStatus.DormantTransferred)
                    && !StringUtils.isEmpty(dormantAccountInfo.depositNo)
                    && StringUtils.isEmpty(dormantAccountInfo.secondaryDepositNo)) {
                    const depositDetailsInfo: DepositDetailsInfo = new DepositDetailsInfo(); // 預入明細情報
                    const depositDetailsInfoList = [];
                    const index: number = accounts.findIndex((selectedItem) => selectedItem.accountNo === dormantAccountInfo.bankAccountId
                        && selectedItem.accountType === dormantAccountInfo.subjectCode);
                    if (index !== -1) {
                        // 口座情報リストの配下、既に口座番号ありの場合、明細を追加
                        depositDetailsInfo.depositNo = dormantAccountInfo.depositNo;
                        accounts[index].depositDetailsInfo.push(depositDetailsInfo);
                    } else {
                        depositDetailsInfo.depositNo = dormantAccountInfo.depositNo;
                        depositDetailsInfoList.push(depositDetailsInfo);
                        accounts.push(this.setAccountInfo(dormantAccountInfo.branchCode, dormantAccountInfo.subjectCode,
                            dormantAccountInfo.bankAccountId, null, depositDetailsInfoList,
                            ClerkConsts.ReceptionCheckBusinessCode.COUNTER_INACTIVE_ACCOUNTS_CANCEL_DEPOSITNO));
                    }
                }
            });
        }

        // 受付可否チェック対象口座ありの場合、APIに投げる
        if (accounts.length > 0) {
            this.receptionCheck(accounts, entity.next, pageIndex);
        } else {
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }

    }

    /**
     * 業務受付可否チェック口座情報設定
     * @param tenban
     * @param accountType
     * @param accountNo
     * @param customerId
     * @param depositDetailsInfo
     * @param businessCode
     * @returns
     */
    private setAccountInfo(
        tenban: string, accountType: string, accountNo: string, customerId: string,
        depositDetailsInfo: DepositDetailsInfo[], businessCode: string): ReceptionCancelAccountApplyCheckAccount {
        const account = new ReceptionCancelAccountApplyCheckAccount();
        account.tenban = tenban;
        account.accountType = accountType;
        account.accountNo = accountNo;
        account.customerId = customerId;
        account.depositDetailsInfo = depositDetailsInfo;
        account.businessCode = businessCode;
        return account;
    }

    /**
     * 少額預金口座の業務コードを設定
     * @param subjectCode
     * @returns
     */
    private setActiveAccountBusinessCode(subjectCode: string): string {
        switch (subjectCode) {
            // 普通・貯蓄・納準
            case ClerkConsts.AvailableAccountType.savings:
            case ClerkConsts.AvailableAccountType.deposit:
            case ClerkConsts.AvailableAccountType.taxPrepare:
                return ClerkConsts.ReceptionCheckBusinessCode.ACTIVE_ACCOUNTS_CANCEL_ORDINARY;
            // 総合定期・総合積定
            case ClerkConsts.AvailableAccountType.fixedDeposit:
            case ClerkConsts.AvailableAccountType.installmentDeposit:
                return ClerkConsts.ReceptionCheckBusinessCode.ACTIVE_ACCOUNTS_CANCEL_TIME_DEPOSIT;
        }
    }

    /**
     * 睡眠・休眠預金口座の業務コードを設定
     * @param subjectCode 口座科目
     * @returns
     */
    private setInactiveAccountBusinessCode(subjectCode: string): string {
        switch (subjectCode) {
            // 普通・貯蓄・納準
            case ClerkConsts.AvailableAccountType.savings:
            case ClerkConsts.AvailableAccountType.deposit:
            case ClerkConsts.AvailableAccountType.taxPrepare:
                return ClerkConsts.ReceptionCheckBusinessCode.COUNTER_INACTIVE_ACCOUNTS_CANCEL_ORDINARY;
            // 当座・別段
            case ClerkConsts.AvailableAccountType.current:
            case ClerkConsts.AvailableAccountType.separateDeposit:
                return ClerkConsts.ReceptionCheckBusinessCode.COUNTER_INACTIVE_ACCOUNTS_CANCEL_CURRENT;
            // 通知・定期・積定
            case ClerkConsts.AvailableAccountType.notification:
            case ClerkConsts.AvailableAccountType.fixedDeposit:
            case ClerkConsts.AvailableAccountType.installmentDeposit:
                return ClerkConsts.ReceptionCheckBusinessCode.COUNTER_INACTIVE_ACCOUNTS_CANCEL_TIME_DEPOSIT;
        }
    }

    private receptionCheck(accounts: ReceptionCancelAccountApplyCheckAccount[], next: number, pageIndex: number) {
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,  // 取次店番
                accounts: accounts // 口座情報リスト
            }
        };

        this.store.registerSignalHandler(ClerkSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
            // 事故取引禁止注意エラーの場合、注意コードを取得の上エラーモーダルを表示する
            this.store.unregisterSignalHandler(ClerkSignal.RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK);
            this.store.unregisterSignalHandler(ClerkSignal.UNACCEPTABLES_NG);
            const errorInfo = this.checkErrorCode(response.errors.data);
            this.showErrorModalForReceptionCheck(errorInfo);
            return;
        });

        this.store.registerSignalHandler(ClerkSignal.RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK, () => {
            this.store.unregisterSignalHandler(ClerkSignal.RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK);
            this.store.unregisterSignalHandler(ClerkSignal.UNACCEPTABLES_NG);
            this.emitMessageRetrivalEvent(next, pageIndex);
        });

        // 業務受付可否チェック
        this.action.receptionCancelAccountApplyCheck(param);
    }

    /**
     * 受付可否チェックにて受付不可エラーとなった際のエラーコードを確認し、集約する
     * @param response 受付可否チェック（少額・睡眠解約／定期明細）レスポンス
     * @returns
     */
    private checkErrorCode(response: ReceptionCancelAccountApplyCheckResponse): string {
        let errorInfo: string;
        let isNeedBr = 1;
        let index = 0;
        const maxArr = ClerkConsts.UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        errorInfo = (this.state.submitData.accountSearchStatus === ClerkConsts.Status.ON
            ? this.state.submitData.accountStatusInfo.branchCode
            : this.state.submitData.inactiveAccountInfo.accountInfo[0].branchCode)
            + COMMON_CONSTANTS.FULL_COLON + response.errorCode;
        for (const account of response.accounts) {
            let unacceptables = '';
            for (const unacceptable of account.unacceptables) {
                unacceptables = unacceptable.unacceptableCode;
                if (index === 0) {
                    errorInfo = errorInfo + COMMON_CONSTANTS.SPACE + unacceptables;
                } else if (isNeedBr > maxArr) {
                    // 1行に最大3つの注意コードを表示する
                    // 超える場合は改行して店番＋エラー情報＋注意コードを表示する
                    errorInfo = errorInfo + COMMON_CONSTANTS.NEW_LINE + errorInfo.slice(0, 14) + unacceptables;
                    isNeedBr = 1;
                } else {
                    errorInfo = errorInfo + COMMON_CONSTANTS.SLASH + unacceptables;
                }
                index++;
                isNeedBr++;
            }
        }
        return errorInfo;
    }

    /**
     * 外貨預金事故情報チェック
     * @param errorInfoOfReceptionCheck
     */
    private checkErrorCodeForForexAccount(errorInfoOfReceptionCheck: ReceptionCheckAccountInfo[], next: number, pageIndex: number) {
        if (this.state.submitData.accountStatusInfo &&
            this.state.submitData.accountStatusInfo.accountStatus === ClerkConsts.AccountStatus.IncomeCancellation
            || this.state.submitData.accountStatusInfo.accountStatus === ClerkConsts.AccountStatus.InactiveCancellation) {

            const errorInfo: string = this.checkErrorCodeForForex(errorInfoOfReceptionCheck,
                this.state.submitData.customerInfo.accountStatusInfo.forexUnacceptableInfo.transactionBanInfo);
            if (errorInfo) {
                this.showErrorModalForReceptionCheck(errorInfo);
                return;
            }

            this.emitMessageRetrivalEvent(next, pageIndex);
        }
    }

    /**
     * 外貨普通預金のエラーコードを確認し、集約する
     */
    private checkErrorCodeForForex(errorInfoOfReceptionCheck: ReceptionCheckAccountInfo[], transactionBanInfo: string[]): string {
        let errorInfo: any;
        let isNeedBr = 1;
        let index = 0;
        const maxArr = ClerkConsts.UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        errorInfo = this.state.submitData.accountStatusInfo.branchCode + COMMON_CONSTANTS.FULL_COLON + HostErrorCode.B_STR_006;
        if (errorInfoOfReceptionCheck) {
            for (const account of errorInfoOfReceptionCheck) {
                let unacceptableCode = '';
                for (const unacceptable of account.unacceptables) {
                    unacceptableCode = unacceptable.unacceptableCode;
                    if (unacceptableCode && unacceptableCode.length > 0) {
                        if (index === 0) {
                            errorInfo = errorInfo + COMMON_CONSTANTS.SPACE + unacceptableCode;
                        } else if (isNeedBr > maxArr) {
                            // 1行に最大3つの注意コードを表示する
                            // 超える場合は改行して店番＋エラー情報＋注意コードを表示する
                            errorInfo = errorInfo + COMMON_CONSTANTS.NEW_LINE + errorInfo.slice(0, 14) + unacceptableCode;
                            isNeedBr = 1;
                        } else {
                            errorInfo = errorInfo + COMMON_CONSTANTS.SLASH + unacceptableCode;
                        }
                        index++;
                        isNeedBr++;
                    }
                }
            }
        }
        if (transactionBanInfo) {
            transactionBanInfo.forEach((transactionBanInfoContent) => {
                const unacceptableCode = this.terminateUtil.transferErrorCodeForCounterForex(transactionBanInfoContent);
                if (unacceptableCode && unacceptableCode.length > 0) {
                    if (index === 0) {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SPACE + unacceptableCode;
                    } else if (isNeedBr > maxArr) {
                        // 1行に最大3つの注意コードを表示する
                        // 超える場合は改行して店番＋エラー情報＋注意コードを表示する
                        errorInfo = errorInfo + COMMON_CONSTANTS.NEW_LINE + errorInfo.slice(0, 14) + unacceptableCode;
                        isNeedBr = 1;
                    } else {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SLASH + unacceptableCode;
                    }
                    index++;
                    isNeedBr++;
                }
            });
        }

        if (index === 0) {
            return null;
        } else {
            return errorInfo;
        }
    }

    /**
     * 口座状態照会の店番号、科目、口座番号と不活動口座情報照会の店番号、科目、口座番号が一致するかないか判定
     * @param inactiveAccountTenKaKo
     * @param activeAccountTenKaKo
     * @returns
     */
    private checkTenKaKo(
        inactiveAccountTenKaKo: { branchCode: string, subjectCode: string, bankAccountId: string },
        activeAccountTenKaKo: { branchCode: string, subjectCode: string, bankAccountId: string }): Boolean {
        return inactiveAccountTenKaKo.branchCode === activeAccountTenKaKo.branchCode
            && inactiveAccountTenKaKo.subjectCode === activeAccountTenKaKo.subjectCode
            && inactiveAccountTenKaKo.bankAccountId === activeAccountTenKaKo.bankAccountId;
    }

    /**
     * 口座状態照会の店番号（相手）、科目（相手）、口座番号（相手）と
     * 不活動口座情報照会の店番号（相手）、科目（相手）、口座番号（相手）が一致するかないか判定
     * @param secondaryAccountTenKaKo
     * @param partnerAccountInfo
     */
    private checkTenKaKoForPartnerAccount(
        secondaryAccountTenKaKo: { branchCode: string, subjectCode: string, bankAccountId: string },
        partnerAccountInfo: PartnerAccountInfo2[]): Boolean {
        return partnerAccountInfo.some((accountInfo) =>
            accountInfo.branchCode === secondaryAccountTenKaKo.branchCode
            && accountInfo.subjectCode === secondaryAccountTenKaKo.subjectCode
            && accountInfo.bankAccountId === secondaryAccountTenKaKo.bankAccountId
        );
    }

    /**
     * エラーモーダルを表示する
     */
    private showErrorModal(errorCode: string, errorTitle: string, errorMessage: string, pageIndex: number) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        const subMessage = `<span class="font-color-red">${errorCode}：${errorTitle}</span>`;
        this.modalService.showAlert(
            errorMessage,
            subMessage, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal'
        );
    }

    /**
     * エラーモーダルを表示する（振替口番種類コード受付対象外）
     */
    private showErrorModalForTransferAccountType(
        checkResult: { errorCode: string, errorMessage: string, transferAccountTypeCode: string, transferAccountType: string },
        errorMessage: string) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        const subMessage = `<span class="font-color-red">${checkResult.errorCode}：${checkResult.errorMessage}<br>
        （${checkResult.transferAccountTypeCode}：${checkResult.transferAccountType}）</span>`;
        this.modalService.showAlert(
            errorMessage,
            subMessage, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal'
        );
    }

    /**
     * エラーモーダルを表示する（受付可否チェック用）
     */
    private showErrorModalForReceptionCheck(errorCode: string, callback?: any) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            this.labelService.labels.alert.terminateTradingStatusMessage,
            `<span class="font-color-red">${errorCode}</span>`, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }
}
