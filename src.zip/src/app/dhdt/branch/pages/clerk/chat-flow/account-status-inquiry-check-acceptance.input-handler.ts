import { Injectable } from '@angular/core';
import { ClerkAction } from 'dhdt/branch/pages/clerk/action/clerk.action';
import { ClerkChatFlowQuestionTypes } from 'dhdt/branch/pages/clerk/chat-flow/clerk.chat-flow-question-types';
import { ClerkState, ClerkStore } from 'dhdt/branch/pages/clerk/store/clerk.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';

/**
 * 口座状態照会【03_口座受付可否確認】input-handler
 *
 * @export
 * @class AccountStatusInquiryCheckAcceptanceInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class AccountStatusInquiryCheckAcceptanceInputHandler extends DefaultChatFlowInputHandler {
    private state: ClerkState;

    constructor(
        private action: ClerkAction,
        private store: ClerkStore,
    ) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(ClerkChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            const answerValues = new Array();
            answerValues.push({ key: entity.name, value: answer.value });
            this.setAnswer({
                text: answer.text,
                value: answerValues
            });
        }
        if (answer.action.type === ClerkChatFlowQuestionTypes.SHOW_ANSWER_TEXT) {
            this.setAnswer({ text: answer.text, value: [] });
        }
        if (answer.action.type === ClerkChatFlowQuestionTypes.ROUTE) {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }
}
