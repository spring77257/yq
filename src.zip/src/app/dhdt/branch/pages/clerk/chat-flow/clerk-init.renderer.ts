import { Injectable } from '@angular/core';
import { ClerkAction } from 'dhdt/branch/pages/clerk/action/clerk.action';
import { ClerkInitInputHandler } from 'dhdt/branch/pages/clerk/chat-flow/clerk-init.input-handler';
import { ClerkSubmitEntity } from 'dhdt/branch/pages/clerk/entity/clerk-submit.entity';
import { ClerkState, ClerkStore } from 'dhdt/branch/pages/clerk/store/clerk.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

/**
 * 口座状態照会【01_解約手続開始】renderer
 *
 * @export
 * @class ClerkInitRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: ClerkInitRenderer.name,
    templateYaml: 'chat-flow-def-clerk-init.yml'
})
export class ClerkInitRenderer extends DefaultChatFlowRenderer {
    public processType = COMMON_CONSTANTS.ProcessType.RequiredInput;
    private state: ClerkState;

    constructor(
        private action: ClerkAction,
        private store: ClerkStore,
        inputHandler: ClerkInitInputHandler,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): ClerkSubmitEntity {
        return this.state.submitData;
    }

}
