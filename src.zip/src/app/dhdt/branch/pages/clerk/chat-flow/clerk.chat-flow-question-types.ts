import { ChatFlowQuestionTypes } from 'dhdt/branch/shared/modules/chat-flow/chat-flow-question-types';

export class ClerkChatFlowQuestionTypes extends ChatFlowQuestionTypes {
    /** 行員ログイン */
    public static readonly LOGIN_CLERK = 'loginClerk';
    /** 解約口座情報を入力する */
    public static readonly INPUT_TERMINATE_ACCOUNT_INFO = 'inputTerminateAccountInfo';
    /** 解約口座情報を確認（復唱）する */
    public static readonly CONFIRM_TERMINATE_ACCOUNT_INFO = 'confirmTerminateAccountInfo';
    /** 解約口座情報を修正する */
    public static readonly FIX_TERMINATE_ACCOUNT_INFO = 'fixTerminateAccountInfo';
    /** 回答値(answer.text)を画面に表示する */
    public static readonly SHOW_ANSWER_TEXT = 'showAnswerText';
    /** 通貨コードを選択する */
    public static readonly CURRENCY_CODE_PICKER = 'currencyCodePicker';
}
