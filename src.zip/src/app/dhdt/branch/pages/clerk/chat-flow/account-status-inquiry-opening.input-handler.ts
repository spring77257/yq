import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { ClerkAction } from 'dhdt/branch/pages/clerk/action/clerk.action';
import { ClerkChatFlowQuestionTypes } from 'dhdt/branch/pages/clerk/chat-flow/clerk.chat-flow-question-types';
import { ClerkConsts } from 'dhdt/branch/pages/clerk/clerk-consts';
import { ClerkState, ClerkStore } from 'dhdt/branch/pages/clerk/store/clerk.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';

/**
 * 口座状態照会【02_オープニング】input-handler
 *
 * @export
 * @class AccountStatusInquiryOpeningInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class AccountStatusInquiryOpeningInputHandler extends DefaultChatFlowInputHandler {
    private state: ClerkState;

    constructor(
        private action: ClerkAction,
        private store: ClerkStore,
        private labelService: LabelService,
    ) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(ClerkChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            const answerValues = new Array();
            answerValues.push({ key: entity.name, value: answer.value });
            this.setAnswer({
                text: answer.text,
                value: answerValues
            });
        }
        if (answer.action.type === ClerkChatFlowQuestionTypes.FIX_TERMINATE_ACCOUNT_INFO) {
            const start = this.state.showChats.findIndex((element) =>
                element.type === ClerkChatFlowQuestionTypes.INPUT_TERMINATE_ACCOUNT_INFO);
            this.action.spliceShowChats(start);
            this.action.setStateSubmitDataValue({ name: 'terminateAccountBranchNo', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'terminateAccountBranchName', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'terminateAccountType', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'terminateAccountNo', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'accountSearchStatus', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'bussinessCode', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'agentErrorCode', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'customerInfo', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'accountStatusInfo', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'incidentalInfo', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'dormantDepositSearchStatus', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'dormantDepositInfo', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'inactiveCustomerInfo', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'inactiveAccountInfo', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'inactiveAccountSearchStatus', value: undefined });
        } else if (answer.action.type === ClerkChatFlowQuestionTypes.SHOW_ANSWER_TEXT) {
            this.setAnswer({ text: answer.text, value: [] });
        }
        if (answer.action.type === ClerkChatFlowQuestionTypes.ROUTE) {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(ClerkChatFlowQuestionTypes.INPUT_TERMINATE_ACCOUNT_INFO)
    private onAccountInfoInputHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        const branchNo = this.labelService.labels.account.branchNo + answer[0].value; // 店番号
        const accountType = this.labelService.labels.account.type + answer[1].value; // 科目コード
        const accountNo = this.labelService.labels.account.no + answer[2].value; // 口座番号
        switch (answer[1].value) {
            // 入力された科目コードが「32:外貨普通」の場合、「71」に変換して保存する（ただし画面に表示する回答は「32」）
            case ClerkConsts.AvailableAccountType.foreignCurrencySavingsForSystem:
                answer[1].value = ClerkConsts.AvailableAccountType.foreignCurrencySavings;
                break;
            // 入力された科目コードが「34:外貨定期」の場合、「73」に変換して保存する（ただし画面に表示する回答は「34」）
            case ClerkConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem:
                answer[1].value = ClerkConsts.AvailableAccountType.foreignCurrencyFixedDeposit;
                break;
            default:
                break;
        }
        this.setAnswer({
            text: branchNo + COMMON_CONSTANTS.NEW_LINE + accountType + COMMON_CONSTANTS.NEW_LINE + accountNo,
            value: [
                { key: entity.choices[0].name, value: answer[0].value }, // 店番号
                { key: entity.choices[1].name, value: answer[1].value }, // 科目コード
                { key: entity.choices[2].name, value: answer[2].value }, // 口座番号
            ]
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(ClerkChatFlowQuestionTypes.CURRENCY_CODE_PICKER)
    private onPickerHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }
}
