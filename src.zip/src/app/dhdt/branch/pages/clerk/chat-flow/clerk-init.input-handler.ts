import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { ClerkAction } from 'dhdt/branch/pages/clerk/action/clerk.action';
import { ClerkChatFlowQuestionTypes } from 'dhdt/branch/pages/clerk/chat-flow/clerk.chat-flow-question-types';
import { ClerkState, ClerkStore } from 'dhdt/branch/pages/clerk/store/clerk.store';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ModalDigitalComponent } from 'dhdt/branch/shared/components/modal/modal-digital/view/modal-digital.component';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ModalController } from 'ionic-angular/components/modal/modal-controller';

/**
 * 口座状態照会【01_解約手続開始】input-handler
 *
 * @export
 * @class ClerkInitInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class ClerkInitInputHandler extends DefaultChatFlowInputHandler {
    private state: ClerkState;

    constructor(
        private action: ClerkAction,
        private store: ClerkStore,
        private labelService: LabelService,
        private loginStore: LoginStore,
        private modalCtrl: ModalController,
    ) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(ClerkChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            const answerValues = new Array();
            answerValues.push({ key: entity.name, value: answer.value });
            this.setAnswer({
                text: answer.text,
                value: answerValues
            });
        }
        if (answer.action.type === ClerkChatFlowQuestionTypes.ROUTE) {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.action.type === ClerkChatFlowQuestionTypes.LOGIN_CLERK) {
            // 行員ログインモーダルを表示
            this.showLoginModal(entity, pageIndex, answer);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    /**
     * ログインモーダルを表示する。
     * モーダルを閉じた際は、同じorder番号を再度読み込む。
     */
    private showLoginModal(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        const modalInfor = {
            title: this.labelService.labels.change.userConfirm,
            subTitle: this.labelService.labels.change.inputPassword,
            showInput: 'two-inputs',
            tabletApplyId: this.loginStore.getState().tabletApplyId
        };
        const loginModal = this.modalCtrl.create(
            ModalDigitalComponent,
            { data: modalInfor },
            { cssClass: 'two-inputs' }
        );
        loginModal.onDidDismiss((success) => {
            if (success) {
                // 以降行員操作となるため、表示中のチャットをクリアする
                this.action.clearShowChats();
                // 次チャットに遷移する
                this.chatFlowCompelete(answer.action.value);
            } else {
                // 行員確認（ログイン）ボタンを再度表示する
                this.emitMessageRetrivalEvent(entity.order, pageIndex);
            }
        });
        loginModal.present();
    }
}
