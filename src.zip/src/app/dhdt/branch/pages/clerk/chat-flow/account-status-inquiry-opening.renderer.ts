import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { ClerkAction } from 'dhdt/branch/pages/clerk/action/clerk.action';
import { AccountStatusInquiryOpeningInputHandler } from 'dhdt/branch/pages/clerk/chat-flow/account-status-inquiry-opening.input-handler';
import { ClerkChatFlowQuestionTypes } from 'dhdt/branch/pages/clerk/chat-flow/clerk.chat-flow-question-types';
import { ClerkConsts } from 'dhdt/branch/pages/clerk/clerk-consts';
import { ClerkSubmitEntity } from 'dhdt/branch/pages/clerk/entity/clerk-submit.entity';
import { ClerkSignal, ClerkState, ClerkStore } from 'dhdt/branch/pages/clerk/store/clerk.store';
import {
    AgentInternalError, ApplyBusinessType, COMMON_CONSTANTS, Constants
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { AccountStatusInfoInquiryRequest } from 'dhdt/branch/pages/terminate/entity/account-status-info-inquiry-request.entity';
import { DormantDepositInfoRequest } from 'dhdt/branch/pages/terminate/entity/dornant-deposit-info-request.entity';
import { InactiveAccountInfoInquiryRequest } from 'dhdt/branch/pages/terminate/entity/inactive-account-info-inquiry-request.entity';
import { InactiveAccountInfoCommon } from 'dhdt/branch/pages/terminate/entity/inactive-account-info-inquiry-response.entity';
import { IncidentalInfoRequest } from 'dhdt/branch/pages/terminate/entity/incidental-info-request.entity';
import { TerminateUtil } from 'dhdt/branch/pages/terminate/utils/terminate-util';
import { AccountInfoInputComponent } from 'dhdt/branch/shared/components/number-input/account-info-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

/**
 * 口座状態照会【02_オープニング】renderer
 *
 * @export
 * @class AccountStatusInquiryOpeningRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: AccountStatusInquiryOpeningRenderer.name,
    templateYaml: 'chat-flow-def-account-status-inquiry-opening.yml'
})
export class AccountStatusInquiryOpeningRenderer extends DefaultChatFlowRenderer {
    public processType = COMMON_CONSTANTS.ProcessType.RequiredInput;
    private state: ClerkState;

    constructor(
        private action: ClerkAction,
        private store: ClerkStore,
        private modalService: ModalService,
        private labelService: LabelService,
        private terminateUtil: TerminateUtil,
        private loginStore: LoginStore,
        inputHandler: AccountStatusInquiryOpeningInputHandler,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): ClerkSubmitEntity {
        return this.state.submitData;
    }

    /**
     * リクエスト送信
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @Renderer(ClerkChatFlowQuestionTypes.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        switch (entity.name) {
            // 内部API: 口座状態照会
            case 'accountStatusInfo': {
                this.getAccountStatusInfo(entity, pageIndex);
                break;
            }
            // 内部API: 少額預金付帯サービス情報取得
            case 'incidentalInfo': {
                this.getIncidentalInfo(entity, pageIndex);
                break;
            }
            // 内部API: 睡眠・休眠情報照会
            case 'dormantDepositInfo': {
                this.getDormantDepositInfo(entity, pageIndex);
                break;
            }
            // 内部API: 不活動口座照会
            case 'inactiveAccountInfo': {
                this.getInactiveAccountInfo(entity, pageIndex);
                break;
            }
            // 内部API: CIF情報照会
            case 'customerInfo': {
                this.getCustomerInfo(entity, pageIndex);
                break;
            }
        }
    }

    @Renderer(ClerkChatFlowQuestionTypes.JUDGE)
    private onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        let judgeResult: boolean | string;
        let checkResult: { judgeResult: string, errorCode?: string, errorTitle?: string, errorMessage?: string };
        switch (entity.name) {
            case 'accountSearchStatus':
                // 口座検索結果
                judgeResult = this.state.submitData.accountSearchStatus;
                break;
            case 'isForeignCurrencySavings':
                // 解約口座の科目コードが「71:外貨普通」の場合、true
                judgeResult = this.state.submitData.terminateAccountType === ClerkConsts.AvailableAccountType.foreignCurrencySavings;
                break;
            case 'isforeignCurrencySavingsFixedDeposit':
                // 解約口座の科目コードが「71:外貨普通」または「73:外貨定期」の場合、true
                judgeResult = this.state.submitData.terminateAccountType === ClerkConsts.AvailableAccountType.foreignCurrencySavings
                    || this.state.submitData.terminateAccountType === ClerkConsts.AvailableAccountType.foreignCurrencyFixedDeposit;
                break;
            case 'bussinessCode':
                // 業務コード(Agent)
                judgeResult = this.state.submitData.bussinessCode;
                break;
            case 'dormantDepositSearchStatus':
                // 索引情報検索結果
                judgeResult = this.state.submitData.dormantDepositSearchStatus;
                break;
            case 'judgeByAccountStatus':
                checkResult = this.judgeByAccountStatus();
                if (checkResult.errorCode && checkResult.errorTitle && checkResult.errorMessage) {
                    this.showErrorModal(checkResult.errorCode, checkResult.errorTitle, checkResult.errorMessage, pageIndex);
                    return;
                }
                judgeResult = checkResult.judgeResult;
                break;
            case 'alreadyPaidOrTerminate':
                // ・活動口座の場合、true
                // ・上記以外の場合、false
                judgeResult = this.state.submitData.bussinessCode === ClerkConsts.BussinessCode.active;
                const errorMessage: string = judgeResult
                    ? this.labelService.labels.alert.terminateCounterAlreadyTerminateMessage
                    : this.labelService.labels.alert.terminateCounterAlreadyPaidMessage;
                checkResult = this.judgeByAccountStatus();
                this.showErrorModal(checkResult.errorCode, checkResult.errorTitle, errorMessage, pageIndex);
                return;
            case 'isActiveAccount':
                // ・解約する口座が活動中（少額預金解約）の場合、true
                // ・勘定系・CRM該当なしの場合、true
                // ・解約する口座が活動中（少額預金解約）で受付対象外の場合、true
                // ・上記以外の場合、false
                judgeResult
                    = this.state.submitData.bussinessCode === ClerkConsts.BussinessCode.active
                    || this.terminateUtil.getPattern(this.state.submitData) === ClerkConsts.Pattern.NOT_APPLICABLE
                    || this.state.submitData.bussinessCode === ClerkConsts.BussinessCode.notAccepted;
                break;
            case 'inactiveAccountSearchStatus':
                // CRM口座情報検索結果
                judgeResult =
                    this.state.submitData.inactiveAccountSearchStatus === ClerkConsts.InactiveAccountSearchStatus.Yes ? true : false;
                break;
            case 'isPassbookName':
                // 通帳証書区分、重要用紙種類を表示するか否かの判定
                const pattern: string = this.terminateUtil.getPattern(this.state.submitData);
                if ((pattern === ClerkConsts.Pattern.DORMANT
                    || pattern === ClerkConsts.Pattern.DORMANT_FOREIGN_CURRENCY_SAVINGS
                    || pattern === ClerkConsts.Pattern.CRM)
                    && this.state.submitData.accountSearchStatus === ClerkConsts.Status.ON
                    && this.state.submitData.terminateAccountType !== ClerkConsts.AvailableAccountType.foreignCurrencyFixedDeposit) {
                    judgeResult = true;
                    break;
                } else {
                    judgeResult = false;
                    break;
                }
            case 'isBelongToBranchNo':
                // 口座名義（勘定系顧客情報）を表示するか否かの判定
                if (this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.CC
                    && this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.INHERIT) {
                    judgeResult = false;
                    break;
                } else {
                    judgeResult = true;
                    break;
                }
            case 'isAccountingCustomerInfo':
                // 口座名義（勘定系顧客情報）を表示するか否かの判定
                /*if (this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.CC
                    && this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.INHERIT) {
                    judgeResult = false;
                    break;
                } else {
                    // 口座状態照会（行員操作 相続業務）の場合、勘定系顧客情報を保有している場合は表示する
                    judgeResult =
                        this.state.submitData.accountSearchStatus === ClerkConsts.Status.ON ||
                            this.state.submitData.mejarCustomerStatus === ClerkConsts.Status.ON
                            ? true : false;
                    break;
                }*/
                // 口座状態照会（行員操作 相続業務）の場合、勘定系顧客情報を保有している場合は表示する
                judgeResult =
                    this.state.submitData.accountSearchStatus === ClerkConsts.Status.ON ||
                        this.state.submitData.mejarCustomerStatus === ClerkConsts.Status.ON
                        ? true : false;
                break;
            case 'isCrmCustomerInfo':
                // 口座名義（ＣＲＭ顧客情報）を表示するか否かの判定
                /*if (this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.CC
                    && this.loginStore.getState().belongToBranchNo !== ClerkConsts.BranchCode.INHERIT) {
                    judgeResult = false;
                    break;
                } else {
                    // 口座状態照会（行員操作 相続業務）の場合、ＣＲＭ顧客情報を保有している場合は表示する
                    judgeResult =
                        this.state.submitData.inactiveAccountSearchStatus === ClerkConsts.Status.ON
                            && this.state.submitData.inactiveCustomerInfo ? true : false;
                    break;
                }*/
                // 口座状態照会（行員操作 相続業務）の場合、ＣＲＭ顧客情報を保有している場合は表示する
                judgeResult =
                    this.state.submitData.inactiveAccountSearchStatus === ClerkConsts.Status.ON
                        && this.state.submitData.inactiveCustomerInfo ? true : false;
                break;
            case 'judgeByDormantPassbook':
                checkResult = this.judgeByAccountStatus();
                judgeResult = checkResult.judgeResult;
                break;
        }
        for (const choice of entity.choices) {
            if (choice.value === judgeResult) {
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
                return;
            }
        }
    }

    @Renderer(ClerkChatFlowQuestionTypes.INPUT_TERMINATE_ACCOUNT_INFO)
    private onAccountInfoInput(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: AccountInfoInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * Pickerのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(ClerkChatFlowQuestionTypes.CURRENCY_CODE_PICKER)
    private onPicker(entity: ChatFlowMessageInterface, pageIndex: number) {
        // TODO 回避資産（開発後削除）
        // this.action.setAnswer({
        //     text: '米ドル',
        //     value: [
        //         { key: entity.name, value: '01' }
        //     ]
        // });
        // this.emitMessageRetrivalEvent(entity.next, pageIndex);

        // 通貨コード一覧をpicker表示
        const options = {
            type: entity.type,
            name: entity.name,
            validationRules: entity.validationRules,
            submitData: this.state.submitData,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: PickerCommonComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * エラーモーダルを表示する
     */
    private showErrorModal(errorCode: string, errorTitle: string, errorMessage: string, pageIndex: number) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        const subMessage = `<span class="font-color-red">${errorCode}：${errorTitle}</span>`;
        this.modalService.showAlert(
            errorMessage,
            subMessage, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal'
        );
    }

    /**
     * 内部API: 口座状態照会
     * @param entity entity
     * @param pageIndex pageIndex
     */
    private getAccountStatusInfo(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // SIGNAL HANDLER設置
        this.store.registerSignalHandler(ClerkSignal.ACCOUNT_STATUS_INFO_INQUIRY, () => {
            this.store.unregisterSignalHandler(ClerkSignal.ACCOUNT_STATUS_INFO_INQUIRY);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
        // APIの入力パラメータ設置
        const param: AccountStatusInfoInquiryRequest = {
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                tenban: this.state.submitData.terminateAccountBranchNo,
                accountType: this.state.submitData.terminateAccountType,
                accountNo: this.state.submitData.terminateAccountNo,
                currencyCode: this.state.submitData.selectCurrencyCode ? this.state.submitData.selectCurrencyCode : null,
            }
        };
        this.action.accountStatusInfoInquiry(param);
    }

    /**
     * 内部API: 少額預金口座付帯サービス情報取得
     * @param entity entity
     * @param pageIndex pageIndex
     */
    private getIncidentalInfo(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // SIGNAL HANDLER設置
        this.store.registerSignalHandler(ClerkSignal.INCIDENTAL_INFO_INQUIRY, () => {
            this.store.unregisterSignalHandler(ClerkSignal.INCIDENTAL_INFO_INQUIRY);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });

        // APIの入力パラメータ設置
        const param = new IncidentalInfoRequest(
            Number(this.loginStore.getState().tabletApplyId),
            this.loginStore.getState().belongToBranchNo,
            this.state.submitData.accountSearchStatus,
            this.state.submitData.customerInfo.customerId,
            this.state.submitData.customerInfo.otherOneSetStatus,
            this.state.submitData.accountStatusInfo
        );
        this.action.getIncidentalInfo(param);
    }

    /**
     * 内部API: 睡眠・休眠情報照会
     */
    private getDormantDepositInfo(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // SIGNAL HANDLER設置
        this.store.registerSignalHandler(ClerkSignal.DORMANT_DEPOSIT_INFO_INQIRY, () => {
            this.store.unregisterSignalHandler(ClerkSignal.DORMANT_DEPOSIT_INFO_INQIRY);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
        // APIの入力パラメータ設置
        const param = new DormantDepositInfoRequest(
            Number(this.loginStore.getState().tabletApplyId),
            this.loginStore.getState().belongToBranchNo,
            this.state.submitData.accountStatusInfo
        );
        this.action.dormantDepositInfoInqiry(param);
    }

    /**
     * 内部API: 不活動口座照会
     */
    private getInactiveAccountInfo(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // SIGNAL HANDLER設置
        this.store.registerSignalHandler(ClerkSignal.INACTIVE_ACCOUNT_INFO_INQUIRY, () => {
            this.store.unregisterSignalHandler(ClerkSignal.INACTIVE_ACCOUNT_INFO_INQUIRY);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
        // APIの入力パラメータ設置
        const param: InactiveAccountInfoInquiryRequest = {
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                tenban: this.state.submitData.terminateAccountBranchNo,
                accountType: this.state.submitData.terminateAccountType,
                accountNo: this.state.submitData.terminateAccountNo,
            }
        };
        this.action.inactiveAccountInfoInquiry(param);
    }

    /**
     * 内部API: CIF情報照会
     */
    private getCustomerInfo(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // APIの入力パラメータ設置
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                accounts: this.makeCifInfoParams(), // パラメータ編集
            }
        };

        this.store.registerSignalHandler(ClerkSignal.GET_CUSTOMER_INFO_NG, (response: HttpStatusError) => {
            // CI照会エラーの場合、処理続行する
            this.store.unregisterSignalHandler(ClerkSignal.GET_CUSTOMER_INFO);
            this.store.unregisterSignalHandler(ClerkSignal.GET_CUSTOMER_INFO_NG);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });

        this.store.registerSignalHandler(ClerkSignal.GET_CUSTOMER_INFO, () => {
            this.store.unregisterSignalHandler(ClerkSignal.GET_CUSTOMER_INFO);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });

        // CIF情報照会
        this.action.getCustomerInfo(param);
    }

    /**
     * 解約口座復唱後（K-5-5直後）の分岐先を判定する
     */
    private judgeByAccountStatus(): { judgeResult: string, errorCode?: string, errorTitle?: string, errorMessage?: string } {
        // 申込業務区分更新（照会のみのため、更新不要（暫定））
        // let info: {
        //     applyBusinessCategory: string;
        //     tabletApplyId: string;
        // };
        // info = {
        //     applyBusinessCategory: this.state.submitData.bussinessCode === ClerkConsts.BussinessCode.inActive ?
        //         ApplyBusinessType.INACTIVE : ApplyBusinessType.ACTIVE,
        //     tabletApplyId: this.loginStore.getState().tabletApplyId
        // };
        // this.action.updateApplyBizCategory(info);

        // 口座状態照会API「口座状態表示」リスト
        const accountStatusArray: string[] = [];
        if (this.state.submitData.accountStatusInfo) {
            accountStatusArray.push(this.state.submitData.accountStatusInfo.accountStatus);
            if (this.state.submitData.accountStatusInfo.partnerAccountInfo) {
                accountStatusArray.push(...this.state.submitData.accountStatusInfo.partnerAccountInfo.map((e) => e.accountStatus));
            }
        }
        // 睡眠・休眠情報照会API「雑益繰入／休眠移管区分」リスト
        const dormantDepositStatusArray: string[] = [];
        if (this.state.submitData.dormantDepositInfo) {
            if (this.state.submitData.dormantDepositInfo.accountInfo) {
                dormantDepositStatusArray.push(...this.state.submitData.dormantDepositInfo.accountInfo.map((e) => e.dormantDepositStatus));
            }
            if (this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo) {
                dormantDepositStatusArray.push(
                    ...this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo.map((e) => e.dormantDepositStatus));
            }
        }

        // CRM整理済口座リスト（単科目定期）
        let margedInactiveAccountInfo: InactiveAccountInfoCommon[] = [];
        let margedCrmInactiveAccountInfo: InactiveAccountInfoCommon[] = [];
        let matchFlag: boolean = false;
        if (this.state.submitData.inactiveAccountSearchStatus === ClerkConsts.Status.ON
            && this.state.submitData.inactiveAccountInfo.accountInfo[0].subjectCode === ClerkConsts.AvailableAccountType.fixedDeposit) {
            margedInactiveAccountInfo =
                this.state.submitData.inactiveAccountInfo.accountInfo.concat(
                    this.state.submitData.inactiveAccountInfo.secondaryAccountInfo);
            // 入力した口座の取引明細情報がある場合、摘要欄を取得する
            let res: { description: string, matchFlag: boolean, status: boolean };
            res = this.terminateUtil.getInputAccountInfo(
                this.state.submitData.terminateAccountBranchNo, this.state.submitData.terminateAccountType,
                this.state.submitData.terminateAccountNo, margedInactiveAccountInfo);
            if (res.matchFlag) {
                // 同一通帳先の口座を取得する
                margedCrmInactiveAccountInfo =
                    this.terminateUtil.getCrmInactiveAccountInfo(res.description, margedInactiveAccountInfo);
                matchFlag = res.matchFlag;
            }
        }

        // [外貨定期]
        if (this.state.submitData.terminateAccountType === ClerkConsts.AvailableAccountType.foreignCurrencyFixedDeposit
            && this.state.submitData.accountStatusInfo
            && this.state.submitData.accountStatusInfo.accountStatus === ClerkConsts.AccountStatus.Active) {
            return { judgeResult: '00' };
        }
        // [活動中の外貨普通]
        if (this.state.submitData.terminateAccountType === ClerkConsts.AvailableAccountType.foreignCurrencySavings
            && this.state.submitData.accountStatusInfo
            && this.state.submitData.accountStatusInfo.accountStatus === ClerkConsts.AccountStatus.Active) {
            return { judgeResult: '01' };
        }
        // [雑益繰入/不活動繰入の外貨普通]
        if (this.state.submitData.terminateAccountType === ClerkConsts.AvailableAccountType.foreignCurrencySavings
            && this.state.submitData.accountStatusInfo
            && (this.state.submitData.accountStatusInfo.accountStatus === ClerkConsts.AccountStatus.IncomeCancellation
                || this.state.submitData.accountStatusInfo.accountStatus === ClerkConsts.AccountStatus.InactiveCancellation)) {
            if ((Number(this.state.submitData.accountStatusInfo.forexDormantAmount) > 0)) {
                return { judgeResult: '02' };
            }
            // [MEJAR後 外貨普通 雑益・不活動繰入外貨額ゼロの場合]
            return {
                judgeResult: '04',
                errorCode: AgentInternalError.ERROR_CODE_N_017,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_017,
            };
        }
        // [受付対象外の場合]（睡眠預金解約 人格コードが個人以外）
        if (this.state.submitData.bussinessCode === ClerkConsts.BussinessCode.inActive
            && this.state.submitData.customerInfo
            && this.state.submitData.customerInfo.personalityCode
            && this.state.submitData.customerInfo.personalityCode !== ClerkConsts.PersonalityCode.Individual) {
            return {
                judgeResult: '03',
                errorCode: AgentInternalError.ERROR_CODE_N_011,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_011,
                errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
            };
        }
        // [受付対象外の場合]（MEJAR前 定期・通知証書式）
        const isCertificateBeforeMejar: boolean =
            this.state.submitData.inactiveAccountInfo
            && this.state.submitData.inactiveAccountInfo.accountInfo
            && this.state.submitData.inactiveAccountInfo.accountInfo.length
            && this.isFixedDepositOrNotification(this.state.submitData.inactiveAccountInfo.accountInfo[0].subjectCode)
            && (this.state.submitData.inactiveAccountInfo.accountInfo[0].transactionDetailsInfo || [])
                .some((e) => this.getPassbookCategoryByRequestNo(e.requestNo) === ClerkConsts.PassbookCategory.certificate);
        // [受付対象外の場合]（MEJAR後 定期・通知証書式）※活動口座は除く
        const isCertificateAfterMejar: boolean =
            this.state.submitData.accountStatusInfo
            && this.isFixedDepositOrNotification(this.state.submitData.accountStatusInfo.subjectCode)
            && this.state.submitData.accountStatusInfo.accountStatus !== ClerkConsts.AccountStatus.Active
            && this.state.submitData.accountStatusInfo.passbookCategory === ClerkConsts.PassbookCategory.certificate;
        if (isCertificateBeforeMejar || isCertificateAfterMejar) {
            return {
                judgeResult: '03',
                errorCode: AgentInternalError.ERROR_CODE_N_013,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_013,
                errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
            };
        }
        // [外貨普通 複数通貨保有先の場合]
        if (this.state.submitData.terminateAccountType === ClerkConsts.AvailableAccountType.foreignCurrencySavings
            && this.state.submitData.accountStatusInfo
            && this.state.submitData.accountStatusInfo.currencyCode === ClerkConsts.MultipleCurrencyCode.MultipleCode) {
            return {
                judgeResult: '03',
                errorCode: AgentInternalError.ERROR_CODE_N_039,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_039,
                errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
            };
        }
        // [受付対象外の場合]（受付対象外の科目や口座状態）※活動口座は除く
        if (this.state.submitData.bussinessCode === ClerkConsts.BussinessCode.notAccepted
            && this.state.submitData.agentErrorCode !== AgentInternalError.ERROR_CODE_N_018
            && this.state.submitData.accountStatusInfo.accountStatus !== ClerkConsts.AccountStatus.Active
            && (this.state.submitData.accountStatusInfo.partnerAccountInfo || [])
                .every((e) => e.accountStatus !== ClerkConsts.AccountStatus.Active)) {
            return {
                judgeResult: '03',
                errorCode: this.state.submitData.agentErrorCode,
                errorTitle: this.labelService.labels.terminate.errorMessage[this.state.submitData.agentErrorCode.replace('-', '_')],
                errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
            };
        }
        // [MEJAR後 雑益・休眠混在の場合]
        if (dormantDepositStatusArray.indexOf(ClerkConsts.DormantDepositStatus.IncomeTransferred) > -1
            && dormantDepositStatusArray.indexOf(ClerkConsts.DormantDepositStatus.DormantTransferred) > -1) {
            return {
                judgeResult: '03',
                errorCode: AgentInternalError.ERROR_CODE_N_015,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_015,
                errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
            };
        }
        // [MEJAR後 活動・休眠／雑益混在の場合]
        if (accountStatusArray.indexOf(ClerkConsts.AccountStatus.Active) > -1
            && accountStatusArray.indexOf(ClerkConsts.AccountStatus.Dormant) > -1) {
            return {
                judgeResult: '03',
                errorCode: AgentInternalError.ERROR_CODE_N_014,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_014,
                errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
            };
        }
        // [MEJAR後 主口座が解約済・相手口座が休眠/雑益混在の場合]
        if (!StringUtils.isEmpty(this.state.submitData.dormantDepositSearchStatus) &&
            this.state.submitData.dormantDepositSearchStatus === ClerkConsts.Status.ON) {
            // MEJAR後 主口座が普通で解約済みの場合、isSavingsFlag: trueに設定する
            let isSavignsFlag: boolean = false;
            let isClosedAndDormant: boolean = false;
            if (this.state.submitData.dormantDepositInfo.accountInfo &&
                this.state.submitData.dormantDepositInfo.accountInfo.length > 0) {
                if (this.state.submitData.dormantDepositInfo.accountInfo[0].subjectCode === ClerkConsts.AvailableAccountType.savings
                    && this.state.submitData.dormantDepositInfo.accountInfo[0].accountStatus === ClerkConsts.AccountStatus.Closed) {
                    isSavignsFlag = true;
                }
            }
            if (isSavignsFlag) {
                // MEJAR後 主口座が普通口座、解約済みの場合 かつ
                // MEJAR後 相手口座が１口座以上あり、休眠・雑益口座の場合
                if (this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo
                    && this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo.length > 0) {
                    isClosedAndDormant = this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo.some((e) =>
                        e.dormantDepositStatus === ClerkConsts.DormantDepositStatus.DormantTransferred
                        || e.dormantDepositStatus === ClerkConsts.DormantDepositStatus.IncomeTransferred);
                    if (isClosedAndDormant) {
                        return {
                            judgeResult: '03',
                            errorCode: AgentInternalError.ERROR_CODE_N_014,
                            errorTitle: this.labelService.labels.terminate.errorMessage.N_014_2,
                            errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
                        };
                    }
                }
            }
        }
        // [MEJAR前 雑益/不活動取消済みの場合（旧取引履歴の取消明細がある場合）]
        let isDeleteStatusOn: boolean = false;
        if (matchFlag) {
            // 単科目定期 同一通帳先の場合
            isDeleteStatusOn =
                margedCrmInactiveAccountInfo
                && margedCrmInactiveAccountInfo.length
                && margedCrmInactiveAccountInfo.every((e) => e.deleteStatus === ClerkConsts.Status.ON);
        } else {
            isDeleteStatusOn =
                this.state.submitData.inactiveAccountInfo
                && this.state.submitData.inactiveAccountInfo.accountInfo
                && this.state.submitData.inactiveAccountInfo.accountInfo.length
                && this.state.submitData.inactiveAccountInfo.accountInfo.every((e) => e.deleteStatus === ClerkConsts.Status.ON)
                && (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo || [])
                    .every((e) => e.deleteStatus === ClerkConsts.Status.ON);
        }
        if (isDeleteStatusOn) {
            return {
                judgeResult: '03',
                errorCode: AgentInternalError.ERROR_CODE_N_037,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_037,
                errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
            };
        }
        // [MEJAR前/後 繰入金額がゼロ円の場合（※ワンセットを除く）]
        let zeroPrincipalAmountBeforeMejar: boolean = false;
        let zeroPrincipalAmountAfterMejar: boolean = false;
        if (matchFlag) {
            // 単科目定期 同一通帳先の場合
            zeroPrincipalAmountBeforeMejar =
                margedCrmInactiveAccountInfo
                && margedCrmInactiveAccountInfo.length
                && margedCrmInactiveAccountInfo
                    .every((e) => e.transactionDetailsInfo
                        && e.transactionDetailsInfo.length
                        && this.isFalsyOrStringZero(this.terminateUtil.getPrincipalAmount(e.transactionDetailsInfo)));
        } else {
            zeroPrincipalAmountBeforeMejar =
                this.state.submitData.inactiveAccountInfo
                && this.state.submitData.inactiveAccountInfo.accountInfo
                && this.state.submitData.inactiveAccountInfo.accountInfo.length
                && this.state.submitData.inactiveAccountInfo.accountInfo
                    .every((e) => e.transactionDetailsInfo
                        && e.transactionDetailsInfo.length
                        && this.isFalsyOrStringZero(this.terminateUtil.getPrincipalAmount(e.transactionDetailsInfo)))
                && (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo || [])
                    .every((e) => e.transactionDetailsInfo
                        && e.transactionDetailsInfo.length
                        && this.isFalsyOrStringZero(this.terminateUtil.getPrincipalAmount(e.transactionDetailsInfo)))
                && !this.existsOneSet();
            zeroPrincipalAmountAfterMejar =
                this.state.submitData.accountSearchStatus === ClerkConsts.Status.ON
                && this.state.submitData.accountStatusInfo
                && this.state.submitData.accountStatusInfo.passbookTypeCode !== ClerkConsts.PassbookTypeCode.onesetNew
                && this.state.submitData.accountStatusInfo.passbookTypeCode !== ClerkConsts.PassbookTypeCode.onesetCarry
                && this.state.submitData.dormantDepositSearchStatus === ClerkConsts.Status.ON
                && this.state.submitData.dormantDepositInfo
                && this.state.submitData.dormantDepositInfo.accountInfo
                && this.state.submitData.dormantDepositInfo.accountInfo.every((e) => this.isFalsyOrStringZero(e.dormantAmount))
                && (this.state.submitData.dormantDepositInfo.partnerDormantAccountInfo || [])
                    .every((e) => this.isFalsyOrStringZero(e.dormantAmount));
        }
        if (zeroPrincipalAmountBeforeMejar || zeroPrincipalAmountAfterMejar) {
            return {
                judgeResult: '04',
                errorCode: AgentInternalError.ERROR_CODE_N_017,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_017,
            };
        }
        // [MEJAR後 契約・媒体単位内の全ての口座が支払済の場合]
        // [MEJAR後 単一媒体で支払済の場合]
        const isPaidAfterMejar: boolean =
            dormantDepositStatusArray.length && dormantDepositStatusArray.every((e) =>
                e === ClerkConsts.DormantDepositStatus.IncomePaid || e === ClerkConsts.DormantDepositStatus.DormantPaid);
        // [MEJAR前 契約・媒体単位内の全ての口座が解約済の場合]
        // [MEJAR前 単一媒体で解約済の場合]
        let isClosedBeforeMejar: boolean = false;
        if (matchFlag) {
            // 単科目定期 同一通帳先の場合
            isClosedBeforeMejar =
                margedCrmInactiveAccountInfo
                && margedCrmInactiveAccountInfo.length
                && margedCrmInactiveAccountInfo
                    .every((e) => e.closedStatus === ClerkConsts.Status.ON);
        } else {
            isClosedBeforeMejar =
                this.state.submitData.inactiveAccountInfo
                && this.state.submitData.inactiveAccountInfo.accountInfo
                && this.state.submitData.inactiveAccountInfo.accountInfo.length
                && this.state.submitData.inactiveAccountInfo.accountInfo
                    .every((e) => e.closedStatus === ClerkConsts.Status.ON)
                && (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo || [])
                    .every((e) => e.closedStatus === ClerkConsts.Status.ON);
        }
        // [MEJAR後 対象先全ての口座が解約済の場合（※少額預金解約）]
        if (isPaidAfterMejar || isClosedBeforeMejar
            || this.state.submitData.agentErrorCode === AgentInternalError.ERROR_CODE_N_018) {
            return {
                judgeResult: '04',
                errorCode: AgentInternalError.ERROR_CODE_N_018,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_018,
            };
        }
        // [MEJAR前 契約・媒体単位内の全てのCRM口座がステータスなしの場合]
        // [MEJAR前 単一媒体でCRM口座がステータスなしの場合]
        const isNonStatusBeforeMejar: boolean =
            this.state.submitData.inactiveAccountSearchStatus === ClerkConsts.Status.ON
            && this.state.submitData.inactiveAccountInfo
            && this.state.submitData.inactiveAccountInfo.accountInfo
            && this.state.submitData.inactiveAccountInfo.accountInfo.length
            && this.state.submitData.inactiveAccountInfo.accountInfo
                .every((e) => StringUtils.isEmpty(e.transferStatus)
                    && StringUtils.isEmpty(e.closedStatus)
                    && StringUtils.isEmpty(e.dormantAccountStatus)
                    && StringUtils.isEmpty(e.centerClosedStatus))
            && (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo || [])
                .every((e) => StringUtils.isEmpty(e.transferStatus)
                    && StringUtils.isEmpty(e.closedStatus)
                    && StringUtils.isEmpty(e.dormantAccountStatus)
                    && StringUtils.isEmpty(e.centerClosedStatus));
        if (isNonStatusBeforeMejar) {
            return {
                judgeResult: '11',
                errorCode: AgentInternalError.ERROR_CODE_N_044,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_044,
                errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
            };
        }
        // [MEJAR前 契約媒体単位で１件も雑益口座がない場合（非活動で混在）]
        if (this.terminateUtil.getPattern(this.state.submitData) === ClerkConsts.Pattern.CRM) {
            let isNonAactiveAccountBeforeMejar: boolean = false;
            let isAllTransferAccountBeforeMejar: boolean = false;
            if (matchFlag) {
                // 単科目定期 同一通帳先の場合
                isNonAactiveAccountBeforeMejar =
                    margedCrmInactiveAccountInfo
                    && margedCrmInactiveAccountInfo.length
                    && margedCrmInactiveAccountInfo
                        .some((e) => (e.dormantAccountStatus === ClerkConsts.Status.ON
                            || e.centerClosedStatus === ClerkConsts.Status.ON)
                            && e.deleteStatus !== ClerkConsts.Status.ON);
                isAllTransferAccountBeforeMejar =
                    margedCrmInactiveAccountInfo
                    && margedCrmInactiveAccountInfo.length
                    && margedCrmInactiveAccountInfo
                        .every((e) => (e.transferStatus === ClerkConsts.Status.ON));
            } else {
                isNonAactiveAccountBeforeMejar =
                    this.state.submitData.inactiveAccountInfo
                    && this.state.submitData.inactiveAccountInfo.accountInfo.length
                    && (this.state.submitData.inactiveAccountInfo.accountInfo
                        .some((e) => (e.dormantAccountStatus === ClerkConsts.Status.ON
                            || e.centerClosedStatus === ClerkConsts.Status.ON)
                            && e.deleteStatus !== ClerkConsts.Status.ON)
                        || (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo || [])
                            .some((e) => (e.dormantAccountStatus === ClerkConsts.Status.ON
                                || e.centerClosedStatus === ClerkConsts.Status.ON)
                                && e.deleteStatus !== ClerkConsts.Status.ON));
                isAllTransferAccountBeforeMejar =
                    this.state.submitData.inactiveAccountInfo
                    && this.state.submitData.inactiveAccountInfo.accountInfo.length
                    && (this.state.submitData.inactiveAccountInfo.accountInfo
                        .every((e) => e.transferStatus === ClerkConsts.Status.ON)
                        && (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo || [])
                            .every((e) => e.transferStatus === ClerkConsts.Status.ON));
            }
            if (!isNonAactiveAccountBeforeMejar && !isAllTransferAccountBeforeMejar) {
                return {
                    judgeResult: '12',
                    errorCode: AgentInternalError.ERROR_CODE_N_045,
                    errorTitle: this.labelService.labels.terminate.errorMessage.N_045,
                    errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
                };
            }
        }
        // [MEJAR前 移管済み口座の場合]
        const isTransferedBeforeMejar: boolean =
            this.state.submitData.inactiveAccountInfo
            && this.state.submitData.inactiveAccountInfo.accountInfo
            && this.state.submitData.inactiveAccountInfo.accountInfo.length
            && (this.state.submitData.inactiveAccountInfo.accountInfo
                .some((e) => e.branchCode === this.state.submitData.terminateAccountBranchNo
                    && (e.subjectCode === this.state.submitData.terminateAccountType
                        || e.subjectCode === ClerkConsts.AvailableAccountType.savingsOrDeposit)
                    && e.bankAccountId === this.state.submitData.terminateAccountNo
                    && e.transferStatus === ClerkConsts.Status.ON)
                || (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo || [])
                    .some((e) => e.branchCode === this.state.submitData.terminateAccountBranchNo
                        && (e.subjectCode === this.state.submitData.terminateAccountType
                            || e.subjectCode === ClerkConsts.AvailableAccountType.savingsOrDeposit)
                        && e.bankAccountId === this.state.submitData.terminateAccountNo
                        && e.transferStatus === ClerkConsts.Status.ON));
        if (isTransferedBeforeMejar) {
            if (this.state.submitData.inactiveAccountInfo.accountInfo
                .every((e) => Boolean(e.transferBranchCode)
                    && Boolean(e.transferBankAccountId))) {
                // 移管先口座情報がある場合
                return { judgeResult: '08' };
            } else {
                // 移管先口座情報がない場合
                return { judgeResult: '09' };
            }
        }
        // [MEJAR前 取消後、再度、雑益した明細は受付対象外]
        let isRetrading: boolean = false;
        if (matchFlag) {
            isRetrading =
                margedCrmInactiveAccountInfo
                && margedCrmInactiveAccountInfo.length
                && margedCrmInactiveAccountInfo
                    .some((e) => e.deleteStatus === ClerkConsts.Status.SECOND);
        } else {
            isRetrading =
                this.state.submitData.inactiveAccountInfo
                && this.state.submitData.inactiveAccountInfo.accountInfo
                && this.state.submitData.inactiveAccountInfo.accountInfo.length
                && (this.state.submitData.inactiveAccountInfo.accountInfo
                    .some((e) => e.deleteStatus === ClerkConsts.Status.SECOND)
                    || (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo || [])
                        .some((e) => e.deleteStatus === ClerkConsts.Status.SECOND));
        }
        if (isRetrading) {
            return {
                judgeResult: '13',
                errorCode: AgentInternalError.ERROR_CODE_N_042,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_042,
                errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
            };
        }
        // [MEJAR前 定期/通知 明細数26以上の場合]
        // [MEJAR後 定期/通知 明細数26以上の場合]
        // 睡眠・休眠情報照会API「継続明細表示」がある場合、または不活動口座照会API「継続明細表示」がある場合、true
        const isContinueDetailsStatusBeforeMejar
            = this.state.submitData.inactiveAccountInfo
            && (this.state.submitData.inactiveAccountInfo.accountInfo.
                some((e) => e.continueDetailsStatus === ClerkConsts.Status.ON)
                || (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo || [])
                    .some((e) => e.continueDetailsStatus === ClerkConsts.Status.ON));
        const isContinueDetailsStatusAfterMejar
            = this.state.submitData.dormantDepositInfo
            && this.state.submitData.dormantDepositInfo.continueDetailsStatus === ClerkConsts.Status.ON;
        if (isContinueDetailsStatusBeforeMejar || isContinueDetailsStatusAfterMejar) {
            return {
                judgeResult: '14',
                errorCode: AgentInternalError.ERROR_CODE_N_046,
                errorTitle: this.labelService.labels.terminate.errorMessage.N_046,
                errorMessage: this.labelService.labels.alert.terminateTradingStatusMessage
            };
        }
        // [MEJAR後支払済で10年経過先]
        // 入力した店科口が主口座にあるか判定
        if (this.loginStore.getState().belongToBranchNo === ClerkConsts.BranchCode.CC
            || this.loginStore.getState().belongToBranchNo === ClerkConsts.BranchCode.INHERIT) {
            const isDormantAccountFlag: Boolean
                = this.state.submitData.accountStatusInfo
                && this.state.submitData.accountStatusInfo.branchCode
                === this.state.submitData.terminateAccountBranchNo
                && this.state.submitData.accountStatusInfo.subjectCode
                === this.state.submitData.terminateAccountType
                && this.state.submitData.accountStatusInfo.bankAccountId
                === this.state.submitData.terminateAccountNo
                && this.state.submitData.accountStatusInfo.accountStatus
                === ClerkConsts.AccountStatus.Dormant;

            // 入力した店科口が従口座にあるか判定
            const isDormantPartnerAccountFlag: Boolean
                = this.state.submitData.accountStatusInfo.partnerAccountInfo
                && this.state.submitData.accountStatusInfo.partnerAccountInfo
                    .some((e) => e.branchCode === this.state.submitData.terminateAccountBranchNo
                        && e.subjectCode === this.state.submitData.terminateAccountType
                        && e.bankAccountId === this.state.submitData.terminateAccountNo
                        && e.accountStatus === ClerkConsts.AccountStatus.Dormant);

            // 入力した店科口が索引にも不活動にもないことを判定
            const isDormantAndInactive: Boolean
                = this.state.submitData.dormantDepositSearchStatus === ClerkConsts.Status.OFF
                && this.state.submitData.inactiveAccountSearchStatus === ClerkConsts.Status.OFF;

            if ((isDormantAccountFlag || isDormantPartnerAccountFlag) && isDormantAndInactive) {
                return { judgeResult: '15' };
            }
        }
        // [その他]
        return { judgeResult: '99' };
    }

    /**
     * ワンセットであるか判定する
     */
    private existsOneSet(): boolean {
        // 元帳がある場合は重要用紙種類コードで判定
        if (this.state.submitData.accountSearchStatus === ClerkConsts.Status.ON) {
            return this.state.submitData.accountStatusInfo.passbookTypeCode === ClerkConsts.PassbookTypeCode.onesetNew
                || this.state.submitData.accountStatusInfo.passbookTypeCode === ClerkConsts.PassbookTypeCode.onesetCarry;
        }
        // 元帳がない場合、普通＋貯蓄がある場合はワンセット通帳とみなす。
        // 不活動口座照会APIで取得した口座情報リスト
        const inactiveAccountInfoList: Array<{ branchCode: string, subjectCode: string, bankAccountId: string }> = [];
        if (this.state.submitData.inactiveAccountInfo.accountInfo
            && this.state.submitData.inactiveAccountInfo.accountInfo.length) {
            this.state.submitData.inactiveAccountInfo.accountInfo.forEach((e) => inactiveAccountInfoList.push({
                branchCode: e.branchCode,
                subjectCode: e.subjectCode,
                bankAccountId: e.bankAccountId
            }));
        }
        if (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo
            && this.state.submitData.inactiveAccountInfo.secondaryAccountInfo.length) {
            this.state.submitData.inactiveAccountInfo.secondaryAccountInfo.forEach((e) => inactiveAccountInfoList.push({
                branchCode: e.branchCode,
                subjectCode: e.subjectCode,
                bankAccountId: e.bankAccountId
            }));
        }
        const savings = inactiveAccountInfoList.some((e) =>
            e.subjectCode === ClerkConsts.AvailableAccountType.savings
        );
        const deposit = inactiveAccountInfoList.some((e) =>
            e.subjectCode === ClerkConsts.AvailableAccountType.deposit
        );
        return savings && deposit;
    }

    /**
     * 科目コードが「20:定期預金」または「16:通知預金」であるか
     */
    private isFixedDepositOrNotification(subjectCode: string): boolean {
        return subjectCode === ClerkConsts.AvailableAccountType.fixedDeposit
            || subjectCode === ClerkConsts.AvailableAccountType.notification;
    }

    /**
     * RQ番号から通帳証書区分（通帳式／証書式）を取得する
     */
    private getPassbookCategoryByRequestNo(requestNo: string): string {
        switch (requestNo) {
            case ClerkConsts.RequestNo.PassbookFixedDeposit:
                return ClerkConsts.PassbookCategory.passbook;
            case ClerkConsts.RequestNo.CertificateFixedDeposit:
            case ClerkConsts.RequestNo.CertificateNotification:
                return ClerkConsts.PassbookCategory.certificate;
            default:
                return undefined;
        }
    }

    /**
     * Falsy（null/undefined/空文字）または文字列"0"であるか
     */
    private isFalsyOrStringZero(target: string): boolean {
        return !Boolean(target) || target === String(Constants.ZERO);
    }

    /**
     * 顧客情報照会APIのパラメータリスト作成
     */
    private makeCifInfoParams(): any {
        const accountsListArr = [];
        let account = {};
        // 不活動口座情報照会の顧客番号を設定
        account = {
            tenban: null,
            accountType: null,
            accountNo: null,
            customerId: this.state.submitData.inactiveCustomerInfo.customerId
        };
        accountsListArr.push(account);
        return accountsListArr;
    }
}
