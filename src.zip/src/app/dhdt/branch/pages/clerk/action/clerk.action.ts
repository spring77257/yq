import { Injectable, NgZone } from '@angular/core';
import { Action } from 'adep/flux';
import { API_URL } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { AccountStatusInfoInquiryRequest } from 'dhdt/branch/pages/terminate/entity/account-status-info-inquiry-request.entity';
import { DormantDepositInfoRequest } from 'dhdt/branch/pages/terminate/entity/dornant-deposit-info-request.entity';
import { InactiveAccountInfoInquiryRequest } from 'dhdt/branch/pages/terminate/entity/inactive-account-info-inquiry-request.entity';
import { ChatFlowActionInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-action.interface';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { HttpService } from 'dhdt/branch/shared/services/http.service';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';

export namespace ClerkActionType {
    export const GET_SAVING_QUESTION_TEMPLATE = 'ClerkActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const SET_ANSWER = 'ClerkActionType_SET_ANSWER';
    export const NEXT_CHAT = 'ClerkActionType_NEXT_CHAT';
    export const CHAT_FLOW_COMPLETE = 'ClerkActionType_CHAT_FLOW_COMPLETE';
    export const EDIT_ANSWER = 'ClerkActionType_EDIT_ANSWER';
    export const RESET_LAST_NODE = 'ClerkActionType_RESET_LAST_NODE';
    export const CLEAR_SHOW_CHATS = 'ClerkActionType_CLEAR_SHOW_CHATS';
    export const SUBMIT_DATA_BACKUP = 'ClerkActionType_SUBMIT_DATA_BACKUP';
    export const CLEAR_STATE = 'ClerkActionType.CLEAR_STATE';
    export const SET_STATE_SUBMIT_DATA_VALUE = 'ClerkActionType_SET_STATE_SUBMIT_DATA_VALUE';
    export const SPLICE_SHOW_CHATS = 'ClerkActionType_SPLICE_SHOW_CHATS';
    export const RESET_SUBMIT_DATA = 'ClerkActionType_RESET_SUBMIT_DATA';
    export const GET_BRANCH_NAME = 'ClerkActionType_RESET_GET_BRANCH_NAME';
    export const ACCOUNT_STATUS_INFO_INQUIRY = 'ClerkActionType_ACCOUNT_STATUS_INFO_INQUIRY';
    export const INCIDENTAL_INFO_INQUIRY = 'ClerkActionType_INCIDENTAL_INFO_INQUIRY';
    export const DORMANT_DEPOSIT_INFO_INQIRY = 'ClerkActionType_DORMANT_DEPOSIT_INFO_INQIRY';
    export const INACTIVE_ACCOUNT_INFO_INQUIRY = 'ClerkActionType_INACTIVE_ACCOUNT_INFO_INQUIRY';
    export const GET_CUSTOMER_INFO = 'ClerkActionType_GET_CUSTOMER_INFO';
    export const GET_CUSTOMER_INFO_NG = 'ClerkActionType_GET_CUSTOMER_INFO_NG';
    export const RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK = 'ClerkActionType_RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK';
    export const UNACCEPTABLES_NG = 'ClerkActionType_UNACCEPTABLES_NG';
}

@Injectable()
export class ClerkAction extends Action implements ChatFlowActionInterface {

    constructor(
        private httpService: HttpService,
        private ngZone: NgZone,
    ) {
        super();
    }

    public loadTemplate(file: string, pageIndex: number) {
        this.httpService.get(API_URL.CHATFLOW_DEFINITION + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ClerkActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    fileInfo: response.result.fileInfos,
                    pageIndex: pageIndex
                }
            });
        });
    }

    public setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this.dispatcher.dispatch({
            actionType: ClerkActionType.SET_ANSWER,
            data: answer
        });
    }

    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: ClerkActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    public chatFlowCompelete(nextChatName: string) {
        this.dispatcher.dispatch({
            actionType: ClerkActionType.CHAT_FLOW_COMPLETE,
            data: nextChatName
        });
    }

    public editAnswer(order: number, pageIndex: number, answerOrder: number, showChatIndex?: number): void {
        this.dispatcher.dispatch({
            actionType: ClerkActionType.EDIT_ANSWER,
            data: { order: order, pageIndex: pageIndex, answerOrder: answerOrder, showChatIndex: showChatIndex }
        });
    }

    public resetLastNode(): void {
        this.dispatcher.dispatch({
            actionType: ClerkActionType.RESET_LAST_NODE,
        });
    }

    public clearShowChats(): void {
        this.dispatcher.dispatch({
            actionType: ClerkActionType.CLEAR_SHOW_CHATS
        });
    }

    public submitDataBackup(): void {
        this.dispatcher.dispatch({
            actionType: ClerkActionType.SUBMIT_DATA_BACKUP
        });
    }

    /**
     * stateをクリアする
     */
    public clearState() {
        this.dispatcher.dispatch({
            actionType: ClerkActionType.CLEAR_STATE
        });
    }

    /**
     * submitDataに値を設定する
     * @param param 項目値
     */
    public setStateSubmitDataValue(param: { name: string, value: any }) {
        this.dispatcher.dispatch({
            actionType: ClerkActionType.SET_STATE_SUBMIT_DATA_VALUE,
            data: param
        });
    }

    /**
     * 表示中のチャットを削除する
     * @param start 削除を開始する要素の位置
     */
    public spliceShowChats(start: number) {
        this.dispatcher.dispatch({
            actionType: ClerkActionType.SPLICE_SHOW_CHATS,
            data: start
        });
    }

    /**
     * タブレット申込管理テーブルの申込業務区分・ステータスを更新する
     * @param params 申込業務区分、タブレット申込管理ID
     */
    public updateApplyBizCategory(params: { applyBusinessCategory: string, tabletApplyId: string }) {
        this.httpService.post(API_URL.UPDATE_APPLY_BUSINESS_CATEGORY, params).subscribe((response) => {
            // do-nothing
        });
    }

    /**
     * submit dataをリセットする
     */
    public resetSubmitData() {
        this.dispatcher.dispatch({
            actionType: ClerkActionType.RESET_SUBMIT_DATA
        });
    }

    /**
     * 内部API: 店舗マスタより店名を取得
     * @param branchCode 店番号
     */
    public getBranchName(branchCode: string) {
        const params = {
            branchCode: branchCode,
        };
        this.httpService.get(API_URL.BRANCH_NAME, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ClerkActionType.GET_BRANCH_NAME,
                data: response.result
            });
        });
    }

    /**
     * 内部API: 口座状態照会
     * @param params
     */
    public accountStatusInfoInquiry(params: AccountStatusInfoInquiryRequest) {
        this.httpService.post(API_URL.ACCOUNT_STATUS_INFO_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ClerkActionType.ACCOUNT_STATUS_INFO_INQUIRY,
                data: response.result
            });
        });
    }

    /**
     * 内部API: 少額預金口座付帯サービス情報取得
     * @param params
     */
    public getIncidentalInfo(params: any) {
        this.httpService.post(API_URL.INCIDENTAL_INFO_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: ClerkActionType.INCIDENTAL_INFO_INQUIRY,
                data: response.result
            });
        });
    }

    /**
     * 内部API: 睡眠・休眠情報照会
     * @param params
     */
    public dormantDepositInfoInqiry(params: DormantDepositInfoRequest) {
        this.httpService.post(API_URL.DORMANT_DEPOSIT_INFO_INQIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ClerkActionType.DORMANT_DEPOSIT_INFO_INQIRY,
                data: response.result
            });
        });
    }

    /**
     * 内部API: 不活動口座照会
     */
    public inactiveAccountInfoInquiry(params: InactiveAccountInfoInquiryRequest) {
        this.httpService.post(API_URL.INACTIVE_ACCOUNT_INFO_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ClerkActionType.INACTIVE_ACCOUNT_INFO_INQUIRY,
                data: response.result
            });
        });
    }

    /**
     * 内部API: CIF情報照会
     */
    public getCustomerInfo(params: any) {
        this.httpService.post(API_URL.CB_CIF_INFOS_INQUIRY, params, null, SpinnerType.SHOW, true).
            subscribe((response: any) => {
                if (response instanceof HttpStatusError) {
                    // エラー発生時
                    if (response.errors && response.errors.data) {
                        this.dispatcher.dispatch({
                            actionType: ClerkActionType.GET_CUSTOMER_INFO_NG,
                            data: response
                        });
                        return;
                    } else {
                        // 上記以外のエラーの場合、共通エラーハンドリング処理にて処理する
                        this.ngZone.runTask(() => {
                            throw response;
                        });
                        return;
                    }
                }

                this.dispatcher.dispatch({
                    actionType: ClerkActionType.GET_CUSTOMER_INFO,
                    data: response.result
                });
            });
    }

    /**
     * 内部API：業務受付可否チェック
     * @param params
     */
    public receptionCancelAccountApplyCheck(params: any) {
        this.httpService.post(API_URL.RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK, params, null, SpinnerType.SHOW, true).
            subscribe((response: any) => {
                // エラー発生時
                if (response instanceof HttpStatusError) {
                    // 事故取引禁止注意コードエラーの場合
                    if (response.errors && response.errors.data) {
                        this.dispatcher.dispatch({
                            actionType: ClerkActionType.UNACCEPTABLES_NG,
                            data: response
                        });
                        return;
                    } else {
                        // 上記以外のエラーの場合、共通エラーハンドリング処理にて処理する
                        this.ngZone.runTask(() => {
                            throw response;
                        });
                        return;
                    }
                }

                // 次の業務に移動する
                this.dispatcher.dispatch({
                    actionType: ClerkActionType.RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK,
                    data: response.result
                });
            });
    }

}
