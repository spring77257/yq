import { Injectable, NgZone } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { ClerkActionType } from 'dhdt/branch/pages/clerk/action/clerk.action';
import { ClerkConsts } from 'dhdt/branch/pages/clerk/clerk-consts';
import { ClerkSubmitEntity } from 'dhdt/branch/pages/clerk/entity/clerk-submit.entity';
import { AccountStatusInfoInquiryResponse } from 'dhdt/branch/pages/terminate/entity/account-status-info-inquiry-response.entity';
import { DormantDepositInfoResponse } from 'dhdt/branch/pages/terminate/entity/dornant-deposit-info-response.entity';
import { InactiveAccountInfoInquiryResponse } from 'dhdt/branch/pages/terminate/entity/inactive-account-info-inquiry-response.entity';
import { TerminateUtil } from 'dhdt/branch/pages/terminate/utils/terminate-util';
import {
    ChatFlowMessageInterface, ChatFlowMessageWithPageIndexInterface
} from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { Observable } from 'rxjs';

export interface ClerkState extends State {
    questions: ChatFlowMessageInterface[][];
    showChats: ChatFlowMessageWithPageIndexInterface[];
    submitData: ClerkSubmitEntity;
    copySubmitData: ClerkSubmitEntity;
    currentFileInfo: { yamlId: string, screenId: string, screenName: string };
}

export const ClerkSignal = {
    GET_QUESTION: 'ClerkSignal_GET_QUESTION',
    SEND_ANSWER: 'ClerkSignal_SEND_ANSWER',
    CHAT_FLOW_COMPLETE: 'ClerkSignal_CHAT_FLOWCOMPLETE',
    ACCOUNT_STATUS_INFO_INQUIRY: 'ClerkSignal_ACCOUNT_STATUS_INFO_INQUIRY',
    INCIDENTAL_INFO_INQUIRY: 'ClerkSignal_INCIDENTAL_INFO_INQUIRY',
    DORMANT_DEPOSIT_INFO_INQIRY: 'ClerkSignal_DORMANT_DEPOSIT_INFO_INQIRY',
    INACTIVE_ACCOUNT_INFO_INQUIRY: 'ClerkSignal_INACTIVE_ACCOUNT_INFO_INQUIRY',
    GET_CUSTOMER_INFO: 'TerminateSignal_GET_CUSTOMER_INFO',
    GET_CUSTOMER_INFO_NG: 'TerminateSignal_GET_CUSTOMER_INFO_NG',
    RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK: 'ClerkSignal_RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK',
    UNACCEPTABLES_NG: 'ClerkSignal_UNACCEPTABLES_NG',
};

@Injectable()
export class ClerkStore extends Store<ClerkState> {
    private keysArr: string[] = [];

    constructor(
        private ngZone: NgZone,
        private editService: EditService,
        private terminateUtil: TerminateUtil) {
        super();
        this.initState();
    }

    private initState() {
        this.state = {
            questions: [],
            showChats: [],
            submitData: new ClerkSubmitEntity(),
            copySubmitData: null,
            currentFileInfo: { yamlId: null, screenId: null, screenName: null },
        };
    }

    /**
     * チャットテンプレートをロードする
     * @param params YAMLファイルに関する情報
     */
    @ActionBind(ClerkActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.saveCurrentYamlInfo(params.fileInfo[0]);
            this.state.submitData.fileInfo = params.fileInfo;

            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(ClerkSignal.GET_QUESTION, params.pageIndex);
        }
    }

    /**
     * 回答を設定する
     * @param params 回答
     */
    @ActionBind(ClerkActionType.SET_ANSWER)
    private setAnswer(answer: { order: number, text: string, value: Array<{ key: string, value: string }> }) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        answer.order = this.keysArr.length;
        chat.answer = answer;
        if (answer.value) {
            answer.value.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    /**
     * 次のステップを取得する
     * @param params 当ステップ情報
     */
    @ActionBind(ClerkActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: { order: number, pageIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .min<ChatFlowMessageInterface>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: this.replaceChatMessage(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order,
                        };
                        this.state.showChats.push(qus);
                        this.sendSignal(ClerkSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: this.replaceChatMessage(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order,
                        };
                        this.state.showChats.push(qus);
                        this.sendSignal(ClerkSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => {
                // DO NOTHING
            });
        });
    }

    /**
     * チャットを完了し次のチャットに遷移する
     * @param nextChatName 次のチャット名
     */
    @ActionBind(ClerkActionType.CHAT_FLOW_COMPLETE)
    private chatFlowComplete(nextChatName: string) {
        this.sendSignal(ClerkSignal.CHAT_FLOW_COMPLETE, nextChatName);
    }

    /**
     * 回答を編集する
     * @param params チャット情報
     */
    @ActionBind(ClerkActionType.EDIT_ANSWER)
    private editAnswer(params: { order: number, pageIndex: number, answerOrder: number, showChatIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;

        let i = -1;
        let index = -1;
        if (params.showChatIndex) {
            index = params.showChatIndex;
        } else {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order) {
                    index = i;
                }
            });
        }

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }
        this.cleanSubmitData(answerOrder);
    }

    /**
     * 最後のノードをチェックする
     * @param params パラメーター
     */
    @ActionBind(ClerkActionType.RESET_LAST_NODE)
    private resetLastNode() {
        const lastNode = this.getState().showChats.pop();
        this.getNextChatByAnswer({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    /**
     * チャットの表示内容をクリアする
     */
    @ActionBind(ClerkActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    /**
     * submitDataをバックアップする
     */
    @ActionBind(ClerkActionType.SUBMIT_DATA_BACKUP)
    private submitDataBackup() {
        this.state.copySubmitData = Object.assign(new ClerkSubmitEntity(), this.state.submitData);
    }

    /**
     * stateをクリアする
     */
    @ActionBind(ClerkActionType.CLEAR_STATE)
    private clearState() {
        this.keysArr = [];
        this.initState();
    }

    /**
     * submitDataに値を設定する
     * @param data 項目値
     */
    @ActionBind(ClerkActionType.SET_STATE_SUBMIT_DATA_VALUE)
    private setStateSubmitDataValue(data: { name: string, value: any }) {
        if (data) {
            this.setSubmitData(data.name, data.value);
        }
    }

    /**
     * YAMLファイルに関する情報を保存する
     * @param params YAMLファイルに関する情報
     */
    private saveCurrentYamlInfo(params: any) {
        this.state.currentFileInfo.yamlId = params.id;
        this.state.currentFileInfo.screenId = params.screenId;
        this.state.currentFileInfo.screenName = params.screenName;
    }

    /**
     * チャット文言を置換する
     * @param message チャット文言
     */
    private replaceChatMessage(message: string) {
        const reg = /\$\([^)]+\)/g;
        const array = message.match(reg);
        if (array === null) {
            return message;
        }

        const displayTransferInfo =
            this.state.submitData.inactiveAccountInfo
            && this.state.submitData.inactiveAccountInfo.accountInfo
            && (this.state.submitData.inactiveAccountInfo.accountInfo
                .find((e) => e.branchCode === this.state.submitData.terminateAccountBranchNo
                    && (e.subjectCode === this.state.submitData.terminateAccountType
                        || e.subjectCode === ClerkConsts.AvailableAccountType.savingsOrDeposit)
                    && e.bankAccountId === this.state.submitData.terminateAccountNo
                    && Boolean(e.transferBranchCode)
                    && Boolean(e.transferBankAccountId))
                || (this.state.submitData.inactiveAccountInfo.secondaryAccountInfo || [])
                    .find((e) => e.branchCode === this.state.submitData.terminateAccountBranchNo
                        && (e.subjectCode === this.state.submitData.terminateAccountType
                            || e.subjectCode === ClerkConsts.AvailableAccountType.savingsOrDeposit)
                        && e.bankAccountId === this.state.submitData.terminateAccountNo
                        && Boolean(e.transferBranchCode)
                        && Boolean(e.transferBankAccountId)));
        const replaceValues = {
            principalWithCurrencyCode:
                this.state.submitData.accountStatusInfo.forexDormantAmount
                + this.terminateUtil.getTerminateDisplayNameForCurrencyName(this.state.submitData.accountStatusInfo.currencyCode),
            transferBranchCode: displayTransferInfo ? displayTransferInfo.transferBranchCode : undefined,
            transferBankAccountId: displayTransferInfo ? displayTransferInfo.transferBankAccountId : undefined
        };

        array.forEach((item) => {
            const prop = item.replace('$(', '').replace(')', '');
            const value = replaceValues[prop];
            message = message.replace(item, value);
        });
        return message;
    }

    /**
     * submitDataをクリーンする
     * @param remain answerOrder
     */
    private cleanSubmitData(remain: number) {
        this.keysArr = this.keysArr.slice(0, remain);
        for (const item in this.state.submitData) {
            if (item.startsWith('get')) {
                continue;
            }
            if (this.keysArr.indexOf(item) < 0) {
                this.state.submitData[item] = undefined;
            }
        }
    }

    /**
     * submitDataをセットする
     * @param key キー
     * @param value 値
     */
    private setSubmitData(key: string, value: any) {
        if (key != null) {
            this.state.submitData[key] = value;
            this.keyPush(key, value);
        }
    }

    /**
     * キーと値を配列に保存する
     * @param key キー
     * @param value 値
     */
    private keyPush(key: string, value: any) {
        if (value == null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                this.keysArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1) {
            this.keysArr.push(key);
        }
    }

    /**
     * 表示中のチャットを削除する
     * @param start 削除を開始する要素の位置
     */
    @ActionBind(ClerkActionType.SPLICE_SHOW_CHATS)
    private spliceShowChats(start: number) {
        this.state.showChats.splice(start);
    }

    /**
     * submit dataをリセットする
     */
    @ActionBind(ClerkActionType.RESET_SUBMIT_DATA)
    private resetSubmitData() {
        this.state.submitData = this.state.copySubmitData;
        this.state.copySubmitData = null;
    }

    /**
     * 内部API: 店舗マスタより店舗名取得
     * @param params
     */
    @ActionBind(ClerkActionType.GET_BRANCH_NAME)
    private getBranchName(params: { branchName: string }) {
        this.setSubmitData('terminateAccountBranchName', params.branchName);
    }

    /**
     * 内部API: 口座状態照会
     */
    @ActionBind(ClerkActionType.ACCOUNT_STATUS_INFO_INQUIRY)
    private getAccountStatusInfo(result: AccountStatusInfoInquiryResponse) {
        this.setSubmitData('accountSearchStatus', result.accountSearchStatus);
        this.setSubmitData('bussinessCode', result.bussinessCode);
        this.setSubmitData('agentErrorCode', result.agentErrorCode);
        this.setSubmitData('customerInfo', result.customerInfo);
        this.setSubmitData('accountStatusInfo', result.customerInfo ? result.customerInfo.accountStatusInfo : undefined);
        this.sendSignal(ClerkSignal.ACCOUNT_STATUS_INFO_INQUIRY);
    }

    /**
     * 内部API: 少額預金口座付帯サービス情報取得
     * @param data APIのレスポンス
     */
    @ActionBind(ClerkActionType.INCIDENTAL_INFO_INQUIRY)
    private setIncidentalInfo(response: any) {
        if (response) {
            this.setSubmitData('incidentalInfo', response.incidentalInfo);
        }
        this.sendSignal(ClerkSignal.INCIDENTAL_INFO_INQUIRY);
    }

    /**
     * 内部API: 睡眠・休眠情報照会
     */
    @ActionBind(ClerkActionType.DORMANT_DEPOSIT_INFO_INQIRY)
    private getDormantDepositInfo(result: DormantDepositInfoResponse) {
        this.setSubmitData('dormantDepositSearchStatus', result.dormantDepositSearchStatus);
        this.setSubmitData('dormantDepositInfo', result.dormantDepositInfo);
        this.sendSignal(ClerkSignal.DORMANT_DEPOSIT_INFO_INQIRY);
    }

    /**
     * 内部API: 不活動口座照会
     */
    @ActionBind(ClerkActionType.INACTIVE_ACCOUNT_INFO_INQUIRY)
    private getInactiveAccountInfo(result: InactiveAccountInfoInquiryResponse) {
        this.setSubmitData('inactiveAccountSearchStatus', result.inactiveAccountSearchStatus);
        this.setSubmitData('inactiveCustomerInfo', result.customerInfo);
        this.setSubmitData('inactiveAccountInfo', result.customerInfo ? result.customerInfo.inactiveAccountInfo : undefined);
        this.sendSignal(ClerkSignal.INACTIVE_ACCOUNT_INFO_INQUIRY);
    }

    /**
     * 内部API: CIF情報照会
     */
    @ActionBind(ClerkActionType.GET_CUSTOMER_INFO)
    private getCustomerInfo(response: any) {
        this.setSubmitData('mejarCustomerStatus', '1');
        this.setSubmitData('customerInfo', response.cifInfoInquiryResponses[0]);
        this.sendSignal(ClerkSignal.GET_CUSTOMER_INFO);
    }

    /**
     * 内部API: CIF情報照会にてエラーになった旨送信する
     */
    @ActionBind(ClerkActionType.GET_CUSTOMER_INFO_NG)
    private getCustomerInfoError(data: any) {
        this.setSubmitData('mejarCustomerStatus', '0');
        this.sendSignal(ClerkSignal.GET_CUSTOMER_INFO_NG, data);
    }

    /**
     * 内部API：業務受付可否チェックにてエラーになった旨送信する
     */
    @ActionBind(ClerkActionType.UNACCEPTABLES_NG)
    private receptionCancelAccountApplyCheckError(data: any) {
        this.sendSignal(ClerkSignal.UNACCEPTABLES_NG, data);
    }

    /**
     * 内部API：業務受付可否チェック
     */
    @ActionBind(ClerkActionType.RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK)
    private receptionCancelAccountApplyCheck(data: any) {
        this.sendSignal(ClerkSignal.RECEPTION_CANCEL_ACCOUNT_APPLY_CHECK);
    }

}
