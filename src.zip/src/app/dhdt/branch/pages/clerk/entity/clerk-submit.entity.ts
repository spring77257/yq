import { AccountStatusInfo, CustomerInfo } from 'dhdt/branch/pages/terminate/entity/account-status-info-inquiry-response.entity';
import { DormantDepositInfo } from 'dhdt/branch/pages/terminate/entity/dornant-deposit-info-response.entity';
import {
    InactiveAccountInfo, InactiveCustomerInfo
} from 'dhdt/branch/pages/terminate/entity/inactive-account-info-inquiry-response.entity';
import { IncidentalInfo } from 'dhdt/branch/pages/terminate/entity/incidental-info-response.entity';

export class ClerkSubmitEntity {

    public fileInfo: string;

    // 内部API: 口座状態照会
    /** 口座検索結果 */
    public accountSearchStatus: string;
    /** 業務コード(Agent) */
    public bussinessCode: string;
    /** 内部エラーコード(Agent) */
    public agentErrorCode: string;
    /** CIF情報 */
    public customerInfo: CustomerInfo;
    /** 口座情報 */
    public accountStatusInfo: AccountStatusInfo;

    // 内部API: 少額預金口座付帯サービス情報取得
    public incidentalInfo: IncidentalInfo;

    // 内部API: 睡眠・休眠情報照会
    /** 索引情報検索結果 */
    public dormantDepositSearchStatus: string;
    /** 睡眠・休眠預金情報 */
    public dormantDepositInfo: DormantDepositInfo;

    // 内部API: 不活動口座照会
    /** 口座検索結果 */
    public inactiveAccountSearchStatus: string;
    /** CRM整理済顧客情報 */
    public inactiveCustomerInfo: InactiveCustomerInfo;
    /** CRM整理済口座情報 */
    public inactiveAccountInfo: InactiveAccountInfo;

    // 内部API: CIF情報照会
    /** 勘定系顧客保有有無 */
    public mejarCustomerStatus: string;

    // オープニング
    /** 解約口座の店番号 */
    public terminateAccountBranchNo: string;
    /** 解約口座の店名 */
    public terminateAccountBranchName: string;
    /** 解約口座の科目コード */
    public terminateAccountType: string;
    /** 解約口座の口座番号 */
    public terminateAccountNo: string;
    /** 外貨預金があるか */
    public confirmCertificateFixedDeposit: string;
    /** 選択した通貨コード */
    public selectCurrencyCode: string;

    // 受付可否
    /** 合計残高 */
    public totalBalance: number;
    /** 口座状態照会APIで取得した口座情報リスト */
    public accountStatusInfoList: Array<{ branchCode: string, subjectCode: string, bankAccountId: string }>;
    /** 不活動口座照会APIで取得した口座情報リスト */
    public inactiveAccountInfoList: Array<{ branchCode: string, subjectCode: string, bankAccountId: string }>;

    constructor() {
        this.fileInfo = undefined;

        // 内部API: 口座状態照会
        this.accountSearchStatus = undefined;
        this.bussinessCode = undefined;
        this.agentErrorCode = undefined;
        this.customerInfo = undefined;
        this.accountStatusInfo = undefined;

        // 内部API: 少額預金口座付帯サービス情報取得
        this.incidentalInfo = undefined;

        // 内部API: 睡眠・休眠情報照会
        this.dormantDepositInfo = undefined;
        this.dormantDepositSearchStatus = undefined;

        // 内部API: 不活動口座照会
        this.inactiveAccountSearchStatus = undefined;
        this.inactiveCustomerInfo = undefined;
        this.inactiveAccountInfo = undefined;

        // 内部API: CIF情報照会（勘定系顧客保有有無）
        this.mejarCustomerStatus = undefined;

        // オープニング
        this.confirmCertificateFixedDeposit = undefined;
        this.terminateAccountBranchNo = undefined;
        this.terminateAccountBranchName = undefined;
        this.terminateAccountType = undefined;
        this.terminateAccountNo = undefined;
        this.selectCurrencyCode = undefined;

        // 受付可否
        this.totalBalance = undefined;
        this.accountStatusInfoList = undefined;
        this.inactiveAccountInfoList = undefined;

        // 未定義のプロパティが追加されるのを抑制する。
        // （開発者は、submitDataに格納される全てのキーを、TerminateSubmitEntityのメンバとして定義すること）
        Object.preventExtensions(this);
    }
}
