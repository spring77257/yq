import { AfterViewChecked, Component, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { IdentificationDocCode } from 'dhdt/branch/pages/change/change-consts';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ExistingAccountChangeAction } from 'dhdt/branch/pages/existing-account-change/action/existing-account-change.action';
import {
    EXISTING_ACCOUNT_CHANGE_RENDERER
} from 'dhdt/branch/pages/existing-account-change/chat-flow/render/existing-account-change.renderer';
import {
    ExistingAccountChangeState, ExistingAccountChangeStateSignal, ExistingAccountChangeStore
} from 'dhdt/branch/pages/existing-account-change/store/existing-account-change.store';
import { AbstractChatFlowControlComponent,
    EditModalButtonValue } from 'dhdt/branch/shared/modules/chat-flow/components/abstract-chat-flow-control.component';
import {
    ChatFlowHeaderInterfaces, ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { EditModalDismissEventValue } from 'dhdt/branch/shared/modules/chat-flow/interfaces/edit-modal-dismiss-event-value.interface';
import { Content } from 'ionic-angular';

/**
 * 住所変更 既存CIF名寄せ機能のチャット
 *
 * @export
 * @class ExistingAccountActionTypeChatComponent
 * @extends {AbstractChatFlowControlComponent}
 * @implements {OnInit}
 * @implements {OnDestroy}
 */
@Component({
    selector: 'existing-account-chat-change',
    templateUrl: './existing-account-chat.component.html'
})
export class ExistingAccountChatChangeComponent extends AbstractChatFlowControlComponent implements OnInit, OnDestroy, AfterViewChecked {
    @ViewChild(Content) public content: Content;
    public state: ExistingAccountChangeState;
    public headerOptions: ChatFlowHeaderInterfaces.Options;
    private currentEditShowchatIndex = -1;

    constructor(
        private store: ExistingAccountChangeStore,
        private action: ExistingAccountChangeAction,
        injector: Injector
    ) {
        super(action, injector);

        this.state = this.store.getState();
    }

    /**
     * 初期化処理として以下を行う。
     * * `AbstractChatFlowControlComponent`の初期化メソッド(`initChatFlowControl`)を実行する。
     * * `ChatFlowHeaderComponent`用のオプションをセットアップする。
     * * Storeからのシグナルを登録する。
     *
     * @memberof ExistingAccountActionTypeChatComponent
     */
    public ngOnInit() {
        this.initChatFlowControl();
        this.setupHeaderOptions();

        this.action.onPresent(this.chatFlowNavParam);

        this.store.registerSignalHandler(ExistingAccountChangeStateSignal.CHAT_FLOW_COMPELETE, (nextComponentType) => {
            // this.onChatFlowComplete(nextComponentType, TopComponent);
            const data = {
                selectedDatas: this.state.lastestSelectedItems,
                nameIdentiImage: this.state.nameIdentiImage,
                propertiesConfrimImage: this.state.propertiesConfrimImage,
                photoOrder: this.state.photoOrder,
                nayoseBcHoldingStatus: this.state.nayoseBcHoldingStatus,
                nayoseBcSuicaHoldingStatus: this.state.nayoseBcSuicaHoldingStatus,
                nayoseCdHoldingStatus: this.state.nayoseCdHoldingStatus,
                idDocAName: this.state.submitData.identificationDocument3AName ?
                    this.state.submitData.identificationDocument3AName : '',
                idDocBName: this.state.submitData.identificationDocument3BName ?
                    this.state.submitData.identificationDocument3BName : '',
                idDocCName: this.getIdDocNameC(),
            };
            this.viewCtrl.dismiss(data);
        });
        this.store.registerSignalHandler(ExistingAccountChangeStateSignal.GET_QUESTION, (pageIndex: number) => {
            this.onYamlDidLoad(pageIndex);
        });
        this.store.registerSignalHandler(ExistingAccountChangeStateSignal.SEND_ANSWER, (data) => {
            this.onNextMessage(data);
        });
    }

    /**
     * クリーンアップ処理として以下を行う。
     * * `AbstractChatFlowControlComponent`のクリーンアップメソッド(`destoyChatFlowControl`)を実行する。
     * * Storeシグナルの登録を解除する。
     *
     * @memberof ExistingAccountActionTypeChatComponent
     */
    public ngOnDestroy() {
        this.destoyChatFlowControl();
        this.store.unregisterSignalHandler(ExistingAccountChangeStateSignal.CHAT_FLOW_COMPELETE);
        this.store.unregisterSignalHandler(ExistingAccountChangeStateSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(ExistingAccountChangeStateSignal.SEND_ANSWER);
    }

    /**
     * ViewCheck後（Viewが変更された後）にメッセージコンテナを最下部へスクロールする。
     *
     * @memberof ExistingAccountActionTypeChatComponent
     */
    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    /**
     * この値によって、ヘッダ下部のStepperがどこまで進んでいるかを判断する。
     */
    public get processType() {
        return -1;
    }

    /**
     * Cancel emitter handler
     */
    public cancelEmitterHandler() {
        super.cancelEmitterHandler();
    }

    /**
     * タイトルを取得する。
     *
     * @memberof ExistingAccountActionTypeChatComponent
     */
    public get headerTitle(): string {
        return this.labels.ExistingAccount.title;
    }

    /**
     * Navigationを取得する。
     *
     * @memberof ExistingAccountActionTypeChatComponent
     */
    public get processItems() {
        return [
            {
                type: COMMON_CONSTANTS.ProcessType.RequiredInput,
                value: this.labels.processType.requiredInput,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyInfoConfirm,
                value: this.labels.processType.applyInfoConfirm,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.BankClerkConfirm,
                value: this.labels.processType.bankClerkConfirm,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
                value: this.labels.processType.completion,
            },
        ];
    }

    /**
     * Editボタンが押下された際に`openEditModal`イベントを発火し、EditModalを表示する。
     *
     * @param order
     * @param pageIndex
     * @param answerOrder
     * @param showChatIndex
     */
    public editChat(order: number, pageIndex: number, answerOrder: number, orderIndex: number): void {
        this.currentEditShowchatIndex = orderIndex;
        super.onEdit(order, pageIndex, answerOrder);
    }

    /**
     * ユーザが回答を編集するかどうかを決定した際に呼び出されるハンドラ。
     *
     * @param {EditModalDismissEventValue} event
     */
    public onEditModalDismiss(event: EditModalDismissEventValue): void {
        const preventedItem = this.editService.endEdit();
        if (event.buttonValue === EditModalButtonValue.EDIT) {
            this.currentRenderer.resetEvents();
            this.action.editAnswer(event.order, event.pageIndex, event.answerOrder, this.currentEditShowchatIndex);
            this.chatFlowInputField.clear();
            this.currentRendererIndex = event.pageIndex;
            this.currentRenderer = this.setupRenderer(event.pageIndex);
            this.getNextChatMessage(event.order, event.pageIndex);
            const deleteCount = this.rendererList.length - this.currentRendererIndex - 1;
            this.rendererList.splice(this.currentRendererIndex + 1, deleteCount);
        } else {
            if (preventedItem) {
                this.getNextChatMessage(preventedItem.order, preventedItem.pageIndex);
            } else {
                this.onModalDismiss();
            }
        }
    }
    /**
     * ページのindexに対して、コンポーネントの名前を取得する
     *
     * @param {number} index
     */
    protected getRendererNameByIndex(index: number) {
        const componentNameMap = {
            0: EXISTING_ACCOUNT_CHANGE_RENDERER,
        };

        let componentName = componentNameMap[index];
        if (!componentName) {
            componentName = EXISTING_ACCOUNT_CHANGE_RENDERER;
        }

        return componentName;
    }

    /**
     * 店舗マスタを更新する
     */
    // tslint:disable-next-line:no-empty
    protected branchStatusUpdate(): void {
    }

    private setupHeaderOptions() {
        this.headerOptions = {
            showReturnTopButton: false,
            title: '名寄せ',
            leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
        };
    }

    /**
     * パターンCにて撮影した書類名(その他書類の場合は入力された書類名)
     * @returns パターンCの書類名
     */
    private getIdDocNameC() {
        const idDocC = this.state.submitData.identificationDocument3C;

        if (idDocC && (idDocC === IdentificationDocCode.OTHER_OFFICAL)) {
            return this.state.submitData.documentListNameC;
        } else {
            return this.state.submitData.identificationDocument3CName ?
                this.state.submitData.identificationDocument3CName : '';
        }
    }
}
