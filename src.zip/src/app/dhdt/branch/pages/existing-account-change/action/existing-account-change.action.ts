import { Injectable, NgZone } from '@angular/core';
import { Action } from 'adep/flux';
import { API_URL } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ChatFlowActionInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-action.interface';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { HttpService, HttpStatus } from 'dhdt/branch/shared/services/http.service';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';

export namespace ExistingAccountChangeActionType {
    export const GET_SAVING_QUESTION_TEMPLATE = 'ExistingAccountChangeActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const TRADING_CONDITION = 'ExistingAccountChangeActionType_TRADING_CONDITION';
    export const NEXT_CHAT = 'ExistingAccountChangeActionType_NEXT_CHAT';
    export const EDIT_CHAT = 'ExistingAccountChangeActionType_EDIT_CHAT';
    export const SET_ANSWER = 'ExistingAccountChangeActionType_SET_ANSWER';
    export const CHAT_FLOW_COMPELETE = 'ExistingAccountChangeActionType_CHAT_FLOW_COMPELETE';
    export const RESET_LAST_NODE = 'ExistingAccountChangeActionType_RESET_LAST_NODE';
    export const RESET_TO_ORDER = 'ExistingAccountChangeActionType_RESET_TO_ORDER';
    export const CLEAR_SHOW_CHATS = 'ExistingAccountChangeActionType_CLEAR_SHOW_CHATS';
    export const SUBMIT_DATA_BACKUP = 'ExistingAccountChangeActionType_SUBMIT_DATA_BACKUP';

    export const PRESENT = 'ExistingAccountChangeActionType_SET_SOURCE_DATA';
    export const SELECT_ACCOUNT = 'ExistingAccountChangeActionType_SELECT_ACCOUNT';
    export const ACCEPTE_CHECK = 'ExistingAccountChangeActionType_ACCEPTE_CHECK';
    export const SET_DOCUMENT_IMAGES = 'ExistingAccountChangeActionType_SET_DOCUMENT_IMAGES';
    export const SET_LAST_SELECT_ITEM = 'ExistingAccountChangeActionType_SET_LAST_SELECT_ITEM';

    export const SET_APPLYID_RECEPTIONTENBAN = 'ExistingAccountChangeActionType_SET_APPLYID_RECEPTIONTENBAN';

    export const SET_ACCEPT_CHECK_FLAG = 'ExistingAccountChangeActionType_SET_ACCEPT_CHECK_FLAG';
    export const CLEAN_CHAT = 'ExistingAccountChangeActionType_CLEAN_CHAT';
    export const SAVE_DOCUMENT_NAME = 'ExistingAccountChangeActionType_SAVE_DOCUMENT_NAME';
}

@Injectable()
export class ExistingAccountChangeAction extends Action implements ChatFlowActionInterface {

    constructor(private httpService: HttpService, private ngZone: NgZone) {
        super();
    }

    /**
     * 取引ぶりをtempPayloadに保存
     */
    public onTradingCondition() {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.TRADING_CONDITION,
        });
    }

    /**
     * チャットテンプレートをロードする
     * @param file yamlファイル名
     * @param pageIndex ページインデックス
     */
    public loadTemplate(file: string, pageIndex: number) {
        this.httpService.get(API_URL.CHATFLOW_DEFINITION + file, null, null, SpinnerType.NO_SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ExistingAccountChangeActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos
                }
            });
        });
    }

    /**
     * 次のステップを取得する
     * @param order オーダー
     * @param pageIndex ページインデックス
     */
    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    /**
     * 回答を編集する。
     *
     * @param {number} order
     * @param {number} pageIndex
     * @memberof ChatFlowActionInterface
     */
    public editAnswer(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.EDIT_CHAT,
            data: {
                order: order, pageIndex: pageIndex, answerOrder: answerOrder, orderIndex: orderIndex
            }
        });
    }

    /**
     * ユーザからの回答をStateに保存する。
     *
     * @param {{ text: string, value: Array<{ key: string, value: string }> }} answer
     * @memberof ChatFlowActionInterface
     */
    public setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }, skipArr?: boolean) {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.SET_ANSWER,
            data: { answer: answer, skipArr: skipArr }
        });
    }

    /**
     * ChatFlowを完了させる。
     *
     * @param {string} nextChatName
     * @memberof ChatFlowActionInterface
     */
    public chatFlowCompelete(nextChatName: string) {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.CHAT_FLOW_COMPELETE,
            data: nextChatName
        });
    }

    /**
     * 指定した順番をレセット。
     *
     * @param {number} order
     * @param {number} pageIndex
     */
    public resetToNode(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.RESET_TO_ORDER,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    /**
     * 現在のChatFlowの最後のMessageを初期化する。
     *
     * @memberof ChatFlowActionInterface
     */
    public resetLastNode() {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.RESET_LAST_NODE
        });
    }

    /**
     * チャットの表示内容をクリアする
     */
    public clearShowChats() {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.CLEAR_SHOW_CHATS
        });
    }

    /**
     * 回答中のChatFlowのデータのバックアップを行う。
     *
     * @memberof ChatFlowActionInterface
     */
    public submitDataBackup(): void {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.SUBMIT_DATA_BACKUP
        });
    }

    public onPresent(data) {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.PRESENT,
            data: data
        });
    }

    public onSelect(account) {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.SELECT_ACCOUNT,
            data: account
        });
    }

    /**
     * 受付（住変）API
     *
     * @param {*} params
     * @memberof ExistingAccountChangeAction
     */
    public acceptCheck(params: any) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, params, undefined, undefined, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.ADDRESS_CHANGE_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: ExistingAccountChangeActionType.ACCEPTE_CHECK,
                        data: response instanceof HttpStatusError ? response.errors.data : response.result
                    });
                }
            }
        );
    }

    /**
     * カメラで撮影した書類をSTATEに保存
     *
     * @param {string} image
     * @memberof ExistingAccountChangeAction
     */
    public setDocumentImage(param) {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.SET_DOCUMENT_IMAGES,
            data: param
        });
    }

    /**
     * 撮影した書類名を保存
     * @param param
     */
    public saveDocumentName(param) {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.SAVE_DOCUMENT_NAME,
            data: param
        });
    }

    public setLastSelectItems(value: any[]) {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.SET_LAST_SELECT_ITEM,
            data: value
        });
    }

    /**
     * 選択された名寄せ候補に受付対象外があるかないか
     *
     * @param {boolean} value
     * @memberof ExistingAccountChangeAction
     */
    public setAcceptCheckFlag(value: boolean): void {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.SET_ACCEPT_CHECK_FLAG,
            data: value
        });
    }

    /**
     * チャットをクリアする
     *
     * @memberof ExistingAccountChangeAction
     */
    public cleanChat() {
        this.dispatcher.dispatch({
            actionType: ExistingAccountChangeActionType.CLEAN_CHAT,
            data: null
        });
    }
}
