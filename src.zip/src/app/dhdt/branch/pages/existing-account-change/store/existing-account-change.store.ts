import { Injectable, NgZone } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { AppProperties } from 'app.properties';
import { Constants } from 'dhdt/branch/pages/change/change-consts';
import {
    DuplicateAccountAndAcceptResultAccount, DuplicateAccountTenpoInfo
} from 'dhdt/branch/pages/change/entity/duplicate-accountInfo-response.entity';
import { ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { AcceptCheckKeyType, CardHoldingStatus } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { ExistingAccountChangeActionType } from 'dhdt/branch/pages/existing-account-change/action/existing-account-change.action';
import {
    AcceptionResult, AcceptionResultAccount, AcceptionResultTradingCondition
} from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { RENDER_TYPE } from 'dhdt/branch/shared/components/change-flow/enum/change-flow.enum';
import { ChangeFlowState } from 'dhdt/branch/shared/components/change-flow/interface/change-flow.interface';
import { ChangeFlowStore } from 'dhdt/branch/shared/components/change-flow/store/change-flow.store';
import {
    ChatFlowMessageInterface, ChatFlowMessageWithPageIndexInterface
} from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';
import { Observable } from 'rxjs';

export interface ExistingAccountChangeState extends State {
    questions: ChatFlowMessageInterface[][];
    showChats: ChatFlowMessageWithOrderIndexInterface[];
    showConfirm: ChatFlowMessageWithOrderIndexInterface[];
    submitData: any;
    currentFileInfo: any;
    accounts: any[];
    originInfos?: any;
    photoOrder: string[];
    documentImages: any; // 撮影したドキュメント書類
    // 受付可否チェックAPIの結果
    acceptCheckResult: Array<{ keyType: string, key: string, value: AcceptionResultAccount }>;
    // 本人取引ぶり
    currentTradingConditions: AcceptionResultTradingCondition[];
    // 名寄せ選択口座の取引ぶり
    selectedTradingConditions: AcceptionResultTradingCondition[];
    // 申請ID
    tabletApplyId: number;
    // 受付番号
    receptionTenban: string;
    // 最後選んだレコード
    lastestSelectedItems: DuplicateAccountAndAcceptResultAccount[]; // 選択された口座情報
    nameIdentiImage: any; // 名寄せ確認写真とコード値の連想配列（パターンXABC）
    propertiesConfrimImage: any; // 名寄せ属性情報確認写真
    nayoseBcHoldingStatus: string;
    nayoseBcSuicaHoldingStatus: string;
    nayoseCdHoldingStatus: string;
    acceptCheckFlag: boolean;
    identificationDocument3XDisplayedName: string; // 本人確認チャットでの書類パターンX表示名称
    identificationDocument3XListName: string; // 本人確認チャットでの書類パターンXその他書類入力表示名称
}

export interface ChatFlowMessageWithOrderIndexInterface extends ChatFlowMessageWithPageIndexInterface {
    orderIndex?: number;
}

export const ExistingAccountChangeStateSignal = {
    GET_QUESTION: 'ExistingAccountChangeStateSignal_GET_QUESTION',
    SEND_ANSWER: 'ExistingAccountChangeStateSignal_SEND_ANSWER',
    CHAT_FLOW_COMPELETE: 'ExistingAccountChangeStateSignal_CHAT_FLOW_COMPELETE',
    ACCEPT_TARGET: 'ExistingAccountChangeStateSignal_ACCEPT_TARGET',
};

@Injectable()
export class ExistingAccountChangeStore extends Store<ExistingAccountChangeState> {
    private keysArr: any[] = [];
    private changeFlowState: ChangeFlowState;
    private tempPayload: string[];
    private nameIdentiArr: any[] = [];
    private photoOrderArr: any[] = [];
    private propertiesConfrimArr: any[] = [];

    constructor(
        private editService: EditService,
        private ngZone: NgZone,
        private changeFlowStore: ChangeFlowStore,
        private changeUtils: ChangeUtils) {
        super();
        this.initState();
        this.changeFlowState = this.changeFlowStore.getState();
        this.state.originInfos = this.changeFlowState.originInfos;
    }

    private initState() {
        this.state = {
            questions: [],
            showChats: [],
            submitData: {},
            currentFileInfo: {},
            showConfirm: [],
            accounts: null,
            acceptCheckResult: [],
            currentTradingConditions: [],
            selectedTradingConditions: [],
            tabletApplyId: -1,
            receptionTenban: '',
            lastestSelectedItems: [],
            nameIdentiImage: {},
            propertiesConfrimImage: '',
            originInfos: [],
            photoOrder: [],
            documentImages: [],
            nayoseBcHoldingStatus: '',
            nayoseBcSuicaHoldingStatus: '',
            nayoseCdHoldingStatus: '',
            acceptCheckFlag: false,
            identificationDocument3XDisplayedName: '',
            identificationDocument3XListName: ''
        };
    }

    /**
     * 取引ぶりをtempPayloadに保存
     */
    @ActionBind(ExistingAccountChangeActionType.TRADING_CONDITION)
    private tradingCondition() {
        const tempPayload: string[] = [];
        this.state.submitData.transactionCheckNo.forEach(
            (element: DuplicateAccountAndAcceptResultAccount) => {
                element.acceptResult.tradingConditions.forEach(
                    (tradingConditon: AcceptionResultTradingCondition) => {
                        if ((tradingConditon.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.houseLoan &&
                            tradingConditon.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.bondCustomers &&
                            tradingConditon.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.goldBullion &&
                            tradingConditon.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.safeDepositBox) &&
                            tempPayload.indexOf(tradingConditon.tradingConditionName) === -1) {
                                tempPayload.push(tradingConditon.tradingConditionName);
                            }
                        }
                );
            }
        );
        this.tempPayload = tempPayload;
    }
    /**
     * yamlファイル読込API呼び出し。
     * @param params yamlファイル読込用
     */
    @ActionBind(ExistingAccountChangeActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(ExistingAccountChangeStateSignal.GET_QUESTION, params.pageIndex);
        }
    }

    /**
     * 次チャットを呼び出し。
     * @param order yamlのorder
     * @param pageIndex ページ番号
     */
    @ActionBind(ExistingAccountChangeActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: { order: number, pageIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .min<ChatFlowMessageInterface>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus: ChatFlowMessageWithOrderIndexInterface = {
                            ...item,
                            question: this.replaceChatMessage(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order
                        };
                        this.state.showChats.push(qus);
                        this.sendSignal(ExistingAccountChangeStateSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        const qus: ChatFlowMessageWithOrderIndexInterface = {
                            ...item,
                            question: this.replaceChatMessage(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        if (!item.options) {
                            item.options = {};
                        }
                        if (item.type === RENDER_TYPE.ITEM_LIST) {
                            this.tradingCondition();
                            qus.payload = [...this.tempPayload];
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order
                        };
                        const repeatOrderArr = this.state.showChats.filter((filterItem) => filterItem.order === params.order);
                        // orderは繰り返しの場合、orderIndexを追加する。
                        (repeatOrderArr && repeatOrderArr.length > 0) ? qus.orderIndex = repeatOrderArr.length : qus.orderIndex = 0;
                        this.state.showChats.push(qus);
                        this.sendSignal(ExistingAccountChangeStateSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => {
                // DO NOTHING
            });
        });
    }

    /**
     * チャット文字を置換。
     * @param message チャット文字
     */
    private replaceChatMessage(message: string) {
        if (message.indexOf('@') === -1) {
            return message;
        }

        const replaceValues = this.state.accounts[0] ? [{
            key: '@nameKanji',
            value: StringUtils.convertHankaku2Zankaku(
                this.state.accounts[0].nameKana || this.state.accounts[0].holderNameFurikana
            )
        }, {
            key: '@birthdate',
            value: this.birthdate
        }, {
            key: '@identificationDocument3X',
            // 書類パターンXは本人確認書類聴取チャット時の名称にて置き換える
            value: this.state.identificationDocument3XDisplayedName
        }, {
            key: '@inputOtherDocument3X',
            // 書類パターンXのその他書類名は本人確認チャット入力時の名称にて置き換える
            value: this.state.identificationDocument3XListName
        }, {
            key: '@identificationDocument3A',
            value: this.changeUtils.getIdentificationDocument3(this.state.submitData.identificationDocument3A)
        }, {
            key: '@identificationDocument3B',
            value: this.changeUtils.getIdentificationDocument3(this.state.submitData.identificationDocument3B)
        }, {
            key: '@identificationDocument3C',
            value: this.changeUtils.getIdentificationDocument3(this.state.submitData.identificationDocument3C)
        }, {
            key: '@branchName',
            value: this.state.accounts[0].branchName
        }] : [];

        let result = message;

        const documentNameKeyArr = ['@identificationDocument3B', '@identificationDocument3C'];

        replaceValues.forEach((element) => {
            if (result.indexOf(element.key) !== -1) {
                let identificationDocumentName;
                const propertyName = documentNameKeyArr[documentNameKeyArr.indexOf(element.key)];
                if (element.key === propertyName) {
                    // 本人確認書類B/C && 記載ありの場合、chatFlowのorder繰り返し運用する。
                    this.state.showChats.forEach((item, index) => {
                        if (propertyName.replace('@', '') === item.name) {
                            // 文言のパラメータはshowChatsからです
                            identificationDocumentName = (item.answer && item.answer.text) ? item.answer.text : null;
                        }
                    });

                    /**
                     * 「本人確認書類B/C選択 && 本人確認書類B/C名はブランク」 or
                     * if   「submitDataの本人確認書類B/C名」は「showChatsの本人確認書類B/C名」と違う の場合、表示の文言のパラメータはshowChatsからです、
                     * else 表示の文言のパラメータはsubmitDataからです
                     */
                    result = (element.value === undefined || identificationDocumentName !== element.value) ?
                                result.replace(element.key, identificationDocumentName) :
                                result.replace(element.key, element.value);
                } else {
                    result = result.replace(element.key, String(element.value));
                }
            }
        });

        return result;
    }

    /**
     * 修正ボタン押下時の処理。
     * @param params yamlのorder,ページ番号
     */
    @ActionBind(ExistingAccountChangeActionType.EDIT_CHAT)
    private editChat(params: { order: number, pageIndex: number, answerOrder: number, orderIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;
        const orderIndex = params.orderIndex;

        let i = -1;
        let index = -1;
        if (orderIndex !== null && orderIndex !== undefined) {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order && message.orderIndex === orderIndex) {
                    index = i;
                }
            });
        } else {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order) {
                    index = i;
                }
            });
        }

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }

        this.cleanSubmitData(answerOrder);
        this.resetIdentificationDocument(order, pageIndex);
    }

    /**
     * 顧客入力情報をstateにセット。
     * @param answer 顧客入力情報
     */
    @ActionBind(ExistingAccountChangeActionType.SET_ANSWER)
    private setAnswer(data: { answer: { order: number, text: string, value: Array<{ key: string, value: string }> }, skipArr: boolean}) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        data.answer.order = this.keysArr.length;
        chat.answer = data.answer;
        if (data.answer.value) {
            data.answer.value.forEach((item) => {
                this.setSubmitData(item.key, item.value, data.skipArr);
            });
        }
    }
    /**
     * 撮影した写真をstateに保存する
     */
    @ActionBind(ExistingAccountChangeActionType.SET_DOCUMENT_IMAGES)
    private setSubmit(param: any) {
        switch (param.key) {
            case 'nameIdentiImageX':
            case 'nameIdentiImageA':
            case 'nameIdentiImageB':
            case 'nameIdentiImageC':
                if (!this.state.nameIdentiImage) {
                    this.state.nameIdentiImage = {};
                }
                if (!this.state.photoOrder) {
                    this.state.photoOrder = [];
                }
                if (param.image) {
                    this.state.nameIdentiImage[param.code] = this.state.nameIdentiImage[param.code] ?
                        [...this.state.nameIdentiImage[param.code], param.image] : [param.image];
                    this.state.photoOrder.push(param.code);
                    // バックアップの最新要素を上書き(撮影時は回答チャットの表示がないため、書類種類のチャット時点としてバックアップする)
                    this.nameIdentiArr.pop();
                    this.nameIdentiArr.push(JSON.parse(JSON.stringify(this.state.nameIdentiImage)));
                    this.photoOrderArr.pop();
                    this.photoOrderArr.push(JSON.parse(JSON.stringify(this.state.photoOrder)));
                }
                break;
            case 'propertiesConfrimImage':
                this.state.propertiesConfrimImage = this.state.propertiesConfrimImage ?
                    [...this.state.propertiesConfrimImage, param.image] : [param.image];
                // バックアップの最新要素を上書き(撮影時は回答チャットの表示がないため、書類種類のチャット時点としてバックアップする)
                this.propertiesConfrimArr.pop();
                this.propertiesConfrimArr.push(JSON.parse(JSON.stringify(this.state.propertiesConfrimImage)));
                break;
        }
    }

    @ActionBind(ExistingAccountChangeActionType.SAVE_DOCUMENT_NAME)
    private saveDocumentName(param) {
        this.setSubmitData(param.key, param.value, true);
    }

    /**
     * 名寄せで選択した口座情報を保存する。
     */
    @ActionBind(ExistingAccountChangeActionType.SET_LAST_SELECT_ITEM)
    private setLastSelectItem(value: any[]) {
        this.state.lastestSelectedItems = value;
    }

    /**
     * チャット情報を初期化。
     */
    @ActionBind(ExistingAccountChangeActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    /**
     * submitDataをバックアップ。
     */
    @ActionBind(ExistingAccountChangeActionType.SUBMIT_DATA_BACKUP)
    private submitDataBackup() {
        // this.state.copySubmitData = Object.assign(new AutomaticTransferSubmitEntity(), this.state.submitData);
    }

    /**
     * チャットが完了
     * @param nextChatName 次のチャットの名
     */
    @ActionBind(ExistingAccountChangeActionType.CHAT_FLOW_COMPELETE)
    private chatFlowCompelete(nextChatName: string) {
        this.sendSignal(ExistingAccountChangeStateSignal.CHAT_FLOW_COMPELETE, nextChatName);
    }

    /**
     * 最後のノードをチェックする
     * @param params パラメーター
     */
    @ActionBind(ExistingAccountChangeActionType.RESET_LAST_NODE)
    private resetLastNode(params: { order: number, pageIndex: number }) {
        const lastNode = this.getState().showChats.pop();
        this.getNextChatByAnswer({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    /**
     * 指定した順番をレセット
     * @param params パラメーター
     */
    @ActionBind(ExistingAccountChangeActionType.RESET_TO_ORDER)
    private resetToOrder(params: { order: number, pageIndex: number }) {
        this.getState().showChats.pop();
        this.getNextChatByAnswer(params);
    }

    @ActionBind(ExistingAccountChangeActionType.PRESENT)
    private onPresent(data) {
        this.initState();
        this.nameIdentiArr = [];
        this.photoOrderArr = [];
        this.propertiesConfrimArr = [];
        this.keysArr = [];
        this.state.accounts = data.accounts;
        // 本人取引ぶり
        this.state.currentTradingConditions = data.currentTradingConditions;
        // 申請ID
        this.state.tabletApplyId = data.tabletApplyId;
        // 受付店舗番号
        this.state.receptionTenban = data.receptionTenban;
        // 本人確認チャットでの書類パターンX表示名称
        this.state.identificationDocument3XDisplayedName = data.identificationDocument3XDisplayedName;
        // 本人確認チャットでの書類パターンXその他書類の入力表示名称
        this.state.identificationDocument3XListName = data.identificationDocument3XListName;
    }

    @ActionBind(ExistingAccountChangeActionType.SELECT_ACCOUNT)
    private onSelect(value) {
        if (value && value !== 'reset') {
            this.state.submitData = {
                ...value,
            };
        } else {
            this.state.submitData = value;
        }
    }

    /**
     * 受付可否チェック（住変）APIの結果を処理
     *
     * @private
     * @param {AcceptionResult} res
     * @memberof ExistingAccountChangeStore
     */
    @ActionBind(ExistingAccountChangeActionType.ACCEPTE_CHECK)
    private onAcceptCheck(res: AcceptionResult) {
        // stateのacceptCheckResultをクリア
        this.state.acceptCheckResult = [];

        // Stateに登録,送信レコードと受信レコードをマッピングする
        const sendedAccount: CifInfo[] = this.state.submitData.allCifInfos;
        sendedAccount.forEach((item, index) => {
            // 受付チェックの結果acceptCheckResultに格納
            // フォーマットは key:value
            // (口座番号また顧客番号): 受付可否チェック結果
            let key: string = this.changeUtils.getFirstFullAccount(item.domesticAccountInfo);
            // 口座番号存在しないときに、顧客番号をキーに設定
            const keyType: AcceptCheckKeyType = key ? AcceptCheckKeyType.ACCOUNT : AcceptCheckKeyType.CUSTOMERID;
            key = key ? key : item.customerId;
            this.state.acceptCheckResult
                .push({ keyType: keyType, key: key, value: res.accounts[index] });
        });

        // 名寄せ先の保有カード情報を設定
        this.setNayoseBcHoldingStatus(res.accounts);
        this.setNayoseBcSuicaHoldingStatus(res.accounts);
        this.setNayoseCdHoldingStatus(res.accounts);

        // 受付チェックに選んだデータの元データと受付結果を結合する
        // this.joinDuplicateAndAcceptData();

        this.sendSignal(ExistingAccountChangeStateSignal.ACCEPT_TARGET, res);
    }

    /**
     * 選択された名寄せ候補に受付対象外があるかないか
     *
     * @param {boolean} value
     * @memberof ExistingAccountChangeState
     */
    @ActionBind(ExistingAccountChangeActionType.SET_ACCEPT_CHECK_FLAG)
    private setAcceptCheckFlag(value: boolean): void {
        this.state.acceptCheckFlag = value;
    }

    /**
     * A:初期表示の口座リストの口座
     * B:受付可否チェックAPIから戻った結果
     * AとBを結合した結果を返す。
     *
     * @private
     * @returns {DuplicateAccountAndAcceptResultAccount}
     * @memberof ExistingAccountChangeRenderer
     */
    // private joinDuplicateAndAcceptData() {
    //     this.state.submitData.existingAccount =
    //         this.state.submitData.existingAccount.map((item: DuplicateAccountAndAcceptResultAccount) => {
    //             item.acceptResult = this.state.acceptCheckResult.find(
    //                 (item2) => {
    //                     // 口座リストから１番目の口座番号を取得
    //                     const fullAccount = this.changeUtils.getFirstFullAccount(item.domesticAccountInfo);
    //                     // 口座番号が存在する場合、acceptResultからkeyTypeが口座番号,key一致するレコードを探す出し
    //                     if (fullAccount) {
    //                         return item2.keyType === AcceptCheckKeyType.ACCOUNT && item2.key === fullAccount;
    //                     } else {
    //                         // 口座番号が存在しない場合、acceptResultからkeyTypeが顧客番号,key一致するレコードを探す出し
    //                         return item2.keyType === AcceptCheckKeyType.CUSTOMERID && item2.key === item.customerId;
    //                     }
    //                 }).value;
    //             return item;
    //         });
    // }

    private get birthdate() {
        const birthdate = this.state.accounts[0].birthdate || this.state.accounts[0].holderBirthdate;
        if (birthdate) {
            return moment(birthdate).format('YYYY年M月D日');
        }
        return this.state.accounts[0].holderBirthdateOCR;
    }

    /**
     * submit dataをセットする
     *
     * @param key キー
     * @param value 値
     */
    private setSubmitData(key, value, skipArr: boolean) {
        if (key !== undefined) {
            this.state.submitData[key] = value;
            this.keyPush(key, value, skipArr);
        }
    }

    /**
     * キーと値を配列に保存する
     *
     * @param key キー
     * @param value 値
     */
    private keyPush(key: any, value: any, skipArr: boolean) {
        if (value === null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                this.keysArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1) {
            this.keysArr.push(key);
            this.backupData();
        } else {
            const index = this.keysArr.indexOf(key);
            this.keysArr[index] = moment().format('YYYYMMDDHHmmss');
            this.keysArr.push(key);
            if (skipArr === undefined || !skipArr) {
                this.backupData();
            }
        }
    }

    /**
     * 写真、撮影順序をバックアップする。
     */
    private backupData() {
        const backupNameIdentiImage = this.state.nameIdentiImage ?
            JSON.parse(JSON.stringify(this.state.nameIdentiImage)) : {};
        this.nameIdentiArr.push(backupNameIdentiImage);
        const backupPhotoOrder = this.state.photoOrder ?
            JSON.parse(JSON.stringify(this.state.photoOrder)) : [];
        this.photoOrderArr.push(backupPhotoOrder);
        const backupPropertiesConfrimImage = this.state.propertiesConfrimImage ?
            JSON.parse(JSON.stringify(this.state.propertiesConfrimImage)) : {};
        this.propertiesConfrimArr.push(backupPropertiesConfrimImage);
    }

    /**
     * submit dataにremain以降の値をクリーンする
     * @param remain
     */
    private cleanSubmitData(remain: number) {
        this.keysArr = this.keysArr.slice(0, remain);
        for (const item in this.state.submitData) {
            if (item.startsWith('get')) {
                continue;
            }

            if (this.keysArr.indexOf(item) < 0) {
                this.state.submitData[item] = undefined;
            }
        }
        this.nameIdentiArr = this.nameIdentiArr.slice(0, remain);
        this.state.nameIdentiImage = this.nameIdentiArr[remain - 1] ?
            JSON.parse(JSON.stringify(this.nameIdentiArr[remain - 1])) : {};
        this.photoOrderArr = this.photoOrderArr.slice(0, remain);
        this.state.photoOrder = this.photoOrderArr[remain - 1] ?
            JSON.parse(JSON.stringify(this.photoOrderArr[remain - 1])) : [];
        this.propertiesConfrimArr = this.propertiesConfrimArr.slice(0, remain);
        this.state.propertiesConfrimImage = this.propertiesConfrimArr[remain - 1] ?
            JSON.parse(JSON.stringify(this.propertiesConfrimArr[remain - 1])) : [];
    }

    /**
     * 名寄せ先のバンクカード情報を設定
     * @param data
     */
    private setNayoseBcHoldingStatus(data: AcceptionResultAccount[]) {
        this.state.nayoseBcHoldingStatus = '';
        for (const account of data) {
            if (account.bcHoldingStatus === CardHoldingStatus.CARD_HOLDING_STATUS_YES) {
                this.state.nayoseBcHoldingStatus = CardHoldingStatus.CARD_HOLDING_STATUS_YES;
                break;
            } else {
                this.state.nayoseBcHoldingStatus = CardHoldingStatus.CARD_HOLDING_STATUS_NO;
            }
        }

    }

    /**
     * 名寄せ先のBC Suica情報を設定
     * @param data
     */
    private setNayoseBcSuicaHoldingStatus(data: AcceptionResultAccount[]) {
        this.state.nayoseBcSuicaHoldingStatus = '';
        for (const account of data) {
            if (account.bcSuicaHoldingStatus === CardHoldingStatus.CARD_HOLDING_STATUS_YES) {
                this.state.nayoseBcSuicaHoldingStatus = CardHoldingStatus.CARD_HOLDING_STATUS_YES;
                break;
            } else {
                this.state.nayoseBcSuicaHoldingStatus = CardHoldingStatus.CARD_HOLDING_STATUS_NO;
            }
        }
    }

    /**
     * 名寄せ先のキャッシュカード情報を設定
     * @param data
     */
    private setNayoseCdHoldingStatus(data: AcceptionResultAccount[]) {
        this.state.nayoseCdHoldingStatus = '';
        for (const account of data) {
            if (account.cdHoldingStatus === CardHoldingStatus.CARD_HOLDING_STATUS_YES) {
                this.state.nayoseCdHoldingStatus = CardHoldingStatus.CARD_HOLDING_STATUS_YES;
                break;
            } else {
                this.state.nayoseCdHoldingStatus = CardHoldingStatus.CARD_HOLDING_STATUS_NO;
            }
        }
    }

    /**
     * チャットをクリアする
     * 表示中のチャットをクリア
     * 保存したデータsubmitDataをクリア
     *
     * @private
     * @memberof ExistingAccountChangeStore
     */
    @ActionBind(ExistingAccountChangeActionType.CLEAN_CHAT)
    private cleanChat() {
        this.clearShowChats();
        this.cleanSubmitData(0);
    }

    private resetIdentificationDocument(order, pageIndex) {
        const chat = this.state.questions[pageIndex].find((item) => item.order === order);
        // 本人確認書類が「住民票の写し（原本）」を選択された場合、「記載あり」→「記載なし」変更された時に、本人確認書類が「null」になることを対応
        if (chat && /@\S+にマイナンバーは記載されていますか？/.test(chat.question)) {
            const propertyNm = chat.question.slice(1, chat.question.indexOf('に'));
            const filter = this.state.showChats.filter((show) => show.name === propertyNm);
            if (filter && filter.length > 0) {
                const answer = filter[filter.length - 1].answer;
                answer.value.forEach((element) => {
                    this.setSubmitData(element.key, element.value, true);
                });
                this.setSubmitData(propertyNm + 'Text', answer.text, true);
            }
        }
    }

}
