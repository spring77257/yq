import { NgModule } from '@angular/core';
import { ExistingAccountChangeAction } from 'dhdt/branch/pages/existing-account-change/action/existing-account-change.action';
import { ExistingAccountInputChangeHandler
 } from 'dhdt/branch/pages/existing-account-change/chat-flow/handler/existing-account-input-change.handler';
import { ExistingAccountChangeRenderer } from 'dhdt/branch/pages/existing-account-change/chat-flow/render/existing-account-change.renderer';
import { ExistingAccountChangeStore } from 'dhdt/branch/pages/existing-account-change/store/existing-account-change.store';
import { ExistingAccountChatChangeComponent } from 'dhdt/branch/pages/existing-account-change/view/existing-account-chat-change.component';
import { AccountShopModule } from 'dhdt/branch/shared/components/account-shop/account-shop.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';

@NgModule({
    imports: [
        IonicModule,
        SharedModule,
        AccountShopModule
    ],
    entryComponents: [
        ExistingAccountChatChangeComponent
    ],
    declarations: [
        ExistingAccountChatChangeComponent
    ],
    providers: [
        ExistingAccountChangeAction,
        ExistingAccountChangeStore,
        ExistingAccountChangeRenderer,
        ExistingAccountInputChangeHandler
    ]
})
export class ExistingAccountChangeModule {
}
