import { Injectable } from '@angular/core';
import { BussinessCode, Constants, IdentificationDocument, TransactionLevel } from 'dhdt/branch/pages/change/change-consts';
import {
    DuplicateAccountAndAcceptResultAccount, DuplicateAccountTenpoInfo
} from 'dhdt/branch/pages/change/entity/duplicate-accountInfo-response.entity';
import { ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import {
    AcceptCheck, AcceptCheckKeyType, COMMON_CONSTANTS, CountryCode, HostResultCode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ExistingAccountChangeAction } from 'dhdt/branch/pages/existing-account-change/action/existing-account-change.action';
import {
    ExistingAccountChangeChatFlowTypes
} from 'dhdt/branch/pages/existing-account-change/chat-flow/existing.account.change.chat-flow-types';
import {
    ExistingAccountInputChangeHandler
} from 'dhdt/branch/pages/existing-account-change/chat-flow/handler/existing-account-input-change.handler';
import {
    ExistingAccountChangeState, ExistingAccountChangeStateSignal, ExistingAccountChangeStore
} from 'dhdt/branch/pages/existing-account-change/store/existing-account-change.store';
import { ButtonCameraComponent } from 'dhdt/branch/shared/components/button-group/button-camera.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { AcceptionResult, AcceptionResultTradingCondition } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import {
    ExistingAccountTableChangeComponent, SHOW_TYPE
} from 'dhdt/branch/shared/components/existing-account-table/existing-account-table-change.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';

export const EXISTING_ACCOUNT_CHANGE_RENDERER = 'ExistingAccountChangeRenderer';

/**
 * `DefaultChatFlowRenderer`において、自動振込解約画面に利用できるRendererを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferCancelRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: EXISTING_ACCOUNT_CHANGE_RENDERER,
    templateYaml: 'chat-flow-def-existing-account-confirmation-change.yml'
})
export class ExistingAccountChangeRenderer extends DefaultChatFlowRenderer {
    public processType: number = -1;
    private state: ExistingAccountChangeState;
    private changeState: ChangeState;

    constructor(
        private action: ExistingAccountChangeAction,
        private store: ExistingAccountChangeStore,
        inputHandler: ExistingAccountInputChangeHandler,
        private changeUtils: ChangeUtils,
        private loginStore: LoginStore,
        private changeStore: ChangeStore) {
        super(action, inputHandler);

        this.state = store.getState();
        this.changeState = changeStore.getState();
    }

    protected get userAnswers(): any {
        return null;
    }

    /**
     * 一覧テーブルcomponentを表示
     *
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof ExistingAccountChangeRenderer
     */
    @Renderer(ExistingAccountChangeChatFlowTypes.EXISTING_ACCOUNT)
    public onExistingAccount(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            disableFirstRow: this.isDisableFirstRow(entity.name),
            showType: this.getExistingAccountTableShowType(entity.name),
            isNameChanged: this.changeState.isNameChanged,
            isAddressChanged: this.changeState.isAddressChanged,
            holderNationalityCode: this.changeState.submitData.nationalityCode
        };

        this.emitRenderEvent({
            class: ExistingAccountTableChangeComponent,
            data: this.getExistingAccountTableItems(entity.name),
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ExistingAccountChangeChatFlowTypes.CAMERA_BUTTON)
    public onCameraButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options: any = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        const received = {...this.changeState.changeDocumentImages, ...this.state.nameIdentiImage};
        let codes: string[];
        if (received) {
            codes = Object.keys(received);
        }
        // 書類に写真が存在する場合は、skipを渡す
        if (entity.name === 'nameIdentiImageA' && entity.skip) {
            codes.forEach((element) => {
                if (this.state.submitData.identificationDocument3A === element) {
                    options.skip = entity.skip;
                }
            });
        } else if (entity.name === 'nameIdentiImageB' && entity.skip) {
            codes.forEach((element) => {
                if (this.state.submitData.identificationDocument3B === element) {
                    options.skip = entity.skip;
                }
            });
        } else if (entity.name === 'nameIdentiImageC' && entity.skip) {
            codes.forEach((element) => {
                if (this.state.submitData.identificationDocument3C === element) {
                    options.skip = entity.skip;
                }
            });
        }

        this.emitRenderEvent({
            class: ButtonCameraComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ExistingAccountChangeChatFlowTypes.TEXT)
    public onText(entity: ChatFlowMessageInterface, pageIndex: number) {
        console.log('onText next:' + entity.next);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(ExistingAccountChangeChatFlowTypes.ITEM_LIST)
    public onItemLIst(entity: any, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(ExistingAccountChangeChatFlowTypes.BUTTON)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        const received = {...this.changeState.changeDocumentImages, ...this.state.nameIdentiImage};
        let codes = [];
        if (received) {
            codes = Object.keys(received);
        }
        if (entity.type === ExistingAccountChangeChatFlowTypes.BUTTON && entity.name === 'identificationDocument3C') {
            for (const choice of entity.choices) {
                if (codes.indexOf(choice.value) !== -1) {
                    choice.options = {
                        cssClass: 'disabled-button',
                    };
                }
            }
        }

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ExistingAccountChangeChatFlowTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number) {

        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ExistingAccountChangeChatFlowTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        let judgeResult: string;

        if (entity.option === 'change') {
            switch (entity.name) {
                case 'addressChanged': {
                    // 住変未変更であれば本人確認書類の所持確認を行う
                    judgeResult = this.changeState.isAddressChanged ? '01' : '02';
                    break;
                }
                case 'nameChanged': {
                    // 氏名未変更であれば本人確認書類の所持確認を行う
                    judgeResult = this.changeState.isNameChanged ? '01' : '02';
                    break;
                }
                case 'onlyPhoneChanged': {
                    // 電話番号のみ変更の場合
                    judgeResult = this.changeState.isNameChanged === false && this.changeState.isAddressChanged === false
                        && this.changeState.isTelChanged === true ? '01' : '02';
                }
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        } else if (entity.option === 'confirm') {
            const confirmA = ['08', '10'];
            const confirmB = ['12', '14'];
            const confirmC = ['01', '02', '03', '05', '06', '07', '10', '11', '12', '13',
                                '14', '15', '20', '21', '22', '25', '27'];
            const possibleAdressIdentifications = ['01', '02', '03', '13', '15', '20', '21', '22'];
            const hasOtherOfficial = ['25'];
            const confirmAddressA = ['10'];
            const skipPaperA = ['09', '11'];
            const skipPaperB = ['13', '15'];
            let codes: string[];
            const received = {...this.changeState.changeDocumentImages, ...this.state.nameIdentiImage};

            if (received) {
                codes = Object.keys(received);
            }
            const selectedAccountTradingConditions =
                this.changeUtils.getTradingConditionsFromSelected(this.state.submitData.transactionCheckNo);
            const level = this.changeUtils.getTransactionLevel(
                selectedAccountTradingConditions, this.changeState.isNameChanged, this.changeState.isAddressChanged);
            switch (entity.name) {
                // 書類Aの撮影が必要な場合02、スキップの場合01
                case 'confirmA': {
                    judgeResult = '01';
                    if (level.levelTwo && this.changeState.isNameChanged && codes) {
                        const matchedCode = [];
                        codes.forEach((receive) => {
                            if (confirmA.indexOf(receive) >= 0) {
                                matchedCode.push(receive);
                            }
                        });
                        judgeResult = (matchedCode.length > 0 || this.changeState.isSelectedSkipButtonA) ? '01' : '02';
                    } else if (level.levelTwo && this.changeState.isNameChanged && !codes) {
                        judgeResult = '02';
                    }
                    break;
                }
                // 書類Bの撮影が必要な場合02、スキップの場合01
                case 'confirmB': {
                    judgeResult = '01';
                    if (level.levelFive && this.changeState.isAddressChanged && codes) {
                        const matchedCode = [];
                        codes.forEach((receive) => {
                            if (confirmB.indexOf(receive) >= 0) {
                                matchedCode.push(receive);
                            }
                        });
                        judgeResult = (matchedCode.length > 0 || this.changeState.isSelectedSkipButtonB) ? '01' : '02';
                    } else if (level.levelFive && this.changeState.isAddressChanged && !codes) {
                        judgeResult = '02';
                    }
                    break;
                }
                // 書類Cの撮影が必要な場合02、スキップの場合01、撮影した書類の内容によって聴取必要な場合は03
                case 'confirmC': {
                    judgeResult = '01';
                    // 本人確認書類聴取チャットにてパターンC確認済みの場合、スキップする
                    if (this.changeState.isAlreadyConfirmC) {
                        break;
                    }
                    // 本人確認書類聴取チャット含めた他のパターンにて書類撮影済みの場合、書類のチェックへ
                    if (codes) {
                        const matchedCode = [];
                        codes.forEach((receive) => {
                            if (confirmC.indexOf(receive) >= 0) {
                                matchedCode.push(receive);
                            }
                        });
                        // 書類聴取済みの場合
                        if (matchedCode.length > 0) {
                            // 住所変更なしの場合（=氏名変更のみ）、聴取済みのためスキップ
                            if (!this.changeState.isAddressChanged) {
                                judgeResult = '01';
                                break;
                            }
                            // 住所変更ありの場合
                            // 本人確認書類聴取チャットにてパターンB確認済みの場合、または名寄せ確認書類チャットでパターンB確認済みの場合、
                            // またはスキップした場合、
                            if (this.changeState.isAlreadyConfirmB || this.state.submitData.identificationDocument3B
                                || this.state.submitData.identificationDocument3B === COMMON_CONSTANTS.SKIP_TEXT) {
                                judgeResult = '01';
                                break;
                            }
                            const possibleConfirmC = matchedCode.some((code) => possibleAdressIdentifications.indexOf(code) >= 0);
                            if (possibleConfirmC) {
                                judgeResult = '03';
                                break;
                            }
                            const resultOtherOfficial = matchedCode.some((code) => hasOtherOfficial.indexOf(code) >= 0);
                            if (resultOtherOfficial) {
                                judgeResult = '04';
                                break;
                            }
                            // パターンXの書類がいずれも合致しない場合、パターンAの書類で住所確認が可能か判定する
                            judgeResult = '05';
                        } else {
                            // 書類未聴取の場合、撮影必要
                            judgeResult = '02';
                        }
                    } else {
                        // 住所変更なし、もしくは住所変更ありかつ本人確認書類聴取チャット含めた他のパターンにて書類未撮影の場合、パターンCの撮影へ
                        judgeResult = '02';
                    }
                    break;
                }
                case 'nationalityCode': {
                    if (this.changeState.submitData.nationalityCode) {
                        judgeResult = this.changeState.submitData.nationalityCode === CountryCode.Japan ? '01' : '02';
                    }
                    break;
                }
                case 'isChoicedPaperA': {
                    // 期限月書類を撮影済みかどうか(パターンA)
                    const matchedCode = [];

                    codes.forEach((receive) => {
                        if (skipPaperA.indexOf(receive) >= 0) {
                            matchedCode.push(receive);
                        }
                    });
                    judgeResult = matchedCode.length > 0 ? '01' : '02';
                    break;
                }
                case 'isChoicedPaperB': {
                    // 期限月書類を撮影済みかどうか(パターンB)
                    const matchedCode = [];

                    codes.forEach((receive) => {
                        if (skipPaperB.indexOf(receive) >= 0) {
                            matchedCode.push(receive);
                        }
                    });
                    judgeResult = matchedCode.length > 0 ? '01' : '02';
                    break;
                }
                // 書類C前の取引振り判断し、必要な場合02、スキップの場合01
                case 'confirmBeforeC': {
                    judgeResult = level.levelThree ? '02' : '01';
                    break;
                }
                // 書類A前の取引振り判断し、必要な場合01、スキップの場合02
                case 'isSkipA': {
                    judgeResult = level.levelTwo ? '01' : '02';
                    break;
                }
                // 書類B前の取引振り判断し、必要な場合01、スキップの場合02
                case 'isSkipB': {
                    judgeResult = level.levelFive ? '01' : '02';
                    break;
                }
                // 書類Cで重複聴取あり時、書類Xで住所確認できない場合、
                // 書類A聴取時は書類Aで住所確認可能か判断し、可能な場合01、不可能な場合02
                case 'addressConfirmCWithA': {
                    const matchedCode = [];

                    codes.forEach((receive) => {
                        if (confirmAddressA.indexOf(receive) >= 0) {
                            matchedCode.push(receive);
                        }
                    });
                    judgeResult = matchedCode.length > 0 ? '01' : '02';
                    break;
                }
                case 'addressConfirmJudge': {
                    judgeResult = this.changeState.isAlreadyConfirmC ? '01' : '02';
                    break;
                }
                case 'checkDocumentType3C': {
                    // パターンCにてマイナンバー撮影済みかどうか
                    judgeResult = this.state.submitData.identificationDocument3C === IdentificationDocument.MY_NUMBER_CARD ? '01' : '02';
                    break;
                }
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        }
        switch (entity.name) {
            case 'accepteCheck':
                // 受付可否チェックAPI
                this.acceptCheckApi(entity, pageIndex);
                break;
            case 'transactionCheck':
                // 取引ぶりチェック
                this.transactionCheck(entity, pageIndex, this.changeState.isNameChanged, this.changeState.isAddressChanged);
                break;
            case 'transactionCheckTwo':
                // 取引ぶりチェック
                this.transactionCheckTwo(entity, pageIndex, this.changeState.isNameChanged, this.changeState.isAddressChanged);
                break;
            case 'requireTransactionDocument':
                // 取引ぶりチェック
                const result = this.chooseDocumentRoute(entity, pageIndex);
                console.log('requireTransactionDocument:' + result);
                this.nextChatByJudge(entity, pageIndex, result);
                break;
            case 'propertiesCheck':
                // 属性一致かどうかチェック
                this.propertiesCheck(entity, pageIndex);
                break;
            case 'acceptCheckTwo':
                this.acceptCheckTwo(entity, pageIndex);
                break;
            default:
                break;
        }
    }

    /**
     * 属性一致かどうかのチェック
     *
     * @private
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof ExistingAccountChangeRenderer
     */
    private propertiesCheck(entity: ChatFlowMessageInterface, pageIndex: number) {
        // 選択された口座の取引ぶり
        const selectedAccountItems: DuplicateAccountAndAcceptResultAccount[] = this.state.lastestSelectedItems;
        const notSameResult = selectedAccountItems.find(
            (item) => {
                return item.attributeMismatchFlag === '1';
            }
        );
        const result = notSameResult ? 'different' : 'same';

        this.nextChatByJudge(entity, pageIndex, result);
    }

    private chooseDocumentRoute(entity: ChatFlowMessageInterface, pageIndex: number): string {
        // 本口座スワイプカードの取引ぶり
        const swipAccountTrading: AcceptionResultTradingCondition[] = this.state.currentTradingConditions;
        // 選択された口座の取引ぶり
        const selectedAccountItems: DuplicateAccountAndAcceptResultAccount[] = this.state.lastestSelectedItems;
        const selectedAccountTradingConditions = this.changeUtils.getTradingConditionsFromSelected(selectedAccountItems);
        selectedAccountItems.forEach(
            (item) => {
                item.acceptResult.tradingConditions.forEach(
                    (data) => {
                        selectedAccountTradingConditions.push(data);
                    }
                );
            }
        );

        // 本口座にその他あるか
        const isSwipCardHasOtherTrading = this.changeUtils.isHaveSpecTradingInTarget(
            [Constants.DBConsts.SpecTransactionCode.other],
            swipAccountTrading);

        // 本口座にそのた、投信有、特定口座ないかどうか
        const isSwipCardNoOthInvSpecTrading = !this.changeUtils.isHaveSpecTradingInTarget(
            [
                Constants.DBConsts.SpecTransactionCode.other,
                Constants.DBConsts.SpecTransactionCode.Investment,
                Constants.DBConsts.SpecTransactionCode.specialDeposit],
            swipAccountTrading
        );

        // 本口座に投信有OR特定口座あるか
        const isSwipCardHasInvSpecTrading = this.changeUtils.isHaveSpecTradingInTarget(
            [
                Constants.DBConsts.SpecTransactionCode.Investment,
                Constants.DBConsts.SpecTransactionCode.specialDeposit
            ],
            swipAccountTrading
        );
        // 選択口座にその他あるか
        const isSelectedHasOther = this.changeUtils.isHaveSpecTradingInTarget(
            [
                Constants.DBConsts.SpecTransactionCode.other
            ],
            selectedAccountTradingConditions
        );
        // 選択口座に投信有OR特定口座あるか
        const isSelectedHasInvSpec = this.changeUtils.isHaveSpecTradingInTarget(
            [
                Constants.DBConsts.SpecTransactionCode.Investment,
                Constants.DBConsts.SpecTransactionCode.specialDeposit
            ],
            selectedAccountTradingConditions
        );
        // 選択口座にそのた、投信有、特定口座ないかどうか
        const isSelectedNoOthInvSpecTrading = !this.changeUtils.isHaveSpecTradingInTarget(
            [
                Constants.DBConsts.SpecTransactionCode.other,
                Constants.DBConsts.SpecTransactionCode.Investment,
                Constants.DBConsts.SpecTransactionCode.specialDeposit],
            selectedAccountTradingConditions
        );

        // judgeの答えを選ぶ
        let judgeResult = '';
        const judgeResultBaseDocument = 'baseDocument';
        const judgeResultDocumentC = 'documentC';
        const judgeResultDocumentD = 'documentD';
        // スワイプ「その他」
        if (isSwipCardHasOtherTrading) {
            judgeResult = judgeResultBaseDocument;
        }

        // スワイプ「その他」含まない　＝＞　スワイプ「投信有OR特定口座」あり　＝＞　選択口座「その他」
        if (!isSwipCardHasOtherTrading && isSwipCardHasInvSpecTrading && isSelectedHasOther) {
            judgeResult = judgeResultDocumentD;
        }

        // スワイプ「その他」含まない　＝＞　スワイプ「投信有OR特定口座」あり　＝＞　選択口座「その他」含まない
        if (!isSwipCardHasOtherTrading && isSwipCardHasInvSpecTrading && !isSelectedHasOther) {
            judgeResult = judgeResultBaseDocument;
        }

        // スワイプ「その他」含まない　＝＞　スワイプ「その他、投信有、特定口座」含まない　＝＞　選択口座「その他」
        if (!isSwipCardHasOtherTrading && isSwipCardNoOthInvSpecTrading && isSelectedHasOther) {
            judgeResult = judgeResultDocumentD;
        }
        // スワイプ「その他」含まない　＝＞　スワイプ「その他、投信有、特定口座」含まない　＝＞　選択口座「その他」含まない　＝＞　選択口座「投信有、特定口座」
        if (!isSwipCardHasOtherTrading && isSwipCardNoOthInvSpecTrading && !isSelectedHasOther && isSelectedHasInvSpec) {
            judgeResult = judgeResultDocumentC;
        }
        // スワイプ「その他」含まない　＝＞　スワイプ「その他、投信有、特定口座」含まない　＝＞　選択口座「その他」含まない　＝＞　選択口座「その他、投信有、特定口座」含まない
        if (!isSwipCardHasOtherTrading && isSwipCardNoOthInvSpecTrading && !isSelectedHasOther && isSelectedNoOthInvSpecTrading) {
            judgeResult = judgeResultBaseDocument;
        }

        return judgeResult;
    }

    private nextChatByJudge(entity: ChatFlowMessageInterface, pageIndex: number, result: string) {
        console.log(entity);
        for (const choice of entity.choices) {
            if (choice.value === result) {
                // 次のチャットを開始させる
                console.log('this.emitMessageRetrivalEvent:' + choice.next);
                (choice.next === -1) ? this.action.chatFlowCompelete('') : this.emitMessageRetrivalEvent(choice.next, pageIndex);

            }
        }
    }

    /**
     * 取引ぶりチェック必要かどうか確認
     *
     * 住所変更もしくは氏名変更した場合は取引ぶりチェックを行う。
     *
     * @private
     * @returns {boolean} true:取引ぶりチェックが必要　false:要らない
     * @memberof ExistingAccountChangeRenderer
     */
    private isNeedTradingCheck(): boolean {
        if (this.changeState.isNameChanged || this.changeState.isAddressChanged) {
            return true;
        }
        return false;
    }

    /**
     * 取引ぶりチェック
     * API送信が必要ない、受付可否チェックAPIの結果に取引ぶり内容を持っている
     *
     * @private
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof ExistingAccountChangeRenderer
     */
    private transactionCheck(entity: ChatFlowMessageInterface, pageIndex: number, isNameChanged: boolean, isAddressChanged: boolean) {
        const isNeedTradingCheck = this.isNeedTradingCheck();

        let judgeResult: string = '';

        // 取引ぶりチェック必要かどうか判断
        // 前のステップで選択したデータ
        const selectedRowTargets: CifInfo[] = this.store.getState().submitData.allCifInfos;
        // 選択した複数データの中に、取引ぶりあるかどうか
        // true:あり,false:なし、配列は空白
        const isHaveTrading: boolean = selectedRowTargets.some(
            (element) => {
                // 選んだレコード口座番号
                const fullAccountNo = this.changeUtils.getFirstFullAccount(element.domesticAccountInfo);
                // 選んだレコードの口座番号
                const customerId = element.customerId;

                const tradingItem = this.state.acceptCheckResult.find(
                    (item) => {
                        if (!this.changeUtils.juniorNisaCheckWithCodes(element.birthDate, item.value.tradingConditions)
                            && !this.changeUtils.notAccepted(item.value.tradingConditions)
                                && !(this.changeState.isNameChanged && this.changeUtils.isNonDelivery(item.value.unacceptables) &&
                                    !this.changeState.isAddressChanged)) {
                            // 口座番号が存在する
                            if (fullAccountNo) {
                                return item.key === fullAccountNo && item.keyType === AcceptCheckKeyType.ACCOUNT
                                    && this.changeUtils.isAccountShowInTradingConfirmDocument(
                                        item.value.tradingConditions, isNameChanged, isAddressChanged);
                            } else {
                                // 口座番号が存在しない
                                return item.key === customerId && item.keyType === AcceptCheckKeyType.CUSTOMERID
                                    && this.changeUtils.isAccountShowInTradingConfirmDocument(
                                        item.value.tradingConditions, isNameChanged, isAddressChanged);
                            }
                        }

                    }
                );
                return tradingItem ? true : false;
            }
        );

        // exit: 離脱 no: 取引振りある yes: 取引振りなしor本人確認書類聴取必要なし（電話番号変更のみかつ取引振りある）
        if (!this.state.acceptCheckFlag && (!isHaveTrading || !isNeedTradingCheck)) {
            judgeResult = 'exit';
        } else if (isHaveTrading && isNeedTradingCheck) {
            judgeResult = 'no';
        } else if (!isHaveTrading || isHaveTrading && !isNeedTradingCheck)  {
            judgeResult = 'yes';
        }

        this.nextChatByJudge(entity, pageIndex, judgeResult);
    }

    /**
     * 取引ぶりチェック
     * API送信が必要ない、受付可否チェックAPIの結果に取引ぶり内容を持っている
     *
     * @private
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof ExistingAccountChangeRenderer
     */
    private transactionCheckTwo(entity: ChatFlowMessageInterface, pageIndex: number, isNameChanged: boolean, isAddressChanged: boolean) {
        let judgeResult: string = '';

        // 取引ぶりチェック必要かどうか判断
        // 前のステップで選択したデータ
        const selectedRowTargets: CifInfo[] = this.store.getState().submitData.allCifInfos;
        // 選択した複数データの中に、取引ぶりあるかどうか
        // true:あり,false:なし、配列は空白
        const isHaveTrading: boolean = selectedRowTargets.some(
            (element) => {
                // 選んだレコード口座番号
                const fullAccountNo = this.changeUtils.getFirstFullAccount(element.domesticAccountInfo);
                // 選んだレコードの顧客番号
                const customerId = element.customerId;

                const tradingItem = this.state.acceptCheckResult.find(
                    (item) => {
                        // 口座番号が存在する
                        if (fullAccountNo) {
                            return item.key === fullAccountNo && item.keyType === AcceptCheckKeyType.ACCOUNT
                                && this.changeUtils.isAccountShowInTradingConfirmDocument(
                                    item.value.tradingConditions, isNameChanged, isAddressChanged);
                        } else {
                            // 口座番号が存在しない
                            return item.key === customerId && item.keyType === AcceptCheckKeyType.CUSTOMERID
                                && this.changeUtils.isAccountShowInTradingConfirmDocument(
                                    item.value.tradingConditions, isNameChanged, isAddressChanged);
                        }

                    }
                );
                return tradingItem ? true : false;
            }
        );

        // no：取引ぶりある　yes:取引ぶりなし
        judgeResult = isHaveTrading ? 'no' : 'yes';

        this.nextChatByJudge(entity, pageIndex, judgeResult);
    }

    /**
     * 一覧テーブルコンポネントに表示する内容を決める
     *
     * @private
     * @param {string} yamlItemName
     * @returns {any[]}
     * @memberof ExistingAccountChangeRenderer
     */
    private getExistingAccountTableItems(yamlItemName: string): any[] {
        switch (yamlItemName) {
            case 'existingAccount':
                // 同一名義人のentityに
                return this.state.accounts;
            case 'transactionCheckNo':
                return this.state.submitData.existingAccount;
            default:
                break;
        }
    }

    private isDisableFirstRow(yamlItemName: string): boolean {
        switch (yamlItemName) {
            case 'existingAccount':
                return true;
            case 'transactionCheckNo':
                return false;
            default:
                break;
        }
    }
    private getExistingAccountTableShowType(yamlItemName: string): SHOW_TYPE {
        switch (yamlItemName) {
            case 'existingAccount':
                return SHOW_TYPE.INIT;
            case 'transactionCheckNo':
                return SHOW_TYPE.TRADING;
            default:
                break;
        }
    }

    private acceptCheckApi(entity: ChatFlowMessageInterface, pageIndex: number) {
        // 送信開始
        this.action.acceptCheck(this.makeAcceptCheckApiParams());

        let result: string = '';

        // 受信
        this.store.registerSignalHandler(ExistingAccountChangeStateSignal.ACCEPT_TARGET, (acceptCheckResult: AcceptionResult) => {
            this.store.unregisterSignalHandler(ExistingAccountChangeStateSignal.ACCEPT_TARGET);
            // (resultCode !== 'C' && resultCode !== 'Z') ? result = 'no' : result = 'yes';
            result = this.isHaveAcceptNo(acceptCheckResult);
            this.nextChatByJudge(entity, pageIndex, result);
        });
    }

    /**
     * 受付可否チェックAPIリクエストに使うパラメータ
     *
     * @private
     * @returns
     * @memberof ExistingAccountChangeRenderer
     */
    private makeAcceptCheckApiParams() {
        // 受付可否チェックを受ける口座リスト
        const accounts = [];
        let businessCode: string = '';
        if (this.changeState.isNameChanged && (this.changeState.isAddressChanged || this.changeState.isTelChanged)) {
            businessCode = BussinessCode.ADDRESS_TEL_NAME_CHANGE;
        } else if (this.changeState.isNameChanged) {
            businessCode = BussinessCode.NAME_CHANGE;
        } else if (this.changeState.isAddressChanged || this.changeState.isTelChanged) {
            businessCode = BussinessCode.ADDRESS_TEL_CHANGE;
        }
        this.state.lastestSelectedItems.forEach((element: DuplicateAccountAndAcceptResultAccount) => {
            // 顧客番号を入れる
            accounts.push({
                customerId: element.customerId
            });
        });

        const acceptCheckApiParams = {
            tabletApplyId: this.state.tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                accounts: accounts,
                businessCode: businessCode,
            }
        };

        return acceptCheckApiParams;
    }

    /**
     * 受付可否チェック
     *
     * @private
     * @param {AcceptionResult} acceptCheckResult
     * @returns {string} notExist: 受付可能 exist: 受付拒否存在 allExist: 全件受付拒否
     * @memberof ExistingAccountChangeRenderer
     */
    private isHaveAcceptNo(acceptCheckResult: AcceptionResult): string {
        this.action.setAcceptCheckFlag(false);
        let count = 0;

        // 取引ぶりチェック　かつ　投信あり　かつ　２０歳未満
        for (const account of this.state.lastestSelectedItems) {
            if (this.changeUtils.juniorNisaCheckWithCodes(account.birthdate, account.acceptResult.tradingConditions)) {
                count++;
            }
        }
        // 受付可否チェック　かつ　API結果がすべて成功 or 取引ぶりチェック　かつ　受付不可
        for (const account of acceptCheckResult.accounts) {
            const level = this.changeUtils.getConfirmDocMesLevelByTransaction(account.tradingConditions);
            if ((account.resultCode !== HostResultCode.IGNORE && account.resultCode !== HostResultCode.SUCCESS) ||
                (this.changeState.isNameChanged && this.changeUtils.isNonDelivery(account.unacceptables) &&
                !this.changeState.isAddressChanged)) {
                count++;
            } else if (level && level === TransactionLevel.NOT_ACCEPTED) {
                count++;
            }
        }
        if (count === 0) {
            return AcceptCheck.NOT_EXIST;
        } else if (count === acceptCheckResult.accounts.length) {
            this.action.setAcceptCheckFlag(true);
            return AcceptCheck.ALL_EXIST;
        } else {
            this.action.setAcceptCheckFlag(true);
            return AcceptCheck.EXIST;
        }
    }

    private acceptCheckTwo(entity: ChatFlowMessageInterface, pageIndex: number) {
        const result = this.state.acceptCheckFlag ? 'yes' : 'no';
        this.nextChatByJudge(entity, pageIndex, result);
    }
}
