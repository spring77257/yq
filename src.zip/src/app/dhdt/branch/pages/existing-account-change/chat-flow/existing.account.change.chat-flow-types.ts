import { ChatFlowQuestionTypes } from 'dhdt/branch/shared/modules/chat-flow/chat-flow-question-types';

export class ExistingAccountChangeChatFlowTypes extends ChatFlowQuestionTypes {
    public static readonly EXISTING_ACCOUNT = 'existingAccount';
    public static readonly CAMERA_BUTTON = 'cameraButton';
    public static readonly ITEM_LIST = 'itemList';
    public static readonly ROUTE = 'route';
}
