import { Injectable } from '@angular/core';
import { ScreenTransition } from 'dhdt/branch/pages/change/change-consts';
import { DuplicateAccountTenpoInfo } from 'dhdt/branch/pages/change/entity/duplicate-accountInfo-response.entity';
import { AddCarema, COMMON_CONSTANTS, SameProperties, SubmitDataKey } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ExistingAccountChangeAction } from 'dhdt/branch/pages/existing-account-change/action/existing-account-change.action';
import {
    ExistingAccountChangeChatFlowTypes
} from 'dhdt/branch/pages/existing-account-change/chat-flow/existing.account.change.chat-flow-types';
import {
    ExistingAccountChangeState, ExistingAccountChangeStore
} from 'dhdt/branch/pages/existing-account-change/store/existing-account-change.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';

/**
 * `DefaultChatFlowInputHandler`において、自動振込解約画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class ExistingAccountInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class ExistingAccountInputChangeHandler extends DefaultChatFlowInputHandler {
    private state: ExistingAccountChangeState;

    constructor(
        private action: ExistingAccountChangeAction,
        private store: ExistingAccountChangeStore) {
        super(action);

        this.state = store.getState();

    }

    @InputHandler(ExistingAccountChangeChatFlowTypes.EXISTING_ACCOUNT)
    private onExistingAccount(entity: ChatFlowMessageInterface, pageIndex: number, answer: DuplicateAccountTenpoInfo[]) {
        // this.action.onSelect(answer);

        const result: any = {};

        const text = [];
        answer.forEach(
            (data) => {
                text.push(data.branchNo + ' ' + data.branchName);
            }
        );
        result.text = text.join('<br>');

        // 最新の選択結果を保存
        this.action.setLastSelectItems(answer);

        // フレームワークのanswerに保存
        result.value = [{ key: entity.name, value: answer }];
        this.action.setAnswer(result);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);

        // 次のチャットがない場合は、チャットを終了する
        if (entity.next === -1) {
            this.chatFlowCompelete();
        }
    }

    @InputHandler(ExistingAccountChangeChatFlowTypes.CAMERA_BUTTON)
    private onCameraButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
            return;
        }
        const param = {
            image: answer.image,
            code: this.getCode(entity.name),
            key: entity.name,
        };
        // 写真を保存
        this.action.setDocumentImage(param);

        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(ExistingAccountChangeChatFlowTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        // 撮影した書類名を保存
        if (entity.name === 'identificationDocument3A' ||
            entity.name === 'identificationDocument3B' ||
            entity.name === 'identificationDocument3C') {
                if (answer === 'skip') {
                    this.action.saveDocumentName({
                        key: entity.name + 'Name',
                        value: ''
                    });
                } else {
                    this.action.saveDocumentName({
                        key: entity.name + 'Name',
                        value: answer.text
                    });
                }
            }
        if (answer === 'skip') {
            this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
            return;
        }
        if (entity.name === ScreenTransition.NEXT_TO_COMPLETE) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
            return;
        }
        if (entity.name === SubmitDataKey.ADD_IDENTITY_DOCUMENT_IMG
                && answer.value === AddCarema.YES) {
            const choice = entity.choices ? entity.choices.find((item) => item.value === answer.value) : undefined;
            this.action.resetToNode(choice ? choice.next : entity.order, pageIndex);
        } else {
            this.action.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.text }
                ]
            });
        }
        // 属性確認済のチャットボタン押下されるとき
        if (entity.name === 'isSameProperties') {
            // いいえ: チャットをクーリン
            if (answer.value === SameProperties.NO) {
                this.action.cleanChat();
            }
        }
        // 指定したチャットを表示
        this.emitMessageRetrivalEvent(answer.next, pageIndex);
    }

    @InputHandler(ExistingAccountChangeChatFlowTypes.KEYBOARD)
    private onKeybord(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({ text: answer.text, value: [{ key: entity.name, value: answer.text }]});
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(ExistingAccountChangeChatFlowTypes.ROUTE)
    private onRoute(entity: ChatFlowMessageInterface) {

        // チャットを終了する
        if (entity.example === 'compelete') {
            this.chatFlowCompelete();
        }
    }

    /**
     * `entity.nameに対応する本人確認書類コードを返却する。
     */
    private getCode(name: string) {
        switch (name) {
            case 'nameIdentiImageX':
                return this.state.submitData.identificationDocument3X;
            case 'nameIdentiImageA':
                return this.state.submitData.identificationDocument3A;
            case 'nameIdentiImageB':
                return this.state.submitData.identificationDocument3B;
            case 'nameIdentiImageC':
                return this.state.submitData.identificationDocument3C;
            case 'propertiesConfrimImage':
                return undefined;
        }
    }
}
