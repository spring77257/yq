import { JsonProperty } from 'adep/json';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';

class ValidationRules {
    public min: { value: number } | string;
    public max: { value: number };
    public required: { value: boolean };
    public conversion: { value: string };
    public range: any[];
    public maxValue: number;
}

export class CreditCardQuestionsModel {
    public order: number;
    public next: number;
    public type: string;
    public question: string;
    public example: string;
    public choices: any[];
    public name: string;
    public options: any;
    @JsonProperty({ clazz: ValidationRules })
    public validationRules: ValidationRules;
    public skip: number;
    public infoType: string;
    public fullwidthHalfwidthDivisionCode: any;
}

export class PageQuestionsModel {
    public order: number;
    public next: number;
    public type: string;
    public example: string;
    public choices: any[];
    @JsonProperty({ clazz: ValidationRules })
    public validationRules: ValidationRules;
    public question: string;
    public name: string;
    public answer: { order: number, text: string, value: any };
    public pageIndex: number;
    public skip: number;
    public orderIndex?: number;
}

export class CreditCardSubmitEntity {
    [key: string]: any;
    // タブレット申込管理ID
    public tabletApplyId: string;
    // 修正チャット、修正済みフラグ
    public editedList: any = {};                      // true:修正済
    // クレジットカードブランド
    public cardBrand;                       // 1:VISA 2:Mastercard 3:GCVISA
    // クレジットカードランク
    public cardRank;                        // 1:一般 2:ゴールド
    // クレジットカードお申し込み種類
    public applyType;                       // 1:バンクカード 2:バンクカードゴールド 3:バンクカードSuica(一般) 4:バンクカードSuica(ゴールド)
    // カード種類
    public cardType;                        // 41,42,43,51,53,61,63
    // ショッピングの取引目的
    public transPurpose: string;
    // お住いの種類
    public houseType: string;
    // 家賃負担
    public livingExpenses: string;
    // 居住年数
    public residenceYears: string;
    // 結婚有無
    public married: string;
    // 生計を同一とする方の人数
    public livelihoodPeople: string;
    // 扶養家族人数
    public dependentFamily: string;
    // ご職業
    public career;
    // お仕事内容
    public jobDescription: string;
    // 業種
    public industryType: string;
    // 業種(その他の場合）
    public industryTypeOther: string;
    // 所属部署
    public department: string;
    // 役職名
    public positionName: string;
    // 従業員数
    public employeeNumber: string;
    // 勤続（営業）年数
    public lengthOfService: string;
    // 転職回数
    public jobChangeTimes: string;
    // 前年度税込年収
    public taxIncludedAnnualIncomeLastYear: string;
    public nameRoma: string;                    // カード券面に表示するお名前(ローマ字)
    public printFirstName: string;              // カード券面printFirstName
    public printLastName: string;               // カード券面printLastName

    // ↓↓↓勤務先用の変数↓↓↓
    public employmentName: string;              // 勤務先名・屋号
    public employmentNameKana: string;          // 勤務先名(フリガナ)
    public employmentFirstTelephoneNo: string;  // お勤め先電話番号1段目
    public employmentSecondTelephoneNo: string; // お勤め先電話番号2段目
    public employmentThirdTelephoneNo: string;  // お勤め先電話番号3段目
    public phoneNoExtension: string;            // お勤め先内線番号
    public employmentHolderAddressPrefecture: string;                   // 都道府県名
    public employmentHolderAddressPrefectureFuriKana: string;           // 都道府県名(フリガナ)
    public employmentHolderAddressCountyUrbanVillage: string;           // 市区町村
    public employmentHolderAddressCountyUrbanVillageFuriKana: string;   // 市区町村(フリガナ)
    public employmentHolderAddressStreet: string;                       // 町丁名
    public employmentHolderAddressStreetFuriKana: string;
    public employmentHolderAddressStreetNameInput: string;              // 町丁名(キーボードで手入力)
    public employmentHolderAddressStreetNameFuriKanaInput: string;      // 町丁名(フリガナ, キーボードで手入力)
    public employmentHolderAddressStreetNameSelect: string;             // 町丁名(検索で選んだ)
    public employmentHolderAddressStreetNameFuriKanaSelect: string;     // 町丁名(フリガナ, 検索で選んだ)
    public employmentHolderAddressHouseNumber: string;                  // 番地以降(キーボードで手入力)
    public employmentHolderAddressHouseNumberFuriKana: string;          // 番地以降(フリガナ, キーボードで手入力)
    public employmentFirstZipCode: string;                              // 郵便番号(前3桁)
    public employmentLastZipCode: string;                               // 郵便番号(後4桁)
    // ↑↑↑勤務先用の変数↑↑↑

    // ↓↓↓学生用の変数↓↓↓
    public schoolName;                          // 学校名
    public schoolNameKana;                      // 学校名（フリガナ）
    public graduateDate: string;                // 卒業予定月
    public isNearGraduate: string;              // 卒業後学生フラグ 1:卒業90日以内である
    // ↑↑↑学生用の変数↑↑↑

    // ↓↓↓親権者用の変数↓↓↓
    public parentalLivingTogether: string;        // 親権者同居フラグ 1:同居している 0:同居してない
    public parentalFirstName: string;             // 親権者FirstName
    public parentalLastName: string;              // 親権者LastName
    public parentalFirstNameFuriKana: string;     // 親権者のお名前(フリガナ)FirstName
    public parentalLastNameFuriKana: string;      // 親権者のお名前(フリガナ)LastName
    public parentalFirstMobileNo: string;         // 親権者の携帯電話番号頭3桁
    public parentalSecondMobileNo: string;        // 親権者の携帯番号中4桁
    public parentalThirdMobileNo: string;         // 親権者の携帯番号後4桁
    public parentalFirstTel: string;              // 親権者の自宅電話番号頭3桁
    public parentalSecondTel: string;             // 親権者の自宅電話番号中4桁
    public parentalThirdTel: string;              // 親権者の自宅電話番号後4桁
    public parentalName;                          // 親権者のお名前
    public parentalNameKana;                      // 親権者のおなまえ(フリガナ)
    public parentalRelationship;                  // 親権者との続柄
    public parentalRelationshipText;              // 親権者との続柄詳細
    public parentalHolderMobileNo;                // 親権者の携帯電話番号
    public parentalHolderTelephoneNo;             // 親権者の自宅電話番号
    public parentalZipCode;                       // 親権者の郵便番号
    public firstZipCode: string;                  // 郵便番号3桁
    public lastZipCode: string;                   // 郵便番号4桁
    public parentalAddress;                       // 親権者の住所
    public parentalAddressKana;                   // 親権者の住所(フリガナ)
    public parentalBirthdate;                     // 親権者の生年月日
    public parentalHolderAddressPrefecture: string;                   // 都道府県名
    public parentalHolderAddressPrefectureFurigana: string;           // 都道府県名(フリガナ)
    public parentalHolderAddressCountyUrbanVillage: string;           // 市区町村
    public parentalHolderAddressCountyUrbanVillageFurigana: string;   // 市区町村(フリガナ)
    public parentalHolderAddressStreet: string;                       // 町丁名
    public parentalHolderAddressStreetNameInput: string;              // 町丁名(キーボードで手入力)
    public parentalHolderAddressStreetNameSelect: string;             // 町丁名(検索で選んだ)
    public parentalHolderAddressStreetNameFuriKanaSelect: string;     // 町丁名(フリガナ, 検索で選んだ)
    public parentalHolderAddressStreetNameFuriKanaInput: string;      // 町丁名(フリガナ, キーボードで手入力)
    public parentalHolderAddressStreetFuriKana: string;
    public parentalHolderAddressHouseNumber: string;                  // 番地以降(キーボードで手入力)
    public parentalHolderAddressHouseNumberFuriKana: string;          // 番地以降(フリガナ, キーボードで手入力)
    public parentalFirstZipCode: string;                              // 郵便番号(前3桁)
    public parentalLastZipCode: string;                               // 郵便番号(後4桁)
    // ↑↑↑親権者用の変数↑↑↑

    // ↓↓↓バンクカード付帯サービス用の変数↓↓↓
    public etcCategory: string;                 // ETCカード申込かどうか 1:申し込む 2:申し込まない
    public suicaAutoCharge;                     // Suicaオートチャージ 1:申し込む 2:申し込まない
    public revoPayCourse;                       // リボ払いコース
    public myPaceRevo;                          // まいペイすリボ
    public loanApplication;                     // バンクカードローン申込 1:申し込む 2:申し込まない
    public isHaveUnsecuredLoan: string;         // 無担保ローン契約 1:有 0：無し（固定）
    public overdraftLimit;                      // 希望貸し越し可能枠
    // ↑↑↑バンクカード付帯サービス用の変数↑↑↑

    public customerApplyStartDate: string;
    public customerApplyEndDate: string;
    public bankclerkAuthenticationStartDate: string;
    public bankclerkAuthenticationEndDate: string;

    public leaveType: string;

    public creditCardAgeFlag: string;              // 1(<18),2(20<=a<30),3(30<=a<66),4(>=66),5(18<=a<20)
    public creditCardBranchCode: string;
    public creditCardBranchName: string;
    public creditCardBranchNo: string;
    public creditCardBranchCategory: string;

    // ↓↓↓名義人関連変数↓↓↓
    public holderName;                          // 名義人ー氏名
    public holderNameFurigana;                  // 名義人ー氏名（フリガナ）
    public holderFirstName;                     // 名義人ー氏名（フリガナ）FirstName
    public holderLastName;                      // 名義人ー氏名（フリガナ）LastName
    public nameAlphabet;                        // 名義人ー英字氏名
    public firstNameAlphabet;                   // 名義人ー英字氏名FirstName
    public lastNameAlphabet;                    // 名義人ー英字氏名lastName
    public holderGender;                        // 名義人ー性別
    public holderBirthdate;                     // 名義人ー生（設立）年月日（西暦）
    public holderZipCode: string;               // 郵便番号
    public holderAddressPrefecture: string;                     // 名義人ー住所・都道府県
    public holderAddressPrefectureFuriKana: string;             // 名義人ー住所・都道府県（フリカナ）
    public holderAddressPrefectureFurigana: string;             // 名義人ー住所・都道府県（フリカナ）
    public holderAddressPrefectureCode: string;
    public holderAddressCountyUrbanVillage: string;             // 名義人ー住所・市区町村
    public holderAddressCountyUrbanVillageFuriKana: string;     // 名義人ー住所・市区町村（フリカナ）
    public holderAddressCountyUrbanVillageFurigana: string;     // 名義人ー住所・市区町村（フリガナ）
    public holderAddressCountyUrbanVillageCode: string;
    public holderAddressStreetNameSelect: string;               // 名義人ー住所・町丁名
    public holderAddressStreetNameInput: string;                // 「その他」の場合は、町丁名(例：湊町４丁目)
    public holderAddressStreetNameFurigana: string;             // 名義人ー住所・町丁名（フリガナ）
    public holderAddressStreetNameFuriKanaInput: string;        // 名義人ー住所・町丁名（フリカナ）
    public holderAddressStreetNameFuriKanaSelect: string;       // 「その他」の場合は、名義人ー住所・町丁名（フリガナ）
    public holderAddressHouseNumber: string;                    // 名義人ー住所・番地以降
    public holderAddressHouseNumberFuriKana: string;            // 名義人ー住所・番地以降（フリカナ）
    public holderAddressHouseNumberFurigana: string;            // 名義人ー住所・番地以降（フリガナ）
    public holderMobileNo;                                      // 名義人ー携帯電話番号
    public holderTelephoneNo;                                   // 名義人ー固定電話番号
    public nationalityCode;                                     // 名義人ー国籍コード
    // ↑↑↑名義人関連変数↑↑↑

    public creditCardFirstPwd4bits: string;                     // クレジットカード暗証番号(4桁)
    public cashCardFirstPwd4bits: string;                       // キャッシュカード暗証番号(4桁)
    public firstPwd4bits: string;                               // CDキャッシュカード暗証番号(4桁) 口座開設側で聴取するキャッシュカード暗証番号

    // QRコード受付情報
    public swipeCif: string;                                    // スワイプ店CIF
    public swipeBranchNo: string;
    public swipeAccountNo: string;
    public swipeAccountType: string;

    public receptionBranchNo: string;                           // 受付店番
    public receptionNo: string;                                 // 受付番号
    public receptionTime: string;                               // 受付年月日時分秒

    public consumptionTax: string;                              // 消費税
    public branchName: string;                                  // スワイプしたカード店舗名

    public fileInfo?: any;

    public nameNonConvert: string;
    public editNameKanji: string;

    public identificationDocument1: string;
    public identificationDocument2: string;

    // 本人確認種類
    public identificationCode: string;
    public identificationDocument1Text: string;
    public identificationDocument2Text: string;
    public category: number;

    public identificationPattern: string;

    public identificationDocument1Images: string[];
    public identificationDocument2Images: string[];
    public identificationAddressImages: string[];
    public identificationStudentImages: string[];

    public address: string;
    public nameKanji: string;

    public identificationDocumentLicenseNo: string;
    public contactNote: string;
    public bakupNotMaskingConfirmImages: any; // BC複合用マスキング未完了オブジェクトバックアップ

    /**
     * 本人氏名を取得
     */
    public getHolderName(): string {
        if (!this.holderFirstName || !this.holderLastName) {
            return this.holderName;
        }
        return this.holderFirstName + COMMON_CONSTANTS.FULL_SPACE + this.holderLastName;
    }

    // 勤務先電話番号取得
    public getEmploymentTelephoneNo(): string {
        if (!this.employmentFirstTelephoneNo || !this.employmentSecondTelephoneNo || !this.employmentThirdTelephoneNo) {
            return '';
        }
        return this.employmentFirstTelephoneNo + this.employmentSecondTelephoneNo + this.employmentThirdTelephoneNo;
    }

    // 親権者携帯電話番号取得
    public getParentalHolderMobileNo(): string {
        if (!this.parentalFirstMobileNo || !this.parentalSecondMobileNo || !this.parentalThirdMobileNo) {
            return '';
        }
        return this.parentalFirstMobileNo + this.parentalSecondMobileNo + this.parentalThirdMobileNo;
    }

    // 親権者自宅電話番号取得
    public getParentalHolderTelephoneNo(): string {
        if (!this.parentalFirstTel || !this.parentalSecondTel || !this.parentalThirdTel) {
            return '';
        }
        return this.parentalFirstTel + this.parentalSecondTel + this.parentalThirdTel;
    }

    public getHolderZipCode(): string {
        if (this.firstZipCode && this.lastZipCode) {
            return this.firstZipCode + this.lastZipCode;
        }
        return '';
    }
    public getHolderAddressStreetName(): string {
        if (this.holderAddressStreetNameSelect || this.holderAddressStreetNameInput) {
            return this.holderAddressStreetNameSelect
                ? this.holderAddressStreetNameSelect : this.holderAddressStreetNameInput;
        }

        return '';
    }
    public getHolderAddressStreetNameFuriKana(): string {
        if (this.holderAddressStreetNameFuriKanaSelect || this.holderAddressStreetNameFuriKanaInput) {
            return this.holderAddressStreetNameFuriKanaSelect
                ? this.holderAddressStreetNameFuriKanaSelect : this.holderAddressStreetNameFuriKanaInput;
        }

        return '';
    }

    public getParentalAddressStreetName(): string {
        if (this.parentalAddressStreetNameSelect || this.parentalAddressStreetNameInput) {
            return this.parentalAddressStreetNameSelect
                ? this.parentalAddressStreetNameSelect : this.parentalAddressStreetNameInput;
        }
        return '';
    }

    public getParentalAddressStreetNameFuriKana(): string {
        if (this.parentalAddressStreetNameFuriKanaSelect) {
            return this.parentalAddressStreetNameFuriKanaSelect;
        }

        if (this.parentalAddressStreetNameFuriKanaInput) {
            return this.parentalAddressStreetNameFuriKanaInput;
        }

        return '';
    }

    public getFamilyMemberName(): string {
        if (this.familyMemberFirstName && this.familyMemberLastName) {
            return this.familyMemberFirstName + COMMON_CONSTANTS.FULL_SPACE + this.familyMemberLastName;
        }
        return '';
    }
    public getFamilyMemberNameFurigana(): string {
        if (this.familyMemberFirstNameKana && this.familyMemberLastNameKana) {
            return this.familyMemberFirstNameKana + ' ' + this.familyMemberLastNameKana;
        }
        return '';
    }
    public getCardFamilyMemberName(): string {
        if (this.cardFamilyMemberFirstName && this.cardFamilyMemberLastName) {
            return this.cardFamilyMemberFirstName + ' ' + this.cardFamilyMemberLastName;
        }
        return '';
    }

    public getGuardianName(): string {
        if (this.parentalFirstName && this.parentalLastName) {
            return this.parentalFirstName + COMMON_CONSTANTS.FULL_SPACE + this.parentalLastName;
        }
        return '';
    }

    public getGuardianNameFurigana(): string {
        if (this.parentalFirstNameKana && this.parentalLastNameKana) {
            return this.parentalFirstNameKana + ' ' + this.parentalLastNameKana;
        }
        return '';
    }

    public getPrintName(): string {
        return this.printFirstName + ' ' + this.printLastName;
    }

    public getCreditRegisterTelephoneNo(): string {
        if (!this.creditRegisterFirstTelephoneNo || !this.creditRegisterSecondTelephoneNo || !this.creditRegisterThirdTelephoneNo) {
            if (this.creditRegisterTelephoneNo === '0') {
                return null;
            }
            return this.creditRegisterTelephoneNo;
        }
        return this.creditRegisterFirstTelephoneNo
            + this.creditRegisterSecondTelephoneNo + this.creditRegisterThirdTelephoneNo;
    }

    /**
     * 表示用アドレスを取得
     */
    public getAddress(): string {
        const prefecture = this.parentalAddressPrefecture || '';
        const countyUrbanVillage = this.parentalAddressCountyUrbanVillage || '';
        const streetName = this.getParentalAddressStreetName() || '';
        const addressHouseNumber = this.parentalAddressHouseNumber || '';

        return prefecture + countyUrbanVillage + streetName + addressHouseNumber;
    }

    /**
     * 表示用フリガナアドレスを取得
     */
    public getAddressFurikana(): string {
        const prefecture = this.parentalAddressPrefectureFuriKana || '';
        const countyUrbanVillage = this.parentalAddressCountyUrbanVillageFuriKana || '';
        const streetName = this.getParentalAddressStreetNameFuriKana() || '';
        const addressHouseNumber = this.parentalAddressHouseNumberFuriKana || '';

        return prefecture + countyUrbanVillage + streetName + addressHouseNumber;
    }

    public getEmploymentAddressStreetName(): string {
        if (this.employmentHolderAddressStreetNameSelect || this.employmentHolderAddressStreetNameInput) {
            return this.employmentHolderAddressStreetNameSelect
                ? this.employmentHolderAddressStreetNameSelect : this.employmentHolderAddressStreetNameInput;
        }
        return '';
    }

    public getParentalHolderAddressStreetName(): string {
        if (this.parentalHolderAddressStreetNameSelect || this.parentalHolderAddressStreetNameInput) {
            return this.parentalHolderAddressStreetNameSelect
                ? this.parentalHolderAddressStreetNameSelect : this.parentalHolderAddressStreetNameInput;
        }
        return '';
    }

}

export class CheckboxStatusEntity {
    public isApplyChecklistStatus: boolean;         // お申し込みにあたっての確認事項
    public isPersonalInformationStatus: boolean;    // 個人情報の利用目的
    public isBankcardRegulationStatus: boolean;     // バンクカードの規定・規約
    public isForeignPulicFiguresSatus: boolean;     // 外国の重要な公的地位にある方の確認
    public isAllMaskingStatus: boolean; // 写真マスキング
    public isStudentMaskingStatus: boolean; // 学生証マスキング
}

export class DropDownListEntity {
    public key: string;
    public value: string;
    public filler1: string;
    public filler2: string;
    public filler3: string;
}
