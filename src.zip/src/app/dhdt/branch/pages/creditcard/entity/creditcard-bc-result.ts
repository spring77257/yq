export class AcceptionResult {
    public accounts: AcceptionResultAccount[];
}

export class AcceptionResultAccount {
    public resultCode: string;
    public errorType: string;
    public errorCode: string;
    public unacceptables: AcceptionResultUnacceptable[];
    public tradingConditions: AcceptionResultTradingCondition[];
}

export class AcceptionResultTradingCondition {
    public tradingConditionCode: string;
    public tradingConditionName: string;
}

export class AcceptionResultUnacceptable {
    public unacceptableCode: string;
    public unacceptableName: string;
}
