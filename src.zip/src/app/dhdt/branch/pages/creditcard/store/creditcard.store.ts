import { Injectable, NgZone } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { LabelService } from 'adep/services';
import {
    AccountType, ClearSavingImagesClickRecordType, Constants, HolderMobileNoFlag,
    IdentificationDocumentCode,
    NameNonConvert, ZipCode,
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CreditCardActionType } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import {
    CheckboxStatusEntity, CreditCardQuestionsModel,
    CreditCardSubmitEntity, DropDownListEntity, PageQuestionsModel
} from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { AcceptionResult } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { CifInfoInquiryResponseEntity } from 'dhdt/branch/shared/entity/cif-info-inquiry-response.entity';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { CifInformationUtils } from 'dhdt/branch/shared/utils/cif-information-utils';
import { KanaToRomaji } from 'dhdt/branch/shared/utils/kana-to-romaji-util';
import * as moment from 'moment';
import { Observable } from 'rxjs/Observable';

export interface CreditCardState extends State {
    questions: CreditCardQuestionsModel[][];
    showChats: PageQuestionsModel[];
    showConfirm: PageQuestionsModel[];
    submitData: CreditCardSubmitEntity;
    originSubmitData: CreditCardSubmitEntity;
    tabletStartDate: string;
    customerApplyStartDate: string;
    tabletApplyId: number;
    identityDocuments: string[];
    additionalInfoDocuments: string[];
    agentIdentityDocuments: string[];
    agentAdditionalInfoDocuments: string[];
    copySubmitData: CreditCardSubmitEntity;
    copyShowConfirm: PageQuestionsModel[];
    dropDownList: DropDownListEntity[];
    cifInfoInquiryList: CifInfoInquiryResponseEntity[];
    checkboxStatus: CheckboxStatusEntity;
    currentFileInfo: any;
    editedKeysArr: any[];
    confirmPageChanges: any;
    // 各書類の画像について、masking確認完了されたない画像のIndexを格納するオブジェクト
    notMaskingConfirmImages: {
        identificationDocument1Images: number[],    // 本人確認書類１
        identificationDocument2Images: number[],    // 本人確認書類２
        identificationAddressImages: number[],   // 住所確認書類
        identificationStudentImages: number[],
    };
    copyComplexTransConfirmInfos: {
        contactNote: string,  // 連絡事項
        identificationStudentImages: string[],  // 学生証
        identificationDocumentLicenseNo: string  // 運転免許証番号
    };
}

export const CreditCardSignal = {
    SEND_ANSWER: 'SEND_ANSWER',
    GET_QUESTION: 'GET_QUESTION',
    GET_INFO_OCR_COMPLETE: 'GET_INFO_OCR_COMPLETE',
    GET_CIF_INFO_COMPLETE: 'GET_CIF_INFO_COMPLETE',
    SUCCESS_VALIDATION: 'SUCCESS_VALIDATION',
    FAILED_VALIDATION: 'FAILED_VALIDATION',
    SUCCESS_INSERT_INFO: 'SUCCESS_INSERT_INFO',
    CHAT_FLOW_COMPELETE: 'CHAT_FLOW_COMPELETE',
    CHAT_FLOW_RETURN: 'CHAT_FLOW_RETURN',
    SUCCESS_INSERT_TIME_SAVINGS_APPLY: 'SUCCESS_INSERT_TIME_SAVINGS_APPLY',  // イメージアップロードAPIが正しく実行完了

    CANCEL_COMPLETE: 'CANCEL_COMPLETE',
    GET_LIST_COMPLETE: 'GET_LIST_COMPLETE',
    GET_CIF_INFORMATION: 'GET_CIF_INFORMATION',  // CIF情報照会
    GET_PASSWORD_RULE: 'GET_NEW_PASSWORD_RULE',  // 暗証番号ルール適合性チェック結果
    SUCCESS_SET_SYSTEM_TIME: 'SUCCESS_SET_SYSTEM_TIME',
    SUCCESS_MODIFY_CHECKBOX_STATUS: 'SUCCESS_MODIFY_CHECKBOX_STATUS',
    ACCEPT_TARGET: 'ACCEPT_TARGET',
    BC_APPLY: 'BC_APPLY',
    CHARACTER_CHECK: 'CHARACTER_CHECK'
};

@Injectable()
export class CreditCardStore extends Store<CreditCardState> {
    public documentMap: Map<number, string>;
    private replaceValues: Array<{ key: string, value: string }>;
    private keysArr: any[] = [];
    private submitDataArr: any[] = [];
    private showConfirmArr: any[] = [];
    private keysArrBak: any[] = [];
    private submitDataArrBak: any[] = [];
    private showConfirmArrBak: any[] = [];

    constructor(
        private ngZone: NgZone,
        private editService: EditService,
        private labelService: LabelService
    ) {
        super();
        this.state = {
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new CreditCardSubmitEntity(),
            originSubmitData: new CreditCardSubmitEntity(),
            tabletStartDate: '',
            customerApplyStartDate: '',
            tabletApplyId: -1,
            identityDocuments: [],
            additionalInfoDocuments: [],
            agentIdentityDocuments: [],
            agentAdditionalInfoDocuments: [],
            copySubmitData: null,
            copyShowConfirm: [],
            dropDownList: [],
            cifInfoInquiryList: new Array<CifInfoInquiryResponseEntity>(),
            checkboxStatus: {
                isApplyChecklistStatus: false,        // お申し込みにあたっての確認事項
                isPersonalInformationStatus: false,   // 個人情報の利用目的
                isBankcardRegulationStatus: false,    // バンクカードの規定・規約
                isForeignPulicFiguresSatus: false,    // 外国の重要な公的地位にある方の確認
                isAllMaskingStatus: false,            // 写真マスキング
                isStudentMaskingStatus: false         // 学生証マスキング
            },
            currentFileInfo: {},
            editedKeysArr: [],
            confirmPageChanges: {},
            notMaskingConfirmImages: {
                identificationDocument1Images: [],    // 本人確認書類１
                identificationDocument2Images: [],    // 本人確認書類２
                identificationAddressImages: [],    // 住所確認書類
                identificationStudentImages: []
            },
            copyComplexTransConfirmInfos: null
        };
        this.setDocumentMap();
    }

    /**
     * 修正用テンプレートをロードする
     * @param params パラメーター
     */
    @ActionBind(CreditCardActionType.GET_CONFIRM_PAGE_TEMPLATE)
    private loadConfirmTemplate(params: any) {
        if (params) {
            this.state.questions[params.pageIndex] = params.data;
            this.state.submitData.fileInfo = params.fileInfo;
        }
    }

    /**
     * チャットテンプレートをロードする
     * @param params yamlファイルにかんする情報
     */
    @ActionBind(CreditCardActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.saveCurrentYamlInfo(params.fileInfo[0]);

            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(CreditCardSignal.GET_QUESTION, params.pageIndex);
        }
    }

    /**
     * branch status insert
     * @param data tabletApplyId
     */
    @ActionBind(CreditCardActionType.BRANCH_STATUS_INSERT)
    private branchStatusInsert(data: any) {
        if (data) {
            this.state.tabletApplyId = data;
            this.setSubmitData('tabletApplyId', data);
        }
    }

    /**
     * 暗証番号ルール適合性チェック(初めて発行)結果設定
     * @param data response data
     */
    @ActionBind(CreditCardActionType.GET_EXISTING_PASSWORD_RULE)
    private signalExistingCustomerPasswordCheckResult(data: any) {
        // 暗証番号ルール適合性チェック結果を発送する
        this.sendSignal(CreditCardSignal.GET_PASSWORD_RULE, data);
    }

    /**
     * ストアをクリアする
     */
    @ActionBind(CreditCardActionType.CLEAR)
    private clearStore() {
        this.keysArr = [];
        this.submitDataArr = [];
        this.showConfirmArr = [];
        this.state = {
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new CreditCardSubmitEntity(),
            originSubmitData: new CreditCardSubmitEntity(),
            tabletStartDate: '',
            customerApplyStartDate: '',
            tabletApplyId: -1,
            identityDocuments: [],
            additionalInfoDocuments: [],
            agentIdentityDocuments: [],
            agentAdditionalInfoDocuments: [],
            copySubmitData: null,
            dropDownList: [],
            copyShowConfirm: [],
            cifInfoInquiryList: new Array<CifInfoInquiryResponseEntity>(),
            checkboxStatus: {
                isApplyChecklistStatus: false,       // お申し込みにあたっての確認事項
                isPersonalInformationStatus: false,  // 個人情報の利用目的
                isBankcardRegulationStatus: false,    // バンクカードの規定・規約
                isForeignPulicFiguresSatus: false,    // 外国の重要な公的地位にある方の確認
                isAllMaskingStatus: false,            // 写真マスキング
                isStudentMaskingStatus: false         // 学生証マスキング
            },
            currentFileInfo: {},
            editedKeysArr: [],
            confirmPageChanges: {},
            notMaskingConfirmImages: {
                identificationDocument1Images: [],    // 本人確認書類１
                identificationDocument2Images: [],    // 本人確認書類２
                identificationAddressImages: [],    // 住所確認書類
                identificationStudentImages: []
            },
            copyComplexTransConfirmInfos: null
        };
    }

    /**
     * 次のステップを取得する
     * @param params 当ステップ情報
     */
    @ActionBind(CreditCardActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: { order: number, pageIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<CreditCardQuestionsModel>(this.state.questions[pageIndex])
                    .min<CreditCardQuestionsModel>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus = new PageQuestionsModel();
                        qus.order = item.order;
                        qus.next = item.next;
                        qus.type = item.type;
                        qus.question = this.replaceParams(item.question);
                        qus.name = item.name;
                        qus.skip = item.skip;
                        qus.pageIndex = pageIndex;
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        this.sendSignal(CreditCardSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<CreditCardQuestionsModel>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        const qus = new PageQuestionsModel();
                        qus.order = item.order;
                        qus.next = item.next;
                        qus.type = item.type;
                        qus.question = this.replaceParams(item.question);
                        qus.name = item.name;
                        qus.skip = item.skip;
                        qus.pageIndex = pageIndex;
                        const repeatOrderArr = this.state.showChats.filter((filterItem) => filterItem.order === params.order);
                        // orderは繰り返しの場合、orderIndexを追加する。
                        (repeatOrderArr && repeatOrderArr.length > 0) ? qus.orderIndex = repeatOrderArr.length : qus.orderIndex = 0;
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        this.sendSignal(CreditCardSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => { console.log('Outside Done!'); });
        });
    }

    /**
     * 質問文言をリプレースする
     * @param str 文言
     * @param type イメージ
     */
    private replaceParams(str: string): string {
        if (str.indexOf('@') === -1) {
            return str;
        }

        this.replaceValues = [
            {
                key: '@Doc2SkipLabel',
                value: this.state.submitData.identificationDocument1 === IdentificationDocumentCode.PASSPORT_WITHOUT_SELF_INPUT ?
                    '' : this.labelService.labels.confirm.identityDocumentConfirm.doc2SkipLabel
            },
            {
                key: '@EmploymentAddressKana',
                value:
                    this.state.submitData.employmentHolderAddressPrefectureFuriKana +
                    this.state.submitData.employmentHolderAddressCountyUrbanVillageFuriKana +
                    (
                        this.state.submitData.employmentHolderAddressStreetNameFuriKanaInput ||
                        this.state.submitData.employmentHolderAddressStreetNameFuriKanaSelect ||
                        this.state.submitData.employmentHolderAddressStreetFuriKana || ''
                    ) + this.state.submitData.employmentHolderAddressHouseNumberFuriKana
            },
            {
                key: '@EmploymentAddressWithoutHouseKana',
                value:
                    this.state.submitData.employmentHolderAddressPrefectureFuriKana +
                    this.state.submitData.employmentHolderAddressCountyUrbanVillageFuriKana
            },
            {
                key: '@EmploymentAddressOther',
                value:
                    this.state.submitData.employmentHolderAddressPrefecture +
                    this.state.submitData.employmentHolderAddressCountyUrbanVillage
            },
            {
                key: '@EmploymentAddress',
                value:
                    this.state.submitData.employmentHolderAddressPrefecture +
                    this.state.submitData.employmentHolderAddressCountyUrbanVillage +
                    (
                        this.state.submitData.employmentHolderAddressStreetNameInput ||
                        this.state.submitData.employmentHolderAddressStreetNameSelect ||
                        this.state.submitData.employmentHolderAddressStreet ||
                        ''
                    )
            },
            {
                key: '@EmploymentZipCode', value: this.state.submitData.employmentFirstZipCode + '-'
                    + this.state.submitData.employmentLastZipCode
            },
            { key: '@EmploymentHolderAddressPrefecture', value: this.state.submitData.employmentHolderAddressPrefecture },
            { key: '@EmploymentHolderAddressCountyUrbanVillage', value: this.state.submitData.employmentHolderAddressCountyUrbanVillage },
            {
                key: '@EmploymentHolderAddressStreetNameSelect',
                value: this.state.submitData.employmentHolderAddressStreet || this.state.submitData.employmentHolderAddressStreetNameSelect
            },
            { key: '@HolderMobileNo', value: this.state.submitData.holderMobileNo },
            { key: '@HolderNameFurigana', value: this.state.submitData.holderNameFurigana },

            {
                key: '@ParentalName',
                value: this.state.submitData.parentalFirstName + ' ' + this.state.submitData.parentalLastName
            },
            {
                key: '@ParentalNameFuriKana',
                value: this.state.submitData.parentalFirstNameFuriKana + ' ' + this.state.submitData.parentalLastNameFuriKana
            },
            {
                key: '@ParentalAddressKana',
                value:
                    this.state.submitData.parentalHolderAddressPrefectureFuriKana +
                    this.state.submitData.parentalHolderAddressCountyUrbanVillageFuriKana +
                    (
                        this.state.submitData.parentalHolderAddressStreetNameFuriKanaInput ||
                        this.state.submitData.parentalHolderAddressStreetNameFuriKanaSelect ||
                        this.state.submitData.parentalHolderAddressStreetFuriKana || ''
                    ) + this.state.submitData.parentalHolderAddressHouseNumberFuriKana
            },
            {
                key: '@ParentalAddressWithoutHouseKana',
                value:
                    this.state.submitData.parentalHolderAddressPrefectureFuriKana +
                    this.state.submitData.parentalHolderAddressCountyUrbanVillageFuriKana
            },
            {
                key: '@ParentalAddressOther',
                value:
                    this.state.submitData.parentalHolderAddressPrefecture +
                    this.state.submitData.parentalHolderAddressCountyUrbanVillage
            },
            {
                key: '@ParentalAddress',
                value:
                    this.state.submitData.parentalHolderAddressPrefecture +
                    this.state.submitData.parentalHolderAddressCountyUrbanVillage +
                    (
                        this.state.submitData.parentalHolderAddressStreetNameInput ||
                        this.state.submitData.parentalHolderAddressStreetNameSelect ||
                        this.state.submitData.parentalHolderAddressStreet ||
                        ''
                    )
            },
            {
                key: '@ParentalZipCode', value: this.state.submitData.parentalFirstZipCode + '-'
                    + this.state.submitData.parentalLastZipCode
            },
            {
                key: '@ParentalHolderAddressPrefecture',
                value: this.state.submitData.parentalHolderAddressPrefecture
            },
            {
                key: '@ParentalHolderAddressCountyUrbanVillage',
                value: this.state.submitData.parentalHolderAddressCountyUrbanVillage
            },
            {
                key: '@ParentalHolderAddressStreetNameSelect',
                value: this.state.submitData.parentalHolderAddressStreet || this.state.submitData.parentalHolderAddressStreetNameSelect
            },
            {
                key: '@identificationDocument1', value: this.state.submitData.identificationDocument1Text
            },
            {
                key: '@identificationDocument2', value: this.state.submitData.identificationDocument2Text
            },
            { key: '@Address', value: this.state.submitData.address},
            { key: '@Name',
              value: this.state.submitData.nameKanjiBackup !== undefined ? this.state.submitData.nameKanjiBackup :
                        this.state.submitData.nameKanji !== undefined ? this.state.submitData.nameKanji : this.state.submitData.nameKana
            },
        ];

        let result = str;

        const documentNameKeyArr = ['@identificationDocument1', '@identificationDocument2'];
        this.replaceValues.forEach((element) => {
            if (result.indexOf(element.key) !== -1) {
                let identificationDocumentName;
                const propertyName = documentNameKeyArr[documentNameKeyArr.indexOf(element.key)];
                if ((this.state.submitData.accountType === AccountType.CREDIT_CARD) &&
                     element.key === propertyName) {
                    // 本人確認書類１/２ && 記載ありの場合、chatFlowのorder繰り返し運用する。
                    this.state.showChats.forEach((item, index) => {
                        if (propertyName.replace('@', '') === item.name) {
                            // 文言のパラメータはshowChatsからです
                            identificationDocumentName = (item.answer && item.answer.text) ? item.answer.text : null;
                        }
                    });

                    /**
                     * 「本人確認書類１/２選択 && 本人確認書類１/２名はブランク」 or
                     * if   「submitDataの本人確認書類１/２名」は「showChatsの本人確認書類１/２名」と違う の場合、表示の文言のパラメータはshowChatsからです、
                     * else 表示の文言のパラメータはsubmitDataからです
                     */
                    result = (element.value === undefined || identificationDocumentName !== element.value) ?
                                result.replace(element.key, identificationDocumentName) :
                                result.replace(element.key, element.value);
                } else {
                    result = result.replace(element.key, element.value);
                }
            }
        });

        return result;
    }

    /**
     * チャット内容を編集する
     *
     * @param params チャット情報
     */
    @ActionBind(CreditCardActionType.EDIT_CHAT)
    private editChat(params: any) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;
        const orderIndex = params.orderIndex;

        let i = -1;
        let index = -1;
        if (orderIndex !== null && orderIndex !== undefined) {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order && message.orderIndex === orderIndex) {
                    index = i;
                }
            });
        } else {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order) {
                    index = i;
                }
            });
        }

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }

        this.cleanSubmitData(answerOrder);
        this.resetIdentificationDocument(order, pageIndex);
    }

    /**
     * 回答を設定する
     * @param params 回答
     */
    @ActionBind(CreditCardActionType.SET_ANSWER)
    private setAnswer(answer: { order: number, text: string, value: Array<{ key: string, value: string }> }) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        answer.order = this.getTopOrder();
        chat.answer = answer;
        if (answer.value) {
            answer.value.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    /**
     * データ設定
     *
     * @param data 回答
     */
    @ActionBind(CreditCardActionType.SET_STATE_DATA)
    private setData(submitData: any) {
        Object.keys(submitData).forEach((key) => {
            this.setSubmitData(key, submitData[key]);
        });
    }

    /**
     * Submitデータ設定
     *
     * @param data 回答
     */
    @ActionBind(CreditCardActionType.SET_STATE_SUBMIT_DATA_VALUE)
    private setStateSubmitDataValue(data: any) {
        if (data) {
            this.setSubmitData(data.name, data.value);
        }
    }

    /**
     * チャットの表示内容をクリアする
     */
    @ActionBind(CreditCardActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    /**
     * パスワードを検証する
     *
     * @param param 検証項目
     */
    @ActionBind(CreditCardActionType.VALIDATION_PASSWORD)
    private validationPassword(params: any) {
        if (params.type === 'SUCCESS') {
            this.sendSignal(CreditCardSignal.SUCCESS_VALIDATION);
        } else {
            this.sendSignal(CreditCardSignal.FAILED_VALIDATION);
        }
    }

    /**
     * submit dataとshowConfirmをバックアップする
     */
    @ActionBind(CreditCardActionType.SUBMIT_DATA_BACKUP)
    private submitDataBackup() {
        this.state.copySubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
        this.state.copyShowConfirm = this.state.showConfirm.slice(0, this.state.showConfirm.length);
    }

    /**
     * submit dataをリセットする
     */
    @ActionBind(CreditCardActionType.RESET_SUBMIT_DATA)
    private resetSubmitData() {
        this.state.submitData = this.state.copySubmitData;
        this.state.copySubmitData = null;
    }

    /**
     * Reset showConfirm
     * @param showConfirm showConfirm
     */
    @ActionBind(CreditCardActionType.RESET_SHOW_CONFIRM)
    private resetShowConfirm(data) {
        this.state.showConfirm = data;
    }

    /**
     * Reset showChats
     * @param data origin showChats
     */
    @ActionBind(CreditCardActionType.RESET_SHOWCHATS)
    private resetShowChats(data: any) {
        this.state.showChats = data.originShowChats;
        this.state.submitData = data.originSubmitData;
    }

    /**
     * コードマスタの情報を取得する
     *
     * @param data
     */
    @ActionBind(CreditCardActionType.RETRIEVE_DROP_LIST)
    private retrieveDropList(data) {
        this.state.dropDownList = data;
    }

    /**
     * 行員認証情報をサブミットする
     *
     * @param data データ
     */
    @ActionBind(CreditCardActionType.BRANCH_INFO_INSERT)
    private branchInfoInsert(data) {
        this.sendSignal(CreditCardSignal.SUCCESS_INSERT_INFO);
    }

    /**
     * チャットが完了
     * @param nextChatName 次のチャットの名
     */
    @ActionBind(CreditCardActionType.CHAT_FLOW_COMPELETE)
    private chatFlowCompelete(nextChatName: string) {
        this.sendSignal(CreditCardSignal.CHAT_FLOW_COMPELETE, nextChatName);
    }

    /**
     * 前のチャットに戻る
     *
     * @private
     * @param {*} next
     * @memberof CreditCardStore
     */
    @ActionBind(CreditCardActionType.CHAT_FLOW_RETURN)
    private chatFlowReturn(next: any) {
        this.sendSignal(CreditCardSignal.CHAT_FLOW_RETURN, next);
    }

    /**
     * 最後のノードをチェックする
     * @param params パラメーター
     */
    @ActionBind(CreditCardActionType.RESET_LAST_NODE)
    private resetLastNode(params: { order: number, pageIndex: number }) {
        this.getState().showChats.pop();
        this.getNextChatByAnswer(params);
    }

    /**
     * 年齢フラグを設定する
     * @param params パラメーター
     */
    @ActionBind(CreditCardActionType.SET_MEMBER_AGE_FLG)
    private setMemberAgeFlg(params: any) {
        this.setSubmitData('memberAgeFlg', params.memberAgeFlg);
        this.setSubmitData('familyApply', params.familyCard);
    }

    /**
     * ランクを設定する
     * @param params パラメーター
     */
    @ActionBind(CreditCardActionType.SET_CREDITCARD_BRAND_AND_RANK)
    private setCreidtCardRank(params: any) {
        if (params.cardBrand) {
            this.setSubmitData('cardBrand', params.cardBrand);
        }
        if (params.cardRank) {
            this.setSubmitData('cardRank', params.cardRank);
        }
        if (params.applyType) {
            this.setSubmitData('applyType', params.applyType);
        }
        if (params.cardType) {
            this.setSubmitData('cardType', params.cardType);
        }
    }

    /**
     * 行員IDを設定する
     * @param bankclerkId 行員ID
     */
    @ActionBind(CreditCardActionType.SET_BANKCLERK_ID)
    private setBankclerkId(params: any) {
        this.setSubmitData('userMngNo', params.bankclerkId);
    }

    /**
     * Save yaml file Information
     */
    private saveCurrentYamlInfo(params: any) {
        this.state.currentFileInfo.yamlId = params.id;
        this.state.currentFileInfo.screenId = params.screenId;
        this.state.currentFileInfo.screenName = params.screenName;
    }

    /**
     * CIF情報照会設定
     * @param data response data
     */
    @ActionBind(CreditCardActionType.SET_CIF_INFORMATION)
    private setCifInformation(results: any) {
        // CIF情報照会
        const cifInfo = results.data[0];
        // 口座残高情報照会
        const accountBalanceInfo = results.data[1];

        if (cifInfo && cifInfo.result) {
            this.state.cifInfoInquiryList = cifInfo.result.cifInfoInquiryResponseList;
            this.settingCifInformation(cifInfo.result.cifInfoInquiryResponse);
        }

        if (accountBalanceInfo && accountBalanceInfo.result && accountBalanceInfo.result.responseList[0]) {
            this.setSubmitData('swipeCardType', accountBalanceInfo.result.responseList[0].holderCardType);
        }

        this.setSubmitData('holderMobileNoFlag', this.state.submitData.holderMobileNo
            ? HolderMobileNoFlag.NOT_BLANK : HolderMobileNoFlag.BLANK);

        this.sendSignal(CreditCardSignal.GET_CIF_INFO_COMPLETE);
    }

    /**
     * SubmitDataに本人基本情報設定を行う
     * @param entity CIF情報エンティティ
     */
    private settingCifInformation(entity: CifInfoInquiryResponseEntity) {
        const kanaToRomaji = new KanaToRomaji();
        // 基本情報を設定する
        CifInformationUtils.setCifBasicInfoForCommon(this.state.submitData, this.keysArr, entity);
        // 店舗名
        this.setSubmitData('branchName', entity.branchName);
        // 氏名ローマ字
        this.setSubmitData('printFirstName',
            kanaToRomaji.convert(entity.nameKana.split('　')[0]));
        this.setSubmitData('printLastName',
            kanaToRomaji.convert(entity.nameKana.split('　')[1]));
        // 勤務先名
        this.setSubmitData('employmentName', entity.branchName);
    }

    /**
     * submit dataをセットする
     *
     * @param key キー
     * @param value 値
     */
    private setSubmitData(key, value) {
        if (key !== undefined) {
            this.state.submitData[key] = value;
            if (key && value) {
                this.keyPush(key, value);
            }
        }
    }

    /**
     * キーを配列に保存する
     *
     * @param key キー
     * @param value 値
     */
    private keyPush(key: any, value: any) {
        if (value === null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                this.keysArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1 || key === 'addIdentityDocumentImg') {
            this.keysArr.push(key);
            const backupSubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
            this.submitDataArr.push(backupSubmitData);
            const backupShowConfirm = JSON.parse(JSON.stringify(this.state.showConfirm));
            this.showConfirmArr.push(backupShowConfirm);
        } else if ((key.indexOf('Kana') !== -1 || key === 'career')
            && value) {
                this.submitDataArr[this.keysArr.length - 1][key] = value;
                this.showConfirmArr[this.keysArr.length - 1].forEach((item) => {
                    if (item.name === key && item.answer
                        && this.state.showChats[this.state.showChats.length - 1]
                        && this.state.showChats[this.state.showChats.length - 1].name === key
                        && this.state.showChats[this.state.showChats.length - 1].answer) {
                        item.answer.text = this.state.showChats[this.state.showChats.length - 1].answer.text;
                    }
                });
        } else if (key === 'loanApplication') {
            this.submitDataArr[this.keysArr.length - 1][key] = value;
        } else if ((key === 'identificationDocument1' || key === 'identificationDocument2'
            || key === 'identificationDocument1Text' || key === 'identificationDocument2Text'
            || key === 'identificationDocument1ExpiryDate' || key === 'identificationDocument2ExpiryDate'
            || key === this.documentMap.get(Constants.IdentityDocumentCategory.Document1)
            || key === this.documentMap.get(Constants.IdentityDocumentCategory.Document2)
            || key === this.documentMap.get(Constants.IdentityDocumentCategory.Address)
            || key === this.documentMap.get(Constants.IdentityDocumentCategory.StudentId))
            && this.keysArr.indexOf(key) !== -1) {
            const index = this.keysArr.indexOf(key);
            this.keysArr[index] = moment().format('YYYYMMDDHHmmss');
            this.keysArr.push(key);
            const backupSubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
            this.submitDataArr.push(backupSubmitData);
            const backupShowConfirm = JSON.parse(JSON.stringify(this.state.showConfirm));
            this.showConfirmArr.push(backupShowConfirm);
        }
    }

    /**
     * submit dataをクリーンする
     * @param remain
     */
    private cleanSubmitData(remain: number) {

        // イメージをバックアップ
        let image1;
        let image2;
        let image3;
        let image4;
        for (const item of this.submitDataArr) {
            if (item.identificationDocument1Images) {
                image1 = item.identificationDocument1Images;
            }
            if (item.identificationDocument2Images) {
                image2 = item.identificationDocument2Images;
            }
            if (item.identificationAddressImages) {
                image3 = item.identificationAddressImages;
            }
            if (item.identificationStudentImages) {
                image4 = item.identificationStudentImages;
            }
        }

        this.keysArr = this.keysArr.slice(0, remain);
        this.submitDataArr = this.submitDataArr.slice(0, remain);
        this.state.submitData = Object.assign(new CreditCardSubmitEntity(), JSON.parse(JSON.stringify(this.submitDataArr[remain - 1])));

        // バックアップしたのイメージをsubmitDataに設定
        this.state.submitData.identificationDocument1Images =
            this.state.submitData.identificationDocument1Images ? image1 : this.state.submitData.identificationDocument1Images;
        this.state.submitData.identificationDocument2Images =
            this.state.submitData.identificationDocument2Images ? image2 : this.state.submitData.identificationDocument2Images;
        this.state.submitData.identificationAddressImages =
            this.state.submitData.identificationAddressImages ? image3 : this.state.submitData.identificationAddressImages;
        this.state.submitData.identificationStudentImages =
            this.state.submitData.identificationStudentImages ? image4 : this.state.submitData.identificationStudentImages;

        this.showConfirmArr = this.showConfirmArr.slice(0, remain);
        this.state.showConfirm = JSON.parse(JSON.stringify(this.showConfirmArr[remain - 1]));
    }

    private getTopOrder() {
        return this.keysArr.length;
    }

    /**
     * 消費税を設定する
     * @param data 消費税
     */
    @ActionBind(CreditCardActionType.GET_CONSUMPTION_TAX)
    private setConsumptionTaxValue(data: any) {
        if (data) {
            this.setSubmitData('consumptionTax', data);
        }
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param data QRコード受付情報
     */
    @ActionBind(CreditCardActionType.SET_SWIPE_INFO)
    private setSwipeInfo(data: any) {
        if (data.swipeInfo) {
            this.setSubmitData('swipeCif', data.swipeInfo.branchCif);
            this.setSubmitData('swipeBranchNo', data.swipeInfo.cardBranchNo);
            this.setSubmitData('swipeAccountNo', data.swipeInfo.cardAccountNo);
            this.setSubmitData('swipeAccountType', data.swipeInfo.cardAccountType);

            this.setSubmitData('receptionBranchNo', data.swipeInfo.receptionBranchNo);
            this.setSubmitData('receptionNo', data.swipeInfo.receptionNo);
            this.setSubmitData('receptionTime', data.swipeInfo.receptionTime);
            this.setSubmitData('accountNo', data.swipeInfo.cardAccountNo);
        }

        this.state.tabletApplyId = data.tabletApplyId;
        this.setSubmitData('tabletApplyId', data.tabletApplyId);
    }

    /**
     * tabletApplyIdをstateに格納する
     * @param data
     */
    @ActionBind(CreditCardActionType.SET_TABLET_APPLY_ID)
    private setTabletApplyId(data: any) {
        this.state.tabletApplyId = data.tabletApplyId;
        this.setSubmitData('tabletApplyId', data.tabletApplyId);
    }

    /**
     * Set the item as the current time of server
     * @param data system time and the key of item
     */
    @ActionBind(CreditCardActionType.SET_SYSTEM_TIME)
    private setAsSystemTime(data: any) {
        this.setSubmitData(data.key, data.systemTime);
        this.sendSignal(CreditCardSignal.SUCCESS_SET_SYSTEM_TIME);
    }

    /**
     * get holderZipCode 郵便番号
     * @param data データ
     */
    @ActionBind(CreditCardActionType.GET_HOLDER_ZIP_CODE)
    private getHolderZipCode(data: any) {
        this.setSubmitData('firstZipCode', data.substring(0, 3));
        this.setSubmitData('lastZipCode', data.substring(3, 7));
    }

    /**
     * 親権者or勤務先の郵便番号を取得する。郵便番号スキップ時に実行される。
     * @param data データ
     */
    @ActionBind(CreditCardActionType.GET_HOLDER_ZIP_CODE_SELECTED)
    private getHolderZipCodeSelected(data: any) {
        if (data.name === 'parentalAddress') {
            this.setSubmitData('parentalFirstZipCode', data.zipCode.substring(0, 3));
            this.setSubmitData('parentalLastZipCode', data.zipCode.substring(3, 7));
        } else if (data.name === 'employmentAddress') {
            this.setSubmitData('employmentFirstZipCode', data.zipCode.substring(0, 3));
            this.setSubmitData('employmentLastZipCode', data.zipCode.substring(3, 7));
        }
    }

    /**
     * clear item from submit data
     */
    @ActionBind(CreditCardActionType.CLEAR_SUBMIT_DATA)
    private clearSubmitData(choices: any[]) {
        choices.forEach((element) => {
            this.state.submitData[element.name] = null;
        });
    }

    /**
     * Set the familyMemberNameRoma
     * @param data familyMemberNameKana
     */
    @ActionBind(CreditCardActionType.SET_FAMILY_NAME_ROMA)
    private setfamilyMemberNameRoma(data: any) {
        if (data) {
            const kanaToRomaji = new KanaToRomaji();
            this.setSubmitData('cardFamilyMemberFirstName',
                kanaToRomaji.convert(data.familyMemberFirstNameKana));
            this.setSubmitData('cardFamilyMemberLastName',
                kanaToRomaji.convert(data.familyMemberLastNameKana));
        }
    }

    /**
     * 郵便番号　default value
     */
    @ActionBind(CreditCardActionType.SET_DEFAULT_ZIP_CODE)
    private setDefaultZipCode(name: string) {
        this.setSubmitData('firstZipCode', ZipCode.FIRST_ZIP_CODE);
        this.setSubmitData('lastZipCode', ZipCode.LAST_ZIP_CODE);
    }

    /**
     * 親権者or勤務先の郵便番号に、default valueをセットする。
     */
    @ActionBind(CreditCardActionType.SET_DEFAULT_TO_SELECTED_ZIP_CODE)
    private setDefaultToSelectedZipCode(name: string) {
        if (name === 'parentalAddress') {
            this.setSubmitData('parentalFirstZipCode', ZipCode.FIRST_ZIP_CODE);
            this.setSubmitData('parentalLastZipCode', ZipCode.LAST_ZIP_CODE);
        } else if (name === 'employmentAddress') {
            this.setSubmitData('employmentFirstZipCode', ZipCode.FIRST_ZIP_CODE);
            this.setSubmitData('employmentLastZipCode', ZipCode.LAST_ZIP_CODE);
        }
    }

    /**
     * 漢字名修正フラグ
     */
    @ActionBind(CreditCardActionType.SET_ONLY_NAME_KANJI_EDIT_FLG)
    private setEditNameKanji() {
        this.setSubmitData('editNameKanji', this.state.submitData.nameNonConvert === NameNonConvert.ON);
    }

    /**
     * modify checkbox status
     * @param name the checbox item need to modify status
     */
    @ActionBind(CreditCardActionType.MODIFY_CHECKBOX_STATUS)
    private modifyCheckboxStatus(name: string) {
        this.state.checkboxStatus[name] = !this.state.checkboxStatus[name];    // ture
        this.sendSignal(CreditCardSignal.SUCCESS_MODIFY_CHECKBOX_STATUS);
    }

    /**
     * 口座開設申込内容確認画面へ戻る際modifyCheckboxStatusを呼び出す
     * @param name the checbox item need to modify status
     */
    @ActionBind(CreditCardActionType.CALL_MODIFY_CHECKBOX_STATUS)
    private callModifyCheckboxStatus(name: string) {
        if (this.state.checkboxStatus[name]) {
            this.modifyCheckboxStatus(name);
        }
    }

    /**
     * 携帯・その他電話の両方がスキップされた場合に番号入力までチャットを戻す
     */
    @ActionBind(CreditCardActionType.NEED_INPUT_PHONE_NO)
    private needInpuPhoneNumber() {
        const chats = this.state.showChats.splice(-4, 4);
        if (chats && chats.length > 0) {
            const chat = chats[0];

            this.getNextChatByAnswer({
                order: chat.order,
                pageIndex: chat.pageIndex
            });
        }

    }

   /**
    * 修正チャット終了時、編集した項目に対して編集済のフラグを立てる。
    */
    @ActionBind(CreditCardActionType.SET_EDITED_LIST)
    private setEditedList(name: string) {
        this.state.editedKeysArr = this.keysArr;
        if (!this.state.submitData.editedList) {
            this.state.submitData.editedList = {};
        }
        this.keysArr.forEach((element) => {
            this.state.submitData.editedList[element] = true;
        });
        if (this.keysArr.indexOf('career') !== -1 && this.state.submitData.isNearGraduate && name !== 'nearGraduate') {
            // "現在の職業"を修正済みにする。("ご卒業後の職業"の修正時は、修正済にならない)
            this.state.submitData.editedList.nowCareer = true;
        }
        if (this.keysArr.indexOf('career') !== -1 && this.state.submitData.isNearGraduate
            && name !== 'nowCareer' && name !== 'career') {
            // "ご卒業後の職業"を修正済みにする。("職業"・"現在の職業"の修正時は、修正済にならない)
            this.state.submitData.editedList.nearGraduate = true;
        }
    }

    /**
     * 修正チャット開始時、keysArrをクリアする。
     */
    @ActionBind(CreditCardActionType.INITIALIZE_DATA_ARR)
    private initializeDataArr() {
        this.keysArr = [];
        this.submitDataArr = [];
        this.showConfirmArr = [];
    }

    /**
     * 確認画面の表示文言を、修正チャット開始前の状態に戻す。
     */
    @ActionBind(CreditCardActionType.RESTORE_SHOW_COFIRM)
    private restoreShowConfirm(name: string) {
        let restoreValue: string;
        this.state.copyShowConfirm.forEach((item) => {
            if (item.name === name) {
                restoreValue = item.answer.text;
            }
        });
        this.state.showConfirm.forEach((item) => {
            if (item.name === name) {
                item.answer.text = restoreValue;
            }
        });
    }

    /**
     * 親権者住所をクリアする (修正チャット用)
     */
    @ActionBind(CreditCardActionType.CLEAR_PARENTAL_ADDRESS)
    private clearParentalAddress() {
        this.setSubmitData('parentalZipCode', undefined);
        this.setSubmitData('parentalAddress', undefined);
        this.setSubmitData('parentalAddressKana', undefined);
        this.setSubmitData('parentalHolderAddressPrefecture', undefined);
        this.setSubmitData('parentalHolderAddressPrefectureFuriKana', undefined);
        this.setSubmitData('parentalHolderAddressCountyUrbanVillage', undefined);
        this.setSubmitData('parentalHolderAddressCountyUrbanVillageFuriKana', undefined);
        this.setSubmitData('parentalHolderAddressStreet', undefined);
        this.setSubmitData('parentalHolderAddressStreetNameInput', undefined);
        this.setSubmitData('parentalHolderAddressStreetNameSelect', undefined);
        this.setSubmitData('parentalHolderAddressStreetNameFuriKanaSelect', undefined);
        this.setSubmitData('parentalHolderAddressStreetNameFuriKanaInput', undefined);
        this.setSubmitData('parentalHolderAddressStreetFuriKana', undefined);
        this.setSubmitData('parentalHolderAddressHouseNumber', undefined);
        this.setSubmitData('parentalHolderAddressHouseNumberFuriKana', undefined);
        this.setSubmitData('parentalFirstZipCode', undefined);
        this.setSubmitData('parentalLastZipCode', undefined);

        // クリア後のバックアップ
        const backupSubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
        this.submitDataArr[this.keysArr.length - 1] = backupSubmitData;
    }

    /**
     * 勤務先情報住所をクリアする (修正チャット用)
     */
    @ActionBind(CreditCardActionType.CLEAR_EMPLOYMENT_ADDRESS)
    private clearEmploymentAddress() {
        this.setSubmitData('employmentHolderAddressPrefecture', undefined);
        this.setSubmitData('employmentHolderAddressPrefectureFuriKana', undefined);
        this.setSubmitData('employmentHolderAddressCountyUrbanVillage', undefined);
        this.setSubmitData('employmentHolderAddressCountyUrbanVillageFuriKana', undefined);
        this.setSubmitData('employmentHolderAddressStreet', undefined);
        this.setSubmitData('employmentHolderAddressStreetNameInput', undefined);
        this.setSubmitData('employmentHolderAddressStreetNameSelect', undefined);
        this.setSubmitData('employmentHolderAddressStreetNameFuriganaSelect', undefined);
        this.setSubmitData('employmentHolderAddressStreetNameFuriganaInput', undefined);
        this.setSubmitData('employmentHolderAddressStreetNameFuriKanaSelect', undefined);
        this.setSubmitData('employmentHolderAddressStreetNameFuriKanaInput', undefined);
        this.setSubmitData('employmentHolderAddressStreetFurigana', undefined);
        this.setSubmitData('employmentHolderAddressHouseNumber', undefined);
        this.setSubmitData('employmentHolderAddressHouseNumberFurigana', undefined);
        this.setSubmitData('employmentHolderAddressHouseNumberFuriKana', undefined);
        this.setSubmitData('employmentFirstZipCode', undefined);
        this.setSubmitData('employmentLastZipCode', undefined);

        // クリア後のバックアップ
        const backupSubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
        this.submitDataArr[this.keysArr.length - 1] = backupSubmitData;
    }

    /**
     * 勤務先情報をクリアする (修正チャット用)
     * @param clearIncome 前年度税込年収をクリアするか否か
     */
    @ActionBind(CreditCardActionType.CLEAR_EMPLOYMENT_INFO)
    private clearEmploymentInfo(clearIncome: boolean) {
        if (clearIncome) {
            this.setSubmitData('taxIncludedAnnualIncomeLastYear', undefined);
        }
        this.clearEmploymentAddress();
        this.setSubmitData('jobDescription', undefined);
        this.setSubmitData('industryType', undefined);
        this.setSubmitData('industryTypeOther', undefined);
        this.setSubmitData('employmentName', undefined);
        this.setSubmitData('employmentNameKana', undefined);
        this.setSubmitData('employmentTelephoneNo', undefined);
        this.setSubmitData('employmentFirstTelephoneNo', undefined);
        this.setSubmitData('employmentSecondTelephoneNo', undefined);
        this.setSubmitData('employmentThirdTelephoneNo', undefined);
        this.setSubmitData('phoneNoExtension', undefined);
        this.setSubmitData('department', undefined);
        this.setSubmitData('positionName', undefined);
        this.setSubmitData('employeeNumber', undefined);
        this.setSubmitData('lengthOfService', undefined);
        this.setSubmitData('jobChangeTimes', undefined);

        // クリア後のバックアップ
        const backupSubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
        this.submitDataArr[this.keysArr.length - 1] = backupSubmitData;
    }

    /**
     * 親権者情報をクリアする (修正チャット用)
     */
    @ActionBind(CreditCardActionType.CLEAR_PARENTAL_INFO)
    private clearParentalInfo() {
        this.clearParentalAddress();
        this.setSubmitData('parentalLivingTogether', undefined);
        this.setSubmitData('parentalFirstName', undefined);
        this.setSubmitData('parentalLastName', undefined);
        this.setSubmitData('parentalName', undefined);
        this.setSubmitData('parentalFirstNameKana', undefined);
        this.setSubmitData('parentalFirstNameFuriKana', undefined);
        this.setSubmitData('parentalLastNameKana', undefined);
        this.setSubmitData('parentalLastNameFuriKana', undefined);
        this.setSubmitData('parentalNameKana', undefined);
        this.setSubmitData('parentalRelationship', undefined);
        this.setSubmitData('parentalBirthdate', undefined);
        this.setSubmitData('parentalHolderMobileNo', undefined);
        this.setSubmitData('parentalFirstMobileNo', undefined);
        this.setSubmitData('parentalSecondMobileNo', undefined);
        this.setSubmitData('parentalThirdMobileNo', undefined);
        this.setSubmitData('parentalHolderTelephoneNo', undefined);
        this.setSubmitData('parentalFirstTel', undefined);
        this.setSubmitData('parentalSecondTel', undefined);
        this.setSubmitData('parentalThirdTel', undefined);

        // クリア後のバックアップ
        const backupSubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
        this.submitDataArr[this.keysArr.length - 1] = backupSubmitData;
    }

    /**
     * バンクカードローン情報をクリアする (修正チャット用)
     */
    @ActionBind(CreditCardActionType.CLEAR_BC_LOAN_INFO)
    private clearBcLoanInfo() {
        this.setSubmitData('loanApplication', '0');
        this.setSubmitData('isHaveUnsecuredLoan', undefined);
        this.setSubmitData('overdraftLimit', undefined);

        // クリア後のバックアップ
        const backupSubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
        this.submitDataArr[this.keysArr.length - 1] = backupSubmitData;
    }

    /**
     * 学校情報をクリアする (修正チャット用)
     */
    @ActionBind(CreditCardActionType.CLEAR_SCHOOL_INFO)
    private clearShoolInfo() {
        this.setSubmitData('schoolName', undefined);
        this.setSubmitData('schoolNameKana', undefined);
        this.setSubmitData('graduateDate', undefined);

        // クリア後のバックアップ
        const backupSubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
        this.submitDataArr[this.keysArr.length - 1] = backupSubmitData;
    }

    @ActionBind(CreditCardActionType.BC_APPLY_CHECK)
    private bcApplyCheck(result: any) {
        let tmpAcceptionResult: AcceptionResult;
        let allAcceptionResult: AcceptionResult[] = new Array();
        const initAcceptionResult: AcceptionResult[] = new Array();

        tmpAcceptionResult = result.data;
        allAcceptionResult = this.state.submitData.bcHoldingStatusAllCustomer;
        if (allAcceptionResult === undefined) {
            initAcceptionResult.push(tmpAcceptionResult);
            this.setStateSubmitDataValuesSpecial([{
                key: 'bcHoldingStatusAllCustomer',
                value: initAcceptionResult
            }]);
        } else {
            allAcceptionResult.push(tmpAcceptionResult);
            this.setStateSubmitDataValuesSpecial([{
                key: 'bcHoldingStatusAllCustomer',
                value: allAcceptionResult
            }]);
        }

        this.sendSignal(CreditCardSignal.BC_APPLY, this.state.submitData.bcHoldingStatusAllCustomer);

    }

    private setStateSubmitDataValuesSpecial(datas: Array<{ key: string, value: any }>) {
        if (datas && datas.length > 0) {
            datas.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    /**
     * 本人確認書類画像を保存
     */
    @ActionBind(CreditCardActionType.SAVE_DOCUMENT_IMAGE)
    private saveIdentityDocumentImage(document: any) {
        const { image, category } = document;
        const submitKey = this.documentMap.get(category);
        this.setSubmitData(
            submitKey,
            this.state.submitData[submitKey] ?
                [...this.state.submitData[submitKey], image] : [image]
        );
    }

    @ActionBind(CreditCardActionType.SET_IDENTIFICATION_DOCUMENT)
    private setIdentificationDocument(data) {
        const { submitData } = data;
        this.state.submitData = submitData;
    }

    /**
     * 本人確認書類画像をクリア
     */
    @ActionBind(CreditCardActionType.CLEAN_DOCUMENT_IMAGE)
    private cleanIdentityDocumentImage(category: Constants.IdentityDocumentCategory) {
        const submitKey = this.documentMap.get(category);
        this.setSubmitData(submitKey, null);
    }

    @ActionBind(CreditCardActionType.SET_STATE_SUBMIT_DATA_VALUE_FOR_CHECK_APPLY)
    private setStateSubmitDataValuesforCheckApply(datas: Array<{ key: string, value: string }>) {
        if (datas && datas.length > 0) {
            datas.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    @ActionBind(CreditCardActionType.SET_SUBMIT_DATA)
    private editSubmitData(data: { index, key, val }) {
        if (data.key) {
            // indexが存在するとき、配列のフィールドに値を入れる。
            // indexが存在しないとき、配列ではないフィールドに値を入れる
            (data.index !== undefined && data.index !== null) ?
                this.state.submitData[data.key][data.index] = data.val :
                this.state.submitData[data.key] = data.val;
        }
    }

    private setDocumentMap() {
        this.documentMap = new Map<number, string>();
        this.documentMap.set(Constants.IdentityDocumentCategory.Document1, 'identificationDocument1Images');
        this.documentMap.set(Constants.IdentityDocumentCategory.Document2, 'identificationDocument2Images');
        this.documentMap.set(Constants.IdentityDocumentCategory.Address, 'identificationAddressImages');
        this.documentMap.set(Constants.IdentityDocumentCategory.StudentId, 'identificationStudentImages');
    }

    @ActionBind(CreditCardActionType.UPDATA_SUBMIT_DATA_BACKUP)
    private updateSubmitDataBackup(datas: Array<{ key: string, value: string }>) {
        if (datas && datas.length > 0) {
            datas.forEach((item) => {
                this.state.confirmPageChanges[item.key] = item.value;
            });
        }
    }

    /**
     * 行員認証情報をサブミットする
     *
     * @param data データ
     */
    @ActionBind(CreditCardActionType.CREDITCARD_INFO_INSERT)
    private creditCardInfoInsert(data) {
        this.sendSignal(CreditCardSignal.SUCCESS_INSERT_INFO, data);
    }

    @ActionBind(CreditCardActionType.SET_STATE_DATA_FOR_CONFIRM)
    private setStateData(data) {
        this.state.submitData = Object.assign(new CreditCardSubmitEntity(), data.submitData);
    }

    /**
     * 文字チェック。
     */
    @ActionBind(CreditCardActionType.CHARACTER_CHECK)
    private characteCheck(data: any) {
        this.sendSignal(CreditCardSignal.CHARACTER_CHECK);
    }

    private resetIdentificationDocument(order, pageIndex) {
        const chat = this.state.questions[pageIndex].find((item) => item.order === order);
        // 本人確認書類が「住民票の写し（原本）」を選択された場合、「記載あり」→「記載なし」変更された時に、本人確認書類が「null」になることを対応
        if (chat && /@\S+にマイナンバーは記載されていますか？/.test(chat.question)) {
            const name = 'identificationDocument' + chat.question.replace(/@\S+(\d{1})\S+/, '$1');
            const filter = this.state.showChats.filter((show) => show.name === name);
            if (filter && filter.length > 0) {
                const answer = filter[filter.length - 1].answer;
                answer.value.forEach((element) => {
                    this.setSubmitData(element.key, element.value);
                });
                this.setSubmitData(name + 'Text', answer.text);
            }
        }
    }

    /**
     * SUBMITDATA_ARRをバックアップする
     */
    @ActionBind(CreditCardActionType.BACKUP_SUBMITDATA_ARR)
    private backupSubmitDataArr() {
        Object.assign(this.keysArrBak, this.keysArr);
        Object.assign(this.submitDataArrBak, this.submitDataArr);
        Object.assign(this.showConfirmArrBak, this.showConfirmArr);
    }

    /**
     * SUBMITDATA_ARRをクリアする
     */
    @ActionBind(CreditCardActionType.CLEAR_CONFIRMPAGE_INFO)
    private clearConfirmPageInfo() {
        this.keysArr = [];
        this.submitDataArr = [];
        this.showConfirmArr = [];
        Object.assign(this.keysArr, this.keysArrBak);
        Object.assign(this.submitDataArr, this.submitDataArrBak);
        Object.assign(this.showConfirmArr, this.showConfirmArrBak);
        this.keysArrBak = [];
        this.submitDataArrBak = [];
        this.showConfirmArrBak = [];

        // 本人確認書類１の名称、画像、書類コード、有効期限
        this.setSubmitData('identificationDocument1', undefined);
        this.setSubmitData('identificationDocument1Images', undefined);
        this.setSubmitData('identificationDocument1ExpiryDate', undefined);
        this.setSubmitData('identificationDocument1ExpiryDateText', undefined);
        this.setSubmitData('identificationDocument1Text', undefined);
        this.setSubmitData('documentListName', undefined);
        // 本人確認書類２の名称、画像、書類コード、有効期限
        this.setSubmitData('identificationDocument2', undefined);
        this.setSubmitData('identificationDocument2Images', undefined);
        this.setSubmitData('identificationDocument2ExpiryDate', undefined);
        this.setSubmitData('identificationDocument2ExpiryDateText', undefined);
        this.setSubmitData('identificationDocument2Text', undefined);
        this.setSubmitData('documentListName2', undefined);
        // 免許証番号
        this.setSubmitData('identificationDocumentLicenseNo', undefined);
        // 現住所確認書類の名称、画像、有効期限
        this.setSubmitData('addressConfirmationDocumentName', undefined);
        this.setSubmitData('identificationAddressImages', undefined);
        this.setSubmitData('identificationAddressExpiryDate', undefined);
        this.setSubmitData('identificationAddressExpiryDateText', undefined);
        // 学生証
        this.setSubmitData('identificationStudentImages', undefined);
        // 連絡事項
        this.setSubmitData('contactNote', undefined);
    }

    /**
     * マスキング未確認データから確認済の写真を削除する
     *
     * @private
     * @param {*} data
     * @memberof SavingsStore
     */
    @ActionBind(CreditCardActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES)
    private removeNotMaskingConfirmImages(data: any) {
        const {documentName, index} = data;
        // indexパラメータが存在する時に、documentNameの属性が配列と認識して
        if (index !== undefined) {
            this.state.notMaskingConfirmImages[documentName].splice(index, 1);
        } else if (this.state.notMaskingConfirmImages[documentName] !== undefined
            && typeof this.state.notMaskingConfirmImages[documentName] === 'boolean') {
            // documentNameの属性は存在かつbooleanの場合、値をfalseにする
            this.state.notMaskingConfirmImages[documentName] = false;
        }
    }

    @ActionBind(CreditCardActionType.RESET_NOT_MASKING_CONFIRM_IMAGES)
    private resetNotMaskingConfirmImages(type: ClearSavingImagesClickRecordType) {
        const _documentResetFn = (documentName: string) => {
            // 書類の保存タイプはboolean
            if (typeof this.state.notMaskingConfirmImages[documentName] === 'boolean') {
                this.state.notMaskingConfirmImages[documentName] = false;

                if (this.state.submitData[documentName]) {
                    this.state.notMaskingConfirmImages[documentName] = true;
                }
            } else {
                // 書類の保存タイプは配列
                this.state.notMaskingConfirmImages[documentName] = [];

                if (this.state.submitData[documentName]) {
                    this.state.submitData[documentName].forEach(
                        (item, index) => {
                            this.state.notMaskingConfirmImages[documentName].push(index);
                        }
                    );
                }
            }
        };

        switch (type) {
            case ClearSavingImagesClickRecordType.DOCUMENT:
                // 既存写真によって、マスキング未確認データをリセット
                Object.keys(this.state.notMaskingConfirmImages).forEach(
                    (atrribute) => {
                        _documentResetFn(atrribute);
                    }
                );
                break;
            case ClearSavingImagesClickRecordType.CLEAR:
                // 本人確認書類１、本人確認書類２、住所確認書類をクリア
                Object.keys(this.state.notMaskingConfirmImages).forEach(
                    (atrribute) => {
                        this.state.notMaskingConfirmImages[atrribute] =
                            typeof this.state.notMaskingConfirmImages[atrribute] === 'boolean' ? false : [];
                    }
                );
                break;
            default:
                break;
        }
    }

    /**
     * BC複合取引の場合、本人確認書類聴取前のsubmitDataをバックアップ
     */
    @ActionBind(CreditCardActionType.BACKUP_ORIGIN_SUBMITDATA)
    private backupOriginSubmitData() {
        this.state.originSubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
    }

    /**
     * BC複合取引の場合、バックアップした運転免許証番号、学生証、連絡事項をクリア
     */
    @ActionBind(CreditCardActionType.CLEAR_COPY_COMPLEX_TRANS_CONFIRM_INFOS)
    private clearCopyComplexTransConfirmInfos() {
        this.state.copyComplexTransConfirmInfos = null;
        this.state.submitData.bakupNotMaskingConfirmImages = undefined;
    }

    /**
     * BC複合取引の場合、運転免許証番号、学生証、連絡事項をバックアップ
     */
    @ActionBind(CreditCardActionType.BACKUP_COMPLEX_TRANS_CONFIRM_INFOS)
    private backupComplexTransConfirmInfos() {
        this.state.copyComplexTransConfirmInfos = {
            contactNote: undefined,  // 連絡事項
            identificationStudentImages: undefined,  // 学生証
            identificationDocumentLicenseNo: undefined  // 運転免許証番号
        };
        this.state.copyComplexTransConfirmInfos.contactNote = this.state.submitData.contactNote;
        this.state.copyComplexTransConfirmInfos.identificationStudentImages = this.state.submitData.identificationStudentImages;
        this.state.copyComplexTransConfirmInfos.identificationDocumentLicenseNo = this.state.submitData.identificationDocumentLicenseNo;
    }

    /**
     * BC複合取引にて
     * 一度口座開設行員確認画面に「戻る」した場合
     * submitData配下の未マスキング完了オブジェクトのバックアップから復元
     */
    @ActionBind(CreditCardActionType.RESTORE_BACKUP_NOT_MASKING_CONFIRM_IMAGES)
    private restoreBackupNotMaskingConfirmImages() {
        this.state.notMaskingConfirmImages = this.state.submitData.bakupNotMaskingConfirmImages;
    }
}
