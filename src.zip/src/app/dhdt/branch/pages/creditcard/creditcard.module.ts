import { NgModule, Type } from '@angular/core';
import { HttpModule } from '@angular/http';
import { LoginModule } from 'dhdt/branch/pages/common/login/login.module';
import { TopModule } from 'dhdt/branch/pages/common/top/top.module';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardChatComponent } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat.component';
import { CreditCardConfirmPageChatComponent } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-confirmpage-chat.component';
import { BackupDataService } from 'dhdt/branch/pages/creditcard/service/backup-data.service';
import { CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { CreditCardConfirmJcbComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-confirm-jcb.component';
import { CreditCardConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-confirm.component';
import { CreditCardInitConfirmJcbComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-initconfirm-jcb.component';
import { CreditCardInitConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-initconfirm.component';
import { AccountShopModule } from 'dhdt/branch/shared/components/account-shop/account-shop.module';
import { AddressModule } from 'dhdt/branch/shared/components/address/address.module';
import { BcAccountShopModule } from 'dhdt/branch/shared/components/bc-account-shop/bc-account-shop.module';
import { ConfirmPageCommonModule } from 'dhdt/branch/shared/components/confirmpage-common/confirmpage.common.module';
import { ModalPasswordModule } from 'dhdt/branch/shared/components/modal/modal-password/modal-password.module';
import { PickerModule } from 'dhdt/branch/shared/components/picker/picker.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';

export const SHARED_FORM_COMPONENT: Array<Type<any>> = [
    CreditCardConfirmComponent,
    CreditCardInitConfirmComponent,
    CreditCardInitConfirmJcbComponent,
    CreditCardConfirmJcbComponent
];

@NgModule({
    imports: [
        LoginModule,
        TopModule,
        IonicModule,
        SharedModule,
        AddressModule,
        AccountShopModule,
        BcAccountShopModule,
        HttpModule,
        PickerModule,
        ConfirmPageCommonModule,
        ModalPasswordModule
    ],
    declarations: [
        SHARED_FORM_COMPONENT,
        CreditCardChatComponent,
        CreditCardConfirmPageChatComponent
    ],
    exports: [
        SHARED_FORM_COMPONENT,
        TopModule,
        CreditCardChatComponent,
        CreditCardConfirmPageChatComponent
    ],
    entryComponents: [
        SHARED_FORM_COMPONENT,
        CreditCardChatComponent,
        CreditCardConfirmPageChatComponent
    ],
    providers: [
        CreditCardAction,
        CreditCardStore,
        BackupDataService
    ]
})
export class CreditCardModule {
}
