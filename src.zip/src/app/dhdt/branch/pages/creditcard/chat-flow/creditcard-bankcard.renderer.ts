import { ViewContainerRef } from '@angular/core';
import {
    AccountType, ApplyBC, ApplyBizCategory, COMMON_CONSTANTS, JudgeResultStatus, TEMPLATE_FILE
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CreditCardChatFlowAccessor } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.accessor';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import {
    BankCardType, Career, CreditCardConsts, FamilyMemberAgeRange, IsBankCardLoan, MaxLength, OverdraftLimit
} from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardQuestionsModel } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { CreditCardInitConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-initconfirm.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { ModalPdfScrollCheckComponent } from 'dhdt/branch/shared/components/modal/modal-pdf/modal-pdf-scroll-check.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { PrintNameInputComponent } from 'dhdt/branch/shared/components/print-name-input/print-name-input.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { ModalController, NavController } from 'ionic-angular';

export class CreditCardBankCardRenderer extends CreditCardChatFlowRenderer {
    public processType = 1;
    private state: CreditCardState;

    constructor(
        private chatFlowAccessor: CreditCardChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: CreditCardStore,
        private modalService: ModalService,
        private audioService: AudioService,
        private modalCtrl: ModalController,
        private navCtrl: NavController,
    ) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
    }

    /**
     * YMLファイル読み込み
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(TEMPLATE_FILE.CREDIT_CARD_BANK_CARD, pageIndex);
    }

    /**
     * タイプにより、各コンポーネントをレンダリング
     * @param question ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public rendererComponents(question: CreditCardQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_DATE_PICKER: {
                this.onPicker(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_PRINTNAME: {
                this.onPrintName(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_TWOCOLS_BUTTON:
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON: {
                this.onButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4: {
                this.onPasswordInput(question, pageIndex);
                break;
            }
            case 'setPasswordForBcCashCard': {
                this.saveBcCashCardPassword(question, pageIndex);
                break;
            }
        }
    }

    /**
     * 選択内容を表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const bcOnSuica = /43|63/;
        const ageCode = /1|2|4/;
        let judgeResult: string;

        if (entity.choices) {
            if (entity.name === 'isSuicaOn') {
                judgeResult = this.state.submitData.cardType.match(bcOnSuica) ? '01' : '02';
                this.nextChatByJudge(entity, pageIndex, judgeResult);
            } else if (entity.name === 'isCanApplyBcLoan') {
                judgeResult = this.state.submitData.career === Career.HOUSEWIFE || this.state.submitData.career === Career.STUDENT ||
                    this.state.submitData.ageClassification.match(ageCode) ? '02' : '01';
                if (judgeResult === '02') {
                    this._action.setStateSubmitDataValue({
                        name: 'loanApplication',
                        value: IsBankCardLoan.IS_NOT_APPLY
                    });
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
            } else if (entity.name === 'isApplyGold') {
                if (this.state.submitData.cardType === BankCardType.BC_GOLD
                    || this.state.submitData.cardType === BankCardType.BC_GOLD_SUICA) {
                    this._action.setStateSubmitDataValue({
                        name: 'overdraftLimit',
                        value: OverdraftLimit.OVERDRAFT_LIMIT_50
                    });
                    judgeResult = '02';
                } else {
                    judgeResult = '01';
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
            } else if (entity.name === 'ifApplyBC') {
                judgeResult = JudgeResultStatus.RESULT_0;
                if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
                    judgeResult = JudgeResultStatus.RESULT_1;
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
            } else {
                entity.choices.forEach((choice) => {
                    if (this.state.submitData[entity.name] === choice.value) {
                        this.getNextChat(choice.next, pageIndex);
                        return;
                    }
                });
            }
        }
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getCreditCardDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        this.getNextChat(entity.next, pageIndex);
                    });
                }
            });
    }

    /**
     * カード券面を入力する
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onPrintName(entity: CreditCardQuestionsModel, pageIndex: number): void {
        // familyMemberNameRomaのplace holderセット
        if (entity.name === 'familyMemberNameRoma') {
            if (!this.state.submitData.cardFamilyMemberFirstName) {
                const params = {
                    familyMemberFirstNameKana: this.state.submitData.familyMemberFirstNameKana,
                    familyMemberLastNameKana: this.state.submitData.familyMemberLastNameKana
                };
                this._action.setfamilyMemberNameRoma(params);
            }
        }

        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getCreditCardDefaultValues(entity.name, this.state.submitData),
            maxLength: MaxLength.MAX_LENGTH_18,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PrintNameInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * Pickerコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onPicker(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            validationRules: entity.validationRules,
            submitData: this.state.submitData,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);

                if (InputUtils.validateAge(answer.value[0].value, 18, this.state.submitData.customerApplyStartDate)) {
                    // 満18歳の場合、家族会員の申し込むフローを続ける。
                    const params = {
                        memberAgeFlg: FamilyMemberAgeRange.ABOVE_18,
                        familyCard: CreditCardConsts.FamilyCardApply.Apply
                    };
                    this._action.setMemberAgeFlg(params);
                } else {
                    // 18歳未満の場合、家族会員の申し込むが中止になって、支払方法フローへ進める。
                    const params = {
                        memberAgeFlg: FamilyMemberAgeRange.BELOW_18,
                        familyCard: CreditCardConsts.FamilyCardApply.NotApply
                    };
                    this._action.setMemberAgeFlg(params);
                }

                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        // ボタンオプション設定（カラム、タイトルなど）
        let options: any;
        switch (entity.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON: {
                options = { maxColNum: 3 };
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_TWOCOLS_BUTTON: {
                options = { maxColNum: 2 };
                break;
            }
            default: {
                options = { title: entity.options ? entity.options.title : undefined };
                break;
            }
        }

        const logInfo = {
            screenName: this._store.getState().currentFileInfo.screenId,
            yamlId: this._store.getState().currentFileInfo.yamlId,
            yamlOrder: entity.order
        };
        Object.defineProperty(options, COMMON_CONSTANTS.TYPE_LOGINFO, { value: logInfo });

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
            .subscribe((answer) => {
                if (entity.name.length > 0 && answer.value.length > 0) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }

                if (entity.name === 'isHaveUnsecuredLoan' && answer.text === IsBankCardLoan.YES) {
                    this._action.setStateSubmitDataValue({
                        name: 'loanApplication',
                        value: IsBankCardLoan.IS_NOT_APPLY
                    });
                }

                if (answer.action.type.length > 0) {
                    this.configAction(answer);
                } else if (answer.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.next, pageIndex);
                }
            });
    }

    /**
     * パスワード入力コンポーネントを表示する
     * @param entity
     * @param pageIndex
     */
    public onPasswordInput(entity: CreditCardQuestionsModel, pageIndex: number) {
        // 暗証番号エラーチェックのため、業務区分により電話番号リストを設定
        const telephone = [];
        // 純新規日本人と純新規外国人の場合
        if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT
            || this.state.submitData.applyBizCategory === ApplyBizCategory.FOREIGN_NATIONALITY) {
            telephone.push(this.state.submitData.holderMobileNo);
            telephone.push(this.state.submitData.holderTelephoneNo);
        } else if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
            // 既存新規
            // 電話番号変更ありの場合
            if (this.state.submitData.existingChangeFirstMobileNo || this.state.submitData.existingChangeFirstTel) {
                telephone.push(this.state.submitData.existingChangeHolderMobileNo);
                telephone.push(this.state.submitData.existingChangeHolderTelephoneNo);
            } else {
                // 電話番号変更なしの場合
                telephone.push(this.state.submitData.holderTelNo1);
                telephone.push(this.state.submitData.holderTelNo2);
                telephone.push(this.state.submitData.holderTelNo3);
            }
        } else {
            // BC単体の場合
            telephone.push(this.state.submitData.holderTelNo1);
            telephone.push(this.state.submitData.holderTelNo2);
            telephone.push(this.state.submitData.holderTelNo3);
        }
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            birthday: this.state.submitData.birthdate,
            birthdayText: this.state.submitData.birthdateWithAge,
            telephone: telephone,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PasswordInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * BC複合の場合、CDキャッシュカード暗証番号をBCキャッシュカードに設定する
     * @param entity
     * @param pageIndex
     */
    public saveBcCashCardPassword(entity: CreditCardQuestionsModel, pageIndex: number): void {
        this._action.setStateSubmitDataValue({
            name: 'cashCardFirstPwd4bits',
            value: this.state.submitData.firstPwd4bits
        });
        this.getNextChat(entity.next, pageIndex);
    }

    private configAction(choice: any) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            this.modalService.showModal(action.value, { imgSrc: action.imgSrc, cssClass: 'settings-modal-h805' });
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            this.chatFlowCompelete();
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this._action.chatFlowCompelete(action.value);
        }
    }

    /**
     * typeがjudgeの際に、分岐しして次のチャットを開始させる
     *
     * @param entity
     * @param pageIndex
     * @param judgeResult
     */
    private nextChatByJudge(entity: CreditCardQuestionsModel, pageIndex: number, judgeResult: string) {
        entity.choices.forEach((choice) => {
            if (choice.value === judgeResult) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }

    private showModal() {
        const modal = this.modalCtrl.create(
            ModalPdfScrollCheckComponent,
            { imgSrc: this._labels.creditcard.bankcard.allThreeImgBank },
            { cssClass: 'settings-modal-bank-card-all' }
        );
        modal.onDidDismiss(() => {
            this.navCtrl.setRoot(CreditCardInitConfirmComponent);
        });
        modal.present();
    }

}
