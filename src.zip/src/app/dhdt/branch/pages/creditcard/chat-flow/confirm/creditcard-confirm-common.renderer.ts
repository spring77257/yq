import { ViewContainerRef } from '@angular/core';
import { InjectionUtils, ObjectUtils } from 'adep/utils';
import {
    AccountType, Age, AgeClassification, ApplyBizCategory, ChatOption, COMMON_CONSTANTS, TEMPLATE_FILE
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardChatFlowAccessor } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.accessor';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import {
    BankCardType, Career, CreditCardConsts, CreditInputPattern, Gender, HouseActureType, HouseOwnType,
    IsBankCardLoan, IsMarried, IsNearGraduate, IsParentalLivingTogether, JobPattern, LivingExpenses, MaxLength, OverdraftLimit
} from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardQuestionsModel, CreditCardSubmitEntity } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/creditcard/service/backup-data.service';
import { CreditCardSignal, CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { SelectAddressCommonComponent } from 'dhdt/branch/shared/components/address/view/select-address-common.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { MultiButtonGroupComponent } from 'dhdt/branch/shared/components/multi-button-group/multi-button-group.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { PrintNameInputComponent } from 'dhdt/branch/shared/components/print-name-input/print-name-input.component';
import { QuantityInputComponent } from 'dhdt/branch/shared/components/quantity-input/quantity-input.component';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { CreditCardUtil } from 'dhdt/branch/shared/utils/creditcard-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';
import { Observable } from 'rxjs';

/**
 * 申込情報確認画面の修正チャット
 */
export class CreditCardConfirmCommonRenderer extends CreditCardChatFlowRenderer {
    public processType = 1;
    private state: CreditCardState;

    private phoneIsSkipped: boolean = false;
    private tellIsSkipped: boolean = false;
    private jobEdited: boolean = false;

    constructor(
        private chatFlowAccessor: CreditCardChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: CreditCardStore,
        private modalService: ModalService,
        private creditCardUtil: CreditCardUtil,
        private loginStore: LoginStore
    ) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
    }

    /**
     * YMLファイル読み込み
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(TEMPLATE_FILE.CREDIT_CARD_CONFIRMPAGE_COMMON, pageIndex);
    }

    /**
     * タイプにより、各コンポーネントをレンダリング
     * @param question ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public rendererComponents(question: CreditCardQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_YEARMONTH_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_PREFECTURE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_COUNTYURBANVILLAGE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_RESIDENCE_YEAR_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_DATE_PICKER: {
                this.onPicker(question, pageIndex);
                break;
            }

            case COMMON_CONSTANTS.ELEMENT_TYPE_TWOCOLS_BUTTON:
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON: {
                this.onButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE: {
                this.configUrl(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECTADDRESS: {
                this.onSelectAddress(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECTSTREET: {
                this.onSelectStreet(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_PRINTNAME: {
                this.onPrintName(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4: {
                this.onPasswordInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_NUMBER_THOUSAND:
            case COMMON_CONSTANTS.ELEMENT_TYPE_NUMBER_PEOPLE:
            case COMMON_CONSTANTS.ELEMENT_TYPE_DEPOSIT_TENTHOUSAND: {
                this.onQuantityInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE_DOUBLE: {
                this.onJudgeDouble(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_MULTI_BUTTON: {
                this.onMulitButton(question, pageIndex);
                break;
            }
        }
    }

    /**
     * チャットフロー・修正チャットでJudge結果が異なるかを検証する。判定にはonJudgeメソッドを流用。
     * 結果に応じて個別処理を実施する。
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudgeDouble(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const judgeResultBefore = this.getJudgeResultFromSubmitData(this.state.copySubmitData, entity, pageIndex);
        let judgeResultEdited = this.getJudgeResultFromSubmitData(this.state.submitData, entity, pageIndex);
        // let nextOrder: number;
        switch (entity.name) {
            // 親権者同居有無
            case 'parentalLivingTogetherJudge': {
                judgeResultEdited = this.judgeParentalLivingTogether(judgeResultBefore, judgeResultEdited);
                break;
            }
            // お住い種類
            case 'houseTypeJudge': {
                judgeResultEdited = this.judgeHouseType(judgeResultBefore, judgeResultEdited);
                break;
            }
            // 職業選択前のダブルジャージ
            case 'studentCheckJudge': {
                judgeResultEdited = this.judgeStudentCheck(judgeResultBefore, judgeResultEdited);
                break;
            }
            // 職業選択のダブルジャージ
            case 'careerCheckJudge': {
                judgeResultEdited = this.judgeCareerCheck(judgeResultBefore, judgeResultEdited);
                break;
            }
            // 卒業年月のダブルジャージ
            case 'graduateDateJudge': {
                judgeResultEdited = this.judgeGraduateDate(judgeResultBefore, judgeResultEdited);
                break;
            }
            // バンクカードローン申し込めるかのダブルジャージ
            case 'isCanApplyBcLoanJudge': {
                judgeResultEdited = this.judgeIsCanApplyBcLoanJudge(judgeResultBefore, judgeResultEdited);
                break;
            }
        }
        this.getNextChatByJudge(judgeResultEdited, entity, pageIndex);
    }

    /**
     * バンクカードローン申し込めるかのダブルジャージ
     * @param judgeResultBefore 一般チャットからの元データ
     * @param judgeResultEdited 修正チャット後の変更値
     * 戻り値：分岐ORDER
     */
    public judgeIsCanApplyBcLoanJudge(judgeResultBefore: string, judgeResultEdited: string): string {
        // 修正前後同じの場合、チャット終了へ、01: 申込可、02: 申込不可
        if (judgeResultBefore === judgeResultEdited) {
            judgeResultEdited = '02';
            // 職業が[主婦][学生]または年齢が20歳未満または66歳以上→その他以外の場合、バンクカードローンの申し込みへ
        } else if (judgeResultBefore === '02' && judgeResultEdited === '01') {
            judgeResultEdited = '01';
            // その他以外の場合→職業が[主婦][学生]または年齢が20歳未満または66歳以上の場合、バンクカードローンの申し込みなし、希望貸越枠削除、チャット終了へ
        } else if (judgeResultBefore === '01' && judgeResultEdited === '02') {
            // 希望貸越枠削除
            this._action.clearBcLoanInfo();
            judgeResultEdited = '02';
        }
        return judgeResultEdited;
    }

    /**
     * 卒業年月のダブルジャージ
     * @param judgeResultBefore 一般チャットからの元データ
     * @param judgeResultEdited 修正チャット後の変更値
     * 戻り値：分岐ORDER
     */
    public judgeGraduateDate(judgeResultBefore: string, judgeResultEdited: string): string {
        // 01:卒業90日以内,  02:卒業90日以上
        if (this.state.submitData.gender === Gender.FEMALE && this.state.copySubmitData.married === IsMarried.MARRIED
            && this.state.submitData.married === IsMarried.UN_MARRIED && judgeResultEdited === '01') {
            // 既婚→独身で卒業90日以内の時、独身主婦となるのを回避。
            this._action.clearShoolInfo();
            this._action.setStateSubmitDataValue({ name: 'isNearGraduate', value: IsNearGraduate.YES });
        } else if (this.jobEdited && !judgeResultBefore && judgeResultEdited === '01') {
            this._action.clearShoolInfo();
            this._action.setStateSubmitDataValue({ name: 'career', value: this.state.copySubmitData.career });
            this._action.restoreShowConfirm('career');
            this._action.setStateSubmitDataValue({ name: 'isNearGraduate', value: IsNearGraduate.YES });
            judgeResultEdited = '02';
        } else if (this.jobEdited && !judgeResultBefore && judgeResultEdited === '02') {
            this._action.clearEmploymentInfo(true);
        } else if (judgeResultBefore === '02' && judgeResultEdited === '01') {
            this._action.clearShoolInfo();
        }
        return judgeResultEdited;
    }

    /**
     * 職業選択のダブルジャージ
     * @param judgeResultBefore 一般チャットからの元データ
     * @param judgeResultEdited 修正チャット後の変更値
     * 戻り値：分岐ORDER
     */
    public judgeCareerCheck(judgeResultBefore: string, judgeResultEdited: string): string {
        // 00:学生, 01:働いていない,  02:働いている
        // その他の場合→[年金受給者]or[主婦]or[無職]、勤務先情報削除(年収消さない)、親権者情報入力へ
        if (judgeResultBefore === '02' && judgeResultEdited === '01') {
            // 前年度年収へ
            this._action.clearEmploymentInfo(false);
            judgeResultEdited = '100';
            // [年金受給者]or[主婦]or[無職]→その以外の場合、勤務先情報入力へ
        } else if (judgeResultBefore === '01' && judgeResultEdited === '02') {
            judgeResultEdited = '02';
            // 同じの場合、チャット終了
        } else if (judgeResultBefore === judgeResultEdited) {
            judgeResultEdited = '100';
        }
        return judgeResultEdited;
    }

    /**
     * 職業選択前のダブルジャージ
     * @param judgeResultBefore 一般チャットからの元データ
     * @param judgeResultEdited 修正チャット後の変更値
     * 戻り値：分岐ORDER
     */
    public judgeStudentCheck(judgeResultBefore: string, judgeResultEdited: string): string {
        // 1:学生, 2:学生ではない
        judgeResultBefore = judgeResultBefore === Career.STUDENT ? '1' : '2';
        judgeResultEdited = judgeResultEdited === Career.STUDENT ? '1' : '2';
        // 学生以外→学生 学校情報入力へ
        if (judgeResultBefore === '2' && judgeResultEdited === '1') {
            // next: 7-42, 学校名入力
            judgeResultEdited = '1';
            // 学生→学生ではない 学校情報クリア、職業チェックへ
        } else if (judgeResultBefore === '1' && judgeResultEdited === '2') {
            // 学校情報クリア
            this._action.clearShoolInfo();
            // 職業チェックへ
            judgeResultEdited = '2';
            // 学生→学生 チャット終了
        } else if (judgeResultBefore === '1' && judgeResultEdited === '1') {
            // next: チャット終了
            judgeResultEdited = '100';
            // 学生以外→学生以外 職業チェックへ
        } else if (judgeResultBefore === '2' && judgeResultEdited === '2') {
            // 職業チェックへ
            judgeResultEdited = '2';
        }
        return judgeResultEdited;
    }

    /**
     * 卒業年月を申込日起算で90日勘定
     * @param graduateDate 卒業年月（YYYYMMDD)
     */
    public getGraduateDatePeriod(graduateDate: any): any {
        const customerApplyDate = this.state.submitData.customerApplyStartDate;
        let remainingPeriod = -1;
        if (graduateDate) {
            const graduateDateTo = new Date(
                graduateDate.substr(0, 4) + '/' + graduateDate.substr(4, 2) + '/' + graduateDate.substr(6, 2));
            const customerApplyDatefrom = new Date(customerApplyDate);
            const ms = graduateDateTo.getTime() - customerApplyDatefrom.getTime();
            remainingPeriod = Math.floor(ms / (1000 * 60 * 60 * 24));
        }
        return remainingPeriod;
    }

    /**
     * 親権者同居有無分岐処理
     * @param judgeResultBefore 一般チャットからの元データ
     * @param judgeResultEdited 修正チャット後の変更値
     * 戻り値：分岐ORDER
     */
    public judgeParentalLivingTogether(judgeResultBefore: string, judgeResultEdited: string): string {
        // 同居有無:あり→なしに変更パターン　全クリア後、親権者住所全般を追加。
        if (judgeResultBefore === '1' && judgeResultEdited === '0') {
            this._action.clearParentalAddress();
            judgeResultEdited = '0';
            // 同居有無:なし→ありに変更パターン　全クリア後、親権者住所に、名義人の住所を代入する。即チャット終了。
        } else if (judgeResultBefore === '0' && judgeResultEdited === '1') {
            this._action.clearParentalAddress();
            this._action.setStateSubmitDataValue({
                name: 'parentalZipCode',
                value: this.state.submitData.firstZipCode ?
                    this.state.submitData.firstZipCode + '-' + this.state.submitData.lastZipCode : this.state.submitData.zipCode
            });
            this._action.setStateSubmitDataValue({ name: 'parentalAddress', value: this.state.submitData.address });
            this._action.setStateSubmitDataValue({ name: 'parentalAddressKana', value: this.state.submitData.addressKana });
            judgeResultEdited = '100';
            // 同居有無:前後で変更なしのパターン チャット終了
        } else if (judgeResultBefore === judgeResultEdited) {
            judgeResultEdited = '100';
        }
        return judgeResultEdited;
    }

    /**
     * お住い種類分岐処理
     * @param judgeResultBefore
     * @param judgeResultEdited
     * 戻り値：分岐ORDER
     */
    public judgeHouseType(judgeResultBefore: string, judgeResultEdited: string): string {
        // 01:所有 (自己所有,家族所有)  02:賃貸(社宅・寮,借家,アパート,公団・公営,賃貸マンション,その他)
        judgeResultBefore = (judgeResultBefore === HouseActureType.OWNED ||
            judgeResultBefore === HouseActureType.FAMILY_OWNED) ? '01' : '02';
        judgeResultEdited = (judgeResultEdited === HouseActureType.OWNED ||
            judgeResultEdited === HouseActureType.FAMILY_OWNED) ? '01' : '02';
        // 所有から賃貸に変更する場合、住宅ローン残高クリア
        if (judgeResultBefore === '01' && judgeResultEdited === '02') {
            judgeResultEdited = '02';
            // 賃貸から所有に変更する場合、家賃負担クリア、住宅ローン残高クリア
        } else if (judgeResultBefore === '02' && judgeResultEdited === '01') {
            judgeResultEdited = '01';
            // 所有→賃貸→所有に変更する場合、住宅ローン有無、住宅ローン残高回復。
        } else if (judgeResultBefore === judgeResultEdited) {
            judgeResultEdited = '100';
        }
        return judgeResultEdited;
    }

    /**
     * チャット修正後項目の再設定
     * @param itemName 項目名
     * @param itemValue 項目値
     */
    public setSaveShowChatsValue(itemName: String, itemValue: any) {
        this.state.showConfirm.forEach((item) => {
            if (item.name === itemName) {
                item.answer.text = itemValue;
            }
        });
    }

    /**
     * パスワードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onPasswordInput(entity: CreditCardQuestionsModel, pageIndex: number): void {
        // 暗証番号エラーチェックのため、業務区分により電話番号リストを設定
        const telephone = [];
        // 純新規日本人と純新規外国人の場合
        if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT
            || this.state.submitData.applyBizCategory === ApplyBizCategory.FOREIGN_NATIONALITY) {
            telephone.push(this.state.submitData.holderMobileNo);
            telephone.push(this.state.submitData.holderTelephoneNo);
        } else if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
            // 既存新規
            // 電話番号変更ありの場合
            if (this.state.submitData.existingChangeFirstMobileNo || this.state.submitData.existingChangeFirstTel) {
                telephone.push(this.state.submitData.existingChangeHolderMobileNo);
                telephone.push(this.state.submitData.existingChangeHolderTelephoneNo);
            } else {
                // 電話番号変更なしの場合
                telephone.push(this.state.submitData.holderTelNo1);
                telephone.push(this.state.submitData.holderTelNo2);
                telephone.push(this.state.submitData.holderTelNo3);
            }
        } else {
            // BC単体の場合
            telephone.push(this.state.submitData.holderTelNo1);
            telephone.push(this.state.submitData.holderTelNo2);
            telephone.push(this.state.submitData.holderTelNo3);
        }
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            birthday: this.state.submitData.birthdate,
            birthdayText: this.state.submitData.birthdateWithAge,
            telephone: telephone,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
        };

        this.chatFlowAccessor.addComponent(entity.choices, PasswordInputComponent,
            this.footerContent, options).subscribe((answer) => {
                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.chatFlowAccessor.clearComponent();
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                } else {
                    this.chatFlowAccessor.clearComponent();
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const choices = this.changeValidationRuleMax(entity, this.state.submitData);
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getCreditCardDefaultValues(entity.name, this.state.submitData),
            title: entity.options ? entity.options.title : undefined,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            fullwidthHalfwidthDivisionCode: entity.fullwidthHalfwidthDivisionCode
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    if (entity.name === 'department') {
                        this._action.setStateSubmitDataValue({ name: 'department', value: undefined });
                    } else if (entity.name === 'positionName') {
                        this._action.setStateSubmitDataValue({ name: 'positionName', value: undefined });
                    }
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    // カナ変換において、特定の属性については最大長を超えないように設定する
                    let maxLength = null;
                    // 町丁名は町丁名(フリガナ)の最大文字数、番地名は町丁名+番地名(フリガナ)の最大文字数-町丁名(フリガナ)の文字数
                    if (answer.value[0]) {
                        const key = answer.value[0].key;
                        switch (key) {
                            case 'holderAddressStreetNameInput':
                            case 'holderAddressHouseNumber':
                                maxLength = InputUtils.calculateMaxLength(key,
                                    this.state.submitData[entity.infoType + 'HolderAddressStreetNameFuriKanaInput'],
                                    this.state.submitData[entity.infoType + 'HolderAddressStreetNameFuriKanaSelect']);
                                break;
                        }
                    }

                    InputUtils.getKanjiToKana(answer.value, maxLength).subscribe((results) => {
                        if (entity.infoType === CreditInputPattern.EMPLOYMENT || entity.infoType === CreditInputPattern.PARENTAL) {
                            results = this.replaceItemKey(entity.infoType, { value: results });
                        }
                        this.setAnswer({ text: answer.text, value: results });
                        if (entity.fullwidthHalfwidthDivisionCode) {
                            this.store.registerSignalHandler(CreditCardSignal.CHARACTER_CHECK, (data) => {
                                this.store.unregisterSignalHandler(CreditCardSignal.CHARACTER_CHECK);
                                this.getNextChat(entity.next, pageIndex);
                            });
                            const params = {
                                tabletApplyId: this._store.getState().tabletApplyId,
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                                    checkStrings: [{
                                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                        checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                    }],
                                }
                            };
                            this._action.characteCheck(params, () => {
                                this._action.editChart(entity.order, pageIndex,
                                    this.state.showChats[this.state.showChats.length - 1].answer.order);
                                this.getNextChat(entity.order, pageIndex);
                            });
                        } else {
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });
                }
            });
    }

    /**
     * キャッシュカード口座入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onNumberKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();

            if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                if (entity.name === 'parentalHolderMobileNo') {
                    this._action.setStateSubmitDataValue({ name: 'parentalHolderMobileNo', value: undefined });
                    this._action.setStateSubmitDataValue({ name: 'parentalFirstMobileNo', value: undefined });
                    this._action.setStateSubmitDataValue({ name: 'parentalSecondMobileNo', value: undefined });
                    this._action.setStateSubmitDataValue({ name: 'parentalThirdMobileNo', value: undefined });

                }
                if (entity.name === 'parentalHolderTelephoneNo') {
                    this._action.setStateSubmitDataValue({ name: 'parentalHolderTelephoneNo', value: undefined });
                    this._action.setStateSubmitDataValue({ name: 'parentalFirstTel', value: undefined });
                    this._action.setStateSubmitDataValue({ name: 'parentalSecondTel', value: undefined });
                    this._action.setStateSubmitDataValue({ name: 'parentalThirdTel', value: undefined });
                }
                if (entity.name === 'phoneNoExtension') {
                    this._action.setStateSubmitDataValue({ name: 'phoneNoExtension', value: undefined });
                }
                this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
            } else {
                this.giveInfotype(entity.infoType, answer);
                this.setAnswer(answer);
            }
            const isShowModal = this.telIsSkip(entity.name, answer === COMMON_CONSTANTS.SIGN_SKIP);
            if (!isShowModal) {
                this.getNextChat(entity.next, pageIndex);
            }
        });
    }

    /**
     * マルチボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onMulitButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxLength: entity.validationRules.max
        };
        this.chatFlowAccessor.addComponent(entity.choices, MultiButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
            }
            this.chatFlowAccessor.clearComponent();
            const next = answer.next.split('、')[0];
            this.getNextChat(Number.parseInt(next), pageIndex);
        });
    }

    /**
     * Type: Textの動作を追加する
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onText(entity: CreditCardQuestionsModel, pageIndex: number): void {
        if (entity.name && entity.name === 'endModifyChat') {
            // 修正チャットの最後がType:textだと表示されない不具合の対処
            Observable.timer(CreditCardConsts.ShowTextTime.END_MODIFY_CHAT).subscribe(() => {
                this.getNextChat(entity.next, pageIndex);
            });
            return;
        }
        this.getNextChat(entity.next, pageIndex);
    }

    /**
     * 数量の汎用入力コンポーネントの表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onQuantityInput(entity: CreditCardQuestionsModel, pageIndex: number): void {
        // 勤務年数が年齢以上で入力できない
        if (entity.name === 'lengthOfService') {
            const age = this.creditCardUtil.calculateAge(this.state.submitData.birthdate);
            if (entity.choices) {
                entity.choices.forEach((choice) => {
                    if (choice.name === 'lengthOfService') {
                        choice.validationRules.maxValue = age;
                    }
                });
            }
        }
        const options = {
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            title: entity.options ? entity.options.title : undefined,
            unit: entity.options ? entity.options.unit : undefined,
            validationRules: entity.validationRules,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, QuantityInputComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * Pickerコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onPicker(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        validation = entity.validationRules;
        if (entity.name === 'graduateDate' && entity.options) {
            entity.options.defaultIndex = this.getGraduateMonthDefaultIndex();
            // システム日時を最小値に設定
            if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
                validation = {
                    ...entity.validationRules,
                    min: moment(customerApplyStartDate)
                        .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM)
                };
            }
        }
        // 居住年数が年齢以上で入力できない
        if (entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_RESIDENCE_YEAR_PICKER) {
            const age = this.creditCardUtil.calculateAge(this.state.submitData.birthdate);
            validation.range[1] = age;
        }

        const options = {
            type: entity.type,
            name: entity.name,
            infoType: entity.infoType,
            defaultIndex: entity.options ? entity.options.defaultIndex : undefined,
            validationRules: validation,
            submitData: this.state.submitData,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.giveInfotype(entity.infoType, answer);
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        let maxColNum;
        switch (entity.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON:
                maxColNum = 3;
                break;
            case COMMON_CONSTANTS.ELEMENT_TYPE_TWOCOLS_BUTTON:
                maxColNum = 2;
                break;
            default:
                maxColNum = 1;
                break;
        }
        const options = {
            maxColNum: maxColNum,
            validationOn: null,
            kanaText: null,
            validationRules: null,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        if (entity.options && entity.options === ChatOption.VALIDATION_ON) {
            const backupDataService = InjectionUtils.injector.get(BackupDataService);
            options.validationOn = ChatOption.VALIDATION_ON;
            options.kanaText = backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
            .subscribe((answer) => {
                if (entity.name.length > 0 && answer.value.length > 0) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value }
                        ]
                    });
                }
                if (entity.name === 'career') {
                    this.jobEdited = true;
                    // 卒業後の職業選択の場合、卒業予定年月日、学校名をクリア
                    if (this.state.submitData.career !== Career.STUDENT) {
                        // 学校情報クリア
                        this._action.clearShoolInfo();
                    }
                    if (entity.options && entity.options === 'careerSelect') {
                        this._action.setStateSubmitDataValue({ name: 'isNearGraduate', value: undefined });
                    }
                    if (entity.options && entity.options === 'afterGraduate') {
                        this._action.setStateSubmitDataValue({ name: 'isNearGraduate', value: IsNearGraduate.YES });
                    }
                }
                if ((entity.name === 'parentalLivingTogether' && answer.value === IsParentalLivingTogether.YES)
                    && (this.state.copySubmitData.parentalLivingTogether !== IsParentalLivingTogether.YES
                        || !this.state.copySubmitData.parentalLivingTogether)) {
                    this._action.setStateSubmitDataValue({
                        name: 'parentalZipCode',
                        value: this.state.submitData.firstZipCode ?
                            this.state.submitData.firstZipCode + '-' + this.state.submitData.lastZipCode : this.state.submitData.zipCode
                    });
                    this._action.setStateSubmitDataValue({ name: 'parentalAddress', value: this.state.submitData.address });
                    this._action.setStateSubmitDataValue({ name: 'parentalAddressKana', value: this.state.submitData.addressKana });
                }
                if (entity.name === 'isHaveUnsecuredLoan' && answer.text === IsBankCardLoan.YES) {
                    this._action.clearBcLoanInfo();
                }
                if (answer.action.type.length > 0) {
                    this.configAction(answer);
                } else if (answer.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.next, pageIndex);
                }
            });
    }

    /**
     * カード券面を入力する
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onPrintName(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: [this.state.submitData.printFirstName + ' ' + this.state.submitData.printLastName, ''],
            maxLength: MaxLength.MAX_LENGTH_19,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PrintNameInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer.text.indexOf(COMMON_CONSTANTS.HALF_POINT_NO_SPACE) !== -1) {
                    answer.text = answer.text.replace(/\./g, COMMON_CONSTANTS.FULL_POINT);
                }
                // 最初の半角スペースによってローマ字氏名を分割する。
                // 前の部分をprintFirstNameとして、後ろの部分はprintLastNameとして
                const printFullName = answer.value[0].value;
                const firstSpaceIndex = printFullName.indexOf(COMMON_CONSTANTS.SPACE);
                const printFirstName = printFullName.substring(0, firstSpaceIndex);
                const printLastName = printFullName.substring(firstSpaceIndex + 1);
                const answerValue = [
                    {
                        key: 'printFirstName',
                        value: printFirstName
                    },
                    {
                        key: 'printLastName',
                        value: printLastName
                    },
                ];
                this.setAnswer({ text: answer.text, value: answerValue });
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * 郵便番号から検索した住所を選択する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSelectAddress(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            submitData: this.getZipCode(entity.infoType),
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.type, SelectAddressCommonComponent, this.footerContent, options)
            .subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer.value) {
                    this.giveInfotype(entity.infoType, answer);
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                } else {
                    this.getNextChat(entity.skip, pageIndex);
                }
            });
    }

    /**
     * 検索した町丁名を選択する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSelectStreet(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const params = {
            prefectureKanji: this.getPrefecture(entity.infoType),
            countyUrbanVillageKanji: this.getCountyUrbanVillage(entity.infoType)
        };
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(params, SelectStreetComponent, this.footerContent, options)
            .subscribe((result: { isSkip: boolean, text: string, value: any }) => {
                this.chatFlowAccessor.clearComponent();
                if (result.value) {
                    const answer = {
                        text: result.text,
                        value: [
                            { key: 'holderAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'holderAddressStreetNameFuriKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) },
                            { key: 'streetWork', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'streetStreet', value: (result.isSkip ? undefined : result.value.streetKanji) }
                        ]
                    };
                    this.giveInfotype(entity.infoType, answer);
                    this.setAnswer(answer);
                    this.getNextChat(result.isSkip ? entity.skip : entity.next, pageIndex);
                } else {
                    this._action.resetLastNode({ order: entity.next, pageIndex: pageIndex });
                }
            });
    }

    private configAction(choice: any) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.chatFlowCompelete(action.value);
        }
    }

    /**
     * Config url
     * @param entity params
     */
    private configUrl(entity, pageIndex) {
        if (entity.option === 'url') {
            const serverInfoService = InjectionUtils.injector.get(ServerInfoService);
            const submitData = this.state.submitData;

            let params;
            switch (entity.name) {
                case 'getAddressFromZipcode': {
                    let firstZipCode: string;
                    let lastZipCode: string;
                    if (submitData[entity.infoType + 'FirstZipCode']) {
                        firstZipCode = submitData[entity.infoType + 'FirstZipCode'];
                    }
                    if (submitData[entity.infoType + 'LastZipCode']) {
                        lastZipCode = submitData[entity.infoType + 'LastZipCode'];
                    }
                    const zipCode = firstZipCode + lastZipCode + '';
                    params = { zipCode: zipCode };
                    break;
                }
                case 'getStreetInitialsKana': {
                    let prefecture;
                    let village;
                    if (submitData[entity.infoType + 'HolderAddressPrefecture']) {
                        prefecture = submitData[entity.infoType + 'HolderAddressPrefecture'];
                    }
                    if (submitData[entity.infoType + 'HolderAddressCountyUrbanVillage']) {
                        village = submitData[entity.infoType + 'HolderAddressCountyUrbanVillage'];
                    }
                    params = {
                        prefectureKanji: prefecture,
                        countyUrbanVillageKanji: village
                    };
                    break;
                }
            }
            serverInfoService.getInfoFormServe(entity.name, params).subscribe((result) => {
                entity.choices.forEach((choice) => {
                    if (result === choice.value) {
                        this._action.getNextChatByAnswer(choice.next, pageIndex);
                        return;
                    }
                });
            });
        } else if (entity.option === 'credit') {
            const judgeResult = this.getJudgeResultFromSubmitData(this.state.submitData, entity, pageIndex);
            this.getNextChatByJudge(judgeResult, entity, pageIndex);
        }
    }

    private getJudgeResultFromSubmitData(submitData: CreditCardSubmitEntity, entity: CreditCardQuestionsModel, pageIndex: number) {
        let judgeResult: string;
        const bcOnSuica = /43|63/;
        const ageCode = /1|2|4/;
        switch (entity.name) {
            case 'jobPattern': {
                judgeResult = this.returnJobPattern();
                break;
            }
            case 'careerCheck': {
                if (submitData.career) {
                    judgeResult = (submitData.career === Career.ANNUITY_PENSION ||
                        submitData.career === Career.HOUSEWIFE ||
                        submitData.career === Career.UNEMPLOYED) ? '01' : '02';
                }
                break;
            }
            case 'graduateDate': {
                const graduateDate = moment(submitData.graduateDate, COMMON_CONSTANTS.DATE_FORMAT_YYYYMM)
                    .endOf(COMMON_CONSTANTS.DATE_MONTH).format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
                const customerApplyDate = moment(submitData.customerApplyStartDate, COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
                const remainingPeriod = moment(graduateDate).diff(customerApplyDate, COMMON_CONSTANTS.DATE_DAY);
                // 申込日起算で90日勘定
                judgeResult = remainingPeriod <= 90 ? '01' : '02';
                break;
            }
            case 'careerAfterGraduation': {
                const canSelectHousewife = submitData.gender === Gender.FEMALE && submitData.married === IsMarried.MARRIED;
                switch (submitData.cardType) {
                    case BankCardType.BC_GOLD:
                    case BankCardType.BC_GOLD_SUICA: {
                        judgeResult = canSelectHousewife ? '03' : '01';
                        break;
                    }
                    case BankCardType.BC_VISA:
                    case BankCardType.BC_SUICA:
                    case BankCardType.BC_MASTERCARD: {
                        judgeResult = canSelectHousewife ? '04' : '02';
                        break;
                    }
                }
                break;
            }
            case 'isSuicaOn': {
                // バンクカードSsuicaまたはバンクカードSuicaゴールドか
                judgeResult = submitData.cardType.match(bcOnSuica) ? '01' : '02';
                break;
            }
            case 'isCanApplyBcLoan': {
                // バンクカードローン申し込めるか
                judgeResult = submitData.career === Career.HOUSEWIFE ||
                    submitData.career === Career.STUDENT ||
                    submitData.ageClassification.match(ageCode) ? '02' : '01';
                if (judgeResult === '02') {
                    this._action.setStateSubmitDataValue({
                        name: 'loanApplication',
                        value: IsBankCardLoan.IS_NOT_APPLY
                    });
                }
                break;
            }
            // 職業選択のダブルジャージ
            case 'studentCheckJudge': {
                judgeResult = submitData.career;
                break;
            }
            // 配偶者有無選択
            case 'femaleHousewife': {
                // 女性かつ主婦かつ独身の場合、１へ、その他の場合２へ
                judgeResult = submitData.gender === Gender.FEMALE
                    && submitData.career === Career.HOUSEWIFE
                    && submitData.married === IsMarried.UN_MARRIED ?
                    '1' : '2';
                break;
            }
            // お住い種類のダブルジャージ
            case 'houseTypeJudge': {
                judgeResult = submitData.houseType;
                break;
            }
            case 'parentalLivingTogether': {
                // 01:親権者の住所入力 02:親権者の住所不要
                judgeResult = submitData.parentalLivingTogether === IsParentalLivingTogether.NO ? '01' : '02';
                break;
            }
            // 卒業年月のダブルジャージ
            case 'graduateDateJudge': {
                if (submitData.graduateDate) {
                    const graduateDate = moment(submitData.graduateDate, COMMON_CONSTANTS.DATE_FORMAT_YYYYMM)
                        .endOf(COMMON_CONSTANTS.DATE_MONTH).format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
                    const customerApplyDate = moment(submitData.customerApplyStartDate, COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
                    const remainingPeriod = moment(graduateDate).diff(customerApplyDate, COMMON_CONSTANTS.DATE_DAY);
                    // 申込日起算で90日勘定
                    judgeResult = remainingPeriod <= 90 ? '01' : '02';
                } else {
                    judgeResult = undefined;
                }
                break;
            }
            // 職業選択のダブルジャージ
            case 'careerCheckJudge': {
                if (submitData.career) {
                    judgeResult = (submitData.career === Career.ANNUITY_PENSION ||
                        submitData.career === Career.HOUSEWIFE ||
                        submitData.career === Career.UNEMPLOYED) ? '01' : '02';
                }
                if (submitData.career === Career.STUDENT) {
                    judgeResult = '00';
                }
                break;
            }
            // 親同居有無のダブルジャージ
            case 'parentalLivingTogetherJudge': {
                judgeResult = submitData.parentalLivingTogether;
                break;
            }
            // バンクカードローン申し込めるかのダブルジャージ
            case 'isCanApplyBcLoanJudge': {
                // バンクカードローン申し込めるか 01: 申込可、02: 申込不可
                judgeResult = submitData.career === Career.HOUSEWIFE || submitData.career === Career.STUDENT ||
                    submitData.ageClassification.match(ageCode) ? '02' : '01';
                break;
            }
            // 居住費負担
            case 'houseType': {
                judgeResult = submitData.houseType === HouseActureType.OWNED || submitData.houseType === HouseActureType.FAMILY_OWNED ?
                    HouseOwnType.OWN : HouseOwnType.RENTAL;        // 所有:01、賃貸:02
                break;
            }
            case 'isApplyGold': {
                if (submitData.cardType === BankCardType.BC_GOLD
                    || submitData.cardType === BankCardType.BC_GOLD_SUICA) {
                    this._action.setStateSubmitDataValue({
                        name: 'overdraftLimit',
                        value: OverdraftLimit.OVERDRAFT_LIMIT_50
                    });
                    judgeResult = '02';
                } else {
                    judgeResult = '01';
                }
                break;
            }
            default: {
                judgeResult = submitData[entity.name];
            }
        }
        return judgeResult;
    }

    private getNextChatByJudge(judgeResult: string, entity: CreditCardQuestionsModel, pageIndex: number) {
        entity.choices.forEach((choice) => {
            if (judgeResult === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }

    /**
     * 性別・申込カード種別・結婚有無から表示する職業パターンを判別する。
     */
    private returnJobPattern() {
        let jobPattern: string;
        if (this.state.submitData.married === IsMarried.UN_MARRIED) {
            switch (this.state.submitData.cardType) {
                case BankCardType.BC_GOLD:
                case BankCardType.BC_GOLD_SUICA: {
                    jobPattern = JobPattern.JOB_PATTERN_01;
                    break;
                }
                case BankCardType.BC_VISA:
                case BankCardType.BC_SUICA:
                case BankCardType.BC_MASTERCARD: {
                    jobPattern = JobPattern.JOB_PATTERN_02;
                    break;
                }
            }
        } else if (this.state.submitData.married === IsMarried.MARRIED) {
            switch (this.state.submitData.cardType) {
                case BankCardType.BC_GOLD:
                case BankCardType.BC_GOLD_SUICA: {
                    if (this.state.submitData.gender === Gender.MALE) {
                        jobPattern = JobPattern.JOB_PATTERN_01;
                    } else if (this.state.submitData.gender === Gender.FEMALE) {
                        jobPattern = JobPattern.JOB_PATTERN_03;
                    }
                    break;
                }
                case BankCardType.BC_VISA:
                case BankCardType.BC_SUICA:
                case BankCardType.BC_MASTERCARD: {
                    if (this.state.submitData.gender === Gender.MALE) {
                        jobPattern = JobPattern.JOB_PATTERN_02;
                    } else if (this.state.submitData.gender === Gender.FEMALE) {
                        jobPattern = JobPattern.JOB_PATTERN_04;
                    }
                    break;
                }
            }
        }
        return jobPattern;
    }

    /**
     * 入力区分に応じて項目名を変更する
     * @param infoType 入力区分
     * @param answers チャットフローエンティティ
     */
    private replaceItemKey(infoType: string, answers: any) {
        const replacedAnswer: any[] = [];
        answers.value.map((item) => {
            if (item.key !== undefined && item.key.indexOf('holder') !== -1) {
                item.key = item.key.replace('holder', infoType + 'Holder');
            }
            if (item.key !== undefined && item.key.indexOf('firstZipCode') !== -1) {
                item.key = item.key.replace('firstZipCode', infoType + 'FirstZipCode');
            }
            if (item.key !== undefined && item.key.indexOf('lastZipCode') !== -1) {
                item.key = item.key.replace('lastZipCode', infoType + 'LastZipCode');
            }
            replacedAnswer.push({ key: item.key, value: item.value });
        });
        return replacedAnswer;
    }

    /**
     * 区分に応じて参照する郵便番号を変更する。
     * @param infoType 勤務先名称・親権者情報の区分。
     */
    private getZipCode(infoType: string) {
        const zipCode = {
            firstZipCode: this.state.submitData[infoType + 'FirstZipCode'],
            lastZipCode: this.state.submitData[infoType + 'LastZipCode']
        };

        return zipCode;
    }

    /**
     * 区分に応じて参照する県を変更する。
     * @param infoType 勤務先名称・親権者情報の区分。
     */
    private getPrefecture(infoType: string) {
        const prefecture = this.state.submitData[infoType + 'HolderAddressPrefecture'];
        return prefecture;
    }

    /**
     * 区分に応じて参照する市区町村を変更する。
     * @param infoType 勤務先名称・親権者情報の区分。
     */
    private getCountyUrbanVillage(infoType: string) {
        const countyUrbanVillage = this.state.submitData[infoType + 'HolderAddressCountyUrbanVillage'];
        return countyUrbanVillage;
    }

    private giveInfotype(infotype: string, answer: any) {
        if (infotype === CreditInputPattern.EMPLOYMENT || infotype === CreditInputPattern.PARENTAL) {
            answer.value = this.replaceItemKey(infotype, answer);
        }
    }

    private telIsSkip(name: string, isSkip: boolean) {
        if (name === 'parentalHolderMobileNo') {
            this.phoneIsSkipped = isSkip;
        }
        if (name === 'parentalHolderTelephoneNo') {
            this.tellIsSkipped = isSkip;
        }
        if (name === 'parentalHolderMobileNo' && this.phoneIsSkipped && this.tellIsSkipped) {
            const buttonList = [
                { text: 'OK', buttonValue: 'ok' },
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.warnTelTitleBC,
                buttonList, () => {
                    this._action.needInputPhoenNo();
                }
            );
            return true;
        }
        return false;
    }

    /**
     * 次の3月末をピッカーのデフォルト値とする。
     */
    private getGraduateMonthDefaultIndex() {
        const defaultIndex = [];
        const customorApplyMonth = moment(this.state.submitData.customerApplyStartDate)
            .format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMM).slice(-2);
        if (Number(customorApplyMonth) < 4) {
            defaultIndex[0] = 0;
            defaultIndex[1] = 2;
        } else {
            defaultIndex[0] = 1;
            defaultIndex[1] = 2;
        }
        return defaultIndex;
    }

    private changeValidationRuleMax(entity: any, submitData: any) {
        const choicesResult = ObjectUtils.clone(entity.choices);
        const holderAddressStreetNameInput = submitData[entity.infoType + 'HolderAddressStreetNameInput'];

        // 「町丁名（漢字）」の入力済桁数により、「番地以降（漢字）」の入力可能最大桁数を調整する
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW
            && choicesResult[0].name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER
            && holderAddressStreetNameInput
            && holderAddressStreetNameInput.length > 0) {
            let holderAddressStreetLength = 0;
            holderAddressStreetLength = holderAddressStreetNameInput.length;
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max - holderAddressStreetLength + 1;
        }
        return choicesResult;
    }

}
