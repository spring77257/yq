import {
    ComponentFactory,
    ComponentFactoryResolver, ComponentRef,
    EventEmitter,
    NgZone
} from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import { CreditCardSignal, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { ComponentProvider } from 'dhdt/branch/shared/components/component-provider';
import { Content } from 'ionic-angular';

/**
 * chat flow accessor.
 */
export class CreditCardChatFlowAccessor {

    protected action: CreditCardAction;
    protected store: CreditCardStore;

    private _chatFlowRenderer: CreditCardChatFlowRenderer;

    private factory: ComponentFactory<ComponentProvider>;
    private qf: ComponentRef<ComponentProvider>;
    private componentFactoryResolver: ComponentFactoryResolver;
    private zone: NgZone;

    constructor(public chatFlowRenderer?: CreditCardChatFlowRenderer) {

        this.action = InjectionUtils.injector.get(CreditCardAction);
        this.store = InjectionUtils.injector.get(CreditCardStore);
        this.componentFactoryResolver = InjectionUtils.injector.get(ComponentFactoryResolver);
        this.zone = InjectionUtils.injector.get(NgZone);
        this._chatFlowRenderer = chatFlowRenderer;

        this.addListioner();
    }

    public addComponent(datas: any, from: any, to: any, options: any = {}): EventEmitter<any> {
        this.factory = this.componentFactoryResolver.resolveComponentFactory(from);
        this.qf = to.createComponent(this.factory);
        this.qf.instance.datas = datas;
        this.qf.instance.options = options;
        this.qf.instance.content = this._chatFlowRenderer.content;
        this.qf.instance.footer = to;
        if (this.qf.instance.refresh) {
            this.qf.instance.refresh.subscribe(() => {
                this.resize();
            });
        }
        return this.qf.instance.launch;
    }

    /**
     * Resize view
     * Called whenever view change
     */
    public resize() {
        this._chatFlowRenderer.content.resize();
        setTimeout(() => {
            if (this._chatFlowRenderer.content && this._chatFlowRenderer.content._scroll !== null) {
                this._chatFlowRenderer.content.scrollToBottom();
            }
        }, 400);
    }

    public clearComponent() {
        if (this.qf) {
            this.qf.destroy();
        }
    }

    public destroy(): void {
        this.store.unregisterSignalHandler(CreditCardSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(CreditCardSignal.SEND_ANSWER);
    }

    public setContent(content: Content) {
        this._chatFlowRenderer.content = content;
    }

    public setRenderer(chatFlowRenderer?: CreditCardChatFlowRenderer) {
        this._chatFlowRenderer = chatFlowRenderer;
    }

    private addListioner() {
        this.store.registerSignalHandler(CreditCardSignal.GET_QUESTION, (pageIndex: number) => {
            // show first message
            this.clearComponent();
            this.action.getNextChatByAnswer(0, pageIndex);
        });
        this.store.registerSignalHandler(CreditCardSignal.SEND_ANSWER, (datas) => {
            const question = datas.question;
            const pageIndex = datas.pageIndex;
            this.clearComponent();
            this._chatFlowRenderer.rendererComponents(question, pageIndex);
        });
    }

}
