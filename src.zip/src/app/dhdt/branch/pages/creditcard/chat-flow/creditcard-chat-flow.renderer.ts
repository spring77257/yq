import { EventEmitter, Output, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { InjectionUtils } from 'adep/utils';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardQuestionsModel } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { Content } from 'ionic-angular';

export interface OnRenderer {
    onText?(entity: CreditCardQuestionsModel, pageIndex: number): void;
    onButton?(entity: CreditCardQuestionsModel, pageIndex: number): void;
    onKeybord?(entity: CreditCardQuestionsModel, pageIndex: number): void;
    onNumberKeybord?(entity: CreditCardQuestionsModel, pageIndex: number): void;
    onRoute?(entity: CreditCardQuestionsModel, pageIndex: number): void;
    onJudge?(entity: CreditCardQuestionsModel, pageIndex: number): void;
}

/**
 * chat flow renderer.
 */
export abstract class CreditCardChatFlowRenderer extends BaseComponent implements OnRenderer {
    public abstract processType: number;
    public _action: CreditCardAction;
    public _store: CreditCardStore;
    @Output() public nextChatEvent = new EventEmitter();
    @ViewChild(Content) public content: Content;

    constructor() {
        super();
        this._action = InjectionUtils.injector.get(CreditCardAction);
        this._store = InjectionUtils.injector.get(CreditCardStore);
    }

    public abstract loadTemplate(pageIndex: number);

    public onText(entity: CreditCardQuestionsModel, pageIndex: number): void {
        this.getNextChat(entity.next, pageIndex);
    }

    public onButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onButton');
    }

    public onKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onKeybord');
    }

    public onNumberKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onNumberKeybord');
    }

    public onJudge(entity: CreditCardQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onJudge');
    }

    public rendererComponents(question: CreditCardQuestionsModel, pageIndex: number) {
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_TEXT: {
                this.onText(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_BUTTON: {
                this.onButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_IMAGE: {
                this.getNextChat(question.next, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE: {
                this.onJudge(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_KEYBORD: {
                this.onKeybord(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_NUMBER: {
                this.onNumberKeybord(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_ROUTE: {
                this.chatFlowCompelete(question.example);
                this.getNextChat(question.next, pageIndex);
                break;
            }
        }
    }

    protected getNextChat(order: number, pageIndex: number) {
        this.nextChatEvent.emit({ order: order, pageIndex: pageIndex });
    }

    protected setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this._action.setAnswer(answer);
    }

    protected chatFlowCompelete(nextChatName?: string) {
        this._action.chatFlowCompelete(nextChatName);
    }

    protected chatFlowReturn(nextChatName?: string, options: any = null) {
        this._action.chatFlowReturn(nextChatName, options);
    }
}
