import {
    AfterViewChecked, animate, ChangeDetectorRef, Component, ElementRef,
    OnDestroy, OnInit, style, transition, trigger, ViewChild, ViewContainerRef
} from '@angular/core';
import { BaseComponent } from 'adep/components';
import { AppProperties } from 'app.properties';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { Content, NavParams, ViewController } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';

import { ObjectUtils } from 'adep/utils';
import { DeviceService } from 'dhd/common/services/device.service';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardConfirmCommonRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/confirm/creditcard-confirm-common.renderer';
import {
    CreditCardConfirmJcbCommonRenderer
} from 'dhdt/branch/pages/creditcard/chat-flow/confirm/creditcard-confirm-jcb-com.renderer';
import { CreditCardChatFlowAccessor } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.accessor';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import { CreditCardSubmitEntity } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { CreditCardUtil } from 'dhdt/branch/shared/utils/creditcard-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';

@Component({
    selector: 'creditcard-confirmpage-chat-component',
    templateUrl: 'creditcard-chat.component.html',
    animations: [
        trigger('ProgressBarAnimation', [
            transition('void => *', [
                style({ transformOrigin: '0 0 0', transform: 'translateY(-100%)' }),
                animate(
                    '300ms',
                    style({ transformOrigin: '0 0 0', transform: 'translateY(0)' })
                )
            ])
        ])
    ]
})

/**
 * control all chat page.
 */
export class CreditCardConfirmPageChatComponent extends BaseComponent implements AfterViewChecked, OnInit, OnDestroy {
    @ViewChild(Content) public content: Content;
    @ViewChild('footerContent', { read: ViewContainerRef }) public footerContent: ViewContainerRef;
    @ViewChild('topBlockView', { read: ElementRef }) public topBlockView: ElementRef;
    @ViewChild('bottomBlockView', { read: ElementRef }) public bottomBlockView: ElementRef;

    public chatFlowAccessor: CreditCardChatFlowAccessor;
    public state: CreditCardState;
    // is current page
    public isCurrentPage: boolean;
    public currentTitle: string;
    public needPassword: boolean = true;
    public showSkipToOrdinaryDeposit: boolean = false;

    public processType: number;

    public tabletApplyId: any;
    public displayTabletApplyId: boolean = false;
    public showRightButton: boolean = false;
    public title: string = this._labels.creditcard.titleHeader;
    public titleImgSrc: string = AppProperties.IMG_ROOT + 'common/img_logo@2x.png';
    public achieveImgSrc: string =  AppProperties.IMG_ROOT + 'common/icon_check_outline@2x.png';
    public backIconImgSrc: string =  AppProperties.IMG_ROOT + 'common/icon_back@2x.png';
    public bellIconImgSrc: string =  AppProperties.IMG_ROOT + 'common/icon_bell@2x.png';
    public showIconImgSrc: string = this.backIconImgSrc;

    // 研修環境かどうかをチェック
    public get isTrngEnv(): boolean {
        return InputUtils.isTrngEnv();
    }

    public leftSubTitle: string = this._labels.header.back;

    private currentPageComponent: CreditCardChatFlowRenderer;
    private currentPageIndex: number;
    private pageComponentList: CreditCardChatFlowRenderer[];

    private startOrder: number;
    private endOrder: number;
    private originShowConfirm: any;
    private originShowChats: any[];
    private originSubmitData: CreditCardSubmitEntity;
    private name: string;

    constructor(
        private store: CreditCardStore, private action: CreditCardAction,
        private modalService: ModalService,
        private loginStore: LoginStore, private deviceService: DeviceService,
        public changeDetectorRef: ChangeDetectorRef,
        private params: NavParams, public viewCtrl: ViewController,
        private editService: EditService,
        private creditCardUtil: CreditCardUtil,
        private loggingService: LoggingService) {
        super();
        this.pageComponentList = [];
        this.state = this.store.getState();
        this.chatFlowAccessor = new CreditCardChatFlowAccessor();
        this.originShowConfirm = ObjectUtils.clone(this.state.showConfirm);
        this.originShowChats = ObjectUtils.clone(this.state.showChats);
        this.originSubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
    }

    public ngOnInit() {

        // tabletApplyIDの表示非表示設定
        if (AppProperties.DISPLAY_TABLET_APPLY_ID === 'true') {
            this.displayTabletApplyId = true;
            this.tabletApplyId = this.state.tabletApplyId || this.loginStore.getState().tabletApplyId;
        }

        this.currentTitle = this.params.get('isCurrentPage') ? this.params.get('currentTitle') : '';
        this.startOrder = this.params.get('startOrder');
        this.endOrder = this.params.get('endOrder');
        this.name = this.params.get('name');
        this.currentPageIndex = this.params.get('pageIndex');
        this.isCurrentPage = true;
        this.needPassword = this.params.get('needPassword') ? false : true;
        this.initializeChatComponent();
    }

    public ngOnDestroy() {
        this.chatFlowAccessor.destroy();
    }

    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    public beforeAlert() {
        this.chatFlowAccessor.clearComponent();
    }
    public afterAlert() {
        const lastNode = this.state.showChats[this.state.showChats.length - 1];
        this.action.resetLastNode({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    /**
     * button click CallBack
     * @param order メッセージの番号
     * @param pageIndex ページ番号
     * @param answerOrder 回答順
     */
    public editCallBack(order: number, pageIndex: number, answerOrder: number, orderIndex: number) {
        this.editService.startEdit();
        this.beforeAlert();
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.editBtn, buttonValue: 'edit' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.editTitle,
            buttonList,
            (item) => {
                const preventedItem = this.editService.endEdit();
                if (item.buttonValue === 'edit') {
                    this.action.editChart(order, pageIndex, answerOrder, orderIndex);
                    this.chatFlowAccessor.clearComponent();
                    this.currentPageIndex = pageIndex;
                    this.currentPageComponent = this.getPageComponent(pageIndex);
                    this.getNextAnswer(order, pageIndex);
                    const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
                    this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
                } else {
                    if (preventedItem) {
                        this.getNextAnswer(preventedItem.order, preventedItem.pageIndex);
                    } else {
                        this.afterAlert();
                    }
                }
            },
            this.labels.alert.editSubTitle
        );
    }

    /**
     * ヘッダータイトル取得
     */
    public get headerTitle(): string {
        return this._labels.creditcard.titleHeader;
    }

    // header cancel button click
    public handleCancelClickEmitter(value) {
        this.action.resetShowConfirm(this.originShowConfirm);
        this.action.resetShowChats(this.originShowChats, this.originSubmitData);
        this.viewCtrl.dismiss(value);
    }

    // left button click
    public leftBtnClick() {
       if (this.leftSubTitle === this.labels.header.back) {
            this.handleCancelClickEmitter('close');
            this.operationLogging(this._labels.logging.Common.Header.CloseAction);
        } else if (this.leftSubTitle === this.labels.common.leftSubTitle.backConfirm) {
            this.handleCancelClickEmitter('backConfirm');
            this.operationLogging(this._labels.logging.Common.Header.BackToConfirm);
        }
    }

    private initializeChatComponent() {
        this.action.submitDataBackup();
        this.action.clearShowChats();
        this.action.initializeDataArr();
        switch (this.name) {
            case 'parentalAddress': {
                this.action.clearParentalAddress();
                break;
            }
            case 'employmentAddress': {
                this.action.clearEmploymentAddress();
                break;
            }
            case 'loanApplication': {
                this.action.setStateSubmitDataValue({ name: 'overdraftLimit', value: null });
                break;
            }
        }
        if (this.currentPageIndex === 198) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, 'CreditCardConfirmCommonComponent');
        } else if (this.currentPageIndex === 96) {
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, 'CreditCardConfirmJcbCommonComponent');
        }
        this.getNextAnswer(this.startOrder, this.currentPageIndex);
    }

    /**
     * add operation log
     */
    private operationLogging(value: string) {
        const params = {
            screenName: this._labels.logging.Common.ScreenName,
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: value
        };
        this.loggingService.log(this.loggingService.generalOperationParams(params));
    }

    /**
     * 次のノードを取得する
     * @param order メッセージの番号
     * @param pageIndex ページ番号
     */
    private getNextAnswer(order: number, pageIndex: number) {
        if (this.startOrder != null && this.endOrder != null && order > this.endOrder) {
            this.action.setEditedList(this.name);
            this.checkAnswers();
            this.viewCtrl.dismiss();
            return;
        }
        Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
            this.action.getNextChatByAnswer(order, pageIndex);
        });
    }

    /**
     * コンポーネントタイプにより、各レンダラをマッピング
     * @param componentType コンポーネントタイプ
     */
    private mappingComponentList(componentType: string): CreditCardChatFlowRenderer {
        let render: CreditCardChatFlowRenderer;
        if (componentType === 'CreditCardConfirmCommonComponent' || componentType === undefined) {
            render = new CreditCardConfirmCommonRenderer(this.chatFlowAccessor,
                this.footerContent, this.store, this.modalService, this.creditCardUtil, this.loginStore);
        } else if (componentType === 'CreditCardConfirmJcbCommonComponent') {
            render = new CreditCardConfirmJcbCommonRenderer(this.chatFlowAccessor,
                this.footerContent, this.store, this.modalService, this.loginStore, this.deviceService);
        }
        return render;
    }

    /**
     * Get page component
     * @param componentType コンポーネントタイプ
     */
    private getPageComponent(pageIndex: number, componentType?: string): CreditCardChatFlowRenderer {
        if (this.pageComponentList[pageIndex] == null) {
            this.pageComponentList[pageIndex] = this.mappingComponentList(componentType);
            this.pageComponentList[pageIndex].nextChatEvent.subscribe((params) => {
                this.getNextAnswer(params.order, params.pageIndex);
            });
        }

        this.topBlockView.nativeElement.style.height = '0px';

        if (this.chatFlowAccessor) {
            this.chatFlowAccessor.setRenderer(this.pageComponentList[pageIndex]);
            this.chatFlowAccessor.setContent(this.content);
        }
        return this.pageComponentList[pageIndex];
    }

    /**
     * 修正チャットの回答内容を確認し、処理を行う。
     */
    private checkAnswers() {
        this.state.editedKeysArr.forEach((element) => {
            switch (element) {
                case 'parentalHolderAddressPrefecture': {
                    if (!this.state.submitData.parentalFirstZipCode && !this.state.submitData.parentalLastZipCode) {
                        if (this.state.submitData.parentalHolderAddressPrefecture &&
                            this.state.submitData.parentalHolderAddressCountyUrbanVillage) {
                            this.action.getHolderZipCodeSelected(
                                this.state.submitData.parentalHolderAddressPrefecture,
                                this.state.submitData.parentalHolderAddressCountyUrbanVillage,
                                this.state.submitData.parentalHolderAddressStreetNameSelect
                                    ? this.state.submitData.parentalHolderAddressStreetNameSelect
                                    : this.state.submitData.parentalHolderAddressStreetNameInput
                                    ? this.state.submitData.parentalHolderAddressStreetNameInput
                                    : '',
                                'parentalAddress');
                        } else {
                            this.action.setDefaultToSelectedZipCode('parentalAddress');
                        }
                    }
                    break;
                }
                case 'employmentHolderAddressPrefecture': {
                    if (!this.state.submitData.employmentFirstZipCode && !this.state.submitData.employmentLastZipCode) {
                        if (this.state.submitData.employmentHolderAddressPrefecture &&
                            this.state.submitData.employmentHolderAddressCountyUrbanVillage) {
                            this.action.getHolderZipCodeSelected(
                                this.state.submitData.employmentHolderAddressPrefecture,
                                this.state.submitData.employmentHolderAddressCountyUrbanVillage,
                                this.state.submitData.employmentHolderAddressStreetNameSelect
                                    ? this.state.submitData.employmentHolderAddressStreetNameSelect
                                    : this.state.submitData.employmentHolderAddressStreetNameInput
                                    ? this.state.submitData.employmentHolderAddressStreetNameInput
                                    : '',
                                'employmentAddress');
                        } else {
                            this.action.setDefaultToSelectedZipCode('employmentAddress');
                        }
                    }
                    break;
                }
                case 'closeAndNotSave': {
                    this.action.resetShowConfirm(this.originShowConfirm);
                    this.action.resetShowChats(this.originShowChats, this.originSubmitData);
                    break;
                }
            }
        });
    }
}
