import { ViewContainerRef } from '@angular/core';
import { DeviceService } from 'dhd/common/services/device.service';
import { ChangeConfirmComponent } from 'dhdt/branch/pages/change/view/change-confirm.component';
import {
    ApplyBC, ApplyBizCategory, BusinessCode, COMMON_CONSTANTS, CoreBankingConst, CountryCode, HostErrorCodeReceptionNG,
    IdentificationCode, TEMPLATE_FILE
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardChatFlowAccessor } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.accessor';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import { ReceptionStatus } from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { AcceptionResult } from 'dhdt/branch/pages/creditcard/entity/creditcard-bc-result';
import { CreditCardQuestionsModel } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { CreditCardSignal, CreditCardState, CreditCardStore, } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { DialogComponent } from 'dhdt/branch/shared/components/dialog/dialog.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { AccountBalanceInquiryInterface } from 'dhdt/branch/shared/interface/account-balance-inquiry.interface';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { ModalController, NavController, NavParams } from 'ionic-angular';

export class CreditCardCommonRenderer extends CreditCardChatFlowRenderer {
    public processType = 1;
    public submitData: any;
    private state: CreditCardState;

    constructor(
        private chatFlowAccessor: CreditCardChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: CreditCardStore,
        private modalCtrl: ModalController,
        private navCtrl: NavController,
        private loginStore: LoginStore,
        private modalService: ModalService,
        private deviceService: DeviceService,
        private audioService: AudioService,
        private action: CreditCardAction,
        private params: NavParams

    ) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
    }

    /**
     * YMLファイル読み込み
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.submitData = this.params.get('submitData');
            // BC本チャット暗証番号エラーチェックのため、電話番号情報を加工
            // BC単体、もしくは既存新規電話番号変更なしの場合
            this.action.setStateSubmitDataValue({ name: 'holderTelNo1', value: this.submitData.holderTelNo1 });
            this.action.setStateSubmitDataValue({ name: 'holderTelNo2', value: this.submitData.holderTelNo2 });
            this.action.setStateSubmitDataValue({ name: 'holderTelNo3', value: this.submitData.holderTelNo3 });
            if (this.state.submitData.applyBizCategory === ApplyBizCategory.FOREIGN_NATIONALITY) {
                // 純新規外国人複合取引の場合
                this.action.setStateSubmitDataValue({ name: 'holderMobileNo', value: this.submitData.holderMobileNo });
                this.action.setStateSubmitDataValue({ name: 'holderTelephoneNo', value: this.submitData.holderTelephoneNo });
            } else {
                // 純新規日本人と既存新規電話番号変更ありの場合
                this.action.setStateSubmitDataValue({ name: 'holderMobileNo', value: this.submitData.existingChangeHolderMobileNo });
                this.action.setStateSubmitDataValue({ name: 'holderTelephoneNo', value: this.submitData.existingChangeHolderTelephoneNo });
            }
            this._action.loadTemplate(TEMPLATE_FILE.CREDIT_CARD_COMPOSIT, pageIndex);
        } else {
            this._action.loadTemplate(TEMPLATE_FILE.CREDIT_CARD_COMMON, pageIndex);
        }
    }

    /**
     * タイプにより、各コンポーネントをレンダリング
     * @param question ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public rendererComponents(question: CreditCardQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD: {
                this.onPassword(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_BASICINFO: {
                this.onSelectbasic(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_ACCOUNTSHOP: {
                this.onAccountShop(question, pageIndex);
                break;
            }
        }
    }

    /**
     * パスワードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onPassword(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const param = {
            tabletApplyId: this.state.tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            terminalNo: this.deviceService.getDeviceId(),
            accountNo: this.state.submitData.swipeAccountNo,
            tenban: this.state.submitData.swipeBranchNo,
            accountType: this.state.submitData.swipeAccountType
        };

        const modal = this.modalCtrl.create(ModalPasswordComponent,
            {
                data: {
                    text: this.labels.password.text,
                    subText: this.labels.creditcard.titlePassword,
                    units: 4,
                    errorMessage: this.labels.password.errMessage,
                    needConfirm: false,
                    cashcardParams: param
                }
            },
            { cssClass: 'settings-modal', enableBackdropDismiss: false });

        modal.onDidDismiss((value) => {
            // 暗証番号認証後、諸届変更画面へ遷移する
            if (value) {
                // CIF情報照会ハンドル
                const cifParam: SimpleCifInfoInquiryInterface = {
                    path: CoreBankingConstants.ApiPathConsts.CIF_INFO_INQUIRY,
                    tabletApplyId: this.state.tabletApplyId,
                    userMngNo: this.loginStore.getState().bankclerkId,
                    params: {
                        bankNo: CoreBankingConst.bankNo,
                        receptionTenban: this.state.submitData.receptionBranchNo,
                        receptionNo: this.state.submitData.receptionNo,
                        terminalNo: this.deviceService.getDeviceId(),
                        tenban: this.state.submitData.swipeBranchNo,
                        accountNo: this.state.submitData.swipeAccountNo,
                        accountType: this.state.submitData.swipeAccountType
                    }
                };

                const inputParams = {
                    tabletApplyId: this.state.tabletApplyId,
                    swipeCif: this.state.submitData.swipeCif || '1234567',
                    branchNo: this.state.submitData.swipeBranchNo || '123',
                    accountNo: this.state.submitData.swipeAccountNo || '1234567',
                    accountType: this.state.submitData.swipeAccountType,
                    receptionBranchNo: this.state.submitData.receptionBranchNo,
                    receptionNo: this.state.submitData.receptionNo,
                    receptionTime: this.state.submitData.receptionTime,
                    password: value,
                };

                // 口座残高情報照会を呼び出す
                const accountBalanceParam: AccountBalanceInquiryInterface = {
                    path: CoreBankingConstants.ApiPathConsts.ACCOUNT_BALANCE_INQUIRY,
                    tabletApplyId: this.state.tabletApplyId,
                    userMngNo: this.loginStore.getState().bankclerkId,
                    params: {
                        bankNo: CoreBankingConst.bankNo,                                 // 銀行番号
                        receptionTenban: this.state.submitData.receptionBranchNo,  // 受付店番
                        receptionNo: this.state.submitData.receptionNo,            // 受付番号
                        terminalNo: this.deviceService.getDeviceId(),            // 端末番号
                        accountInfoList: [{
                            tenban: this.state.submitData.swipeBranchNo,
                            accountNo: this.state.submitData.swipeAccountNo,
                            accountType: COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL
                        }]
                    }
                };

                this.navCtrl.push(
                    ChangeConfirmComponent,
                    {
                        type: COMMON_CONSTANTS.BusinessFlowType.CreditCard,
                        processType: COMMON_CONSTANTS.ProcessType.RequiredInput,
                        cifParam: cifParam,
                        inputParams: inputParams,
                        callBack: () => {
                            this._action.getCifInformation(cifParam, accountBalanceParam);
                            this.store.registerSignalHandler(CreditCardSignal.GET_CIF_INFO_COMPLETE, () => {
                                this._action.getNextChatByAnswer(entity.next, pageIndex);
                            });
                        }
                    },
                    { animate: false }
                );
            }
        });
        modal.present();
    }

    public onSelectbasic(entity: CreditCardQuestionsModel, pageIndex: number): void {
        this.getNextChat(entity.next, pageIndex);

    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value }
                    ]
                });
            }
            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * 選択内容を表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: CreditCardQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        let skipFlg: boolean;
        skipFlg = false;
        if (entity.options === 'credit') {
            switch (entity.name) {
                // 国籍判定
                case 'nationalityCode': {
                    judgeResult = this.state.submitData.nationalityCode === CountryCode.Japan ? '01' : '02';
                    break;
                }
                // 顧客年齢判定
                case 'creditCardAgeFlg': {
                    if (this.state.submitData.ageClassification === '1') {
                        judgeResult = '1';
                    } else if (this.state.submitData.ageClassification === '2') {
                        judgeResult = '2';
                    } else if (this.state.submitData.ageClassification === '3') {
                        judgeResult = '4';
                    } else if (this.state.submitData.ageClassification === '4') {
                        judgeResult = '5';
                    }
                    break;
                }
                // BC申込チェック
                case 'bankCardCheck':
                    skipFlg = true;
                    this.bankCardApplyCheckApi(entity, pageIndex);
                    break;
                case 'identificationCode': {
                    judgeResult = (this.state.submitData.identificationCode !== IdentificationCode.CODE_99) ? '00' : '99';
                    break;
                }
            }
            if (!skipFlg) {
                this.goToNextChat(entity, judgeResult, pageIndex);
            }
        }
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });

                        const resetResultList = InputUtils.holderNameReset(entity.name, this.state.submitData);

                        if (resetResultList) {
                            resetResultList.forEach((resetResult) => {
                                this._action.setStateSubmitDataValue({
                                    name: resetResult.key,
                                    value: resetResult.value
                                });
                            });
                        }
                        this.getNextChat(entity.next, pageIndex);
                    });
                }
            });
    }

    /**
     * アカウントショップコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onAccountShop(entity: CreditCardQuestionsModel, pageIndex: number): void {
        this.getNextChat(entity.next, pageIndex);
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.chatFlowCompelete(action.value);
        }
    }

    /**
     * 受付可否チェックAPIリクエストに使うパラメータ
     *
     * @private
     * @returns
     * @memberof ExistingAccountChangeRenderer
     */
    private makeAcceptCheckApiParams() {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((cifInfo) => {
            accounts.push({
                customerId: cifInfo.customerId,
            });
        });

        const acceptCheckApiParams = {
            tabletApplyId: this.state.submitData.tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                accounts: accounts,
                businessCode: BusinessCode.COMMON_NG
            }
        };

        return acceptCheckApiParams;
    }

    /**
     * BC申込チェック
     */
    private bankCardApplyCheckApi(entity: CreditCardQuestionsModel, pageIndex: number) {
        let judgeResult: string = '';
        let tempResult: any;
        // 普通預金口座開設_キャッシュカードスワイプなしの場合、
        if (this.state.submitData.cardInfo === undefined) {
            judgeResult = '02';
            this.goToNextChat(entity, judgeResult, pageIndex);
        } else {
            // 受信
            this.store.registerSignalHandler(CreditCardSignal.BC_APPLY, (data: AcceptionResult[]) => {
                this.store.unregisterSignalHandler(CreditCardSignal.BC_APPLY);
                tempResult = this.checkAllAcceptionResult(data);
                if (tempResult === ReceptionStatus.YES || tempResult === ReceptionStatus.NO) {
                    judgeResult = tempResult === ReceptionStatus.NO ? '01' : '02';
                    this.goToNextChat(entity, judgeResult, pageIndex);
                } else {
                    this.showErrorModal(tempResult);
                }
            });
            // 送信開始
            this.action.bankCardApplyCheck(this.makeAcceptCheckApiParams());
        }
    }

    /**
     * BC受付可否チェックAPI
     * @param {*} params
     */
    private checkAllAcceptionResult(params: AcceptionResult[]) {
        for (const data of params) {
            const errorInfo = this.checkErrorCode(data);
            if (!errorInfo) {
                if (this.getBcHoldingStatus(data) === ReceptionStatus.NO) {
                    return ReceptionStatus.NO;
                }
            } else {
                return errorInfo;
            }
        }
        return ReceptionStatus.YES;
    }

    private showErrorModal(errorInfo: any) {
        const errorParams = {
            imgSrc: 'icon_hourgrass@2x.png',
            message: this.labels.common.error.host.support,
            subMessage: `<span class="font-color-red">（${errorInfo.errorCode} ${errorInfo.unacceptableCode}）</span>`,
            buttonList: [{ text: 'OK', buttonValue: 'ok' }]
        };
        const errorModal = this.modalCtrl.create(
            DialogComponent, errorParams, { cssClass: 'settings-error-modal', enableBackdropDismiss: false }
        );
        this.audioService.subject.next(true);
        errorModal.present();
    }

    private checkErrorCode(acceptCheckResult: AcceptionResult) {
        let errorInfo: any;

        // 返却されたエラーコードが、受付可否チェック検出対象かを確認する。
        function isHostError(errorCode: string): boolean {
            return (Object.keys(HostErrorCodeReceptionNG).some((key) => HostErrorCodeReceptionNG[key] === errorCode));
        }

        for (const account of acceptCheckResult.accounts) {
            if (isHostError(account.errorCode)) {
                let unacceptables = '';
                for (const unacceptable of account.unacceptables) {
                    unacceptables = unacceptables + '/' + unacceptable.unacceptableCode;
                }
                unacceptables = unacceptables.substr(0, 1) === '/' ? unacceptables.substr(1) : unacceptables;
                errorInfo = {
                    errorCode: account.errorCode,
                    unacceptableCode: unacceptables
                };
            }
        }
        return errorInfo;
    }

    private getBcHoldingStatus(acceptCheckResult: AcceptionResult): string {
        let result: boolean = false;
        console.log(acceptCheckResult);
        for (const account of acceptCheckResult.accounts) {
            if (account.tradingConditions.length > 0) {
                result = true;
                break;
            }
        }
        return result ? ReceptionStatus.NO : ReceptionStatus.YES;
    }

    private goToNextChat(entity: CreditCardQuestionsModel, judgeResult: string, pageIndex: number) {
        entity.choices.forEach((choice) => {
            if (judgeResult === choice.value) {
                this.getNextChat(choice.next, pageIndex);
                return;
            }
        });
    }
}
