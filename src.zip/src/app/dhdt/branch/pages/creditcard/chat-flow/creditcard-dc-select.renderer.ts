import { NgZone, ViewContainerRef } from '@angular/core';
import { IsCompositApply, MaxLength} from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PrintNameInputComponent } from 'dhdt/branch/shared/components/print-name-input/print-name-input.component';

import { InjectionUtils } from 'adep/utils';
import { AccountType, ApplyBC, COMMON_CONSTANTS, IdentificationCode, TEMPLATE_FILE } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardChatFlowAccessor } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.accessor';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import { CreditCardQuestionsModel } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { CardSelectorComponent } from 'dhdt/branch/shared/components/card-selector/view/card-selector.component';
import { MultiButtonGroupComponent } from 'dhdt/branch/shared/components/multi-button-group/multi-button-group.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { QuantityInputComponent } from 'dhdt/branch/shared/components/quantity-input/quantity-input.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { CreditCardUtil } from 'dhdt/branch/shared/utils/creditcard-util';
import { KanaToRomaji } from 'dhdt/branch/shared/utils/kana-to-romaji-util';

export class CreditCardDCSelectRenderer extends CreditCardChatFlowRenderer {
    public processType = 1;
    private state: CreditCardState;
    private zone: NgZone;

    constructor(
        private chatFlowAccessor: CreditCardChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private action: CreditCardAction,
        private store: CreditCardStore,
        private modalService: ModalService,
        private audioService: AudioService,
        private creditCardUtil: CreditCardUtil,
    ) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
        this.zone = InjectionUtils.injector.get(NgZone);
    }

    /**
     * YMLファイル読み込み
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(TEMPLATE_FILE.CREDIT_CARD_DC, pageIndex);
    }

    /**
     * タイプにより、各コンポーネントをレンダリング
     * @param question ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public rendererComponents(question: CreditCardQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_MODAL_CONFIRM: {
                this.onModal(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_CARD_BUTTON: {
                this.onCardButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_TITLE_BUTTON:
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON:
            case COMMON_CONSTANTS.ELEMENT_TYPE_TWOCOLS_BUTTON: {
                this.onButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_PRINTNAME: {
                this.onPrintName(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_RESIDENCE_YEAR_PICKER: {
                this.onPicker(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_DEPOSIT_TENTHOUSAND:
            case COMMON_CONSTANTS.ELEMENT_TYPE_NUMBER_PEOPLE: {
                this.onQuantityInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_MULTI_BUTTON: {
                this.onMulitButton(question, pageIndex);
                break;
            }
        }
    }

    /**
     * アカウントショップコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onModal(entity: CreditCardQuestionsModel, pageIndex: number): void {
        this.modalService.showModal(entity.type, {
            jcbCardExtage: false
        }, () => {
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * カードをダリング
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onCardButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, CardSelectorComponent, this.footerContent, options)
            .subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer({
                    text: answer.text,
                    // cardTypeのkeysArr登録回避、およびチャット画面へ回答表示のため、ダミーを登録
                    value: [{ key: 'cardDummy', value: '1' }]
                });
                this.setCardBrankAndRank(answer);
                this.getNextChat(answer.next, pageIndex);
            });
    }

    /**
     * クレジットカードのブランドとランクを設定
     * @param answer ボタン選択の結果
     */
    public setCardBrankAndRank(answer: any) {
        if (answer.cardBrand !== '0' && answer.cardRank !== '0' && answer.applyType !== '0' && answer.value !== '00') {
            const params = {
                applyType: answer.applyType,    // お申込み種類
                cardBrand: answer.cardBrand,    // ブランド
                cardRank: answer.cardRank,      //  カードランク
                cardType: answer.value          //  カード種類
            };
            this._action.setCreidtCardBrandAndRank(params);
        }
    }

    /**
     * カード券面を入力する
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onPrintName(entity: CreditCardQuestionsModel, pageIndex: number): void {
        let names;
        if (this.state.submitData.nameAlphabet === null || !this.state.submitData.nameAlphabet) {
            if (this.state.submitData.existingChangeFirstNameKana) {
                names = [this.state.submitData.existingChangeFirstNameKana,
                    this.state.submitData.existingChangeLastNameKana];
            } else {
                names = this.state.submitData.nameKana.split(COMMON_CONSTANTS.FULL_SPACE);
            }
        }

        const kanaToRomaji = new KanaToRomaji();
        const options = {
            validationRules: entity.validationRules,
            defaultValues: this.state.submitData.nameAlphabet
                ? [this.state.submitData.nameAlphabet, '']
                : [kanaToRomaji.convert(names[1]) + ' ' + kanaToRomaji.convert(names[0]), ''],
            maxLength: MaxLength.MAX_LENGTH_19,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PrintNameInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer.text.indexOf(COMMON_CONSTANTS.HALF_POINT_NO_SPACE) !== -1) {
                    answer.text = answer.text.replace(/\./g, COMMON_CONSTANTS.FULL_POINT);
                }
                // 最初の半角スペースによってローマ字氏名を分割する。
                // 前の部分をprintFirstNameとして、後ろの部分はprintLastNameとして
                const printFullName = answer.value[0].value;
                const firstSpaceIndex = printFullName.indexOf(COMMON_CONSTANTS.SPACE);
                const printFirstName = printFullName.substring(0, firstSpaceIndex);
                const printLastName = printFullName.substring(firstSpaceIndex + 1);
                const answerValue = [
                    {
                        key: 'printFirstName',
                        value: printFirstName
                    },
                    {
                        key: 'printLastName',
                        value: printLastName
                    },
                ];
                this.setAnswer({ text: answer.text, value: answerValue});
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * Pickerコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onPicker(entity: CreditCardQuestionsModel, pageIndex: number): void {
        // 居住年数が年齢以上で入力できない
        if (entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_RESIDENCE_YEAR_PICKER) {
            const age = this.creditCardUtil.calculateAge(this.state.submitData.birthdate);
            entity.validationRules.range[1] = age;
        }
        const colNum = entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_PICKER ? '2' : '1';
        const options = {
            type: entity.type,
            name: entity.name,
            validationRules: entity.validationRules,
            defaultIndex: entity.options.defaultIndex,
            maxColNum: colNum,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * 金額入力コンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onQuantityInput(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            unit: entity.options ? entity.options.unit : undefined,
            validationRules: entity.validationRules,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, QuantityInputComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        let options: any;

        switch (entity.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_TWOCOLS_BUTTON: {
                options = { maxColNum: 2 };
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON: {
                options = { maxColNum: 3 };
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_TITLE_BUTTON: {
                options = { title: entity.options ? entity.options.title : undefined };
                break;
            }
            default: {
                options = { title: entity.options ? entity.options.title : undefined };
                break;
            }
        }

        const logInfo = {
            screenName: this._store.getState().currentFileInfo.screenId,
            yamlId: this._store.getState().currentFileInfo.yamlId,
            yamlOrder: entity.order,
        };
        Object.defineProperty(options, COMMON_CONSTANTS.TYPE_LOGINFO, { value: logInfo });

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value }
                    ]
                });
            }
            if (entity.name === 'cardBrand' || entity.name === 'cardType') {
                this.setCardBrankAndRank(answer);
            }
            if (answer.action.type.length > 0) {
                this.configAction(answer);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * マルチボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onMulitButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxLength: entity.validationRules.max
        };
        this.chatFlowAccessor.addComponent(entity.choices, MultiButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value }
                    ]
                });
            }

            this.chatFlowAccessor.clearComponent();

            const next = answer.next.split('、')[0];
            this.getNextChat(Number.parseInt(next), pageIndex);
        });
    }

    /**
     * 選択内容を表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: CreditCardQuestionsModel, pageIndex: number): void {
        let judgeResult: string;

        if (entity.choices) {
            switch (entity.name) {
                case 'isForeigner': {
                    judgeResult = !this.state.submitData.nameAlphabet ? '01' : '02';
                    break;
                }
                case 'checkComposit': {
                    judgeResult = this.state.submitData.ifApplyBC === ApplyBC.YES ?
                    IsCompositApply.YES : IsCompositApply.NO;
                    break;
                }
                case 'identificationCode': {
                    judgeResult = '01' ;
                    // 既保持者 の場合
                    if (this.state.submitData.accountType === AccountType.CREDIT_CARD) {
                        judgeResult = this.state.submitData.identificationCode ?
                        (this.state.submitData.identificationCode === IdentificationCode.CODE_80 ? '01' : '02') : '01';
                    // スワイプなし
                    } else if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT) {
                        judgeResult = this.state.submitData.identificationCode ?
                        (this.state.submitData.identificationCode === IdentificationCode.CODE_80 ? '01' : '02') : '01';
                    }
                    break;
                }
                default: {
                    entity.choices.forEach((choice) => {
                        if (this.state.submitData[entity.name] === choice.value) {
                            this.getNextChat(choice.next, pageIndex);
                            return;
                        }
                    });
                }
            }
            entity.choices.forEach((choice) => {
                if (choice.value === judgeResult) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: this._labels.creditcard.modal.skip, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    private configAction(choice: any) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.chatFlowCompelete(action.value);
        }
    }
}
