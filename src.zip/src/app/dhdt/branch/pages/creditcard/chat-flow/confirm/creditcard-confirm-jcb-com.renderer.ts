import { ViewContainerRef } from '@angular/core';
import { InjectionUtils, ObjectUtils } from 'adep/utils';
import { DeviceService } from 'dhd/common/services/device.service';
import {
    ChatOption, COMMON_CONSTANTS, CoreBankingConst, PasswordVerify, TEMPLATE_FILE
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardChatFlowAccessor } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.accessor';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import { CreditCardConsts, FamilyMemberAgeRange, MaxLength } from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardQuestionsModel } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/creditcard/service/backup-data.service';
import { CreditCardSignal, CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { SelectAddressCommonComponent } from 'dhdt/branch/shared/components/address/view/select-address-common.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { CardListComponent } from 'dhdt/branch/shared/components/card-list/card-list.component';
import { DepositInputComponent } from 'dhdt/branch/shared/components/deposit-input/deposit-input.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { PrintNameInputComponent } from 'dhdt/branch/shared/components/print-name-input/print-name-input.component';
import { QuantityInputComponent } from 'dhdt/branch/shared/components/quantity-input/quantity-input.component';
import { ExistingPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/existing-password-rule-check.interface';
import { NewPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/new-password-rule-check.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
export class CreditCardConfirmJcbCommonRenderer extends CreditCardChatFlowRenderer {
    public processType = 1;
    private state: CreditCardState;
    private replaceValues: Array<{ key: string, value: string }>;

    constructor(
        private chatFlowAccessor: CreditCardChatFlowAccessor, private footerContent: ViewContainerRef,
        private store: CreditCardStore, private modalService: ModalService, private loginStore: LoginStore,
        private deviceService: DeviceService
    ) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
    }

    /**
     * YMLファイル読み込み
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(TEMPLATE_FILE.CREDIT_CARD_CONFIRMPAGE_JCB_COM, pageIndex);
    }

    /**
     * タイプにより、各コンポーネントをレンダリング
     * @param question ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public rendererComponents(question: CreditCardQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_TITLE_BUTTON:
            case COMMON_CONSTANTS.ELEMENT_TYPE_TWOCOLS_BUTTON:
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON: {
                this.onButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_PRINTNAME: {
                this.onPrintName(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_YEARMONTH_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_PREFECTURE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_COUNTYURBANVILLAGE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_YEAR_PICKER_IYOCA: {
                this.onPicker(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_DATE_PICKER: {
                this.onFamilyPicker(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_DEPOSIT_TENTHOUSAND: {
                this.onDepositInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECTADDRESS: {
                this.onSelectAddress(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECTSTREET: {
                this.onSelectStreet(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4: {
                this.onPasswordInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_NUMBER_THOUSAND: {
                this.onQuantityInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_CARD: {
                this.onCard(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.CONFIG_URL: {
                this.configUrl(question, pageIndex);
                break;
            }
        }
    }

    /**
     * カード券面を入力する
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onPrintName(entity: CreditCardQuestionsModel, pageIndex: number): void {
        // familyMemberNameRomaのplace holderセット
        if (entity.name === 'familyMemberNameRoma') {
            if (!this.state.submitData.cardFamilyMemberFirstName) {
                const params = {
                    familyMemberFirstNameKana: this.state.submitData.familyMemberFirstNameKana,
                    familyMemberLastNameKana: this.state.submitData.familyMemberLastNameKana
                };
                this._action.setfamilyMemberNameRoma(params);
            }
        }

        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getCreditCardDefaultValues(entity.name, this.state.submitData),
            maxLength: MaxLength.MAX_LENGTH_17,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PrintNameInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer({ text: answer.text, value: answer.value });
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * Pickerコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onPicker(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            defaultIndex: entity.options ? entity.options.defaultIndex : undefined,
            title: entity.options ? entity.options.title : undefined,
            validationRules: entity.validationRules,
            submitData: this.state.submitData,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    if (entity.name === 'parentalAddressPrefecture' ||
                        entity.name === 'parentalAddressCountyUrbanVillage') {
                        answer.value = this.replaceHolder2Parental(answer.value);
                    }
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * FamilyPickerコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onFamilyPicker(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            validationRules: entity.validationRules,
            submitData: this.state.submitData,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);

                if (InputUtils.validateAge(answer.value[0].value, 18, this.state.submitData.customerApplyStartDate)) {
                    // 満18歳の場合、家族会員の申し込むフローを続ける。
                    const params = {
                        memberAgeFlg: FamilyMemberAgeRange.ABOVE_18,
                        familyCard: CreditCardConsts.FamilyCardApply.Apply
                    };
                    this._action.setMemberAgeFlg(params);
                } else {
                    // 18歳未満の場合、家族会員の申し込むが中止になって、支払方法フローへ進める。
                    const params = {
                        memberAgeFlg: FamilyMemberAgeRange.BELOW_18,
                        familyCard: CreditCardConsts.FamilyCardApply.NotApply
                    };
                    this._action.setMemberAgeFlg(params);
                }

                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * 金額入力コンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onDepositInput(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            validationRules: entity.validationRules,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, DepositInputComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * 住所コンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onSelectAddress(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            submitData: this.state.submitData,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.type, SelectAddressCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer.value) {
                    if (entity.name === 'parentalAddress') {
                        answer.value = this.replaceHolder2Parental(answer.value);
                    }
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                } else {
                    if (answer !== COMMON_CONSTANTS.SIGN_SKIP) {
                        this.setAnswer(answer);
                    }
                    const preNode = this.state.showChats[this.state.showChats.length - 2];
                    this._action.resetLastNode({ order: preNode.skip, pageIndex: preNode.pageIndex });
                }
            });
    }

    /**
     * 町丁名コンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onSelectStreet(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const params = {
            prefectureCode: this.state.submitData.parentalAddressPrefectureCode,
            prefectureKanji: this.state.submitData.parentalAddressPrefecture,
            countyUrbanVillageCode: this.state.submitData.parentalAddressCountyUrbanVillageCode,
            countyUrbanVillageKanji: this.state.submitData.parentalAddressCountyUrbanVillage,
        };
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(params, SelectStreetComponent, this.footerContent, options)
            .subscribe((result: { isSkip: boolean, text: string, value: any }) => {
                this.chatFlowAccessor.clearComponent();

                const answer = {
                    text: result.text,
                    value: [
                        { key: 'parentalAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                        { key: 'parentalAddressStreetNameFuriKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) }
                    ]
                };
                this.setAnswer(answer);
                this.getNextChat(result.isSkip ? entity.skip : entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            maxColNum: (entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON) ? 3 : undefined,
            validationOn: null,
            kanaText: null,
            validationRules: null,
            title: null,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        if (entity.options && entity.options === ChatOption.VALIDATION_ON) {
            const backupDataService = InjectionUtils.injector.get(BackupDataService);
            options.validationOn = ChatOption.VALIDATION_ON;
            options.kanaText = backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }

        switch (entity.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_TWOCOLS_BUTTON: {
                options.maxColNum = 2;
                options.title = entity.options ? entity.options.title : undefined;
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON: {
                options.maxColNum = 3;
                options.title = entity.options ? entity.options.title : undefined;
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_TITLE_BUTTON: {
                options.title = entity.options ? entity.options.title : undefined;
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_BUTTON: {
                options.title = entity.options ? entity.options.title : undefined;
                break;
            }
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: this.replaceParams(answer.value) },
                        { key: answer.name, value: this.replaceParams(answer.value) }
                    ]
                });
            }
            if (answer.action.type.length > 0) {
                this.configAction(answer, pageIndex);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * 選択内容を表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: CreditCardQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {

        const choices = InputUtils.changeValidationRuleMax(entity, this.state.submitData);
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getCreditCardDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        this.getNextChat(entity.next, pageIndex);
                    });
                }
            });
    }

    /**
     * キャッシュカード口座入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onNumberKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this._action.clearSubmitData(entity.choices);
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * パスワードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onPasswordInput(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
        };

        this.chatFlowAccessor.addComponent(entity.choices, PasswordInputComponent,
            this.footerContent, options).subscribe((answer) => {

                // 暗証番号ルール適合性チェックを行う
                const existingParams: ExistingPasswordRuleCheckInterface = {
                    path: CoreBankingConstants.ApiPathConsts.PASSWORD_RULE_CHECK,
                    tabletApplyId: this.state.tabletApplyId,
                    userMngNo: this.loginStore.getState().bankclerkId,
                    params: {
                        bankNo: CoreBankingConst.bankNo,
                        receptionTenban: this.state.submitData.receptionBranchNo,
                        receptionNo: this.state.submitData.receptionNo,
                        terminalNo: this.deviceService.getDeviceId(),
                        passcodeType: entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4 ?
                            COMMON_CONSTANTS.PasscodeType.password4bits : COMMON_CONSTANTS.PasscodeType.password6bits,
                        passcode: answer.value[0].value,
                        tenban: this.state.submitData.swipeBranchNo,
                        accountNo: this.state.submitData.swipeAccountNo,
                        branchCif: this.state.submitData.swipeCif,
                        officeNo: this.state.submitData.getEmploymentTelephoneNo(),
                    }
                };

                // self params
                const selfParams: NewPasswordRuleCheckInterface = this.state.submitData.getEmploymentTelephoneNo() ? {
                    path: CoreBankingConstants.ApiPathConsts.PASSWORD_RULE_CHECK,
                    tabletApplyId: this.state.tabletApplyId,
                    userMngNo: this.loginStore.getState().bankclerkId,
                    params: {
                        bankNo: CoreBankingConst.bankNo,
                        receptionTenban: this.state.submitData.receptionBranchNo,
                        receptionNo: this.state.submitData.receptionNo,
                        terminalNo: this.deviceService.getDeviceId(),
                        passcodeType: entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4 ?
                            COMMON_CONSTANTS.PasscodeType.password4bits : COMMON_CONSTANTS.PasscodeType.password6bits,
                        passcode: answer.value[0].value,
                        birthday: this.state.submitData.holderBirthdate,
                        telephoneNo: '',
                        mobileNo: '',
                        officeNo: this.state.submitData.getEmploymentTelephoneNo()
                    }
                } : null;

                if (entity.name !== COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_CREDIT_FAMILY) {
                    // normal check
                    // 暗証番号ルール適合性チェックを行う
                    this.checkExistingPassword(existingParams, answer, entity, pageIndex, selfParams);
                } else {
                    // credit family check
                    // 暗証番号ルール適合性チェックを行う
                    this.checkFamilyPassword(existingParams, answer, entity, pageIndex, selfParams);
                }
            });
    }

    /**
     * 千円以上の金額入力コンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onQuantityInput(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            title: entity.options ? entity.options.title : undefined,
            unit: entity.options ? entity.options.unit : undefined,
            validationRules: entity.validationRules,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, QuantityInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * カードコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onCard(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, CardListComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value }
                ]
            });
            this.getNextChat(answer.next, pageIndex);
        });
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            this.modalService.showModal(action.value, { imgSrc: action.imgSrc });
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.chatFlowCompelete(action.value);
        }
    }

    /**
     * 質問文言をリプレースする
     * @param str 文言
     * @param type イメージ
     */
    private replaceParams(str: string): string {
        if (str.indexOf('@') === -1) {
            return str;
        }

        this.replaceValues = [
            { key: '@HolderMobileNo', value: this.state.submitData.holderMobileNo }
        ];

        let result = str;
        this.replaceValues.forEach((element) => {
            if (result.indexOf(element.key) !== -1) {
                result = result.replace(element.key, element.value);
            }
        });

        return result;
    }

    /**
     * 住所パラメータ名切替
     * @param param パラメータ
     */
    private replaceHolder2Parental(param: any) {
        return param.map((item) => {
            if (item.key !== undefined && item.key.indexOf('holder') !== -1) {
                item.key = item.key.replace('holder', 'parental');
            }
            return item;
        });
    }

    /*
     * Config url
     * @param entity params
     */
    private configUrl(entity, pageIndex) {
        if (entity.option === 'url') {
            const serverInfoService = InjectionUtils.injector.get(ServerInfoService);
            const submitData = this.state.submitData;

            let params;
            switch (entity.name) {
                case 'getAddressFromZipcode': {
                    let firstZipCode;
                    let lastZipCode;
                    if (submitData.firstZipCode) {
                        firstZipCode = submitData.firstZipCode;
                    }
                    if (submitData.lastZipCode) {
                        lastZipCode = submitData.lastZipCode;
                    }
                    const zipCode = firstZipCode + lastZipCode + '';
                    params = { zipCode: zipCode };
                    break;
                }
                case 'getStreetInitialsKana': {
                    let pregecture;
                    let village;
                    if (submitData.holderAddressPrefecture) {
                        pregecture = submitData.holderAddressPrefecture;
                    }
                    if (submitData.holderAddressCountyUrbanVillage) {
                        village = submitData.holderAddressCountyUrbanVillage;
                    }
                    params = {
                        prefectureKanji: pregecture,
                        countyUrbanVillageKanji: village
                    };
                    break;
                }
                case COMMON_CONSTANTS.STREET_PARENTAL: {
                    let pregecture;
                    let village;
                    if (submitData.parentalAddressPrefecture) {
                        pregecture = submitData.parentalAddressPrefecture;
                    }
                    if (submitData.parentalAddressCountyUrbanVillage) {
                        village = submitData.parentalAddressCountyUrbanVillage;
                    }
                    params = {
                        prefectureKanji: pregecture,
                        countyUrbanVillageKanji: village
                    };
                    break;
                }
            }
            serverInfoService.getInfoFormServe(entity.name, params).subscribe((result) => {
                entity.choices.forEach((choice) => {
                    if (result === choice.value) {
                        this._action.getNextChatByAnswer(choice.next, pageIndex);
                        return;
                    }
                });
            });
        }
    }

    private checkExistingPassword(existingParams, answer, entity, pageIndex, selfParams) {
        this._action.checkSelfPassword(existingParams, selfParams)
            .subscribe((ok) => {
                if (!ok) {
                    this.modalService.showAlert(
                        this.labels.error.passwordError,
                        null, 'icon_alert@2x.png', null, 'settings-alert-modal'
                    );
                } else {
                    this.chatFlowAccessor.clearComponent();
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    private checkFamilyPassword(existingParams, answer, entity, pageIndex, selfParams) {
        const familyParams: NewPasswordRuleCheckInterface = {
            path: CoreBankingConstants.ApiPathConsts.PASSWORD_RULE_CHECK,
            tabletApplyId: this.state.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            params: {
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                passcodeType: entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4 ?
                    COMMON_CONSTANTS.PasscodeType.password4bits : COMMON_CONSTANTS.PasscodeType.password6bits,
                passcode: answer.value[0].value,
                birthday: this.state.submitData.familyBirthdate,
                telephoneNo: this.state.submitData.holderTelephoneNo.replace(/[-]/g, ''),
                mobileNo: this.state.submitData.holderMobileNo.replace(/[-]/g, ''),
                officeNo: ''
            }
        };
        this._action.checkFamilyPassword(existingParams, familyParams, selfParams)
            .subscribe((ok) => {
                if (!ok) {
                    this.modalService.showAlert(
                        this.labels.error.passwordError,
                        null, 'icon_alert@2x.png', null, 'settings-alert-modal'
                    );
                } else {
                    this.chatFlowAccessor.clearComponent();
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }
}
