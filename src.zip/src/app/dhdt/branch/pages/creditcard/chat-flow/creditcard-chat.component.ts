import {
    AfterViewChecked, animate, ChangeDetectorRef, Component, ElementRef,
    NgZone, OnDestroy, OnInit, style, transition, trigger, ViewChild, ViewContainerRef
} from '@angular/core';
import { BaseComponent } from 'adep/components';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import {
    ExistingSavingsForeignInitConfirmComponent
} from 'dhdt/branch/pages/bank-savings-deposit/view/existing-savings-foreign/view/existing-savings-foreign-initconfirm.component';
import { BsdAgentConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/savings/bsd-agent-confirm.component';
import {
    AccountType, ApplyBC, ChatFlowChoicesValue, COMMON_CONSTANTS, Constants, EventsType, ReferenceFlg
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardAddressIdentificationRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-address-identification.renderer';
import { CreditCardBankCardRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-bankcard.renderer';
import { CreditCardChatFlowAccessor } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.accessor';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import { CreditCardCheckApplyRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-check-apply.renderer';
import { CreditCardCommonRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-common.renderer';
import { CreditCardDCSelectRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-dc-select.renderer';
import { CreditCardEmploymentRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-employment.renderer';
import {
    CreditCardIdentificationDocumentOneRender
} from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-identification-documentOne.render';
import {
    CreditCardIdentificationDocumentTwoRender
} from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-identification-documentTwo.render';
import {
    CreditCardIdentificationLicenseNoRender
} from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-identification-license-no.renderer';
import { CreditCardImgapplyRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-img-apply.renderer';
import { CreditCardStudentIdentificationRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-student-identification.renderer';
import { CreditCardStudentRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-student.renderer';
import { CreditCardStuffConfirmRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-stuff-confirm.renderer';
import { CreditCardTypeRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-type.renderer';
import { CreditCardJcbEmploymentRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/jcb/creditcard-jcb-employment.renderer';
import { CreditCardJcbFamilyRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/jcb/creditcard-jcb-family.renderer';
import { CreditCardJcbGuardianRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/jcb/creditcard-jcb-guardian.renderer';
import { CreditCardJcbStudentRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/jcb/creditcard-jcb-student.renderer';
import { CreditCardJcbTypeRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/jcb/creditcard-jcb-type.renderer';
import { CreditCardJcbRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/jcb/creditcard-jcb.renderer';
import { CreditCardSignal, CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { CreditCardInitConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-initconfirm.component';
import {
    ExistingSavingsContentConfirmComponent
} from 'dhdt/branch/pages/existing-savings/view/existing-savings-content-confirm.component';
import {
    ExistingSavingsInitConfirmComponent
} from 'dhdt/branch/pages/existing-savings/view/existing-savings-initconfirm.component';
import { ProcessItem } from 'dhdt/branch/shared/components/header/header.component';
import {
    AccountModalPasswordComponent
} from 'dhdt/branch/shared/components/modal/modal-password/view/account-modal-password.component';
import { ModalPdfScrollCheckComponent } from 'dhdt/branch/shared/components/modal/modal-pdf/modal-pdf-scroll-check.component';
import { ChatFlowHeaderInterfaces } from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { CreditCardUtil } from 'dhdt/branch/shared/utils/creditcard-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { App, Content, Events, ModalController, NavController, NavParams, ViewController } from 'ionic-angular';
import { Subscription } from 'rxjs';
import { Observable } from 'rxjs/Observable';

@Component({
    selector: 'creditcard-chat-component',
    templateUrl: 'creditcard-chat.component.html',
    animations: [
        trigger('ProgressBarAnimation', [
            transition('void => *', [
                style({ transformOrigin: '0 0 0', transform: 'translateY(-100%)' }),
                animate(
                    '300ms',
                    style({ transformOrigin: '0 0 0', transform: 'translateY(0)' })
                )
            ])
        ])
    ]
})

/**
 * control all chat page.
 */
export class CreditCardChatComponent extends BaseComponent implements AfterViewChecked, OnInit, OnDestroy {
    @ViewChild(Content) public content: Content;
    @ViewChild('footerContent', { read: ViewContainerRef }) public footerContent: ViewContainerRef;
    @ViewChild('topBlockView', { read: ElementRef }) public topBlockView: ElementRef;
    @ViewChild('bottomBlockView', { read: ElementRef }) public bottomBlockView: ElementRef;
    @ViewChild('audioView', { read: ElementRef }) public audioView: ElementRef;

    public subscription: Subscription;
    public audioSubscription: Subscription;

    public isPlaying: boolean = false;
    public chatFlowAccessor: CreditCardChatFlowAccessor;
    public state: CreditCardState;
    // is current page
    public isCurrentPage: boolean;
    public currentTitle: string = this._labels.creditcard.titleHeader;
    public needPassword: boolean = true;
    public showSkipToOrdinaryDeposit: boolean = false;
    public headerOptions: ChatFlowHeaderInterfaces.Options;
    public tabletApplyId: any;
    public displayTabletApplyId: boolean = false;

    public readonly imgDone: string = 'img-done';
    public readonly activeOne: string = 'img-active-one';
    public readonly nonActiveOne: string = 'img-non-active-one';
    public readonly activeTwo: string = 'img-active-two';
    public readonly nonActiveTwo: string = 'img-non-active-two';
    public readonly activeThree: string = 'img-active-three';
    public readonly nonActiveThree: string = 'img-non-active-three';
    public readonly activeFour: string = 'img-active-four';
    public readonly nonActiveFour: string = 'img-non-active-four';
    public readonly activeFive: string = 'img-active-five';
    public readonly nonActiveFive: string = 'img-non-active-five';

    // 研修環境かどうかをチェック
    public get isTrngEnv(): boolean {
        return InputUtils.isTrngEnv();
    }

    public processItems: ProcessItem[] =  [
        {
            type: COMMON_CONSTANTS.ProcessType.RequiredInput,
            value: this.labels.processType.requiredInput,
            achieve: false,
            imgSrc: this.nonActiveOne,
            imgSrcActive: this.activeOne
        },
        {
            type: COMMON_CONSTANTS.ProcessType.ApplyInfoConfirm,
            value: this.labels.processType.applyInfoConfirm,
            achieve: false,
            imgSrc: this.nonActiveTwo,
            imgSrcActive: this.activeTwo
        },
        {
            type: COMMON_CONSTANTS.ProcessType.BankClerkConfirm,
            value: this.labels.processType.bankClerkConfirm,
            achieve: false,
            imgSrc: this.nonActiveThree,
            imgSrcActive: this.activeThree
        },
        {
            type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
            value: this.labels.processType.completion,
            achieve: false,
            imgSrc: this.nonActiveFour,
            imgSrcActive: this.activeFour
        }
    ];

    // title info
    public showRightButton: boolean = true;
    public titleImgSrc: string = AppProperties.IMG_ROOT + 'common/img_logo@2x.png';
    public achieveImgSrc: string =  AppProperties.IMG_ROOT + 'common/icon_check_outline@2x.png';
    public backIconImgSrc: string =  AppProperties.IMG_ROOT + 'common/icon_back@2x.png';
    public bellIconImgSrc: string =  AppProperties.IMG_ROOT + 'common/icon_bell@2x.png';
    public showIconImgSrc: string = this.bellIconImgSrc;

    public leftSubTitle: string = this._labels.regular.holder.leftSubTitle;
    // ログインボタン押下時の二重リクエスト防止
    public isReturning: boolean = false;

    private currentPageComponent: CreditCardChatFlowRenderer;
    private currentPageIndex: number;
    private pageComponentList: CreditCardChatFlowRenderer[];

    private startOrder: number;
    private endOrder: number;
    private submitData: any;
    private options?: {
        component: string;
        title: string;
        process: number;
        clear: boolean;
        submitData: any;
    };

    constructor(
        private store: CreditCardStore, private action: CreditCardAction,
        private modalService: ModalService, private audioService: AudioService,
        private navCtrl: NavController, public changeDetectorRef: ChangeDetectorRef,
        private params: NavParams, public viewCtrl: ViewController,
        private modalCtrl: ModalController,
        private deviceService: DeviceService, private loginStore: LoginStore,
        private zone: NgZone,
        private editService: EditService,
        private creditCardUtil: CreditCardUtil,
        private loggingService: LoggingService,
        private app: App,
        private events: Events
    ) {
        super();

        this.subscription = this.audioService.subject.subscribe((status: boolean) => {
            if (this.audioView && this.audioView.nativeElement) {
                if (status) {
                    this.startAudio();
                } else {
                    this.stopAudio();
                }
            }
        });
        this.audioSubscription = this.audioService.audioSubject.subscribe((status: boolean) => {
            if (this.audioView && this.audioView.nativeElement) {
                if (status) {
                    this.startAudioWithoutModal();
                } else {
                    this.stopAudio();
                }
            }
        });
        this.events.unsubscribe(EventsType.AUDIO_PLAY);
        this.events.subscribe(EventsType.AUDIO_PLAY, (play) => {
            if (play) {
                if (!this.isPlaying) {
                    this.isPlaying = true;
                    this.audioView.nativeElement.load();
                    this.audioView.nativeElement.play();
                    this.stopAudio();
                }
            } else {
                this.stopAudio();
            }
        });

        this.pageComponentList = [];
        this.state = this.store.getState();
        this.chatFlowAccessor = new CreditCardChatFlowAccessor();
        this.options = params.get('options');

        if (this.options && this.options.submitData) {
            this.action.clearShowChats();
            this.action.setStateData(this.options);
        }
    }

    public ngOnInit() {

        if (this.params && this.params.get('tabletApplyId')) {
            this.action.setTabletApplyId({
                tabletApplyId: this.params.get('tabletApplyId')
            });
        }

        // tabletApplyIDの表示非表示設定
        if (AppProperties.DISPLAY_TABLET_APPLY_ID === 'true') {
            this.displayTabletApplyId = true;
            this.tabletApplyId = this.state.tabletApplyId || this.loginStore.getState().tabletApplyId;
        }
        this.submitData = this.params.get('submitData');
        this.startOrder = this.params.get('startOrder');
        this.endOrder = this.params.get('endOrder');
        this.isCurrentPage = this.params.get('isCurrentPage') ? true : false;
        this.currentTitle = this.params.get('isCurrentPage') ? this.params.get('currentTitle') : this._labels.creditcard.titleHeader;

        this.showRightButton = this.isCurrentPage ? false : true;

        if (this.isCurrentPage) {
            this.leftSubTitle = this.labels.header.back;
        } else {
            this.leftSubTitle = this.options && this.options.title === '本人確認書類' ?
            this.labels.common.leftSubTitle.backConfirm : this.labels.header.callBankclerk;
        }

        if (this.leftSubTitle === this.labels.header.callBankclerk) {
            this.showIconImgSrc = this.bellIconImgSrc;
        } else if (this.leftSubTitle === this.labels.header.back || this.leftSubTitle === this.labels.common.leftSubTitle.backConfirm) {
            this.showIconImgSrc = this.backIconImgSrc;
        }

        if (!this.submitData) {
            this.submitData = this.options.submitData;
        }

        // submitDataをセット
        if (this.submitData) {
            this.action.setData(this.submitData);
            this.action.setStateSubmitDataValue({name: 'editedList', value: undefined});
            // 複合取引(スワイプ無し)の時、年齢フラグを算出
            if (!this.state.submitData.ageClassification && this.state.submitData.birthdate) {
                const ageClass =
                    this.creditCardUtil.getAgeClassification(this.creditCardUtil.calculateAge(this.state.submitData.birthdate));
                this.action.setStateSubmitDataValue({name: 'ageClassification', value: ageClass});
            }
        }

        if (this.startOrder != null && this.endOrder != null && !this.options.component) {
            this.action.clearShowChats();
            let componentName = '';
            if (this.currentPageIndex === 0) {
                // クレジットカード共通
                componentName = 'CreditCardCommonComponent';
            } else if (this.currentPageIndex === 1) {
                // クレジットカードDC
                componentName = 'CreditCardDCSelectComponent';
            } else if (this.currentPageIndex === 2) {
                // クレジットカードEmployment
                componentName = 'CreditCardEmploymentComponent';
            } else if (this.currentPageIndex === 3) {
                // クレジットカードFamily
                componentName = 'CreditCardFamilyComponent';
            } else if (this.currentPageIndex === 4) {
                // クレジットカードType
                componentName = 'CreditCardTypeComponent';
            }
            this.action.submitDataBackup();
            this.currentPageComponent = this.getPageComponent(this.currentPageIndex, componentName);
            this.getNextAnswer(this.startOrder, this.currentPageIndex);
        } else {
            this.currentPageIndex = 0;
            this.currentPageComponent = this.options ?
                this.getPageComponent(0, this.options.component) : this.getPageComponent(0);
            if (this.state.submitData.ifApplyBC === ApplyBC.YES && this.currentPageComponent.processType ===
                COMMON_CONSTANTS.ProcessType.RequiredInput) {
                this.showSkipToOrdinaryDeposit = true;
            }
            setTimeout(() => {
                this.currentPageComponent.loadTemplate(0);
            }, 600);
        }

        this.store.registerSignalHandler(CreditCardSignal.CHAT_FLOW_COMPELETE, (nextChatName) => {
            if (nextChatName === 'top') {
                Observable.timer(Constants.PageConsts.backToTopStayTime).subscribe(() => {
                    this.navCtrl.setRoot(TopComponent);
                    this.chatFlowAccessor.clearComponent();
                });
            } else if (nextChatName === 'CreditCardInitConfirmComponent') {
                this.showModal();
            } else if (nextChatName === 'compelete') {
                this.viewCtrl.dismiss({
                    ...this.state
                });
            } else if (nextChatName === ChatFlowChoicesValue.BACK_TO_TOP) {
                Observable.timer(Constants.ZERO).subscribe(() => {
                    this.navCtrl.setRoot(TopComponent);
                    this.chatFlowAccessor.clearComponent();
                });
            } else {
                this.currentPageIndex += 1;
                this.currentPageComponent = this.getPageComponent(this.currentPageIndex, nextChatName);
                this.zone.run(() => {
                    Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                        this.currentPageComponent.loadTemplate(this.currentPageIndex);
                    });
                });

                this.chatFlowAccessor.clearComponent();
            }
        });

        // 前のチャットに戻る
        this.store.registerSignalHandler(CreditCardSignal.CHAT_FLOW_RETURN, (next) => {
            const copyShowChats = Array.from(this.state.showChats);
            const item = copyShowChats.reverse().find(
                (qus) => {
                    return qus.name === next.name && qus.type !== 'judge' && qus.type !== 'judge_1';
                }
            );

            this.toEditChat(item.order, item.pageIndex, item.answer.order, item.orderIndex);
        });
    }

    public ngOnDestroy() {
        this.chatFlowAccessor.destroy();
        this.store.unregisterSignalHandler(CreditCardSignal.GET_INFO_OCR_COMPLETE);
        this.store.unregisterSignalHandler(CreditCardSignal.CHAT_FLOW_COMPELETE);
        this.store.unregisterSignalHandler(CreditCardSignal.CHAT_FLOW_RETURN);
        this.subscription.unsubscribe();
        this.audioSubscription.unsubscribe();
    }

    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    public beforeAlert() {
        this.chatFlowAccessor.clearComponent();
    }
    public afterAlert() {
        const lastNode = this.state.showChats[this.state.showChats.length - 1];
        this.action.resetLastNode({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    /**
     * button click CallBack
     * @param order メッセージの番号
     * @param pageIndex ページ番号
     * @param answerOrder 回答順
     */
    public editCallBack(order: number, pageIndex: number, answerOrder: number, orderIndex: number) {
        this.editService.startEdit();
        this.beforeAlert();
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.editBtn, buttonValue: 'edit' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.editTitle,
            buttonList,
            (item) => {
                const preventedItem = this.editService.endEdit();
                if (item.buttonValue === 'edit') {
                    this.action.editChart(order, pageIndex, answerOrder, orderIndex);
                    this.chatFlowAccessor.clearComponent();
                    this.currentPageIndex = pageIndex;
                    this.currentPageComponent = this.getPageComponent(pageIndex);
                    this.getNextAnswer(order, pageIndex);
                    const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
                    this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
                } else {
                    if (preventedItem) {
                        this.getNextAnswer(preventedItem.order, preventedItem.pageIndex);
                    } else {
                        this.afterAlert();
                    }
                }
            },
            this.labels.alert.editSubTitle
        );
    }

    // left button click
    public leftBtnClick() {
        if (this.leftSubTitle === this.labels.header.callBankclerk) {
            this.startAudio();
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
            this.operationLogging(this._labels.logging.Common.Header.CallClerkAction);
        } else if (this.leftSubTitle === this.labels.header.back) {
            this.handleCancelClickEmitter('close');
            this.operationLogging(this._labels.logging.Common.Header.CloseAction);
        } else if (this.leftSubTitle === this.labels.common.leftSubTitle.backConfirm) {
            this.handleCancelClickEmitter('backConfirm');
            this.operationLogging(this._labels.logging.Common.Header.BackToConfirm);
        }
    }

    public startAudioWithoutModal() {
        if (!this.isPlaying) {
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
            this.isPlaying = true;
            this.audioView.nativeElement.load();
            this.audioView.nativeElement.play();
            this.stopAudio();
        }
    }

    public startAudio() {
        if (!this.isPlaying) {
            this.isPlaying = true;
            this.audioView.nativeElement.load();
            this.audioView.nativeElement.play();
            this.stopAudio();
        }
    }

    public returnToTop() {
        this.isReturning = true;
        this.beforeAlert();
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToTopBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToTopTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    if (this.navCtrl !== this.app.getRootNav()) {
                        this.viewCtrl.dismiss(null, null, {
                            animate: false
                        }).then(() => this.app.getRootNav().setRoot(TopComponent));
                    } else {
                        this.app.getRootNav().setRoot(TopComponent);
                    }
                } else {
                    this.isReturning = false;
                    this.afterAlert();
                }
            }
        );
        this.operationLogging(this._labels.logging.Common.GobackTopAction);
    }

    /**
     * processType取得
     */
    public get processType(): number {
        return this.isCurrentPage ? -1 : this.currentPageComponent.processType;
    }

    // header cancel button click
    public handleCancelClickEmitter(value) {
        // タイトルが「本人確認書類」の場合、ポップアップを表示。※本人確認チャット
        if (this.options && this.options.title === '本人確認書類') {
            const buttonList = [
                { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
                { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.backToConfirmTitle,
                buttonList,
                (item) => {
                    if (item.buttonValue === 'back') {
                        this.viewCtrl.dismiss(value);
                    }
                }
            );
        } else {
            this.viewCtrl.dismiss(value);
        }
    }

    public skipToOrdinaryDepositConfirmPage() {
        this.beforeAlert();
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToOrdinaryDepositConfirmPage, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.skipToOrdinaryDepositConfirmPage,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    this.skipToConfirmPage();
                } else {
                    this.afterAlert();
                }
            }
        );
    }

    private skipToConfirmPage() {
        this.action.setStateSubmitDataValue({ name: 'ifApplyBC', value: ApplyBC.NO });
        this.action.setStateSubmitDataValue({ name: 'ifApplyBCBak', value: ApplyBC.NO });

        // 申し込み確認画面のBC修正によって来る場合
        if (this.state.submitData.referenceFlg === ReferenceFlg.Confrim) {
            this.backConfirmPageByModify();
        } else {
        // 外国籍の場合
        if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT
            && this.state.submitData.applyBizCategory === '04') {
                // 該当しない場合
            this.navCtrl.setRoot(ExistingSavingsForeignInitConfirmComponent,
                {
                    submitData: this.state.submitData,
                    ifApplyBC: ApplyBC.NO,
                    ifApplyBCBak: ApplyBC.NO
                    }
                );
        // スワイプあり
            } else if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
                // 該当しない場合
                if (this.state.submitData.existingChangeFlag === '1') {
                    this.navCtrl.setRoot(ExistingSavingsContentConfirmComponent,
                        {
                            submitData: this.state.submitData,
                            ifApplyBC: ApplyBC.NO,
                            ifApplyBCBak: ApplyBC.NO,
                        });
                } else {
                    this.navCtrl.setRoot(ExistingSavingsInitConfirmComponent,
                        {
                            submitData: this.state.submitData,
                            ifApplyBC: ApplyBC.NO,
                            ifApplyBCBak: ApplyBC.NO,
                        });
                }
        // スワイプ無し
        } else if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT) {
            this.navCtrl.setRoot(BsdAgentConfirmComponent,
                {
                    submitData: this.state.submitData,
                    ifApplyBC: ApplyBC.NO,
                    ifApplyBCBak: ApplyBC.NO,
                    }
                );
            }
        }

        // BC申込チャット途中で離脱する場合は、storeをクリアする
        // 理由がBC申込チャットに複数回出入りが可能なので、入る時にクリアな状態で始まりたい
        this.action.clearStore();
    }

    private toEditChat(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.beforeAlert();
        this.action.editChart(order, pageIndex, answerOrder, orderIndex);
        this.chatFlowAccessor.clearComponent();
        this.currentPageIndex = pageIndex;
        this.currentPageComponent = this.getPageComponent(pageIndex);
        this.getNextAnswer(order, pageIndex);
        const deleteCount = this.pageComponentList.length - this.currentPageIndex - 1;
        this.pageComponentList.splice(this.currentPageIndex + 1, deleteCount);
    }

    /**
     * 次のノードを取得する
     * @param order メッセージの番号
     * @param pageIndex ページ番号
     */
    private getNextAnswer(order: number, pageIndex: number) {
        if (this.startOrder != null && this.endOrder != null && order > this.endOrder) {
            if (this.needPassword && !this.options.component) {
                const modal = this.modalCtrl.create(AccountModalPasswordComponent,
                    { data: this._labels.creditcard.titlePassword },
                    { cssClass: 'settings-modal', enableBackdropDismiss: false });
                modal.onDidDismiss((value) => this.viewCtrl.dismiss(value));
                modal.present();
            } else {
                this.viewCtrl.dismiss({
                    ...this.state
                });
            }
            return;
        }
        Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
            this.action.getNextChatByAnswer(order, pageIndex);
        });
    }

    /**
     * コンポーネントタイプにより、各レンダラをマッピング
     * @param componentType コンポーネントタイプ
     */
    private mappingComponentList(componentType: string): CreditCardChatFlowRenderer {
        let render: CreditCardChatFlowRenderer;
        if (componentType === 'CreditCardCommonComponent' || componentType === undefined) {
            render = new CreditCardCommonRenderer(this.chatFlowAccessor, this.footerContent, this.store, this.modalCtrl, this.navCtrl,
                this.loginStore, this.modalService, this.deviceService, this.audioService, this.action, this.params);
        } else if (componentType === 'CreditCardDCSelectComponent') {
            render = new CreditCardDCSelectRenderer(this.chatFlowAccessor,
                this.footerContent, this.action, this.store, this.modalService, this.audioService, this.creditCardUtil);
        } else if (componentType === 'CreditCardEmploymentComponent') {
            render = new CreditCardEmploymentRenderer(this.chatFlowAccessor, this.footerContent, this.store, this.audioService,
                this.creditCardUtil, this.modalService, this.loginStore);
        } else if (componentType === 'CreditCardBankCardComponent') {
            render = new CreditCardBankCardRenderer(this.chatFlowAccessor,
                this.footerContent, this.store, this.modalService, this.audioService, this.modalCtrl, this.navCtrl);
        } else if (componentType === 'CreditCardTypeComponent') {
            render = new CreditCardTypeRenderer(this.chatFlowAccessor,
                this.footerContent, this.store, this.loginStore, this.deviceService, this.modalService, this.navCtrl);
        } else if (componentType === 'CreditCardStudentComponent') {
            render = new CreditCardStudentRenderer(this.chatFlowAccessor,
                this.footerContent, this.store);
        } else if (componentType === 'CreditCardJcbComponent') {
            render = new CreditCardJcbRenderer(this.chatFlowAccessor,
                this.footerContent, this.store, this.modalService, this.audioService);
        } else if (componentType === 'CreditCardJcbEmploymentComponent') {
            render = new CreditCardJcbEmploymentRenderer(this.chatFlowAccessor,
                this.footerContent, this.store);
        } else if (componentType === 'CreditCardJcbFamilyComponent') {
            render = new CreditCardJcbFamilyRenderer(this.chatFlowAccessor,
                this.footerContent, this.store, this.modalService, this.audioService);
        } else if (componentType === 'CreditCardJcbTypeComponent') {
            render = new CreditCardJcbTypeRenderer(this.chatFlowAccessor,
                this.footerContent, this.store, this.loginStore, this.deviceService, this.modalService, this.navCtrl);
        } else if (componentType === 'CreditCardJcbStudentComponent') {
            render = new CreditCardJcbStudentRenderer(this.chatFlowAccessor,
                this.footerContent, this.store);
        } else if (componentType === 'CreditCardJcbGuardianComponent') {
            render = new CreditCardJcbGuardianRenderer(this.chatFlowAccessor,
                this.footerContent, this.store);
        } else if (componentType === 'CreditCardCheckApplyComponent') {
            render = new CreditCardCheckApplyRenderer(this.chatFlowAccessor, this.footerContent, this.store);
            render.processType = 3;
        } else if (componentType === 'CreditCardAddressIdentificationComponent') {
            render = new CreditCardAddressIdentificationRenderer(this.chatFlowAccessor, this.footerContent, this.store);
            render.processType = 3;
        } else if (componentType === 'CreditCardIdentificationDocumentOneComponent') {
            render = new CreditCardIdentificationDocumentOneRender(this.chatFlowAccessor, this.footerContent, this.store);
            render.processType = 3;
        } else if (componentType === 'CreditCardIdentificationDocumentTwoComponent') {
            render = new CreditCardIdentificationDocumentTwoRender(this.chatFlowAccessor, this.footerContent, this.store);
            render.processType = 3;
        } else if (componentType === 'CreditCardImgapplyComponent') {
            render = new CreditCardImgapplyRenderer(this.chatFlowAccessor, this.footerContent, this.store);
            render.processType = 3;
        } else if (componentType === 'CreditCardIdentificationLicenseNoComponent') {
            render = new CreditCardIdentificationLicenseNoRender(this.chatFlowAccessor, this.footerContent, this.store);
            render.processType = 3;
        } else if (componentType === 'CreditCardStuffConfirmComponent') {
            render = new CreditCardStuffConfirmRenderer(this.chatFlowAccessor, this.footerContent, this.store, this.loginStore);
            render.processType = 3;
        } else if (componentType === 'CreditCardStudentIdentificationComponent') {
            render = new CreditCardStudentIdentificationRenderer(this.chatFlowAccessor, this.footerContent, this.store);
            render.processType = 3;
        }
        return render;
    }

    private getPageComponent(pageIndex: number, componentType?: string): CreditCardChatFlowRenderer {
        if (componentType === 'CreditCardCheckApplyComponent'
            && this.state.submitData.identificationDocument1 && this.state.submitData.identificationDocument1Images) {
                componentType = 'CreditCardIdentificationLicenseNoComponent';
        } else if (componentType === 'ChangeIdentityDocument') {
            componentType = 'CreditCardCheckApplyComponent';
        }

        if (this.pageComponentList[pageIndex] == null) {
            this.pageComponentList[pageIndex] = this.mappingComponentList(componentType);
            this.pageComponentList[pageIndex].nextChatEvent.subscribe((params) => {
                this.getNextAnswer(params.order, params.pageIndex);
            });
        }

        if (this.chatFlowAccessor) {
            this.chatFlowAccessor.setRenderer(this.pageComponentList[pageIndex]);
            this.chatFlowAccessor.setContent(this.content);
        }
        return this.pageComponentList[pageIndex];
    }

    private showModal() {
        const modal = this.modalCtrl.create(
            ModalPdfScrollCheckComponent,
            { title: this._labels.creditcard.individualCreditInfoAuthorityModal.title,
              pdfSrc: this._labels.creditcard.individualCreditInfoAuthorityModal.pdfSrc },
            { cssClass: 'settings-modal-bank-card-all', enableBackdropDismiss: false }
        );
        modal.onDidDismiss(() => {
            // 複合取引の場合、普通預金口座の確認画面へ遷移する
            if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
                // 申し込み確認画面のBC修正によって来る場合
                if (this.state.submitData.referenceFlg === ReferenceFlg.Confrim) {
                    this.completeConfirmPageByModify();
                // その他の場合
                } else {
                // 外国籍の場合
                   if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT
                       && this.state.submitData.applyBizCategory === '04') {
                        this.navCtrl.setRoot(ExistingSavingsForeignInitConfirmComponent,
                            {
                                submitData: this.state.submitData
                    });
                // スワイプあり
                    } else if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
                        if (this.state.submitData.existingChangeFlag === '1') {
                            this.navCtrl.setRoot(ExistingSavingsContentConfirmComponent,
                                {
                                    submitData: this.state.submitData
                                });
                        } else {
                            this.navCtrl.setRoot(ExistingSavingsInitConfirmComponent,
                                {
                                    submitData: this.state.submitData
                                });
                        }
                  // スワイプ無し
                } else if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT) {
                    this.navCtrl.setRoot(BsdAgentConfirmComponent,
                        {
                            submitData: this.state.submitData
                        });
                    }
                }
                // 既保持者
            } else {
                this.navCtrl.setRoot(CreditCardInitConfirmComponent);
            }
       });
        modal.present();
    }

    /**
     * add operation log
     */
    private operationLogging(value: string) {
        const params = {
            screenName: this._labels.logging.Common.ScreenName,
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: value
        };
        this.loggingService.log(this.loggingService.generalOperationParams(params));
    }

    private stopAudio() {
        if (this.isPlaying) {
            Observable.timer(7000).subscribe(() => {
                this.isPlaying = false;
                this.audioView.nativeElement.pause();
            });
        }
    }

    /**
     * 申込確認画面のBC修正ボタンによってBC申し込みチャットが完了時に使用される
     * 申込確認画面に戻る、BC申込完了パラメータを渡す
     *
     * @private
     * @memberof CreditCardChatComponent
     */
    private completeConfirmPageByModify() {
        this.navCtrl.getPrevious().instance.receiveBCParamByModify({
            ifApplyBCBak: ApplyBC.YES
        });
        this.navCtrl.pop();
    }

    /**
     * 申込確認画面のBC修正ボタンによってBC申し込みチャットが途中終了時に使用される
     * 申込確認画面に戻る、BC申込完了パラメータを渡す
     * @private
     * @memberof CreditCardChatComponent
     */
    private backConfirmPageByModify() {
        this.navCtrl.getPrevious().instance.receiveBCParamByModify({
            ifApplyBC: ApplyBC.NO,
            ifApplyBCBak: ApplyBC.NO
        });
        this.navCtrl.pop();
    }
}
