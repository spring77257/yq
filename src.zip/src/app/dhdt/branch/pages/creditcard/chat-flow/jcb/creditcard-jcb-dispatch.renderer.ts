import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { ChatOption, COMMON_CONSTANTS, TEMPLATE_FILE } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CreditCardChatFlowAccessor } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.accessor';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import { CreditCardQuestionsModel } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/creditcard/service/backup-data.service';
import { CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { SelectAddressCommonComponent } from 'dhdt/branch/shared/components/address/view/select-address-common.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { DepositInputComponent } from 'dhdt/branch/shared/components/deposit-input/deposit-input.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { QuantityInputComponent } from 'dhdt/branch/shared/components/quantity-input/quantity-input.component';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';

export class CreditCardJcbDispatchRenderer extends CreditCardChatFlowRenderer {
    public processType = 1;
    private state: CreditCardState;

    constructor(private chatFlowAccessor: CreditCardChatFlowAccessor, private footerContent: ViewContainerRef,
                private store: CreditCardStore) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
    }

    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(TEMPLATE_FILE.CREDIT_CARD_JCB_DISPATCH, pageIndex);
    }

    /**
     * コンポネントを表示する
     * @param question チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public rendererComponents(question: CreditCardQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_YEARMONTH_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_PREFECTURE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_COUNTYURBANVILLAGE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_PICKER: {
                this.onPicker(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECTADDRESS: {
                this.onSelectAddress(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECTSTREET: {
                this.onSelectStreet(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON: {
                this.onButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_DEPOSIT_TENTHOUSAND: {
                this.onDepositInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_NUMBER_THOUSAND: {
                this.onQuantityInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE: {
                this.configUrl(question, pageIndex);
                break;
            }
        }
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getCreditCardDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });
                        this.getNextChat(entity.next, pageIndex);
                    });
                }
            });
    }

    public onNumberKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    public onPicker(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            defaultIndex: entity.options ? entity.options.defaultIndex : undefined,
            title: entity.options ? entity.options.title : undefined,
            validationRules: entity.validationRules,
            submitData: this.state.submitData,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * 住所コンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSelectAddress(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            submitData: this.state.submitData,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.type, SelectAddressCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer.value) {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                } else {
                    if (answer !== COMMON_CONSTANTS.SIGN_SKIP) {
                        this.setAnswer(answer);
                    }
                    const preNode = this.state.showChats[this.state.showChats.length - 2];
                    this._action.resetLastNode({ order: preNode.skip, pageIndex: preNode.pageIndex });
                }
            });
    }

    /**
     * 町丁名コンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSelectStreet(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const params = {
            prefectureCode: this.state.submitData.holderAddressPrefectureCode,
            prefectureKanji: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillageCode: this.state.submitData.holderAddressCountyUrbanVillageCode,
            countyUrbanVillageKanji: this.state.submitData.holderAddressCountyUrbanVillage,
        };
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(params, SelectStreetComponent, this.footerContent, options)
            .subscribe((result: { isSkip: boolean, text: string, value: any }) => {
                this.chatFlowAccessor.clearComponent();

                const answer = {
                    text: result.text,
                    value: [
                        { key: 'holderAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                        { key: 'holderAddressStreetNameFuriKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) }
                    ]
                };
                this.setAnswer(answer);
                this.getNextChat(result.isSkip ? entity.skip : entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            maxColNum: (entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON) ? 3 : undefined,
            validationOn: null,
            kanaText: null,
            validationRules: null,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        if (entity.options && entity.options === ChatOption.VALIDATION_ON) {
            const backupDataService = InjectionUtils.injector.get(BackupDataService);
            options.validationOn = ChatOption.VALIDATION_ON;
            options.kanaText = backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
            .subscribe((answer) => {
                if (entity.name.length > 0 && answer.value.length > 0) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }

                if (answer.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.next, pageIndex);
                }
            });
    }

    public onDepositInput(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            title: entity.options ? entity.options.title : undefined,
            validationRules: entity.validationRules,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, DepositInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    public onQuantityInput(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            title: entity.options ? entity.options.title : undefined,
            unit: entity.options ? entity.options.unit : undefined,
            validationRules: entity.validationRules,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, QuantityInputComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    /**
     * Config url
     * @param entity params
     */
    private configUrl(entity, pageIndex) {
        if (entity.option === 'url') {
            const serverInfoService = InjectionUtils.injector.get(ServerInfoService);
            const submitData = this.state.submitData;

            let params;
            switch (entity.name) {
                case 'getAddressFromZipcode': {
                    let firstZipCode;
                    let lastZipCode;
                    if (submitData.firstZipCode) {
                        firstZipCode = submitData.firstZipCode;
                    }
                    if (submitData.lastZipCode) {
                        lastZipCode = submitData.lastZipCode;
                    }
                    const zipCode = firstZipCode + lastZipCode + '';
                    params = { zipCode: zipCode };
                    break;
                }
                case 'getStreetInitialsKana': {
                    let pregecture;
                    let village;
                    if (submitData.holderAddressPrefecture) {
                        pregecture = submitData.holderAddressPrefecture;
                    }
                    if (submitData.holderAddressCountyUrbanVillage) {
                        village = submitData.holderAddressCountyUrbanVillage;
                    }
                    params = {
                        prefectureKanji: pregecture,
                        countyUrbanVillageKanji: village
                    };
                    break;
                }
            }
            serverInfoService.getInfoFormServe(entity.name, params).subscribe((result) => {
                entity.choices.forEach((choice) => {
                    if (result === choice.value) {
                        this._action.getNextChatByAnswer(choice.next, pageIndex);
                        return;
                    }
                });
            });
        }
    }
}
