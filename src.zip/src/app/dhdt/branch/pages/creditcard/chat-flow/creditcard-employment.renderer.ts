import { ViewContainerRef } from '@angular/core';
import { InjectionUtils, ObjectUtils } from 'adep/utils';
import { AgeClassification, ApplyBC, ChatOption, COMMON_CONSTANTS, TEMPLATE_FILE } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardChatFlowAccessor } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.accessor';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import {
    BankCardType, Career, CreditInputPattern, Gender, IsCompositApply, IsMarried, IsNearGraduate,
    IsParentalLivingTogether, JobPattern
} from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardQuestionsModel } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { BackupDataService } from 'dhdt/branch/pages/creditcard/service/backup-data.service';
import { CreditCardSignal, CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { SelectAddressCommonComponent } from 'dhdt/branch/shared/components/address/view/select-address-common.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { QuantityInputComponent } from 'dhdt/branch/shared/components/quantity-input/quantity-input.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { CreditCardUtil } from 'dhdt/branch/shared/utils/creditcard-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';

/**
 * 横浜バンクカード発行（7.職業・勤務先情報入力 - 09.親権者情報入力）
 */
export class CreditCardEmploymentRenderer extends CreditCardChatFlowRenderer {
    public processType = 1;
    private state: CreditCardState;

    private phoneIsSkipped: boolean = false;
    private tellIsSkipped: boolean = false;

    constructor(
        private chatFlowAccessor: CreditCardChatFlowAccessor,
        private footerContent: ViewContainerRef,
        private store: CreditCardStore,
        private audioService: AudioService,
        private creditCardUtil: CreditCardUtil,
        private modalService: ModalService,
        private loginStore: LoginStore
    ) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
    }

    /**
     * YMLファイル読み込み
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(TEMPLATE_FILE.CREDIT_CARD_EMPLOYMENT, pageIndex);
    }

    /**
     * タイプにより、各コンポーネントをレンダリング
     * @param question ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public rendererComponents(question: CreditCardQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_YEARMONTH_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_PREFECTURE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_COUNTYURBANVILLAGE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_PICKER:
            case COMMON_CONSTANTS.ELEMENT_TYPE_DATE_PICKER: {
                this.onPicker(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON: {
                this.onButton(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE: {
                this.configUrl(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECTADDRESS: {
                this.onSelectAddress(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_SELECTSTREET: {
                this.onSelectStreet(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_DEPOSIT_TENTHOUSAND: {
                this.onQuantityInput(question, pageIndex);
                break;
            }
        }
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const choices = this.changeValidationRuleMax(entity, this.state.submitData);
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getCreditCardDefaultValues(entity.name, this.state.submitData),
            title: entity.options ? entity.options.title : undefined,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            fullwidthHalfwidthDivisionCode: entity.fullwidthHalfwidthDivisionCode
        };

        this.chatFlowAccessor.addComponent(choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    // カナ変換において、特定の属性については最大長を超えないように設定する
                    let maxLength = null;
                    // 町丁名は町丁名(フリガナ)の最大文字数、番地名は町丁名+番地名(フリガナ)の最大文字数-町丁名(フリガナ)の文字数
                    if (answer.value[0]) {
                        const key = answer.value[0].key;
                        switch (key) {
                            case 'holderAddressStreetNameInput':
                            case 'holderAddressHouseNumber':
                                maxLength = InputUtils.calculateMaxLength(key,
                                    this.state.submitData[entity.infoType + 'HolderAddressStreetNameFuriKanaInput'],
                                    this.state.submitData[entity.infoType + 'HolderAddressStreetNameFuriKanaSelect']);
                                break;
                        }
                    }

                    InputUtils.getKanjiToKana(answer.value, maxLength).subscribe((results) => {
                        if (entity.infoType === CreditInputPattern.EMPLOYMENT || entity.infoType === CreditInputPattern.PARENTAL) {
                            results = this.replaceItemKey(entity.infoType, { value: results });
                        }
                        this.setAnswer({ text: answer.text, value: results });
                        if (entity.fullwidthHalfwidthDivisionCode) {
                            this.store.registerSignalHandler(CreditCardSignal.CHARACTER_CHECK, (data) => {
                                this.store.unregisterSignalHandler(CreditCardSignal.CHARACTER_CHECK);
                                this.getNextChat(entity.next, pageIndex);
                            });
                            const params = {
                                tabletApplyId: this._store.getState().tabletApplyId,
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                                    checkStrings: [{
                                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                        checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                                    }],
                                }
                            };
                            this._action.characteCheck(params, () => {
                                this._action.editChart(entity.order, pageIndex,
                                    this.state.showChats[this.state.showChats.length - 1].answer.order);
                                this.getNextChat(entity.order, pageIndex);
                            });
                        } else {
                            this.getNextChat(entity.next, pageIndex);
                        }
                    });
                }
            });
    }

    /**
     * キャッシュカード口座入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onNumberKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();

            if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
            } else {
                this.giveInfotype(entity.infoType, answer);
                this.setAnswer(answer);
            }
            const isShowModal = this.telIsSkip(entity.name, answer === 'skip');
            if (!isShowModal) {
                this.getNextChat(entity.next, pageIndex);
            }
        });
    }

    /**
     * 数量の汎用入力コンポーネントの表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onQuantityInput(entity: CreditCardQuestionsModel, pageIndex: number): void {
        // 勤務年数が年齢以上で入力できない
        if (entity.name === 'lengthOfService') {
            const age = this.creditCardUtil.calculateAge(this.state.submitData.birthdate);
            if (entity.choices) {
                entity.choices.forEach((choice) => {
                    if (choice.name === 'lengthOfService') {
                        choice.validationRules.maxValue = age;
                    }
                });
            }
        }
        const options = {
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            title: entity.options ? entity.options.title : undefined,
            unit: entity.options ? entity.options.unit : undefined,
            validationRules: entity.validationRules,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, QuantityInputComponent, this.footerContent, options).subscribe((answer) => {
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);
            this.getNextChat(entity.next, pageIndex);
        });
    }

    /**
     * Pickerコンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onPicker(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        validation = entity.validationRules;
        if (entity.name === 'graduateDate' && entity.options) {
            entity.options.defaultIndex = this.getGraduateMonthDefaultIndex();
            // システム日時を最小値に設定
            if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
                validation = {
                    ...entity.validationRules,
                    min: moment(customerApplyStartDate)
                        .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM)
                };
            }
        }

        const options = {
            type: entity.type,
            name: entity.name,
            infoType: entity.infoType,
            defaultIndex: entity.options ? entity.options.defaultIndex : undefined,
            validationRules: validation,
            submitData: this.state.submitData,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.giveInfotype(entity.infoType, answer);
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            maxColNum: (entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON) ? 3
                : (entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_BUTTON) ? 2
                    : undefined,
            validationOn: null,
            kanaText: null,
            validationRules: null,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        if (entity.options && entity.options === ChatOption.VALIDATION_ON) {
            const backupDataService = InjectionUtils.injector.get(BackupDataService);
            options.validationOn = ChatOption.VALIDATION_ON;
            options.kanaText = backupDataService.getCheckedItemValue(entity.question);
            options.validationRules = entity.validationRules;
        }
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
            .subscribe((answer) => {
                if (entity.name.length > 0 && answer.value.length > 0) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }

                if (entity.name === 'career') {
                    // 卒業後の職業選択の場合、卒業予定年月日、学校名をクリア
                    if (this.state.submitData.career !== Career.STUDENT) {
                        this._action.clearShoolInfo();
                    }
                    if (entity.options && entity.options === 'careerSelect') {
                        this._action.setStateSubmitDataValue({ name: 'isNearGraduate', value: undefined });
                    }
                    if (entity.options && entity.options === 'afterGraduate') {
                        this._action.setStateSubmitDataValue({ name: 'isNearGraduate', value: IsNearGraduate.YES });
                    }
                }
                if (entity.name === 'parentalLivingTogether' && answer.value === IsParentalLivingTogether.YES) {
                    this._action.setStateSubmitDataValue({
                        name: 'parentalZipCode',
                        value: this.state.submitData.firstZipCode ?
                            this.state.submitData.firstZipCode + '-' + this.state.submitData.lastZipCode : this.state.submitData.zipCode
                    });
                    this._action.setStateSubmitDataValue({ name: 'parentalAddress', value: this.state.submitData.address });
                    this._action.setStateSubmitDataValue({ name: 'parentalAddressKana', value: this.state.submitData.addressKana });
                }

                if (answer.action.type.length > 0) {
                    this.configAction(answer);
                } else if (answer.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.next, pageIndex);
                }
            });
    }

    /**
     * 郵便番号から検索した住所を選択する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSelectAddress(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            submitData: this.getZipCode(entity.infoType),
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.type, SelectAddressCommonComponent, this.footerContent, options)
            .subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer.value) {
                    this.giveInfotype(entity.infoType, answer);
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                } else {
                    this.getNextChat(entity.skip, pageIndex);
                }
            });
    }

    /**
     * 検索した町丁名を選択する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSelectStreet(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const params = {
            prefectureKanji: this.getPrefecture(entity.infoType),
            countyUrbanVillageKanji: this.getCountyUrbanVillage(entity.infoType)
        };
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(params, SelectStreetComponent, this.footerContent, options)
            .subscribe((result: { isSkip: boolean, text: string, value: any }) => {
                this.chatFlowAccessor.clearComponent();
                if (result.value) {
                    const answer = {
                        text: result.text,
                        value: [
                            { key: 'holderAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'holderAddressStreetNameFuriKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) },
                            { key: 'streetWork', value: (result.isSkip ? undefined : result.value.streetKanji) },
                            { key: 'streetStreet', value: (result.isSkip ? undefined : result.value.streetKanji) }
                        ]
                    };
                    this.giveInfotype(entity.infoType, answer);
                    this.setAnswer(answer);
                    this.getNextChat(result.isSkip ? entity.skip : entity.next, pageIndex);
                } else {
                    this._action.resetLastNode({ order: entity.next, pageIndex: pageIndex });
                }
            });
    }

    private configAction(choice: any) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.chatFlowCompelete(action.value);
        }
    }

    /**
     * Config url
     * @param entity params
     */
    private configUrl(entity, pageIndex) {
        if (entity.option === 'url') {
            const serverInfoService = InjectionUtils.injector.get(ServerInfoService);
            const submitData = this.state.submitData;

            let params;
            switch (entity.name) {
                case 'getAddressFromZipcode': {
                    let firstZipCode: string;
                    let lastZipCode: string;
                    if (submitData[entity.infoType + 'FirstZipCode']) {
                        firstZipCode = submitData[entity.infoType + 'FirstZipCode'];
                    }
                    if (submitData[entity.infoType + 'LastZipCode']) {
                        lastZipCode = submitData[entity.infoType + 'LastZipCode'];
                    }
                    const zipCode = firstZipCode + lastZipCode + '';
                    params = { zipCode: zipCode };
                    break;
                }
                case 'getStreetInitialsKana': {
                    let prefecture;
                    let village;
                    if (submitData[entity.infoType + 'HolderAddressPrefecture']) {
                        prefecture = submitData[entity.infoType + 'HolderAddressPrefecture'];
                    }
                    if (submitData[entity.infoType + 'HolderAddressCountyUrbanVillage']) {
                        village = submitData[entity.infoType + 'HolderAddressCountyUrbanVillage'];
                    }
                    params = {
                        prefectureKanji: prefecture,
                        countyUrbanVillageKanji: village
                    };
                    break;
                }
            }
            serverInfoService.getInfoFormServe(entity.name, params).subscribe((result) => {
                entity.choices.forEach((choice) => {
                    if (result === choice.value) {
                        this._action.getNextChatByAnswer(choice.next, pageIndex);
                        return;
                    }
                });
            });
        } else if (entity.option === 'credit') {
            let judgeResult: string;

            switch (entity.name) {
                case 'jobPattern': {
                    judgeResult = this.returnJobPattern();
                    break;
                }
                case 'careerCheck': {
                    if (this.state.submitData.career) {
                        judgeResult = (this.state.submitData.career === Career.ANNUITY_PENSION ||
                            this.state.submitData.career === Career.HOUSEWIFE ||
                            this.state.submitData.career === Career.UNEMPLOYED) ? '01' : '02';
                    }
                    break;
                }
                case 'graduateDate': {
                    const graduateDate = moment(this.state.submitData.graduateDate, COMMON_CONSTANTS.DATE_FORMAT_YYYYMM)
                        .endOf(COMMON_CONSTANTS.DATE_MONTH).format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
                    const customerApplyDate = moment(this.state.submitData.customerApplyStartDate,
                        COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
                    const remainingPeriod = moment(graduateDate).diff(customerApplyDate, COMMON_CONSTANTS.DATE_DAY);
                    // 申込日起算で90日勘定
                    judgeResult = remainingPeriod <= 90 ? '01' : '02';
                    break;
                }
                case 'careerAfterGraduation': {
                    const canSelectHousewife = this.state.submitData.gender === Gender.FEMALE
                        && this.state.submitData.married === IsMarried.MARRIED;
                    switch (this.state.submitData.cardType) {
                        case BankCardType.BC_GOLD:
                        case BankCardType.BC_GOLD_SUICA: {
                            judgeResult = canSelectHousewife ? '03' : '01';
                            break;
                        }
                        case BankCardType.BC_VISA:
                        case BankCardType.BC_SUICA:
                        case BankCardType.BC_MASTERCARD: {
                            judgeResult = canSelectHousewife ? '04' : '02';
                            break;
                        }
                    }
                    break;
                }
                case 'parentalLivingTogether': {
                    // judgeResult = 01:親権者の住所入力 02:親権者の住所不要
                    judgeResult = this.state.submitData.parentalLivingTogether === IsParentalLivingTogether.NO ? '01' : '02';
                    break;
                }
                case 'checkComposit': {
                    judgeResult = this.state.submitData.ifApplyBC === ApplyBC.YES ?
                        IsCompositApply.YES : IsCompositApply.NO;
                    break;
                }
                case 'checkEmploymentName': {
                    // judgeResult = 01:お勤め先名称入力 02:お勤め先名称不要
                    judgeResult = !this.state.submitData.holderWorkPlace ? '01' : '02';
                    if (this.state.submitData.holderWorkPlace) {
                        InputUtils.getKanjiToKana(
                            [{ key: 'employmentName', value: this.state.submitData.holderWorkPlace }]
                        ).subscribe((results) => {
                            this._action.setStateSubmitDataValue({ name: results[0].key, value: results[0].value });
                            this._action.setStateSubmitDataValue({ name: results[1].key, value: results[1].value });
                        });
                    }
                    break;
                }
            }
            entity.choices.forEach((choice) => {
                if (judgeResult === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    /**
     * 性別・申込カード種別・結婚有無から表示する職業パターンを判別する。
     */
    private returnJobPattern() {
        let jobPattern: string;
        if (this.state.submitData.married === IsMarried.UN_MARRIED) {
            switch (this.state.submitData.cardType) {
                case BankCardType.BC_GOLD:
                case BankCardType.BC_GOLD_SUICA: {
                    jobPattern = JobPattern.JOB_PATTERN_01;
                    break;
                }
                case BankCardType.BC_VISA:
                case BankCardType.BC_SUICA:
                case BankCardType.BC_MASTERCARD: {
                    jobPattern = JobPattern.JOB_PATTERN_02;
                    break;
                }
            }
        } else if (this.state.submitData.married === IsMarried.MARRIED) {
            switch (this.state.submitData.cardType) {
                case BankCardType.BC_GOLD:
                case BankCardType.BC_GOLD_SUICA: {
                    if (this.state.submitData.gender === Gender.MALE) {
                        jobPattern = JobPattern.JOB_PATTERN_01;
                    } else if (this.state.submitData.gender === Gender.FEMALE) {
                        jobPattern = JobPattern.JOB_PATTERN_03;
                    }
                    break;
                }
                case BankCardType.BC_VISA:
                case BankCardType.BC_SUICA:
                case BankCardType.BC_MASTERCARD: {
                    if (this.state.submitData.gender === Gender.MALE) {
                        jobPattern = JobPattern.JOB_PATTERN_02;
                    } else if (this.state.submitData.gender === Gender.FEMALE) {
                        jobPattern = JobPattern.JOB_PATTERN_04;
                    }
                    break;
                }
            }
        }
        return jobPattern;
    }

    /**
     * 入力区分に応じて項目名を変更する
     * @param infoType 入力区分
     * @param answers チャットフローエンティティ
     */
    private replaceItemKey(infoType: string, answers: any) {
        const replacedAnswer: any[] = [];
        answers.value.map((item) => {
            if (item.key !== undefined && item.key.indexOf('holder') !== -1) {
                item.key = item.key.replace('holder', infoType + 'Holder');
            }
            if (item.key !== undefined && item.key.indexOf('firstZipCode') !== -1) {
                item.key = item.key.replace('firstZipCode', infoType + 'FirstZipCode');
            }
            if (item.key !== undefined && item.key.indexOf('lastZipCode') !== -1) {
                item.key = item.key.replace('lastZipCode', infoType + 'LastZipCode');
            }
            replacedAnswer.push({ key: item.key, value: item.value });
        });
        return replacedAnswer;
    }

    /**
     * 区分に応じて参照する郵便番号を変更する。
     * @param infoType 勤務先名称・親権者情報の区分。
     */
    private getZipCode(infoType: string) {
        const zipCode = {
            firstZipCode: this.state.submitData[infoType + 'FirstZipCode'],
            lastZipCode: this.state.submitData[infoType + 'LastZipCode']
        };

        return zipCode;
    }

    /**
     * 区分に応じて参照する県を変更する。
     * @param infoType 勤務先名称・親権者情報の区分。
     */
    private getPrefecture(infoType: string) {
        const prefecture = this.state.submitData[infoType + 'HolderAddressPrefecture'];
        return prefecture;
    }

    /**
     * 区分に応じて参照する市区町村を変更する。
     * @param infoType 勤務先名称・親権者情報の区分。
     */
    private getCountyUrbanVillage(infoType: string) {
        const countyUrbanVillage = this.state.submitData[infoType + 'HolderAddressCountyUrbanVillage'];
        return countyUrbanVillage;
    }

    private giveInfotype(infotype: string, answer: any) {
        if (infotype === CreditInputPattern.EMPLOYMENT || infotype === CreditInputPattern.PARENTAL) {
            answer.value = this.replaceItemKey(infotype, answer);
        }
    }

    /**
     * 次の3月末をピッカーのデフォルト値とする。
     */
    private getGraduateMonthDefaultIndex() {
        const defaultIndex = [];
        const customorApplyMonth = moment(this.state.submitData.customerApplyStartDate)
            .format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMM).slice(-2);
        if (Number(customorApplyMonth) < 4) {
            defaultIndex[0] = 0;
            defaultIndex[1] = 2;
        } else {
            defaultIndex[0] = 1;
            defaultIndex[1] = 2;
        }
        return defaultIndex;
    }

    private telIsSkip(name: string, isSkip: boolean) {
        if (name === 'parentalHolderMobileNo') {
            this.phoneIsSkipped = isSkip;
        }
        if (name === 'parentalHolderTelephoneNo') {
            this.tellIsSkipped = isSkip;
        }
        if (name === 'parentalHolderMobileNo' && this.phoneIsSkipped && this.tellIsSkipped) {
            const buttonList = [
                { text: 'OK', buttonValue: 'ok' },
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.warnTelTitleBC,
                buttonList,
                () => {
                    this._action.needInputPhoenNo();
                }
            );
            return true;
        }
        return false;
    }

    private changeValidationRuleMax(entity: any, submitData: any) {
        const choicesResult = ObjectUtils.clone(entity.choices);
        const holderAddressStreetNameInput = submitData[entity.infoType + 'HolderAddressStreetNameInput'];

        // 「町丁名（漢字）」の入力済桁数により、「番地以降（漢字）」の入力可能最大桁数を調整する
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW
            && choicesResult[0].name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER
            && holderAddressStreetNameInput
            && holderAddressStreetNameInput.length > 0) {
            let holderAddressStreetLength = 0;
            holderAddressStreetLength = holderAddressStreetNameInput.length;
            choicesResult[0].validationRules.max = entity.choices[0].validationRules.max - holderAddressStreetLength + 1;
        }
        return choicesResult;
    }
}
