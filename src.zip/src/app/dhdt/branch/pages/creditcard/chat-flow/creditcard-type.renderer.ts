import { ViewContainerRef } from '@angular/core';
import { DeviceService } from 'dhd/common/services/device.service';
import { COMMON_CONSTANTS, CoreBankingConst, PasswordVerify, TEMPLATE_FILE } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardChatFlowAccessor } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.accessor';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import { CreditCardQuestionsModel } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { CreditCardSignal, CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { CreditCardInitConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-initconfirm.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { ExistingPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/existing-password-rule-check.interface';
import { NewPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/new-password-rule-check.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { NavController } from 'ionic-angular';

export class CreditCardTypeRenderer extends CreditCardChatFlowRenderer {
    public processType = 1;
    private state: CreditCardState;

    constructor(private chatFlowAccessor: CreditCardChatFlowAccessor, private footerContent: ViewContainerRef,
                private store: CreditCardStore, private loginStore: LoginStore, private deviceService: DeviceService,
                private modalService: ModalService, private navCtrl: NavController) {
        super();
        this.state = this.store.getState();
        this._action.setCustomerApplyStartDate();
    }

    /**
     * YMLファイル読み込み
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(TEMPLATE_FILE.CREDIT_CARD_TYPE, pageIndex);
    }

    /**
     * タイプにより、各コンポーネントをレンダリング
     * @param question ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public rendererComponents(question: CreditCardQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4: {
                this.onPasswordInput(question, pageIndex);
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_TITLE_BUTTON:
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON: {
                this.onButton(question, pageIndex);
                break;
            }
        }
    }

    /**
     * 選択内容を表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onJudge(entity: CreditCardQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (this.state.submitData[entity.name] === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    /**
     * キャッシュカード口座入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onNumberKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * パスワードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onPasswordInput(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, PasswordInputComponent,
            this.footerContent, options).subscribe((answer) => {
                const existingParams: ExistingPasswordRuleCheckInterface = {
                    path: CoreBankingConstants.ApiPathConsts.PASSWORD_RULE_CHECK,
                    tabletApplyId: this.state.tabletApplyId,
                    userMngNo: this.loginStore.getState().bankclerkId,
                    params: {
                        bankNo: CoreBankingConst.bankNo,
                        receptionTenban: this.state.submitData.receptionBranchNo,
                        receptionNo: this.state.submitData.receptionNo,
                        terminalNo: this.deviceService.getDeviceId(),
                        passcodeType: entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4 ?
                            COMMON_CONSTANTS.PasscodeType.password4bits : COMMON_CONSTANTS.PasscodeType.password6bits,
                        passcode: answer.value[0].value,
                        tenban: this.state.submitData.swipeBranchNo,
                        accountNo: this.state.submitData.swipeAccountNo,
                        branchCif: this.state.submitData.swipeCif,
                        officeNo: this.state.submitData.getEmploymentTelephoneNo(),
                    }
                };

                // self params
                const selfParams: NewPasswordRuleCheckInterface = this.state.submitData.getEmploymentTelephoneNo() ? {
                    path: CoreBankingConstants.ApiPathConsts.PASSWORD_RULE_CHECK,
                    tabletApplyId: this.state.tabletApplyId,
                    userMngNo: this.loginStore.getState().bankclerkId,
                    params: {
                        bankNo: CoreBankingConst.bankNo,
                        receptionTenban: this.state.submitData.receptionBranchNo,
                        receptionNo: this.state.submitData.receptionNo,
                        terminalNo: this.deviceService.getDeviceId(),
                        passcodeType: entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4 ?
                            COMMON_CONSTANTS.PasscodeType.password4bits : COMMON_CONSTANTS.PasscodeType.password6bits,
                        passcode: answer.value[0].value,
                        birthday: this.state.submitData.holderBirthdate,
                        telephoneNo: '',
                        mobileNo: '',
                        officeNo: this.state.submitData.getEmploymentTelephoneNo()
                    }
                } : null;

                if (entity.name !== COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_CREDIT_FAMILY) {
                    // check normal password
                    this.checkExistingPassword(existingParams, answer, entity, pageIndex, selfParams);
                } else {
                    // credit family password
                    this.checkFamilyPassword(existingParams, answer, entity, pageIndex, selfParams);
                }
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public onButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        let options: any;
        switch (entity.type) {
            case COMMON_CONSTANTS.ELEMENT_TYPE_THREECOLS_BUTTON: {
                options = { maxColNum: 3 };
                break;
            }
            case COMMON_CONSTANTS.ELEMENT_TYPE_TITLE_BUTTON: {
                options = { title: entity.options ? entity.options.title : undefined };
                break;
            }
        }

        const logInfo = {
            screenName: this._store.getState().currentFileInfo.screenId,
            yamlId: this._store.getState().currentFileInfo.yamlId,
            yamlOrder: entity.order
        };
        Object.defineProperty(options, COMMON_CONSTANTS.TYPE_LOGINFO, { value: logInfo });

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options)
            .subscribe((answer) => {
                if (entity.name.length > 0 && answer.value.length > 0) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
                }

                if (answer.action.type.length > 0) {
                    this.configAction(answer);
                } else if (answer.next !== -1) {
                    this.chatFlowAccessor.clearComponent();
                    this.getNextChat(answer.next, pageIndex);
                }
            });
    }

    private configAction(choice: any) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            this.modalService.showModal(action.value, { imgSrc: action.imgSrc });
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.navCtrl.setRoot(CreditCardInitConfirmComponent);
        }
    }

    private checkExistingPassword(existingParams, answer, entity, pageIndex, selfParams) {
        this._action.checkSelfPassword(existingParams, selfParams)
            .subscribe((ok) => {
                if (!ok) {
                    this.modalService.showAlert(
                        this.labels.error.passwordError,
                        null, 'icon_alert@2x.png', null, 'settings-alert-modal'
                    );
                } else {
                    this.chatFlowAccessor.clearComponent();
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }

    private checkFamilyPassword(existingParams, answer, entity, pageIndex, selfParams) {
        const familyParams: NewPasswordRuleCheckInterface = {
            path: CoreBankingConstants.ApiPathConsts.PASSWORD_RULE_CHECK,
            tabletApplyId: this.state.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            params: {
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                passcodeType: entity.type === COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_BITS4 ?
                    COMMON_CONSTANTS.PasscodeType.password4bits : COMMON_CONSTANTS.PasscodeType.password6bits,
                passcode: answer.value[0].value,
                birthday: this.state.submitData.familyBirthdate,
                telephoneNo: this.state.submitData.holderTelephoneNo.replace(/[-]/g, ''),
                mobileNo: this.state.submitData.holderMobileNo.replace(/[-]/g, ''),
                officeNo: ''
            }
        };
        this._action.checkFamilyPassword(existingParams, familyParams, selfParams)
            .subscribe((ok) => {
                if (!ok) {
                    this.modalService.showAlert(
                        this.labels.error.passwordError,
                        null, 'icon_alert@2x.png', null, 'settings-alert-modal'
                    );
                } else {
                    this.chatFlowAccessor.clearComponent();
                    this.setAnswer(answer);
                    this.getNextChat(entity.next, pageIndex);
                }
            });
    }
}
