import { ViewContainerRef } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { COMMON_CONSTANTS, IdentificationCode, TEMPLATE_FILE } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CreditCardChatFlowAccessor } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.accessor';
import { CreditCardChatFlowRenderer } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat-flow.renderer';
import { IdentificationDocument } from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardQuestionsModel } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { CreditCardState, CreditCardStore, } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import * as moment from 'moment';

/**
 * Self Check apply component(情報入力画面（本人確認書類聴取）).
 */
export class CreditCardIdentificationDocumentTwoRender extends CreditCardChatFlowRenderer {

    public processType = -1;

    private state: CreditCardState;
    private modalService: ModalService;

    constructor(private chatFlowAccessor: CreditCardChatFlowAccessor,
                private footerContent: ViewContainerRef,
                private store: CreditCardStore) {
        super();
        this.state = this.store.getState();
        this.modalService = InjectionUtils.injector.get(ModalService);
    }

    /**
     * チャットファイルをロードする
     * @param pageIndex ページ番号
     */
    public loadTemplate(pageIndex: number) {
        this._action.loadTemplate(TEMPLATE_FILE.CREDIT_CARD_IDENTIFICATION_DOCUMENT_TWO, pageIndex);
    }

    /**
     * チャットのtype属性についてハンドリング。
     * @param question チャットの質問
     * @param pageIndex ページ番号
     */
    public rendererComponents(question: CreditCardQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'datepicker': {
                this.onPicker(question, pageIndex);
                break;
            }
            case 'saveSubmit': {
                this.onSaveSubmit(question, pageIndex);
                break;
            }
        }
    }

    /**
     * 固定値を保存する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onSaveSubmit(entity: CreditCardQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            this._action.setStateSubmitDataValueforCheckApply(entity.choices);
            this.getNextChat(entity.next, pageIndex);
        }
    }

    public onPicker(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const customerApplyStartDate = this.state.submitData.customerApplyStartDate;
        let validation: any;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD)
            };
        } else {
            validation = entity.validationRules;
        }

        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            submitData: this.state.submitData,
            skip: {
                text: this.labels.picker.skipExpiryDate,
                width: 224,
                height: 64,
                marginRight: 32,
                marginBottom: 32
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, PickerCommonComponent, this.footerContent,
            options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                if (answer !== COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            ...answer.value,
                            {
                                key: entity.name + 'Text',
                                value: answer.text
                            }
                        ]
                    });
                } else {
                    this.setAnswer({
                        text: this.labels.picker.skipExpiryDate,
                        value: [{
                            key: entity.name,
                            value: COMMON_CONSTANTS.DEFAULT_EXPIRY_DATE
                        }, {
                            key: entity.name + 'Text',
                            value: this.labels.picker.skipExpiryDate
                        }]
                    });
                }
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onButton(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value }
                    ]
                });
            }

            if (answer.action.type.length > 0) {
                this.configAction(answer);
            } else if (answer.next !== -1) {
                this.chatFlowAccessor.clearComponent();
                this.getNextChat(answer.next, pageIndex);
            }
        });
    }

    /**
     * キーボードコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onKeybord(entity: CreditCardQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();

                if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
                    this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                    this.getNextChat(entity.skip, pageIndex);
                } else {
                    InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                        this.setAnswer({ text: answer.text, value: results });

                        const resetResultList = InputUtils.holderNameReset(entity.name, this.state.submitData);
                        if (resetResultList) {
                            this._action.setStateSubmitDataValueforCheckApply(resetResultList);
                        }
                        this.getNextChat(entity.next, pageIndex);
                    });
                }
            });
    }

    /**
     * メモリにの値を判断する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    public onJudge(entity: CreditCardQuestionsModel, pageIndex: number): void {
        let judgeResult: string;

        if (entity.choices) {
            switch (entity.name) {
                case 'docJudge': {
                    judgeResult = (this.state.submitData.identificationCode === IdentificationCode.CODE_99) ? '01' : '04';
                    break;
                }
                case 'identificationDocument1judge': {
                    judgeResult = this.state.submitData.identificationDocument1 === IdentificationDocument.PASSPORT_NO_HOLDER ? '26' : '00';
                    break;
                }
                case 'identificationCode': {
                    judgeResult = this.state.submitData.identificationCode === IdentificationCode.CODE_99 ? '00' : '80';
                    break;
                }
                default: {
                    const choice = entity.choices.find((item) => {
                        return item.value === this.state.submitData[entity.name];
                    });
                    this.getNextChat(choice ? choice.next : entity.next, pageIndex);
                    return;
                }
            }
            entity.choices.forEach((choice) => {
                if (choice.value === judgeResult) {
                    this.getNextChat(choice.next, pageIndex);
                    return;
                }
            });
        }
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(choice: any) {
        const action = choice.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            this.modalService.showModal(action.value, { imgSrc: action.imgSrc });
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ROUTE) {
            this.chatFlowCompelete(action.value);
        }
    }
}
