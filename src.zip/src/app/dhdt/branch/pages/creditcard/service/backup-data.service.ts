import { Injectable } from '@angular/core';
import { InjectionUtils } from 'adep/utils';
import { CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';

@Injectable()
export class BackupDataService {
    private creditCardStore: CreditCardStore;

    constructor() {
        this.creditCardStore = InjectionUtils.injector.get(CreditCardStore);
    }

    /**
     * get checkedItem value
     * @param question checkedItem info
     */
    public getCheckedItemValue(question: string): string {
        if (question && question.indexOf('@AddressKana') !== -1) {
            return this.creditCardStore.getState().submitData.holderAddressPrefectureFuriKana +
                this.creditCardStore.getState().submitData.holderAddressCountyUrbanVillageFuriKana +
                this.creditCardStore.getState().submitData.getHolderAddressStreetNameFuriKana() +
                this.creditCardStore.getState().submitData.holderAddressHouseNumberFuriKana;
        }
        if (question && question.indexOf('@EmploymentAddressKana') !== -1) {
            return this.creditCardStore.getState().submitData.employmentHolderAddressPrefectureFuriKana +
                this.creditCardStore.getState().submitData.employmentHolderAddressCountyUrbanVillageFuriKana +
                (this.creditCardStore.getState().submitData.employmentHolderAddressStreetNameFuriKanaSelect
                    || this.creditCardStore.getState().submitData.employmentHolderAddressStreetNameFuriKanaInput || '') +
                this.creditCardStore.getState().submitData.employmentHolderAddressHouseNumberFuriKana;
        }
        if (question && question.indexOf('@ParentalAddressKana') !== -1) {
            return this.creditCardStore.getState().submitData.parentalHolderAddressPrefectureFuriKana +
                this.creditCardStore.getState().submitData.parentalHolderAddressCountyUrbanVillageFuriKana +
                (this.creditCardStore.getState().submitData.parentalAddressStreetNameFuriKanaSelect
                    || this.creditCardStore.getState().submitData.parentalAddressStreetNameFuriKanaInput || '') +
                this.creditCardStore.getState().submitData.parentalHolderAddressHouseNumberFuriKana;
        }
        return null;
    }
}
