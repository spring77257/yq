import { Injectable } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { InjectionUtils } from 'adep/utils';
import { TEMPLATE_FILE } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';

export namespace ConfirmPageComponentParamName {
    // クレジットカード
    export const CREDITCARD_BRAND: string = 'CREDITCARD_BRAND';
    export const CREDITCARD_DC_TYPE: string = 'CREDITCARD_DC_TYPE';
    // バンクカード情報
    export const PRINT_NAME: string = 'PRINT_NAME'; // お名前（ローマ字氏名）
    export const TRANS_PURPOSE: string = 'TRANS_PURPOSE'; // 取引目的
    export const CREDIT_CARD_PASSWORD: string = 'CREDIT_CARD_PASSWORD'; // クレジットカード暗証番号
    export const CASH_CARD_PASSWORD: string = 'CASH_CARD_PASSWORD'; // キャッシュカード暗証番号
    // お住いの情報
    export const HOUSE_TYPE: string = 'HOUSE_TYPE'; // お住まいの種類
    export const RESIDENCE_YEARS: string = 'RESIDENCE_YEARS'; // 居住年数
    export const LIVING_EXPENSES: string = 'LIVING_EXPENSES'; // 住宅ローン・家賃負担
    // 家族情報
    export const MARRIED: string = 'MARRIED'; // 結婚の有無
    export const LIVELIHOOD_PEOPLE: string = 'LIVELIHOOD_PEOPLE'; // 同一生計人数
    export const DEPENDENT_FAMILY: string = 'DEPENDENT_FAMILY'; // 扶養家族人数
    // 職業・お勤め先情報
    export const CREDITCARD_CAREER: string = 'CREDITCARD_CAREER'; // ご職業
    export const NEAR_GRADUATE: string = 'NEAR_GRADUATE'; // 卒業後ご職業(卒業90日以内の学生)
    export const NOW_CAREER: string = 'NOW_CAREER'; // 現在のご職業(卒業90日以内の学生)
    export const JOB_DESCRIPTION: string = 'JOB_DESCRIPTION'; // お仕事内容
    export const INDUSTRY_TYPE: string = 'INDUSTRY_TYPE'; // 業種
    export const EMPLOYMENT_NAME: string = 'EMPLOYMENT_NAME'; // お勤め先名称
    export const EMPLOYMENT_ADDRESS: string = 'EMPLOYMENT_ADDRESS'; // お勤め先住所
    export const BELONG_SECTION: string = 'BELONG_SECTION';
    export const BELONG_SECTIONKANA: string = 'BELONG_SECTIONKANA';
    export const CASHCARD_FAMILY_NAME: string = 'CASHCARD_FAMILY_NAME';
    export const EMPLOYMENT_TELEPHCOMMONNO: string = 'EMPLOYMENT_TELEPHCOMMONNO'; // お勤め先電話番号
    export const PHONENO_EXTENSION: string = 'PHONENO_EXTENSION'; // お勤め先内線番号
    export const ENTER_COMPANY_DATE: string = 'ENTER_COMPANY_DATE';
    export const FAMILY_MEMBER_NAME: string = 'FAMILY_MEMBER_NAME';
    export const CARD_FAMILY_MEMBER_NAME: string = 'CARD_FAMILY_MEMBER_NAME';
    export const FAMILY_MEMBER_BIRTHDATE: string = 'FAMILY_MEMBER_BIRTHDATE';
    export const FAMILY_MEMBER_GENDER: string = 'FAMILY_MEMBER_GENDER';
    export const FAMILY_MEMBER_RELATIONSHIP: string = 'FAMILY_MEMBER_RELATIONSHIP';
    export const DEPARTMENT: string = 'DEPARTMENT'; // 所属部課
    export const POSITION_NAME: string = 'POSITION_NAME'; // 役職名
    export const EMPLOYEE_NUMBER: string = 'EMPLOYEE_NUMBER'; // 従業員数
    export const LENGTH_OF_SERVICE: string = 'LENGTH_OF_SERVICE'; // 勤続年数
    export const JOB_CHANGE_TIMES: string = 'JOB_CHANGE_TIMES'; // 転職回数
    export const TAXINCLUDED_ANNUALINCOME: string = 'TAXINCLUDED_ANNUALINCOME'; // 前年度税込年収
    // 学校情報
    export const CREDIT_CARD_SCHOOL_NAME: string = 'CREDIT_CARD_SCHOOL_NAME'; // 学校名
    export const CREDIT_CARD_SCHOOL_YEAR: string = 'CREDIT_CARD_SCHOOL_YEAR';
    export const GRADUATE_DATE: string = 'GRADUATE_DATE'; // 卒業予定年月
    export const POST: string = 'POST';
    // 親権者情報
    export const GUARDIAN_NAME: string = 'GUARDIAN_NAME'; // 親権者お名前
    export const GUARDIAN_RELATION: string = 'GUARDIAN_RELATION'; // 続柄
    export const PARENTAL_BIRTHDAY: string = 'PARENTAL_BIRTHDAY'; // 親権者生年月日
    export const GUARDIAN_ADDRESS: string = 'GUARDIAN_ADDRESS'; // 親権者住所
    export const GUARDIAN_MOBILENO: string = 'GUARDIAN_MOBILENO'; // 親権者連絡先(携帯電話)
    export const GUARDIAN_TELEPHONE_NO: string = 'GUARDIAN_TELEPHONE_NO'; // 親権者連絡先(固定電話)
    export const PARENTAL_LIVING_TOGETHER: string = 'PARENTAL_LIVING_TOGETHER'; // 親権者と同居有無
    // 付帯サービス申込
    export const IS_ETC_CARD: string = 'IS_ETC_CARD'; // ETCカード
    export const CREDIT_CARD_FAMILY_PWD: string = 'CREDIT_CARD_FAMILY_PWD';
    export const DISPATCH_FROM_SERVICE_LENGTH: string = 'DISPATCH_FROM_SERVICE_LENGTH';
    export const SUICA_AUTO_CHARGE: string = 'SUICA_AUTO_CHARGE' ; // スイカオートチャージ
    export const REVO_PAY_COURSE: string = 'REVO_PAY_COURSE' ; // リボ払いコース
    export const MY_PACE_REVO: string = 'MY_PACE_REVO' ; // マイ・ペイすリボ
    export const LOAN_APPLICATION: string = 'LOAN_APPLICATION' ; // バンクカードローン
    export const IS_HAVE_UNSECUREDLOAN: string = 'IS_HAVE_UNSECUREDLOAN' ; // 無担保ローン契約
    export const OVER_DRAFTLIMIT: string = 'OVER_DRAFTLIMIT' ; // 希望貸越可能枠
}

export namespace ChartID {
    // キャッシュカード
    export const COMMON: Number = 198;
}

@Injectable()
export class CreditCardConfirmPageCommonService extends BaseComponent {
    private params: Map<string, any>;
    private store: CreditCardStore;
    private action: CreditCardAction;

    constructor() {
        super();
        this.store = InjectionUtils.injector.get(CreditCardStore);
        this.action = InjectionUtils.injector.get(CreditCardAction);
        this.params = new Map();
    }

    public loadConfirmTemplate() {
        this.action.loadConfirmPageTemplate(TEMPLATE_FILE.CREDIT_CARD_CONFIRMPAGE_COMMON, 198);
    }

    // クレジットカード
    public getCreditCardConfirmPageComponentParams() {
        const params: Map<string, any> = new Map();
        // おなまえ(ローマ字)
        // 外国人の場合
        if (this.store.getState().submitData.nameAlphabet) {
            params.set(ConfirmPageComponentParamName.PRINT_NAME,
                {
                    startOrder: 20035, endOrder: 20035, name: 'nameRoma',
                    currentTitle: this.labels.creditcard.credit.nameKana, pageIndex: ChartID.COMMON
                });
        } else {
            params.set(ConfirmPageComponentParamName.PRINT_NAME,
                {
                    startOrder: 11034, endOrder: 11034, name: 'nameRoma',
                    currentTitle: this.labels.creditcard.credit.nameKana, pageIndex: ChartID.COMMON
                });
        }
        // 取引目的
        params.set(ConfirmPageComponentParamName.TRANS_PURPOSE,
            {
                startOrder: 12001, endOrder: 12001, name: 'transPurpose',
                currentTitle: this.labels.creditcard.credit.transPurpose, pageIndex: ChartID.COMMON
            });
        // クレジットカード暗証番号
        params.set(ConfirmPageComponentParamName.CREDIT_CARD_PASSWORD,
            {
                startOrder: 13111, endOrder: 13111, name: 'creditCardPassword',
                currentTitle: this.labels.creditcard.credit.selfCard, pageIndex: ChartID.COMMON
            });
        // キャッシュカード暗証番号
        params.set(ConfirmPageComponentParamName.CASH_CARD_PASSWORD,
            {
                startOrder: 13112, endOrder: 13112, name: 'cashCardPassword',
                currentTitle: this.labels.creditcard.credit.cashCard, pageIndex: ChartID.COMMON
            });
        // お住いの種類
        params.set(ConfirmPageComponentParamName.HOUSE_TYPE,
            {
                startOrder: 22200, endOrder: 22225, name: 'houseType',
                currentTitle: this.labels.creditcard.creditCardFamilyInformation.livingType, pageIndex: ChartID.COMMON
            });
        // 居住年数
        params.set(ConfirmPageComponentParamName.RESIDENCE_YEARS,
            {
                startOrder: 11042, endOrder: 11042, name: 'residenceYears',
                currentTitle: this.labels.creditcard.creditCardFamilyInformation.livingYear, pageIndex: ChartID.COMMON
            });

        // 住宅ローン・家賃負担
        params.set(ConfirmPageComponentParamName.LIVING_EXPENSES,
            {
                startOrder: 18210, endOrder: 18225, name: 'livingExpenses',
                currentTitle: this.labels.creditcard.creditCardFamilyInformation.rent, pageIndex: ChartID.COMMON
            });
        // 配偶者の有無
        params.set(ConfirmPageComponentParamName.MARRIED,
            {
                startOrder: 30301, endOrder: 50027, name: 'married',
                currentTitle: this.labels.creditcard.houseHoldInformation.married, pageIndex: ChartID.COMMON
            });
        // 生計を同一とする方の人数
        params.set(ConfirmPageComponentParamName.LIVELIHOOD_PEOPLE,
            {
                startOrder: 11052, endOrder: 11052, name: 'livelihoodPeople',
                currentTitle: this.labels.creditcard.houseHoldInformation.livelihoodPeople, pageIndex: ChartID.COMMON
            });
        // 扶養家族の人数
        params.set(ConfirmPageComponentParamName.DEPENDENT_FAMILY,
            {
                startOrder: 11053, endOrder: 11053, name: 'dependentFamily',
                currentTitle: this.labels.creditcard.houseHoldInformation.dependentFamily, pageIndex: ChartID.COMMON
            });
        // ご職業
        params.set(ConfirmPageComponentParamName.CREDITCARD_CAREER,
            {
                startOrder: 40001, endOrder: 50027, name: 'career',
                currentTitle: this.labels.creditcard.income.occupation, pageIndex: ChartID.COMMON
            });
        // 現在のご職業
        params.set(ConfirmPageComponentParamName.NOW_CAREER,
            {
                startOrder: 40001, endOrder: 50027, name: 'nowCareer',
                currentTitle: this.labels.creditcard.income.occupation, pageIndex: ChartID.COMMON
            });
        // ご卒業後の職業
        params.set(ConfirmPageComponentParamName.NEAR_GRADUATE,
            {
                startOrder: 40054, endOrder: 50027, name: 'nearGraduate',
                currentTitle: this.labels.creditcard.income.afterGraduateOccupation, pageIndex: ChartID.COMMON
            });
        // 仕事内容
        params.set(ConfirmPageComponentParamName.JOB_DESCRIPTION,
            {
                startOrder: 12709, endOrder: 12709, name: 'jobDescription',
                currentTitle: this.labels.creditcard.income.occupation, pageIndex: ChartID.COMMON
            });
        // 業種
        params.set(ConfirmPageComponentParamName.INDUSTRY_TYPE,
            {
                startOrder: 23025, endOrder: 23026, name: 'industryType',
                currentTitle: this.labels.creditcard.income.occupation, pageIndex: ChartID.COMMON
            });
        // 勤務先名称
        params.set(ConfirmPageComponentParamName.EMPLOYMENT_NAME,
            {
                startOrder: 12715, endOrder: 12716, name: 'employmentName',
                currentTitle: this.labels.creditcard.constructionLandInformation.nameAndNo, pageIndex: ChartID.COMMON
            });
        // 住所 (勤務先)
        params.set(ConfirmPageComponentParamName.EMPLOYMENT_ADDRESS,
            {
                startOrder: 21101, endOrder: 21134, name: 'employmentAddress',
                currentTitle: this.labels.creditcard.constructionLandInformation.address, pageIndex: ChartID.COMMON
            });
        // 勤務先の電話番号
        params.set(ConfirmPageComponentParamName.EMPLOYMENT_TELEPHCOMMONNO,
            {
                startOrder: 12734, endOrder: 12734, name: 'employmentTelephoneNo',
                currentTitle: this.labels.creditcard.constructionLandInformation.tel, pageIndex: ChartID.COMMON
            });
        // 勤務先の内線番号
        params.set(ConfirmPageComponentParamName.PHONENO_EXTENSION,
            {
                startOrder: 12735, endOrder: 12737, name: 'phoneNoExtension',
                currentTitle: this.labels.creditcard.constructionLandInformation.phoneNoExtension, pageIndex: ChartID.COMMON
            });
        // 所属部課
        params.set(ConfirmPageComponentParamName.DEPARTMENT,
            {
                startOrder: 12738, endOrder: 12738, name: 'department',
                currentTitle: this.labels.creditcard.constructionLandInformation.department, pageIndex: ChartID.COMMON
            });
        // 役職名
        params.set(ConfirmPageComponentParamName.POSITION_NAME,
            {
                startOrder: 12739, endOrder: 12739, name: 'positionName',
                currentTitle: this.labels.creditcard.constructionLandInformation.officialPosition, pageIndex: ChartID.COMMON
            });
        // 従業員数
        params.set(ConfirmPageComponentParamName.EMPLOYEE_NUMBER,
            {
                startOrder: 12740, endOrder: 12740, name: 'employeeNumber',
                currentTitle: this.labels.creditcard.constructionLandInformation.employeesNumber, pageIndex: ChartID.COMMON
            });
        // 勤続（営業）年数
        params.set(ConfirmPageComponentParamName.LENGTH_OF_SERVICE,
            {
                startOrder: 12741, endOrder: 12741, name: 'lengthOfService',
                currentTitle: this.labels.creditcard.constructionLandInformation.lengthOfService, pageIndex: ChartID.COMMON
            });
        // 転職回数
        params.set(ConfirmPageComponentParamName.JOB_CHANGE_TIMES,
            {
                startOrder: 12742, endOrder: 12742, name: 'jobChangeTimes',
                currentTitle: this.labels.creditcard.constructionLandInformation.jobChangeTimes, pageIndex: ChartID.COMMON
            });
        // 前年度税込年収
        params.set(ConfirmPageComponentParamName.TAXINCLUDED_ANNUALINCOME,
            {
                startOrder: 12743, endOrder: 12743, name: 'taxIncludedAnnualIncomeLastYear',
                currentTitle: this.labels.creditcard.constructionLandInformation.taxIncludedAnnualIncomeLastYear, pageIndex: ChartID.COMMON
            });
        // 学校名
        params.set(ConfirmPageComponentParamName.CREDIT_CARD_SCHOOL_NAME,
            {
                startOrder: 12800, endOrder: 12801, name: 'schoolName',
                currentTitle: this.labels.creditcard.school.name, pageIndex: ChartID.COMMON
            });
        // 卒業予定年月
        params.set(ConfirmPageComponentParamName.GRADUATE_DATE,
            {
                startOrder: 40043, endOrder: 50027, name: 'graduateDate',
                currentTitle: this.labels.creditcard.school.graduationYM, pageIndex: ChartID.COMMON
            });
        // 親権者との同居有無
        params.set(ConfirmPageComponentParamName.PARENTAL_LIVING_TOGETHER,
            {
                startOrder: 16200, endOrder: 16255, name: 'parentalLivingTogether',
                currentTitle: this.labels.creditcard.parental.parentalLivingTogether, pageIndex: ChartID.COMMON
            });
        // 親権者のお名前
        params.set(ConfirmPageComponentParamName.GUARDIAN_NAME,
            {
                startOrder: 12904, endOrder: 12905, name: 'parentalName',
                currentTitle: this.labels.creditcard.parental.guardianName, pageIndex: ChartID.COMMON
            });
        // 続柄
        params.set(ConfirmPageComponentParamName.GUARDIAN_RELATION,
            {
                startOrder: 12906, endOrder: 12907, name: 'parentalRelationship',
                currentTitle: this.labels.creditcard.parental.guardianRelation, pageIndex: ChartID.COMMON
            });
        // 生年月日（親権者）
        params.set(ConfirmPageComponentParamName.PARENTAL_BIRTHDAY,
            {
                startOrder: 12908, endOrder: 12908, name: 'parentalBirthdate',
                currentTitle: this.labels.creditcard.parental.gradianBirthDay, pageIndex: ChartID.COMMON
            });
        // 住所（親権者）
        params.set(ConfirmPageComponentParamName.GUARDIAN_ADDRESS,
            {
                startOrder: 20211, endOrder: 20244, name: 'parentalAddress',
                currentTitle: this.labels.creditcard.parental.guardianAddress, pageIndex: ChartID.COMMON
            });
        // 携帯電話番号（親権者）
        params.set(ConfirmPageComponentParamName.GUARDIAN_MOBILENO,
            {
                startOrder: 12909, endOrder: 12914, name: 'parentalHolderMobileNo',
                currentTitle: this.labels.creditcard.parental.guardianMobileNo, pageIndex: ChartID.COMMON
            });
        // 固定電話番号（親権者）
        params.set(ConfirmPageComponentParamName.GUARDIAN_TELEPHONE_NO,
            {
                startOrder: 12911, endOrder: 12914, name: 'parentalHolderTelephoneNo',
                currentTitle: this.labels.creditcard.parental.guardianMobileNo, pageIndex: ChartID.COMMON
            });
         // ETCカード
        params.set(ConfirmPageComponentParamName.IS_ETC_CARD,
            {
                startOrder: 13003, endOrder: 13003, name: 'etcCategory',
                currentTitle: this.labels.creditcard.paymentMethod.etcCategory, pageIndex: ChartID.COMMON
            });
        // オートチャージ
        params.set(ConfirmPageComponentParamName.SUICA_AUTO_CHARGE,
            {
                startOrder: 13002, endOrder: 13002, name: 'suicaAutoCharge',
                currentTitle: this.labels.creditcard.paymentMethod.suicaAutoCharge, pageIndex: ChartID.COMMON
            });
        // リボ払いコース
        params.set(ConfirmPageComponentParamName.REVO_PAY_COURSE,
            {
                startOrder: 13004, endOrder: 13004, name: 'revoPayCourse',
                currentTitle: this.labels.creditcard.paymentMethod.revoPayCourse, pageIndex: ChartID.COMMON
            });
        // マイ・ペイすリボ
        params.set(ConfirmPageComponentParamName.MY_PACE_REVO,
            {
                startOrder: 13005, endOrder: 13005, name: 'myPaceRevo',
                currentTitle: this.labels.creditcard.paymentMethod.myPaceRevo, pageIndex: ChartID.COMMON
            });
        // バンクカードローン
        params.set(ConfirmPageComponentParamName.LOAN_APPLICATION,
            {
                startOrder: 17007, endOrder: 17015, name: 'loanApplication',
                currentTitle: this.labels.creditcard.paymentMethod.loanApplication, pageIndex: ChartID.COMMON
            });
        // 無担保ローン契約
        params.set(ConfirmPageComponentParamName.IS_HAVE_UNSECUREDLOAN,
            {
                startOrder: 19008, endOrder: 19015, name: 'isHaveUnsecuredLoan',
                currentTitle: this.labels.creditcard.paymentMethod.isHaveUnsecuredLoan, pageIndex: ChartID.COMMON
            });
        // 希望貸越可能枠
        params.set(ConfirmPageComponentParamName.OVER_DRAFTLIMIT,
            {
                startOrder: 13006, endOrder: 13009, name: 'overdraftLimit',
                currentTitle: this.labels.creditcard.paymentMethod.overdraftLimit, pageIndex: ChartID.COMMON
            });

        return params;
    }
}
