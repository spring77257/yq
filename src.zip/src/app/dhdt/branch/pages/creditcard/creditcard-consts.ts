/**
 * クレジットカード用定数
 */
export namespace CreditCardConsts {

    /**
     * 家族会員申込
     */
    export enum FamilyCardApply {
        // 申込
        Apply = '1',
        // 申し込まない
        NotApply = '2'
    }

    /**
     * 年齢
     */
    export enum AGE {
        // 18歳
        Age_18 = 18,
        // 20歳
        Age_20 = 20,
        // 30歳
        Age_30 = 30,
        // 66歳
        Age_66 = 66
    }

    /**
     * チャット表示のため待機する時間
     */
    export enum ShowTextTime {
        // 修正チャット、最後のorderがType:textのとき。
        END_MODIFY_CHAT = 3000,
    }

    // 生計費決済(固定)
    export const SHOPPING_AIM = '1';
}

// 申込業務区分
export class ApplyBusinessType {
    public static readonly DC = '50';
    public static readonly JCB = '51';
}

// 職業
export class Career {
    // 会社/団体役員
    public static readonly GROUP_OFFICERS = '01';
    // 官公庁職員
    public static readonly GOVERMENT_EMPLOYEE = '02';
    // 自営業
    public static readonly INDIVIDUAL_BUSINESS = '05';
    // 年金受給者
    public static readonly ANNUITY_PENSION = '06';
    // 派遣
    public static readonly DISPATCHING = '09';
    // パート/アルバイト
    public static readonly PART = '10';
    // 無職
    public static readonly UNEMPLOYED = '11';
    // その他
    public static readonly OTHER = '99';
    // 学生
    public static readonly STUDENT = '07';
    // 主婦
    public static readonly HOUSEWIFE = '08';
}

// 職業
export class CareerJcb {
    // 会社員1
    public static readonly GROUP_OFFICERS_1 = '01';
    // 公務員・弁護士・医師・公認会計士2
    public static readonly PUBLIC_OFFICER = '02';
    // 自営業者3
    public static readonly INDIVIDUAL_BUSINESS = '03';
    // 会社経営者4
    public static readonly CORPORATE_MANAGER = '04';
    // 契約社員5
    public static readonly CONTRACT_EMPLOYEE = '05';
    // 派遣社員6
    public static readonly DISPATCHING_EMPLOYEE = '06';
    // 嘱託社員7
    public static readonly COMMISSIONED_EMPLOYEE = '07';
    // バート・アルバイトの方8
    public static readonly PART = '08';
    // 年金が主な収入の方9
    public static readonly ANNUITY_PENSION = '09';
    // 不動産が主な収入の方10
    public static readonly INCOME_ESTATE = '10';
    // 主婦の方11
    public static readonly HOUSEWIFE = '11';
    // 学生の方12
    public static readonly STUDENT = '12';
    // その他13
    public static readonly OTHER = '13';
}

// 業種
export class IndustryType {
    // 業種その他
    public static readonly INDUSTORY_TYPE_OTHER = '99';
}

// 結婚有無
export class IsMarried {
    // 独身
    public static readonly UN_MARRIED = '0';
    // 既婚
    public static readonly MARRIED = '1';
}

// 性別
export class Gender {
    // 男性
    public static readonly MALE = '1';
    // 女性
    public static readonly FEMALE = '2';
}

// 職業パターン区分
export class JobPattern {
    // パターン区分1
    public static readonly JOB_PATTERN_01 = '1';
    // パターン区分2
    public static readonly JOB_PATTERN_02 = '2';
    // パターン区分3
    public static readonly JOB_PATTERN_03 = '3';
    // パターン区分4
    public static readonly JOB_PATTERN_04 = '4';

}

// バンクカード種類
export class BankCardType {
    // 横浜バンクカードVISA
    public static readonly BC_VISA = '41';
    // 横浜バンクカードMastercard
    public static readonly BC_MASTERCARD = '42';
    // バンクカードSuica
    public static readonly BC_SUICA = '43';
    // バンクカードヤングゴールドVISA
    public static readonly BC_YOUNG_GOLD_VISA = '51';
    // バンクカードヤングゴールドSUICA
    public static readonly BC_YOUNG_GOLD_SUICA = '53';
    // バンクカードゴールド
    public static readonly BC_GOLD = '61';
    // バンクカードゴールドSUICA
    public static readonly BC_GOLD_SUICA = '63';
}

// カードコンポネートタイプ
export class CreditInputPattern {
    // 勤務先情報
    public static readonly EMPLOYMENT = 'employment';
    // 親権者情報
    public static readonly PARENTAL = 'parental';
}

// 家族会員申込
export class IsFamilyMembership {
    // 申し込む
    public static readonly APPLY = '1';
    // 申し込まない
    public static readonly NOT_APPLY = '2';
}

// 家族会員年齢判定
export class FamilyMemberAgeRange {
    // 18歳未満の場合
    public static readonly BELOW_18 = '0';
    // 18歳以上の場合
    public static readonly ABOVE_18 = '1';
}

// 年齢判定
export class CreditCardAgeRange {
    // 18歳未満の場合
    public static readonly BELOW_18 = '1';
    // 18歳~20歳未満の場合
    public static readonly FROM_18_TO_20 = '2';
    // 20歳~65歳以下の場合
    public static readonly FROM_20_TO_66 =  '3';
    // 66歳以上場合
    public static readonly ABOVE_66 = '4';
}

// ETCカード
export class IsEtcCard {
    // 申し込む
    public static readonly APPLY = '1';
    // 申し込まない
    public static readonly NOT_APPLY = '0';
}

// ブランド
export class CreditCardBrand {
    // VISA
    public static readonly VISA = '1';
    // Mastercard
    public static readonly MASTERCARD = '2';
    // JCB
    public static readonly JCB = '3';
}

// ランク
export class CreditCardRank {
    // 一般
    public static readonly NORMAL = '1';
    // ゴールド
    public static readonly GOLD = '2';
    // エクステージ
    public static readonly EXTAGE_BLACK = '3';
}

// 携帯電話料金支払
export class MobileFarePayment {
    // クレジット決済にする
    public static readonly HAVE = '1';
    // クレジット決済にしない
    public static readonly NOT_HAVE = '0';
}

// 文字列長さの最大
export class MaxLength {
    // 最大文字が17場合
    public static readonly MAX_LENGTH_17 = 17;
    // 最大文字が18場合
    public static readonly MAX_LENGTH_18 = 18;
    // 最大文字が19場合
    public static readonly MAX_LENGTH_19 = 19;
}

// カードコンポネートタイプ
export class CardComponentType {
    // カード
    public static readonly CARD = 'card';
    // ボタン
    public static readonly BUTTON = 'button';
}

// 親権者の続柄
export class ParentalRelation {
    // 親権者の続柄-その他
    public static readonly OTHER = '3';
}

// 親権者同居
export class IsParentalLivingTogether {
    // はい
    public static readonly YES = '1';
    // いいえ
    public static readonly NO = '0';
}

// バンクカードローン申し込み
export class IsBankCardLoan {
    // 申し込みあり
    public static readonly IS_APPLY = '1';
    // 申し込み無し
    public static readonly IS_NOT_APPLY = '0';
    // 選択肢　はい
    public static readonly YES = 'はい';
    // 選択肢　いいえ
    public static readonly NO = 'いいえ';
    // 申し込む文言
    public static readonly IS_APPLY_TEXT = '申し込む';
    // 申し込まない文言
    public static readonly IS_NOT_APPLY_TEXT = '申し込まない';
}

//  バンクカード画像
export  class BankCardImage {
    //  バンクカード（VISA）
    public static readonly VISA_NORMAL =  './assets/imgs/common/bankcard_visa_320px@2x.png';
    //  バンクカードゴールド（VISA）
    public static readonly VISA_GOLD =  './assets/imgs/common/bankcardgold_320px@2x.png';
    //  バンクカード（Mastercard）
    public static readonly MASTERCARD =  './assets/imgs/common/bankcard_master_320px@2x.png';
    //  バンクカードSuica
    public static readonly SUICA_NORMAL =  './assets/imgs/common/suica_320px@2x.png';
    //  バンクカードゴールドSuica
    public static readonly SUICA_GOLD =  './assets/imgs/common/suicagold_320px@2x.png';
}

export class HouseType {
    // 自己所有
    public static readonly SELF_OWNED = '01';
    // 家族所有
    public static readonly FAMILY_OWNED = '02';
}

/**
 * お住まいの種類(複数修正チャット用)
 */
export class HouseOwnType {
    // 所有:一般選択の01~02
    public static readonly OWN = '01';
    // 賃貸:一般選択の03~99
    public static readonly RENTAL = '02';
}

/**
 * お住まいの種類(一般選択)
 */
export class HouseActureType {
    // 自己所有
    public static readonly OWNED = '01';
    // 家族所有
    public static readonly FAMILY_OWNED = '02';
    // 社宅・寮
    public static readonly COMPANY_HOUSING = '03';
    // 借家
    public static readonly RENTED_HOUSE = '04';
    // アパート
    public static readonly APARTMENT = '07';
    // 公団・公営
    public static readonly PUBLIC_HOUSING = '08';
    // 賃貸マンション
    public static readonly RENTAL_APARTMENT = '06';
    // その他
    public static readonly OTHERS = '99';
}

/**
 * 住宅ローン負担
 */
export class HouseLoan {
    // 住宅ローンあり
    public static readonly HOUSELOAN_YES = '住宅ローンあり';
    // 住宅ローンなし
    public static readonly HOUSELOAN_NO = '住宅ローンなし';
}

/**
 * 住宅ローン負担
 */
export class HouseLoanValue {
    // 住宅ローンあり
    public static readonly HOUSELOAN_YES = '2';
    // 住宅ローンなし
    public static readonly HOUSELOAN_NO = '1';
}
/**
 * 家賃負担
 */
export class LivingExpenses {
    // 家賃負担あり
    public static readonly LIVING_EXPENSES_YES = '家賃負担あり';
    // 家賃負担なし
    public static readonly LIVING_EXPENSES_NO = '家賃負担なし';
}

/**
 * 卒業90日以内のフラグ
 */
export class IsNearGraduate {
    // 卒業90日以内
    public static readonly YES = '1';
}

// 職業名称
export class CareerText {
    // 会社/団体役員
    public static readonly GROUP_OFFICERS = '正社員';
    // 官公庁職員
    public static readonly GOVERMENT_EMPLOYEE = '官公庁職員';
    // 自営業
    public static readonly INDIVIDUAL_BUSINESS = '自営業';
    // 年金受給者
    public static readonly ANNUITY_PENSION = '年金受給者';
    // 派遣
    public static readonly DISPATCHING = '派遣';
    // パート/アルバイト
    public static readonly PART = 'パート・アルバイト';
    // 無職
    public static readonly UNEMPLOYED = '無職';
    // その他
    public static readonly OTHER = 'その他';
    // 学生
    public static readonly STUDENT = '学生';
    // 主婦
    public static readonly HOUSEWIFE = '主婦';
}

// バンクカードローン希望貸越可能枠
export class OverdraftLimit {
    // 10万円
    public static readonly OVERDRAFT_LIMIT_10 = '01';
    // 30万円
    public static readonly OVERDRAFT_LIMIT_30 = '02';
    // 50万円
    public static readonly OVERDRAFT_LIMIT_50 = '03';
}

// 画面にバンクカード申し込みを選択
export class IsBankCardSelected {
    // 申し込みあり
    public static readonly IS_SELECTED = '1';
    // 申し込み無し
    public static readonly IS_NOT_SELECTED = '0';
}

// 画面にバンクカードゴールド申し込みを選択
export class IsBankCardGoldSelected {
    // 申し込みあり
    public static readonly IS_SELECTED = '1';
    // 申し込み無し
    public static readonly IS_NOT_SELECTED = '0';
}

// 画面にバンクカードSuica申し込みを選択
export class IsBankCardSuicaSelected {
    // 申し込みあり
    public static readonly IS_SELECTED = '1';
    // 申し込み無し
    public static readonly IS_NOT_SELECTED = '0';
}

// 画面にバンクカードSuicaゴールド申し込みを選択
export class IsBankCardSuicaGoldSelected {
    // 申し込みあり
    public static readonly IS_SELECTED = '1';
    // 申し込み無し
    public static readonly IS_NOT_SELECTED = '0';
}

// 受付状態
export class ReceptionStatus {
    // 受付不可
    public static readonly NO = '1';
    // 受付可能
    public static readonly YES = '0';
}

// 複合取引フラグ
export class IsCompositApply {
    // はい(複合取引)
    public static readonly YES  = '01';
    // いいえ(複合取引ではない)
    public static readonly NO = '00';
}

// 申込カード(複合取引時)
export class CompositCardType {
    // BC
    public static readonly BC  = '01';
    // BC suica
    public static readonly BC_SUICA = '02';
    // BC gold
    public static readonly BC_GOLD = '03';
    // BC suicaGold
    public static readonly BC_SUICA_GOLD = '04';
}

export class TradingCondition {
    public static readonly BC_HOLDING = '13';
}

// 書類
export class IdentificationDocument {
    // 在留カード・特別永住者証明書
    public static readonly RESIDENCE_CARD_SPECIAL_PERMANENT = '06';
    // 学生証
    public static readonly STUDENT_ID = '21';
    // 在留カード
    public static readonly RESIDENCE_CARD = '31';
    // 特別永住者証明書
    public static readonly SPECIAL_PERMANENT = '32';
    // 運転免許証
    public static readonly DRIVER_LICENSE = '01';
    // パスポート（所持人記入欄あり）
    public static readonly PASSPORT_HOLDER = '03';
    // パスポート（所持人記入欄なし）
    public static readonly PASSPORT_NO_HOLDER = '26';
    // 福祉手帳（顔写真付）
    public static readonly WELFARE_NOTEBOOK_WITH_FACE_PHOTO = '05';
    // 住民基本台帳カード（顔写真付）
    public static readonly BASIC_RESIDENT_REGISTER_CARD_WITH_FACE_PHOTO = '20';
    // マイナンバーカード
    public static readonly MY_NUMBER_CARD = '08';
    // その他官公庁から発行された書類（顔写真付）
    public static readonly OTHER_GOVERNMENT_DOCUMENTS_WITH_FACE_PHOTO = '09';

}
