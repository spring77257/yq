import { Component, OnDestroy, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import {
    CareerJcb, CreditCardAgeRange, IsFamilyMembership
} from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardConfirmPageCommonService } from 'dhdt/branch/pages/creditcard/service/creditcard-confirmpage.common.service';
import { CreditCardSignal, CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { CreditCardInitConfirmJcbComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-initconfirm-jcb.component';
import { ModalDigitalStore } from 'dhdt/branch/shared/components/modal/modal-digital/store/modal-digital.store';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { CreditCardPrepareDataUtil } from 'dhdt/branch/shared/utils/creditcard-prepare-data-util';
import { NavController } from 'ionic-angular';

/**
 * 行員確認画面（クレジットカード）
 */
@Component({
    selector: 'creditcard-confirm-component-jcb',
    templateUrl: 'creditcard-confirm-jcb.component.html'
})
export class CreditCardConfirmJcbComponent extends BaseComponent implements OnInit, OnDestroy {
    public state: CreditCardState;
    public confirmPageCommonParams: Map<string, any> = null;
    public submitted: boolean = false;
    public isClerkConfirm: boolean = true;
    public saveShowChats: any = {};
    public processType = 3;
    public isSelfApplyConfirm: boolean = true;  // distinguish 申込内容確認 from (行員確認用)ご本人確認

    constructor(
        private action: CreditCardAction,
        private navCtrl: NavController,
        private store: CreditCardStore,
        private confirmPageCommonService: CreditCardConfirmPageCommonService,
        private creditCardPrepareDataUtil: CreditCardPrepareDataUtil,
        private modalDigitalStore: ModalDigitalStore,
        private modalService: ModalService,
        private savingsAction: SavingsAction,
        private cancelAction: CancelAction,
        private logging: LoggingService,
    ) {
        super();
        this.state = this.store.getState();
    }

    public ngOnInit() {
        // chat
        this.state.showConfirm.forEach((item) => {
            if (item.type !== 'judge') {
                if (item.name === 'familyApply') {
                    if (item.answer && item.answer.text) {
                        item.answer.text = this.state.submitData.familyApply === IsFamilyMembership.APPLY
                            ? this.labels.creditcard.applyBtn : this.labels.creditcard.applyNotBtn;
                    }
                }
                this.saveShowChats[item.name] = item;
            }
        });

        this.initPageData();
        this.registerSignalHandlers();
    }

    public ngOnDestroy(): void {
        this.unregisterSignalHandlers();
        this.clearMemory();
    }

    public clearMemory() {
        this.action.clearStore();
    }

    public hideConstructionLandInformation() {
        // 会社員1
        // 会社経営者2
        // 自営業者3
        // 公務員・弁護士・医師・公認会計士4
        // 契約社員5
        // 派遣社員6
        // 嘱託社員7
        // バート・アルバイトの方8
        // 年金が主な収入の方9  不動産が主な収入の方10  主婦の方11  学生の方12 上記以外の方13
        if (this.state.submitData.career === CareerJcb.INCOME_ESTATE
            || this.state.submitData.career === CareerJcb.HOUSEWIFE
            || this.state.submitData.career === CareerJcb.ANNUITY_PENSION
            || this.state.submitData.career === CareerJcb.STUDENT) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 収入を表示するかどうかの判断
     */
    public hideAnnualIncome() {
        if (this.state.submitData.career === CareerJcb.HOUSEWIFE
            || this.state.submitData.career === CareerJcb.STUDENT) {
            return true;
        } else {
            return false;
        }
    }

    public hideFamilyInformation() {
        // 会社員1
        // 会社経営者2
        // 自営業者3
        // 公務員・弁護士・医師・公認会計士4
        // 契約社員5
        // 派遣社員6
        // 嘱託社員7
        // バート・アルバイトの方8
        // 年金が主な収入の方9  不動産が主な収入の方10  主婦の方11  学生の方12 上記以外の方13
        if (this.state.submitData.career === CareerJcb.HOUSEWIFE
            || this.state.submitData.career === CareerJcb.STUDENT) {
            return true;
        } else {
            return false;
        }
    }

    public hideSchoolInformation() {
        // 会社員1
        // 会社経営者2
        // 自営業者3
        // 公務員・弁護士・医師・公認会計士4
        // 契約社員5
        // 派遣社員6
        // 嘱託社員7
        // バート・アルバイトの方8
        // 年金が主な収入の方9  不動産が主な収入の方10  主婦の方11  学生の方12 上記以外の方13
        if (this.state.submitData.career === CareerJcb.STUDENT) {
            return false;
        } else {
            return true;
        }
    }

    public hideParentalInformation() {
        // 会社員1
        // 会社経営者2
        // 自営業者3
        // 公務員・弁護士・医師・公認会計士4
        // 契約社員5
        // 派遣社員6
        // 嘱託社員7
        // バート・アルバイトの方8
        // 年金が主な収入の方9  不動産が主な収入の方10  主婦の方11  学生の方12 上記以外の方13
        if (this.state.submitData.career === CareerJcb.STUDENT) {
            return false;
        }

        return this.hideParentalWarning();
    }

    public hideParentalWarning() {
        // 18-20歳の場合、ワーニングを表示する
        if (this.state.submitData.ageClassification === CreditCardAgeRange.FROM_18_TO_20) {
            return false;
        }
        return true;
    }

    public returnBack() {
        this.navCtrl.push(CreditCardInitConfirmJcbComponent);
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo[0].screenId,
            this.labels.logging.AccountConfirm.backConfirmButton,
        );
    }

    /**
     * '認証する' button click
     */
    public submit() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo[0].screenId,
            this.labels.logging.AccountConfirm.confirmButton,
        );
        this.submitted = true;
        this.action.saveCreditCardData(this.prepareSubmitData());
    }

    /**
     * push nextPage
     */
    public pushNextPage() {
        this.modalService.showCompleteModal().subscribe({
            next: (event) => {
                switch (event) {
                    case COMMON_CONSTANTS.BACK_TYPE_REAPPLY_MENU:
                        this.navCtrl.setRoot(ChatComponent, { reapplyFlg: true });
                        break;
                    default:
                        this.navCtrl.setRoot(TopComponent);
                }
            },
            complete: () => {
                this.savingsAction.clearStore();
                this.cancelAction.clearStore();
            }
        });
    }

    /**
     * prepare data
     */
    public prepareSubmitData(): any {
        // 行員登録画面に遷移するとき、入力する行員IDを記録する
        this.action.setBankclerkId(this.modalDigitalStore.getState().bankclerkId);
        return this.creditCardPrepareDataUtil.prepareCreditCardSavingsJcbSubmitData(this.state);
    }

    /**
     * 画面データ初期化する
     */
    private initPageData() {
        // 行員認証開始時間を記録する
        this.action.setBankclerkAuthenticationStartDate();
    }

    /**
     * registerSignalHandlers
     */
    private registerSignalHandlers() {
        this.store.registerSignalHandler(CreditCardSignal.SUCCESS_INSERT_INFO, () => {
            this.pushNextPage();
        });
    }

    /**
     * unregisterSignalHandlers
     */
    private unregisterSignalHandlers() {
        this.store.unregisterSignalHandler(CreditCardSignal.SUCCESS_INSERT_INFO);
    }
}
