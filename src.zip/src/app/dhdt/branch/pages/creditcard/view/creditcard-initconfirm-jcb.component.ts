import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { DeviceService } from 'dhd/common/services/device.service';
import { CompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/completion.component';
import { ChangeConfirmPageCommonService } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import { ZipCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import {
    CareerJcb, CreditCardAgeRange, CreditCardRank, IsEtcCard, IsFamilyMembership, IsParentalLivingTogether, MobileFarePayment
} from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardConfirmPageCommonService } from 'dhdt/branch/pages/creditcard/service/creditcard-confirmpage.common.service';
import { CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController } from 'ionic-angular';

/**
 * 申込内容確認画面（クレジットカード）
 */
@Component({
    selector: 'creditcard-initconfirm-component-jcb',
    templateUrl: 'creditcard-initconfirm-jcb.component.html'
})
export class CreditCardInitConfirmJcbComponent extends BaseComponent implements OnInit {
    public state: CreditCardState;
    public confirmPageCommonParams: Map<string, any> = null;
    public changeConfirmPageParams: Map<string, any> = null;
    public changeHolderMobileNoFlag: boolean = false;
    public saveShowChats: any = {};
    public processType = 2;
    public isSelfApplyConfirm: boolean = true;  // distinguish 申込内容確認 from (行員確認用)ご本人確認

    public showConfirmPassword: string = '';
    public editedList: any = {};
    constructor(
        private action: CreditCardAction,
        private navCtrl: NavController,
        private store: CreditCardStore,
        private confirmPageCommonService: CreditCardConfirmPageCommonService,
        private changeConfirmPageService: ChangeConfirmPageCommonService,
        private modalCtrl: ModalController,
        private logging: LoggingService,
        private deviceService: DeviceService,
    ) {
        super();
        this.state = this.store.getState();
    }

    public ngOnInit() {
        // get 修正 detail
        this.confirmPageCommonService.loadConfirmTemplate();
        this.changeConfirmPageService.loadConfirmTemplate();
        this.changeConfirmPageParams = this.changeConfirmPageService.getChangeConfirmPageComponentParams();
        this.getParentalZipCode();

        this.state.showConfirm.forEach((item) => {
            if (item.type !== 'judge') {
                if (item.name === 'familyApply') {
                    if (item.answer && item.answer.text) {
                        item.answer.text = this.state.submitData.familyApply === IsFamilyMembership.APPLY
                            ? this.labels.creditcard.applyBtn : this.labels.creditcard.applyNotBtn;
                    }
                }
                this.saveShowChats[item.name] = item;
            }
        });
        this.action.setEditNameKanji();
    }

    // headerTitle
    public get headerTitle(): string {
        return this.labels.creditcard.titleHeader;
    }

    // click 'お申込み' button
    public moveToNextPage() {
        const param = {
            tabletApplyId: this.state.tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            terminalNo: this.deviceService.getDeviceId(),
            accountNo: this.state.submitData.swipeAccountNo,
            tenban: this.state.submitData.swipeBranchNo,
            accountType: this.state.submitData.swipeAccountType
        };

        const modal = this.modalCtrl.create(ModalPasswordComponent,
            {
                data: {
                    text: this.labels.creditcard.passwordConfirm.text,
                    subText: this.labels.creditcard.passwordConfirm.subText,
                    units: 4,
                    needConfirm: false,
                    cashcardParams: param,
                    errorMessage: this.labels.confirm.passwordModal.errorMessage
                }
            },
            { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.onDidDismiss((value) => {
            if (value) {
                this.action.setCustomerApplyEndDate();
                this.navCtrl.push(CompletionComponent);
            }
        });
        modal.present();
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo[0].screenId,
            this.labels.logging.InfoComfirm.ApplyButton,
        );
    }

    public hideConstructionLandInformation() {
        // 会社員1
        // 会社経営者2
        // 自営業者3
        // 公務員・弁護士・医師・公認会計士4
        // 契約社員5
        // 派遣社員6
        // 嘱託社員7
        // バート・アルバイトの方8
        // 年金が主な収入の方9  不動産が主な収入の方10  主婦の方11  学生の方12 上記以外の方13
        if (this.state.submitData.career === CareerJcb.INCOME_ESTATE
            || this.state.submitData.career === CareerJcb.HOUSEWIFE
            || this.state.submitData.career === CareerJcb.ANNUITY_PENSION
            || this.state.submitData.career === CareerJcb.STUDENT) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 収入を表示するかどうかの判断
     */
    public hideAnnualIncome() {
        if (this.state.submitData.career === CareerJcb.HOUSEWIFE
            || this.state.submitData.career === CareerJcb.STUDENT) {
            return true;
        } else {
            return false;
        }
    }

    public hideFamilyInformation() {
        // 会社員1
        // 会社経営者2
        // 自営業者3
        // 公務員・弁護士・医師・公認会計士4
        // 契約社員5
        // 派遣社員6
        // 嘱託社員7
        // バート・アルバイトの方8
        // 年金が主な収入の方9  不動産が主な収入の方10  主婦の方11  学生の方12 上記以外の方13
        if (this.state.submitData.career === CareerJcb.HOUSEWIFE
            || this.state.submitData.career === CareerJcb.STUDENT) {
            return true;
        } else {
            return false;
        }
    }

    public hideSchoolInformation() {
        // 会社員1
        // 会社経営者2
        // 自営業者3
        // 公務員・弁護士・医師・公認会計士4
        // 契約社員5
        // 派遣社員6
        // 嘱託社員7
        // バート・アルバイトの方8
        // 年金が主な収入の方9  不動産が主な収入の方10  主婦の方11  学生の方12 上記以外の方13
        if (this.state.submitData.career === CareerJcb.STUDENT) {
            return false;
        } else {
            return true;
        }
    }

    public hideParentalInformation() {
        // 会社員1
        // 会社経営者2
        // 自営業者3
        // 公務員・弁護士・医師・公認会計士4
        // 契約社員5
        // 派遣社員6
        // 嘱託社員7
        // バート・アルバイトの方8
        // 年金が主な収入の方9  不動産が主な収入の方10  主婦の方11  学生の方12 上記以外の方13
        if (this.state.submitData.career === CareerJcb.STUDENT) {
            return false;
        }
        if (this.state.submitData.ageClassification === CreditCardAgeRange.FROM_18_TO_20) {
            return false;
        }
        return true;
    }

    /**
     *  親権者の郵便番号
     */
    public getParentalZipCode() {
        if (!this.state.submitData.firstZipCode && !this.state.submitData.lastZipCode) {
            if (this.state.submitData.parentalAddressPrefecture && this.state.submitData.parentalAddressCountyUrbanVillage) {
                this.action.getHolderZipCode(
                    this.state.submitData.parentalAddressPrefecture,
                    this.state.submitData.parentalAddressCountyUrbanVillage,
                    this.state.submitData.getParentalAddressStreetName());
            } else {
                this.action.setDefaultZipCode();
            }
        }
    }

    /**
     * 親権者の郵便番号 emitter
     */
    public changePostSkipEmitterHandler() {
        this.getParentalZipCode();
    }

    /**
     * ボタン制御
     */
    public get footerBtnDisable() {

        // 家族会員申込 申し込む
        if (this.state.submitData.familyApply === IsFamilyMembership.APPLY) {
            if (!this.state.submitData.getFamilyMemberName()
                || !this.state.submitData.getFamilyMemberNameFurigana()
                || !this.state.submitData.getCardFamilyMemberName()
                || !this.state.submitData.familyBirthdate
                || !this.state.submitData.familyGender
                || !this.state.submitData.familyRelationship
                || !this.state.submitData.creditCardFamilyFirstPwd4bits) {
                return true;
            }
        }

        // ETCカード 申し込む
        if (this.state.submitData.etcCard === IsEtcCard.APPLY) {
            if (!this.state.submitData.quicPay || !this.state.submitData.mobileFarePayment) {
                return true;
            }

            if (this.state.submitData.mobileFarePayment === MobileFarePayment.HAVE) {
                if (!this.state.submitData.mobileOperators || !this.state.submitData.getCreditRegisterTelephoneNo()) {
                    return true;
                }
            }
        }

        if (this.state.submitData.parentalLivingTogetherFlag === IsParentalLivingTogether.NO &&
            (this.state.submitData.ageClassification === CreditCardAgeRange.FROM_18_TO_20 ||
            this.state.submitData.career === CareerJcb.STUDENT)) {
            if (!StringUtils.validateAddressKana(this.state.submitData.getAddressFurikana())) {
                return true;
            }
        }
        return false;
    }

    public get isNotBlackCard() {
        return this.state.submitData.cardRank !== CreditCardRank.EXTAGE_BLACK;
    }

    /**
     * 変更項目を設定
     * @param data 変更項目
     */
    public handleItemChangedEmitter(data) {
        this.action.setStateSubmitDataValue(
            {
                name: 'holderName',
                value: data.holderNameKanji,
            }
        );
    }

}
