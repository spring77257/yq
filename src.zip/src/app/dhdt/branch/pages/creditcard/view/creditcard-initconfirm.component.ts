import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { CompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/completion.component';
import { ChangeConfirmPageCommonService } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import { AccountType, ApplyBC, BusinessCode, IdentificationCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { Career, CreditCardAgeRange, IsFamilyMembership, IsMarried } from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardConfirmPageCommonService } from 'dhdt/branch/pages/creditcard/service/creditcard-confirmpage.common.service';
import { CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { BussinessCode } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import { ExistingSavingsStore } from 'dhdt/branch/pages/existing-savings/store/existing-savings.store';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { ModalController, NavController, NavParams } from 'ionic-angular';

/**
 * 申込内容確認画面（クレジットカード）
 */
@Component({
    selector: 'creditcard-initconfirm-component',
    templateUrl: 'creditcard-initconfirm.component.html'
})
export class CreditCardInitConfirmComponent extends BaseComponent implements OnInit {
    public state: CreditCardState;
    public confirmPageCommonParams: Map<string, any> = null;
    public changeConfirmPageParams: Map<string, any> = null;
    public changeHolderMobileNoFlag: boolean = false;
    public saveShowChats: any = {};
    public processType = 2;
    public tabletApplyId: number;

    public isSelfApplyConfirm: boolean = true;  // distinguish 申込内容確認 from (行員確認用)ご本人確認

    public showConfirmPassword: string = '';
    public editedList: any = {};
    public businessCode: string;
    public submitData: any;
    public savingCreditcardPasswordChangeRequiredFlag: boolean = false;
    public savingDepositPasswordChangeRequiredFlag: boolean = false;

    constructor(
        private loginStore: LoginStore,
        private rsaService: RsaEncryptService,
        private action: CreditCardAction,
        private navCtrl: NavController,
        private store: CreditCardStore,
        private confirmPageCommonService: CreditCardConfirmPageCommonService,
        private changeConfirmPageService: ChangeConfirmPageCommonService,
        private modalCtrl: ModalController,
        private logging: LoggingService,
        private savingStore: SavingsStore,
        private savingAction: SavingsAction,
        private existingSavingsStore: ExistingSavingsStore,
        private existingSavingsAction: ExistingSavingsAction,
        private params: NavParams,
        private rsaEncryptService: RsaEncryptService
    ) {
        super();
        this.state = this.store.getState();
    }

    public ngOnInit() {
        this.submitData = this.params.get('submitData');

        // submitDataをセット
        if (this.submitData) {
            this.action.setData(this.submitData);
        }
        this.getHolderZipCode();
        if (this.state.submitData.ifApplyBC !== ApplyBC.YES) {
            this.action.setStateSubmitDataValue(
                {
                    name: 'accountType',
                    value: AccountType.CREDIT_CARD,
                }
            );
        } else {
            if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
                this.businessCode = BussinessCode.EXISTING_SAVINGS;
            }
        }
        // 認証の場合
        this.action.setStateSubmitDataValue([{
            name: 'isModify',
            value: '2'
        }]);
        // get 修正 detail
        this.confirmPageCommonService.loadConfirmTemplate();
        this.confirmPageCommonParams = this.confirmPageCommonService.getCreditCardConfirmPageComponentParams();
        this.changeConfirmPageService.loadConfirmTemplate();
        this.changeConfirmPageParams = this.changeConfirmPageService.getChangeConfirmPageComponentParams();
        // chat
        this.state.showConfirm.forEach((item) => {
            if (item.type !== 'judge') {
                if (item.name === 'familyApply') {
                    if (item.answer && item.answer.text) {
                        item.answer.text = this.state.submitData.familyApply === IsFamilyMembership.APPLY
                            ? this.labels.creditcard.applyBtn : this.labels.creditcard.applyNotBtn;
                    }
                }
                this.saveShowChats[item.name] = item;
            }
        });
        this.action.setEditNameKanji();
    }

    public savingDepositPasswordChangeRequiredEmitter(value: boolean) {
        this.savingDepositPasswordChangeRequiredFlag = value;
    }

    public savingCreditcardPasswordChangeRequiredEmitter(value: boolean) {
        this.savingCreditcardPasswordChangeRequiredFlag = value;
    }

    // headerTitle
    public get headerTitle(): string {
        return this.labels.creditcard.titleHeader;
    }

    // click 'お申込み' button
    public moveToNextPage() {
        this.action.setCustomerApplyEndDate();
        // 複合取引の場合、暗証番号を入力させる
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            // 既存新規スワイプありの場合、スワイプしたキャッシュカードの暗証番号で認証
            if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS && this.state.submitData.cardInfo) {
                const modal = this.modalCtrl.create(ModalPasswordComponent,
                    {
                        data: {
                            text: this.labels.password.inputPasswordAgainText,
                            subText: this.labels.password.inputPasswordAgainSubText,
                            units: 4,
                            needConfirm: false,
                            validation: (password) => this.action.validatePassword({
                                tabletApplyId: this.state.submitData.tabletApplyId, // タブレット申込管理ID
                                params: {
                                    receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                                    tenban: this.state.submitData.cardInfo.branchNo, // 店番
                                    accountType: this.state.submitData.cardInfo.accountType, // 科目
                                    accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                                    icCardInfo: this.savingStore.getState().icData,  // カード情報を入れる
                                    passcode: this.rsaEncryptService.encrypt(password)  // 暗証番号
                                }
                            })
                        }
                    },
                    { cssClass: 'settings-modal', enableBackdropDismiss: false });
                modal.onDidDismiss((value) => {
                    if (value && value.result) {
                        this.navCtrl.push(CompletionComponent);
                    }
                });
                modal.present();
            } else {
                // スワイプなし、または既存新規SWなしの場合、入力したキャッシュカードの暗証番号で認証
                const modal = this.modalCtrl.create(
                    ModalPasswordComponent,
                    {
                        data: {
                            text: this.labels.confirm.passwordModal.text,
                            subText: this.labels.confirm.passwordModal.subText,
                            units: 4,
                            errorMessage: this.labels.confirm.passwordModal.errorMessage,
                            needConfirm: true,
                            inputPassword: this.state.submitData.cashCardFirstPwd4bits
                        }
                    },
                    { cssClass: 'settings-modal', enableBackdropDismiss: false });
                modal.onDidDismiss((value) => {
                    if (value) {
                        this.navCtrl.push(CompletionComponent);
                    }
                });
                modal.present();
            }
        } else {
            // 既保持者の場合、スワイプしたキャッシュカードの暗証番号で認証
            const modal = this.modalCtrl.create(ModalPasswordComponent,
                {
                    data: {
                        text: this.labels.password.inputPasswordAgainText,
                        subText: this.labels.password.inputPasswordAgainSubText,
                        units: 4,
                        needConfirm: false,
                        validation: (password) => this.action.validatePassword({
                            tabletApplyId: this.state.submitData.tabletApplyId, // タブレット申込管理ID
                            params: {
                                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                                tenban: this.state.submitData.cardInfo.branchNo, // 店番
                                accountType: this.state.submitData.cardInfo.accountType, // 科目
                                accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                                icCardInfo: this.savingStore.getState().icData,  // カード情報を入れる
                                passcode: this.rsaEncryptService.encrypt(password)  // 暗証番号
                            }
                        })
                    }
                },
                { cssClass: 'settings-modal', enableBackdropDismiss: false });
            modal.onDidDismiss((value) => {
                if (value && value.result) {
                    this.navCtrl.push(CompletionComponent);
                }
            });
            modal.present();
        }
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.InfoComfirm.ApplyButton,
        );
    }

    public hideSchoolInformation() {
        // 正社員
        // 官公庁職員
        // 公務員3
        // 自営業
        // パート/アルバイト
        // 派遣
        // 主婦
        // 年金受給者  無職  学生  その他
        if (this.state.submitData.career === Career.STUDENT) {
            return false;
        } else {
            return true;
        }
    }

    public hideParentalWarning() {
        // 年齢が20歳未満かつ独身の場合は、親権者情報を表示する。
        if ((this.state.submitData.ageClassification === CreditCardAgeRange.BELOW_18
                ||  this.state.submitData.ageClassification === CreditCardAgeRange.FROM_18_TO_20)
                && this.state.submitData.married === IsMarried.UN_MARRIED) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * ボタン制御
     */
    public get footerBtnDisable() {
        if (this.savingCreditcardPasswordChangeRequiredFlag || this.savingDepositPasswordChangeRequiredFlag) {
            // キャッシュカードの暗証番号が要修正でない場合、フッターボタン活性化
            return true;
        }
        // BC単体かつ本人確認書類コードが80以外の場合
        const idenCode = InputUtils.getIdentificationCodeWithChange(this.state.submitData);
        if (this.state.submitData.businessCode === BusinessCode.BC_APPLY && idenCode && idenCode !== IdentificationCode.CODE_80) {
            //  お申し込みにあたっての確認事項、個人の利用目的、バンクカード規定・規約、外国PEPsのチェックボックスについてチェック済みの場合、活性化する。
            if (this.state.checkboxStatus.isApplyChecklistStatus &&
                this.state.checkboxStatus.isPersonalInformationStatus &&
                this.state.checkboxStatus.isBankcardRegulationStatus &&
                this.state.checkboxStatus.isForeignPulicFiguresSatus) {
                return false;
            }
        // 複合取引、または本人確認書類コードが80の場合
        } else {
            //  お申し込みにあたっての確認事項、個人の利用目的、バンクカード規定・規約のチェックボックスについてチェック済みの場合、活性化する。
            if (this.state.checkboxStatus.isApplyChecklistStatus &&
                this.state.checkboxStatus.isPersonalInformationStatus &&
                this.state.checkboxStatus.isBankcardRegulationStatus) {
                return false;
            }
        }
        return true;
    }

    /**
     * 変更項目を設定
     * @param data 変更項目
     */
    public handleItemChangedEmitter(data) {
        this.action.setStateSubmitDataValue(
            {
                name: 'holderName',
                value: data.holderNameKanji,
            }
        );
    }

    /**
     * BC暗証番号を修正した場合、その更新をCD暗証番号に反映させる
     * @param data 変更項目
     */
    public setPwdForFirstPwd4bitsEmitter(data) {
        this.action.setStateSubmitDataValue(
            {
                name: 'firstPwd4bits',
                value: data.value,
            }
        );
        // 口座開設側のstate.submitDataの暗証番号に修正後の値を格納
        if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
            // 既存新規の場合
            this.existingSavingsAction.setStateSubmitDataValue([{ key: 'firstPwd4bits', value: data.value }]);
            this.existingSavingsAction.setStateSubmitDataValue([{ key: 'cashCardFirstPwd4bits', value: data.value }]);
        } else {
            // 純新規（日本人・外国人）の場合
            this.savingAction.setStateSubmitDataValue({ name: 'firstPwd4bits', value: data.value });
            this.savingAction.setStateSubmitDataValue({ name: 'cashCardFirstPwd4bits', value: data.value });
        }
    }

    /**
     *  checkboxStatusEmmiterHandler
     *  @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.action.modifyCheckboxStatus(checboxItem);
    }

    // click 戻る button
    public backConfirmClick() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.creditcard.clerk.accountBack
        );
        this.navCtrl.pop();
    }

    /**
     * 郵便番号逆引き
     */
    private getHolderZipCode() {
        if (!this.state.submitData.parentalFirstZipCode && !this.state.submitData.parentalLastZipCode
                && !this.state.submitData.parentalZipCode && this.state.submitData.parentalFirstName) {
            if (this.state.submitData.parentalHolderAddressPrefecture &&
                this.state.submitData.parentalHolderAddressCountyUrbanVillage) {
                this.action.getHolderZipCodeSelected(
                    this.state.submitData.parentalHolderAddressPrefecture,
                    this.state.submitData.parentalHolderAddressCountyUrbanVillage,
                    this.state.submitData.parentalHolderAddressStreetNameSelect
                        ? this.state.submitData.parentalHolderAddressStreetNameSelect
                        : this.state.submitData.parentalHolderAddressStreetNameInput
                        ? this.state.submitData.parentalHolderAddressStreetNameInput
                        : '',
                    'parentalAddress');
            } else {
                this.action.setDefaultToSelectedZipCode('parentalAddress');
            }
        }

        if (!this.state.submitData.employmentFirstZipCode && !this.state.submitData.employmentLastZipCode
            && this.state.submitData.employmentName) {
            if (this.state.submitData.employmentHolderAddressPrefecture &&
                this.state.submitData.employmentHolderAddressCountyUrbanVillage) {
                this.action.getHolderZipCodeSelected(
                    this.state.submitData.employmentHolderAddressPrefecture,
                    this.state.submitData.employmentHolderAddressCountyUrbanVillage,
                    this.state.submitData.employmentHolderAddressStreetNameSelect
                        ? this.state.submitData.employmentHolderAddressStreetNameSelect
                        : this.state.submitData.employmentHolderAddressStreetNameInput
                        ? this.state.submitData.employmentHolderAddressStreetNameInput
                        : '',
                    'employmentAddress');
            } else {
                this.action.setDefaultToSelectedZipCode('employmentAddress');
            }
        }

    }

}
