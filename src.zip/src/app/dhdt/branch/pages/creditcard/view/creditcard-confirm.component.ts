import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { LabelService } from 'adep/services';
import { InjectionUtils, ObjectUtils } from 'adep/utils';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import {
    ExistingSavingsForeignInitConfirmComponent
} from 'dhdt/branch/pages/bank-savings-deposit/view/existing-savings-foreign/view/existing-savings-foreign-initconfirm.component';
import { BsdAgentConfirmComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/savings/bsd-agent-confirm.component';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { ChangeConfirmPageCommonService } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import {
    AccountCategory, AccountType, Age, ApplyBC, ApplyBizCategory, BusinessCode, CHANGECATEGORY, ClearSavingImagesClickRecordType,
    CodeCategory, COMMON_CONSTANTS, Constants, Decimal, HasLicense, HostResultCode, IdentificationCode,
    IdentificationDocumentCode, IdentificationDocumentMethod, IdInfoDocType,
    Income, MaskingCheckboxName, PrincipalAgentCategory, ServiceCategory, SsnHave, SsnWrite, StoreChanged,
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { CreditCardAction } from 'dhdt/branch/pages/creditcard/action/creditcard.action';
import { CreditCardChatComponent } from 'dhdt/branch/pages/creditcard/chat-flow/creditcard-chat.component';
import {
    Career, CreditCardAgeRange, CreditCardRank, IdentificationDocument, IsBankCardSuicaGoldSelected, IsBankCardSuicaSelected, IsMarried,
    IsNearGraduate, IsParentalLivingTogether
} from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { CreditCardSubmitEntity } from 'dhdt/branch/pages/creditcard/entity/creditcard-questions.model';
import { CreditCardConfirmPageCommonService } from 'dhdt/branch/pages/creditcard/service/creditcard-confirmpage.common.service';
import { CreditCardSignal, CreditCardState, CreditCardStore } from 'dhdt/branch/pages/creditcard/store/creditcard.store';
import { CreditCardInitConfirmComponent } from 'dhdt/branch/pages/creditcard/view/creditcard-initconfirm.component';
import { ExistingSavingsAction } from 'dhdt/branch/pages/existing-savings/action/existing-savings.action';
import { BussinessCode } from 'dhdt/branch/pages/existing-savings/existing-savings-consts';
import { ExistingSavingsContentConfirmComponent } from 'dhdt/branch/pages/existing-savings/view/existing-savings-content-confirm.component';
import { ExistingSavingsInitConfirmComponent } from 'dhdt/branch/pages/existing-savings/view/existing-savings-initconfirm.component';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ConfirmUtil } from 'dhdt/branch/shared/utils/confirm-util';
import { CreditCardUtil } from 'dhdt/branch/shared/utils/creditcard-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController, NavParams } from 'ionic-angular';

/**
 * 行員確認画面
 */
@Component({
    selector: 'creditcard-confirm-component',
    templateUrl: 'creditcard-confirm.component.html'
})
export class CreditCardConfirmComponent extends BaseComponent implements OnInit {
    public state: CreditCardState;
    public confirmPageCommonParams: Map<string, any> = null;
    public saveShowChats: any = {};
    public loginStore: LoginStore;
    public submitted: boolean = false;
    public isClerkConfirm: boolean = true;
    // 二度押下を回避するフラグ
    public isBackToCustomerConfirmPage = false;
    public editedList: any = {};
    public processType = 3;

    public isCareerShow: boolean = false;
    public isSignShow: boolean = false;
    public isW9Show: boolean = false;
    public isFatcaShow: boolean = false;
    public isReceptionNoShow: boolean = true;

    public changeConfirmPageParams: Map<string, any> = null;
    public submitData: any;
    public businessCode: string;
    public registerParams: any = {};
    private originSubmitData: any;

    constructor(
        private action: CreditCardAction,
        private navCtrl: NavController,
        private store: CreditCardStore,
        private modalCtrl: ModalController,
        private modalService: ModalService,
        private savingsAction: SavingsAction,
        private existingSavingsAction: ExistingSavingsAction,
        private cancelAction: CancelAction,
        private logging: LoggingService,
        private confirmPageCommonService: CreditCardConfirmPageCommonService,
        private changeConfirmPageService: ChangeConfirmPageCommonService,
        private rsaEncryptService: RsaEncryptService,
        private creditCardUtil: CreditCardUtil,
        private params: NavParams,
        private labelService: LabelService,
        private errorMessageService: ErrorMessageService,
        private confirmUtil: ConfirmUtil,
        private savingsStore: SavingsStore
    ) {
        super();
        this.state = this.store.getState();
        this.isSignShow = this.state.submitData.identificationCode === IdentificationCode.CODE_99;
        this.isW9Show = this.state.submitData.isSsnWrite === SsnWrite.YES;
        this.isFatcaShow = this.state.submitData.isSsnHave === SsnHave.NO || this.state.submitData.isTaxForAmerican === SsnHave.NO;
        this.originSubmitData = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);
        this.action.backupSubmitDataArr();
    }

    /**
     * 画面初期化
     */
    public ngOnInit() {

        this.confirmPageCommonService.loadConfirmTemplate();
        this.confirmPageCommonParams = this.confirmPageCommonService.getCreditCardConfirmPageComponentParams();
        this.changeConfirmPageService.loadConfirmTemplate();
        this.changeConfirmPageParams = this.changeConfirmPageService.getChangeConfirmPageComponentParams();

        this.submitData = this.params.get('submitData');
        this.registerParams = this.params.get('registerParams');

        // submitDataをセット
        if (this.submitData) {
            this.action.setData(this.submitData);
        }
        if (this.state.submitData.ifApplyBC === ApplyBC.YES && this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
            this.businessCode = BussinessCode.EXISTING_SAVINGS;
        }
        if (this.state.submitData.receptionNumber) {
            this.isReceptionNoShow = false;
        }
        if (this.state.copyComplexTransConfirmInfos != null) {
            // 連絡事項
            // 修正チャットでスキップした場合、nullになる
            if (this.state.copyComplexTransConfirmInfos.contactNote !== undefined) {
                this.action.setStateSubmitDataValue({
                    name: 'contactNote',
                    value: this.state.copyComplexTransConfirmInfos.contactNote
                });
            }
            // 学生証
            if (this.state.copyComplexTransConfirmInfos.identificationStudentImages) {
                this.action.setStateSubmitDataValue({
                    name: 'identificationStudentImages',
                    value: this.state.copyComplexTransConfirmInfos.identificationStudentImages
                });
            }
            // 口座開設行員認証画面で修正を行っていない場合
            if (this.state.submitData.isModify === '2') {
                // 運転免許証番号
                if (this.state.copyComplexTransConfirmInfos.identificationDocumentLicenseNo) {
                    this.action.setStateSubmitDataValue({
                        name: 'identificationDocumentLicenseNo',
                        value: this.state.copyComplexTransConfirmInfos.identificationDocumentLicenseNo
                    });
                }
            }
        }
        this.initShowData();
        this.setForeignIdentiDocuExpireData();
        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.isCareerShow = this.state.submitData.identificationCode !== IdentificationCode.CODE_80;
        this.action.submitDataBackup();
        this.action.backupComplexTransConfirmInfos();
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            // BC複合取引
            // submitData配下の未マスキング完了オブジェクトのバックアップがある場合
            this.state.submitData.bakupNotMaskingConfirmImages ?
                this.action.restoreBackupNotMaskingConfirmImages() :
            // ない場合、未マスキング完了オブジェクトを初期化
            this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.DOCUMENT);
        }
    }

    public onChange(data) {
        let key = data.key;
        let value = data.value;
        this.action.setStateSubmitDataValue(data);
        if (ObjectUtils.isArray(data)) {
            key = data[0].key;
            value = data[0].value;
        }
        this.action.updateSubmitDataBackup([{
            key: key,
            value: value
        }]);
    }

    /**
     * サブミットデータを加工する
     */
    public processSubmitData(): any {
        let idInfoDoc1: String;
        switch (this.state.submitData.identificationDocument1) {
            case IdentificationDocument.RESIDENCE_CARD:
            case IdentificationDocument.SPECIAL_PERMANENT: {
                idInfoDoc1 = IdentificationDocument.RESIDENCE_CARD_SPECIAL_PERMANENT;
                break;
            }
            default: {
                // 純新規OCRの場合、書類コードをAPIへ連携させる
                idInfoDoc1 = this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT
                    ? this.idInfoDoc1() : this.state.submitData.identificationDocument1;
                break;
            }
        }
        // dataの加工処理を実行する
        let submitData;
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            // スワイプなしの場合
            submitData = {
                tabletApplyId: this.state.submitData.tabletApplyId,
                openAccountParams: {
                    hasChange: '0',
                    ifApplyBc: '1',    // BC申込有
                    ...this.makeBcInfo(idInfoDoc1),
                    customerInfos: this.makeCustomerInfo()
                }
            };
            // スワイプありの場合
            if (this.state.submitData.accountType === AccountType.EXISTING_SAVINGS) {
                submitData = {
                    tabletApplyId: this.registerParams.tabletApplyId,
                    changeParams: {
                        receptionTenban: this.registerParams.changeParams.receptionTenban,
                        birthdate: this.registerParams.changeParams.birthdate,
                        eyeCueNo: this.registerParams.changeParams.eyeCueNo,
                        bankClerkId: this.registerParams.changeParams.bankClerkId,
                        operatorName: this.registerParams.changeParams.operatorName,
                        customerInfos: this.registerParams.changeParams.customerInfos
                    },
                    openAccountParams: {
                        ...this.makeBcInfo(idInfoDoc1),    // BC申込情報
                        receptionTenban: this.registerParams.openAccountParams.receptionTenban,
                        eyeCueNo: this.registerParams.openAccountParams.eyeCueNo,
                        bankClerkId: this.registerParams.openAccountParams.bankClerkId,
                        operatorName: this.registerParams.openAccountParams.operatorName,
                        hasChange: this.registerParams.openAccountParams.hasChange,
                        ifApplyBc: '1',    // BC申込有
                        customerInfos: this.registerParams.openAccountParams.customerInfos
                    }
                };
            }
        } else {
            submitData = {
                tabletApplyId: this.state.submitData.tabletApplyId,
                params: {
                    ...this.makeBcInfo(idInfoDoc1),
                }
            };
        }
        // 複合か否かで、設定するパラメーターを変更。
        if (submitData.openAccountParams && submitData.openAccountParams.complexTransactionsFlag === '1') {
            if (this.state.submitData.complexAccountInfo) {
                submitData.openAccountParams.branchCode = this.state.submitData.complexAccountInfo.branchNo;
                submitData.openAccountParams.subjectCode = this.state.submitData.complexAccountInfo.accountType;
                submitData.openAccountParams.bankAccountId = this.state.submitData.complexAccountInfo.accountNo;
            } else {
                submitData.openAccountParams.branchCode = null;
                submitData.openAccountParams.subjectCode = null;
                submitData.openAccountParams.bankAccountId = null;
            }
        } else {
            submitData.params.branchCode = this.state.submitData.cardInfo.branchNo;
            submitData.params.subjectCode = this.state.submitData.cardInfo.accountType;
            submitData.params.bankAccountId = this.state.submitData.cardInfo.accountNo;
        }

        return submitData;
    }

    /**
     * ボタンを押下するとAPI呼び出しを行う。
     */
    public saveSubmit() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.AccountConfirm.confirmButton,
        );
        this.submitted = true;
        this.store.registerSignalHandler(CreditCardSignal.SUCCESS_INSERT_INFO, (data) => {
            this.store.unregisterSignalHandler(CreditCardSignal.SUCCESS_INSERT_INFO);
            if (data.resultCode === HostResultCode.SUCCESS) {
                this.modalService.showCompleteModal().subscribe({
                    next: (event) => {
                        switch (event) {
                            case COMMON_CONSTANTS.BACK_TYPE_REAPPLY_MENU:
                                this.navCtrl.setRoot(ChatComponent, { reapplyFlg: true });
                                break;
                            default:
                                this.navCtrl.setRoot(TopComponent);
                        }
                    },
                    complete: () => {
                        this.action.clearStore();
                        this.savingsAction.clearStore();
                        this.cancelAction.clearStore();
                    }
                });
            } else {
                this.errorMessageService.showMessageModal(this.labelService.labels.common.error.host.applyErrorMessage, () => {
                    this.navCtrl.setRoot(TopComponent);
                    this.action.clearStore();
                    this.savingsAction.clearStore();
                    this.cancelAction.clearStore();
                });
            }
        });
        // 複合取引の場合、普通預金口座開設を呼び出す
        if (this.state.submitData.ifApplyBC === ApplyBC.YES) {
            this.action.submitTimeSavingOrangeApplyInfo(this.processSubmitData());
        } else {
            this.action.submitCreditCardData(this.processSubmitData());
        }
    }

    /**
     * 前遷移画面を設定する
     */
    public backToInfoConfirmPage() {
        this.isBackToCustomerConfirmPage = true;
        const fileInfo = this.state.submitData.fileInfo;
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    // 申込画面に戻るので、マスキング未確認オブジェクトをクリア
                    this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.CLEAR);
                    this.clearConfirmPageInfo();
                    // バックアップした運転免許証番号、学生証、連絡事項をクリア
                    this.action.clearCopyComplexTransConfirmInfos();
                    this.action.setStateSubmitDataValue([{
                        name: 'isModify',
                        value: '2'
                    }]);
                    if (this.state.submitData.businessCode === BusinessCode.SAVING_ACCOUNT) {
                        // スワイプあり口座開設＋バンクカード
                        this.existingSavingsAction.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.CLEAR);
                        this.existingSavingsAction.clearIdentificationDocument();
                        this.existingSavingsAction.clearCreditCardConfirmPageInfo();
                        this.existingSavingsAction.setStateSubmitDataValue([{ key: 'isModify', value: '2' }]);
                        this.action.setStateData({ submitData: this.state.originSubmitData });
                        this.navCtrl.setRoot(ExistingSavingsContentConfirmComponent,
                            {
                                submitData: this.state.submitData,
                            });
                        this.navCtrl.push(ExistingSavingsInitConfirmComponent);
                        this.navCtrl.push(CreditCardInitConfirmComponent);
                    } else if (this.state.submitData.applyBizCategory === ApplyBizCategory.JAPANESE_NATIONALITY) {
                        // スワイプなし口座開設(日本国籍)＋バンクカード
                        this.savingsAction.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.CLEAR);
                        // OCRの情報(hasLicense)を本人確認書類聴取前に戻す
                        this.savingsAction.setStateData({ submitData: this.params.get('originSubmitData') });
                        this.savingsAction.clearCreditCardConfirmPageInfo();
                        this.savingsAction.setStateSubmitDataValue({ name: 'isModify', value: '2' });
                        this.action.setStateData({ submitData: this.state.originSubmitData });
                        this.navCtrl.setRoot(BsdAgentConfirmComponent,
                            {
                                submitData: this.state.submitData,
                            });
                        this.navCtrl.push(CreditCardInitConfirmComponent);
                    } else if (this.state.submitData.applyBizCategory === ApplyBizCategory.FOREIGN_NATIONALITY) {
                        // スワイプなし口座開設(外国籍)＋バンクカード
                        this.savingsAction.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.CLEAR);
                        const backupIdentificationDocument1 = this.savingsStore.getState().submitData.identificationDocument1;
                        const backupIdentificationDocument1Text = this.savingsStore.getState().submitData.identificationDocument1Text;
                        this.savingsAction.clearCreditCardConfirmPageInfo();
                        this.savingsAction.setStateSubmitDataValue({
                            name: 'identificationDocument1',
                            value: backupIdentificationDocument1
                        });
                        this.savingsAction.setStateSubmitDataValue({
                            name: 'identificationDocument1Text',
                            value: backupIdentificationDocument1Text
                        });
                        this.savingsAction.setStateSubmitDataValue({ name: 'isModify', value: '2' });
                        this.action.setStateData({ submitData: this.state.originSubmitData });
                        this.navCtrl.setRoot(ExistingSavingsForeignInitConfirmComponent,
                            {
                                submitData: this.state.submitData,
                            });
                        this.navCtrl.push(CreditCardInitConfirmComponent);
                    } else {
                        // バンクカードのみ
                        this.navCtrl.setRoot(CreditCardInitConfirmComponent,
                            {
                                submitData: this.state.submitData,
                            });
                    }
                    this.logging.saveCustomOperationLog(
                        fileInfo ? fileInfo[0].screenId : '',
                        this.labels.logging.AccountConfirm.backConfirmButton,
                    );
                } else {
                    this.isBackToCustomerConfirmPage = false;
                }
            }
        );
    }

    /**
     * 連絡事項がスキップかつ(勤務地住所&顧客住所が受付対象地域外)の場合
     */
    public unReceptionAddressPrefecture() {
        // 受付できる地域：神奈川県、東京都、千葉県、群馬県、愛知県、大阪府（居住地/勤務地）
        const receptionArea = ['神奈川', '東京都', '千葉県', '群馬県', '愛知県', '大阪府'];
        const addressPrefecture = this.state.submitData.holderAddressPrefecture
            ? this.state.submitData.holderAddressPrefecture.substring(0, 3)
            : this.state.submitData.address ? this.state.submitData.address.substring(0, 3) : '';
        const employmentHolderAddressPrefecture = this.state.submitData.employmentHolderAddressPrefecture
            ? this.state.submitData.employmentHolderAddressPrefecture.substring(0, 3) : '';
        if (!this.state.submitData.contactNote
            && (receptionArea.indexOf(addressPrefecture) === -1
            && receptionArea.indexOf(employmentHolderAddressPrefecture) === -1)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 連絡事項がスキップかつ(無職または前年度税込年収が赤字)の場合
     */
    public isShowOtherNote() {
        if (!this.state.submitData.contactNote
            && (this.state.submitData.career === Career.UNEMPLOYED || this.checkIncome())) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * ボタン制御
     */
    public get footerBtnDisable(): boolean {
        // 受付番号なし　また　(本人確認書類を聴取している　かつ　マスキンチェックボックスがチェックされていない)
        // また連絡事項がスキップかつ(勤務地住所かつ顧客住所が受付対象地域外または(無職または前年度税込年収)が赤字)の場合
        const isStudent =
            this.state.submitData.career === Career.STUDENT ? true : false;
        let isNotMasking: boolean;
        if (this.state.submitData.isCreditIdentification) {
        // BC単体の場合
            isNotMasking =
            // 学生の場合：学生証＋本人確認書類のマスキング必須
            // 学生以外の場合：本人確認書類のマスキングのみ
                isStudent ? (!this.state.checkboxStatus.isAllMaskingStatus ||
                !this.state.checkboxStatus.isStudentMaskingStatus) :
                !this.state.checkboxStatus.isAllMaskingStatus;
        } else {
        // BC複合の場合
            isNotMasking =
                isStudent ? !this.state.checkboxStatus.isStudentMaskingStatus : false;
        }
        return isNotMasking || !this.state.submitData.receptionNumber ||
            this.isShowOtherNote() || this.unReceptionAddressPrefecture();
    }

    /**
     * 申込内容確認へ戻る
     */
    public clearConfirmPageInfo() {
        // マスキングチェックボックスをクリアする
        this.clearMaskingCheckBox();
        this.clearStudentMaskingCheckBox();
        this.action.setStateData({ submitData: this.originSubmitData });
        this.action.clearConfirmPageInfo();
    }

    public onChangeReceptionNumber(data) {
        this.action.setStateSubmitDataValueforCheckApply(data);
        this.action.updateSubmitDataBackup(data);
    }

    /**
     * 修正ボタン Emitハンドラー
     */
    public onEdit(key: String) {
        let options;
        let modal;
        const backup = Object.assign(new CreditCardSubmitEntity(), this.state.submitData);

        this.action.clearShowChats();
        this.action.initializeDataArr();
        this.action.setBankclerkAuthenticationStartDate();

        switch (key) {
            case this.labels.confirm.identityDocumentConfirm.table.title8:
                this.state.submitData.identificationDocumentLicenseNo = null;
                options = {
                    component: 'CreditCardIdentificationLicenseNoComponent',
                    process: -1,
                };
                modal = this.modalCtrl.create(CreditCardChatComponent,
                    {
                        options,
                        isCurrentPage: true,
                        currentTitle: this.labels.confirm.identityDocumentConfirm.table.title8,
                        startOrder: 640,
                        endOrder: 659,
                    },
                    { cssClass: 'full-modal' });
                break;
            case this.labels.creditcard.otherInformation.contactNote:
                this.state.submitData.contactNote = null;
                options = {
                    component: 'CreditCardStuffConfirmComponent',
                    process: -1,
                };
                modal = this.modalCtrl.create(CreditCardChatComponent,
                    {
                        options,
                        isCurrentPage: true,
                        currentTitle: this.labels.creditcard.otherInformation.contactNote,
                    },
                    { cssClass: 'full-modal' });
                break;
            case this.labels.creditcard.school.studentIdentityDocument:
                this.state.submitData.identificationStudentImages = null;
                options = {
                    component: 'CreditCardStudentIdentificationComponent',
                    process: -1,
                };
                modal = this.modalCtrl.create(CreditCardChatComponent,
                    {
                        options,
                        isCurrentPage: true,
                        currentTitle: this.labels.creditcard.school.studentIdentityDocument,
                        startOrder: 670,
                        endOrder: 719,
                    },
                    { cssClass: 'full-modal' });
                break;
            default:
                this.state.submitData.identificationDocumentLicenseNo = null;
                this.state.submitData.identificationDocument1 = null;
                this.state.submitData.identificationDocument1Text = null;
                this.state.submitData.identificationDocument1Images = null;
                this.state.submitData.identificationDocument2 = null;
                this.state.submitData.identificationDocument2Text = null;
                this.state.submitData.identificationDocument2Images = null;
                this.state.submitData.identificationAddressImages = null;
                this.state.submitData.addressConfirmationDocumentName = null;
                this.state.submitData.identificationAddressExpiryDate = null;
                options = {
                    component: 'ChangeIdentityDocument',
                    process: -1,
                };
                modal = this.modalCtrl.create(CreditCardChatComponent,
                    {
                        options,
                        isCurrentPage: true,
                        currentTitle: this.labels.confirm.identityDocumentConfirm.title,
                        startOrder: 1,
                        endOrder: 659
                    },
                    { cssClass: 'full-modal' });
        }
        modal.present();
        modal.onDidDismiss((state: any) => {
            if (state && state !== 'close') {
                switch (key) {
                    case this.labels.creditcard.otherInformation.contactNote:
                        this.state.copyComplexTransConfirmInfos.contactNote = state.submitData.contactNote;
                        break;
                    case this.labels.creditcard.school.studentIdentityDocument:
                        this.state.copyComplexTransConfirmInfos.identificationStudentImages = state.submitData.identificationStudentImages;
                        // 学生証のマスキング機能追加に伴う、修正チャットのクリア処理を追加
                        // 学生証の修正後、マスキングチェックボックスをクリアする
                        this.clearStudentMaskingCheckBox();
                        this.action.setStateData(state);
                        // 最新の写真によってマスキング未確認データをセットする
                        this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.DOCUMENT);
                        break;
                    case this.labels.confirm.identityDocumentConfirm.table.title8:
                        this.state.copyComplexTransConfirmInfos.identificationDocumentLicenseNo =
                            state.submitData.identificationDocumentLicenseNo;
                        break;
                    default:
                        // 本人確認書類の修正後、マスキングチェックボックスをクリアする
                        this.clearMaskingCheckBox();
                        this.action.setStateData(state);
                        // 最新の写真によってマスキング未確認データをセットする
                        this.action.resetNotMaskingConfirmImages(ClearSavingImagesClickRecordType.DOCUMENT);
                }
            } else {
                this.state.submitData = backup;
            }
        });
    }

    /**
     * 変更項目を設定
     * @param data 変更項目
     */
    public changePostSkipEmitterHandler(data) {
        this.action.setStateSubmitDataValue(
            {
                name: 'holderName',
                value: data.holderNameKanji,
            }
        );
    }

    public hideSchoolInformation() {
        // 職業学生、または卒業90日以内で学生証撮影時、表示する。
        if (this.state.submitData.career === Career.STUDENT || this.state.submitData.isNearGraduate === IsNearGraduate.YES) {
            return false;
        } else {
            return true;
        }
    }

    public hideParentalWarning() {
        // 年齢が20歳未満かつ独身の場合は、親権者情報を表示する。
        if ((this.state.submitData.ageClassification === CreditCardAgeRange.BELOW_18
            || this.state.submitData.ageClassification === CreditCardAgeRange.FROM_18_TO_20)
            && this.state.submitData.married === IsMarried.UN_MARRIED) {
            return false;
        } else {
            return true;
        }
    }

    public checkIncome() {
        if (this.state.submitData.birthdate !== undefined) {
            if ((this.creditCardUtil.calculateAge(this.state.submitData.birthdate) < Age.Age_20) &&
                (parseInt(this.state.submitData.taxIncludedAnnualIncomeLastYear, Decimal.Decimal_10) < Income.Income_100)) {
                return true;
            } else if ((this.creditCardUtil.calculateAge(this.state.submitData.birthdate) >= Age.Age_20) &&
                (this.state.submitData.cardRank === CreditCardRank.NORMAL) &&
                (parseInt(this.state.submitData.taxIncludedAnnualIncomeLastYear, Decimal.Decimal_10) < Income.Income_150)) {
                return true;
            } else if ((this.creditCardUtil.calculateAge(this.state.submitData.birthdate) >= Age.Age_20) &&
                (this.state.submitData.cardRank === CreditCardRank.GOLD) &&
                (parseInt(this.state.submitData.taxIncludedAnnualIncomeLastYear, Decimal.Decimal_10) < Income.Income_300)) {
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.action.modifyCheckboxStatus(checboxItem);
    }

    /**
     * 画像修正モーダル終了時、sumbitDataに修正した値を登録する
     *
     * @param {{ index: number, fieldName: string, value: string }} data
     * @memberof CreditCardConfirmComponent
     */
    public onImageMaskingComplete(data: { index: number, fieldName: string, value: string }) {
        this.action.editSomeDataInSubmitData(data.index, data.fieldName, data.value);
    }

    public onMaskingConfirmEmmiterHandler(imageInfo: { documentName: string, index: number }) {
        this.action.removeNotMaskingConfirmImages(imageInfo);
    }

    // click 戻る button
    public backConfirmClick() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.creditcard.clerk.accountBack
        );
        const identificationDocumentLicenseNo = this.state.submitData.identificationDocumentLicenseNo;
        const bakupNotMaskingConfirmImages = this.state.notMaskingConfirmImages;
        if (this.state.submitData.businessCode === BusinessCode.SAVING_ACCOUNT) {
            // スワイプあり口座開設＋バンクカード
            this.existingSavingsAction.setStateSubmitDataValue(
                [{ key: 'identificationDocumentLicenseNo', value: identificationDocumentLicenseNo }]
            );
            this.existingSavingsAction.setStateSubmitDataValue(
                [{ key: 'bakupNotMaskingConfirmImages', value: bakupNotMaskingConfirmImages }]
            );
        } else if (this.state.submitData.applyBizCategory === ApplyBizCategory.JAPANESE_NATIONALITY) {
            // スワイプなし口座開設(日本国籍)＋バンクカード
            this.savingsAction.setStateSubmitDataValue({ name: 'identificationDocumentLicenseNo', value: identificationDocumentLicenseNo });
            this.savingsAction.setStateSubmitDataValue(
                { name: 'bakupNotMaskingConfirmImages', value: bakupNotMaskingConfirmImages }
            );
        } else if (this.state.submitData.applyBizCategory === ApplyBizCategory.FOREIGN_NATIONALITY) {
            // スワイプなし口座開設(外国籍)＋バンクカード
            this.savingsAction.setStateSubmitDataValue(
                { name: 'bakupNotMaskingConfirmImages', value: bakupNotMaskingConfirmImages }
            );
        }
        this.navCtrl.pop();
    }

    /**
     * 画面の表示データを初期化する
     */
    private initShowData() {
        // 画面の表示データを初期化する
        this.state.showConfirm.forEach((item) => {
            if (item.type !== COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE) {
                this.saveShowChats[item.name] = item;
            }
        });
    }

    /*
    * 表示用お勤め先住所を設定する
    */
    private showEmploymentAddress(): string {

        const employmentPrefecture = this.state.submitData.employmentHolderAddressPrefecture;
        const employmentCountyUrbanVillage = this.state.submitData.employmentHolderAddressCountyUrbanVillage;
        const employmentStreetName = this.state.submitData.employmentHolderAddressStreetNameInput ||
            this.state.submitData.employmentHolderAddressStreetNameSelect ||
            this.state.submitData.employmentHolderAddressStreet ||
            '';
        const employmentAddressHouseNumber = this.state.submitData.employmentHolderAddressHouseNumber;

        if (employmentPrefecture || employmentCountyUrbanVillage || employmentStreetName || employmentAddressHouseNumber) {
            return employmentPrefecture + employmentCountyUrbanVillage + employmentStreetName + employmentAddressHouseNumber;
        } else {
            return null;
        }
    }

    /**
     * 表示文言を取得する
     * @param name 項目名称
     */
    private getShowTextFromItems(
        itemName: string, itemNames: string[], fillCharacter: string = ' '): string {
        let showValue = '';
        itemNames.forEach((name, index) => {
            if (this.state.submitData[name] != null) {
                showValue = showValue + this.state.submitData[name];
                if (index !== itemNames.length - 1) {
                    showValue = showValue + fillCharacter;
                }
            }
        });
        this.state.submitData[itemName] = showValue;
        if (showValue !== '') {
            return showValue;
        } else {
            return null;
        }
    }

    /**
     * 親権者郵便番号を設定する
     */
    private showParentalPostCode(): string {
        // 親権者情報なしの場合
        if (!this.state.submitData.parentalLivingTogether) {
            return null;
        }
        // 親権者と同居ありの場合、親権者郵便番号に本人郵便番号を設定
        if (this.state.submitData.parentalLivingTogether === IsParentalLivingTogether.YES) {
            // 純新規口座開設/既保持口座開設:諸届変更あり
            if (this.state.submitData.firstZipCode && this.state.submitData.lastZipCode) {
                return this.state.submitData.firstZipCode + this.state.submitData.lastZipCode;
                // 既保持口座開設（諸届変更なし）/BC単体
            } else {
                return this.state.submitData.zipCode.replace('-', '');
            }
            // 親権者と同居なしの場合、親権者郵便番号を設定
        } else {
            return this.state.submitData.parentalFirstZipCode + this.state.submitData.parentalLastZipCode;
        }
    }

    /*
    * 表示用住所を設定する
    */
    private showPrentalAddress(): string {
        // 親権者なしの場合
        if (!this.state.submitData.parentalLivingTogether) {
            return null;
        }
        // 親権者と同居ありの場合、親権者住所に本人住所を設定
        if (this.state.submitData.parentalLivingTogether === IsParentalLivingTogether.YES) {
            // 純新規口座開設/既保持口座開設:諸届変更あり
            if (this.state.submitData.holderAddressPrefecture) {
                return this.state.submitData.holderAddressPrefecture + this.state.submitData.holderAddressCountyUrbanVillage
                    + this.state.submitData.getHolderAddressStreetName() + this.state.submitData.holderAddressHouseNumber;
                // 既保持口座開設（諸届変更なし）/BC単体
            } else {
                return this.state.submitData.address;
            }
            // 親権者と同居なしの場合、親権者住所を設定
        } else {
            const parentalPrefecture = this.state.submitData.parentalHolderAddressPrefecture;
            const parentalCountyUrbanVillage = this.state.submitData.parentalHolderAddressCountyUrbanVillage;
            const parentalStreetName = this.state.submitData.parentalHolderAddressStreetNameInput ||
                this.state.submitData.parentalHolderAddressStreetNameSelect ||
                this.state.submitData.parentalHolderAddressStreet ||
                '';
            const parentalAddressHouseNumber = this.state.submitData.parentalHolderAddressHouseNumber;

            const address = parentalPrefecture + parentalCountyUrbanVillage + parentalStreetName + parentalAddressHouseNumber;
            return address ? address : null;
        }
    }

    /*
    * 表示用先住所カナを設定する
    */
    private showPrentalAddressFurikana(): string {
        // 親権者なしの場合
        if (!this.state.submitData.parentalLivingTogether) {
            return null;
        }
        // 親権者と同居ありの場合、親権者住所に本人住所を設定
        if (this.state.submitData.parentalLivingTogether === IsParentalLivingTogether.YES) {
            // 純新規口座開設/既保持口座開設:諸届変更あり
            if (this.state.submitData.holderAddressPrefectureFuriKana) {
                return this.state.submitData.holderAddressPrefectureFuriKana + this.state.submitData.holderAddressCountyUrbanVillageFuriKana
                    + this.state.submitData.getHolderAddressStreetNameFuriKana() + this.state.submitData.holderAddressHouseNumberFuriKana;
                // 既保持口座開設（諸届変更なし）/BC単体
            } else {
                return this.state.submitData.addressKana;
            }
            // 親権者と同居なしの場合、親権者住所を設定
        } else {
            const parentalPrefectureKana = this.state.submitData.parentalHolderAddressPrefectureFuriKana;
            const parentalCountyUrbanVillageKana = this.state.submitData.parentalHolderAddressCountyUrbanVillageFuriKana;
            const parentalStreetNameKana = this.state.submitData.parentalHolderAddressStreetFuriKana ||
                this.state.submitData.parentalHolderAddressStreetNameFuriKanaInput ||
                this.state.submitData.parentalHolderAddressStreetNameFuriKanaSelect ||
                '';
            const parentalAddressHouseNumberKana = this.state.submitData.parentalHolderAddressHouseNumberFuriKana;
            const addressFurikana = parentalPrefectureKana + parentalCountyUrbanVillageKana +
                parentalStreetNameKana + parentalAddressHouseNumberKana;
            return addressFurikana ? addressFurikana : null;
        }
    }

    private clearMaskingCheckBox() {
        // 本人確認画面が終わったら、maskingチェックボックスをリセット
        if (this.state.checkboxStatus.isAllMaskingStatus) {
            this.action.modifyCheckboxStatus(MaskingCheckboxName.MASKING_CHECKBOX_NAME);
        }
    }

    private clearStudentMaskingCheckBox() {
        // 本人確認画面が終わったら、学生証のmaskingチェックボックスをリセット
        if (this.state.checkboxStatus.isStudentMaskingStatus) {
            this.action.modifyCheckboxStatus(MaskingCheckboxName.STUDENT_CHECKBOX_NAME);
        }
    }

    /**
     * 画面の表示データを初期化する
     */
    private setForeignIdentiDocuExpireData() {
        // 画面の表示データを初期化する
        if (this.state.submitData.identityDocument1ExpirationDate) {
            this.action.setStateSubmitDataValue(
                { name: 'identificationDocument1ExpiryDate', value: this.state.submitData.identityDocument1ExpirationDate }
            );
        }
        if (this.state.submitData.identityDocument2ExpirationDate) {
            this.action.setStateSubmitDataValue(
                { name: 'identificationDocument2ExpiryDate', value: this.state.submitData.identityDocument2ExpirationDate }
            );
        }
        if (this.state.submitData.addressConfirmationDocumentExpirationDate) {
            this.action.setStateSubmitDataValue(
                { name: 'identificationAddressExpiryDate', value: this.state.submitData.addressConfirmationDocumentExpirationDate }
            );
        }
    }

    /**
     * 顧客情報データを加工する
     */
    private makeCustomerInfo(): any {
        let customerInfos;
        // スワイプなしの場合、顧客情報追加
        if (this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT) {
            // 1件目は口座開設情報
            customerInfos = [
                {
                    ...this.makeCustomerInfoDefult()
                }
            ];
            if (this.state.submitData.existingAccount) {
                // 店番号(代表口座）
                const ibInfo = this.creditCardUtil.getIbInfo(this.state.submitData);
                customerInfos[0].ibBranchCode = ibInfo ? ibInfo.branchCode : undefined;
                // 科目コード(代表口座）
                customerInfos[0].ibSubjectCode = ibInfo ? ibInfo.subjectCode : undefined;
                // 口座番号(代表口座）
                customerInfos[0].ibBankAccountId = ibInfo ? ibInfo.bankAccountId : undefined;
                // サービス利用区分
                customerInfos[0].serviceCategory =
                    ibInfo && ibInfo.ibContractInfo.serviceCategory === ServiceCategory.TB_ONLY ? ServiceCategory.IB : undefined;
            }
            // 本人の場合、選択された名寄せを追加
            if (this.state.submitData.isAgent === '0' && this.state.submitData.existingAccount) {
                this.state.submitData.existingAccount.forEach((account) => {
                    let customerInfo;
                    customerInfo = {
                        ...this.makeCustomerInfoDefult(),
                        customerId: account.customerId,
                        identificationCode: account.identificationCode,
                        changeCategory: CHANGECATEGORY.NOTCHANGE,    // 届出事項変更区分:変更不要
                        accountCategory: AccountCategory.NO,    // 普通口座開設区分
                    };
                    customerInfos.push(customerInfo);
                });
            }
        } else if (this.state.submitData.accountType === AccountType.FOREIGN_SAVINGS) {
            // 外国人
            customerInfos = [
                {
                    ...this.processSubmitDataForeign()
                }
            ];
        }
        return customerInfos;
    }

    /**
     * 顧客情報デフォルトデータを加工する
     */
    private makeCustomerInfoDefult(): any {
        // 米国人示唆情報
        const fatcaStasus = this.confirmUtil.getFatcaStatusTextJp(
            this.state.submitData.isGreenCardHave, this.state.submitData.fatcaStatus);

        return {
            nameKanji: this.state.submitData.holderName,
            nameKana: this.state.submitData.holderNameFurikana,
            gender: this.state.submitData.holderGender,
            birthdate: this.state.submitData.holderBirthdate,
            customerId: this.state.submitData.existingAccount ? this.setCustomerId() : undefined,
            identificationCode: this.state.submitData.existingAccount ?
                this.setIdentificationCode(this.setCustomerId()) : undefined,
            zipCode: this.state.submitData.firstZipCode ?
                this.state.submitData.firstZipCode + this.state.submitData.lastZipCode : undefined,
            prefecture: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillage: this.state.submitData.holderAddressCountyUrbanVillage,
            street: this.getHolderAddressStreetName(),
            subAddress: this.state.submitData.holderAddressHouseNumber,
            prefectureKana: this.state.submitData.holderAddressPrefectureFuriKana,
            countyUrbanVillageKana: this.state.submitData.holderAddressCountyUrbanVillageFuriKana,
            streetKana: this.getHolderAddressStreetNameFuriKana(),
            subAddressKana: this.state.submitData.holderAddressHouseNumberFuriKana,
            mobilePhoneNo: this.state.submitData.holderMobileNo,
            otherPhoneNo: this.state.submitData.holderTelephoneNo,
            occBusiness: this.state.submitData.holderCareer ? this.state.submitData.holderCareer.split('、') : undefined,
            workPlace: this.state.submitData.holderWorkPlace,
            accountOpeningPurpose:
                this.state.submitData.accountOpeningPurpose ? this.state.submitData.accountOpeningPurpose.split('、') : undefined,
            nationalityCode: this.state.submitData.agentCountry,
            agentNameKana: this.state.submitData.agentNameFurikana,
            agentName: this.state.submitData.agentName,
            agentBirthdate: this.state.submitData.agentBirthdate,
            agentRelationship: this.state.submitData.relationship,
            agentMethod: this.agentMethod(),
            agentDoc1: this.agentDoc1(),
            agentExpirationDate1: this.state.submitData.agentIdentificationDocument1ExpiryDate,
            agentDoc2: this.state.submitData.agentIdentificationDocument2,
            agentExpirationDate2: this.state.submitData.agentIdentificationDocument2ExpiryDate,
            agentDocName: this.state.submitData.agentDocName,
            agentExpirationDate: this.state.submitData.agentExpirationDate,
            residenceFlagJapanOnly: this.state.submitData.isJapanLive,
            principalAgentCategory: this.state.submitData.isAgent,
            nameDifferenceFlag: this.state.submitData.isDifferenceKanji,
            addressDifferenceFlag: this.state.submitData.addressDifferenceFlag,

            // 「フィルタリングシステム検索」APIから取得した「フィルタリングシステムの案件番号」
            outIssueNo: this.state.submitData.outIssueNo,
            // 「フィルタリングシステム検索」APIから取得した「照会結果」を設定
            outStatus: this.state.submitData.outStatus,
            passcode: this.rsaEncryptService.encrypt(this.state.submitData.firstPwd4bits),
            otherResidenceAddress: this.state.submitData.otherCountry,
            menuCode: '01',
            w9NameAlphabet: this.state.submitData.nameEnglish,
            w9AddressAlphabet: this.state.submitData.addressEnglish,
            w9CityNameAlphabet: this.state.submitData.cityOrTown,
            w9PrefecturesAlphabet: this.state.submitData.province,
            w9CountryNameAlphabet: this.state.submitData.agentCountryEnglish,
            w9SocialSecurityNo: this.state.submitData.socialSecurityNumber ?
                this.state.submitData.socialSecurityNumber.replace(/\-/g, '') : undefined,
            // 米国人示唆情報、　this.state.submitData.w9AmericanSuggestionInfo,の利用は廃止する。
            w9AmericanSuggestionInfo: fatcaStasus.americanSuggestionInfo,
            remainingPeriod: this.state.submitData.remainingPeriod,
            birthCountry: this.state.submitData.fatcaCountry,
            residenceCountryName: '0100',
            otherResidenceCountryName: this.state.submitData.agentCountry,
            accountOpeningBranchCode: this.state.submitData.tenban,
            receiptMethod: this.state.submitData.receiptMethod || CodeCategory.RECEIPT_METHOD_MAIL,
            // 本人確認方法
            // 本人確認書類１がパスポート（所持欄記載なし）場合「04」を設定、以外の場合は既存通り
            idInfoMethod: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                IdentificationDocumentMethod.PRESENT_ONE_ADDRESS_TYPE :
                this.idInfoMethod(),
            idInfoDoc1: this.idInfoDoc1(),
            // 本人確認書類２コード
            // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            idInfoDoc2: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                undefined : this.state.submitData.identificationDocument2,
            identityDocument1ExpirationDate: this.state.submitData.identificationDocument1ExpiryDate,
            identityDocument1Name: this.state.submitData.documentListName,
            // 本人確認書類２有効期間
            // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            identityDocument2ExpirationDate: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                undefined : this.state.submitData.identificationDocument2ExpiryDate,
            // 本人確認書類２その他書類名
            // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            identityDocument2Name: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                undefined : this.state.submitData.documentListName2,
            // 住所確認書類の書類名
            // 本人確認書類１がパスポート（所持欄記載なし）場合 かつ　書類２がその他場合、入力書類名を設定。書類２が以外の場合、ボタン名を設定
            // 本人確認書類１がパスポート（所持欄記載なし）以外場合既存通り
            addressConfirmationDocumentName:
                (this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1)
                    && !StringUtils.isEmpty(this.state.submitData.identificationDocument2)) ?
                    (this.isDocumentTwoOther(this.state.submitData.identificationDocument2) ?
                        this.state.submitData.documentListName2 :
                        this.state.submitData.identificationDocument2Text) :
                    this.state.submitData.addressConfirmationDocumentName,
            // 住所確認書類の有効期間
            // 本人確認書類１がパスポート（所持欄記載なし）場合「本人確認書類２の有効期間」を設定、以外の場合は既存通り
            addressConfirmationDocumentExpirationDate: (this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1)
                && !StringUtils.isEmpty(this.state.submitData.identificationDocument2)) ?
                this.state.submitData.identificationDocument2ExpiryDate :
                this.state.submitData.identificationAddressExpiryDate,
            bankCardFlag: this.state.submitData.bankCardFlag,
            bankCardGoldFlag: this.state.submitData.bankCardGoldFlag,
            bankCardSuicaFlag: this.state.submitData.bankCardSuicaFlag === IsBankCardSuicaSelected.IS_SELECTED ||
                this.state.submitData.bankCardSuicaGoldFlag === IsBankCardSuicaGoldSelected.IS_SELECTED ?
                IsBankCardSuicaSelected.IS_SELECTED : IsBankCardSuicaSelected.IS_NOT_SELECTED,
            imageDoc1: this.imageDoc1(),
            // 本人確認書類２画像
            // 本人確認書類１がパスポート（所持欄記載なし）場合「undefined」を設定、以外の場合は既存通り
            imageDoc2: this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1) ?
                undefined : this.state.submitData.identificationDocument2Images,
            // 住所確認書類画像
            // 本人確認書類１がパスポート（所持欄記載なし）場合「本人確認書類２の画像」を設定、以外の場合は既存通り
            imageAddressDoc: (this.isDocumentOneNewPassport(this.state.submitData.identificationDocument1)
                && !StringUtils.isEmpty(this.state.submitData.identificationDocument2)) ?
                this.state.submitData.identificationDocument2Images :
                this.state.submitData.identificationAddressImages,
            imageAgentDoc1: this.imageAgentDoc1(),
            imageAgentDoc2: this.state.submitData.identificationDocument2AgentImages,
            imageAgentAddressDoc: this.state.submitData.identificationAddressAgentImages,
            signatureCrs: this.state.submitData.sign,
            signatureFatca: this.state.submitData.signFatca,
            signatureOath: this.state.submitData.signOath,
            signatureAgree: this.state.submitData.signAgree,
            // 名寄あるとき携帯電話存在チェック結果を格納、名寄なしときundefinedを格納
            existsMobileNoFlg: this.state.submitData.existingAccount ? this.hasExistingMobilePhoneNumber() : undefined,
            isSmsPhone: this.state.submitData.isSmsPhone,
            isNeedPassbook: this.state.submitData.isNeedPassbook,
            // 基準特例
            confirmPurpose: this.state.submitData.confirmPurpose
        };
    }

    private setCustomerId(): string {
        let customerId;

        const sameBranchAccountList = this.state.submitData.existingAccount.filter((account) =>
            account.branchNo === this.state.submitData.tenban);

        if (sameBranchAccountList.length === 1) {
            customerId = sameBranchAccountList[0].customerId;
        } else if (sameBranchAccountList.length > 1) {
            const sameBranchCustomerIdList = [];
            sameBranchAccountList.forEach((account) => {
                sameBranchCustomerIdList.push(account.customerId);
            });
            const sameBranchCifInfoList = [];
            sameBranchCustomerIdList.forEach((cid) => {
                for (const cifInfo of this.state.submitData.allCifInfos) {
                    if (cifInfo.customerId === cid) {
                        sameBranchCifInfoList.push(cifInfo);
                        break;
                    }
                }
            });
            sameBranchCifInfoList.sort((a, b) => {
                return Number(a.openingDate) - Number(b.openingDate);
            });
            customerId = sameBranchCifInfoList[0].customerId;
        }

        return customerId;
    }

    private setIdentificationCode(customerId: string): string {
        if (customerId) {
            if (this.noAccountCheck(customerId)) {
                // 名寄せかつ、口座を持たない顧客の場合、本人確認コード９９として扱う
                return IdentificationCode.CODE_99;
            } else {
                const cifInfo = this.state.submitData.allCifInfos.find((item) => item.customerId === customerId);
                return cifInfo.identificationCode;
            }
        } else {
            return undefined;
        }
    }

    /**
     * 代理人ー本人確認方法
     */
    private agentMethod() {
        if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) {
            if (this.state.submitData.hasLicense === HasLicense.HAS_NOT_LICENSE) {
                return this.state.submitData.agentMethod;
            }
            return '01';
        }
        return undefined;
    }

    /**
     * 代理人ー本人確認書類１
     */
    private agentDoc1() {
        if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) {
            if (this.state.submitData.hasLicense === HasLicense.HAS_NOT_LICENSE) {
                return this.state.submitData.agentIdentificationDocument1;
            }
            // OCR読み取りの場合、画面で選択した本人確認資料　01：運転免許証 or 08：個人番号カード
            return this.state.submitData.hasLicense;
        }
        return undefined;
    }

    /**
     * 本人確認方法
     */
    private idInfoMethod() {
        if (this.state.submitData.isAgent === PrincipalAgentCategory.HOLDER) {
            if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
                // OCR読み取りの場合、01：1種類提示
                return '01';
            }
        }
        return this.state.submitData.idInfoMethod;
    }

    /**
     * 本人確認書類１
     */
    private idInfoDoc1() {
        if (this.state.submitData.isAgent === PrincipalAgentCategory.HOLDER) {
            if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
                // OCR読み取りの場合、画面で選択した本人確認資料　01：運転免許証 or 08：個人番号カード
                return this.state.submitData.hasLicense;
            }
        }
        return this.state.submitData.identificationDocument1;
    }

    /**
     * 本人確認書類1（画像ファイル）
     */
    private imageDoc1() {
        if (this.state.submitData.isAgent === PrincipalAgentCategory.HOLDER) {
            if (this.state.submitData.hasLicense !== HasLicense.HAS_NOT_LICENSE) {
                // OCR読み取りの場合、OCRから取得した画像ファイル
                if (this.state.submitData.hasLicense === Constants.DriveCard) {
                    return this.state.submitData.holderCardImageFront && this.state.submitData.holderCardImageBack ?
                        [this.state.submitData.holderCardImageFront, this.state.submitData.holderCardImageBack] : undefined;
                } else if (this.state.submitData.hasLicense === Constants.MyNumberCard) {
                    return this.state.submitData.holderCardImageFront ? [this.state.submitData.holderCardImageFront] : undefined;
                } else {
                    return undefined;
                }
            }
        }
        return this.state.submitData.identificationDocument1Images;
    }

    /**
     * 代理人確認書類1（画像ファイル）
     */
    private imageAgentDoc1() {
        if (this.state.submitData.isAgent === PrincipalAgentCategory.AGENT) {
            if (this.state.submitData.hasLicense === HasLicense.HAS_NOT_LICENSE) {
                return this.state.submitData.identificationDocument1AgentImages;
            }
            if (this.state.submitData.hasLicense === Constants.DriveCard) {
                return this.state.submitData.agentCardImageFront && this.state.submitData.agentCardImageBack ?
                    [this.state.submitData.agentCardImageFront, this.state.submitData.agentCardImageBack] : undefined;
            } else if (this.state.submitData.hasLicense === Constants.MyNumberCard) {
                return this.state.submitData.agentCardImageFront ? [this.state.submitData.agentCardImageFront] : undefined;
            } else {
                return undefined;
            }
        }
        return undefined;
    }

    private hasExistingMobilePhoneNumber(): string {

        const { holderTelNo1, holderTelNo2, holderTelNo3 } = this.state.submitData.existingAccount[0];

        if (holderTelNo1 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo1)) {
            return Constants.HAS_EXISTS_MOBILE_NO;
        }
        if (holderTelNo2 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo2)) {
            return Constants.HAS_EXISTS_MOBILE_NO;
        }
        if (holderTelNo3 && Constants.REGEXP_MOBILE_WITH_DASH.test(holderTelNo3)) {
            return Constants.HAS_EXISTS_MOBILE_NO;
        }

        return Constants.NO_EXISTS_MOBILE_NO;
    }

    /**
     * 書類１はパスポート（所持欄記載なし）かどうかを判断
     *
     * @private
     * @param {string} identificationDocument1
     * @return {*}  {boolean}　true：パスポート（所持欄記載なし）　false：パスポート（所持欄記載なし）以外
     */
    private isDocumentOneNewPassport(identificationDocument1: string): boolean {
        return !StringUtils.isEmpty(identificationDocument1) && identificationDocument1
            === IdentificationDocumentCode.PASSPORT_WITHOUT_SELF_INPUT;
    }

    /**
     * 書類２はその他官公庁から発行された書類（顔写真なし）かどうかを判断
     *
     * @private
     * @param {string} identificationDocument2
     * @return {*}  {boolean}　true：他官公庁から発行された書類（顔写真なし）　false：他官公庁から発行された書類（顔写真なし）以外
     */
    private isDocumentTwoOther(identificationDocument2: string): boolean {
        return !StringUtils.isEmpty(identificationDocument2) && identificationDocument2
            === IdentificationDocumentCode.OTHER_IDENTIFICATION_NO_PHOTO_DOCUMENT;
    }
    private getMobilePhoneNo(): string {
        if (this.state.submitData.existingChangeFirstMobileNo) {
            return this.state.submitData.existingChangeFirstMobileNo + COMMON_CONSTANTS.HALF_HYPHEN
                + this.state.submitData.existingChangeSecondMobileNo + COMMON_CONSTANTS.HALF_HYPHEN
                + this.state.submitData.existingChangeThirdMobileNo;
        } else if (this.state.submitData.holderMobileNo) {
            return this.state.submitData.holderMobileNo;
        } else if (this.state.submitData.existingChangeFirstTel) {
            return undefined;
        } else {
            return this.holderMobilePhoneNo();
        }
    }
    private holderMobilePhoneNo(): string {
        const { holderTelNo1, holderTelNo2, holderTelNo3 } = this.state.submitData;
        if (holderTelNo1 && /^(090|080|070)[0-9-]+/.test(holderTelNo1)) {
            return this.state.submitData.holderTelNo1;
        } else if (holderTelNo2 && /^(090|080|070)[0-9-]+/.test(holderTelNo2)) {
            return this.state.submitData.holderTelNo2;
        } else if (holderTelNo3 && /^(090|080|070)[0-9-]+/.test(holderTelNo3)) {
            return this.state.submitData.holderTelNo3;
        }
    }
    private getHomePhoneNo(): string {
        if (this.state.submitData.existingChangeFirstTel) {
            return this.state.submitData.existingChangeFirstTel + COMMON_CONSTANTS.HALF_HYPHEN
                + this.state.submitData.existingChangeSecondTel + COMMON_CONSTANTS.HALF_HYPHEN
                + this.state.submitData.existingChangeThirdTel;
        } else if (this.state.submitData.holderTelephoneNo) {
            return this.state.submitData.holderTelephoneNo;
        } else if (this.state.submitData.existingChangeFirstMobileNo) {
            return undefined;
        } else {
            return this.holderHomePhoneNo();
        }
    }
    private holderHomePhoneNo(): string {
        const { holderTelNo1, holderTelNo2, holderTelNo3 } = this.state.submitData;
        if (holderTelNo1 && ! /^(090|080|070)[0-9-]+/.test(holderTelNo1)) {
            return this.state.submitData.holderTelNo1;
        } else if (holderTelNo2 && ! /^(090|080|070)[0-9-]+/.test(holderTelNo2)) {
            return this.state.submitData.holderTelNo2;
        } else if (holderTelNo3 && ! /^(090|080|070)[0-9-]+/.test(holderTelNo3)) {
            return this.state.submitData.holderTelNo3;
        }
    }

    /**
     * BCデータを加工する
     */
    private makeBcInfo(idInfoDoc1: any): any {
        return {
            receptionTenban: this.loginStore.getState().belongToBranchNo,
            eyeCueNo: this.state.submitData.receptionNumber,
            bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
            operatorName: this.loginStore.getState().clerkInfo.operatorName,
            customerId: null,
            branchCode: null,
            subjectCode: null,
            bankAccountId: null,
            mobilePhoneNo: this.getMobilePhoneNo(),
            homePhoneNo: this.getHomePhoneNo(),
            cardType: this.state.submitData.applyType,
            cardBrand: this.state.submitData.cardBrand,
            romanName: this.state.submitData.nameRoma,
            houseType: this.state.submitData.houseType,
            residenceYears: this.state.submitData.residenceYears,
            livingExpenses: this.state.submitData.livingExpenses,
            marriaged: this.state.submitData.married,
            sameLivelihood: this.state.submitData.livelihoodPeople,
            dependentsNo: this.state.submitData.dependentFamily,
            occupation: this.state.submitData.career,
            jobDescription: this.state.submitData.jobDescription,
            industryType: this.state.submitData.industryType,
            industryTypeOtherDetails: this.state.submitData.industryTypeOther,
            officeInfoKanjiName: this.state.submitData.employmentName,
            officeInfoKanaName: this.state.submitData.employmentNameKana,
            officeInfoPostCode: this.state.submitData.employmentFirstZipCode && this.state.submitData.employmentLastZipCode ?
                this.state.submitData.employmentFirstZipCode + this.state.submitData.employmentLastZipCode : null,
            officeInfoAddress: this.showEmploymentAddress(),
            officeInfoPhoneNo: this.getShowTextFromItems('employmentTelephoneNo', ['employmentFirstTelephoneNo',
                'employmentSecondTelephoneNo', 'employmentThirdTelephoneNo'], '-'),
            officeInfoPhoneNoExtension: this.state.submitData.phoneNoExtension,
            department: this.state.submitData.department,
            positionName: this.state.submitData.positionName,
            employeeNumber: this.state.submitData.employeeNumber,
            lengthOfService: this.state.submitData.lengthOfService,
            jobChangeTimes: this.state.submitData.jobChangeTimes,
            taxIncludedAnnualIncomeLastYear: this.state.submitData.taxIncludedAnnualIncomeLastYear ?
                this.state.submitData.taxIncludedAnnualIncomeLastYear : '0',
            schoolInfoKanjiName: this.state.submitData.schoolName,
            schoolInfoKanaName: this.state.submitData.schoolNameKana,
            graduationDate: this.state.submitData.graduateDate,
            parentInfoKanjiName: this.getShowTextFromItems('parentalName', ['parentalFirstName', 'parentalLastName'], '　'),
            parentInfoKanaName: this.getShowTextFromItems('parentalNameFuriKana', ['parentalFirstNameFuriKana',
                'parentalLastNameFuriKana'], '　'),
            relationship: this.state.submitData.parentalRelationship,
            relationshipOtherDetails: this.state.submitData.parentalRelationshipText,
            parentInfoBirthDate: this.state.submitData.parentalBirthdate,
            parentInfoPostCode: this.showParentalPostCode(),
            parentInfoKanjiAddress: this.showPrentalAddress(),
            parentInfoKanaAddress: this.showPrentalAddressFurikana(),
            contactPhoneNo: this.getShowTextFromItems('parentalHolderMobileNo', ['parentalFirstMobileNo', 'parentalSecondMobileNo',
                'parentalThirdMobileNo'], '-'),
            contactHomePhoneNo: this.getShowTextFromItems('parentalHolderTelephoneNo', ['parentalFirstTel', 'parentalSecondTel',
                'parentalThirdTel'], '-'),
            suicaAutoCharge: this.state.submitData.suicaAutoCharge,
            etcCategory: this.state.submitData.etcCategory,
            revoPayCourse: this.state.submitData.revoPayCourse,
            myPaceRevo: this.state.submitData.myPaceRevo,
            openingStatus: this.state.submitData.loanApplication,
            loanValue: this.state.submitData.overdraftLimit,
            bcPassWord: this.rsaEncryptService.encrypt(this.state.submitData.creditCardFirstPwd4bits),
            cdPassWord: this.rsaEncryptService.encrypt(this.state.submitData.cashCardFirstPwd4bits),
            identificationCode: InputUtils.getIdentificationCodeWithChange(this.state.submitData),
            licenseNo: this.state.submitData.identificationDocumentLicenseNo,
            judgingConsiderationMessage: this.state.submitData.contactNote,
            birthdate: this.state.submitData.birthdate,
            idInfoMethod: this.state.submitData.idInfoMethod,
            idInfoDoc1: idInfoDoc1,
            idInfoDoc2: this.state.submitData.identificationDocument2,
            identityDocument1ExpirationDate: this.state.submitData.identificationDocument1ExpiryDate,
            identityDocument1Name: this.state.submitData.documentListName,
            identityDocument2ExpirationDate: this.state.submitData.identificationDocument2ExpiryDate,
            identityDocument2Name: this.state.submitData.documentListName2,
            addressConfirmationDocumentName: this.state.submitData.addressConfirmationDocumentName,
            addressConfirmationDocumentExpirationDate: this.state.submitData.identificationAddressExpiryDate,
            nationalityCode: this.state.submitData.nationalityCode,
            kanjiDifferenceCheck: this.state.submitData.isDifferenceKanji === '1' ? '1' : '0',
            // 純新規の場合はOCRの可能性があるため判断、その他業務は本人確認書類1を使用
            imageDoc1: this.state.submitData.accountType === AccountType.ORDINARY_DEPOSIT
                ? this.imageDoc1()
                : this.state.submitData.identificationDocument1Images,
            imageDoc2: this.state.submitData.identificationDocument2Images,
            imageAddressDoc: this.state.submitData.identificationAddressImages,
            identificationLoanExamination: this.state.submitData.identificationStudentImages,
            complexTransactionsFlag: this.state.submitData.ifApplyBC === ApplyBC.YES ? '1' : null,
            nameKanji: this.state.submitData.nameKanji ? this.state.submitData.nameKanji : null,
            nameKana: this.state.submitData.nameKana,
            transPurpose:
                this.state.submitData.transPurpose ? this.state.submitData.transPurpose.split('、') : ['01'],
        };
    }

    private processSubmitDataForeign() {
        let documentParam = null;

        switch (this.state.submitData.identificationDocType) {
            case IdInfoDocType.TYPE_RESIDENCE_CARD:
                documentParam = {
                    // 本人確認資料1
                    idInfoDoc1: this.state.submitData.identificationDocument1,
                    // 本人確認資料2
                    idInfoDoc2: this.state.submitData.identificationDocument2,
                    // 本人確認書類１有効期限
                    identityDocument1ExpirationDate: this.state.submitData.identityDocument1ExpirationDate,
                    // 本人確認書類２有効期限
                    identityDocument2ExpirationDate: this.state.submitData.identityDocument2ExpirationDate,
                    // 現住所確認書類有効期限
                    addressConfirmationDocumentExpirationDate: this.state.submitData.addressConfirmationDocumentExpirationDate,
                    // 本人確認書類1（画像ファイル）
                    imageDoc1: this.state.submitData.identificationDocument1Images,
                    // 本人確認書類2（画像ファイル）
                    imageDoc2: this.state.submitData.identificationDocument2Images,
                    // 本人現住所確認書類（画像ファイル）
                    imageAddressDoc: this.state.submitData.identificationAddressImages,
                };
                break;
            case IdInfoDocType.TYPE_PERMANENT_RESIDENT:
                documentParam = {
                    // 本人確認資料1
                    idInfoDoc1: this.state.submitData.identificationDocument1,
                    // 本人確認資料2
                    idInfoDoc2: this.state.submitData.identificationDocument2,
                    // 本人確認書類１有効期限
                    identityDocument1ExpirationDate: this.state.submitData.identityDocument1ExpirationDate,
                    // 本人確認書類２有効期限
                    identityDocument2ExpirationDate: this.state.submitData.identityDocument2ExpirationDate,
                    // 現住所確認書類有効期限
                    addressConfirmationDocumentExpirationDate: this.state.submitData.addressConfirmationDocumentExpirationDate,
                    // 本人確認書類1（画像ファイル）
                    imageDoc1: this.state.submitData.identificationDocument1Images,
                    // 本人確認書類2（画像ファイル）
                    imageDoc2: this.state.submitData.identificationDocument2Images,
                    // 本人現住所確認書類（画像ファイル）
                    imageAddressDoc: this.state.submitData.identificationAddressImages,
                    // 在留期間満了日 = 顧客が入力した特別永住者証明書の有効期限
                    residenceExpirationDate: this.state.submitData.identityDocument1ExpirationDate,
                };
                break;
            case IdInfoDocType.TYPE_US_TROOPS:
                documentParam = {
                    // 本人確認資料1
                    idInfoDoc1: this.state.submitData.identificationDocument2,
                    // 本人確認資料2
                    idInfoDoc2: null,
                    // 在留期間満了日 = 顧客が入力した米軍IDの有効期限
                    residenceExpirationDate: this.state.submitData.identityDocument1ExpirationDate,
                    // 本人確認書類１有効期限 = 顧客が入力したパスポートの有効期限
                    identityDocument1ExpirationDate: this.state.submitData.identityDocument2ExpirationDate,
                    // 本人確認書類２有効期限
                    identityDocument2ExpirationDate: null,
                    // 現住所確認書類有効期限
                    addressConfirmationDocumentExpirationDate: this.state.submitData.addressConfirmationDocumentExpirationDate,
                    // 米軍IDの画像
                    imageEnrollmentCertificate: this.state.submitData.identificationDocument1Images,
                    // 本人確認書類1（画像ファイル） = パスポートの写真
                    imageDoc1: this.state.submitData.identificationDocument2Images,
                    // 本人確認書類2（画像ファイル）
                    imageDoc2: null,
                    // 本人現住所確認書類（画像ファイル）
                    imageAddressDoc: this.state.submitData.identificationAddressImages,
                };
                break;
            default:
        }

        // 米国人示唆情報
        const fatcaStasus = this.confirmUtil.getFatcaStatusTextFor(
            this.state.submitData.nationalityCode, this.state.submitData.isGreenCardHave);

        return {
            ...this.state.submitData,
            schoolName: this.state.submitData.attendingSchoolName,
            nameDifferenceFlag: this.state.submitData.isDifferenceKanji,
            passcode: this.rsaEncryptService.encrypt(this.state.submitData.firstPwd4bits),
            occBusiness: this.state.submitData.occBusiness ? this.state.submitData.occBusiness.split('、') : undefined,
            accountOpeningPurpose: this.state.submitData.accountOpeningPurpose ?
                this.state.submitData.accountOpeningPurpose.split('、') : undefined,
            w9SocialSecurityNo: this.state.submitData.w9SocialSecurityNo ?
                this.state.submitData.w9SocialSecurityNo.replace(/\-/g, '') : undefined,
            receptionTenban: this.loginStore.getState().belongToBranchNo,
            accountOpeningBranchCode: this.state.submitData.existingAccount ?
                this.state.submitData.existingAccount.branchNo : this.state.submitData.tenban,
            prefecture: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillage: this.state.submitData.holderAddressCountyUrbanVillage,
            street: this.getHolderAddressStreetName(),
            prefectureKana: this.state.submitData.holderAddressPrefectureFuriKana,
            countyUrbanVillageKana: this.state.submitData.holderAddressCountyUrbanVillageFuriKana,
            streetKana: this.getHolderAddressStreetNameFuriKana(),
            subAddressKana: this.state.submitData.holderAddressHouseNumberFuriKana,
            subAddress: this.state.submitData.holderAddressHouseNumber,
            residenceFlagJapanOnly: this.state.submitData.residenceOnlyJapan,
            // 本人代理人区分 0：本人
            principalAgentCategory: '0',
            // 行員ID
            bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
            // オペレータ氏名
            operatorName: this.loginStore.getState().clerkInfo.operatorName,
            signatureCrs: this.state.submitData.sign,
            menuCode: '05',
            receiptMethod: this.state.submitData.receiptMethod || CodeCategory.RECEIPT_METHOD_MAIL,
            w9CountryNameAlphabet: this.state.submitData.agentCountryEnglish === COMMON_CONSTANTS.OTHER_COUNTRY_NAME ?
                this.state.submitData.w9CountryNameAlphabet : this.state.submitData.agentCountryEnglish,
            residenceStatus: this.state.submitData.residenceStatusText,
            customerId: this.state.submitData.existingAccount ? this.state.submitData.existingAccount.customerId : undefined,
            eyeCueNo: this.state.submitData.receptionNumber,
            residenceCountryName: this.state.submitData.residenceCountryName || '0100',   // 日本
            nameKanji: this.state.submitData.firstNameKanji && this.state.submitData.lastNameKanji ?
                this.state.submitData.firstNameKanji + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKanji : null,
            nameKana:
                this.state.submitData.firstNameKana + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKana,
            nameAlphabet:
                this.state.submitData.firstNameAlphabet + COMMON_CONSTANTS.SPACE + this.state.submitData.lastNameAlphabet,
            bankCardSuicaFlag: this.state.submitData.bankCardSuicaFlag === IsBankCardSuicaSelected.IS_SELECTED ||
                this.state.submitData.bankCardSuicaGoldFlag === IsBankCardSuicaGoldSelected.IS_SELECTED ?
                IsBankCardSuicaSelected.IS_SELECTED : IsBankCardSuicaSelected.IS_NOT_SELECTED,
            ...documentParam,
            isNeedPassbook: this.state.submitData.isNeedPassbook,
            // 米国人示唆情報、　this.state.submitData.w9AmericanSuggestionInfo,の利用は廃止する。
            w9AmericanSuggestionInfo: fatcaStasus.americanSuggestionInfo,
        };
    }

    private getHolderAddressStreetName() {
        if (this.state.submitData.holderAddressStreetNameSelect || this.state.submitData.holderAddressStreetNameInput) {
            return this.state.submitData.holderAddressStreetNameSelect
                ? this.state.submitData.holderAddressStreetNameSelect : this.state.submitData.holderAddressStreetNameInput;
        }

        return '';
    }

    private getHolderAddressStreetNameFuriKana() {
        if (this.state.submitData.holderAddressStreetNameFuriKanaSelect || this.state.submitData.holderAddressStreetNameFuriKanaInput) {
            return this.state.submitData.holderAddressStreetNameFuriKanaSelect
                ? this.state.submitData.holderAddressStreetNameFuriKanaSelect : this.state.submitData.holderAddressStreetNameFuriKanaInput;
        }

        return '';
    }

    /**
     * 名寄せ時、既存口座の存在有無をチェックする
     *
     * @param customerId 顧客番号
     * @returns
     */
    private noAccountCheck(customerId: string): boolean {
        // チェック対象の科目
        const subjectCodeList = {
            11: true,  // 当座預金（一般当座貸越含む）
            12: true,  // 普通預金（総合口座貸越、普通預金貸越含む）
            13: true,  // 貯蓄預金
            14: true,  // 納税準備預金
            16: true,  // 通知預金
            19: false, // 別段預金　←チェック対象外
            20: true,  // 定期預金
            26: true,  // 積立定期預金（財形含む）
            48: false  // 貸越専用カードローン　←チェック対象外
        };

        let retVal = false;
        if (customerId && this.state.submitData.allCifInfos) {
            const cifInfo = this.state.submitData.allCifInfos.find((item) => item.customerId === customerId);
            if (cifInfo) {
                const domesticAccountInfos = cifInfo.domesticAccountInfo ? cifInfo.domesticAccountInfo : [];
                let accountCnt = 0;
                domesticAccountInfos.forEach((domesticAccountInfo) => {
                    if (subjectCodeList[domesticAccountInfo.subjectCode]) {
                        accountCnt++;
                    }
                });
                if (accountCnt === 0) {
                    retVal = true;
                }
            }
        }
        return retVal;
    }

}
