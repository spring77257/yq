import { Injectable, NgZone } from '@angular/core';
import { Action } from 'adep/flux';
import { LabelService } from 'adep/services';
import { API_URL, ApplyDate, ClearSavingImagesClickRecordType,
    COMMON_CONSTANTS,
    Constants, HostResultCode, PasswordVerify} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { AccountBalanceInquiryInterface } from 'dhdt/branch/shared/interface/account-balance-inquiry.interface';
import { ExistingPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/existing-password-rule-check.interface';
import { NewPasswordRuleCheckInterface } from 'dhdt/branch/shared/interface/new-password-rule-check.interface';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { HostErrorService } from 'dhdt/branch/shared/services/host-error.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { HttpService, HttpStatus } from 'dhdt/branch/shared/services/http.service';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { App } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';

export namespace CreditCardActionType {
    export const GET_SAVING_QUESTION_TEMPLATE: string = 'CreditCardActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const NEXT_CHAT: string = 'CreditCardActionType_NEXT_CHAT';
    export const CLEAR: string = 'CreditCardActionType_LOAD_TEMPLATE_CLEAR';
    export const CLEAR_SHOW_CHATS: string = 'CreditCardActionType_CLEAR_SHOW_CHATS';
    export const BRANCH_STATUS_INSERT: string = 'CreditCardActionType_BRANCH_STATUS_INSERT';
    export const BRANCH_STATUS_UPDATE: string = 'CreditCardActionType_BRANCH_STATUS_UPDATE';
    export const SET_ANSWER: string = 'CreditCardActionType_SET_ANSWER';
    export const EDIT_CHAT: string = 'CreditCardActionType_EDIT_CHAT';
    export const SET_STATE_SUBMIT_DATA_VALUE: string = 'CreditCardActionType_SET_STATE_SUBMIT_DATA_VALUE';
    export const SET_STATE_DATA: string = 'CreditCardActionType_SET_STATE_DATA';
    export const VALIDATION_PASSWORD: string = 'CreditCardActionType_VALIDATION_PASSWORD';
    export const SUBMIT_DATA_BACKUP: string = 'CreditCardActionType_SUBMIT_DATA_BACKUP';
    export const RESET_SUBMIT_DATA: string = 'CreditCardActionType_RESET_SUBMIT_DATA';
    export const RETRIEVE_DROP_LIST: string = 'CreditCardActionType_RETRIEVE_DROP_LIST';
    export const BRANCH_INFO_INSERT: string = 'CreditCardActionType_BRANCH_INFO_INSERT';
    export const CHAT_FLOW_COMPELETE = 'CreditCardACTIONTYPE_CHAT_FLOW_COMPELETE';
    export const CHAT_FLOW_RETURN = 'CreditCardACTIONTYPE_CHAT_FLOW_RETURN';
    export const RESET_LAST_NODE = 'CreditCardACTIONTYPE_RESET_LAST_NODE';
    export const SET_BANKCLERK_ID: string = 'SET_BANKCLERK_ID';
    export const GET_CONSUMPTION_TAX = 'CreditCardACTIONTYPE_GET_CONSUMPTION_TAX'; // 消費税

    export const SET_MEMBER_AGE_FLG: string = 'SET_MEMBER_AGE_FLG';

    export const SET_CREDITCARD_BRAND_AND_RANK: string = 'SET_CREDITCARD_BRAND_AND_RANK';
    export const GET_CONFIRM_PAGE_TEMPLATE: string = 'GET_CONFIRM_PAGE_TEMPLATE';
    export const SET_CIF_INFORMATION = 'CreditCardActionType_SET_CIF_INFORMATION';  // CIF情報照会
    export const SET_SWIPE_INFO: string = 'ExistingSavingsActionType_SET_SWIPE_INFO';
    export const GET_BRANCH_NAME: string = 'CreditCardActionType_GET_BRANCH_NAME';
    export const GET_EXISTING_PASSWORD_RULE: string = 'CreditCardActionType_GET_EXISTING_PASSWORD_RULE'; // 暗証番号ルール適合性チェック
    export const RESET_SHOW_CONFIRM = 'CreditCardActionType_RESET_SHOW_CONFIRM';
    export const RESET_SHOWCHATS = 'CreditCardActionType_RESET_SHOWCHATS';

    export const SET_SYSTEM_TIME: string = 'ExistingSavingsActionType_SET_SYSTEM_TIME';

    export const GET_HOLDER_ZIP_CODE = 'CreditCardActionType_GET_HOLDER_ZIP_CODE'; // 郵便番号(横浜版未使用)
    export const GET_HOLDER_ZIP_CODE_SELECTED = 'CreditCardActionType_GET_HOLDER_ZIP_CODE_SELECTED'; // 郵便番号(親権者or勤務先)

    export const CLEAR_SUBMIT_DATA = 'CreditCardActionTypee_CLEAR_SUBMIT_DATA'; // clear data

    export const SET_FAMILY_NAME_ROMA: string = 'CreditCardActionType_SET_FAMILY_NAME_ROMA';
    export const SET_DEFAULT_ZIP_CODE: string = 'CreditCardActionType_SET_DEFAULT_ZIP_CODE'; // 郵便番号(横浜版未使用)
    export const SET_DEFAULT_TO_SELECTED_ZIP_CODE: string = 'CreditCardActionType_SET_DEFAULT_TO_SELECTED_ZIP_CODE'; // 郵便番号(親権者or勤務先)
    export const SET_ONLY_NAME_KANJI_EDIT_FLG: string = 'CreditCardActionType_SET_ONLY_NAME_KANJI_EDIT_FLG';
    export const MODIFY_CHECKBOX_STATUS: string = 'CreditCardActionType_MODIFY_CHECKBOX_STATUS'; // 確認事項チェックボックス
    export const CALL_MODIFY_CHECKBOX_STATUS: string = 'CreditCardActionType_CALL_MODIFY_CHECKBOX_STATUS';
    export const CLEAR_PARENTAL_ADDRESS: string = 'CreditCardActionType_CLEAR_PARENTAL_ADDRESS';
    export const CLEAR_EMPLOYMENT_ADDRESS: string = 'CreditCardActionType_CLEAR_EMPLOYMENT_ADDRESS';
    export const NEED_INPUT_PHONE_NO: string = 'CreditCardActionType_NEED_INPUT_PHONE_NO';

    export const SET_EDITED_LIST: string = 'CreditCardActionType_SET_EDITED_LIST';
    export const SET_PARENTALADDRESS_FROM_COPY_OR_EDITED: string = 'CreditCardActionType_SET_PARENTALADDRESS_FROM_COPY_OR_EDITED';
    export const INITIALIZE_DATA_ARR: string = 'CreditCardActionType_INITIALIZE_DATA_ARR';
    export const CLEAR_EMPLOYMENT_INFO: string = 'CreditCardActionType_CLEAR_EMPLOYMENT_INFO';
    export const CLEAR_PARENTAL_INFO: string = 'CreditCardActionType_CLEAR_PARENTAL_INFO';
    export const CLEAR_BC_LOAN_INFO: string = 'CreditCardActionType_CLEAR_BC_LOAN_INFO';
    export const CLEAR_SCHOOL_INFO: string = 'CreditCardActionType.CLEAR_SCHOOL_INFO';
    export const RESTORE_SHOW_COFIRM: string = 'CreditCardActionType.RESTORE_SHOW_COFIRM';
    export const BC_APPLY_CHECK = 'CreditCardActionType_BC_APPLY_CHECK';

    export const SET_IDENTIFICATION_DOCUMENT = 'CreditCardActionType_SET_IDENTIFICATION_DOCUMENT';
    export const SAVE_DOCUMENT_IMAGE = 'CreditCardActionType_SAVE_DOCUMENT_IMAGE';
    export const CLEAN_DOCUMENT_IMAGE = 'CreditCardActionType_CLEAN_DOCUMENT_IMAGE';
    export const SET_STATE_SUBMIT_DATA_VALUE_FOR_CHECK_APPLY: string = 'CreditCardActionType_SET_STATE_SUBMIT_DATA_VALUE_FOR_CHECK_APPLY';
    export const SET_SUBMIT_DATA: string = 'CreditCardActionType_SET_SUBMIT_DATA';

    export const UPDATA_SUBMIT_DATA_BACKUP = 'CreditCardActionType_UPDATA_SUBMIT_DATA_BACKUP';
    export const CREDITCARD_INFO_INSERT = 'CreditCardActionType_CREDITCARD_INFO_INSERT';

    export const SET_STATE_DATA_FOR_CONFIRM = 'CreditCardActionType_SET_STATE_DATA_FOR_CONFIRM';
    export const CHARACTER_CHECK = 'CreditCardActionType_CHARACTER_CHECK';

    export const BACKUP_SUBMITDATA_ARR = 'CreditCardActionType_BACKUP_SUBMITDATA_ARR';
    export const CLEAR_CONFIRMPAGE_INFO = 'CreditCardActionType_CLEAR_CONFIRMPAGE_INFO';

    export const REMOVE_NOT_MASKING_CONFIRM_IMAGES = 'CreditCardActionType_REMOVE_NOT_MASKING_CONFIRM_IMAGES';
    export const RESET_NOT_MASKING_CONFIRM_IMAGES = 'CreditCardActionType_RESET_NOT_MASKING_CONFIRM_IMAGES';

    export const SET_TABLET_APPLY_ID = 'CreditCardActionType_SET_TABLET_APPLY_ID';
    export const BACKUP_ORIGIN_SUBMITDATA = 'CreditCardActionType_BACKUP_ORIGIN_SUBMITDATA';
    export const CLEAR_COPY_COMPLEX_TRANS_CONFIRM_INFOS = 'CreditCardActionType_CLEAR_COPY_COMPLEX_TRANS_CONFIRM_INFOS';
    export const BACKUP_COMPLEX_TRANS_CONFIRM_INFOS = 'CreditCardActionType_BACKUP_COMPLEX_TRANS_CONFIRM_INFOS';
    export const RESTORE_BACKUP_NOT_MASKING_CONFIRM_IMAGES = 'CreditCardActionType_RESTORE_BACKUP_NOT_MASKING_CONFIRM_IMAGES';
}

@Injectable()
export class CreditCardAction extends Action {
    constructor(
        private httpService: HttpService,
        private logging: LoggingService,
        private hostErrorService: HostErrorService,
        private ngZone: NgZone,
        private labelService: LabelService,
        private appCtrl: App,
        private errorMessageService: ErrorMessageService
    ) {
        super();
    }

    public setBankclerkId(bankclerkId: string) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_BANKCLERK_ID,
            data: { bankclerkId: bankclerkId }
        });
    }

    public loadTemplate(file: string, pageIndex: number) {
        this.httpService.get(file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    fileInfo: response.result.fileInfos,
                    pageIndex: pageIndex
                }
            });
        });
    }

    public branchStatusInsert(params: any) {
        this.httpService.post(API_URL.BRANCH_STATUS_INSERT, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.BRANCH_STATUS_INSERT,
                data: response.result
            });
        });
    }

    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    public clearStore() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAR
        });
    }

    public clearShowChats() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAR_SHOW_CHATS
        });
    }

    public editChart(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.EDIT_CHAT,
            data: { order: order, pageIndex: pageIndex, answerOrder: answerOrder, orderIndex: orderIndex }
        });
    }

    public setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_ANSWER,
            data: answer
        });
    }

    public setData(submitData: any) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_STATE_DATA,
            data: submitData
        });
    }

    public setStateSubmitDataValue(param: any) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_STATE_SUBMIT_DATA_VALUE,
            data: param
        });
    }

    public submitDataBackup() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SUBMIT_DATA_BACKUP
        });
    }

    public chatFlowCompelete(nextChatName: string) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CHAT_FLOW_COMPELETE,
            data: nextChatName
        });
    }

    public chatFlowReturn(nextChatName: string, options: any = null) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CHAT_FLOW_RETURN,
            data: {
                name: nextChatName,
                options: options
            }
        });
    }

    public resetLastNode(params: { order: number, pageIndex: number }) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.RESET_LAST_NODE,
            data: params
        });
    }

    public async validatePassword(params: any) {
        return new Promise((resolve, reject) => {
            this.httpService.post(API_URL.CARD_CERTIFICATION_CHECK, params, null, SpinnerType.SHOW_TRANSPARENT, true)
                .subscribe(
                    (result) => {
                        if (result.status === HttpStatus.SUCCESS) {
                            resolve(true);
                        } else if (result.status === HttpStatus.HOST_ERROR) {
                            this.hostErrorService.push({
                                resultCode: result.errors.data.resultCode,
                                errorCode: result.errors.data.errorCode,
                                message: result.errors.message,
                                handel: () => {
                                    resolve(false);
                                }
                            });
                        } else {
                            throw new HttpStatusError(API_URL.CARD_CERTIFICATION_CHECK, result.status, result.errors);
                        }
                    }, (error) => {
                        reject(error);
                    });
        });
    }

    /**
     * 会員年齢フラグ設定
     * @param params 会員18歳フラグと家族会員
     */
    public setMemberAgeFlg(params: any) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_MEMBER_AGE_FLG,
            data: params
        });
    }

    public setCreidtCardBrandAndRank(params: any) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_CREDITCARD_BRAND_AND_RANK,
            data: params
        });
    }

    /**
     * クレジットカード発行
     * @param params
     */
    public saveCreditCardData(params: any) {
        this.httpService.post(API_URL.CREDITCARD_INFO_INSERT, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.BRANCH_INFO_INSERT,
                data: response.result
            });
        });
    }

    public loadConfirmPageTemplate(file: string, pageIndex: number) {
        this.httpService.get(file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.GET_CONFIRM_PAGE_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos,
                }
            });
        });
    }

    /**
     * CIF情報照会
     * @param cifInfoParams CIF情報照会用パラメータ
     * @param accountBalanceParams 口座残高情報照会用パラメータ
     */
    public getCifInformation(cifInfoParams: SimpleCifInfoInquiryInterface,
                             accountBalanceParams: AccountBalanceInquiryInterface) {
        const cifInfoRequest: Observable<any> = this.httpService.post(API_URL.CB_GET_SIMPLE_CIF_INFORMATION, cifInfoParams);
        const accountBalanceRequest: Observable<any> = this.httpService.post(API_URL.CB_GET_ACCOUNT_BALANCE, accountBalanceParams);

        Observable.forkJoin(cifInfoRequest, accountBalanceRequest).subscribe((data) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.SET_CIF_INFORMATION,
                data: { data: data }
            });
        });

    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param params QRコード受付情報
     */
    public setSwipeInfo(params: any) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_SWIPE_INFO,
            data: params
        });
    }

    /**
     * tabletApplyIdをstateに格納する
     * @param params
     */
    public setTabletApplyId(params: any) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_TABLET_APPLY_ID,
            data: params
        });
    }

    /**
     * 暗証番号ルール適合性チェック(初めて発行場合)
     * @param params 暗証番号ルール適合性チェック用パラメータ
     */
    public checkExistingCustomerPasswordRule(params: ExistingPasswordRuleCheckInterface) {
        this.httpService.post(API_URL.CB_CHECK_EXISTING_PASSWORD_RULE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.GET_EXISTING_PASSWORD_RULE,
                data: response.result
            });
        });
    }

    /**
     * 暗証番号ルール適合性チェック(初めて発行場合)
     * @param existingParams existing params
     * @param selfParams self params
     */
    public checkSelfPassword(
        existingParams: ExistingPasswordRuleCheckInterface,
        selfParams: NewPasswordRuleCheckInterface): Observable<boolean> {
        const temp = [];

        // existing
        const existingCheck$ = this.httpService
            .post(API_URL.CB_CHECK_EXISTING_PASSWORD_RULE, existingParams)
            .map((res) => (res.result.response.values.result || '') === PasswordVerify.SUCCESS);
        temp.push(existingCheck$);

        // self
        const selfCheck$ = selfParams ? this.httpService
            .post(API_URL.CB_CHECK_NEW_PASSWORD_RULE, selfParams)
            .map((res) => (res.result.response.values.result || '') === PasswordVerify.SUCCESS) : null;
        if (selfCheck$) {
            temp.push(selfCheck$);
        }

        return Observable.combineLatest<boolean>(
            ...temp,
            (...args) => args.every((e) => e)
        ).take(1);
    }

    /**
     * Family password check
     * @param params 暗証番号ルール適合性チェック用パラメータ
     */
    public checkFamilyPassword(
        existingParams: ExistingPasswordRuleCheckInterface,
        familyParams: NewPasswordRuleCheckInterface,
        selfParams: NewPasswordRuleCheckInterface): Observable<boolean> {
        const temp = [];

        // existing
        const existingCheck$ = this.httpService
            .post(API_URL.CB_CHECK_EXISTING_PASSWORD_RULE, existingParams)
            .map((res) => (res.result.response.values.result || '') === PasswordVerify.SUCCESS);
        temp.push(existingCheck$);

        // family
        const normalCheck$ = this.httpService
            .post(API_URL.CB_CHECK_NEW_PASSWORD_RULE, familyParams)
            .map((res) => (res.result.response.values.result || '') === PasswordVerify.SUCCESS);
        temp.push(normalCheck$);

        // self
        const selfCheck$ = selfParams ? this.httpService
            .post(API_URL.CB_CHECK_NEW_PASSWORD_RULE, selfParams)
            .map((res) => (res.result.response.values.result || '') === PasswordVerify.SUCCESS) : null;
        if (selfCheck$) {
            temp.push(selfCheck$);
        }

        return Observable.combineLatest<boolean>(
            ...temp,
            (...args) => args.every((e) => e)
        ).take(1);
    }

    /**
     * 消費税を取得する
     */
    public getConsumptionTax() {
        this.httpService.get(API_URL.GET_CONSUMPTION_TAX).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.GET_CONSUMPTION_TAX,
                data: response.result
            });
        });
    }

    /**
     * Reset showConfirm
     * @param showConfirm showConfirm
     */
    public resetShowConfirm(showConfirm: any) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.RESET_SHOW_CONFIRM,
            data: showConfirm
        });
    }

    /**
     * Reset showChats to origin
     * @param originShowChats originShowChats
     */
    public resetShowChats(originShowChats: any[], originSubmitData: any) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.RESET_SHOWCHATS,
            data: { originShowChats, originSubmitData }
        });
    }

    /**
     * 顧客申し込み開始時間を設定する
     */
    public setCustomerApplyStartDate() {
        this.setAsSystemTime(ApplyDate.CUSTOMER_APPLY_START_DATE);
    }

    /**
     * 顧客申し込み完了時間を設定する
     */
    public setCustomerApplyEndDate() {
        this.setAsSystemTime(ApplyDate.CUSTOMER_APPLY_END_DATE);
    }

    /**
     * 行員認証開始時間を設定する
     */
    public setBankclerkAuthenticationStartDate() {
        this.setAsSystemTime(ApplyDate.BANKCLERK_AUTHENTICATION_START_DATE);
    }

    /**
     * set the item value as the current time of server
     * @param key the checbox item need to modify status
     */
    public setAsSystemTime(key: string) {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.SET_SYSTEM_TIME,
                data: {
                    key: key,
                    systemTime: response.result.value
                }
            });
        });
    }

    /**
     * get holderZipCode 郵便番号
     * @param prefectureKanji 都道府県
     * @param countyUrbanVillageKanji 市区町村
     * @param streetKanji 町丁名
     */
    public getHolderZipCode(prefectureKanji: string, countyUrbanVillageKanji: string, streetKanji: string) {
        const params = {
            prefectureKanji: prefectureKanji,
            countyUrbanVillageKanji: countyUrbanVillageKanji,
            streetKanji: streetKanji
        };
        this.httpService.get(API_URL.ADDRESS_ZIP_CODE_SEARCH, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.GET_HOLDER_ZIP_CODE,
                data: response.result.zipCode
            });
        }
        );
    }

    /**
     * 親権者or勤務先の郵便番号を取得する。郵便番号スキップ時に実行される。
     * @param prefectureKanji 都道府県
     * @param countyUrbanVillageKanji 市区町村
     * @param streetKanji 町丁名
     */
    public getHolderZipCodeSelected(prefectureKanji: string, countyUrbanVillageKanji: string, streetKanji: string, name: string) {
        const params = {
            prefectureKanji: prefectureKanji,
            countyUrbanVillageKanji: countyUrbanVillageKanji,
            streetKanji: streetKanji
        };
        this.httpService.get(API_URL.ADDRESS_ZIP_CODE_SEARCH, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.GET_HOLDER_ZIP_CODE_SELECTED,
                data: {zipCode: response.result.zipCode, name: name}
            });
        }
        );
    }

    /**
     * clear item from submit data
     */
    public clearSubmitData(choices: any[]) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAR_SUBMIT_DATA,
            data: choices
        });
    }

    /**
     * 家族会員の名前(フリガナ)をカード券面にセット。
     * @param params QRコード受付情報
     */
    public setfamilyMemberNameRoma(params: any) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_FAMILY_NAME_ROMA,
            data: params
        });
    }

    /**
     * 郵便番号　default value
     */
    public setDefaultZipCode() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_DEFAULT_ZIP_CODE,
        });
    }

    /**
     * 親権者or勤務先の郵便番号に、default valueをセットする。
     */
    public setDefaultToSelectedZipCode(name: string) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_DEFAULT_TO_SELECTED_ZIP_CODE,
            data: name
        });
    }

    /**
     * 登録不可漢字先が漢字氏名を入力した際、申込内容確認画面で修正ボタンが表示する
     */
    public setEditNameKanji() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_ONLY_NAME_KANJI_EDIT_FLG,
        });
    }

    /**
     * ログ
     */
    public saveOperationLog(logInfo: IOperationInfo) {
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }

    /**
     * modify checkbox status
     * @param name the checbox item need to modify status
     */
    public modifyCheckboxStatus(name: string) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.MODIFY_CHECKBOX_STATUS,
            data: name
        });
    }

    /**
     * 口座開設申込内容確認画面へ戻る際modifyCheckboxStatusを呼び出す
     * @param name the checbox item need to modify status
     */
    public callModifyCheckboxStatus(name: string) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CALL_MODIFY_CHECKBOX_STATUS,
            data: name
        });
    }

    public needInputPhoenNo() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.NEED_INPUT_PHONE_NO,
        });
    }

    public initializeDataArr() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.INITIALIZE_DATA_ARR,
        });
    }

    public setEditedList(name: string) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_EDITED_LIST,
            data: name
        });
    }

    /**
     * 親権者住所の変数をクリアする。
     */
    public clearParentalAddress() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAR_PARENTAL_ADDRESS,
        });
    }

    /**
     * 勤務先住所の変数をクリアする。
     */
    public clearEmploymentAddress() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAR_EMPLOYMENT_ADDRESS,
        });
    }

    /**
     * 勤務先情報をクリアする (修正チャット用)
     * @param clearIncome 前年度税込年収をクリアするか否か
     */
    public clearEmploymentInfo(clearIncome: boolean) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAR_EMPLOYMENT_INFO,
            data: clearIncome
        });
    }

    /**
     * 親権者情報をクリアする (修正チャット用)
     */
    public clearParentalInfo() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAR_PARENTAL_INFO,
        });
    }

    /**
     * バンクカードローン情報をクリアする (修正チャット用)
     */
    public clearBcLoanInfo() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAR_BC_LOAN_INFO,
        });
    }

    /**
     * 学校情報情報をクリアする (修正チャット用)
     */
    public clearShoolInfo() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAR_SCHOOL_INFO,
        });
    }

    /**
     * 確認画面の表示文言を、修正チャット開始前の状態に戻す。
     */
    public restoreShowConfirm(name: string) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.RESTORE_SHOW_COFIRM,
            data: name
        });
    }

   /**
    * BC受付可否チェックAPI
    * @param {*} params
    */
    public bankCardApplyCheck(params: any) {
        this.httpService.post(API_URL.BC_APPLY_CHECK, params, undefined, undefined, true).subscribe(
            (response) => {
                this.dispatcher.dispatch({
                    actionType: CreditCardActionType.BC_APPLY_CHECK,
                    data: {
                        data: response instanceof HttpStatusError ? response.errors.data : response.result,
                    }
                });
            }
        );
    }

    public setIdentificationDocument(data) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_IDENTIFICATION_DOCUMENT,
            data: data
        });
    }

    /**
     * 本人確認書類画像をクリア
     */
    public cleanIdentityDocumentImage(category: Constants.IdentityDocumentCategory) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAN_DOCUMENT_IMAGE,
            data: category
        });
    }

    /**
     * 本人確認書類画像を保存
     */
    public saveIdentityDocumentImage(document: {image: string, category: Constants.IdentityDocumentCategory}) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SAVE_DOCUMENT_IMAGE,
            data: document
        });
    }

    /**
     * サブミットデータに値を設定する
     *
     * @param param 項目値
     */
    public setStateSubmitDataValueforCheckApply(param: Array<{ key: string, value: string }>) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_STATE_SUBMIT_DATA_VALUE_FOR_CHECK_APPLY,
            data: param
        });
    }

    /**
     * submitDataの値を変更する
     *
     * @param {*} data
     * @memberof CreditCardActionType
     */
    public editSomeDataInSubmitData(index: number, key: string, val: any) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_SUBMIT_DATA,
            data: {
                index: index,
                key: key,
                val: val
            }
        });
    }

    public updateSubmitDataBackup(data) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.UPDATA_SUBMIT_DATA_BACKUP,
            data: data
        });
    }

    /**
     * 行員確認画面 submit
     * @param params params
     */
    public submitCreditCardData(params: any) {
        this.httpService.post(
            API_URL.BANKCARD_BC_APPLICATION,
            params, {},
            SpinnerType.SHOW
        ).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.CREDITCARD_INFO_INSERT,
                data: response.result
            });
        });
    }

    /**
     * 普通預金口座開設APIを呼び出す
     * @param params params
     */
    public submitTimeSavingOrangeApplyInfo(params: any) {
        this.httpService.post(
            API_URL.ORDINARILY_ACCOUNT_INFO,
            params, {},
            SpinnerType.SHOW
        ).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CreditCardActionType.CREDITCARD_INFO_INSERT,
                data: response.result
            });
        });
    }

    public setStateData(data) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.SET_STATE_DATA_FOR_CONFIRM,
            data: data
        });
    }

    /**
     * 文字チェック
     * @param params 文字チェックパラメータ
     */
    public characteCheck(params: any, handel?: any) {
        this.httpService.post(API_URL.CHARACTER_CHECK, params, null, SpinnerType.SHOW_TRANSPARENT, true)
        .subscribe((result) => {
            if (result.status === HttpStatus.SUCCESS) {
                this.dispatcher.dispatch({
                    actionType: CreditCardActionType.CHARACTER_CHECK,
                    data: result.result
                });
            } else if (result.status === HttpStatus.HOST_ERROR) {
                if (result.errors.data &&
                    result.errors.data.resultCode &&
                    result.errors.data.resultCode === HostResultCode.REENTER) {
                        this.hostErrorService.push({
                            resultCode: result.errors.data.resultCode,
                            errorCode: result.errors.data.errorCode,
                            message: result.errors.message,
                            handel: handel
                        });
                }
            } else {
                throw new HttpStatusError(API_URL.CHARACTER_CHECK, result.status, result.errors);
            }
        });
    }

    /**
     * SUBMITDATA_ARRをバックアップする
     */
    public backupSubmitDataArr() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.BACKUP_SUBMITDATA_ARR
        });
    }

    /**
     * SUBMITDATA_ARRをクリアする
     */
    public clearConfirmPageInfo() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAR_CONFIRMPAGE_INFO
        });
    }

    /**
     * 写真未確認状態管理オブジェクトから確認済内容を削除
     *
     * @param {{documentName: string, index: number}} maskingConfirmImgStatus
     * @memberof CreditCardAction
     */
    public removeNotMaskingConfirmImages(maskingConfirmImgStatus: {documentName: string, index: number}) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES,
            data: maskingConfirmImgStatus
        });
    }

    /**
     * マスキング確認完了しないオブジェクトをリセット。
     *
     * @param {ClearSavingImagesClickRecordType} type リセットタイプ
     * @memberof CreditCardAction
     */
    public resetNotMaskingConfirmImages(type: ClearSavingImagesClickRecordType) {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.RESET_NOT_MASKING_CONFIRM_IMAGES,
            data: type
        });
    }

    /**
     * BC複合取引の場合、本人確認書類聴取前のsubmitDataをバックアップ
     */
    public backupOriginSubmitData() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.BACKUP_ORIGIN_SUBMITDATA,
        });
    }

    public resetSubmitData() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.RESET_SUBMIT_DATA
        });
    }

    /**
     * BC複合取引の場合、バックアップした運転免許証番号、学生証、連絡事項をクリア
     */
    public clearCopyComplexTransConfirmInfos() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.CLEAR_COPY_COMPLEX_TRANS_CONFIRM_INFOS
        });
    }

    /**
     * BC複合取引の場合、運転免許証番号、学生証、連絡事項をバックアップ
     */
    public backupComplexTransConfirmInfos() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.BACKUP_COMPLEX_TRANS_CONFIRM_INFOS
        });
    }

    /**
     * BC複合取引の場合にて
     * 一度口座開設行員確認画面に「戻る」した場合
     * submitData配下の未マスキング完了オブジェクトのバックアップから復元
     */
    public restoreBackupNotMaskingConfirmImages() {
        this.dispatcher.dispatch({
            actionType: CreditCardActionType.RESTORE_BACKUP_NOT_MASKING_CONFIRM_IMAGES
        });
    }
}
