/**
 * 修正ChatFlowRenderer用のクラスデコレータ。
 * @param options 修正yaml情報
 */
export function AutomaticTransferConfirmRenderer(options) {
    return (target: any) => {
        Reflect.defineProperty(target, AutomaticTransferLoadConfirmYamlTemplate, {
            value: options.templateYaml
        });
    };
}

/**
 * 修正ChatFlowRenderer用yamlのキー
 */
export const AutomaticTransferLoadConfirmYamlTemplate = Symbol('AutomaticTransferConfirmYamlTemplate');
