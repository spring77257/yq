import { NgModule, Type } from '@angular/core';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferCancelInputHandler
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/handler/automatic-transfer-cancel.handler';
import {
    AutomaticTransferCommonInputHandler
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/handler/automatic-transfer-common.handler';
import {
    AutomaticTransferNewApplyInputHandler
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/handler/automatic-transfer-new-apply.handler';
import {
    AutomaticTransferNewinformationInputHandler
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/handler/automatic-transfer-new-information.handler';
import {
    AutomaticTransferNewRecipientInputHandler
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/handler/automatic-transfer-new-recipient.handler';
import {
    AutomaticTransferCancelRenderer
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/renderer/automatic-transfer-cancel.renderer';
import {
    AutomaticTransferCommonRenderer
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/renderer/automatic-transfer-common.renderer';
import {
    AutomaticTransferNewApplyRenderer
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/renderer/automatic-transfer-new-apply.renderer';
import {
    AutomaticTransferNewInformationRenderer
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/renderer/automatic-transfer-new-information.renderer';
import {
    AutomaticTransferNewRecipientRenderer
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/renderer/automatic-transfer-new-recipient.renderer';
import { AutomaticTransferConfirmService } from 'dhdt/branch/pages/automatic-transfer/service/automatic-transfer-confirm.service';
import { AutomaticTransferStore } from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import { AutomaticTransferChatComponent } from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-chat.component';
import { AutomaticTransferConfirmComponent } from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-confirm.component';
import { AutomaticTransferConfirmationComponent
} from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-confirmation.component';
import { AutomaticTransferInitconfirmComponent } from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-initconfirm.component';
import { AutomaticTransferTopCompleteComponent } from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-top-complete.component';
import { AccountShopModule } from 'dhdt/branch/shared/components/account-shop/account-shop.module';
import { ConfirmPageCommonModule } from 'dhdt/branch/shared/components/confirmpage-common/confirmpage.common.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';

export const SHARED_FORM_COMPONENT: Array<Type<any>> = [
    AutomaticTransferChatComponent,
    AutomaticTransferTopCompleteComponent,
    AutomaticTransferConfirmationComponent,
    AutomaticTransferInitconfirmComponent,
    AutomaticTransferConfirmComponent,
];

@NgModule({
    imports: [
        IonicModule,
        SharedModule,
        AccountShopModule,
        ConfirmPageCommonModule
    ],
    declarations: [
        SHARED_FORM_COMPONENT,
    ],
    exports: [
        SHARED_FORM_COMPONENT,
    ],
    entryComponents: [
        SHARED_FORM_COMPONENT,
    ],
    providers: [
        AutomaticTransferAction,
        AutomaticTransferStore,
        AutomaticTransferCommonRenderer,
        AutomaticTransferNewApplyRenderer,
        AutomaticTransferNewInformationRenderer,
        AutomaticTransferNewRecipientRenderer,
        AutomaticTransferCancelRenderer,
        AutomaticTransferCommonInputHandler,
        AutomaticTransferNewApplyInputHandler,
        AutomaticTransferNewinformationInputHandler,
        AutomaticTransferNewRecipientInputHandler,
        AutomaticTransferCancelInputHandler,
        AutomaticTransferConfirmService
    ]
})
export class AutomaticTransferModule {
}
