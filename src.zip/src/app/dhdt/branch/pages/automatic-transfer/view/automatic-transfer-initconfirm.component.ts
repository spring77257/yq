import { Component, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import { AutomaticTransferConfirmItem } from 'dhdt/branch/pages/automatic-transfer/service/automatic-transfer-confirm.item';
import {
    AutomaticTransferState, AutomaticTransferStateSignal, AutomaticTransferStore
} from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import { AutomaticTransferChatComponent } from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-chat.component';
import {
    AutomaticTransferConfirmationComponent
} from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-confirmation.component';
import { AutomaticTransferRegisterCategory } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { ChatFlowHeaderInterfaces } from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { HolderAgentInfoUtil } from 'dhdt/branch/shared/utils/holder_agent_info-util';
import { Content, ModalController, NavController } from 'ionic-angular';
import { AutomaticTransferConfirmService } from '../service/automatic-transfer-confirm.service';

/**
 * 自動振込申込確認画面
 *
 * @export
 * @class AutomaticTransferActionTypeChatComponent
 * @extends {AbstractChatFlowControlComponent}
 * @implements {OnDestroy}
 */
@Component({
    selector: 'automatic-transfer-initconfirm-component',
    templateUrl: 'automatic-transfer-initconfirm.component.html'
})
export class AutomaticTransferInitconfirmComponent extends BaseComponent {
    @ViewChild(Content) public content: Content;
    public state: AutomaticTransferState;
    public headerOptions: ChatFlowHeaderInterfaces.Options;
    public editedList: Map<AutomaticTransferConfirmItem, boolean>;

    constructor(private store: AutomaticTransferStore,
                private action: AutomaticTransferAction,
                private confirmService: AutomaticTransferConfirmService,
                private modalCtrl: ModalController,
                private navCtrl: NavController,
                private logging: LoggingService,
                private loginStore: LoginStore) {

        super();
        this.state = this.store.getState();
        this.editedList = new Map();
    }

    /**
     * 自動振込情報の変更
     * @param param 変更情報
     */
    public simplyChange(param: Object | AutomaticTransferConfirmItem) {
        if (param instanceof Object) {
            const { item, associated } = param as { item: AutomaticTransferConfirmItem, associated: AutomaticTransferConfirmItem[] };
            this.showConfirmModal(item, associated);
        } else {
            const item = param as AutomaticTransferConfirmItem;
            this.showConfirmModal(item);
        }
    }

    /**
     * 新規振込の場合を判定する
     */
    public get isTransfer(): boolean {
        return this.state.submitData.registerCategory === AutomaticTransferRegisterCategory.TRANSFER;
    }

    /**
     * 確認ボタン文言を取得する
     */
    public get confirmButtonText() {
        return this.isTransfer ? this.labels.automaticTransfer.contentConfirm.endButtonTransfer
            : this.labels.automaticTransfer.contentConfirm.endButtonCancel;
    }

    /**
     * タートル文言を取得する
     */
    public get confirmTitle() {
        return this.isTransfer ? this.labels.automaticTransfer.contentConfirm.title
            : this.labels.automaticTransfer.contentConfirm.cancelTitle;
    }

    public moveToNextPage() {
        this.logging.saveCustomOperationLog(
            this.labels.logging.AutomaticTransfer.AutomaticConfirm.ScreenName,
            this.isTransfer ? this.labels.logging.AutomaticTransfer.applyButton
                : this.labels.logging.AutomaticTransfer.cancelApplyButton,
        );
        const param = {
            tabletApplyId: this.state.submitData.tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            accountNo: this.state.submitData.swipeAccountNo,
            tenban: this.state.submitData.swipeBranchNo,
            accountType: this.state.submitData.swipeAccountType
        };

        const modal = this.modalCtrl.create(ModalPasswordComponent,
            {
                data: {
                    text: this.labels.password.inputPasswordAgainText,
                    subText: this.labels.password.inputPasswordAgainSubText,
                    units: 4,
                    needConfirm: false,
                    cashcardParams: param
                }
            },
            { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.onDidDismiss((value) => {
            if (value) {
                this.store.registerSignalHandler(AutomaticTransferStateSignal.CUSTOMER_APPLY_END_DATE, () => {
                    this.store.unregisterSignalHandler(AutomaticTransferStateSignal.CUSTOMER_APPLY_END_DATE);
                    this.navCtrl.push(AutomaticTransferConfirmationComponent);
                });
                this.action.setCustomerApplyEndDate();
            }
        });
        modal.present();
    }

    /**
     * 確認用ChatComponentを表示
     * @param item 修正されたitem
     * @param associated 修正されたitemと関係あるitem
     */
    private showConfirmModal(item, associated?: any[]) {

        const confirm = this.confirmService.confirmParams.get(item);
        this.saveOperationLog(confirm);
        const modal = this.modalCtrl.create(AutomaticTransferChatComponent,
            {
                startOrder: confirm.startOrder, endOrder: confirm.endOrder, pageIndex: confirm.pageIndex,
                isCurrentPage: true, currentTitle: confirm.currentTitle
            },
            { cssClass: 'full-modal', enableBackdropDismiss: false });
        modal.onDidDismiss((value) => {
            if (value !== undefined) {
                return;
            }

            this.editedList.set(item, true);
            if (associated) {
                associated.forEach((element) => this.editedList.set(element, true));
            }
        });
        modal.present();
    }

    /**
     *  操作ログ
     */
    private saveOperationLog(showChartParam) {
        const value = this.getLogValue(showChartParam);
        const logInfo: IOperationInfo = {
            screenName: this._labels.logging.AutomaticTransfer.AutomaticConfirm.ScreenName,
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: value,
        };
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }

    private getLogValue(showChartParam) {
        switch (showChartParam.name) {
            // 内容
            case 'wireTransferContents':
            return this._labels.logging.AutomaticTransfer.AutomaticConfirm.wireTransferContentsButton;
            // 引落口座
            case 'withdrawalAccount':
            return this._labels.logging.AutomaticTransfer.AutomaticConfirm.withdrawalAccountButton;
            // 振込先銀行
            case 'transferDestinationBank':
            return this._labels.logging.AutomaticTransfer.AutomaticConfirm.transferDestinationBankButton;
            // 毎月振込日
            case 'monthlyTransferDate':
            return this._labels.logging.AutomaticTransfer.AutomaticConfirm.monthlyTransferDateButton;
            // 再振込処理
            case 'reTransferProcess':
            return this._labels.logging.AutomaticTransfer.AutomaticConfirm.reTransferProcessButton;
            // 毎月振込金額
            case 'monthlyTransferAmount':
            return this._labels.logging.AutomaticTransfer.AutomaticConfirm.monthlyTransferAmountButton;
            // 特定振込月
            case 'specifiedTransferMonth':
            return this._labels.logging.AutomaticTransfer.AutomaticConfirm.specifiedTransferMonth1Button;
            // 振込終了年月
            case 'transferEndDate':
            return this._labels.logging.AutomaticTransfer.AutomaticConfirm.transferEndDateButton;
            // 解約
            case 'transferCancel':
            return this._labels.logging.AutomaticTransfer.AutomaticConfirm.contractCancelInfoButton;
        }
    }
}
