import { AfterViewChecked, Component, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AUTOMATIC_TRANSFER_CANCEL_RENDERER_TYPE
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/renderer/automatic-transfer-cancel.renderer';
import {
    AUTOMATIC_TRANSFER_COMMON_RENDERER_TYPE
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/renderer/automatic-transfer-common.renderer';
import {
    AUTOMATIC_TRANSFER_NEW_APPLY_RENDERER_TYPE
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/renderer/automatic-transfer-new-apply.renderer';
import {
    AUTOMATIC_TRANSFER_NEW_INFORMATION_RENDERER_TYPE
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/renderer/automatic-transfer-new-information.renderer';
import {
    AUTOMATIC_TRANSFER_NEW_RECIPIENT_RENDERER_TYPE
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/renderer/automatic-transfer-new-recipient.renderer';
import { AutomaticTransferConfirmService } from 'dhdt/branch/pages/automatic-transfer/service/automatic-transfer-confirm.service';
import {
    AutomaticTransferState, AutomaticTransferStateSignal, AutomaticTransferStore
} from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import {
    AutomaticTransferRegisterCategory, AutomaticTransferStudentDepositType,
    COMMON_CONSTANTS, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import {
    AbstractChatFlowControlComponent
} from 'dhdt/branch/shared/modules/chat-flow/components/abstract-chat-flow-control.component';
import {
    ChatFlowHeaderInterfaces,
    ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { Content } from 'ionic-angular';

/**
 * AutomaticTransferActionTypeに関わるChatFlowを制御する。
 *
 * @export
 * @class AutomaticTransferActionTypeChatComponent
 * @extends {AbstractChatFlowControlComponent}
 * @implements {OnInit}
 * @implements {OnDestroy}
 */
@Component({
    selector: 'automatic-transfer-chat-component',
    templateUrl: 'automatic-transfer-chat.component.html'
})
export class AutomaticTransferChatComponent extends AbstractChatFlowControlComponent implements OnInit, OnDestroy, AfterViewChecked {
    @ViewChild(Content) public content: Content;
    public state: AutomaticTransferState;
    public headerOptions: ChatFlowHeaderInterfaces.Options;

    constructor(private store: AutomaticTransferStore,
                private action: AutomaticTransferAction,
                private confirmService: AutomaticTransferConfirmService,
                injector: Injector) {
        super(action, injector);

        this.state = this.store.getState();
    }

    /**
     * 初期化処理として以下を行う。
     * * `AbstractChatFlowControlComponent`の初期化メソッド(`initChatFlowControl`)を実行する。
     * * `ChatFlowHeaderComponent`用のオプションをセットアップする。
     * * Storeからのシグナルを登録する。
     *
     * @memberof AutomaticTransferActionTypeChatComponent
     */
    public ngOnInit() {
        this.parseParam();
        this.setupHeaderOptions();
        this.currentRenderer = this.setupRenderer(this.currentRendererIndex, this.getRendererNameByIndex(this.currentRendererIndex));
        this.action.clearShowChats();

        if (this.chatFlowNavParam.startOrder != null && this.chatFlowNavParam.endOrder != null) {
            this.action.submitDataBackup();
            this.chatFlowNavParam.needPassword = false;
            this.confirmService.loadConfirmTemplate({
                renderer: this.currentRenderer, index: this.currentRendererIndex
            });
            this.store.registerSignalHandler(AutomaticTransferStateSignal.GET_CONFIRM_PAGE_TEMPLATE, (pageIndex: number) => {
                this.store.unregisterSignalHandler(AutomaticTransferStateSignal.GET_CONFIRM_PAGE_TEMPLATE);
                this.chatFlowInputField.clear();
                this.action.getNextChatByAnswer(this.chatFlowNavParam.startOrder, pageIndex);
            });
        } else {
            this.action.clearStore();
            this.currentRenderer.loadTemplate(this.currentRendererIndex);
            this.action.setCustomerApplyStartDate(this.chatFlowNavParam.customerApplyStartDate);
            // 読み込むQRコード情報をこのフローに設定する
            this.action.setSwipeInfo(this.chatFlowNavParam.swipeInfo);
            // 取得されたtabletApplyId設定する
            this.action.setStateSubmitDataValue({name: SubmitDataKey.KEY_TABLET_APPLY_ID, value: this.chatFlowNavParam.tabletApplyId});
        }

        this.store.registerSignalHandler(AutomaticTransferStateSignal.CHAT_FLOW_COMPELETE, (nextComponentType) => {
            this.onChatFlowComplete(nextComponentType, TopComponent);
        });
        this.store.registerSignalHandler(AutomaticTransferStateSignal.GET_QUESTION, (pageIndex: number) => {
            this.onYamlDidLoad(pageIndex);
        });
        this.store.registerSignalHandler(AutomaticTransferStateSignal.SEND_ANSWER, (data) => {
            this.onNextMessage(data);
        });
        this.viewCtrl.willEnter.subscribe(() => {
            this.store.registerSignalHandler(AutomaticTransferStateSignal.DISMISS_COMPONENT, () => {
                // 修正場合は、システムエラーが発生すれば、modalをdismiss
                if (this.chatFlowNavParam.startOrder != null && this.chatFlowNavParam.endOrder != null) {
                    this.viewCtrl.dismiss();
                }
            });
        });
        this.viewCtrl.willLeave.subscribe(() => {
            if (this.state.submitData.registerCategory === AutomaticTransferRegisterCategory.TRANSFER) {
                // 取扱手数料を設定
                this.action.setStateSubmitDataValue({
                    name: SubmitDataKey.HANDLING_FEE,
                    value: this.state.studentAccountType === AutomaticTransferStudentDepositType.STUDENT ? 0 : this.state.handlingFee
                });
            }
            this.store.unregisterSignalHandler(AutomaticTransferStateSignal.DISMISS_COMPONENT);
        });
    }

    /**
     * クリーンアップ処理として以下を行う。
     * * `AbstractChatFlowControlComponent`のクリーンアップメソッド(`destoyChatFlowControl`)を実行する。
     * * Storeシグナルの登録を解除する。
     *
     * @memberof AutomaticTransferActionTypeChatComponent
     */
    public ngOnDestroy() {
        this.destoyChatFlowControl();
        this.store.unregisterSignalHandler(AutomaticTransferStateSignal.CHAT_FLOW_COMPELETE);
        this.store.unregisterSignalHandler(AutomaticTransferStateSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(AutomaticTransferStateSignal.SEND_ANSWER);
    }

    /**
     * ViewCheck後（Viewが変更された後）にメッセージコンテナを最下部へスクロールする。
     *
     * @memberof AutomaticTransferActionTypeChatComponent
     */
    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    /**
     * この値によって、ヘッダ下部のStepperがどこまで進んでいるかを判断する。
     */
    public get processType() {
        return this.chatFlowNavParam.startOrder && this.chatFlowNavParam.endOrder ? -1 : 1;
    }

    /**
     * Cancel emitter handler
     */
    public cancelEmitterHandler() {
        super.cancelEmitterHandler();
        this.action.submitDataRestore();
    }

    /**
     * タイトルを取得する。
     *
     * @memberof AutomaticTransferActionTypeChatComponent
     */
    public get headerTitle(): string {
        return this.labels.automaticTransfer.title;
    }

    /**
     * Navigationを取得する。
     *
     * @memberof AutomaticTransferActionTypeChatComponent
     */
    public get processItems() {
        return [
            {
                type: COMMON_CONSTANTS.ProcessType.RequiredInput,
                value: this.labels.processType.requiredInput,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyInfoConfirm,
                value: this.labels.processType.applyInfoConfirm,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.BankClerkConfirm,
                value: this.labels.processType.bankClerkConfirm,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
                value: this.labels.processType.completion,
            },
        ];
    }

    /**
     * ページのindexに対して、コンポーネントの名前を取得する
     *
     * @param {number} index
     */
    protected getRendererNameByIndex(index: number) {
        const componentNameMap = {
            0: AUTOMATIC_TRANSFER_COMMON_RENDERER_TYPE,
            1: AUTOMATIC_TRANSFER_NEW_APPLY_RENDERER_TYPE,
            2: AUTOMATIC_TRANSFER_NEW_RECIPIENT_RENDERER_TYPE,
            3: AUTOMATIC_TRANSFER_NEW_INFORMATION_RENDERER_TYPE,
            4: AUTOMATIC_TRANSFER_CANCEL_RENDERER_TYPE,
        };

        let componentName = componentNameMap[index];
        if (!componentName) {
            componentName = AUTOMATIC_TRANSFER_COMMON_RENDERER_TYPE;
        }

        return componentName;
    }

    /**
     * 店舗マスタを更新する
     */
    // tslint:disable-next-line:no-empty
    protected branchStatusUpdate(): void {
    }

    private setupHeaderOptions() {
        if (!this.chatFlowNavParam.isCurrentPage) {
            this.headerOptions = {
                showReturnTopButton: true,
                topComponent: TopComponent,
                title: this.headerTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.CALL_CLERK
            };
        } else {
            this.headerOptions = {
                showReturnTopButton: false,
                title: this.chatFlowNavParam.currentTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
            };
        }
    }
}
