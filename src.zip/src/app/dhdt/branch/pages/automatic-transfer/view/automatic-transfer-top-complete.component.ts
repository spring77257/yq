import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import {
    ChatFlowHeaderInterfaces,
    ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { NavController } from 'ionic-angular';
@Component({
    selector: 'automatic-transfer-top-complete-component',
    templateUrl: 'automatic-transfer-top-complete.component.html'
})

/**
 * 自動振込-入力完了画面
 */
export class AutomaticTransferTopCompleteComponent extends BaseComponent
    implements OnInit {
    // バックグラウンド画像URL
    public imgUrl: any;
    public processType = COMMON_CONSTANTS.ProcessType.ApplyCompletion;
    public headerOptions: ChatFlowHeaderInterfaces.Options;

    constructor(
        private navCtrl: NavController,
        private action: AutomaticTransferAction,
        private logging: LoggingService,
        private savingsAction: SavingsAction
    ) {
        super();
    }

    public ngOnInit(): void {
        this.imgUrl = COMMON_CONSTANTS.FLOW_TYPE_WITHOUT_AUTHENTICATION;
        this.setupHeaderOptions();
    }

    /**
     * TOPに戻る
     */
    public moveToNext(): void {
        this.logging.saveCustomOperationLog(
            this.labels.logging.AutomaticTransfer.TopComplete.ScreenName,
            this.labels.logging.Common.GobackTopAction,
        );
        // ストアをクリア
        this.clearStores();
        this.navCtrl.setRoot(TopComponent);
    }

    /**
     * ストアのクリア
     */
    private clearStores() {
        this.action.clearStore();
        this.savingsAction.clearStore();
    }

    /**
     * Navigationを取得する。
     *
     */
    public get processItems() {
        return [
            {
                type: COMMON_CONSTANTS.ProcessType.RequiredInput,
                value: this.labels.processType.requiredInput
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyInfoConfirm,
                value: this.labels.processType.applyInfoConfirm
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
                value: this.labels.processType.completion
            }
        ];
    }

    /**
     * ヘッダオプションの設定
     */
    private setupHeaderOptions() {
        this.headerOptions = {
            showReturnTopButton: true,
            topComponent: TopComponent,
            title: this.labels.automaticTransfer.title,
            leftButtonType: ChatFlowHeaderOptions.LeftButtonType.CALL_CLERK
        };
    }
}
