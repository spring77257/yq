import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import { AutomaticTransferConfirmComponent } from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-confirm.component';
import { COMMON_CONSTANTS, CssConsts } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ModalDigitalStore } from 'dhdt/branch/shared/components/modal/modal-digital/store/modal-digital.store';
import { ModalDigitalComponent } from 'dhdt/branch/shared/components/modal/modal-digital/view/modal-digital.component';
import {
    ChatFlowHeaderInterfaces,
    ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalController, NavController } from 'ionic-angular';
import { NavParams } from 'ionic-angular/navigation/nav-params';

@Component({
    selector: 'automatic-transfer-confirmation-component',
    templateUrl: 'automatic-transfer-confirmation.component.html'
})

/**
 * 自動振込-行員確認.
 */
export class AutomaticTransferConfirmationComponent extends BaseComponent implements OnInit {
    @ViewChild('audioView', { read: ElementRef }) public audioView;
    // バックグラウンド画像Url
    public imgUrl: any;
    public processType = COMMON_CONSTANTS.ProcessType.BankClerkConfirm;
    public headerOptions: ChatFlowHeaderInterfaces.Options;

    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private action: AutomaticTransferAction,
        private modalDigitalStore: ModalDigitalStore,
        private modalCtrl: ModalController,
        private logging: LoggingService,
    ) {
        super();
        this.processType = COMMON_CONSTANTS.ProcessType.BankClerkConfirm;
    }

    public ngOnInit(): void {
        this.imgUrl = COMMON_CONSTANTS.FLOW_TYPE_INIT_CONFIRM;
        this.setupHeaderOptions();
    }

    /**
     * ビューが入る
     */
    public ionViewDidEnter() {
        this.audioView.nativeElement.play();
    }

    /**
     * 行員確認
     */
    public onButtonClick(): void {
        const modal = this.modalCtrl.create(
            ModalDigitalComponent,
            { data: {
                title: this.labels.change.userConfirm,
                subTitle: this.labels.change.inputPassword,
                showInput: CssConsts.CSS_CLASS_TWO_INPUTS
            }},
            { cssClass: CssConsts.CSS_CLASS_TWO_INPUTS }
        );
        modal.onDidDismiss((success) => {
            if (success) {
                // 行員認証IDを記録する
                this.action.setBankclerkId(this.modalDigitalStore.getState().bankclerkId);
                // 行員認証開始時間を記録する
                this.action.setBankclerkAuthenticationStartDate();
                this.navCtrl.push(AutomaticTransferConfirmComponent);
            }
        });
        modal.present();
        this.logging.saveCustomOperationLog(
            this.labels.logging.AutomaticTransfer.AutomaticConfirmToClerk.ScreenName,
            this.labels.logging.AutomaticTransfer.AutomaticConfirmToClerk.ClerkButton,
        );
    }

    /**
     * Navigationを取得する。
     *
     */
    public get processItems() {
        return [
            {
                type: COMMON_CONSTANTS.ProcessType.RequiredInput,
                value: this.labels.processType.requiredInput
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyInfoConfirm,
                value: this.labels.processType.applyInfoConfirm
            },
            {
                type: COMMON_CONSTANTS.ProcessType.BankClerkConfirm,
                value: this.labels.processType.bankClerkConfirm
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
                value: this.labels.processType.completion
            },
        ];
    }

    /**
     * ボタンのタイトル
     */
    public get buttonTitle() {
        return this.labels.automaticTransfer.clerkConfirmButton;
    }

    /**
     * ヘッダオプションの設定
     */
    private setupHeaderOptions() {
        this.headerOptions = {
            showReturnTopButton: true,
            topComponent: TopComponent,
            title: this.labels.automaticTransfer.title,
            leftButtonType: ChatFlowHeaderOptions.LeftButtonType.CALL_CLERK
        };
    }

}
