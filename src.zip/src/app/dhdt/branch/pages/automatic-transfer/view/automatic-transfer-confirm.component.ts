import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferState, AutomaticTransferStateSignal, AutomaticTransferStore
} from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import { AutomaticTransferInitconfirmComponent } from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-initconfirm.component';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { AutomaticTransferRegisterCategory, COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ChatFlowHeaderInterfaces } from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { DocumentCategoryService } from 'dhdt/branch/shared/modules/document-category/service/document-category.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { HolderAgentInfoUtil } from 'dhdt/branch/shared/utils/holder_agent_info-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { Content, NavController, ViewController } from 'ionic-angular';

/**
 * 自動振込申込確認画面
 *
 * @export
 * @class AutomaticTransferActionTypeChatComponent
 * @extends {AbstractChatFlowControlComponent}
 * @implements {OnInit}
 * @implements {OnDestroy}
 */
@Component({
    selector: 'automatic-transfer-confirm-component',
    templateUrl: 'automatic-transfer-confirm.component.html'
})
export class AutomaticTransferConfirmComponent extends BaseComponent implements OnInit, OnDestroy {
    @ViewChild(Content) public content: Content;
    public state: AutomaticTransferState;
    public headerOptions: ChatFlowHeaderInterfaces.Options;
    public submitted: boolean = false;
    // 二度押下を回避するフラグ
    public isBackToCustomerConfirmPage = false;

    private insertImageType: string = COMMON_CONSTANTS.InsertImageType.image;
    private insertImageTypeNoFace: string = COMMON_CONSTANTS.InsertImageType.image;

    constructor(private store: AutomaticTransferStore,
                private action: AutomaticTransferAction,
                private navCtrl: NavController,
                private modalService: ModalService,
                private logging: LoggingService,
                private categoryService: DocumentCategoryService,
                private viewCtrl: ViewController) {

        super();
        this.state = this.store.getState();

        this.viewCtrl.willEnter.subscribe(() => this.categoryService.addObserver((data) => {
            this.action.setDocumentCategory(data);
        }, this));

        this.viewCtrl.willLeave.subscribe(() => this.categoryService.removeObserver(this));
    }

    /**
     * 初期化処理として以下を行う。
     * * `AbstractChatFlowControlComponent`の初期化メソッド(`initChatFlowControl`)を実行する。
     * * `ChatFlowHeaderComponent`用のオプションをセットアップする。
     * * Storeからのシグナルを登録する。
     *
     * @memberof AutomaticTransferActionTypeChatComponent
     */
    public ngOnInit() {
        //  申込完了画面を遷移する
        this.store.registerSignalHandler(AutomaticTransferStateSignal.SUCCESS_INSERT_INFO, () => {
            this.modalService.showCompleteModal().subscribe({
                next: (event) => {
                    switch (event) {
                        case COMMON_CONSTANTS.BACK_TYPE_REAPPLY_MENU:
                            this.navCtrl.setRoot(ChatComponent, { reapplyFlg: true });
                            break;
                        default:
                            this.navCtrl.setRoot(TopComponent);
                    }
                },
                complete: () => {
                    this.action.clearStore();
                }
            });
        });
    }

    /**
     * クリーンアップ処理として以下を行う。
     * * `AbstractChatFlowControlComponent`のクリーンアップメソッド(`destoyChatFlowControl`)を実行する。
     * * Storeシグナルの登録を解除する。
     *
     * @memberof AutomaticTransferActionTypeChatComponent
     */
    public ngOnDestroy() {
        this.unregisterSignalHandlers();
    }

    /**
     * 勘定API更新系のリスナーをアンインストールする
     */
    public unregisterSignalHandlers() {
        this.store.unregisterSignalHandler(AutomaticTransferStateSignal.SUCCESS_INSERT_INFO);
    }

    /**
     * 自動振込申込情報の変更
     * @param params 変更情報
     */
    public simplyChange(params: { title: string, editList: any, name: string, startOrder: number, endOrder: number }) {
        // todo
    }

    /**
     * 自動振込-解約情報の変更
     * @param params 変更情報
     */
    public simplyChangeCancel(params: { title: string, editList: any, name: string, startOrder: number, endOrder: number }) {
        // todo
    }

    /**
     * 新規振込の場合を判定する
     */
    public get isTransfer(): boolean {
        return this.state.submitData.registerCategory === AutomaticTransferRegisterCategory.TRANSFER;
    }

    /**
     * データをサブミットする
     */
    public submit() {
        this.submitted = true;
        this.action.saveSubmitData({
            ...HolderAgentInfoUtil.prepareExistReserveSubmitData(this.state),
            userMngNo: this.state.submitData.bankclerkConfirmId,
            // 名義人名を全角カナ→半角カナ（小カナ含む）に変換
            beneficiaryName: StringUtils.convertZankaku2Hankaku(this.state.submitData.beneficiaryName)
        });
        this.logging.saveCustomOperationLog(
            this.labels.logging.AutomaticTransfer.AutomaticConfirmClerkPage.ScreenName,
            this.labels.logging.AccountConfirm.confirmButton,
        );
    }

    /**
     * 前遷移画面を設定する
     */
    public backToInfoConfirmPage() {
        this.isBackToCustomerConfirmPage = true;
        this.clearConfirmPageInfo();
        this.navCtrl.setRoot(AutomaticTransferInitconfirmComponent);
        this.logging.saveCustomOperationLog(
            this.labels.logging.AutomaticTransfer.AutomaticConfirmClerkPage.ScreenName,
            this.labels.logging.AccountConfirm.backConfirmButton,
        );
    }

    /**
     * 申込内容確認へ戻る
     */
    public clearConfirmPageInfo() {
        this.action.clearConfirmPageInfo();
    }

    /**
     * 入力チェック結果を返す
     */
    public get disableFooterButton(): boolean {
        return !this.checkInputValidation();
    }

    /**
     * 顔写真のある本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedEmitter(event?: any) {
        this.insertImageType = event || this.insertImageType;
    }

    /**
     * 顔写真のない本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedNoFaceEmitter(event?: any) {
        this.insertImageTypeNoFace = event || this.insertImageTypeNoFace;
    }

    /**
     * 画面の入力するチェック
     */
    private checkInputValidation(): boolean {
        const submitData = this.state.submitData;

        let validationResult = this.checkIdentityDocumentsValidation();

        if (validationResult && submitData.holderIdentityDocumentNoCopyReason) { // コピー徴求ができない理由
            validationResult = StringUtils.validateZenkaku(submitData.holderIdentityDocumentNoCopyReason);
        }

        if (validationResult && submitData.holderNoCopyReason) { // コピー徴求ができない理由
            validationResult = StringUtils.validateZenkaku(submitData.holderNoCopyReason);
        }

        return validationResult;
    }

    /**
     * 本人確認書類チェック
     */
    private checkIdentityDocumentsValidation(): boolean {
        if (this.state.submitData.holderIdentityDocumentType && !this.submitted) {
            // 顔写真のある本人確認の画像登録
            if (this.state.identityDocuments && this.state.identityDocuments.length > 0) {
                return true;
            }

            // 顔写真のある本人確認のテキスト登録
            if (this.state.submitData.holderNoCopyReason || this.state.submitData.holderPublisher ||
                this.state.submitData.holderPublishDate || this.state.submitData.holderSignNo) {
                return true;
            }

            // 顔写真のない本人確認の画像登録
            if (this.state.additionalInfoDocuments && this.state.additionalInfoDocuments.length > 0) {
                return true;
            }

            // 顔写真のない本人確認のテキスト登録
            if (this.state.submitData.holderIdentityDocumentNoCopyReason || this.state.submitData.holderIdentityDocumentPublisher ||
                this.state.submitData.holderIdentityDocumentPublishDate || this.state.submitData.holderIdentityDocumentSignNo) {
                return true;
            }
        }

        return false;
    }

}
