/**
 * 修正項目
 */
export enum AutomaticTransferConfirmItem {
    /** 振込資金の内容 */
    WireTransferContents = 1,
    /** 引落口座 */
    WithdrawalAccount = 2,
    /** 振込先銀行 */
    TransferDestinationBank = 3,
    /** 毎月振込日 */
    MonthlyTransferDate = 4,
    /** 再振込処理 */
    ReTransferProcess = 5,
    /** 毎月振込金額 */
    MonthlyTransferAmount = 6,
    /** 特定振込月 */
    SpecifiedTransferMonth = 7,
    /** 振込終了年月 */
    TransferEndDate = 8,
    /** 解約 */
    TransferCancel = 9,
    /** 最終振込年月 */
    TransferLastDate = 10,
}
