import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferLoadConfirmYamlTemplate
} from 'dhdt/branch/pages/automatic-transfer/decorator/automatic-transfer-confirm.renderer';
import { AutomaticTransferConfirmItem } from 'dhdt/branch/pages/automatic-transfer/service/automatic-transfer-confirm.item';

/**
 * 修正用サービス
 */
@Injectable()
export class AutomaticTransferConfirmService {
    public static readonly CONFIRM_KEY = Symbol();

    private labels;

    constructor(private action: AutomaticTransferAction, labelService: LabelService) {
        this.labels = labelService.labels;
    }

    /**
     * 修正用データマッピング
     */
    public get confirmParams() {
        const map = new Map();
        // 内容
        map.set(AutomaticTransferConfirmItem.WireTransferContents, {
            startOrder: 140,
            endOrder: 170,
            pageIndex: 1,
            currentTitle: this.labels.automaticTransfer.contentConfirm.wireTransferContents,
            name: 'wireTransferContents',
        });
        // 引落口座
        map.set(AutomaticTransferConfirmItem.WithdrawalAccount, {
            startOrder: 10,
            endOrder: 130,
            pageIndex: 1,
            currentTitle: this.labels.automaticTransfer.contentConfirm.withdrawalAccount,
            name: 'withdrawalAccount',
        });
        // 振込先銀行
        map.set(AutomaticTransferConfirmItem.TransferDestinationBank, {
            startOrder: 10,
            endOrder: 80,
            pageIndex: 2,
            currentTitle: this.labels.automaticTransfer.contentConfirm.transferDestinationBank,
            name: 'transferDestinationBank',
        });
        // 毎月振込日
        map.set(AutomaticTransferConfirmItem.MonthlyTransferDate, {
            startOrder: 10,
            endOrder: 40,
            pageIndex: 3,
            currentTitle: this.labels.automaticTransfer.contentConfirm.monthlyTransferDate,
            name: 'monthlyTransferDate',
        });
        // 再振込処理
        map.set(AutomaticTransferConfirmItem.ReTransferProcess, {
            startOrder: 50,
            endOrder: 50,
            pageIndex: 3,
            currentTitle: this.labels.automaticTransfer.contentConfirm.reTransferProcess,
            name: 'reTransferProcess',
        });
        // 毎月振込金額
        map.set(AutomaticTransferConfirmItem.MonthlyTransferAmount, {
            startOrder: 80,
            endOrder: 130,
            pageIndex: 3,
            currentTitle: this.labels.automaticTransfer.contentConfirm.monthlyTransferAmount,
            name: 'monthlyTransferAmount',
        });
        // 特定振込月
        map.set(AutomaticTransferConfirmItem.SpecifiedTransferMonth, {
            startOrder: 130,
            endOrder: 230,
            pageIndex: 3,
            currentTitle: this.labels.automaticTransfer.contentConfirm.specifiedTransferMonth,
            name: 'specifiedTransferMonth',
        });
        // 振込終了年月
        map.set(AutomaticTransferConfirmItem.TransferEndDate, {
            startOrder: 60,
            endOrder: 70,
            pageIndex: 3,
            currentTitle: this.labels.automaticTransfer.contentConfirm.transferEndDate,
            name: 'transferEndDate',
        });
        // 解約
        map.set(AutomaticTransferConfirmItem.TransferCancel, {
            startOrder: 10,
            endOrder: 132,
            pageIndex: 4,
            currentTitle: this.labels.automaticTransfer.contentConfirm.transferCancel,
            name: 'transferCancel',
        });

        return map;
    }

    /**
     * 修正用テンプレートをロードする
     * @param params パラメーター
     */
    public loadConfirmTemplate(params) {
        const yaml = Reflect.getPrototypeOf(params.renderer).constructor[AutomaticTransferLoadConfirmYamlTemplate];
        if (yaml) {
            this.action.loadConfirmPageTemplate(yaml, params.index);
        }
    }
}
