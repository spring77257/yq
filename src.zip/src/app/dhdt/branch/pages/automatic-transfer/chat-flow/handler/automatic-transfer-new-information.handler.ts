import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferChatFlowQuestionTypes
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/automatic-transfer.chat-flow-question-types';
import {
    AutomaticTransferState, AutomaticTransferStateSignal, AutomaticTransferStore
} from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import {
    AutomaticTransferAccountFlag, AutomaticTransferCommissionType, AutomaticTransferEntityName,
    COMMON_CONSTANTS, CoreBankingConst, CssConsts, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import * as moment from 'moment';
import { Observable } from 'rxjs';

/**
 * `DefaultChatFlowInputHandler`において、自動振込新規申込画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferNewinformationInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class AutomaticTransferNewinformationInputHandler extends DefaultChatFlowInputHandler {

    private state: AutomaticTransferState;

    constructor(private action: AutomaticTransferAction,
                private store: AutomaticTransferStore,
                private labelService: LabelService,
                private deviceService: DeviceService,
                private modalService: ModalService,
                private loginStore: LoginStore) {
        super(action);
        this.state = store.getState();
    }

    @InputHandler([
        AutomaticTransferChatFlowQuestionTypes.DAY_PICKER,
        AutomaticTransferChatFlowQuestionTypes.YEAR_MONTH_PICKER,
        AutomaticTransferChatFlowQuestionTypes.PICKER
    ])
    private onPickerHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({
            text: answer.text,
            value: answer.value
        });

        switch (entity.name) {
            case SubmitDataKey.MONTHLY_TRANSFER_DATE:
                this.action.setStateSubmitDataValue({
                    name: SubmitDataKey.MONTHLY_TRANSFER_DATE,
                    value: this.state.submitData.monthlyTransferDate.replace(/^([0-9]{1})$/, '0$1')
                });
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
                break;
            case SubmitDataKey.SPECIFIED_TRANSFER_MONTH_1:
                // 特定振込月と振込終了年月の相関バリデーション
                if (!this.checkSpecifiedTransferMonth()) {
                    this.showWarningMessage(this.labelService.labels.automaticTransfer.message.specifiedTransferMonthError);
                } else {
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                }
                break;
            case SubmitDataKey.SPECIFIED_TRANSFER_MONTH_2:
                // 特定月が重複のことをチェック
                if (this.state.submitData.specifiedTransferMonth2 === this.state.submitData.specifiedTransferMonth1) {
                    this.showWarningMessage(this.labelService.labels.automaticTransfer.message.selectSameMonth);
                } else if (!this.checkSpecifiedTransferMonth()) {
                    this.showWarningMessage(this.labelService.labels.automaticTransfer.message.specifiedTransferMonthError);
                } else {
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                }
                break;
            case SubmitDataKey.TRANSFER_START_DATE:
                if (this.diffSystemDate({
                    month: this.state.submitData.transferStartDate,
                    day: this.state.submitData.monthlyTransferDate,
                    unit: COMMON_CONSTANTS.DATE_DAY
                }) < 0) {
                    this.showWarningMessage(this.labelService.labels.automaticTransfer.errorMessage.isBeforeSystemDate);
                } else if (this.diffSystemDate({
                    month: this.state.submitData.transferStartDate,
                    day: this.state.submitData.monthlyTransferDate,
                    unit: COMMON_CONSTANTS.DATE_MONTH
                }) > 6) {
                    this.showWarningMessage(this.labelService.labels.automaticTransfer.errorMessage.isAfterSixMonths);
                } else if (this.transferStartDateIsAfterEndDate()) {
                    this.showWarningMessage(this.labelService.labels.automaticTransfer.errorMessage.isAfterEndDate);
                } else if (!this.checkSpecifiedTransferMonth()) {
                    this.showWarningMessage(this.labelService.labels.automaticTransfer.message.specifiedTransferMonthError);
                } else {
                    // 本日より3営業日以内をチェック
                    this.checkBusinessDay().subscribe((result) => {
                        if (result) {
                            this.emitMessageRetrivalEvent(entity.next, pageIndex);
                        } else {
                            this.showWarningMessage(this.labelService.labels.automaticTransfer.errorMessage.checkBusinessDayFailed);
                        }
                    });
                }
                break;
            case SubmitDataKey.TRANSFER_END_DATE:
                if (this.state.submitData.transferStartDate >= this.state.submitData.transferEndDate) {
                    this.showWarningMessage(this.labelService.labels.automaticTransfer.errorMessage.isBeforeStartDate);
                } else if (!this.checkSpecifiedTransferMonth()) {
                    this.showWarningMessage(this.labelService.labels.automaticTransfer.message.specifiedTransferMonthError);
                } else {
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                }
                break;
            default:
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    @InputHandler([
        AutomaticTransferChatFlowQuestionTypes.BUTTON,
        AutomaticTransferChatFlowQuestionTypes.BUTTON_THREE_COLS
    ])
    private onButtonHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({
            text: answer.text,
            value: entity.name.length > 0 ? [{ key: entity.name, value: answer.value }] : undefined
        });
        if (answer.next !== -1) {
            // 振込終了年月を指定しなければ、平成99年12月を振込終了年月に設定
            if (answer.action && answer.action.type === SubmitDataKey.TRANSFER_END_DATE) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: SubmitDataKey.TRANSFER_END_DATE, value: answer.action.value }
                    ]
                });
            } else if (entity.name === AutomaticTransferEntityName.SPECIFIED_TRANSFER_MONTH_SECLECT) {
                this.action.clearSpecifiedTransfer();
            }
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(AutomaticTransferChatFlowQuestionTypes.DEPOSIT_INPUT)
    private onDepositInputHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        this.setAnswer(answer);
        // 手数料は「0」を格納
        entity.choices.forEach((choice) => this.action.setExchangeFee(choice.name, AutomaticTransferCommissionType.EXCHANGE_FREE));
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    /**
     * Show warn modal
     * @param message message
     */
    private showWarningMessage(message) {
        const buttonList = [
            { text: 'OK', buttonValue: 'ok' },
        ];
        this.modalService.showWarnAlert(
            message,
            buttonList,
            null,
            null,
            CssConsts.CSS_CLASS_WARNING_MODAL
        );
    }

    /**
     * システム日付と比較
     */
    private diffSystemDate(param) {
        switch (param.unit) {
            case COMMON_CONSTANTS.DATE_DAY:
                const end = moment(param.month, COMMON_CONSTANTS.DATE_FORMAT_YYYYMM).endOf(COMMON_CONSTANTS.DATE_MONTH).date();
                const date = param.month + (end > param.day ? param.day : end);

                return moment(date, COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD)
                    .diff(moment(this.state.submitData.customerApplyStartDate), COMMON_CONSTANTS.DATE_DAY);
            case COMMON_CONSTANTS.DATE_MONTH:
                return moment(param.month, COMMON_CONSTANTS.DATE_FORMAT_YYYYMM)
                    .diff(moment(this.state.submitData.customerApplyStartDate).startOf(COMMON_CONSTANTS.DATE_MONTH),
                        COMMON_CONSTANTS.DATE_MONTH);
        }
    }

    /**
     * 振込開始年月が振込終了年月以降かをチェック
     */
    private transferStartDateIsAfterEndDate() {
        if (this.state.submitData.transferEndDate) {
            return this.state.submitData.transferStartDate >= this.state.submitData.transferEndDate;
        }
        return false;
    }

    /**
     * 特定振込月と振込終了年月の相関バリデーション
     */
    private checkSpecifiedTransferMonth() {
        if (this.state.submitData.transferStartDate && this.state.submitData.transferEndDate) {
            // 振込終了年月が指定しない場合は、バリデーションチェック実行しない
            if (this.state.submitData.transferEndDate === COMMON_CONSTANTS.AUTOMATIC_TRANSFER_DEFAULT_END_DATE) {
                return true;
            }
            // 特定振込月が指定された場合は、バリデーションチェック実行
            if (this.state.submitData.specifiedTransferMonth1 || this.state.submitData.specifiedTransferMonth2) {
                // 振込開始年を取得
                const startYear = this.state.submitData.transferStartDate.substring(0, 4);
                // 振込終了年を取得
                const endYear = this.state.submitData.transferEndDate.substring(0, 4);
                // 振込終了年ー振込開始年＞1の場合、バリデーションチェック実行しない
                if (Number(endYear) - Number(startYear) <= 1) {
                    const check = (specifiedTransferMonth) => {
                        // 最小の特定振込年月
                        const min = startYear + specifiedTransferMonth;
                        // 最大の特定振込年月
                        const max = endYear + specifiedTransferMonth;
                        if (min >= this.state.submitData.transferStartDate && min <= this.state.submitData.transferEndDate) {
                            return true;
                        } else if (max >= this.state.submitData.transferStartDate && max <= this.state.submitData.transferEndDate) {
                            return true;
                        } else {
                            return false;
                        }
                    };
                    // 特定振込月①が選択された場合、チェック実行
                    if (this.state.submitData.specifiedTransferMonth1 && !check(this.state.submitData.specifiedTransferMonth1)) {
                        return false;
                    }
                    // 特定振込月②が選択された場合、チェック実行
                    if (this.state.submitData.specifiedTransferMonth2 && !check(this.state.submitData.specifiedTransferMonth2)) {
                        return false;
                    }
                    return true;
                }
            }
        }
        return true;
    }

    /**
     * 営業日をチェック
     */
    private checkBusinessDay(): Observable<boolean> {
        return Observable.create((observe) => {
            this.action.checkBusinessDay({
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                baseDate: moment(this.state.submitData.customerApplyStartDate).format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD),
                transferStartMonth: this.state.submitData.transferStartDate,
                transferDay: this.state.submitData.monthlyTransferDate,
                pastFuture: this.state.submitData.handlingHolidays === AutomaticTransferAccountFlag.HANDLING_PER_DAY ?
                    AutomaticTransferAccountFlag.BUSINESS_PER_DAY : AutomaticTransferAccountFlag.BUSINESS_NEXT_DAY,
                tabletApplyId: this.state.submitData.tabletApplyId,
                userMngNo: this.loginStore.getState().bankclerkId,
            });
            this.store.registerSignalHandler(AutomaticTransferStateSignal.CHECK_BUSINESS_DAY, (data) => {
                this.store.unregisterSignalHandler(AutomaticTransferStateSignal.CHECK_BUSINESS_DAY);
                observe.next(data && data.result);
                observe.complete();
            });
        });
    }
}
