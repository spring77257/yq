import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferChatFlowQuestionTypes
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/automatic-transfer.chat-flow-question-types';
import {
    AutomaticTransferNewApplyInputHandler
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/handler/automatic-transfer-new-apply.handler';
import {　AutomaticTransferConfirmRenderer　} from 'dhdt/branch/pages/automatic-transfer/decorator/automatic-transfer-confirm.renderer';
import {
    AutomaticTransferState, AutomaticTransferStateSignal, AutomaticTransferStore
} from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import {
    AutomaticTransferAccountFlag, AutomaticTransferCommissionType, AutomaticTransferEntityName,
    AutomaticTransferStudentDepositType, COMMON_CONSTANTS, CoreBankingConst, CssConsts, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { TableViewComponent } from 'dhdt/branch/shared/components/table-view/table-view.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

export const AUTOMATIC_TRANSFER_NEW_APPLY_RENDERER_TYPE = 'AutomaticTransferNewApplyRenderer';

/**
 * `DefaultChatFlowRenderer`において、自動振込新規申込画面に利用できるRendererを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferNewApplyRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: AUTOMATIC_TRANSFER_NEW_APPLY_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-automatic-transfer-new-apply.yml'
})
@AutomaticTransferConfirmRenderer({
    templateYaml: 'chat-flow-def-automatic-transfer-new-apply-confirmpage.yml'
})
export class AutomaticTransferNewApplyRenderer extends DefaultChatFlowRenderer {
    public processType: number = COMMON_CONSTANTS.ProcessType.RequiredInput;
    protected userAnswers: any;

    private state: AutomaticTransferState;

    constructor(private labelService: LabelService,
                private loginStore: LoginStore,
                private action: AutomaticTransferAction,
                private store: AutomaticTransferStore,
                private deviceService: DeviceService,
                inputHandler: AutomaticTransferNewApplyInputHandler) {
        super(action, inputHandler);

        this.state = this.store.getState();
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.JUDGE)
    private onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        switch (entity.name) {
            case AutomaticTransferEntityName.WITHDRAWAL_ACCOUNT:
                this.getAccountWithoutCard(entity, pageIndex);
                break;
            case SubmitDataKey.HANDLING_FEE:
                this.getHandlingFee(entity, pageIndex);
                break;
            case AutomaticTransferEntityName.WITHDRAWAL_FEE:
                this.getWithdrawalFee(entity, pageIndex);
                break;
        }
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.ACCOUNT_SHOP)
    private onTransferAccountList(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer([
        AutomaticTransferChatFlowQuestionTypes.BUTTON,
        AutomaticTransferChatFlowQuestionTypes.BUTTON_THREE_COLS
    ])
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            maxColNum: (entity.type === AutomaticTransferChatFlowQuestionTypes.BUTTON_THREE_COLS) ? 3 : undefined,
        };
        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.OTHER_ACCOUNTS_LIST)
    private onOtherAccountList(entity: ChatFlowMessageInterface, pageIndex: number) {
        const titleForHeader = [
            this.labelService.labels.commonAccount.confirm.dealer,
            this.labelService.labels.commonAccount.confirm.transactionKind,
            this.labelService.labels.confirm.product.branchNo
        ];
        const options = {
            logInfo: entity.options.logInfo,
            delegate: {
                columns: 3,
                rows: this.state.otherAccountsList.length,
                cssClass: CssConsts.CSS_CLASS_TABLE_VIEW_WIDTH,
                dataSource: this.state.otherAccountsList,
                titleForHeaderInColumn(column: number) {
                    return titleForHeader[column];
                },
                itemAtIndex(row: number, column: number) {
                    switch (column) {
                        case 0:
                            return [{ title: this.dataSource[row].branchName, cssClass: CssConsts.CSS_CLASS_TABLE_ITEM_FONT_20 }];
                        case 1:
                            return [{ title: this.dataSource[row].accountTypeData, cssClass: CssConsts.CSS_CLASS_TABLE_ITEM_FONT_20 }];
                        case 2:
                            return [{ title: this.dataSource[row].accountNo, cssClass: CssConsts.CSS_CLASS_TABLE_ITEM_FONT_20 }];
                    }
                },
                canSelectRow(row: number) {
                    return true;
                },
                didSelectRow(row: number) {
                    return this.dataSource[row];
                }
            }
        };
        this.emitRenderEvent({
            class: TableViewComponent,
            data: undefined,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.KEYBOARD)
    private onKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: entity.options,
        }, entity, pageIndex);
    }

    /**
     * 口座情報照会(自動振込)を取得
     */
    private getAccountWithoutCard(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.action.getAccountWithoutCard({
            accountNo: this.state.submitData.accountNo,
            tabletApplyId: this.state.submitData.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            cifInfo: this.state.cifInfo,
            swipeBranchNo: this.state.submitData.swipeBranchNo
        });
        this.store.registerSignalHandler(AutomaticTransferStateSignal.GET_ACCOUNT_WITHOUT_CARD, (info) => {
            this.store.unregisterSignalHandler(AutomaticTransferStateSignal.GET_ACCOUNT_WITHOUT_CARD);

            if (entity.choices) {
                for (const choice of entity.choices) {
                    const flag = (info && info.length > 0) ? AutomaticTransferAccountFlag.OTHER : AutomaticTransferAccountFlag.CURRENT;
                    if (choice.value === flag) {
                        return this.emitMessageRetrivalEvent(choice.next, pageIndex);
                    }
                }
            }
        });
    }

    /**
     * 取扱手数料を取得
     */
    private getHandlingFee(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.action.getTransferFee({
            bankNo: CoreBankingConst.bankNo,
            terminalNo: this.deviceService.getDeviceId(),
            commissionType: AutomaticTransferCommissionType.HANDLING,
            userMngNo: this.loginStore.getState().bankclerkId,
            tabletApplyId: this.state.submitData.tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
        }, SubmitDataKey.HANDLING_FEE);
        this.store.registerSignalHandler(AutomaticTransferStateSignal.GET_TRANSFER_FEE, () => {
            this.store.unregisterSignalHandler(AutomaticTransferStateSignal.GET_TRANSFER_FEE);
            return this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
    }

    /**
     * 毎月振込額と特定の月の振込金額に発生する振込手数料を取得
     */
    private getWithdrawalFee(entity: ChatFlowMessageInterface, pageIndex: number) {
        const params = {
            bankNo: CoreBankingConst.bankNo,
            terminalNo: this.deviceService.getDeviceId(),
            commissionType: AutomaticTransferCommissionType.TRANSFER,
            userMngNo: this.loginStore.getState().bankclerkId,
            tabletApplyId: this.state.submitData.tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            withdrawalBranchNo: this.state.submitData.withdrawalBranchNo,
            transferDestinationBankCode: this.state.submitData.transferDestinationBankCode,
            transferDestinationBranchCode: this.state.submitData.transferDestinationBranchCode
        };
        this.store.registerSignalHandler(AutomaticTransferStateSignal.GET_WITHDRAWAL_FEE, () => {
            this.store.unregisterSignalHandler(AutomaticTransferStateSignal.GET_WITHDRAWAL_FEE);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
        this.action.getWithdrawalFee({
            params,
            amounts: [
                {
                    key: SubmitDataKey.MONTHLY_EXCHANGE_FEE,
                    amount: this.state.submitData.monthlyTransferAmount
                }, {
                    key: SubmitDataKey.SPECIFIED_EXCHANGE_FEE_1,
                    amount: this.state.submitData.specifiedTransferAmount1
                }, {
                    key: SubmitDataKey.SPECIFIED_EXCHANGE_FEE_2,
                    amount: this.state.submitData.specifiedTransferAmount2
                }
            ],
            isStudent: this.state.studentAccountType === AutomaticTransferStudentDepositType.STUDENT
        });
    }
}
