import { Injectable } from '@angular/core';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferChatFlowQuestionTypes
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/automatic-transfer.chat-flow-question-types';
import {
    AutomaticTransferState, AutomaticTransferStore
} from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import { COMMON_CONSTANTS, SubmitDataKey } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';

/**
 * `DefaultChatFlowInputHandler`において、自動振込新規申込画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferNewApplyInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class AutomaticTransferNewApplyInputHandler extends DefaultChatFlowInputHandler {

    constructor(private action: AutomaticTransferAction) {
        super(action);
    }

    @InputHandler([
        AutomaticTransferChatFlowQuestionTypes.BUTTON,
        AutomaticTransferChatFlowQuestionTypes.BUTTON_THREE_COLS
    ])
    private onButtonHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({
            text: answer.text,
            value: entity.name.length > 0 ? [{ key: entity.name, value: answer.value }] : undefined
        });

        if (answer.action) {
            this.configAction(entity, answer, pageIndex);
        } else {
            this.configEntityHandler(entity, answer, pageIndex);
        }

        if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(AutomaticTransferChatFlowQuestionTypes.OTHER_ACCOUNTS_LIST)
    private onOtherAccountListHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({
            text: answer.branchName + COMMON_CONSTANTS.FULL_SPACE + answer.accountTypeData + COMMON_CONSTANTS.FULL_SPACE + answer.accountNo,
            value: [
                {
                    key: SubmitDataKey.WITHDRAWAL_BRANCH_NO, value: answer.branchNo
                }, {
                    key: SubmitDataKey.WITHDRAWAL_BRANCH_NAME, value: answer.branchName
                }, {
                    key: SubmitDataKey.WITHDRAWAL_ACCOUNT_ITEM, value: answer.accountType,
                }, {
                    key: SubmitDataKey.WITHDRAWAL_ACCOUNT_NO, value: answer.accountNo
                }
            ]
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(AutomaticTransferChatFlowQuestionTypes.KEYBOARD)
    private onKeyboardHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        // 振込資金の内容（その他）は未入力場合は「ｿｳｷﾝ」を設定
        let text: string = answer.text.length > 0 ? answer.text : COMMON_CONSTANTS.AUTOMATIC_TRANSFER_CONTENT_DEFAULT_OTHER;

        if (entity.name === SubmitDataKey.KANA_DETAIL) {
            const choice = entity.choices.find((item) => item.name === SubmitDataKey.KANA_DETAIL);
            if (choice && answer.text.length > choice.validationRules.max) {
                text = text.substring(0, choice.validationRules.max);
            }
        }
        this.setAnswer({
            text: text,
            value: [
                { key: entity.name, value: text }
            ]
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    /**
     * アクション判定
     * @param entity ChatFlowのYamlTemplateから送られてくるデータ
     * @param answer ユーザからの回答
     * @param pageIndex ページ番号
     */
    private configAction(entity: ChatFlowMessageInterface, answer: any, pageIndex: number) {
        switch (answer.action.type) {
            case COMMON_CONSTANTS.ACTION_TYPE_ROUTE:
                this.chatFlowCompelete(answer.action.value);
                break;
            case COMMON_CONSTANTS.ELEMENT_TYPE_ACCOUNTSHOP:
                // 「この口座を設定する」ボタンを押すと、スワイプ店の情報を申込人引落情報に設定
                this.action.setSwipeCardToWithdrawalAccount();
                break;
        }
    }

    /**
     * ChatFlowのハンドラ判定
     * @param entity ChatFlowのYamlTemplateから送られてくるデータ
     * @param answer ユーザからの回答
     * @param pageIndex ページ番号
     */
    private configEntityHandler(entity: ChatFlowMessageInterface, answer: any, pageIndex: number) {
        switch (entity.name) {
            case SubmitDataKey.WIRE_TRANSFER_CONTENTS:
                this.action.clearKanaDetail();
                break;
        }
    }
}
