import { Injectable } from '@angular/core';
import { DeviceService } from 'dhd/common/services/device.service';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferChatFlowQuestionTypes
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/automatic-transfer.chat-flow-question-types';
import {
    AutomaticTransferNewRecipientInputHandler
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/handler/automatic-transfer-new-recipient.handler';
import {　AutomaticTransferConfirmRenderer　} from 'dhdt/branch/pages/automatic-transfer/decorator/automatic-transfer-confirm.renderer';
import {
    AutomaticTransferState, AutomaticTransferStateSignal, AutomaticTransferStore
} from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import {
    AutomaticTransferAccountFlag, AutomaticTransferCommissionType, AutomaticTransferEntityName,
    AutomaticTransferStudentDepositType, COMMON_CONSTANTS, CoreBankingConst, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

export const AUTOMATIC_TRANSFER_NEW_RECIPIENT_RENDERER_TYPE = 'AutomaticTransferNewRecipientRenderer';

/**
 * `DefaultChatFlowRenderer`において、自動振込新規申込画面に利用できるRendererを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferNewRecipientRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: AUTOMATIC_TRANSFER_NEW_RECIPIENT_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-automatic-transfer-new-recipient.yml'
})
@AutomaticTransferConfirmRenderer({
    templateYaml: 'chat-flow-def-automatic-transfer-new-recipient-confirmpage.yml'
})
export class AutomaticTransferNewRecipientRenderer extends DefaultChatFlowRenderer {
    public processType: number = COMMON_CONSTANTS.ProcessType.RequiredInput;
    protected userAnswers: any;

    private state: AutomaticTransferState;

    constructor(private action: AutomaticTransferAction,
                private store: AutomaticTransferStore,
                private deviceService: DeviceService,
                private loginStore: LoginStore,
                inputHandler: AutomaticTransferNewRecipientInputHandler) {
        super(action, inputHandler);

        this.state = store.getState();
    }

    @Renderer([
        AutomaticTransferChatFlowQuestionTypes.BUTTON,
        AutomaticTransferChatFlowQuestionTypes.BUTTON_THREE_COLS
    ])
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            maxColNum: (entity.type === AutomaticTransferChatFlowQuestionTypes.BUTTON_THREE_COLS) ? 3 : undefined,
        };
        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.NUMBER_KEYBORD)
    private onNumberKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: NumberInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.KEYBOARD)
    private onKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            title: entity.options.title,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            defaultValues:
                entity.name === SubmitDataKey.BENEFICIARY_NAME ? [this.state.submitData.beneficiaryName] : undefined
        };

        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.JUDGE)
    private onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // 振込先銀行を修正した後で、毎月の振込金額手数料と特定の月の振込金額手数料を再計算
        if (entity.name === AutomaticTransferEntityName.WITHDRAWAL_FEE) {
            const params = {
                bankNo: CoreBankingConst.bankNo,
                terminalNo: this.deviceService.getDeviceId(),
                commissionType: AutomaticTransferCommissionType.TRANSFER,
                userMngNo: this.loginStore.getState().bankclerkId,
                tabletApplyId: this.state.submitData.tabletApplyId,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                withdrawalBranchNo: this.state.submitData.withdrawalBranchNo,
                transferDestinationBankCode: this.state.submitData.transferDestinationBankCode,
                transferDestinationBranchCode: this.state.submitData.transferDestinationBranchCode
            };
            this.store.registerSignalHandler(AutomaticTransferStateSignal.GET_WITHDRAWAL_FEE, () => {
                this.store.unregisterSignalHandler(AutomaticTransferStateSignal.GET_WITHDRAWAL_FEE);
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            });
            this.action.getWithdrawalFee({
                params,
                amounts: [
                    {
                        key: SubmitDataKey.MONTHLY_EXCHANGE_FEE,
                        amount: this.state.submitData.monthlyTransferAmount
                    }, {
                        key: SubmitDataKey.SPECIFIED_EXCHANGE_FEE_1,
                        amount: this.state.submitData.specifiedTransferAmount1
                    }, {
                        key: SubmitDataKey.SPECIFIED_EXCHANGE_FEE_2,
                        amount: this.state.submitData.specifiedTransferAmount2
                    }
                ],
                isStudent: this.state.studentAccountType === AutomaticTransferStudentDepositType.STUDENT
            });
        } else if (entity.name === AutomaticTransferEntityName.CHECK_IYO_BANK) {
            const choice = entity.choices.find((item) => {
                if (this.action.checkBankIsIyoBank(this.state.submitData.transferDestinationBank)) {
                    return item.value === AutomaticTransferAccountFlag.IYO_BANK;
                } else {
                    return item.value === AutomaticTransferAccountFlag.OTHER_BANK;
                }
            });
            if (choice) {
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
            }
        }
    }
}
