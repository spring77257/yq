import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferChatFlowQuestionTypes
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/automatic-transfer.chat-flow-question-types';
import { AutomaticTransferState, AutomaticTransferStore } from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import {
    COMMON_CONSTANTS, CssConsts, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import * as moment from 'moment';

/**
 * `DefaultChatFlowInputHandler`において、自動振込解約画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferCancelInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class AutomaticTransferCancelInputHandler extends DefaultChatFlowInputHandler {
    private state: AutomaticTransferState;

    constructor(private action: AutomaticTransferAction,
                private store: AutomaticTransferStore,
                private audioService: AudioService,
                private modalService: ModalService,
                private labelService: LabelService) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(AutomaticTransferChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({
            text: answer.text,
            value: entity.name.length > 0 ? [{ key: entity.name, value: answer.value }] : undefined
        });

        if (answer.action && answer.action.type.length > 0) {
            this.configAction(entity, answer, pageIndex);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(AutomaticTransferChatFlowQuestionTypes.TRANSFER_CANCEL_LIST)
    private onTransferCancelListHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({ text: answer.text, value: [] });
        this.action.setTransferCancelInfo(answer.value);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler([
        AutomaticTransferChatFlowQuestionTypes.DAY_PICKER,
        AutomaticTransferChatFlowQuestionTypes.YEAR_MONTH_PICKER
    ])
    private onPickerHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({
            text: answer.text,
            value: answer.value
        });

        if (entity.name === SubmitDataKey.TRANSFER_LAST_DATE) {
            const isBefore = moment(this.state.submitData.transferLastDate, COMMON_CONSTANTS.DATE_FORMAT_YYYYMM)
                .isBefore(moment(this.state.submitData.customerApplyStartDate));
            if (isBefore) {
                const buttonList = [
                    { text: 'OK', buttonValue: 'ok' },
                ];
                return this.modalService.showWarnAlert(
                    this.labelService.labels.automaticTransfer.errorMessage.checkLastDayFailed,
                    buttonList,
                    null,
                    null,
                    CssConsts.CSS_CLASS_WARNING_MODAL
                );
            }
        }

        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    /**
     * アクション判定
     * @param choice ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    private configAction(entity: ChatFlowMessageInterface, answer: any, pageIndex: number) {
        const action = answer.action;
        switch (action.type) {
            case COMMON_CONSTANTS.ACTION_TYPE_MODAL:
                if (action.value === COMMON_CONSTANTS.ACTION_TYPE_AUTHENTICATION) {
                    this.audioService.audioSubject.next(true);
                    this.action.editAnswer(entity.order, pageIndex, answer.order);
                    this.emitMessageRetrivalEvent(entity.order, pageIndex);
                }
                break;
            case COMMON_CONSTANTS.ACTION_TYPE_ROUTE:
                this.chatFlowCompelete(action.value);
                break;
            case COMMON_CONSTANTS.ACTION_TYPE_ADMIN:
                this.audioService.subject.next(true);
                this.chatFlowCompelete();
                break;
        }
    }
}
