import { ChatFlowQuestionTypes } from 'dhdt/branch/shared/modules/chat-flow/chat-flow-question-types';

/**
 * `ChatFlowQuestionTypes`において、自動振込画面に利用できるQuestionTypeを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferChatFlowQuestionTypes
 * @extends {ChatFlowQuestionTypes}
 */
export class AutomaticTransferChatFlowQuestionTypes extends ChatFlowQuestionTypes {
    public static readonly NEED_PASSWORD = 'needpassword';
    public static readonly BUTTON_THREE_COLS = 'buttonThreeCols';
    public static readonly ACCOUNT_SHOP = 'accountshop';
    public static readonly DEPOSIT_INPUT = 'numberThousand';
    public static readonly OTHER_ACCOUNTS_LIST = 'otherAccountsList';
    public static readonly DAY_PICKER = 'daypicker';
    public static readonly YEAR_MONTH_PICKER = 'yearMonthPicker';
    public static readonly PICKER = 'picker';
    public static readonly TRANSFER_CANCEL_LIST = 'transferCancelList';
    public static readonly AGREED_MODAL = 'agreedModal';
}
