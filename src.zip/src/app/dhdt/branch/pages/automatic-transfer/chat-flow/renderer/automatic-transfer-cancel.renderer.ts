import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferChatFlowQuestionTypes
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/automatic-transfer.chat-flow-question-types';
import {
    AutomaticTransferCancelInputHandler
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/handler/automatic-transfer-cancel.handler';
import {　AutomaticTransferConfirmRenderer　} from 'dhdt/branch/pages/automatic-transfer/decorator/automatic-transfer-confirm.renderer';
import {
    AutomaticTransferState, AutomaticTransferStateSignal, AutomaticTransferStore
} from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import { AutomaticTransferInitconfirmComponent } from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-initconfirm.component';
import {
    AutomaticTransferAccountFlag, AutomaticTransferAccountItem, AutomaticTransferEntityName, COMMON_CONSTANTS, CssConsts
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import {
    TableViewComponent, TableViewDelegate, TableViewItemInterface
} from 'dhdt/branch/shared/components/table-view/table-view.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { App, NavController } from 'ionic-angular';
import * as moment from 'moment';
import { Observable } from 'rxjs';

export const AUTOMATIC_TRANSFER_CANCEL_RENDERER_TYPE = 'AutomaticTransferCancelRenderer';

/**
 * `DefaultChatFlowRenderer`において、自動振込解約画面に利用できるRendererを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferCancelRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: AUTOMATIC_TRANSFER_CANCEL_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-automatic-transfer-cancel.yml'
})
@AutomaticTransferConfirmRenderer({
    templateYaml: 'chat-flow-def-automatic-transfer-cancel-confirmpage.yml'
})
export class AutomaticTransferCancelRenderer extends DefaultChatFlowRenderer implements TableViewDelegate {
    public processType: number = COMMON_CONSTANTS.ProcessType.RequiredInput;
    protected userAnswers: any;

    private state: AutomaticTransferState;
    private labels;
    private navCtrl: NavController;

    constructor(private labelService: LabelService,
                private loginStore: LoginStore,
                private action: AutomaticTransferAction,
                private store: AutomaticTransferStore,
                app: App,
                inputHandler: AutomaticTransferCancelInputHandler) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.labels = this.labelService.labels;
        this.navCtrl = app.getActiveNavs()[0];
    }

    /**
     * 契約中の自動振込一覧のheader部分を指定
     */
    public get titleForHeader() {
        return [
            this.labels.automaticTransfer.cancel.contentsOfTransferFund,
            this.labels.automaticTransfer.cancel.beneficiaryNameKana,
            this.labels.automaticTransfer.cancel.transferDestinationAccount,
            this.labels.automaticTransfer.cancel.withdrawalAccount,
            this.labels.automaticTransfer.cancel.monthlyTransferInfo,
            this.labels.automaticTransfer.cancel.specifiedTransferInfo1,
            this.labels.automaticTransfer.cancel.specifiedTransferInfo2,
            this.labels.automaticTransfer.cancel.transferEndDate
        ];
    }

    /**
     * Tableの列を制御
     */
    public get columns(): number {
        return this.titleForHeader.length;
    }

    /**
     * Tableの行を制御
     */
    public get rows(): number {
        return this.state.transferCancelList.length;
    }

    /**
     * Tableの行数表示可
     */
    public get isShowLineNumbers(): boolean {
        return true;
    }

    /**
     * columnで、Header部分のタイトルを取得
     */
    public titleForHeaderInColumn(column: number): string {
        return this.titleForHeader[column];
    }

    /**
     * rowとcolumnで、項目を取得
     */
    public itemAtIndex(row: number, column: number): TableViewItemInterface[] {
        const info = this.state.transferCancelList[row];
        switch (column) {
            case 0:
                if (info.contentsOfTransferFund === AutomaticTransferAccountFlag.OTHER_FUND) {
                    return [{
                        title: this.contentsOfTransferFundText(info.contentsOfTransferFund)
                    }, {
                        title: StringUtils.convertHankaku2Zankaku(info.summaryKana), cssClass: CssConsts.CSS_CLASS_TABLE_ITEM_FONT_14
                    }];
                } else {
                    return [{ title: this.contentsOfTransferFundText(info.contentsOfTransferFund) }];
                }
            case 1:
                // 受取人名（カナ）
                return [{ title: StringUtils.convertHankaku2Zankaku(info.beneficiaryNameKana) }];
            case 2:
                // 振込先銀行口座
                return [
                    { title: info.transferDestinationBankKana },
                    { title: info.transferDestinationBranchKana },
                    { title: this.contentsOfAccountInfo(info.receivedAccountNo, info.receivedAccountType) }
                ];
            case 3:
                // 引落指定預金口座
                return [
                    { title: info.withdrawalBankName },
                    { title: info.withdrawalBranchName || info.withdrawalBranchNo },
                    { title: this.contentsOfAccountInfo(info.withdrawalAccountNo, info.withdrawalAccountType) }
                ];
            case 4:
                // 毎月振込日/振込額
                return [
                    {
                        title: info.monthlyTransferDate.replace(/^0([1-9]{1})$/, '$1') + this.labels.common.day,
                        cssClass: CssConsts.CSS_CLASS_TABLE_ITEM_RIGHT
                    },
                    {
                        title: InputUtils.priceChange(info.monthlyTransferAmount) + this.labels.unit.normal,
                    },
                ];
            case 5:
                // 特定振込月/金額 ①
                if (info.specifiedTransferMonth1 && info.specifiedTransferAmount1) {
                    return [
                        {
                            title: this.transformMonth(info.specifiedTransferMonth1),
                        },
                        {
                            title: InputUtils.priceChange(info.specifiedTransferAmount1) + this.labels.unit.normal,
                        },
                    ];
                } else if (info.specifiedTransferMonth1) {
                    return [
                        { title: info.specifiedTransferMonth1 + this.labels.common.month, cssClass: CssConsts.CSS_CLASS_TABLE_ITEM_RIGHT }
                    ];
                }
                return [{ title: COMMON_CONSTANTS.HALF_HYPHEN, cssClass: CssConsts.CSS_CLASS_TABLE_ITEM_RIGHT }];
            case 6:
                // 特定振込月/金額 ②
                if (info.specifiedTransferMonth2 && info.specifiedTransferAmount2) {
                    return [
                        {
                            title: this.transformMonth(info.specifiedTransferMonth2),
                        },
                        {
                            title: InputUtils.priceChange(info.specifiedTransferAmount2) + this.labels.unit.normal,
                        },
                    ];
                } else if (info.specifiedTransferMonth2) {
                    return [
                        { title: info.specifiedTransferMonth2 + this.labels.common.month, cssClass: CssConsts.CSS_CLASS_TABLE_ITEM_RIGHT }
                    ];
                }
                return [{ title: COMMON_CONSTANTS.HALF_HYPHEN, cssClass: CssConsts.CSS_CLASS_TABLE_ITEM_RIGHT }];
            case 7:
                // 振込終了年月
                if (info.transferEndDate) {
                    // 振込終了年月を指定していなければ、「-」を表示
                    return [{
                        title: info.transferEndDate === COMMON_CONSTANTS.AUTOMATIC_TRANSFER_DEFAULT_END_DATE ?
                            COMMON_CONSTANTS.HALF_HYPHEN : moment(info.transferEndDate, COMMON_CONSTANTS.DATE_FORMAT_YYYYMM)
                                .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_SPRIT)
                    }];
                }
                return [{ title: COMMON_CONSTANTS.HALF_HYPHEN }];
        }
    }

    /**
     * 行を選択可を制御
     */
    public canSelectRow(row: number): boolean {
        return this.state.transferCancelList[row].selectFlag === AutomaticTransferAccountFlag.CAN_SELECT;
    }

    /**
     * 行を選択された時に呼び出さ、選択されたデータを返却
     */
    public didSelectRow(row: number) {
        return {
            text: this.transformChatMessageForTransferBankInfo(row, this.state.transferCancelList[row]),
            index: row,
            value: this.state.transferCancelList[row]
        };
    }

    /**
     * columnのcssを定義
     */
    public cssClassForColumn(column: number) {
        switch (column) {
            case 2:
                return CssConsts.CSS_CLASS_TABLE_TRANSFER_BANK;
            case 4:
            case 5:
            case 6:
                return CssConsts.CSS_CLASS_TABLE_ITEM_RIGHT;
            default:
                return null;
        }
    }

    /**
     * 行を選択された時に呼び出さ、chat flowに表示されたメッセージを返却
     * @param index 行数
     * @param info　選択された解約情報
     */
    private transformChatMessageForTransferBankInfo(index, info) {
        return index + 1 + COMMON_CONSTANTS.HALF_POINT + this.getTransferCancelAccountMessage(info);
    }

    /**
     * 月テストを取得
     * @param month 月データ
     */
    private transformMonth(month) {
        return month.replace(/^0([1-9]{1})$/, '$1') + this.labels.common.month;
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.TRANSFER_CANCEL_LIST)
    private onTransferCancelList(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.emitRenderEvent({
            class: TableViewComponent,
            data: undefined,
            options: {
                delegate: this,
                logInfo: entity.options.logInfo
            },
        }, entity, pageIndex);
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.ACCOUNT_SHOP)
    private onTransferAccountList(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.JUDGE)
    private onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        switch (entity.name) {
            case AutomaticTransferEntityName.TRANSFER_CANCEL_LIST:
                this.checkTransferCancelList()
                    .subscribe((result) => {
                        for (const choice of entity.choices) {
                            if (choice.value === result) {
                                return  this.emitMessageRetrivalEvent(choice.next, pageIndex);
                            }
                        }
                    });
                break;
            default:
                entity.choices.forEach((choice) => this.emitMessageRetrivalEvent(choice.next, pageIndex));
        }
    }

    @Renderer([
        AutomaticTransferChatFlowQuestionTypes.DAY_PICKER,
        AutomaticTransferChatFlowQuestionTypes.YEAR_MONTH_PICKER
    ])
    private onPicker(entity: ChatFlowMessageInterface, pageIndex: number): void {
        let validation = entity.validationRules;
        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(this.state.submitData.customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM)
            };
        }
        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            defaultIndex: [0, moment(this.state.submitData.customerApplyStartDate).month()],
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: PickerCommonComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.ROUTE)
    private onRoute(entity: ChatFlowMessageInterface, pageIndex: number): void {
        if (entity.example === AutomaticTransferAccountFlag.CANCEL_CONFIRM) {
            this.navCtrl.setRoot(AutomaticTransferInitconfirmComponent);
        }
    }

    /**
     * 契約中の自動振込itemを選択された時にchat用文字を返却
     * @param info 契約中の自動振込情報
     */
    private getTransferCancelAccountMessage(info) {
        return this.contentsOfTransferFundText(info.contentsOfTransferFund) +
            COMMON_CONSTANTS.FULL_SPACE +
            StringUtils.convertHankaku2Zankaku(info.beneficiaryNameKana) +
            COMMON_CONSTANTS.FULL_SPACE +
            info.transferDestinationBankKana +
            COMMON_CONSTANTS.FULL_SPACE +
            info.transferDestinationBranchKana +
            COMMON_CONSTANTS.FULL_SPACE +
            this.contentsOfAccountInfo(info.receivedAccountNo, info.receivedAccountType);
    }

    /**
     * 契約中の自動振込内容のコードを文字に変更
     * @param value 契約中の自動振込内容のコード
     */
    private contentsOfTransferFundText(value: string): string {
        switch (value) {
            case AutomaticTransferAccountFlag.SCHOOL:
                return this.labels.automaticTransfer.transferFundText.school;
            case AutomaticTransferAccountFlag.RENT:
                return this.labels.automaticTransfer.transferFundText.rent;
            case AutomaticTransferAccountFlag.OTHER_FUND:
                return this.labels.automaticTransfer.transferFundText.other;
        }
    }

    /**
     * 契約中の自動振銀行口座情報を返却
     * @param accountNo 口座番号
     * @param accountType 口座種類
     */
    private contentsOfAccountInfo(accountNo, accountType): string {
        switch (accountType) {
            case AutomaticTransferAccountItem.ORDINARY:
                return this.labels.accountInfo.accountType.ordinary + COMMON_CONSTANTS.HALF_HYPHEN + accountNo;
            case AutomaticTransferAccountItem.CURRENT:
                return this.labels.accountInfo.accountType.current + COMMON_CONSTANTS.HALF_HYPHEN + accountNo;
            case AutomaticTransferAccountItem.SAVINGS:
                return this.labels.accountInfo.accountType.savings + COMMON_CONSTANTS.HALF_HYPHEN + accountNo;
            case AutomaticTransferAccountItem.DEPOSITS_TAX_PAYMENT:
                return this.labels.accountInfo.accountType.depositsTaxPayment + COMMON_CONSTANTS.HALF_HYPHEN + accountNo;
        }
    }

    /**
     * 契約中の自動振込一覧をチェック
     * @param filtering リストのフィルタ
     */
    private checkTransferCancelList(): Observable<string> {
        return Observable.create((observe) => {
            // 契約中の自動振込一覧を取得
            this.action.getContractInfo({
                tabletApplyId: this.state.submitData.tabletApplyId,
                userMngNo: this.loginStore.getState().bankclerkId,
                branchNo: this.state.submitData.swipeBranchNo,
                accountNo: this.state.submitData.swipeAccountNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                cifInfo: this.state.cifInfo,
            });

            this.store.registerSignalHandler(AutomaticTransferStateSignal.GET_CONTRACT_INFO, (info) => {
                this.store.unregisterSignalHandler(AutomaticTransferStateSignal.GET_CONTRACT_INFO);
                if (info && info.filter((item) => item.selectFlag === AutomaticTransferAccountFlag.CAN_SELECT).length > 0) {
                    observe.next(AutomaticTransferAccountFlag.CANCEL_LIST_NO_EMPTY);
                } else {
                    observe.next(AutomaticTransferAccountFlag.CANCEL_LIST_IS_EMPTY);
                }
                observe.complete();
            });
        });
    }
 }
