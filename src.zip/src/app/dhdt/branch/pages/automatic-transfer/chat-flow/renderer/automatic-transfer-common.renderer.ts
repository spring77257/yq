import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferChatFlowQuestionTypes
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/automatic-transfer.chat-flow-question-types';
import {
    AutomaticTransferCommonInputHandler
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/handler/automatic-transfer-common.handler';
import {
    AutomaticTransferState, AutomaticTransferStateSignal, AutomaticTransferStore
} from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import { ChangeConfirmComponent } from 'dhdt/branch/pages/change/view/change-confirm.component';
import { COMMON_CONSTANTS, CoreBankingConst } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { App, NavController } from 'ionic-angular';

export const AUTOMATIC_TRANSFER_COMMON_RENDERER_TYPE = 'AutomaticTransferCommonRenderer';

/**
 * `DefaultChatFlowRenderer`において、自動振込開始画面に利用できるRendererを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferCommonRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: AUTOMATIC_TRANSFER_COMMON_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-automatic-transfer-common.yml'
})
export class AutomaticTransferCommonRenderer extends DefaultChatFlowRenderer {
    public processType: number = COMMON_CONSTANTS.ProcessType.RequiredInput;
    protected userAnswers: any;

    private navCtrl: NavController;
    private state: AutomaticTransferState;

    constructor(private modalService: ModalService,
                private deviceService: DeviceService,
                private labelService: LabelService,
                private loginStore: LoginStore,
                private action: AutomaticTransferAction,
                private store: AutomaticTransferStore,
                app: App,
                inputHandler: AutomaticTransferCommonInputHandler) {
        super(action, inputHandler);

        this.navCtrl = app.getActiveNavs()[0];
        this.state = this.store.getState();
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = { validationRules: entity.validationRules, skip: entity.skip, type: entity.type, name: entity.name };
        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * パスワードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(AutomaticTransferChatFlowQuestionTypes.NEED_PASSWORD)
    private onPassword(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const param = {
            tabletApplyId: this.state.submitData.tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            terminalNo: this.deviceService.getDeviceId(),
            accountNo: this.state.submitData.swipeAccountNo,
            tenban: this.state.submitData.swipeBranchNo,
            accountType: this.state.submitData.swipeAccountType
        };

        this.modalService.showModal(COMMON_CONSTANTS.ELEMENT_TYPE_PASSWORD_VERIFICATION,
            {
                text: this.labelService.labels.password.inputPasswordText,
                subText: this.labelService.labels.password.inputPasswordSubText,
                units: COMMON_CONSTANTS.PASSWORD_MODAL_UNITS,
                needConfirm: false,
                cashcardParams: param
            }, (result) => {
                if (result) {
                    this.showConfirmPage(entity.next, pageIndex, result);
                }
            });
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.JUDGE)
    private onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        if (entity.choices) {
            for (const choice of entity.choices) {
                if (choice.value === this.state.submitData[entity.name]) {
                    this.parentInputHandler.chatFlowCompelete(choice.action.value);
                    return;
                }
            }
        }
    }

    private showConfirmPage(next: number, pageIndex: number, result: any) {
        // CIF情報照会ハンドル
        const cifParam: SimpleCifInfoInquiryInterface = {
            path: CoreBankingConstants.ApiPathConsts.CIF_INFO_INQUIRY,
            tabletApplyId: this.state.submitData.tabletApplyId,
            userMngNo: this.loginStore.getState().bankclerkId,
            params: {
                bankNo: CoreBankingConst.bankNo,
                receptionTenban: this.state.submitData.receptionBranchNo,
                receptionNo: this.state.submitData.receptionNo,
                terminalNo: this.deviceService.getDeviceId(),
                tenban: this.state.submitData.swipeBranchNo,
                accountNo: this.state.submitData.swipeAccountNo,
                accountType: this.state.submitData.swipeAccountType
            }
        };

        const inputParams = {
            tabletApplyId: this.state.submitData.tabletApplyId,
            swipeCif: this.state.submitData.swipeCif,
            branchNo: this.state.submitData.swipeBranchNo,
            accountNo: this.state.submitData.swipeAccountNo,
            accountType: this.state.submitData.swipeAccountType,
            receptionBranchNo: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            receptionTime: this.state.submitData.receptionTime,
            password: result,
        };

        this.navCtrl.push(
            ChangeConfirmComponent,
            {
                type: COMMON_CONSTANTS.BusinessFlowType.AutomaticTransfer,
                processType: this.processType,
                cifParam: cifParam,
                inputParams: inputParams,
                callBack: () => {
                    this.action.getCifInformation(cifParam);
                    this.store.registerSignalHandler(AutomaticTransferStateSignal.GET_ANCESTOR_CIF_INFO_COMPLETE, () => {
                        this.store.unregisterSignalHandler(AutomaticTransferStateSignal.GET_ANCESTOR_CIF_INFO_COMPLETE);
                        this.emitMessageRetrivalEvent(next, pageIndex, 0);
                    });
                }
            },
            { animate: false }
        );
    }
}
