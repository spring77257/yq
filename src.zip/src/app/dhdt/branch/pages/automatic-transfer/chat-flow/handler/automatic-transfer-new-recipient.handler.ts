import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferChatFlowQuestionTypes
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/automatic-transfer.chat-flow-question-types';
import {
    AutomaticTransferState, AutomaticTransferStateSignal, AutomaticTransferStore
} from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import {
    ApplyBusinessType, AutomaticTransferAccountItem, AutomaticTransferErrorCode,
    COMMON_CONSTANTS, CoreBankingConst, CssConsts, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { LoginComponent } from 'dhdt/branch/pages/common/login/view/login.component';
import { DialogComponent } from 'dhdt/branch/shared/components/dialog/dialog.component';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { LoadingService } from 'dhdt/branch/shared/services/loading.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { App, ModalController } from 'ionic-angular';

/**
 * `DefaultChatFlowInputHandler`において、自動振込新規申込画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferNewRecipientInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class AutomaticTransferNewRecipientInputHandler extends DefaultChatFlowInputHandler {

    private state: AutomaticTransferState;

    constructor(private action: AutomaticTransferAction,
                private store: AutomaticTransferStore,
                private modalService: ModalService,
                private deviceService: DeviceService,
                private loginStore: LoginStore,
                private labelService: LabelService,
                private loadingService: LoadingService,
                private appCtrl: App,
                private modalCtrl: ModalController,
                private errorMessageService: ErrorMessageService) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler([
        AutomaticTransferChatFlowQuestionTypes.BUTTON,
        AutomaticTransferChatFlowQuestionTypes.BUTTON_THREE_COLS
    ])
    private onButtonHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({
            text: answer.text,
            value: entity.name.length > 0 ? [{ key: entity.name, value: answer.value }] : undefined
        });

        if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler([
        AutomaticTransferChatFlowQuestionTypes.KEYBOARD,
        AutomaticTransferChatFlowQuestionTypes.NUMBER_KEYBORD
    ])
    private onKeybordHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        let data = answer;
        switch (entity.name) {
            // 銀行名の存在チェック
            case SubmitDataKey.TRANSFER_DESTINATION_BANK:
                this.registerCheckTransferDestinationInfoHandle({
                    signal: AutomaticTransferStateSignal.CHECK_TRANSFER_DESTINATION_BANK,
                    entity: entity,
                    pageIndex: pageIndex
                });
                this.action.checkTransferDestinationBank(answer.text);
                break;
            // 支店名の存在チェック
            case SubmitDataKey.TRANSFER_DESTINATION_BRANCH:
                this.registerCheckTransferDestinationInfoHandle(
                    {
                        signal: AutomaticTransferStateSignal.CHECK_TRANSFER_DESTINATION_BRANCH,
                        entity: entity,
                        pageIndex: pageIndex
                    },
                    answer
                );
                this.action.checkTransferDestinationBranch(this.state.submitData.transferDestinationBank, answer.text);
                break;
            // 口座番号の存在チェック
            case SubmitDataKey.TRANSFER_DESTINATION_ACCOUNT_NO:
                this.registerCheckTransferDestinationInfoHandle({
                    signal: AutomaticTransferStateSignal.CHECK_TRANSFER_DESTINATION_ACCOUNT_NO,
                    entity: entity,
                    pageIndex: pageIndex
                });
                this.action.checkReceiptAccountNo(
                    this.state.submitData.transferDestinationBank,
                    this.state.submitData.receiptAccountItem,
                    {
                        tabletApplyId: this.state.submitData.tabletApplyId,
                        userMngNo: this.loginStore.getState().bankclerkId,
                        bankNo: CoreBankingConst.bankNo,
                        receptionTenban: this.state.submitData.receptionBranchNo,
                        receptionNo: this.state.submitData.receptionNo,
                        terminalNo: this.deviceService.getDeviceId(),
                        tenban: this.state.submitData.transferDestinationBranchCode,
                        accountNo: answer.text,
                        accountType: this.state.submitData.receiptAccountItem === AutomaticTransferAccountItem.SAVINGS
                            ? COMMON_CONSTANTS.AccountTypeCode.ordinary : this.state.submitData.receiptAccountItem,
                        nameKana: this.state.submitData.holderNameFurigana
                    });
                break;
            //  口座名義人
            case SubmitDataKey.BENEFICIARY_NAME:
                const input = answer.value.find((item) => item.key === SubmitDataKey.BENEFICIARY_NAME);
                const value = StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku(input.value));
                // 受取口座の口座名義人カナに入力された内容を半角カナに変換して、文字列が25桁を超えているのをチェック
                if (value.length > COMMON_CONSTANTS.BENEFICIARY_NAME_MAX_LENGTH) {
                    const buttonList = [
                        { text: 'OK', buttonValue: 'ok' },
                    ];
                    this.modalService.showWarnAlert(
                        this.labelService.labels.automaticTransfer.errorMessage.exceededMaxLength,
                        buttonList,
                        null,
                        null,
                        CssConsts.CSS_CLASS_WARNING_MODAL
                    );
                } else {
                    // gimで正規表現式を設定されたので、英小文字が入力されたら自動で英大文字にする
                    data = {
                        text: answer.text.toUpperCase(),
                        value: [{
                            key: SubmitDataKey.BENEFICIARY_NAME,
                            value: input.value.toUpperCase()
                        }]
                    };
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                }
                break;
            default:
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
        if (entity.name !== SubmitDataKey.TRANSFER_DESTINATION_BRANCH) {
            this.setAnswer(data);
        }
    }

    /**
     * 銀行名、支店名存在、口座番号チェック処理
     * @param entity ChatFlowのYamlTemplateから送られてくるデータのインターフェース
     * @param pageIndex page index
     */
    private registerCheckTransferDestinationInfoHandle(param: { signal: string; entity: any; pageIndex: any; }, answer?: any) {
        this.store.registerSignalHandler(param.signal, (error) => {
            this.store.unregisterSignalHandler(param.signal);
            if (error) {
                if (answer) {
                    this.setAnswer(answer);
                }
                if (error.reason) {
                    return　this.errorHandler(error.reason);
                } else if (error.message) {
                    return this.errorMessageService.showMessageModal(error.message);
                }
            } else if (answer) {
                this.setAnswer({
                    text: this.state.submitData.transferDestinationBranch,
                    value: [{ key: param.entity.name, value: this.state.submitData.transferDestinationBranch }]
                });
            }
            this.emitMessageRetrivalEvent(param.entity.next, param.pageIndex);
        });
    }

    /**
     * エラー処理
     * @param reason error reason
     */
    private errorHandler(reason) {
        switch (reason) {
            case AutomaticTransferErrorCode.Q00026:
            case AutomaticTransferErrorCode.Q00027:
                this.errorMessageService.handleExternalError({
                    errReason: reason,
                    applyBusinessType: ApplyBusinessType.AUTOMATIC_TRANSFER,
                    processNo: undefined,
                    uri: undefined
                });
                break;
            default:
                const message = this.errorMessageService.getMessageFromExternalError({
                    errReason: reason,
                    applyBusinessType: ApplyBusinessType.AUTOMATIC_TRANSFER,
                    processNo: undefined,
                    uri: undefined
                });
                const params = {
                    imgSrc: 'icon_alert@2x.png',
                    message: message,
                    buttonList: [{ text: 'OK', buttonValue: 'ok' }]
                };
                const modal = this.modalCtrl.create(
                    DialogComponent, params, { cssClass: 'settings-error-modal', enableBackdropDismiss: false }
                );
                this.loadingService.dismissAllLoading();
                if (modal) {
                    modal.present();
                }
                modal.onDidDismiss(() => {
                    this.action.dismissComponent();
                    this.action.clearStore();
                    this.appCtrl.getRootNav().setRoot(LoginComponent);
                });
        }
    }
}
