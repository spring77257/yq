import { Injectable } from '@angular/core';
import { DeviceService } from 'dhd/common/services/device.service';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferChatFlowQuestionTypes
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/automatic-transfer.chat-flow-question-types';
import {
    AutomaticTransferNewinformationInputHandler
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/handler/automatic-transfer-new-information.handler';
import {　AutomaticTransferConfirmRenderer　} from 'dhdt/branch/pages/automatic-transfer/decorator/automatic-transfer-confirm.renderer';
import {
    AutomaticTransferState, AutomaticTransferStateSignal, AutomaticTransferStore
} from 'dhdt/branch/pages/automatic-transfer/store/automatic-transfer.store';
import { AutomaticTransferInitconfirmComponent } from 'dhdt/branch/pages/automatic-transfer/view/automatic-transfer-initconfirm.component';
import {
    AutomaticTransferCommissionType, AutomaticTransferEntityName, AutomaticTransferStudentDepositType,
    COMMON_CONSTANTS, CoreBankingConst, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { QuantityInputComponent } from 'dhdt/branch/shared/components/quantity-input/quantity-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { App, NavController } from 'ionic-angular';
import * as moment from 'moment';

export const AUTOMATIC_TRANSFER_NEW_INFORMATION_RENDERER_TYPE = 'AutomaticTransferNewInformationRenderer';

/**
 * `DefaultChatFlowRenderer`において、自動振込新規申込画面に利用できるRendererを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferNewInformationRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: AUTOMATIC_TRANSFER_NEW_INFORMATION_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-automatic-transfer-new-information.yml'
})
@AutomaticTransferConfirmRenderer({
    templateYaml: 'chat-flow-def-automatic-transfer-new-information-confirmpage.yml'
})
export class AutomaticTransferNewInformationRenderer extends DefaultChatFlowRenderer {
    public processType: number = COMMON_CONSTANTS.ProcessType.RequiredInput;
    protected userAnswers: any;

    private state: AutomaticTransferState;
    private navCtrl: NavController;

    constructor(private action: AutomaticTransferAction,
                private store: AutomaticTransferStore,
                private deviceService: DeviceService,
                private loginStore: LoginStore,
                private modalService: ModalService,
                app: App,
                inputHandler: AutomaticTransferNewinformationInputHandler) {
        super(action, inputHandler);
        this.navCtrl = app.getActiveNavs()[0];
        this.state = this.store.getState();
    }

    @Renderer([
        AutomaticTransferChatFlowQuestionTypes.DAY_PICKER,
        AutomaticTransferChatFlowQuestionTypes.YEAR_MONTH_PICKER,
        AutomaticTransferChatFlowQuestionTypes.PICKER
    ])
    private onPicker(entity: ChatFlowMessageInterface, pageIndex: number): void {
        let validation = entity.validationRules;
        let defaultIndex = null;

        // システム日時を最小値に設定
        if (entity.validationRules.min === COMMON_CONSTANTS.PICKER_TYPE_TODAY) {
            validation = {
                ...entity.validationRules,
                min: moment(this.state.submitData.customerApplyStartDate)
                    .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM)
            };
        }

        if (entity.name === SubmitDataKey.TRANSFER_START_DATE) {
            // 振込開始月の範囲は6ヶ月以内
            const month = moment(this.state.submitData.customerApplyStartDate).month() + 1;
            validation.range = month > 6 ? [0, 1] : [0, 0];
        }

        // 振込開始年月と振込終了年月の場合、初期値は本年月を設定
        if (entity.name === SubmitDataKey.TRANSFER_START_DATE || entity.name === SubmitDataKey.TRANSFER_END_DATE) {
            defaultIndex = [0, moment(this.state.submitData.customerApplyStartDate).month()];
        }

        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            title: entity.options ? entity.options.title : undefined,
            defaultIndex: defaultIndex,
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: PickerCommonComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer([
        AutomaticTransferChatFlowQuestionTypes.BUTTON,
        AutomaticTransferChatFlowQuestionTypes.BUTTON_THREE_COLS
    ])
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            maxColNum: (entity.type === AutomaticTransferChatFlowQuestionTypes.BUTTON_THREE_COLS) ? 3 : undefined,
        };
        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.DEPOSIT_INPUT)
    private onDepositInput(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            title: entity.options ? entity.options.title : undefined,
            unit: entity.options ? entity.options.unit : undefined,
            validationRules: entity.validationRules
        };

        this.emitRenderEvent({
            class: QuantityInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.JUDGE)
    private onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        switch (entity.name) {
            // 学生を判断処理
            case AutomaticTransferEntityName.STUDENT_DEPOSIT_TYPE:
                for (const choice of entity.choices) {
                    if (choice.value === this.state.studentAccountType) {
                        return this.emitMessageRetrivalEvent(choice.next, pageIndex);
                    }
                }
                break;
            // 振込金額手数料を取得
            case SubmitDataKey.MONTHLY_EXCHANGE_FEE:
                this.getTransferFee(this.state.submitData.monthlyTransferAmount, entity, pageIndex);
                break;
            case SubmitDataKey.SPECIFIED_EXCHANGE_FEE_1:
                this.getTransferFee(this.state.submitData.specifiedTransferAmount1, entity, pageIndex);
                break;
            case SubmitDataKey.SPECIFIED_EXCHANGE_FEE_2:
                this.getTransferFee(this.state.submitData.specifiedTransferAmount2, entity, pageIndex);
                break;
            // 特定月の振込は１ヵ月分、２ヵ月分を判断処理
            case AutomaticTransferEntityName.SPECIFIED_TRANSFER_MONTH_SECLECT:
                for (const choice of entity.choices) {
                    if (this.state.submitData[AutomaticTransferEntityName.SPECIFIED_TRANSFER_MONTH_SECLECT] === choice.value) {
                        return this.emitMessageRetrivalEvent(choice.next, pageIndex);
                    }
                }
                break;
            default:
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    @Renderer(AutomaticTransferChatFlowQuestionTypes.AGREED_MODAL)
    private onAgreedModal(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.modalService.showModal(entity.type, { pdfSrc: COMMON_CONSTANTS.AUTOMATIC_TRANSFER_PDF_FILE, isShowSubTitle: false }, () => {
            // 自動振込申込内容確認を遷移
            this.navCtrl.setRoot(AutomaticTransferInitconfirmComponent);
        });
    }

    /**
     * 振込金額手数料を取得
     * @param amount 振込金額
     * @param entity entity
     * @param key page index
     */
    private getTransferFee(amount, entity, pageIndex) {
        const params = {
            bankNo: CoreBankingConst.bankNo,
            terminalNo: this.deviceService.getDeviceId(),
            commissionType: AutomaticTransferCommissionType.TRANSFER,
            transferAmount: amount,
            userMngNo: this.loginStore.getState().bankclerkId,
            tabletApplyId: this.state.submitData.tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            withdrawalBranchNo: this.state.submitData.withdrawalBranchNo,
            transferDestinationBankCode: this.state.submitData.transferDestinationBankCode,
            transferDestinationBranchCode: this.state.submitData.transferDestinationBranchCode,
        };

        this.action.getTransferFee(params, entity.name);
        this.store.registerSignalHandler(AutomaticTransferStateSignal.GET_TRANSFER_FEE, () => {
            this.store.unregisterSignalHandler(AutomaticTransferStateSignal.GET_TRANSFER_FEE);
            for (const choice of entity.choices) {
                const type = this.state.submitData[entity.name] + this.state.handlingFee > 0 ?
                    AutomaticTransferCommissionType.PAY : AutomaticTransferCommissionType.FREE;
                if (choice.value === type) {
                    return this.emitMessageRetrivalEvent(choice.next, pageIndex);
                }
            }
        });
    }
}
