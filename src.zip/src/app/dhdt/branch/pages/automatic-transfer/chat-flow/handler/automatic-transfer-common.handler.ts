import { Injectable } from '@angular/core';
import { AutomaticTransferAction } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import {
    AutomaticTransferChatFlowQuestionTypes
} from 'dhdt/branch/pages/automatic-transfer/chat-flow/automatic-transfer.chat-flow-question-types';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';

/**
 * `DefaultChatFlowInputHandler`において、自動振込開始画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferCommonInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class AutomaticTransferCommonInputHandler extends DefaultChatFlowInputHandler {

    constructor(action: AutomaticTransferAction) {
        super(action);
    }

    @InputHandler(AutomaticTransferChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({
            text: answer.text,
            value: entity.name.length > 0 ? [{ key: entity.name, value: answer.value }] : undefined
        });

        if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }
}
