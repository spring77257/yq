import { Injectable } from '@angular/core';
import { Action } from 'adep/flux';
import { HttpService } from 'dhdt/branch/shared/services/http.service';

import { ReceptionInfoEntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/reception-info.entity';
import {
    API_URL, AutomaticTransferAccountItem, CodeCategory, COMMON_CONSTANTS, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { AccountExistCheckInterface } from 'dhdt/branch/shared/interface/account-exist-check.interface';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { ChatFlowActionInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-action.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { DocumentCategorySubjectData } from 'dhdt/branch/shared/modules/document-category/entity/document-category.entity';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { Observable } from 'rxjs';

export namespace AutomaticTransferActionType {
    export const GET_SAVING_QUESTION_TEMPLATE: string = 'AutomaticTransferActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const NEXT_CHAT: string = 'AutomaticTransferActionType_NEXT_CHAT';
    export const CLEAR: string = 'AutomaticTransferActionType_LOAD_TEMPLATE_CLEAR';
    export const CLEAR_SHOW_CHATS: string = 'AutomaticTransferActionType_CLEAR_SHOW_CHATS';
    export const DISMISS_COMPONENT: string = 'AutomaticTransferActionType_DISMISS_COMPONENT';
    export const BRANCH_STATUS_UPDATE: string = 'AutomaticTransferActionType_BRANCH_STATUS_UPDATE';
    export const SET_CUSTOMER_APPLY_START_DATE: string = 'AutomaticTransferActionType_SET_CUSTOMER_APPLY_START_DATE';
    export const SET_ANSWER: string = 'AutomaticTransferActionType_SET_ANSWER';
    export const EDIT_CHAT: string = 'AutomaticTransferActionType_EDIT_CHAT';
    export const SET_STATE_SUBMIT_DATA_VALUE: string = 'AutomaticTransferActionType_SET_STATE_SUBMIT_DATA_VALUE';
    export const SET_SWIPE_CARD_TO_SUBMIT_DATA = 'AutomaticTransferActionType_SET_SWIPE_CARD_TO_SUBMIT_DATA';
    export const SUBMIT_DATA_BACKUP: string = 'AutomaticTransferActionType_SUBMIT_DATA_BACKUP';
    export const SUBMIT_DATA_RESTORE: string = 'AutomaticTransferActionType_SUBMIT_DATA_RESTORE';
    export const RETRIEVE_DROP_LIST: string = 'AutomaticTransferActionType_RETRIEVE_DROP_LIST';
    export const BRANCH_INFO_INSERT: string = 'AutomaticTransferActionType_BRANCH_INFO_INSERT';
    export const CHAT_FLOW_COMPELETE = 'AutomaticTransferACTIONTYPE_CHAT_FLOW_COMPELETE';
    export const RESET_LAST_NODE = 'AutomaticTransferACTIONTYPE_RESET_LAST_NODE';
    export const RESET_SHOW_CONFIRM = 'AutomaticTransferActionType_RESET_SHOW_CONFIRM';
    export const SET_CUSTOMER_APPLY_END_DATE: string = 'AutomaticTransferActionType_SET_CUSTOMER_APPLY_END_DATE';
    export const SET_BANKCLERK_CONFIRM_START_DATE: string = 'SET_BANKCLERK_CONFIRM_START_DATE';
    export const GET_CONFIRM_PAGE_TEMPLATE: string = 'GET_CONFIRM_PAGE_TEMPLATE';
    export const SET_SWIPE_INFO: string = 'AutomaticTransferActionType_SET_SWIPE_INFO';
    export const GET_ACCOUNT_EXISTING = 'AutomaticTransferActionType_GET_ACCOUNT_EXISTING';
    export const SET_CIF_INFORMATION = 'AutomaticTransferActionType_SET_CIF_INFORMATION';
    export const SET_SIMPLE_CIF_INFORMATION = 'AutomaticTransferActionType_SET_SIMPLE_CIF_INFORMATION';
    export const SET_BANKCLERK_ID = 'AutomaticTransferActionType_SET_BANKCLERK_ID';
    export const SET_AGENCY_BRANCH_INFO = 'AutomaticTransferActionType_SET_AGENCY_BRANCH_INFO';
    export const SET_BANKCLERK_CONFIRM_DATE = 'AutomaticTransferActionType_SET_BANKCLERK_CONFIRM_DATE';
    export const SET_INPUTCONTENT_CONFIRMATION_DATE = 'AutomaticTransferActionType_SET_INPUTCONTENT_CONFIRMATION_DATE';
    export const SET_PROCEDUREGUIDE_COMPLETE_DATE = 'AutomaticTransferActionType_SET_PROCEDUREGUIDE_COMPLETE_DATE';
    export const SET_TRANSFER_CANCEL_INFO = 'AutomaticTransferActionType_SET_TRANSFER_CANCEL_INFO';
    export const SET_EXCHANGE_FEE = 'AutomaticTransferActionType_SET_EXCHANGE_FEE';
    export const GET_ACCOUNT_WITHOUT_CARD = 'AutomaticTransferActionType_GET_ACCOUNT_WITHOUT_CARD';
    export const GET_CONTRACT_INFO = 'AutomaticTransferActionType_GET_CONTRACT_INFO';
    export const CLEAR_CONFIRM_PAGE_INFO: string = 'AutomaticTransferActionType_CLEAR_CONFIRM_PAGE_INFO';
    export const CLEAR_SPECIFIED_TRANSFER = 'AutomaticTransferActionType_CLEAR_SPECIFIED_TRANSFER';
    export const CLEAR_KANA_DETAIL = 'AutomaticTransferActionType_CLEAR_KANA_DETAIL';
    export const GET_TRANSFER_DESTINATION_BANK = 'AutomaticTransferActionType_GET_TRANSFER_DESTINATION_BANK';
    export const GET_TRANSFER_DESTINATION_BRANCH = 'AutomaticTransferActionType_GET_TRANSFER_DESTINATION_BRANCH';
    export const GET_TRANSFER_FEE = 'AutomaticTransferActionType_GET_TRANSFER_FEE';
    export const GET_WITHDRAWAL_FEE = 'AutomaticTransferActionType_GET_WITHDRAWAL_FEE';
    export const CHECK_RECEIPT_ACCOUNT_NO = 'AutomaticTransferActionType_CHECK_RECEIPT_ACCOUNT_NO';
    export const CHECK_BUSINESS_DAY = 'AutomaticTransferActionType_CHECK_BUSINESS_DAY';
}

@Injectable()
export class AutomaticTransferAction extends Action implements ChatFlowActionInterface {

    constructor(
        private httpService: HttpService
    ) {
        super();
    }

    /**
     * submit dataを更新
     *
     * @param data 書類カテゴリと選択された書類
     * @param isHolderPage 本人確認画面フラグ
     * @param isHolder 本人フラグ
     */
    public setDocumentCategory(data: DocumentCategorySubjectData) {
        switch (data.code) {
            // 本人確認情報
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_TYPE:
                this.setStateSubmitDataValue({
                    name: SubmitDataKey.HOLDER_ID_DOC_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                });
                break;
            // 本人確認書類（顔写真ない）の補完書類の種類
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_PHOTOGRAPH_TYPE:
                this.setStateSubmitDataValue({
                    name: SubmitDataKey.HOLDER_ID_DOC_PHOTO_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                });
                break;
            // 本人確認書類（住所異なる）の補完書類の種類
            case CodeCategory.CODE_CATEGORY_IDENTITY_DOC_ADDRESS_TYPE:
                this.setStateSubmitDataValue({
                    name: SubmitDataKey.HOLDER_ID_DOC_ADDRESS_TYPE,
                    value: data.entity ? data.entity.codeValue : null
                });
                break;
            // コピー徴求ができない理由
            case CodeCategory.CODE_CATEGORY_NO_COPY_REASON:
            // 住所が相違する理由
            case CodeCategory.CODE_CATEGORY_DIFFERENT_ADDRESS_REASON:
            // 遠隔地等住所等の場合の理由
            case CodeCategory.CODE_CATEGORY_FAR_ADDRESS_REASON:
                this.setStateSubmitDataValue({
                    name: data.key,
                    value: data.entity ? data.entity.data : null
                });
                break;
        }
    }

    /**
     * チャットテンプレートをロードする
     * @param file yamlファイル名
     * @param pageIndex ページインデックス
     */
    public loadTemplate(file: string, pageIndex: number) {
        this.httpService.get(API_URL.CHATFLOW_DEFINITION + file, null, null, SpinnerType.NO_SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: AutomaticTransferActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos
                }
            });
        });
    }

    /**
     * タブレット申し込み情報にデータを更新する
     * @param params タブレット申し込み情報
     */
    public branchStatusUpdate(params: any) {
        this.httpService.post(API_URL.BRANCH_STATUS_UPDATE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: AutomaticTransferActionType.BRANCH_STATUS_UPDATE,
                data: response.result
            });
        });
    }

    /**
     * 次のステップを取得する
     * @param order オーダー
     * @param pageIndex ページインデックス
     */
    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    /**
     * 回答を編集する。
     *
     * @param {number} order
     * @param {number} pageIndex
     * @memberof ChatFlowActionInterface
     */
    public editAnswer(order: number, pageIndex: number, answerOrder: number, showChatIndex?: number) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.EDIT_CHAT,
            data: {
                order: order, pageIndex: pageIndex, answerOrder: answerOrder, showChatIndex: showChatIndex
            }
        });
    }

    /**
     * ユーザからの回答をStateに保存する。
     *
     * @param {{ text: string, value: Array<{ key: string, value: string }> }} answer
     * @memberof ChatFlowActionInterface
     */
    public setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.SET_ANSWER,
            data: answer
        });
    }

    /**
     * ChatFlowを完了させる。
     *
     * @param {string} nextChatName
     * @memberof ChatFlowActionInterface
     */
    public chatFlowCompelete(nextChatName: string) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.CHAT_FLOW_COMPELETE,
            data: nextChatName
        });
    }

    /**
     * 現在のChatFlowの最後のMessageを初期化する。
     *
     * @memberof ChatFlowActionInterface
     */
    public resetLastNode() {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.RESET_LAST_NODE
        });
    }

    /**
     * Reset showConfirm
     * @param showConfirm showConfirm
     */
    public resetShowConfirm(showConfirm: any) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.RESET_SHOW_CONFIRM,
            data: showConfirm
        });
    }

    /**
     * ストアをクリアする
     */
    public clearStore() {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.CLEAR
        });
    }

    /**
     * チャットの表示内容をクリアする
     */
    public clearShowChats() {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.CLEAR_SHOW_CHATS
        });
    }

    /**
     * dismiss component
     */
    public dismissComponent() {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.DISMISS_COMPONENT
        });
    }

    /**
     * 顧客申し込み開始時間を設定する
     */
    public setCustomerApplyStartDate(date) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.SET_CUSTOMER_APPLY_START_DATE,
            data: {
                systemTime: date
            }
        });
    }

    /**
     * 顧客申し込み完了時間を設定する
     */
    public setCustomerApplyEndDate() {
        this.setSystemTime(AutomaticTransferActionType.SET_CUSTOMER_APPLY_END_DATE);
    }

    /**
     * 行員認証開始時間を設定する
     */
    public setBankclerkAuthenticationStartDate() {
        this.setSystemTime(AutomaticTransferActionType.SET_BANKCLERK_CONFIRM_START_DATE);
    }

    /**
     * 行員認証時間を設定する
     */
    public setBankclerkAuthenticationEndDate() {
        this.setSystemTime(AutomaticTransferActionType.SET_BANKCLERK_CONFIRM_DATE);
    }

    /**
     * 入力内容確認完了時間を設定する
     */
    public setInputContentConfirmationDate() {
        this.setSystemTime(AutomaticTransferActionType.SET_INPUTCONTENT_CONFIRMATION_DATE);
    }

    /**
     * 手続き案内完了時間を設定する
     */
    public setProcedureGuideCompleteDate() {
        this.setSystemTime(AutomaticTransferActionType.SET_PROCEDUREGUIDE_COMPLETE_DATE);
    }

    /**
     * サブミットデータに値を設定する
     *
     * @param param 項目値
     */
    public setStateSubmitDataValue(param: any) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.SET_STATE_SUBMIT_DATA_VALUE,
            data: param
        });
    }

    /**
     * スワイプカードの口座引落指定口座にを設定
     */
    public setSwipeCardToWithdrawalAccount() {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.SET_SWIPE_CARD_TO_SUBMIT_DATA,
        });
    }

    /**
     * 手数料をセット
     * @param name 項目名
     * @param fee 手数料
     */
    public setExchangeFee(name: string, fee: number) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.SET_EXCHANGE_FEE,
            data: { name, fee }
        });
    }

    /**
     * コードマスタの情報を取得する
     *
     * @param params
     */
    public retrieveDropList(params: any) {
        this.httpService.get(API_URL.CATEGORY_CODES_RETRIEVE, params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: AutomaticTransferActionType.RETRIEVE_DROP_LIST,
                data: response.result
            });
        });
    }

    /**
     * 修正用テンプレートをロードする
     * @param params パラメーター
     */
    public loadConfirmPageTemplate(file: string, pageIndex: number) {
        this.httpService.get(API_URL.CHATFLOW_DEFINITION + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: AutomaticTransferActionType.GET_CONFIRM_PAGE_TEMPLATE,
                data: { data: response.result.questions, pageIndex: pageIndex }
            });
        });
    }

    /**
     * 行員認証情報をサブミットする
     *
     * @param params データ
     */
    public saveSubmitData(params: any) {
        this.httpService.post(API_URL.AUTOMATIC_TRANSFER_INSERT, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: AutomaticTransferActionType.BRANCH_INFO_INSERT,
                data: response.result
            });
        });
    }

    /**
     * 回答中のChatFlowのデータのバックアップを行う。
     */
    public submitDataBackup() {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.SUBMIT_DATA_BACKUP
        });
    }

    /**
     * バックアップの回答中のChatFlowのデータを復元する。
     */
    public submitDataRestore() {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.SUBMIT_DATA_RESTORE
        });
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param params QRコード受付情報
     */
    public setSwipeInfo(params: ReceptionInfoEntity) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.SET_SWIPE_INFO,
            data: params
        });
    }

    /**
     * 特定の月をクリア
     */
    public clearSpecifiedTransfer() {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.CLEAR_SPECIFIED_TRANSFER,
        });
    }

    /**
     * カナ摘要をクリア
     */
    public clearKanaDetail() {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.CLEAR_KANA_DETAIL,
        });
    }

    /**
     * 解約情報を設定
     */
    public setTransferCancelInfo(data) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.SET_TRANSFER_CANCEL_INFO,
            data: data
        });
    }

    /**
     * 口座存在チェック
     * @param params 口座存在チェック用パラメータ
     */
    public checkAccountExisting(params: AccountExistCheckInterface) {
        this.httpService.post(API_URL.CB_CHECK_ACCOUNT_EXISTING, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: AutomaticTransferActionType.GET_ACCOUNT_EXISTING,
                data: response.result
            });
        });
    }

    /**
     * CIF情報照会
     * @param params CIF情報照会用パラメータ
     */
    public getCifInformation(cifParams: SimpleCifInfoInquiryInterface) {
        this.httpService.post(API_URL.CB_GET_CIF_INFORMATION, cifParams).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: AutomaticTransferActionType.SET_CIF_INFORMATION,
                data: { data: response.result }
            });
        });
    }

    /**
     * CIF情報照会
     * @param params CIF情報照会用パラメータ
     */
    public getSimpleCifInformation(cifParams: SimpleCifInfoInquiryInterface) {
        this.httpService.post(API_URL.CB_GET_SIMPLE_CIF_INFORMATION, cifParams).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: AutomaticTransferActionType.SET_SIMPLE_CIF_INFORMATION,
                data: { data: response.result }
            });
        });
    }

    /**
     * 口座情報照会
     * @param params 口座情報照会パラメータ
     */
    public getAccountWithoutCard(param) {
        this.httpService.post(API_URL.CB_GET_ACCOUNT_WITHOUT_CARD, param)
            .subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: AutomaticTransferActionType.GET_ACCOUNT_WITHOUT_CARD,
                    data: response.result
                });
            });
    }

    /**
     * 行員登録画面に遷移するとき、入力する行員IDを記録する
     * @param bankclerkId 行員ID
     */
    public setBankclerkId(bankclerkId: string) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.SET_BANKCLERK_ID,
            data: { bankclerkId: bankclerkId }
        });
    }

    /**
     * 取次店番を記録する
     * @param branchNo 店番号
     */
    public setAgencyBranchInfo(branchNo: string) {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.SET_AGENCY_BRANCH_INFO,
            data: { branchNo: branchNo }
        });
    }

    /**
     * 毎月振込額に発生する振込手数料を取得
     * @param params 振込手数料用パラメータ
     */
    public getTransferFee(params, key): any {
        this.httpService.post(API_URL.TRANSFER_FEE, params)
            .subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: AutomaticTransferActionType.GET_TRANSFER_FEE,
                    data: {
                        result: response.result,
                        key: key
                    }
                });
            });
    }

    /**
     * 毎月振込額と特定の月の振込金額に発生する振込手数料を取得
     * @param params 毎月振込額と特定の月の振込金額
     */
    public getWithdrawalFee(data) {
        if (data.isStudent) {
            this.dispatcher.dispatch({
                actionType: AutomaticTransferActionType.GET_WITHDRAWAL_FEE,
                data: data.amounts.map((item) => {
                    return {
                        key: item.key,
                        value: item.amount ? 0 : null
                    };
                })
            });
        } else {
            Observable.forkJoin(data.amounts.filter((element) => element.amount).flatMap((item) => {
                // 振込額に発生する振込手数料を取得
                return this.httpService.post(API_URL.TRANSFER_FEE, {
                    ...data.params,
                    transferAmount: item.amount
                }).map((response) => {
                    const { transferFeeResponseBean } = response.result;
                    const amount = transferFeeResponseBean && transferFeeResponseBean.commissionAmount ?
                        Number(transferFeeResponseBean.commissionAmount) : 0;
                    return {
                        key: item.key,
                        value: amount
                    };
                });
            })).subscribe((list) => {
                this.dispatcher.dispatch({
                    actionType: AutomaticTransferActionType.GET_WITHDRAWAL_FEE,
                    data: list
                });
            });
        }
    }

    /**
     * 自動振込契約明細照会
     * @param param 明細照会パラメータ
     */
    public getContractInfo(param) {
        this.httpService.post(API_URL.CONTRACT_INFO, param).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: AutomaticTransferActionType.GET_CONTRACT_INFO,
                data: response.result
            });
        });
    }

    /**
     *  行員確認の入力データをクリアする
     */
    public clearConfirmPageInfo() {
        this.dispatcher.dispatch({
            actionType: AutomaticTransferActionType.CLEAR_CONFIRM_PAGE_INFO
        });
    }

    /**
     * 営業日チェック
     * @param param 営業日チェックパラメータ
     */
    public checkBusinessDay(param) {
        this.httpService.post(API_URL.BUSINESS_DAY_CHECK, param)
            .subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: AutomaticTransferActionType.CHECK_BUSINESS_DAY,
                    data: response.result
                });
            });
    }

    /**
     * 銀行名の存在チェック
     * @param bank 銀行名
     */
    public checkTransferDestinationBank(bank: string) {
        // 金融機関情報を呼び出し、銀行名の存在をチェック
        this.httpService.post(API_URL.BANK_EXIST_CHECK, { bankNameKanji: bank })
            .subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: AutomaticTransferActionType.GET_TRANSFER_DESTINATION_BANK,
                    data: response.result
                });
            });
    }

    /**
     * 支店名の存在チェック
     * @param bank 銀行名
     * @param branch 支店名
     */
    public checkTransferDestinationBranch(bank: string, branch: string) {
        // 金融機関情報を呼び出し、支店名の存在をチェック
        this.httpService.post(API_URL.BRANCH_EXIST_CHECK, { branchNameKanji: branch, bankNameKanji: bank })
            .map((response) => response.result)
            .subscribe((data) => {
                this.dispatcher.dispatch({
                    actionType: AutomaticTransferActionType.GET_TRANSFER_DESTINATION_BRANCH,
                    data: data
                });
            });
    }

    /**
     * 受取口座の口座番号の存在チェック
     * @param bank 銀行名
     * @param params 勘定APIパラメータ
     */
    public checkReceiptAccountNo(bank: string, item: string, params) {
        if (this.checkBankIsIyoBank(bank)) {
            let response;
            switch (item) {
                // 預金種目が「普通」の場合
                case AutomaticTransferAccountItem.ORDINARY:
                    response = this.checkReceiptAccountNoForOrdinaryItem(params);
                    break;
                // 預金種目が「当座」と「貯蓄」の場合
                case AutomaticTransferAccountItem.SAVINGS:
                case AutomaticTransferAccountItem.CURRENT:
                    response = this.checkReceiptAccountNoForOtherItem(params);
                    break;
            }
            response.subscribe((data) => {
                this.dispatcher.dispatch({
                    actionType: AutomaticTransferActionType.CHECK_RECEIPT_ACCOUNT_NO,
                    data: data
                });
            }, (error) => {
                this.dispatcher.dispatch({
                    actionType: AutomaticTransferActionType.CHECK_RECEIPT_ACCOUNT_NO,
                    data: {
                        errorResponse: error
                    }
                });
            });
        } else {
            this.dispatcher.dispatch({
                actionType: AutomaticTransferActionType.CHECK_RECEIPT_ACCOUNT_NO,
                data: {
                    receiptAccountNo: params.accountNo,
                }
            });
        }
    }

    /**
     * 振込先銀行チェック
     * @param bank 銀行名
     */
    public checkBankIsIyoBank(bank: string): boolean {
        return bank === COMMON_CONSTANTS.IYO_BANK_NAME;
    }

    /**
     * 預金種目が「普通」の場合、口座存在チェックをする
     * @param params 勘定APIパラメータ
     */
    private checkReceiptAccountNoForOrdinaryItem(params) {
        // CIF情報照会を呼出し、氏名カナを取得する。
        return this.httpService.post(API_URL.CB_GET_SIMPLE_CIF_INFORMATION, {
            path: CoreBankingConstants.ApiPathConsts.CIF_INFO_INQUIRY,
            tabletApplyId: params.tabletApplyId,
            userMngNo: params.userMngNo,
            params: params
        }, null, null, true).flatMap((response) => {
            const { cifInfoInquiryResponse, errorResponse } = response.result;
            if (errorResponse && errorResponse.wsp_res && errorResponse.wsp_res.code === COMMON_CONSTANTS.PROCESS_CODE_NG) {
                return Observable.throw(errorResponse);
            } else {
                return this.checkStudentAccountType(params)
                    .map((info) => {
                        return {
                            ...cifInfoInquiryResponse,
                            ...info,
                            receiptAccountNo: params.accountNo
                        };
                    });
            }
        });
    }

    private checkStudentAccountType(params) {
        return this.httpService.post(API_URL.CB_GET_ACCOUNT_BALANCE, {
            path: CoreBankingConstants.ApiPathConsts.ACCOUNT_BALANCE_INQUIRY,
            tabletApplyId: params.tabletApplyId,
            userMngNo: params.userMngNo,
            params: {
                accountInfoList: [{
                    accountNo: params.accountNo,
                    accountType: params.accountType,
                    tenban: params.tenban
                }],
                bankNo: params.bankNo,
                receptionNo: params.receptionNo,
                receptionTenban: params.receptionTenban,
                terminalNo: params.terminalNo
            }
        }).flatMap((response) => {
            const { responseList, errorResponse } = response.result;
            if (responseList) {
                return Observable.of(responseList.find((item) => item.tenban === params.tenban));
            } else {
                return Observable.throw(errorResponse);
            }
        });
    }

    /**
     * 預金種目が「当座」と「貯蓄」の場合、口座存在チェックをする
     * @param params 勘定APIパラメータ
     */
    private checkReceiptAccountNoForOtherItem(params) {
        // CIF情報照会を呼出し、氏名カナを取得する
        return this.httpService.post(API_URL.CB_GET_SIMPLE_CIF_INFORMATION, {
            path: CoreBankingConstants.ApiPathConsts.CIF_INFO_INQUIRY,
            tabletApplyId: params.tabletApplyId,
            userMngNo: params.userMngNo,
            params: params
        }, null, null, true).flatMap((response) => {
            const { cifInfoInquiryResponse, errorResponse } = response.result;
            if (errorResponse && errorResponse.wsp_res && errorResponse.wsp_res.code === COMMON_CONSTANTS.PROCESS_CODE_NG) {
                return Observable.throw(errorResponse);
            } else {
                return Observable.of({
                    ...cifInfoInquiryResponse,
                    receiptAccountNo: params.accountNo
                });
            }
        });
    }

    /**
     * システム時間を取得
     */
    private setSystemTime(automaticTransferActionType: string) {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: automaticTransferActionType,
                data: {
                    systemTime: response.result.value
                }
            });
        });
    }
}
