/**
 * 自動振込
 */
export class AutomaticTransferSubmitEntity {
    public customerApplyStartDate: string;             // 行員認証入力完了日時
    public bankclerkAuthenticationStartDate: string;
    public bankclerkAuthenticationEndDate: string;     // 入力内容確認完了行員認証時間
    public customerApplyEndDate: string;               // 入力内容確認完了時間
    public applyDate: string;                          // 手続き案内完了時間
    public bankclerkConfirmId: string;                 // 行員ID

    public branchNo: string;
    public branchNameKanji: string;

    public tabletApplyId: number;
    public userMngNo: string;
    public accountNo: string;
    public branchName: string;
    public agencyBranchNo: string;     // 取次店番
    public bankNo: string; // 銀行番号
    public terminalNo: string; // 端末番号
    public holderNameFurigana: string;

    // QRコード受付情報
    public swipeCif: string;                           // スワイプ店CIF
    public receptionBranchNo: string;                  // 受付店番
    public receptionNo: string;                        // 受付番号
    public receptionTime: string;                      // 受付年月日時分秒
    public swipeBranchNo: string;                      // カード店番
    public swipeAccountNo: string;                     // カード口座番号
    public swipeAccountType: string;                   // カード科目

    public holderAddressPrefecture: string;
    public holderAddressPrefectureFurigana: string;
    public holderAddressCountyUrbanVillage: string;
    public holderAddressCountyUrbanVillageFurigana: string;
    public holderIdentityDocumentAddressReason: string;
    public holderIdentityDocumentPhotographType: string;
    public holderIdentityDocumentAddressType: string;
    public holderIdentityDocumentNoCopyReason: string;
    public holderIdentityDocumentType: string;
    public holderNoCopyReason: string;
    public holderRemoteAddressReason: string;
    public holderPublisher: string;
    public holderPublishDate: string;
    public holderSignNo: string;
    public holderIdentityDocumentPublisher: string;
    public holderIdentityDocumentPublishDate: string;
    public holderIdentityDocumentSignNo: string;

    // 自動振込申込情報
    public registerCategory: string;                    // 登録区分
    public withdrawalBankName: string;                  // 申込人引落銀行
    public withdrawalBranchNo: string;                  // 申込人引落店番
    public withdrawalBranchName: string;                // 申込人引落店名（表示用）
    public withdrawalAccountItem: string;               // 申込人引落科目
    public withdrawalAccountItemText: string;           // 申込人引落科目テキスト（表示用）
    public withdrawalAccountNo: string;                 // 申込人引落口座番号
    public handlingNo: string;                          // 取扱番号
    public wireTransferContents: string;                // 振込資金の内容
    public kanaDetail: string;                          // カナ摘要
    public transferDestinationBank: string;             // 振込先銀行名
    public transferDestinationBankKana: string;         // 振込先銀行カナ名
    public transferDestinationBankCode: string;         // 金融機関コード
    public transferDestinationBranch: string;           // 振込先支店名
    public transferDestinationBranchKana: string;       // 振込先支店カナ名
    public transferDestinationBranchCode: string;       // 金融機関情報取得した店舗コード
    public receiptAccountItem: string;                  // 受取口座科目
    public receiptAccountNo: string;                    // 受取口座口座番号
    public beneficiaryName: string;                     // 受取人名
    public monthlyTransferDate: string;                 // 毎月振込日
    public handlingHolidays: string;                    // 休日の取扱い
    public reTransferProcess: string;                   // 再振込処理
    public transferStartDate: string;                   // 振込開始年月
    public transferEndDate: string;                     // 振込終了年月
    public transferEndDateSelect: string;               // 振込終了年月指定フラグ
    public monthlyTransferAmount: number;               // 毎月振込金額
    public monthlyExchangeFee: number;                  // 毎月為替手数料
    public specifiedTransferMonth1: string;             // 特定振込月１
    public specifiedTransferAmount1: number;            // 特定振込額１
    public specifiedExchangeFee1: number;               // 特定為替手数料１
    public specifiedTransferMonth2: string;             // 特定振込月２
    public specifiedTransferAmount2: number;            // 特定振込額２
    public specifiedExchangeFee2: number;               // 特定為替手数料２
    public handlingFee: number;                         // 取扱手数料
    public transferLastDate: string;                    // 最終振込年月
    public transferIyoStudent: string;
}
