import { Injectable, NgZone } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { LabelService } from 'adep/services';
import { AutomaticTransferActionType } from 'dhdt/branch/pages/automatic-transfer/action/automatic-transfer.action';
import { AutomaticTransferSubmitEntity } from 'dhdt/branch/pages/automatic-transfer/entity/automatic-transfer-submit.entity';
import { ReceptionInfoEntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/reception-info.entity';
import {
    ApplyBusinessType, AutomaticTransferStudentDepositType, COMMON_CONSTANTS, SubmitDataKey
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { CifInfoInquiryResponseEntity } from 'dhdt/branch/shared/entity/cif-info-inquiry-response.entity';
import {
    ChatFlowMessageInterface,
    ChatFlowMessageWithPageIndexInterface
} from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { CifInformationUtils } from 'dhdt/branch/shared/utils/cif-information-utils';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { App } from 'ionic-angular';
import * as moment from 'moment';
import { Observable } from 'rxjs/Observable';

export interface AutomaticTransferState extends State {
    studentAccountType: string;
    questions: ChatFlowMessageInterface[][];
    showChats: ChatFlowMessageWithPageIndexInterface[];
    showConfirm: ChatFlowMessageWithPageIndexInterface[];
    submitData: AutomaticTransferSubmitEntity;
    copySubmitData: AutomaticTransferSubmitEntity;
    currentFileInfo: any;
    wholeCif: string; // 全店CIF
    cifInfo: Array<{ branchCif: string, branchName: string, tenban: string }>; // 全店CIF情報
    otherAccountsList: any[];
    transferCancelList: any[];
    identityDocuments: string[];
    additionalInfoDocuments: string[];
    handlingFee: number;
}

export const AutomaticTransferStateSignal = {
    SEND_ANSWER: 'AutomaticTransferStateSignal_SEND_ANSWER',
    GET_QUESTION: 'AutomaticTransferStateSignal_GET_QUESTION',
    SUCCESS_INSERT_INFO: 'SAutomaticTransferStateSignal_UCCESS_INSERT_INFO',
    CHAT_FLOW_COMPELETE: 'AutomaticTransferStateSignal_CHAT_FLOW_COMPELETE',
    GET_CHECK_ACCOUNT_EXISTING: 'AutomaticTransferStateSignal_GET_CHECK_ACCOUNT_EXISTING',
    SUCCESS_SET_CUST_START_TIME: 'AutomaticTransferStateSignal_SUCCESS_SET_CUST_START_TIME',
    CIF_SIMPLE_INFORMATION_COMPLETE: 'AutomaticTransferStateSignal_CIF_SIMPLE_INFORMATION_COMPLETE',
    GET_ANCESTOR_CIF_INFO_COMPLETE: 'AutomaticTransferStateSignal_GET_ANCESTOR_CIF_INFO_COMPLETE',
    GET_ACCOUNT_WITHOUT_CARD: 'AutomaticTransferStateSignal_GET_ACCOUNT_WITHOUT_CARD',
    GET_TRANSFER_FEE: 'AutomaticTransferStateSignal_GET_TRANSFER_FEE',
    GET_WITHDRAWAL_FEE: 'AutomaticTransferStateSignal_GET_WITHDRAWAL_FEE',
    GET_CONTRACT_INFO: 'AutomaticTransferStateSignal_GET_CONTRACT_INFO',
    CIF_INFORMATION_COMPLETE: 'AutomaticTransferStateSignal_CIF_INFORMATION_COMPLETE',
    GET_CONFIRM_PAGE_TEMPLATE: 'AutomaticTransferStateSignal_GET_CONFIRM_PAGE_TEMPLATE',
    CHECK_TRANSFER_DESTINATION_BANK: 'AutomaticTransferStateSignal_CHECK_TRANSFER_DESTINATION_BANK',
    CHECK_TRANSFER_DESTINATION_BRANCH: 'AutomaticTransferStateSignal_CHECK_TRANSFER_DESTINATION_BRANCH',
    CHECK_TRANSFER_DESTINATION_ACCOUNT_NO: 'AutomaticTransferStateSignal_CHECK_TRANSFER_DESTINATION_ACCOUNT_NO',
    CHECK_STUDENT_DESTINATION_TYPE: 'AutomaticTransferStateSignal_CHECK_STUDENT_DESTINATION_TYPE',
    CHECK_BUSINESS_DAY: 'AutomaticTransferStateSignal_CHECK_BUSINESS_DAY',
    CUSTOMER_APPLY_END_DATE: 'AutomaticTransferStateSignal_CUSTOMER_APPLY_END_DATE',
    DISMISS_COMPONENT: 'AutomaticTransferStateSignal_DISMISS_COMPONENT'
};

@Injectable()
export class AutomaticTransferStore extends Store<AutomaticTransferState> {
    private keysArr: any[] = [];

    constructor(
        private ngZone: NgZone,
        private labelService: LabelService,
        private errorMessageService: ErrorMessageService,
        private editService: EditService,
        private appCtrl: App
    ) {
        super();
        this.state = {
            questions: [],
            showChats: [],
            submitData: new AutomaticTransferSubmitEntity(),
            copySubmitData: null,
            currentFileInfo: {},
            wholeCif: undefined,
            cifInfo: null,
            otherAccountsList: null,
            transferCancelList: null,
            showConfirm: [],
            identityDocuments: [],
            additionalInfoDocuments: [],
            studentAccountType: undefined,
            handlingFee: null
        };
    }

    /**
     * yamlファイル読込API呼び出し。
     * @param params yamlファイル読込用
     */
    @ActionBind(AutomaticTransferActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.saveCurrentYamlInfo(params.fileInfo[0]);
            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(AutomaticTransferStateSignal.GET_QUESTION, params.pageIndex);
        }
    }

    /**
     * Save yaml file Information
     * @param params yaml情報
     */
    private saveCurrentYamlInfo(params: any) {
        this.state.currentFileInfo.yamlId = params.id;
        this.state.currentFileInfo.screenId = params.screenId;
        this.state.currentFileInfo.screenName = params.screenName;
    }

    /**
     * stateを初期化。
     */
    @ActionBind(AutomaticTransferActionType.CLEAR)
    private clearStore() {
        this.keysArr = [];
        this.state = {
            questions: [],
            showChats: [],
            submitData: new AutomaticTransferSubmitEntity(),
            copySubmitData: null,
            currentFileInfo: {},
            wholeCif: undefined,
            cifInfo: null,
            otherAccountsList: null,
            transferCancelList: null,
            showConfirm: [],
            identityDocuments: [],
            additionalInfoDocuments: [],
            studentAccountType: undefined,
            handlingFee: null
        };
    }

    /**
     * 次チャットを呼び出し。
     * @param order yamlのorder
     * @param pageIndex ページ番号
     */
    @ActionBind(AutomaticTransferActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: { order: number, pageIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .min<ChatFlowMessageInterface>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: this.replaceChatMessage(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order
                        };
                        this.state.showChats.push(qus);
                        this.sendSignal(AutomaticTransferStateSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: this.replaceChatMessage(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order
                        };
                        this.state.showChats.push(qus);
                        this.sendSignal(AutomaticTransferStateSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => {
                // DO NOTHING
            });
        });
    }

    /**
     * Reset showConfirm
     * @param showConfirm showConfirm
     */
    @ActionBind(AutomaticTransferActionType.RESET_SHOW_CONFIRM)
    private resetShowConfirm(showConfirm) {
        this.state.showConfirm = showConfirm;
    }

    /**
     * 特定の月をクリア
     */
    @ActionBind(AutomaticTransferActionType.CLEAR_SPECIFIED_TRANSFER)
    private clearSpecifiedTransfer() {
        this.state.submitData.specifiedTransferMonth1 = null;
        this.state.submitData.specifiedTransferAmount1 = null;
        this.state.submitData.specifiedExchangeFee1 = null;

        this.state.submitData.specifiedTransferMonth2 = null;
        this.state.submitData.specifiedTransferAmount2 = null;
        this.state.submitData.specifiedExchangeFee2 = null;
    }

    /**
     * カナ摘要をクリア
     */
    @ActionBind(AutomaticTransferActionType.CLEAR_KANA_DETAIL)
    private clearKanaDetail() {
        this.state.submitData.kanaDetail = null;
    }

    /**
     * チャット文字を置換。
     * @param message チャット文字
     */
    private replaceChatMessage(message: string) {
        if (message.indexOf('@') === -1) {
            return message;
        }

        const replaceValues = [
            { key: '@handlingFee', value: this.priceChange(this.state.handlingFee) },
            {
                key: '@monthlyExchangeFee',
                value: this.priceChange(this.state.submitData.monthlyExchangeFee + this.state.handlingFee)
            },
            {
                key: '@specifiedExchangeFee1',
                value: this.priceChange(this.state.submitData.specifiedExchangeFee1 + this.state.handlingFee)
            },
            {
                key: '@specifiedExchangeFee2',
                value: this.priceChange(this.state.submitData.specifiedExchangeFee2 + this.state.handlingFee)
            }
        ];

        let result = message;
        replaceValues.forEach((element) => {
            if (result.indexOf(element.key) !== -1) {
                result = result.replace(element.key, String(element.value));
            }
        });

        return result;
    }

    /**
     * 顧客申し込み開始時間を設定する
     * @param systemTime システム時間
     */
    @ActionBind(AutomaticTransferActionType.SET_CUSTOMER_APPLY_START_DATE)
    private setCustomerApplyStartDate(date) {
        this.setSubmitData('customerApplyStartDate', date.systemTime);
    }

    /**
     * 顧客申し込み終了時間を設定する
     * @param systemTime システム時間
     */
    @ActionBind(AutomaticTransferActionType.SET_CUSTOMER_APPLY_END_DATE)
    private setCustomerApplyEndDate(data: { systemTime: string }) {
        this.setSubmitData('customerApplyEndDate', data.systemTime);
        this.sendSignal(AutomaticTransferStateSignal.CUSTOMER_APPLY_END_DATE);
    }

    /**
     * 行員ログインが完了した時間
     * @param systemTime システム時間
     */
    @ActionBind(AutomaticTransferActionType.SET_BANKCLERK_CONFIRM_START_DATE)
    private setBankclerkAuthenticationStartDate(data: { systemTime: string }) {
        this.setSubmitData('bankclerkAuthenticationStartDate', data.systemTime);
    }

    /**
     * 解約情報を設定
     */
    @ActionBind(AutomaticTransferActionType.SET_TRANSFER_CANCEL_INFO)
    private setTransferCancelInfo(data) {
        if (data) {
            // 取扱番号
            this.setSubmitData(SubmitDataKey.HANDLING_NO, data.handingNo);
            // 内容/摘要
            this.setSubmitData(SubmitDataKey.WIRE_TRANSFER_CONTENTS, data.contentsOfTransferFund);
            // 受取人名（カナ）
            this.setSubmitData(SubmitDataKey.BENEFICIARY_NAME, data.beneficiaryNameKana);
            // 引落指定銀行情報
            this.setSubmitData(SubmitDataKey.WITHDRAWAL_BANK_NAME, data.withdrawalBankName);
            this.setSubmitData(SubmitDataKey.WITHDRAWAL_BRANCH_NAME, data.withdrawalBranchName);
            this.setSubmitData(SubmitDataKey.WITHDRAWAL_BRANCH_NO, data.withdrawalBranchNo);
            this.setSubmitData(SubmitDataKey.WITHDRAWAL_ACCOUNT_ITEM, data.withdrawalAccountType);
            this.setSubmitData(SubmitDataKey.WITHDRAWAL_ACCOUNT_NO, data.withdrawalAccountNo);
            // 振込先銀行情報
            this.setSubmitData(SubmitDataKey.TRANSFER_DESTINATION_BANK, data.transferDestinationBankKana);
            this.setSubmitData(SubmitDataKey.TRANSFER_DESTINATION_BRANCH, data.transferDestinationBranchKana);
            this.setSubmitData(SubmitDataKey.TRANSFER_DESTINATION_ACCOUNT_NO, data.receivedAccountNo);
            this.setSubmitData(SubmitDataKey.TRANSFER_DESTINATION_ACCOUNT_ITEM, data.receivedAccountType);
            // 毎月振込情報
            this.setSubmitData(SubmitDataKey.MONTHLY_TRANSFER_DATE, data.monthlyTransferDate);
            this.setSubmitData(SubmitDataKey.MONTHLY_TRANSFER_AMOUNT, data.monthlyTransferAmount);
            // 特定振込月/金額 ①
            this.setSubmitData(SubmitDataKey.SPECIFIED_TRANSFER_MONTH_1, data.specifiedTransferMonth1);
            this.setSubmitData(SubmitDataKey.SPECIFIED_TRANSFER_AMOUNT1, data.specifiedTransferAmount1);
            // 特定振込月/金額 ②
            this.setSubmitData(SubmitDataKey.SPECIFIED_TRANSFER_MONTH_2, data.specifiedTransferMonth2);
            this.setSubmitData(SubmitDataKey.SPECIFIED_TRANSFER_AMOUNT2, data.specifiedTransferAmount2);
            // 振込終了年月
            this.setSubmitData(SubmitDataKey.TRANSFER_END_DATE, data.transferEndDate);
            // 内容／摘要(その他)
            this.setSubmitData(SubmitDataKey.KANA_DETAIL, data.summaryKana);
        }
    }

    /**
     * スワイプカードの口座引落指定口座にを設定
     */
    @ActionBind(AutomaticTransferActionType.SET_SWIPE_CARD_TO_SUBMIT_DATA)
    private setSwipeCardToWithdrawalAccount() {
        this.setStateSubmitDataValue({
            name: SubmitDataKey.WITHDRAWAL_BRANCH_NO,
            value: this.state.submitData.swipeBranchNo
        });
        this.setStateSubmitDataValue({
            name: SubmitDataKey.WITHDRAWAL_BRANCH_NAME,
            value: this.state.submitData.branchName
        });
        this.setStateSubmitDataValue({
            name: SubmitDataKey.WITHDRAWAL_ACCOUNT_ITEM,
            value: this.state.submitData.swipeAccountType
        });
        this.setStateSubmitDataValue({
            name: SubmitDataKey.WITHDRAWAL_ACCOUNT_NO,
            value: this.state.submitData.swipeAccountNo
        });
    }

    /**
     * 修正ボタン押下時の処理。
     * @param params yamlのorder,ページ番号
     */
    @ActionBind(AutomaticTransferActionType.EDIT_CHAT)
    private editChat(params: { order: number, pageIndex: number, answerOrder: number, showChatIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;

        let i = -1;
        let index = -1;
        if (params.showChatIndex) {
            index = params.showChatIndex;
        } else {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order) {
                    index = i;
                }
            });
        }

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }

        this.cleanSubmitData(answerOrder);
    }

    /**
     * 顧客入力情報をstateにセット。
     * @param answer 顧客入力情報
     */
    @ActionBind(AutomaticTransferActionType.SET_ANSWER)
    private setAnswer(answer: { order: number, text: string, value: Array<{ key: string, value: string }> }) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        answer.order = this.keysArr.length;
        chat.answer = answer;
        if (answer.value) {
            answer.value.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    /**
     * state.submitDataにデータをセット。
     * @param data
     */
    @ActionBind(AutomaticTransferActionType.SET_STATE_SUBMIT_DATA_VALUE)
    private setStateSubmitDataValue(data: any) {
        if (data) {
            this.setSubmitData(data.name, data.value);
        }
    }

    /**
     * 手数料をセット
     */
    @ActionBind(AutomaticTransferActionType.SET_EXCHANGE_FEE)
    private setExchangeFee(data) {
        const { name, fee } = data;
        switch (name) {
            case SubmitDataKey.MONTHLY_TRANSFER_AMOUNT:
                this.setSubmitData(SubmitDataKey.MONTHLY_EXCHANGE_FEE, fee);
                break;
            case SubmitDataKey.SPECIFIED_TRANSFER_AMOUNT1:
                this.setSubmitData(SubmitDataKey.SPECIFIED_EXCHANGE_FEE_1, fee);
                break;
            case SubmitDataKey.SPECIFIED_TRANSFER_AMOUNT2:
                this.setSubmitData(SubmitDataKey.SPECIFIED_EXCHANGE_FEE_2, fee);
                break;
        }
    }

    /**
     * チャット情報を初期化。
     */
    @ActionBind(AutomaticTransferActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    /**
     * submitDataをバックアップ。
     */
    @ActionBind(AutomaticTransferActionType.SUBMIT_DATA_BACKUP)
    private submitDataBackup() {
        this.state.copySubmitData = Object.assign(new AutomaticTransferSubmitEntity(), this.state.submitData);
    }

    /**
     * submitDataをリストア。
     */
    @ActionBind(AutomaticTransferActionType.SUBMIT_DATA_RESTORE)
    private submitDataRestore() {
        this.state.submitData = Object.assign(new AutomaticTransferSubmitEntity(), this.state.copySubmitData);
        this.state.copySubmitData = null;
    }

    /**
     * コードマスタの情報を取得する
     *
     * @param data
     */
    @ActionBind(AutomaticTransferActionType.RETRIEVE_DROP_LIST)
    private retrieveDropList(data) {
        // this.state.dropDownList = data;
    }

    /**
     * 行員認証情報をサブミットする
     *
     * @param data データ
     */
    @ActionBind(AutomaticTransferActionType.BRANCH_INFO_INSERT)
    private branchInfoInsert(data) {
        this.sendSignal(AutomaticTransferStateSignal.SUCCESS_INSERT_INFO);
    }

    /**
     * チャットが完了
     * @param nextChatName 次のチャットの名
     */
    @ActionBind(AutomaticTransferActionType.CHAT_FLOW_COMPELETE)
    private chatFlowCompelete(nextChatName: string) {
        this.sendSignal(AutomaticTransferStateSignal.CHAT_FLOW_COMPELETE, nextChatName);
    }

    /**
     * 最後のノードをチェックする
     * @param params パラメーター
     */
    @ActionBind(AutomaticTransferActionType.RESET_LAST_NODE)
    private resetLastNode(params: { order: number, pageIndex: number }) {
        const lastNode = this.getState().showChats.pop();
        this.getNextChatByAnswer({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    /**
     * ConfirmデータをStateにセットする
     * @param params
     */
    @ActionBind(AutomaticTransferActionType.GET_CONFIRM_PAGE_TEMPLATE)
    private loadConfirmTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(AutomaticTransferStateSignal.GET_CONFIRM_PAGE_TEMPLATE, params.pageIndex);
        }
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param data QRコード受付情報
     */
    @ActionBind(AutomaticTransferActionType.SET_SWIPE_INFO)
    private setSwipeInfo(data: ReceptionInfoEntity) {
        // QRコードを読み込む場合
        if (data) {
            this.setSubmitData('swipeCif', data.branchCif);
            this.setSubmitData('swipeBranchNo', data.cardBranchNo);
            this.setSubmitData('swipeAccountNo', data.cardAccountNo);
            this.setSubmitData('swipeAccountType', data.cardAccountType);

            this.setSubmitData('receptionBranchNo', data.receptionBranchNo);
            this.setSubmitData('receptionNo', data.receptionNo);
            this.setSubmitData('receptionTime', data.receptionTime);
        }
    }

    /**
     * CIF情報照会設定
     * @param data response data
     */
    @ActionBind(AutomaticTransferActionType.SET_CIF_INFORMATION)
    private setCifInformation(response) {
        if (response && response.data) {
            this.settingCifInformation(response.data.cifInfoInquiryResponse);
            this.state.cifInfo = response.data.cifInfo;
        }
        this.sendSignal(AutomaticTransferStateSignal.GET_ANCESTOR_CIF_INFO_COMPLETE);
    }

    /**
     * SubmitDataに本人基本情報設定を行う
     * @param entity CIF情報エンティティ
     */
    private settingCifInformation(entity: CifInfoInquiryResponseEntity) {
        // 基本情報を設定する
        CifInformationUtils.setCifBasicInfoForCommon(this.state.submitData, this.keysArr, entity);
        // regionCode
        this.setSubmitData('holderRegionCode', entity.regionCode);

        this.setSubmitData('accountNo', entity.accountNo);
        this.setSubmitData('branchName', entity.branchName);
    }

    /**
     * CIF情報照会情報
     * @param params CIF情報照会用パラメータ
     */
    @ActionBind(AutomaticTransferActionType.SET_SIMPLE_CIF_INFORMATION)
    private getSimpleCifInformation(data: any) {
        this.settingCifInformation(data.data.cifInfoInquiryResponse);
        this.sendSignal(AutomaticTransferStateSignal.CIF_SIMPLE_INFORMATION_COMPLETE, data);
    }

    /**
     * 行員IDをstateにセット。
     */
    @ActionBind(AutomaticTransferActionType.SET_BANKCLERK_ID)
    private setBankclerkId(params: any) {
        this.setSubmitData('bankclerkConfirmId', params.bankclerkId);
    }

    /**
     * 取次店情報をstateにセット。
     * @param params 店番
     */
    @ActionBind(AutomaticTransferActionType.SET_AGENCY_BRANCH_INFO)
    private setAgencyBranchInfo(params: any) {
        this.setSubmitData('agencyBranchNo', params.branchNo);
    }

    /**
     * 行員認証入力完了日時を設定する
     */
    @ActionBind(AutomaticTransferActionType.SET_BANKCLERK_CONFIRM_DATE)
    private setBankclerkAuthenticationEndDate(data: { systemTime: string }) {
        this.setSubmitData('bankclerkAuthenticationEndDate', data.systemTime);
    }

    /**
     * 入力内容確認完了時間を設定する
     */
    @ActionBind(AutomaticTransferActionType.SET_INPUTCONTENT_CONFIRMATION_DATE)
    private setInputContentConfirmationDate(data: { systemTime: string }) {
        this.setSubmitData('customerApplyEndDate', data.systemTime);
    }

    /**
     * 手続き案内完了時間を設定する
     */
    @ActionBind(AutomaticTransferActionType.SET_PROCEDUREGUIDE_COMPLETE_DATE)
    private setProcedureGuideCompleteDate(data: { systemTime: string }) {
        this.setSubmitData('applyDate', data.systemTime);
    }

    /**
     * 口座情報照会
     */
    @ActionBind(AutomaticTransferActionType.GET_ACCOUNT_WITHOUT_CARD)
    private getAccountWithoutCard(data) {
        this.state.otherAccountsList = data.accountInfo;
        this.sendSignal(AutomaticTransferStateSignal.GET_ACCOUNT_WITHOUT_CARD, data.accountInfo);
    }

    /**
     * 自動振込契約明細照会
     */
    @ActionBind(AutomaticTransferActionType.GET_CONTRACT_INFO)
    private getContractInfo(data) {
        if (data.errorResponse && data.errorResponse.wsp_res
            && data.errorResponse.wsp_res.code === COMMON_CONSTANTS.PROCESS_CODE_NG) {
            const message = this.errorMessageService.getMessageFromExternalError({
                errReason: data.errorResponse.values.errReason,
                applyBusinessType: ApplyBusinessType.AUTOMATIC_TRANSFER,
                processNo: undefined,
                uri: undefined
            });
            this.errorMessageService.showMessageModal(message, () => {
                this.appCtrl.getRootNav().setRoot(TopComponent);
                this.clearStore();
            });
        } else {
            this.state.transferCancelList = data.automaticTransferInfo || [];
            this.sendSignal(AutomaticTransferStateSignal.GET_CONTRACT_INFO, this.state.transferCancelList);
        }
    }

    /**
     *  行員確認の入力データをクリアする
     */
    @ActionBind(AutomaticTransferActionType.CLEAR_CONFIRM_PAGE_INFO)
    private clearConfirmPageInfo() {
        // 本人確認書類
        this.setSubmitData('holderIdentityDocumentType', null);
        // 本人確認書類をクリアする
        this.state.identityDocuments = [];
        // 本人確認補完書類をクリアする
        this.state.additionalInfoDocuments = [];
        // 遠隔地等住所等の場合の理由
        this.setSubmitData('holderRemoteAddressReason', null);
        // 住所が相違する理由
        this.setSubmitData('holderIdentityDocumentAddressReason', null);
        // コピー徴求ができない理由
        this.setSubmitData('holderIdentityDocumentNoCopyReason', null);
        // 発行元
        this.setSubmitData('holderIdentityDocumentPublisher', null);
        // 発行日
        this.setSubmitData('holderIdentityDocumentPublishDate', null);
        // 記号番号
        this.setSubmitData('holderIdentityDocumentSignNo', null);
        // コピー徴求ができない理由
        this.setSubmitData('holderNoCopyReason', null);
        // 発行元
        this.setSubmitData('holderPublisher', null);
        // 発行日
        this.setSubmitData('holderPublishDate', null);
        // 記号番号
        this.setSubmitData('holderSignNo', null);
        // 顔写真のない本人確認書類の場合の補完書類
        this.setSubmitData('holderIdentityDocumentPhotographType', null);
        // 本人確認書類の住所と現住所が異なる場合の補完書類
        this.setSubmitData('holderIdentityDocumentAddressType', null);
    }

    /**
     * 営業日チェック
     * @param param 営業日チェックパラメータ
     */
    @ActionBind(AutomaticTransferActionType.CHECK_BUSINESS_DAY)
    private checkBusinessDay(data) {
        const { businessdayCheckResponseBean } = data;
        this.sendSignal(AutomaticTransferStateSignal.CHECK_BUSINESS_DAY, businessdayCheckResponseBean);
    }

    /**
     * 銀行名の存在チェック
     * @param bank 銀行名
     */
    @ActionBind(AutomaticTransferActionType.GET_TRANSFER_DESTINATION_BANK)
    private checkTransferDestinationBank(data) {
        if (data) {
            const { formalBankNameKanji, formalBankNameKana, bankCode } = data;
            this.setSubmitData('transferDestinationBank', formalBankNameKanji);
            this.setSubmitData('transferDestinationBankCode', bankCode);

            // 半角カナ、小カナ含まず
            const kana = StringUtils.convertZankaku2Hankaku(formalBankNameKana);
            this.setSubmitData('transferDestinationBankKana', StringUtils.converContractedSound2HankakuKata(kana));
            this.sendSignal(AutomaticTransferStateSignal.CHECK_TRANSFER_DESTINATION_BANK);
        } else {
            // 銀行名不存在の場合
            this.sendSignal(AutomaticTransferStateSignal.CHECK_TRANSFER_DESTINATION_BANK, {
                message: this.labelService.labels.automaticTransfer.message.notBank
            });
        }
    }

    /**
     * 支店名の存在チェック
     * @param branch 支店名
     */
    @ActionBind(AutomaticTransferActionType.GET_TRANSFER_DESTINATION_BRANCH)
    private checkTransferDestinationBranch(data) {
        if (data) {
            const { branchNameKanji, branchNameKana, branchCode } = data;

            this.setSubmitData('transferDestinationBranch', branchNameKanji);
            this.setSubmitData('transferDestinationBranchCode', branchCode);

            // 半角カナ、小カナ含まず
            const kana = StringUtils.convertZankaku2Hankaku(branchNameKana);
            this.setSubmitData('transferDestinationBranchKana', StringUtils.converContractedSound2HankakuKata(kana));
            this.sendSignal(AutomaticTransferStateSignal.CHECK_TRANSFER_DESTINATION_BRANCH);
        } else {
            this.sendSignal(AutomaticTransferStateSignal.CHECK_TRANSFER_DESTINATION_BRANCH, {
                message: this.labelService.labels.automaticTransfer.message.notBranch
            });
        }
    }

    /**
     * 受取口座の口座番号の存在チェック
     * @param data 口座番号の存在チェック結果
     */
    @ActionBind(AutomaticTransferActionType.CHECK_RECEIPT_ACCOUNT_NO)
    private checkReceiptAccountNo(data) {
        if (data) {
            this.state.submitData.receiptAccountNo = data.receiptAccountNo;
            this.state.submitData.beneficiaryName = data.nameKana;
            this.state.studentAccountType = data.studentAccountType || AutomaticTransferStudentDepositType.NOT_STUDENT;

            this.state.submitData.transferIyoStudent = this.state.studentAccountType === AutomaticTransferStudentDepositType.STUDENT ?
                COMMON_CONSTANTS.AUTOMATIC_TRANSFER_IYO_STUDENT : null;
        }

        this.sendSignal(AutomaticTransferStateSignal.CHECK_TRANSFER_DESTINATION_ACCOUNT_NO, {
            reason: data && data.errorResponse && data.errorResponse.values ? data.errorResponse.values.errReason : null
        });
    }

    /**
     * 毎月振込額に発生する振込手数料を取得
     */
    @ActionBind(AutomaticTransferActionType.GET_TRANSFER_FEE)
    private getTransferFee(data) {
        const { transferFeeResponseBean, errorResponse } = data.result;
        const amount = transferFeeResponseBean && transferFeeResponseBean.commissionAmount ?
            Number(transferFeeResponseBean.commissionAmount) : 0;

        if (data.key === SubmitDataKey.HANDLING_FEE) {
            this.state.handlingFee = amount;
        } else {
            this.setSubmitData(data.key, amount);
        }

        this.sendSignal(AutomaticTransferStateSignal.GET_TRANSFER_FEE);
    }

    /**
     * 毎月振込額と特定の月の振込金額に発生する振込手数料を取得
     * @param params 毎月振込額と特定の月の振込金額
     */
    @ActionBind(AutomaticTransferActionType.GET_WITHDRAWAL_FEE)
    private getWithdrawalFee(data) {
        if (data) {
            data.forEach((element) => {
                this.setSubmitData(element.key, element.value);
            });
        }
        this.sendSignal(AutomaticTransferStateSignal.GET_WITHDRAWAL_FEE);
    }

    /**
     * dismiss component
     */
    @ActionBind(AutomaticTransferActionType.DISMISS_COMPONENT)
    private dismissComponent() {
        this.sendSignal(AutomaticTransferStateSignal.DISMISS_COMPONENT);
    }

    /**
     * submit dataをセットする
     *
     * @param key キー
     * @param value 値
     */
    private setSubmitData(key, value) {
        if (key !== undefined) {
            this.state.submitData[key] = value;
            this.keyPush(key, value);
        }
    }

    /**
     * キーと値を配列に保存する
     *
     * @param key キー
     * @param value 値
     */
    private keyPush(key: any, value: any) {
        if (value === null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                this.keysArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1) {
            this.keysArr.push(key);
        } else {
            const index = this.keysArr.indexOf(key);
            this.keysArr[index] = moment().format('YYYYMMDDHHmmss');
            this.keysArr.push(key);
        }
    }

    /**
     * submit dataにremain以降の値をクリーンする
     * @param remain
     */
    private cleanSubmitData(remain: number) {
        this.keysArr = this.keysArr.slice(0, remain);
        for (const item in this.state.submitData) {
            if (item.startsWith('get')) {
                continue;
            }

            if (this.keysArr.indexOf(item) < 0) {
                this.state.submitData[item] = undefined;
            }
        }
    }

    /**
     * 手数料format
     * @param amount 手数料
     */
    private priceChange(amount: number) {
        if (amount) {
            return InputUtils.priceChange(String(amount));
        }
        return 0;
    }
}
