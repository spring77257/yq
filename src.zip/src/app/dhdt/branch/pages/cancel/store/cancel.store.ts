import { Injectable, NgZone } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { CancelAction, CancelActionType } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelListEntity } from 'dhdt/branch/pages/cancel/entity/cancel-list.entity';
import { CancelSubmitEntity, CheckboxStatusEntity, identificationDoc } from 'dhdt/branch/pages/cancel/entity/cancel-submit.entity';
import { DepositDetailsCountListEntity } from 'dhdt/branch/pages/cancel/entity/deposit-details-count-list.entity';
import { ClearChangeImagesClickRecordType, SubmitDataKey } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfoInquiryResponseEntity } from 'dhdt/branch/shared/entity/cif-info-inquiry-response.entity';
import { ChatFlowQuestionTypes } from 'dhdt/branch/shared/modules/chat-flow/chat-flow-question-types';
import {
    ChatFlowMessageInterface, ChatFlowMessageWithPageIndexInterface
    } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { Observable } from 'rxjs';

export interface CancelState extends State {
    questions: ChatFlowMessageInterface[][];
    showChats: ChatFlowMessageWithPageIndexInterface[];
    showConfirm: ChatFlowMessageWithPageIndexInterface[];
    submitData: CancelSubmitEntity;
    tabletStartDate: string;
    customerApplyStartDate: string;
    tabletApplyId: number;
    identityDocuments: string[];
    copySubmitData: CancelSubmitEntity;
    cancelableList: CancelListEntity[];
    depositDetailsCountList: DepositDetailsCountListEntity[];
    cifInfoInquiryList: CifInfoInquiryResponseEntity[];
    currentFileInfo: any;
    checkboxStatus: CheckboxStatusEntity;
    // 各書類の画像について、マスキングされていない画像のIndexを格納するオブジェクト
    notMaskingConfirmImages: {
        identificationDoc1Images: number[],
        identificationDoc2Images: number[]
    };
    isModify: boolean;
}

export const CancelSignal = {
    SEND_ANSWER: 'SEND_ANSWER',
    GET_QUESTION: 'GET_QUESTION',
    SUCCESS_VALIDATION: 'SUCCESS_VALIDATION',
    FAILED_VALIDATION: 'FAILED_VALIDATION',
    SUCCESS_INSERT_INFO: 'SUCCESS_INSERT_INFO',
    CHAT_FLOW_COMPELETE: 'CHAT_FLOW_COMPELETE',

    DONE_GET_LIST: 'DONE_GET_LIST',
    DONE_GET_CIF_INFO: 'DONE_GET_CIF_INFO',
    CANCEL_COMPLETE: 'CANCEL_COMPLETE',
    SUCCESS_INSERT_CANCEL_INFO: 'SUCCESS_INSERT_CANCEL_INFO',

    GET_CANCELABLE_LIST: 'GET_CANCELABLE_LIST',
    GET_CANCEL_RATE_LIST: 'GET_CANCEL_RATE_LIST',
    RECEPTION_CHECK: 'RECEPTION_CHECK',
    RESET_CANCEL_LIST: 'RESET_CANCEL_LIST',
};

@Injectable()
export class CancelStore extends Store<CancelState> {
    private keysArr: any[] = [];

    constructor(private action: CancelAction,
                private ngZone: NgZone,
                private editService: EditService) {
        super();
        this.state = {
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new CancelSubmitEntity(),
            tabletStartDate: '',
            customerApplyStartDate: '',
            tabletApplyId: -1,
            identityDocuments: [],
            copySubmitData: null,
            cancelableList: new Array(),
            depositDetailsCountList: new Array(),
            cifInfoInquiryList: new Array<CifInfoInquiryResponseEntity>(),
            currentFileInfo: {},
            checkboxStatus: {
                isAllMaskingStatus: false
            },
            // 各書類の画像について、マスキングされていない画像のIndexを格納するオブジェクト
            notMaskingConfirmImages: {
                identificationDoc1Images: [],
                identificationDoc2Images: []
            },
            isModify: false,
        };
    }

    /**
     * yamlをセット。
     * @param params APIのレスポンス
     */
    @ActionBind(CancelActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.saveCurrentYamlInfo(params.fileInfo[0]);

            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(CancelSignal.GET_QUESTION, params.pageIndex);
        }
    }

    /**
     * タブレット申込管理番号をstateにセット。
     * @param data APIのレスポンス
     */
    @ActionBind(CancelActionType.BRANCH_STATUS_INSERT)
    private branchStatusInsert(data: any) {
        if (data) {
            this.state.tabletApplyId = data;
            this.setSubmitData('tabletApplyId', data);
        }
    }

    /**
     * stateを初期化。
     */
    @ActionBind(CancelActionType.CLEAR)
    private clearStore() {
        this.state = {
            questions: [],
            showChats: [],
            showConfirm: [],
            submitData: new CancelSubmitEntity(),
            tabletStartDate: '',
            customerApplyStartDate: '',
            tabletApplyId: -1,
            identityDocuments: [],
            copySubmitData: null,
            cancelableList: new Array(),
            depositDetailsCountList: new Array(),
            cifInfoInquiryList: new Array<CifInfoInquiryResponseEntity>(),
            currentFileInfo: {},
            checkboxStatus: {
                isAllMaskingStatus: false
            },
            // 各書類の画像について、マスキングされていない画像のIndexを格納するオブジェクト
            notMaskingConfirmImages: {
                identificationDoc1Images: [],
                identificationDoc2Images: []
            },
            isModify: false,
        };
    }

    @ActionBind(CancelActionType.CLEAR_DOCUMENTS)
    private clearStoreDocuments() {
        this.state.identityDocuments = [];
        // 受付番号（EQ番号）
        this.setSubmitData('receptionNumber', null);
        // 本人確認-チェックボックス
        this.setSubmitData('selfConfrimStatus', null);
        // 本人確認書類
        this.setSubmitData('identificationDoc', null);
        // 記号番号
        this.setSubmitData('markNo', null);
        // 解約理由
        this.setSubmitData('cancelReason', null);
    }

    /**
     * 次チャットを読込。
     * @param params yamlのorder,ページ番号
     */
    @ActionBind(CancelActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: { order: number, pageIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .min<ChatFlowMessageInterface>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: item.question,
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                        };
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        this.sendSignal(CancelSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: this.replaceChatMessage(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                        };
                        this.state.showChats.push(qus);
                        this.state.showConfirm.push(qus);
                        this.sendSignal(CancelSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => { console.log('Outside Done!'); });
        });
    }

    /**
     * 修正ボタン押下時の処理。
     * @param params yamlのorder,ページ番号
     */
    @ActionBind(CancelActionType.EDIT_CHAT)
    private editChat(params: { order: number, pageIndex: number, answerOrder: number, showChatIndex: number }) {
        const oldShowChat: ChatFlowMessageWithPageIndexInterface[] = JSON.parse(JSON.stringify(this.state.showChats));
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;

        let i = -1;
        let index = -1;
        if (params.showChatIndex) {
            index = params.showChatIndex;
        } else {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order) {
                    index = i;
                }
            });
        }

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }
        this.cleanSubmitData(answerOrder);

        // 書類聴取情報を回答履歴よりリストアする
        this.restoreCheckInfo(this.state.showChats);
        // 書類徴取の修正チャット時に、画像をクリアする。
        this.cleanCheckInfoInModifyChat(this.state.showChats, oldShowChat);

    }

    /**
     * 書類聴取情報を回答履歴よりリストアする<br/>
     * ※複数回更新される値について、鉛筆修正で戻した時点での選択値の情報にてリストアする
     *
     * @private
     * @memberof CancelStore
     */
    private restoreCheckInfo(showChats: ChatFlowMessageWithPageIndexInterface[]) {

        // リストア対象
        const restoreTargetKeyList = [
            // 本人確認書類1(コード値、表示名)
            identificationDoc.identificationDoc1,
            identificationDoc.identificationDoc1Text,
            identificationDoc.identificationDoc1NameInput,
            // 本人確認書類2(表示名)
           identificationDoc.identificationDoc2NameInput,
        ];

        // 回答履歴のanswerより、keyの一致する値のうち最後に設定したものをリストアする値とする
        this.restoreByLatestAnswer(restoreTargetKeyList, showChats, undefined);
    }

    /**
     * 回答履歴のanswerを参照して値をリストアする<br/>
     *
     * @private
     * @memberof CancelStore
     */
    private restoreByLatestAnswer(
        restoreTargetKeyList: identificationDoc[], showChats: ChatFlowMessageWithPageIndexInterface[], initialValue: any) {
        restoreTargetKeyList.forEach((targetKey: string) => {
            let restoreValue: any;
            // keyがshowChatに存在するかどうか
            let isInShowChat: boolean;
            showChats.forEach((chat: ChatFlowMessageWithPageIndexInterface) => {
                if (chat.answer && chat.answer.value) {
                    if (Array.isArray(chat.answer.value)) {
                        chat.answer.value.forEach((answerValue: any) => {
                            if (targetKey === answerValue.key) {
                                isInShowChat = true;
                                restoreValue = answerValue.value;
                            }
                        });
                    } else {
                        if (targetKey === chat.answer.value.key) {
                            isInShowChat = true;
                            restoreValue = chat.answer.value.value;
                        }
                    }
                }
            });
            // keyがshowChatに存在しないかつkeysArrayに存在する（別チャットで回答）場合、値を変更しない。
            if (!isInShowChat && this.keysArr.indexOf(targetKey) > -1) {
                return;
            }
            // 一致しなかった場合(一度も回答していない状態)、初期値を設定
            this.state.submitData[targetKey] = restoreValue ? restoreValue : initialValue;
        });
    }

    /**
     * 書類徴取の修正チャット時に、ShowChatの変化をトリガーに画像をクリアする。
     * 修正チャットの鉛筆修正で,identificationDocumentImagesがクリアされないことの対処。
     * @private
     * @memberof LossReissueFindingStore
     */
    private cleanCheckInfoInModifyChat(
        latestShowChat: ChatFlowMessageWithPageIndexInterface[], oldShowChat: ChatFlowMessageWithPageIndexInterface[]) {

        const cleanTargetKeyList = [
            // 削除対象：本人確認書類１（画像）・本人確認書類２（画像）
            identificationDoc.identificationDoc1Images,
            identificationDoc.identificationDoc2Images,
        ];

        cleanTargetKeyList.forEach((targetKey: string) => {
            // 鉛筆修正後のShowChatに、cameraButtonが含まれているか
            let isInLatestShowChat: boolean = false;
            latestShowChat.forEach((chat: ChatFlowMessageWithPageIndexInterface) => {
                if (chat.name === targetKey && chat.type === ChatFlowQuestionTypes.CAMERA_BUTTON) {
                    isInLatestShowChat = true;
                }
            });
            // 鉛筆修正前のShowChatに、cameraButtonが含まれているか
            let isInOldShowChat: boolean = false;
            oldShowChat.forEach((chat: ChatFlowMessageWithPageIndexInterface) => {
                if (chat.name === targetKey && chat.type === ChatFlowQuestionTypes.CAMERA_BUTTON) {
                    isInOldShowChat = true;
                }
            });

            if (isInOldShowChat && !isInLatestShowChat) {
                // 鉛筆修正前後で「ShowChatに含まれる→含まれない」と変化した場合、クリアを実施する。
                this.state.submitData[targetKey] = undefined;
            }
        });
    }

    /**
     * 指定したノードまでリセットする
     * @param params パラメーター
     */
    @ActionBind(CancelActionType.RESET_TO_NODE)
    private resetToNode(params: { order: number, pageIndex: number }) {
        this.getState().showChats.pop();
        this.getNextChatByAnswer(params);
    }

    /**
     * 本人確認書類画像を保存
     */
    @ActionBind(CancelActionType.SAVE_DOCUMENT_IMAGE)
    private saveIdentityDocumentImage(data: { submitKey: string, image: string }) {
        this.setSubmitData(
            data.submitKey,
            this.state.submitData[data.submitKey] ?
                [...this.state.submitData[data.submitKey], data.image] : [data.image]
        );
    }

    /**
     * マスキング済みの画像を格納する
     */
    @ActionBind(CancelActionType.EDIT_SUBMIT_DATA)
    private editSubmitData(data: { index: number, key: string, val: string }) {
        if (data.key) {
            switch (data.key) {
                default: // 本人確認書類1、本人確認書類2
                    this.state.submitData[data.key][data.index] = data.val;
            }
        }
    }

    /**
     * modify checkbox status
     * @param name the checbox item need to modify status
     */
    @ActionBind(CancelActionType.MODIFY_CHECKBOX_STATUS)
    private modifyCheckboxStatus(name: string) {
        this.state.checkboxStatus[name] = !this.state.checkboxStatus[name];
    }

    /**
     * 未マスキング状態管理オブジェクトからマスキング完了済み画像のindexを削除する
     */
    @ActionBind(CancelActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES)
    private removeNotMaskingConfirmImages(data: { documentName: string, index: number }) {
        const { documentName, index } = data;
        this.state.notMaskingConfirmImages[documentName].splice(index, 1);
    }

    /**
     * 未マスキング状態管理オブジェクトをリセットする
     */
    @ActionBind(CancelActionType.RESET_NOT_MASKING_CONFIRM_IMAGES)
    private resetNotMaskingConfirmImages(type: ClearChangeImagesClickRecordType) {
        const _documentResetFn = (documentName: string) => {
            this.state.notMaskingConfirmImages[documentName] = [];
            switch (documentName) {
                default: // 本人確認書類1、本人確認書類2
                    if (this.state.submitData[documentName]) {
                        this.state.submitData[documentName].forEach(
                            (item, index) => {
                                this.state.notMaskingConfirmImages[documentName].push(index);
                            }
                        );
                    }
            }
        };
        switch (type) {
            case ClearChangeImagesClickRecordType.CHANGE_DOCUMENT:
                // 未マスキング状態管理オブジェクトに各書類パターンの全画像のindexを格納する
                Object.keys(this.state.notMaskingConfirmImages).forEach(
                    (atrribute) => {
                        _documentResetFn(atrribute);
                    }
                );
                break;
            case ClearChangeImagesClickRecordType.CLEAR:
                // 未マスキング状態管理オブジェクトをクリアする
                this.state.notMaskingConfirmImages = {
                    identificationDoc1Images: [],
                    identificationDoc2Images: []
                };
                break;
            default:
                break;
        }
    }

    /**
     * 書類聴取チャットにおける回答内容をクリアする
     */
    @ActionBind(CancelActionType.CLEAR_CANCEL_DOCUMENTS)
    private clearCancelDocuments() {
        this.state.submitData.identificationDoc1 = null;
        this.state.submitData.identificationDoc1Text = null;
        this.state.submitData.identificationDoc1Images = null;
        this.state.submitData.identificationDoc1NameInput = null;
        this.state.submitData.identificationDoc2Images = null;
        this.state.submitData.identificationDoc2NameInput = null;
    }

    /**
     * 書類聴取チャットにおける回答内容をクリアする
     */
    @ActionBind(CancelActionType.CLEAR_CANCEL_REASON)
    private clearCancelReason() {
        this.state.submitData.cancelReason = null;
    }

    /**
     * reset checkbox status
     */
    @ActionBind(CancelActionType.RESET_CHECKBOX_STATUS)
    private resetCheckboxStatus() {
        this.state.checkboxStatus = {
            isAllMaskingStatus: false
        };
    }

    /**
     * 顧客入力情報をstateにセット。
     * @param answer 顧客入力情報
     */
    @ActionBind(CancelActionType.SET_ANSWER)
    private setAnswer(answer: { order: number, text: string, value: Array<{ key: string, value: string }> }) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        answer.order = this.keysArr.length;
        chat.answer = answer;
        if (answer.value) {
            answer.value.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    /**
     * state.submitDataにデータをセット。
     * @param data
     */
    @ActionBind(CancelActionType.SET_STATE_SUBMIT_DATA_VALUE)
    private setStateSubmitDataValue(data: any) {
        if (data) {
            this.setSubmitData(data.name, data.value);
        }
    }

    /**
     * チャット情報を初期化。
     */
    @ActionBind(CancelActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    /**
     * submitDataをバックアップ。
     */
    @ActionBind(CancelActionType.SUBMIT_DATA_BACKUP)
    private submitDataBackup() {
        this.state.copySubmitData = Object.assign(new CancelSubmitEntity(), this.state.submitData);
    }

    /**
     * submitDataを初期化。
     */
    @ActionBind(CancelActionType.RESET_SUBMIT_DATA)
    private resetSubmitData() {
        this.state.submitData = this.state.copySubmitData;
        this.state.copySubmitData = null;
    }

    @ActionBind(CancelActionType.SET_STATE_DATA_FOR_CONFIRM)
    private setStateData(data) {
        this.state.submitData = Object.assign(new CancelSubmitEntity(), data.submitData);
    }

    /**
     * submitDataを設定する
     *
     * @param data 回答
     */
    @ActionBind(CancelActionType.SET_STATE_DATA)
    private setData(submitData: any) {
        Object.keys(submitData).forEach((key) => {
            this.setSubmitData(key, submitData[key]);
        });
    }

    /**
     * yamlが終了した際の処理。
     * @param nextChatName 次yaml名
     */
    @ActionBind(CancelActionType.CHAT_FLOW_COMPELETE)
    private chatFlowCompelete(nextChatName: string) {
        this.sendSignal(CancelSignal.CHAT_FLOW_COMPELETE, nextChatName);
    }

    @ActionBind(CancelActionType.RESET_SHOWCHATS)
    private resetShowChats(data: any) {
        this.state.showChats = data;
    }

    /**
     * 修正ボタン押下時の処理。
     */
    @ActionBind(CancelActionType.RESET_LAST_NODE)
    private resetLastNode(data?: boolean) {
        const lastNode = this.getState().showChats.pop();
        if (!!data && lastNode.type === 'request') {
            this.getState().showChats.push(lastNode);
        } else {
            this.getNextChatByAnswer({ order: lastNode.order, pageIndex: lastNode.pageIndex });
        }
    }

    /**
     * 修正チャットフラグの保存。
     */
    @ActionBind(CancelActionType.SET_MODIFY_FLG)
    private setModifyFlg(value) {
        this.state.isModify = value;
    }

    /**
     * レスポンスをstateにセット。
     * 金額や日付等のデータを加工。
     * @param data APIのレスポンス
     */
    @ActionBind(CancelActionType.ACCOUNT_INFO_INQUIRY)
    private getCancelableList(data: any) {
        if (!data.cancelableList) {
            this.setSubmitData('cancelableFlg', '0');
        } else {
            const partialTrueCount: string[] = new Array();

            this.state.cancelableList = data.cancelableList;
            this.state.cancelableList.forEach((listData) => {
                listData.depositDateFormat = InputUtils.dateChange(listData.depositDate);
                if (listData.dueDate) {
                    listData.dueDateFormat = InputUtils.dateChange(listData.dueDate);
                }
                partialTrueCount.push(listData.closeImpossibleFlag);
            });

            this.setSubmitData('cancelableFlg', partialTrueCount.indexOf('0') === -1 ? '0' : '1');
       }

        if (data.depositDetailsCountList) {
            this.state.depositDetailsCountList = data.depositDetailsCountList;
        }

        this.sendSignal(CancelSignal.GET_CANCELABLE_LIST);
    }

    /**
     * 顧客入力情報をstateにセット。
     * @param data 顧客入力情報
     */
    @ActionBind(CancelActionType.MODIFY_ID)
    private modifyId(data: any[]) {
        for (const i in this.state.cancelableList) {
            this.state.cancelableList[i].id = data[i];
        }
    }

    /**
     * 顧客入力情報をstateにセット。
     * @param data 顧客入力情報
     */
    @ActionBind(CancelActionType.MODIFY_CANCEL_AMOUNT)
    private modifyCancelAmount(data: any[]) {
        for (const i in this.state.cancelableList) {
            this.state.cancelableList[i].cancelAmount = data[i];
        }
    }

    /**
     * 顧客入力情報をstateにセット。
     * @param data 顧客入力情報
     */
    @ActionBind(CancelActionType.ITEM_COUNT)
    private itemCount(data: any[]) {
        for (const i in this.state.cancelableList) {
            this.state.cancelableList[i].count = data[i];
        }
    }

    /**
     * インサートに成功した場合次処理のシグナルを送る。
     * @param data
     */
    @ActionBind(CancelActionType.CANCEL_INFO_INSERT)
    private cancelInfoInsert(data) {
        this.sendSignal(CancelSignal.SUCCESS_INSERT_CANCEL_INFO, data);
    }

    /**
     * APIのレスポンスをセット。
     * @param params APIのレスポンス
     */
    @ActionBind(CancelActionType.GET_CONFIRM_PAGE_TEMPLATE)
    private loadConfirmTemplate(params: any) {
        if (params) {
            this.state.questions[params.pageIndex] = params.data;
            this.setSubmitData('fileInfo', params.fileInfo);
        }
    }

    /**
     * 解約合計金額をstateにセット。
     * @param data 解約合計金額
     */
    @ActionBind(CancelActionType.SET_TOTAL_AMOUNT)
    private setTotalAmount(data?: any) {
        if (data) {
            // 解約リスト選択場合、解約合計設定（定期払い戻し利息含まない）
            this.setSubmitData('totalAmount', data);
        } else {
            // 申込確認画面の解約合計設定（定期払い戻し金額（元金）と積立定期払い戻し金額（元金）の合計）
            let totalAmount: number = 0;
            this.state.submitData.cancelableList.forEach((item) => {
                totalAmount = totalAmount + Number.parseInt(item.estimatedPaymentAmount || item.depositAmount);
            });
            this.setSubmitData('totalAmount', totalAmount);
        }
    }

    @ActionBind(CancelActionType.RESET_CANCEL_LIST)
    private resetCancelList() {
        this.state.cancelableList.forEach((data) => {
            data.id = false;
            data.count = null;
            data.cancelAmount = data.cancelAmount ? '0' : null;
        });
        this.state.submitData.totalAmount = 0;
        this.sendSignal(CancelSignal.RESET_CANCEL_LIST);
    }

    // Save yaml file Information
    private saveCurrentYamlInfo(params: any) {
        this.state.currentFileInfo.yamlId = params.id;
        this.state.currentFileInfo.screenId = params.screenId;
        this.state.currentFileInfo.screenName = params.screenName;
    }

    private setSubmitData(key, value) {
        if (key !== undefined) {
            this.state.submitData[key] = value;
            this.keyPush(key, value);
        }
    }

    private keyPush(key: any, value: any) {
        if (value === null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                this.keysArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1) {
            this.keysArr.push(key);
        }
    }

    private cleanSubmitData(remain: number) {
        this.keysArr = this.keysArr.slice(0, remain);

        for (const item in this.state.submitData) {
            if (item.startsWith('get')) {
                continue;
            }
            if (this.keysArr.indexOf(item) < 0 && item !== SubmitDataKey.LOG_FILE_INFO) {
                this.state.submitData[item] = undefined;
            }
        }
    }
    /**
     * 確認情報をセット
     * @param confirmInfo 確認情報
     */
    @ActionBind(CancelActionType.SET_SELF_CONFIRM_INFO)
    private setSelfConfirmInfo(confirmInfo: any) {
        confirmInfo.forEach((key) => {
            this.setSubmitData(key, confirmInfo[key]);
        });
    }
    /**
     * cif情報をセット
     * @param cifInfo cif情報
     */
    @ActionBind(CancelActionType.SET_CIF_INFO)
    private setCifInfo(cifInfo: any) {
        Object.keys(cifInfo).forEach((key) => {
            this.setSubmitData(key, cifInfo[key]);
        });
    }

    /**
     * 利息照会・払い戻し口座一覧照会
     * @param data 利息照会・払い戻し口座一覧
     */
    @ActionBind(CancelActionType.GET_CANCEL_RATE_LIST)
    private getCancelRateList(data: any) {
        this.setSubmitData('cancelableList', data.cancelableList);

        this.state.submitData.cancelableList.forEach((listData) => {
            listData.depositDateFormat = InputUtils.dateChange(listData.depositDate);
            if (listData.dueDate) {
                listData.dueDateFormat = InputUtils.dateChange(listData.dueDate);
            }
        });
        this.setSubmitData('transferList', data.transferAccounts);
        // 入金口座は複数件の場合
        if (data.transferAccounts && data.transferAccounts.length > 1) {
            this.setSubmitData('transferFlg', '2');
            this.setSubmitData('isCancel', true);
        // 入金口座は1件の場合
        } else if (data.transferAccounts && data.transferAccounts.length === 1) {
            data.transferAccounts[0].isCancel = true;
            this.setSubmitData ('transferAccountInfo', data.transferAccounts[0]);
            this.setSubmitData('transferFlg', '1');
        // 入金口座は0件の場合
        } else {
            this.setSubmitData('transferFlg', '0');
        }
        this.sendSignal(CancelSignal.GET_CANCEL_RATE_LIST);
    }

    /**
     * 受付可否チェック。
     */
    @ActionBind(CancelActionType.RECEPTION_CHECK)
    private receptionCheck(data: any) {
        Object.keys(data).forEach((key) => {
            this.setSubmitData(key, data[key]);
        });
        this.sendSignal(CancelSignal.RECEPTION_CHECK);
    }

    /**
     * 解約積立定期口座ごとに概算支払金額を格納
     */
    @ActionBind(CancelActionType.SET_ESTIMATED_PAYMENT_AMOUNT)
    private setEstimatedPaymentAmount(data: any) {
        this.state.cancelableList.forEach((cancelAccount) => {
            if (cancelAccount.branchNo === data.branchNo && cancelAccount.accountType === data.accountType
                && cancelAccount.accountNo === data.accountNo) {
                    cancelAccount.estimatedPaymentAmount = data.estimatedPaymentAmount;
                }
        });
    }

    /**
     * submitData配下の解約商品一覧解約積立定期口座ごとに概算支払金額を格納
     */
    @ActionBind(CancelActionType.SET_ESTIMATED_PAYMENT_AMOUNT_FOR_SUBMIT_DATA)
    private setEstimatedPaymentAmountForSubmitData() {
        this.state.cancelableList.forEach((item) => {
            if (item.estimatedPaymentAmount) {
                this.state.submitData.cancelableList.forEach((submitDataCancelableAccount) => {
                    if (submitDataCancelableAccount.branchNo === item.branchNo
                        && submitDataCancelableAccount.accountType === item.accountType
                        && submitDataCancelableAccount.accountNo === item.accountNo) {
                        submitDataCancelableAccount.estimatedPaymentAmount = item.estimatedPaymentAmount;
                    }
                });
            }
        });
    }

    /**
     * 質問文言をリプレースする
     * @param message 文言
     */
    private replaceChatMessage(message: string) {
        const reg = /\$\([^)]+\)/g;
        const array = message.match(reg);
        if (array === null) {
            return message;
        }

        const replaceValues = {
            // 定期解約 本人確認書類チャット
            IdentificationDoc1: this.state.submitData.identificationDoc1NameInput ?
                this.state.submitData.identificationDoc1NameInput : this.state.submitData.identificationDoc1Text,
            IdentificationDoc2: this.state.submitData.identificationDoc2NameInput,
            Name: this.state.submitData.nameKanji,
            Address: this.state.submitData.address,
        };

        array.forEach((item) => {
            const prop = item.replace('$(', '').replace(')', '');
            const value = replaceValues[prop];
            message = message.replace(item, value);
        });
        return message;
    }
}
