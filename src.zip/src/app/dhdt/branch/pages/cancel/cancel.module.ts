import { NgModule, Type } from '@angular/core';
import { HttpModule } from '@angular/http';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelIdentificationDocumentHandler } from 'dhdt/branch/pages/cancel/chat-flow/cancel-identification-document.handler';
import { CancelIdentificationDocumentRenderer } from 'dhdt/branch/pages/cancel/chat-flow/cancel-identification-document.renderer';
import { CancelInitInputHandler } from 'dhdt/branch/pages/cancel/chat-flow/cancel-init.input-handler';
import { CancelInitRenderer } from 'dhdt/branch/pages/cancel/chat-flow/cancel-init.renderer';
import { CancelModifyRenderer } from 'dhdt/branch/pages/cancel/chat-flow/cancel-modify.renderer';
import { CancelInputHandler } from 'dhdt/branch/pages/cancel/chat-flow/cancel.input-handler';
import { CancelRenderer } from 'dhdt/branch/pages/cancel/chat-flow/cancel.renderer';
import { CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';
import { CancelChatComponent } from 'dhdt/branch/pages/cancel/view/cancel-chat.component';
import { CancelConfirmPageChatComponent } from 'dhdt/branch/pages/cancel/view/cancel-confirm-page-chat.component';
import { CancelConfirmComponent } from 'dhdt/branch/pages/cancel/view/cancel-confirm.component';
import { CancelComponent } from 'dhdt/branch/pages/cancel/view/cancel.component';
import { LoginModule } from 'dhdt/branch/pages/common/login/login.module';
import { TopModule } from 'dhdt/branch/pages/common/top/top.module';
import { AccountShopModule } from 'dhdt/branch/shared/components/account-shop/account-shop.module';
import { Nl2brPipe } from 'dhdt/branch/shared/components/cancel-list/pipe/nl2br.pipe';
import { CancelAccountShopComponent } from 'dhdt/branch/shared/components/confirmpage-common/cancel/cancel-account-shop.component';
import { ConfirmPageCommonModule } from 'dhdt/branch/shared/components/confirmpage-common/confirmpage.common.module';
import { ModalPasswordModule } from 'dhdt/branch/shared/components/modal/modal-password/modal-password.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';
import { CancelSubmitEntity, CheckboxStatusEntity } from './entity/cancel-submit.entity';

export const SHARED_FORM_COMPONENT: Array<Type<any>> = [
    CancelConfirmComponent,
    CancelComponent,
    CancelConfirmPageChatComponent,
    CancelChatComponent,
    CancelAccountShopComponent,
];

@NgModule({
    imports: [
        LoginModule,
        IonicModule,
        SharedModule,
        HttpModule,
        ConfirmPageCommonModule,
        TopModule,
        AccountShopModule,
        ModalPasswordModule,
    ],
    declarations: [
        SHARED_FORM_COMPONENT,
        Nl2brPipe
    ],
    exports: [
        SHARED_FORM_COMPONENT,
        TopModule,
    ],
    entryComponents: [
        SHARED_FORM_COMPONENT,
    ],
    providers: [
        CancelAction,
        CancelStore,
        CancelInitInputHandler,
        CancelInitRenderer,
        CancelModifyRenderer,
        CancelInputHandler,
        CancelRenderer,
        CancelIdentificationDocumentRenderer,
        CancelIdentificationDocumentHandler,
        CancelSubmitEntity,
        CheckboxStatusEntity

    ]
})
export class CancelModule {
}
