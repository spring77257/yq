import { Injectable, NgZone } from '@angular/core';
import { Action } from 'adep/flux';
import { LabelService } from 'adep/services';
import { CancelListEntity } from 'dhdt/branch/pages/cancel/entity/cancel-list.entity';
import { API_URL, ClearChangeImagesClickRecordType, HostResultCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ChatFlowActionInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-action.interface';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { HostErrorService } from 'dhdt/branch/shared/services/host-error.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { HttpService, HttpStatus } from 'dhdt/branch/shared/services/http.service';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { App } from 'ionic-angular';

export namespace CancelActionType {

    export const GET_SAVING_QUESTION_TEMPLATE: string = 'CancelActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const NEXT_CHAT: string = 'CancelActionType_NEXT_CHAT';
    export const CLEAR: string = 'CancelActionType_LOAD_TEMPLATE_CLEAR';
    export const CLEAR_SHOW_CHATS: string = 'CancelActionType_CLEAR_SHOW_CHATS';
    export const BRANCH_STATUS_INSERT: string = 'CancelActionType_BRANCH_STATUS_INSERT';
    export const BRANCH_STATUS_UPDATE: string = 'CancelActionType_BRANCH_STATUS_UPDATE';
    export const SET_CUSTOMER_APPLY_START_DATE: string = 'CancelActionType_SET_CUSTOMER_APPLY_START_DATE';
    export const SET_ANSWER: string = 'CancelActionType_SET_ANSWER';
    export const EDIT_CHAT: string = 'CancelActionType_EDIT_CHAT';
    export const SET_STATE_SUBMIT_DATA_VALUE: string = 'CancelActionType_SET_STATE_SUBMIT_DATA_VALUE';
    export const SUBMIT_DATA_BACKUP: string = 'CancelActionType_SUBMIT_DATA_BACKUP';
    export const RESET_SUBMIT_DATA: string = 'CancelActionType_RESET_SUBMIT_DATA';
    export const RETRIEVE_DROP_LIST: string = 'CancelActionType_RETRIEVE_DROP_LIST';
    export const SET_TABLE_START_DATE = 'CancelActionType_SET_TABLE_START_DATE';
    export const UPLOAD_IMAGE = 'CancelActionType_UPLOAD_IMAGE';
    export const CHAT_FLOW_COMPELETE = 'CancelActionType_CHAT_FLOW_COMPELETE';
    export const RESET_LAST_NODE = 'CancelActionType_RESET_LAST_NODE';
    export const SET_BANKCLERK_CONFIRM_START_DATE: string = 'CancelActionType_SET_BANKCLERK_CONFIRM_START_DATE';
    export const SET_BANKCLERK_CONFIRM_END_DATE: string = 'CancelActionType_SET_BANKCLERK_CONFIRM_END_DATE';
    export const UPDATA_SUBMIT_DATA_BACKUP = 'CancelActionType_UPDATA_SUBMIT_DATA_BACKUP';
    export const SET_SELF_CONFIRM_INFO = 'CancelActionType_SET_SELF_CONFIRM_INFO';
    export const MODIFY_ID = 'CancelActionType_MODIFY_ID';
    export const MODIFY_CANCEL_AMOUNT = 'CancelActionType_MODIFY_CANCEL_AMOUNT';
    export const ITEM_COUNT = 'CancelActionType_ITEM_COUNT';
    export const CANCEL_INFO_INSERT = 'CancelActionType_CANCEL_INFO_INSERT';
    export const GET_CONFIRM_PAGE_TEMPLATE = 'CancelActionType_GET_CONFIRM_PAGE_TEMPLATE';
    export const ACCOUNT_INFO_INQUIRY: string = 'CancelActionType_ACCOUNT_INFO_INQUIRY';
    export const CIF_INFO_INQUIRY: string = 'CancelActionType_CIF_INFO_INQUIRY';
    export const SET_HOLDER_INFO: string = 'CancelActionType_SET_HOLDER_INFO';
    export const SET_TOTAL_AMOUNT: string = 'CancelActionType_SET_TOTAL_AMOUNT';
    export const SET_SWIPE_INFO: string = 'CancelActionType_SET_SWIPE_INFO';
    export const CLEAR_DOCUMENTS: string = 'CancelActionType_CLEAR_DOCUMENTS';
    export const RESET_SHOWCHATS: string = 'CancelActionType_RESET_SHOWCHATS';
    export const SET_CIF_INFO = 'SET_CIF_INFO';
    export const GET_CANCEL_RATE_LIST = 'GET_CANCEL_RATE_LIST';
    export const RECEPTION_CHECK = 'RECEPTION_CHECK';
    export const RESET_CANCEL_LIST = 'RESET_CANCEL_LIST';
    export const SET_ESTIMATED_PAYMENT_AMOUNT: string = 'CancelActionType_SET_ESTIMATED_PAYMENT_AMOUNT';
    export const SET_ESTIMATED_PAYMENT_AMOUNT_FOR_SUBMIT_DATA: string = 'CancelActionType_SET_ESTIMATED_PAYMENT_AMOUNT_FOR_SUBMIT_DATA';
    export const SET_STATE_DATA_FOR_CONFIRM = 'CancelActionType_SET_STATE_DATA_FOR_CONFIRM';
    export const SET_STATE_DATA = 'CancelActionType_SET_STATE_DATA';
    export const RESET_TO_NODE = 'CancelActionType_RESET_TO_NODE';
    export const SAVE_DOCUMENT_IMAGE = 'CancelActionType_SAVE_DOCUMENT_IMAGE';
    export const EDIT_SUBMIT_DATA = 'CancelActionType_EDIT_SUBMIT_DATA';
    export const MODIFY_CHECKBOX_STATUS = 'CancelActionType_MODIFY_CHECKBOX_STATUS';
    export const REMOVE_NOT_MASKING_CONFIRM_IMAGES = 'CancelActionType_REMOVE_NOT_MASKING_CONFIRM_IMAGES';
    export const RESET_NOT_MASKING_CONFIRM_IMAGES = 'CancelActionType_RESET_NOT_MASKING_CONFIRM_IMAGES';
    export const RESET_CHECKBOX_STATUS = 'CancelActionType_RESET_CHECKBOX_STATUS';
    export const SET_MODIFY_FLG = 'CancelActionType_SET_MODIFY_FLG';
    export const CLEAR_CANCEL_DOCUMENTS = 'CancelActionType_CLEAR_CANCEL_DOCUMENTS';
    export const CLEAR_CANCEL_REASON = 'CancelActionType_CLEAR_CANCEL_REASON';
}

@Injectable()
export class CancelAction extends Action implements ChatFlowActionInterface {
    constructor(
        private httpService: HttpService,
        private hostErrorService: HostErrorService,
        private ngZone: NgZone,
        private labelService: LabelService,
        private appCtrl: App,
        private errorMessageService: ErrorMessageService
    ) {
        super();
    }

    /**
     * yamlファイル読込API呼び出し。
     * @param file ファイル名
     * @param pageIndex ページ番号
     */
    public loadTemplate(file: string, pageIndex: number) {

        this.httpService.get('/chatflow/definition/' + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CancelActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: { data: response.result.questions,
                        pageIndex: pageIndex,
                        fileInfo: response.result.fileInfos,
                     }
            });
        });
    }

    /**
     * 申込開始情報登録API呼び出し。
     * @param params リクエストパラメータ
     */
    public branchStatusInsert(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CancelActionType.BRANCH_STATUS_INSERT,
                data: response.result
            });
        });
    }

    /**
     * 申込終了情報登録API呼び出し。
     * @param params リクエストパラメータ
     */
    public branchStatusUpdate(params: any) {
        this.httpService.post(API_URL.BRANCH_STATUS_UPDATE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CancelActionType.BRANCH_STATUS_UPDATE,
                data: response.result
            });
        });
    }

    /**
     * 次チャットを呼び出し。
     * @param order yamlのorder
     * @param pageIndex ページ番号
     */
    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    public resetToNode(order: number, pageIndex: number): void {
        this.dispatcher.dispatch({
            actionType: CancelActionType.RESET_TO_NODE,
            data: { order: order, pageIndex: pageIndex}
        });
    }

    /**
     * 本人確認書類画像を保存
     * @param {{ submitKey: string, image: string }} document
     * @memberof CancelAction
     */
    public saveIdentityDocumentImage(data: { submitKey: string, image: string }) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SAVE_DOCUMENT_IMAGE,
            data: data
        });
    }

    /**
     * stateを初期化。
     */
    public clearStore() {
        this.dispatcher.dispatch({
            actionType: CancelActionType.CLEAR
        });
    }

    public clearStoreDocuments() {
        this.dispatcher.dispatch({
            actionType: CancelActionType.CLEAR_DOCUMENTS
        });
    }

    /**
     * chat情報を初期化。
     */
    public clearShowChats() {
        this.dispatcher.dispatch({
            actionType: CancelActionType.CLEAR_SHOW_CHATS
        });
    }

    /**
     * 修正ボタン押下時の処理。
     * @param order yamlのorder
     * @param pageIndex ページ番号
     */
    public editAnswer(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.EDIT_CHAT,
            data: { order: order, pageIndex: pageIndex, answerOrder: answerOrder,  orderIndex: orderIndex}
        });
    }

    /**
     * 顧客入力情報をstateに登録。
     * @param answer 顧客入力情報
     */
    public setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SET_ANSWER,
            data: answer
        });
    }

    public setData(submitData: any) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SET_STATE_DATA,
            data: submitData
        });
    }

    public setStateSubmitDataValue(param: any) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SET_STATE_SUBMIT_DATA_VALUE,
            data: param
        });
    }

    public submitDataBackup() {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SUBMIT_DATA_BACKUP
        });
    }

    public resetSubmitData() {
        this.dispatcher.dispatch({
            actionType: CancelActionType.RESET_SUBMIT_DATA
        });
    }

    public setStateData(data) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SET_STATE_DATA_FOR_CONFIRM,
            data: data
        });
    }

    /**
     * マスキング済みの画像を格納する
     */
    public editSubmitData(index: number, key: string, val: string) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.EDIT_SUBMIT_DATA,
            data: {
                index: index,
                key: key,
                val: val
            }
        });
    }

    /**
     * modify checkbox status
     * @param name the checbox item need to modify status
     */
    public modifyCheckboxStatus(name: string) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.MODIFY_CHECKBOX_STATUS,
            data: name
        });
    }

    /**
     * 未マスキング状態管理オブジェクトからマスキング完了済み画像のindexを削除する
     *
     * @param {{documentName: string, index: number}} maskingConfirmImgStatus
     * @memberof CancelAction
     */
    public removeNotMaskingConfirmImages(maskingConfirmImgStatus: {documentName: string, index: number}) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES,
            data: maskingConfirmImgStatus
        });
    }

    /**
     * 未マスキング状態管理オブジェクトをリセットする
     *
     * @param {ClearChangeImagesClickRecordType} type リセットタイプ
     * @memberof CancelAction
     */
    public resetNotMaskingConfirmImages(type: ClearChangeImagesClickRecordType) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.RESET_NOT_MASKING_CONFIRM_IMAGES,
            data: type
        });
    }

    /**
     * reset checkbox status
     */
    public resetCheckboxStatus() {
        this.dispatcher.dispatch({
            actionType: CancelActionType.RESET_CHECKBOX_STATUS,
        });
    }

    /**
     * 修正チャットフラグの保存
     * @param value フラグの値
     */
    public setModifyFlg(value) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SET_MODIFY_FLG,
            data: value
        });
    }

    /**
     * 書類聴取チャットにおける回答内容をクリアする
     */
    public clearCancelDocuments() {
        this.dispatcher.dispatch({
            actionType: CancelActionType.CLEAR_CANCEL_DOCUMENTS,
        });
    }

    /**
     * 書類聴取チャットにおける回答内容をクリアする
     */
    public clearCancelReason() {
        this.dispatcher.dispatch({
            actionType: CancelActionType.CLEAR_CANCEL_REASON,
        });
    }

    /**
     * 次yamlを読込。
     * @param nextChatName 次yaml名
     */
    public chatFlowCompelete(nextChatName: string) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.CHAT_FLOW_COMPELETE,
            data: nextChatName
        });
    }

    /**
     * 修正ボタン押下時にチャット情報をリセット。
     */
    public resetLastNode(noCallRequest?: boolean) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.RESET_LAST_NODE,
            data: noCallRequest,
        });
    }

    /**
     * 選択した商品のstateの情報を変更。
     * @param params 顧客入力情報
     */
    public modifyId(params: any[]) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.MODIFY_ID,
            data: params
        });
    }

    /**
     * 選択した商品のstateの情報を変更。
     * @param params 顧客入力情報
     */
    public modifyCancelAmount(params: any[]) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.MODIFY_CANCEL_AMOUNT,
            data: params
        });
    }

    /**
     * 選択した商品のstateの情報を変更。
     * @param params 顧客入力情報
     */
    public itemCount(params: any[]) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.ITEM_COUNT,
            data: params
        });
    }

    /**
     * 解約情報インサートAPI呼び出し。
     * @param params リクエストパラメータ
     */
    public cancelInfoInsert(params: any) {
        this.httpService.post(API_URL.CANCEL_INSERT, params, {}, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CancelActionType.CANCEL_INFO_INSERT,
                data: response.result
            });
        });
    }

    /**
     * Reset showChats to origin
     * @param originShowChats originShowChats
     */
    public resetShowChats(originShowChats: any[]) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.RESET_SHOWCHATS,
            data: originShowChats
        });
    }

    /**
     * 内容確認画面用yaml読込API呼び出し。
     * @param file yaml名
     * @param pageIndex ページ番号
     */
    public loadConfirmPageTemplate(file: string, pageIndex: number) {

        this.httpService.get('/chatflow/definition/' + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CancelActionType.GET_CONFIRM_PAGE_TEMPLATE,
                data: { data: response.result.questions,
                        pageIndex: pageIndex,
                        fileInfo: response.result.fileInfos,
                     }
            });
        });
    }

    /**
     * 定期と積立の支払・解約の一覧取得呼び出し。
     * @param params リクエストパラメータ
     */
    public getCancelableList(params: any) {
        this.httpService.post('/core-banking/time-deposit-account-cancelable-info/inquiry', params, undefined, SpinnerType.SHOW)
        .subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CancelActionType.ACCOUNT_INFO_INQUIRY,
                data: response.result
            });
        });
    }

    /**
     * 解約合計金額をstateにセット。
     * @param data 解約合計金額
     */
    public setTotalAmount(data?: any) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SET_TOTAL_AMOUNT,
            data: data
        });
    }

    /**
     * 解約希望商品を初期化する。
     */
    public resetCancelList() {
        this.dispatcher.dispatch({
            actionType: CancelActionType.RESET_CANCEL_LIST
        });
    }

    /**
     * ICカードの認証処理を行う。
     * @param params ICカード情報
     */
    public cardIinfoCheck(params: any) {
        return new Promise((resolve, reject) => {
            this.httpService.post('/card-info/check', params, null, SpinnerType.SHOW_TRANSPARENT, true)
                .subscribe((result) => {
                    if (result.status === HttpStatus.SUCCESS) {
                        resolve(true);
                    } else if (result.status === HttpStatus.HOST_ERROR) {
                        this.hostErrorService.push({
                            resultCode: result.errors.data.resultCode,
                            errorCode: result.errors.data.errorCode,
                            message: result.errors.message,
                            handel: () => {
                                resolve(false);
                            }
                        });
                    } else {
                        throw new HttpStatusError('/card-info/check', result.status, result.errors);
                    }
                }, (error) => {
                    reject(error);
                });
        });
    }

    public updateSubmitDataBackup(data) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.UPDATA_SUBMIT_DATA_BACKUP,
            data: data
        });
    }

    public setSelfConfirmInfo(data) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SET_SELF_CONFIRM_INFO,
            data: data
        });
    }

    /**
     * cif情報をセット
     * @param cifInfo cif情報
     */
    public setCifInfo(cifInfo: any) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SET_CIF_INFO,
            data: cifInfo
        });
    }

    /**
     * 015-払い戻し口座一覧
     * @param params 払い戻し口座一覧パラメータ
     */
    public getCancelRateList(params: any) {
        this.httpService.post(API_URL.GET_CANCEI_RATE_INFO, params, undefined, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CancelActionType.GET_CANCEL_RATE_LIST,
                data: response.result
            });
        });
    }

    /**
     * 受付可否チェック
     * @param params 受付可否チェックパラメータ
     */
    public receptionCheck(params: any) {
        this.httpService.post(API_URL.RECEPTION_CHECK, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CancelActionType.RECEPTION_CHECK,
                data: response.result
            });
        });
    }

    public async receptionCheckWithoutError(params: any, next: number, pageIndex: number) {
        return new Promise((resolve, reject) => {
            this.httpService.post(API_URL.RECEPTION_CHECK, params, null, SpinnerType.SHOW_TRANSPARENT, true)
                .subscribe((result) => {
                    if (result.status === HttpStatus.SUCCESS) {
                        this.setStateSubmitDataValue({
                            name: 'receptionFlg',
                            value: '1',
                        });
                    } else if (result.status === HttpStatus.HOST_ERROR) {
                        this.setStateSubmitDataValue({
                            name: 'receptionFlg',
                            value: '0',
                        });
                    } else {
                        throw new HttpStatusError(API_URL.RECEPTION_CHECK, result.status, result.errors);
                    }
                    this.getNextChatByAnswer(next, pageIndex);
                }, (error) => {
                    reject(error);
                });
        });
    }

    /**
     * 解約積立定期口座ごとに概算支払金額を格納
     * @param params
     */
    public setEstimatedPaymentAmount(params: any) {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SET_ESTIMATED_PAYMENT_AMOUNT,
            data: params
        });
    }
    /**
     * submitData配下の解約商品一覧解約積立定期口座ごとに概算支払金額を格納
     * @param params
     */
    public setEstimatedPaymentAmountForSubmitData() {
        this.dispatcher.dispatch({
            actionType: CancelActionType.SET_ESTIMATED_PAYMENT_AMOUNT_FOR_SUBMIT_DATA,
        });
    }
}
