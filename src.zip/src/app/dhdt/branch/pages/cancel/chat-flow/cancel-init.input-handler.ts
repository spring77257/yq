import { Injectable } from '@angular/core';
import { AppProperties } from 'app.properties';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelChatFlowQuestionTypes } from 'dhdt/branch/pages/cancel/chat-flow/cancel.chat-flow-question-types';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { Observable } from 'rxjs';

@Injectable()
export class CancelInitInputHandler extends DefaultChatFlowInputHandler {

    constructor(private action: CancelAction,
                private audioService: AudioService,
                ) {
        super(action);
    }

    @InputHandler(CancelChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer: any) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.value }
                ]
            });
        }

        if (answer.action.type.length > 0) {
            this.configAction(answer);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    private configAction(choice: any) {
        const action = choice.action;
        if (action.type === 'admin') {
            this.audioService.subject.next(true);
            this.chatFlowCompelete();
        } else if (action.type === 'route') {
            this.chatFlowCompelete(action.value);
        }
    }
}
