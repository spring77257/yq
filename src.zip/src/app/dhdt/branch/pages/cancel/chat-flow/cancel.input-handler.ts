import { Injectable } from '@angular/core';
import { AppProperties } from 'app.properties';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelChatFlowQuestionTypes } from 'dhdt/branch/pages/cancel/chat-flow/cancel.chat-flow-question-types';
import { CancelSignal, CancelState, CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';
import { CancelConfirmComponent } from 'dhdt/branch/pages/cancel/view/cancel-confirm.component';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { App, NavController } from 'ionic-angular';
import { Observable } from 'rxjs';

@Injectable()
export class CancelInputHandler extends DefaultChatFlowInputHandler {

    private state: CancelState;
    private navCtrl: NavController;

    constructor(private action: CancelAction,
                private store: CancelStore,
                private loginStore: LoginStore,
                private modalService: ModalService,
                private audioService: AudioService,
                app: App) {
        super(action);
        this.state = this.store.getState();
        this.navCtrl = app.getActiveNavs()[0];
    }
    @InputHandler(CancelChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            this.setAnswer({
            text: answer.text,
            value: [
                { key: entity.name, value: answer.value },
                { key: answer.name, value: answer.value }
            ]
            });
        }
        if (answer.action.type.length > 0) {
            this.configAction(answer);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(CancelChatFlowQuestionTypes.CANCEL_LIST)
    private onCancelListHandler(entity, pageIndex) {
        this.action.setStateSubmitDataValue({
            name: 'cancelableList',
            value: this.state.cancelableList.filter((item) => {
                return item.id === true;
            })
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(CancelChatFlowQuestionTypes.SELECT_PAYOUT_ACCOUNT)
    private onSelectPayoutAccountHandler(entity, pageIndex, answer) {
        if (answer) {
            this.setAnswer({
                text: answer.text,
                value: [{
                    key: entity.name,
                    value: answer.value
                },
                ]
            });
        }
        this.store.registerSignalHandler(CancelSignal.RECEPTION_CHECK, () => {
            this.store.unregisterSignalHandler(CancelSignal.RECEPTION_CHECK);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                tenban: answer.value.branchNo, // 店番
                accountType: answer.value.accountType, // 科目
                accountNo: answer.value.accountNo, // 口座番号
                businessCode: entity.options.businessCode, // 業務コード
            }
        };
        this.action.receptionCheck(param);
    }

    private configAction(choice: any) {
        const action = choice.action;

        if (action.type === 'admin') {
            this.audioService.subject.next(true);
            this.chatFlowCompelete();
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            const info = {
                imgSrc: action.imgSrc
            };
            this.modalService.showModal(action.value, info);
            Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                this.action.resetLastNode();
            });
        } else if (action.type === 'route') {
            switch (action.value) {
                case 'backToTop':
                    this.chatFlowCompelete(action.value);
                    break;
                case 'CancelConfirmComponent':
                    this.navCtrl.setRoot(CancelConfirmComponent);
                    break;
                default:
                    break;
            }
        }
    }
}
