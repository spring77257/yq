import { Injectable, OnInit } from '@angular/core';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelIdentificationDocumentHandler } from 'dhdt/branch/pages/cancel/chat-flow/cancel-identification-document.handler';
import { CancelChatFlowQuestionTypes } from 'dhdt/branch/pages/cancel/chat-flow/cancel.chat-flow-question-types';
import { CancelState, CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ButtonCameraComponent } from 'dhdt/branch/shared/components/button-group/button-camera.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/chat-flow.renderer';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { NavController } from 'ionic-angular';

export const CANCEL_IDENTIFICATION_DOCUMENT_TYPE = 'CancelIdentificationDocumentComponent';
/*
 * 定期解約ー本人確認チャット用レンダラー
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CANCEL_IDENTIFICATION_DOCUMENT_TYPE,
    templateYaml: 'chat-flow-def-cancel-identification-document.yml'
})
export class CancelIdentificationDocumentRenderer extends DefaultChatFlowRenderer {

    public processType = COMMON_CONSTANTS.ProcessType.BankClerkConfirm;
    private state: CancelState;
    private navCtrl: NavController;
    constructor(
        private action: CancelAction,
        private store: CancelStore,
        private identificationDocumentHandler: CancelIdentificationDocumentHandler
    ) {
        super(action, identificationDocumentHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    @Renderer(CancelChatFlowQuestionTypes.BUTTON)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number) {

        const options = {
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        // 修正チャットの場合。本確認書類①の「持っていない」ボタンを非活性化にする
        if (entity.name === 'identificationDoc1') {
            for (const choice of entity.choices) {
                if (this.state.submitData.isEdited && choice.value === '31') {
                    choice.options = {
                        cssClass: 'disabled-button',
                    };
                }
            }
        }

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);

    }

    @Renderer(CancelChatFlowQuestionTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            fullwidthHalfwidthDivisionCode: entity.fullwidthHalfwidthDivisionCode
        };

        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);

    }

    @Renderer(CancelChatFlowQuestionTypes.CAMERA_BUTTON)
    public onCamera(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: ButtonCameraComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(CancelChatFlowQuestionTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        let judgeResult: any;
        switch (entity.name) {
            default: {
                // nameに一致するsubmitDataの値を返却し、一致するchoiceに進む
                judgeResult = this.state.submitData[entity.name];
            }
        }
        this.nextChatByJudge(entity, pageIndex, judgeResult);
    }

    /**
     * typeがjudgeの際に、分岐して次のチャットを開始させる
     *
     * @param entity
     * @param pageIndex
     * @param judgeResult
     */
    private nextChatByJudge(entity: ChatFlowMessageInterface, pageIndex: number, judgeResult: string) {
        for (const choice of entity.choices) {
            if (choice.value === judgeResult) {
                // 次のチャットを開始させる
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
                return;
            }
        }
        // 一致するものがない場合、entityのnextを参照する
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(CancelChatFlowQuestionTypes.CHANGE_CONTENT_CANCEL)
    private onChangeContentReissue(entity: ChatFlowMessageInterface, pageIndex: number): void {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

}
