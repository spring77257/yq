import { ChatFlowQuestionTypes } from 'dhdt/branch/shared/modules/chat-flow/chat-flow-question-types';

export class CancelChatFlowQuestionTypes extends ChatFlowQuestionTypes {
    public static readonly NEED_PASSWORD = 'needpassword';
    public static readonly CANCEL_LIST = 'cancelList';
    public static readonly ACCOUNT_SHOP = 'accountshop';
    public static readonly SELECT_PAYOUT_ACCOUNT = 'selectPayoutAccount';
    public static readonly CHANGE_CONTENT_CANCEL = 'changeContentCancel';
    public static readonly ROUTE = 'route';
}
