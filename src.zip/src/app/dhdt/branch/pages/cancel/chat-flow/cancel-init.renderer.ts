import { Injectable } from '@angular/core';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelInitInputHandler } from 'dhdt/branch/pages/cancel/chat-flow/cancel-init.input-handler';
import { CancelChatFlowQuestionTypes } from 'dhdt/branch/pages/cancel/chat-flow/cancel.chat-flow-question-types';
import { CancelSignal, CancelState, CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';
import { RequestType } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

export const CANCEL_INIT_RENDERER_TYPE = 'CancelInitComponent';
/**
 * 解約初期確認用コンポーネント。
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CANCEL_INIT_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-cancel-init.yml'
})
export class CancelInitRenderer extends DefaultChatFlowRenderer {

    public processType = 1;

    private state: CancelState;

    constructor(private action: CancelAction,
                private store: CancelStore,
                private loginStore: LoginStore,
                inputHandler: CancelInitInputHandler) {
            super(action, inputHandler);
            this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    @Renderer(CancelChatFlowQuestionTypes.JUDGE)
    private onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        const choice = entity.choices.find((item) => {
            return item.value === this.state.submitData[entity.name];
        });
        this.action.getNextChatByAnswer(choice ? choice.next : entity.next, pageIndex);
    }

    /**
     * Send request
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @Renderer(CancelChatFlowQuestionTypes.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        switch (entity.name) {
            // 定期、積立定期一覧取得
            case RequestType.CANCELABLE_LIST: {
                this.getCancelableList(entity, pageIndex);
                break;
            }
        }
    }

    private getCancelableList(entity: ChatFlowMessageInterface, pageIndex: number): void {

        this.store.registerSignalHandler(CancelSignal.GET_CANCELABLE_LIST, () => {
            this.store.unregisterSignalHandler(CancelSignal.GET_CANCELABLE_LIST);
            this.action.getNextChatByAnswer(entity.next, pageIndex);
        });

        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                customerId: this.state.submitData.customerId, // 顧客番号
            }
        };
        this.action.getCancelableList(param);
    }
}
