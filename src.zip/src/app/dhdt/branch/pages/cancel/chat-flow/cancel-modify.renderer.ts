import { Injectable } from '@angular/core';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelChatFlowQuestionTypes } from 'dhdt/branch/pages/cancel/chat-flow/cancel.chat-flow-question-types';
import { CancelInputHandler } from 'dhdt/branch/pages/cancel/chat-flow/cancel.input-handler';
import { CancelSignal, CancelState, CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';
import { RequestType } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { CancelComplexListComponent } from 'dhdt/branch/shared/components/cancel-list/view/cancel-complex-list.component';
import { PayoutAccountComponent } from 'dhdt/branch/shared/components/payout-account/view/payout-account.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

export const CANCEL_MODIFY_RENDERER_TYPE = 'CancelModifyComponent';
/**
 * ヘッダー項目が1(解約商品選択)時用コンポーネント。
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CANCEL_MODIFY_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-cancel-modify.yml'
})
export class CancelModifyRenderer extends DefaultChatFlowRenderer {
    public processType = -1;

    private state: CancelState;
    constructor(private action: CancelAction,
                private store: CancelStore,
                private loginStore: LoginStore,
                private inputHandler: CancelInputHandler) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    @Renderer(CancelChatFlowQuestionTypes.CANCEL_LIST)
    public onCancelList(entity: ChatFlowMessageInterface, pageIndex: number): void {
        this.store.registerSignalHandler(CancelSignal.RESET_CANCEL_LIST, () => {
            this.store.unregisterSignalHandler(CancelSignal.RESET_CANCEL_LIST);
            this.emitRenderEvent({
                class: CancelComplexListComponent,
                data: this.state.cancelableList,
            }, entity, pageIndex);
        });
        this.action.resetCancelList();
    }

    /**
     * 口座表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    @Renderer(CancelChatFlowQuestionTypes.SELECT_PAYOUT_ACCOUNT)
    private onSelectPayoutAccount(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this.store.getState().currentFileInfo.screenId,
                yamlId: this.store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            cssClass: 'cancel-payout-account-component',
            isCancel: true, // 解約の場合、金額を表示されない
        };
        this.emitRenderEvent({
            class: PayoutAccountComponent,
            data: { data: this.state.submitData[entity.example] || [] },
            options: options
        }, entity, pageIndex);
    }

    /**
     * Send request
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @Renderer(CancelChatFlowQuestionTypes.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        switch (entity.name) {
            // 015-定期、積立定期一覧取得
            case RequestType.CANCEL_RATE_LIST: {
                this.getCancelRateList(entity, pageIndex);
                break;
            }
        }
    }

    private getCancelRateList(entity: ChatFlowMessageInterface, pageIndex: number): void {
        this.store.registerSignalHandler(CancelSignal.GET_CANCEL_RATE_LIST, () => {
            this.store.unregisterSignalHandler(CancelSignal.GET_CANCEL_RATE_LIST);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });

        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                customerId: this.state.submitData.customerId, // 顧客番号
                cancelableList: this.state.submitData.cancelableList,
            }
        };
        this.action.getCancelRateList(param);
    }
}
