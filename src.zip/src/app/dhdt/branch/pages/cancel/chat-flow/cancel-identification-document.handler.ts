import { Injectable } from '@angular/core';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelChatFlowQuestionTypes } from 'dhdt/branch/pages/cancel/chat-flow/cancel.chat-flow-question-types';
import { CancelSignal, CancelState, CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';
import { CancelComponent } from 'dhdt/branch/pages/cancel/view/cancel.component';
import { AddCarema, CancelIdentificationDocument, COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/chat-flow.input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { App, NavController } from 'ionic-angular';
import { ScreenTransition } from '../../common-business/common-business-consts';
/*
 * 定期解約ー本人確認チャット用handler
 */
@Injectable()
export class CancelIdentificationDocumentHandler extends DefaultChatFlowInputHandler {
    private state: CancelState;
    private navCtrl: NavController;

    constructor(
        private action: CancelAction,
        private store: CancelStore,
        app: App
    ) {
        super(action);
        this.state = this.store.getState();
        this.navCtrl = app.getActiveNavs()[0];
    }
    @InputHandler(CancelChatFlowQuestionTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.action.setAnswer({
                text: COMMON_CONSTANTS.SKIP_TEXT,
                value: [
                    { key: entity.name, value: COMMON_CONSTANTS.SKIP_TEXT }
                ]});
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
            return;
        }
        if (entity.name.length > 0 && answer.value.length > 0) {
            if (entity.name === CancelIdentificationDocument.ADD_IDENTITY_DOCUMENT_IMG
                && answer.value === AddCarema.YES) {
                const choice = entity.choices ? entity.choices.find((item) => item.value === answer.value) : undefined;
                this.action.resetToNode(choice ? choice.next : entity.order, pageIndex);
            } else {
                this.action.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        // 本人確認書類選択の場合、表示名を保存する
                        /identificationDoc\d/.test(entity.name) ?
                            { key: entity.name + 'Text', value: answer.text } :
                            { key: answer.name, value: answer.text }
                    ]
                });
            }
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
            return;
        } else if (answer.action.type && answer.action.type === ScreenTransition.BACK_TO_TOP) {
            this.chatFlowCompelete(answer.action.type);
            return;
        } else {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
            return;
        }
    }

    @InputHandler(CancelChatFlowQuestionTypes.KEYBOARD)
    private onKeybord(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({ text: answer.text, value: answer.value });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(CancelChatFlowQuestionTypes.CAMERA_BUTTON)
    private onCameraButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        // 写真を保存
        this.action.saveIdentityDocumentImage({ submitKey: entity.name, image: answer.image });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

}
