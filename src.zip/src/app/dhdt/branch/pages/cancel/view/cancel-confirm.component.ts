import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { CompletionComponent } from 'dhdt/branch/pages/bank-savings-deposit/view/completion.component';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelConfirmPageCommonService } from 'dhdt/branch/pages/cancel/service/cancel-confirmpage.common.service';
import { CancelState, CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ShowChartParam } from 'dhdt/branch/shared/components/confirmpage-common/showchart.param';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ModalController, NavController } from 'ionic-angular';

@Component({
    selector: 'cancel-confirm-component',
    templateUrl: 'cancel-confirm.component.html'
})

/**
 * 申込内容確認画面（定期預金払い戻し）。
 */
export class CancelConfirmComponent extends BaseComponent implements OnInit {

    public confirmPageCommonParams: Map<string, any> = null;
    public state: CancelState;

    public editedList: any = {};
    public saveShowChats: any = {};

    public cancelList: ShowChartParam;
    public cancelAmountList: ShowChartParam;

    constructor(
        private action: CancelAction,
        private store: CancelStore,
        private navCtrl: NavController,
        private confirmPageCommonService: CancelConfirmPageCommonService,
        private modalCtrl: ModalController,
        private logging: LoggingService,
        private loginStore: LoginStore,
        private rsaEncryptService: RsaEncryptService,
        private savingStore: SavingsStore
    ) {
        super();
        this.state = this.store.getState();
    }

    public ngOnInit(): void {
        this.confirmPageCommonService.loadConfirmTemplate();
        this.state.showChats.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
        this.action.setEstimatedPaymentAmountForSubmitData();
        this.action.setTotalAmount();
    }

    // click 'お申込み' button
    public pushCompletionPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo[0].screenId,
            this.labels.logging.InfoComfirm.ApplyButton,
        );

        const modal = this.modalCtrl.create(ModalPasswordComponent,
            {
                data: {
                    text: this.labels.password.inputPasswordAgainText,
                    subText: this.labels.password.inputPasswordAgainSubText,
                    units: 4,
                    needConfirm: false,
                    validation: (password) => this.action.cardIinfoCheck({
                        tabletApplyId: this.state.submitData.tabletApplyId, // タブレット申込管理ID
                        params: {
                            receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                            tenban: this.state.submitData.cardInfo.branchNo, // 店番
                            accountType: this.state.submitData.cardInfo.accountType, // 科目
                            accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                            icCardInfo: this.savingStore.getState().icData,  // カード情報を入れる
                            passcode: this.rsaEncryptService.encrypt(password)  // 暗証番号
                        }
                    })
                }
            },
            { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.onDidDismiss((value) => {
            if (value && value.result) {
                this.navCtrl.push(CompletionComponent);
            }
        });
        modal.present();
    }

    // application button disable
    public validateNextButton(): boolean {
        let validate = true;
        let count: number = 0;
        let check: number = 0;
        this.state.cancelableList.forEach((item) => {
            if (item.id) {
                check++;
                if (item.totalCancelAmount !== null) {
                    count++;
                }
            }
        });
        if (check === count) {
            validate = false;
        }
        return validate;
    }

    // get header title
    public get headerTitle(): string {
        if (!this.state.submitData.accountType || !this.state.submitData.accountTypeText) {
            return '';
        }
        return this.state.submitData.accountTypeText;
    }
}
