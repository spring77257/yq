import { AfterViewChecked, Component, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CANCEL_INIT_RENDERER_TYPE } from 'dhdt/branch/pages/cancel/chat-flow/cancel-init.renderer';
import { CANCEL_RENDERER_TYPE } from 'dhdt/branch/pages/cancel/chat-flow/cancel.renderer';
import { CancelSignal, CancelState, CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';
import { ScreenTransition } from 'dhdt/branch/pages/common-business/common-business-consts';
import { COMMON_CONSTANTS, Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { AbstractChatFlowControlComponent } from 'dhdt/branch/shared/modules/chat-flow/components/abstract-chat-flow-control.component';
import { ChatFlowHeaderInterfaces, ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { EditModalButtonValue, EditModalDismissEventValue
} from 'dhdt/branch/shared/modules/chat-flow/interfaces/edit-modal-dismiss-event-value.interface';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { App, Content, NavParams } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';
import { CANCEL_IDENTIFICATION_DOCUMENT_TYPE } from '../chat-flow/cancel-identification-document.renderer';

@Component({
    selector: 'cancel-chat-component',
    templateUrl: 'cancel-chat.component.html'
})

/**
 * 解約チャットフロー制御用コンポーネント。
 */
@Component({
    selector: 'cancel-chat-component',
    templateUrl: 'cancel-chat.component.html'
})
export class CancelChatComponent extends AbstractChatFlowControlComponent implements AfterViewChecked, OnInit, OnDestroy {

    @ViewChild(Content) public content: Content;
    public state: CancelState;
    public headerOptions: ChatFlowHeaderInterfaces.Options;
    private currentEditShowchatIndex = -1;
    private options?: {
        component: string;
        title: string;
        process: number;
        clear: boolean;
        submitData: any;
    };
    constructor(
        private app: App,
        private store: CancelStore,
        private action: CancelAction,
        private navParams: NavParams,
        private injector: Injector,
        private modalServiceCancel: ModalService,
        private logging: LoggingService,
    ) {
        super(action, injector);
        this.options = navParams.get('options');
        this.state = this.store.getState();

        this.action.clearShowChats();
    }

    public ngOnInit() {
        if (this.navParams) {
            const data = this.navParams.get('submitData');
            if (data) {
                this.action.setData(data);
            }
        }
        this.action.submitDataBackup();
        this.initChatFlowControl();
        this.setupHeaderOptions();

        this.store.registerSignalHandler(CancelSignal.CHAT_FLOW_COMPELETE, (nextComponentType) => {
            if (nextComponentType === COMMON_CONSTANTS.ELEMENT_TYPE_COMPLETE) {
                this.viewCtrl.dismiss({
                    ...this.state
                });
            } else if (nextComponentType === ScreenTransition.BACK_TO_TOP) {
                Observable.timer(Constants.PageConsts.backToTopStayTime).subscribe(() => {
                    this.app.getRootNav().setRoot(TopComponent).then(() => {
                        this.viewCtrl.dismiss(undefined, undefined, { animate: false });
                    });
                    this.chatFlowInputField.clear();
                });
            } else {
                this.onChatFlowComplete(nextComponentType, TopComponent);
            }
        });
        this.store.registerSignalHandler(CancelSignal.GET_QUESTION, (pageIndex: number) => {
            this.onYamlDidLoad(pageIndex);
        });
        this.store.registerSignalHandler(CancelSignal.SEND_ANSWER, (data) => {
            this.onNextMessage(data);
        });
        // 本人確認書類の修正チャット起動時の場合、同チャットの回答内容をクリアする
        if (this.navParams.get('name') === 'identificationDocument') {
            this.action.clearCancelDocuments();
        } else if (this.navParams.get('name') === 'cancelReason') {
            this.action.clearCancelReason();
        }
        // 修正チャットに経由した場合
        if (this.navParams.get('isCurrentPage') === true) {
            this.action.setStateSubmitDataValue({
                name: 'isEdited',
                value: true
            });
        }
    }

    public ngOnDestroy() {
        this.destoyChatFlowControl();
        this.store.unregisterSignalHandler(CancelSignal.CHAT_FLOW_COMPELETE);
        this.store.unregisterSignalHandler(CancelSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(CancelSignal.SEND_ANSWER);
    }

    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    public onModalDismiss() {
        this.action.resetLastNode(true);
    }

    /**
     * タイトル取得
     */
    public get headerTitle(): string {
        return this.labels.header.cancel.title;
    }

    public get processItems() {
        return [
            {
                type: COMMON_CONSTANTS.ProcessType.RequiredInput,
                value: this.labels.header.cancel.one,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyInfoConfirm,
                value: this.labels.header.cancel.three,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.BankClerkConfirm,
                value: this.labels.header.cancel.four,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
                value: this.labels.header.cancel.five,
            }
        ];
    }

    /**
     * Editボタンが押下された際に`openEditModal`イベントを発火し、EditModalを表示する。
     *
     * @param order
     * @param pageIndex
     * @param answerOrder
     * @param showChatIndex
     */
    public editChat(order: number, pageIndex: number, answerOrder: number, orderIndex: number): void {
        this.currentEditShowchatIndex = orderIndex;
        super.onEdit(order, pageIndex, answerOrder);
    }

    /**
     * ユーザが回答を編集するかどうかを決定した際に呼び出されるハンドラ。
     *
     * @param {EditModalDismissEventValue} event
     */
    public onEditModalDismiss(event: EditModalDismissEventValue): void {
        const preventedItem = this.editService.endEdit();
        if (event.buttonValue === EditModalButtonValue.EDIT) {
            this.currentRenderer.resetEvents();
            this.action.editAnswer(event.order, event.pageIndex, event.answerOrder, this.currentEditShowchatIndex);
            this.chatFlowInputField.clear();
            this.currentRendererIndex = event.pageIndex;
            this.currentRenderer = this.setupRenderer(event.pageIndex);
            this.getNextChatMessage(event.order, event.pageIndex);
            const deleteCount = this.rendererList.length - this.currentRendererIndex - 1;
            this.rendererList.splice(this.currentRendererIndex + 1, deleteCount);
        } else {
            if (preventedItem) {
                this.getNextChatMessage(preventedItem.order, preventedItem.pageIndex);
            } else {
                this.onModalDismiss();
            }
        }
    }

    /**
     * ProcessTypeを取得する。
     *
     * @memberof CancelChatComponent
     */
    public get processType(): number {
        return this.chatFlowNavParam.isCurrentPage ? -1 : this.currentRenderer.processType;
    }

    /**
     * 戻るボタンクリックHandler
     */
    public cancelEmitterHandler() {
        // 本人確認書類聴取チャットの場合は申込内容確認画面に戻る、それ以外は修正チャットの戻るボタン
        if (this.processType === COMMON_CONSTANTS.ProcessType.BankClerkConfirm) {
            const buttonList = [
                { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
                { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
            ];
            this.modalServiceCancel.showWarnAlert(
                this.labels.alert.backToConfirmTitle,
                buttonList,
                (item) => {
                    if (item.buttonValue === 'back') {
                        this.viewCtrl.dismiss('backConfirmCancel');
                    }
                }
            );
        } else {
            this.action.setModifyFlg(false);
            this.saveOperationLog();
            this.action.resetSubmitData();
            super.cancelEmitterHandler();
        }
    }

    protected getRendererNameByIndex(index: number) {
        const componentNameMap = {
            0: CANCEL_INIT_RENDERER_TYPE,
            1: CANCEL_RENDERER_TYPE,
            98: CANCEL_IDENTIFICATION_DOCUMENT_TYPE
        };
        // 定期解約の本人確認チャットに遷移するため、以下の処理を追加
        if (this.options && this.options.component) {
            return this.options.component;
        }
        const componentName = componentNameMap[index];
        return componentName;
    }

    protected branchStatusUpdate() {
        // todo 更新の必要がない場合、削除してください。
    }

    private setupHeaderOptions() {
        if (!this.chatFlowNavParam.isCurrentPage) {
            this.headerOptions = {
                showReturnTopButton: true,
                topComponent: TopComponent,
                title: this.headerTitle,
                needTwoBtnInLeftButton: true,
                leftButtonType: this.processType === COMMON_CONSTANTS.ProcessType.BankClerkConfirm ?
                    ChatFlowHeaderOptions.LeftButtonType.BACK_CONFIRM
                    : ChatFlowHeaderOptions.LeftButtonType.CALL_CLERK
            };
        } else {
            this.headerOptions = {
                showReturnTopButton: false,
                title: this.chatFlowNavParam.currentTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
            };
        }
    }

    /**
     *  操作ログ
     */
    private saveOperationLog() {
        const logInfo: IOperationInfo = {
            screenName: this.state.currentFileInfo.screenId,
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: this._labels.logging.Common.Header.CloseAction,
        };
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }
}
