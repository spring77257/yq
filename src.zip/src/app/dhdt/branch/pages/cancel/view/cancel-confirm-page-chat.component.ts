import {
    AfterViewChecked, Component, Injector, OnDestroy, OnInit, ViewChild
    } from '@angular/core';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CANCEL_MODIFY_RENDERER_TYPE } from 'dhdt/branch/pages/cancel/chat-flow/cancel-modify.renderer';
import { CancelSignal, CancelState, CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { AbstractChatFlowControlComponent } from 'dhdt/branch/shared/modules/chat-flow/components/abstract-chat-flow-control.component';
import {
    ChatFlowHeaderInterfaces, ChatFlowHeaderOptions
    } from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { Content } from 'ionic-angular';
/**
 * 解約チャットフロー制御用コンポーネント。
 */
@Component({
    selector: 'cancel-confirm-chat-component',
    templateUrl: 'cancel-chat.component.html'
})
export class CancelConfirmPageChatComponent extends AbstractChatFlowControlComponent implements AfterViewChecked, OnInit, OnDestroy {

    @ViewChild(Content) public content: Content;
    public state: CancelState;
    public headerOptions: ChatFlowHeaderInterfaces.Options;

    constructor(
        private store: CancelStore,
        private action: CancelAction,
        private loginStore: LoginStore,
        injector: Injector) {
        super(action, injector);

        this.state = this.store.getState();
    }

    public ngOnInit() {
        this.initChatFlowControl();
        this.setupHeaderOptions();
        this.store.registerSignalHandler(CancelSignal.CHAT_FLOW_COMPELETE, (nextComponentType) => {
            this.onChatFlowComplete(nextComponentType, TopComponent);
        });
        this.store.registerSignalHandler(CancelSignal.GET_QUESTION, (pageIndex: number) => {
            this.onYamlDidLoad(pageIndex);
        });
        this.store.registerSignalHandler(CancelSignal.SEND_ANSWER, (data) => {
            this.onNextMessage(data);
        });
    }

    public ngOnDestroy() {
        this.destoyChatFlowControl();
        this.store.unregisterSignalHandler(CancelSignal.CHAT_FLOW_COMPELETE);
        this.store.unregisterSignalHandler(CancelSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(CancelSignal.SEND_ANSWER);
    }

    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    /**
     * タイトル取得
     */
    public get headerTitle(): string {
        return this.labels.header.cancel.title;
    }

    /**
     * Cancel emitter handler
     */
    public cancelEmitterHandler() {
        super.cancelEmitterHandler();
        this.action.resetSubmitData();
    }

    public get processItems() {
        return [
            {
                type: COMMON_CONSTANTS.ProcessType.RequiredInput,
                value: this.labels.header.cancel.one,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyInfoConfirm,
                value: this.labels.header.cancel.three,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.BankClerkConfirm,
                value: this.labels.header.cancel.four,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
                value: this.labels.header.cancel.five,
            }
        ];
    }

    /**
     * update tablet_apply information
     */
    public updateTabletApplyInfo() {
        return;
    }

    protected getRendererNameByIndex(index: number) {
        return CANCEL_MODIFY_RENDERER_TYPE;
    }

    protected branchStatusUpdate() {
        // todo 更新の必要がない場合、削除してください。
    }

    private setupHeaderOptions() {
        if (!this.chatFlowNavParam.isCurrentPage) {
            this.headerOptions = {
                showReturnTopButton: true,
                topComponent: TopComponent,
                title: this.headerTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.CALL_CLERK
            };
        } else {
            this.headerOptions = {
                showReturnTopButton: false,
                title: this.chatFlowNavParam.currentTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
            };
        }
    }
}
