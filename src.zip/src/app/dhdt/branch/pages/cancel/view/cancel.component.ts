import { Component, NgZone, OnInit, } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { LabelService } from 'adep/services';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelListEntity } from 'dhdt/branch/pages/cancel/entity/cancel-list.entity';
import { CancelSubmitEntity } from 'dhdt/branch/pages/cancel/entity/cancel-submit.entity';
import { CancelConfirmPageCommonService,
    ConfirmPageComponentParamName } from 'dhdt/branch/pages/cancel/service/cancel-confirmpage.common.service';
import { CancelSignal, CancelState, CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';
import { CancelConfirmComponent } from 'dhdt/branch/pages/cancel/view/cancel-confirm.component';
import { ClearChangeImagesClickRecordType, COMMON_CONSTANTS,
    HostResultCode, MaskingCheckboxName } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ShowChartParam } from 'dhdt/branch/shared/components/confirmpage-common/showchart.param';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { NavController } from 'ionic-angular';
import { ModalController } from 'ionic-angular/components/modal/modal-controller';
import { NavParams } from 'ionic-angular/navigation/nav-params';
import { CancelChatComponent } from './cancel-chat.component';

@Component({
    selector: 'cancel-component',
    templateUrl: 'cancel.component.html'
})
export class CancelComponent extends BaseComponent implements OnInit {

    public state: CancelState;
    public submitted: boolean = false;
    public selfCheckStatus: boolean;
    public originSubmitData: CancelSubmitEntity;
    public confirmPageCommonParams: Map<string, any> = null;
    // 二度押下を回避するフラグ
    public isBackToCustomerConfirmPage = false;
    constructor(private navCtrl: NavController,
                private modalService: ModalService,
                private logging: LoggingService,
                private loginStore: LoginStore,
                private action: CancelAction,
                private savingsAction: SavingsAction,
                private store: CancelStore,
                private labelService: LabelService,
                private errorMessageService: ErrorMessageService,
                private navParam: NavParams,
                private zone: NgZone,
                private cancelConfirmPageCommonService: CancelConfirmPageCommonService,
                private modalCtrl: ModalController,
    ) {
        super();
        this.state = this.store.getState();
        this.originSubmitData = this.navParam.get('originSubmitData');
    }

    public ngOnInit() {
        this.cancelConfirmPageCommonService.loadConfirmTemplate();
        this.confirmPageCommonParams = this.cancelConfirmPageCommonService.getCancelConfirmPageComponentParams();
    }

    /**
     * APIが成功した場合、次ページに遷移。
     */
    public pushNextPage(params: any) {
        // 定期積立解約実行APIを呼び出し、払い戻し明細を勘定系へ連携する。
        // 申込完了モーダルを表示する。	「DHDT_API詳細_L01-W-API004_定期積立支払・解約処理」を呼び出し
        this.store.registerSignalHandler(CancelSignal.SUCCESS_INSERT_CANCEL_INFO, (result) => {
            this.store.unregisterSignalHandler(CancelSignal.SUCCESS_INSERT_CANCEL_INFO);
            if (result.resultCode === HostResultCode.SUCCESS) {
                this.modalService.showCompleteModal().subscribe({
                    next: (event) => {
                        switch (event) {
                            case COMMON_CONSTANTS.BACK_TYPE_REAPPLY_MENU:
                                this.navCtrl.setRoot(ChatComponent, { reapplyFlg: true });
                                break;
                            default:
                                this.navCtrl.setRoot(TopComponent);
                        }
                    },
                    complete: () => {
                        this.action.clearStore();
                        this.savingsAction.clearStore();
                    }
                });
            } else {
                this.errorMessageService.showMessageModal(this.labelService.labels.common.error.host.applyErrorMessage, () => {
                    this.navCtrl.setRoot(TopComponent);
                    this.action.clearStore();
                    this.savingsAction.clearStore();
                });
            }
        });
        this.action.cancelInfoInsert(params);
    }

    /**
     * 前遷移画面を設定する
     */
    public backToInfoConfirmPage() {
        this.isBackToCustomerConfirmPage = true;
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    // 定期解約submitDataを書類聴取チャット実施直前の状態に復元する
                    this.action.setStateData({ submitData: this.originSubmitData });
                    // 申込内容確認に戻るので、未マスキング状態管理オブジェクト（喪失側）をクリア
                    this.action.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.CLEAR);
                    // 定期解約StateのcheckboxStatusを初期化（falseをセット）する
                    this.action.resetCheckboxStatus();
                    this.action.setStateSubmitDataValue({ name: 'isBackToChangeConfirmPage', value: false });
                    this.navCtrl.setRoot(CancelConfirmComponent);
                    this.logging.saveCustomOperationLog(
                        this.state.submitData.fileInfo[0].screenId,
                        this.labels.logging.AccountConfirm.backConfirmButton,
                    );
                } else {
                    this.isBackToCustomerConfirmPage = false;
                }
            }
        );
    }

    public submit() {
        if (this.state.submitData.holderTelNo1 === null && this.state.submitData.holderTelNo2 === null
            && this.state.submitData.holderTelNo3 === null) {
            const buttonList = [
                { text: this.labels.common.dialog.ok, buttonValue: 'ok' }
            ];
            this.modalService.showWarnAlert(
                this.labels.alert.registerPhone,
                buttonList,
                (item) => {
                    if (item.buttonValue === 'ok') {
                        this.saveSubmit();
                    }
                },
                null
            );
        } else {
            this.saveSubmit();
        }
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo[0].screenId,
            this.labels.logging.AccountConfirm.confirmButton,
        );
    }

    /**
     * 本人確認書類の「修正」ボタン押下
     */
    public onEdit(key?: string) {
        const param: ShowChartParam = this.confirmPageCommonParams.get(ConfirmPageComponentParamName.IDENTIFICATION_DOCUMENT);
        const modalSub = this.modalCtrl.create(CancelChatComponent,
            {
                startOrder: param.startOrder, endOrder: param.endOrder, name: param.name,
                pageIndex: param.pageIndex, isCurrentPage: true, currentTitle: param.currentTitle, needPassword: true
            },
            { cssClass: 'full-modal', enableBackdropDismiss: false }
        );
        modalSub.onDidDismiss((value) => {
            if (value === 'close') {
                // 修正チャット離脱（戻るボタン押下）の場合
                return;
            }
            // マスキング確認チェックボックスがチェック状態の場合、falseをセット
            if (this.state.checkboxStatus.isAllMaskingStatus) {
                this.checkboxStatusEmmiterHandler(MaskingCheckboxName.MASKING_CHECKBOX_NAME);
            }
            // 未マスキング状態管理オブジェクトを再設定する
            this.action.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.CHANGE_DOCUMENT);
        });
        modalSub.present();
    }

    public disableNextButton(): boolean {
        return !(this.state.submitData.receptionNumber
            && this.selfCheckStatus
            && this.state.checkboxStatus.isAllMaskingStatus);
    }

    public onChangeReceptionNumber(data) {
        data.forEach((element) => {
            this.action.setStateSubmitDataValue({
                name: element.key,
                value: element.value
            });
        });
        this.action.updateSubmitDataBackup(data);
    }

    public onChangeSelfInfo(data) {
        data.forEach((element) => {
            this.action.setStateSubmitDataValue({
                name: element.key,
                value: element.value
            });
        });
        this.action.setSelfConfirmInfo(data);
    }

    public onImageMaskingComplete(data: { index: number, fieldName: string, value: string }) {
        this.action.editSubmitData(data.index, data.fieldName, data.value);
    }

    public checkboxStatusEmmiterHandler(checboxItem: string) {
        this.action.modifyCheckboxStatus(checboxItem);
    }

    /**
     * 未マスキング状態管理オブジェクトからマスキング完了済みの画像のindexを削除する
     * （マスキングモーダル内の「マスキング確認完了」ボタン押下時）
     */
    public onMaskingConfirmEmmiterHandler(maskingConfirmImgStatus: { documentName: string, index: number }) {
        this.action.removeNotMaskingConfirmImages(maskingConfirmImgStatus);
    }

    public selfCheckBoxStatus(checkItem: boolean) {
        this.selfCheckStatus = checkItem;
    }

    private preparedInsertData() {
        // dataの加工処理を実行する
        return {
            tabletApplyId: this.state.submitData.tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                // EQ番号
                eyeCueNo: this.state.submitData.receptionNumber,
                // 行員ID
                bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
                // オペレータ氏名
                operatorName: this.loginStore.getState().clerkInfo.operatorName,
                customerId:	this.state.submitData.customerId,
                nameKanji: this.state.submitData.nameKanjiBackup || this.state.submitData.nameKanji,
                nameKana: this.state.submitData.nameKana,
                identificationDoc: null,
                markNo: null,
                cancelReason: this.state.submitData.cancelReason,
                cancelableList: this.setCancelableList(),
                transferBranchNo: this.state.submitData.transferAccountInfo.branchNo,
                transferAccountType: this.state.submitData.transferAccountInfo.accountType,
                transferAccountNo: this.state.submitData.transferAccountInfo.accountNo,
                depositDetailsCountList: this.state.depositDetailsCountList,
                // 画像１
                identificationDoc1: this.state.submitData.identificationDoc1Images,
                // 画像２
                identificationDoc2: this.state.submitData.identificationDoc2Images ?
                this.state.submitData.identificationDoc2Images : null,
                // 画像ファイル名
                identificationDocName: this.setIdentificationDocName(),
            }
        };
    }

    private setCancelableList(): CancelListEntity[] {
        this.state.submitData.cancelableList.forEach((cancelableAccount) => {
            for (const cancelAccount of this.state.cancelableList) {
                if (cancelableAccount.branchNo === cancelAccount.branchNo && cancelableAccount.accountNo === cancelAccount.accountNo
                    && cancelableAccount.accountType === cancelAccount.accountType) {
                        // 元帳残高 - 概算支払金額 = 0円のとき、フラグを立つ。
                        if (cancelAccount.depositAmount === cancelAccount.estimatedPaymentAmount) {
                            cancelableAccount.paymentEqualLedger = COMMON_CONSTANTS.PAYMENT_EQUAL_LEDGER_FLAG;
                            break;
                        }
                }
            }
        });
        return this.state.submitData.cancelableList;
    }

    private setIdentificationDocName() {
        const identificationDocNameList: string[] = [];
        const identificationDoc1Name: string = this.state.submitData.identificationDoc1NameInput ?
        this.state.submitData.identificationDoc1NameInput : this.state.submitData.identificationDoc1Text;
        identificationDocNameList.push(StringUtils.convertHankaku2Zankaku(identificationDoc1Name));
        if (this.state.submitData.identificationDoc2NameInput) {
            identificationDocNameList.push(StringUtils.convertHankaku2Zankaku(this.state.submitData.identificationDoc2NameInput));
        }
        return identificationDocNameList;
    }

    private saveSubmit() {
        this.submitted = true;
        const preparedInsertData = this.preparedInsertData();
        this.pushNextPage(preparedInsertData);
    }

}
