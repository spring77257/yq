/**
 * 解約振替口座情報エンティティ。
 */
export class TransferListEntity {

    // 店番号
    public branchNo: string;
    // 科目コード
    public accountType: string;
    // 口座番号
    public accountNo: string;
    // 総合口座有無
    public compoundAccountStatus: string;
    // 表面残高
    public depositAmount: string;
    // 重要用紙種類コード
    public passbookInfoCode: string;
    // 通帳区分
    public passbookCategory: string;
    // 明細作成周期
    public detailCreateCycle: string;
    // Web口座表示
    public webAccountStatus: string;
    // 解約の場合、共通componentで金額を表示されない
    public isCancel: boolean;

}
