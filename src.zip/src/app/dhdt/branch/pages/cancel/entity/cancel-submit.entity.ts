import { CancelListEntity } from 'dhdt/branch/pages/cancel/entity/cancel-list.entity';
import { TransferListEntity } from 'dhdt/branch/pages/cancel/entity/transfer-list.entity';

/**
 * 商品情報以外の情報を保存しておくエンティティ。
 * インサートAPIに渡す情報を保存するエンティティ。
 */
export class CancelSubmitEntity {

    public accountType: string;
    public accountTypeText: string;
    public leaveType: string;
    public branchNo: string;
    public branchNameKanji: string;
    public agencyBranchNo: string;
    public cancelableFlg: string;
    public customerId: string;
    public transferList: TransferListEntity[];
    public transferFlg: string;
    public transferAccountInfo: TransferListEntity;
    public isCancel: boolean; // 解約の場合、共通componentで金額を表示されない
    public nameKanji: string;
    public nameKanjiBackup: string;
    public nameKana: string;
    public address: string;
    public holderTelNo1: string;
    public holderTelNo2: string;
    public holderTelNo3: string;

    public addressDiffrentReason: string;

    public firstZipCode: string;
    public lastZipCode: string;

    public totalAmount: number;

    // 名義人―記号番号
    public holderSignNo: string;
    public holderPublisher: string;
    public holderPublishDate: string;
    public holderNoCopyReason: string;

    // 行員ID
    public userMngNo: string;
    // 顧客申込入力完了日時
    public customerApplyEndDate: string;
    // 行員認証入力開始日時
    public bankclerkAuthenticationStartDate: string;
    // 行員認証入力完了日時
    public bankclerkAuthenticationEndDate: string;
    // 行員確認日時
    public bankclerkConfirmDate: string;
    // ステータス
    public status: string;

    public receptionBranchNo: string;        // 受付店番
    public receptionNo: string;        // 受付番号
    public receptionNumber: string;        // 受付番号
    public receptionTime: string;        // 受付年月日時分秒
    public nameNonConvert: string;

    // タブレット申込管理番号
    public tabletApplyId: number;
    // 申込業務区分
    public applyBusinessType: string;
    // RQ番号
    public rqNo: string;
    public cardInfo: any;
    public cancelList: CancelListEntity[];

    public cancelableList: CancelListEntity[];

    public haveItems: string;

    public fileInfo?: any;
    public imagesInfos: any[];

    public identificationDoc: string;
    public markNo: string;
    public cancelReason: string;
    // 修正チャットに経由
    public isEdited: boolean;

    /** 本人確認書類1（コード値） */
    public identificationDoc1: string;
    /** 本人確認書類1（表示名） */
    public identificationDoc1Text: string;
    /** 本人確認書類1（画像） */
    public identificationDoc1Images: string[];
    /** 本人確認書類1 具体的な書類名（入力値） */
    public identificationDoc1NameInput: string;

    /** 本人確認書類2（画像） */
    public identificationDoc2Images: string[];
    /** 本人確認書類2 具体的な書類名（入力値） */
    public identificationDoc2NameInput: string;
}

export enum identificationDoc {
    /** 本人確認書類1（コード値） */
    identificationDoc1 = 'identificationDoc1',
    /** 本人確認書類1（表示名） */
    identificationDoc1Text = 'identificationDoc1Text',
    /** 本人確認書類1（画像） */
    identificationDoc1Images = 'identificationDoc1Images',
    /** 本人確認書類1 具体的な書類名（入力値） */
    identificationDoc1NameInput = 'identificationDoc1NameInput',
    /** 本人確認書類2（画像） */
    identificationDoc2Images = 'identificationDoc2Images',
    /** 本人確認書類2 具体的な書類名（入力値） */
    identificationDoc2NameInput = 'identificationDoc2NameInput',
}

export class CheckboxStatusEntity {
    /** 写真マスキング */
    public isAllMaskingStatus: boolean;

}
