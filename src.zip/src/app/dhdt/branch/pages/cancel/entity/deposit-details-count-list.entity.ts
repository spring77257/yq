/**
 * 預入明細数情報エンティティ。
 */
export class DepositDetailsCountListEntity {
    // 店番号
    public branchNo: string;
    // 科目コード
    public accountType: string;
    // 口座番号
    public accountNo: string;
    // 預入明細数
    public depositDetailsCount: string;
}
