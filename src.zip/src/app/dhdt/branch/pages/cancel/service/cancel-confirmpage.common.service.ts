import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { CancelAction } from 'dhdt/branch/pages/cancel/action/cancel.action';
import { CancelStore } from 'dhdt/branch/pages/cancel/store/cancel.store';

export namespace ConfirmPageComponentParamName {
    export const CANCELINFO_CANCELLIST: string = 'CANCELINFO_CANCELLIST';
    export const TRANSFER_ACCOUNT: string = 'TRANSFER_ACCOUNT';
    export const IDENTIFICATION_DOCUMENT: string = 'IDENTIFICATION_DOCUMENT';
    export const CANCEL_REASON: string = 'CANCEL_REASON';
}

export namespace ChatID {
    export const CANCEL_IDENTIFICATION_DOCUMENT_MODIFY: Number = 98;
    export const CANCEL_MODIFY: Number = 99;
}

@Injectable()
export class CancelConfirmPageCommonService {
    private params: Map<string, any>;
    private store: CancelStore;
    private action: CancelAction;

    constructor(private labelService: LabelService) {
        this.store = InjectionUtils.injector.get(CancelStore);
        this.action = InjectionUtils.injector.get(CancelAction);
        this.params = new Map();
    }

    public loadConfirmTemplate() {
        this.action.loadConfirmPageTemplate('chat-flow-def-cancel-identification-document.yml', 98);
        this.action.loadConfirmPageTemplate('chat-flow-def-cancel-modify.yml', 99);
    }

    /**
     * 修正ボタン押下時のチャットのパラメーター設定。
     */
    public getCancelConfirmPageComponentParams() {
        this.params.set(ConfirmPageComponentParamName.CANCELINFO_CANCELLIST,
            {startOrder : 1, endOrder : 30, name : 'cancelList',
             currentTitle : this.labelService.labels.cancel.confirm.modifyChatTitle, pageIndex : ChatID.CANCEL_MODIFY});
        this.params.set(ConfirmPageComponentParamName.TRANSFER_ACCOUNT,
            {startOrder : 70, endOrder : 80, name : 'transferAccount',
             currentTitle : this.labelService.labels.cancel.confirm.transferAccountTitle, pageIndex : ChatID.CANCEL_MODIFY});
        this.params.set(ConfirmPageComponentParamName.IDENTIFICATION_DOCUMENT,
            {startOrder : 5, endOrder : 20, name : 'identificationDocument',
             currentTitle : this.labelService.labels.cancel.confirm.document, pageIndex : ChatID.CANCEL_IDENTIFICATION_DOCUMENT_MODIFY});
        this.params.set(ConfirmPageComponentParamName.CANCEL_REASON,
            {startOrder : 21, endOrder : 21, name : 'cancelReason',
             currentTitle : this.labelService.labels.cancel.confirm.document, pageIndex : ChatID.CANCEL_IDENTIFICATION_DOCUMENT_MODIFY});
        return this.params;
    }
}
