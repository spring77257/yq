import { NgModule } from '@angular/core';
import { AccountShopModule } from 'dhdt/branch/shared/components/account-shop/account-shop.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular';
import { AddCheckChangeAction } from './action/add-check-change.action';
import { AddCheckChangeRenderer } from './chat-flow/add-check-change.render';
import { AddCheckInputChangeHandler } from './chat-flow/add-check-input-change.handler';
import { AddCheckChangeStore } from './store/add-check-change.store';
import { AddCheckChangeChatComponent } from './view/add-check-change-chat.component';

@NgModule({
    imports: [
        IonicModule,
        SharedModule,
        AccountShopModule
    ],
    entryComponents: [
        AddCheckChangeChatComponent
    ],
    declarations: [
        AddCheckChangeChatComponent
    ],
    providers: [
        AddCheckChangeAction,
        AddCheckChangeStore,
        AddCheckChangeRenderer,
        AddCheckInputChangeHandler
    ]
})
export class AddCheckChangeModule {
}
