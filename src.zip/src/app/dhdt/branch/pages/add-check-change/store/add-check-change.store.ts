import { Injectable, NgZone } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { AppProperties } from 'app.properties';
import { CashCardDeliveryType } from 'dhdt/branch/pages/change/change-consts';
import {
     ChatFlowMessageInterface, ChatFlowMessageWithPageIndexInterface
    } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { KanaToRomaji } from 'dhdt/branch/shared/utils/kana-to-romaji-util';
import { Observable } from 'rxjs';
import { AddCheckChangeActionType } from '../action/add-check-change.action';

export const AddCheckChangeStateSignal = {
    GET_QUESTION: 'AddCheckChangeStateSignal_GET_QUESTION',
    SEND_ANSWER: 'AddCheckChangeStateSignal_SEND_ANSWER',
    CHAT_FLOW_COMPLETE: 'AddCheckChangeStateSignal_CHAT_FLOWCOMPLETE',
};

export interface AddCheckChangeState extends State {
    questions: ChatFlowMessageInterface[][];
    showChats: ChatFlowMessageWithPageIndexInterface[];
    idDocList: any;
    currentFileInfo: any;
    currentCif: any;
    tabletApplyId: string;
    receptionTenban: string;
    currentFileInfoscreenId: any;
    bcNameRoma: any;
    customerId: string;
    nameKana: string;
    nameAlphabet: String;
    nationalityCode: string;
    holderNameFurigana: string;
    holderNameAlphabet: string;
    cardInfo: any;
    bcHoldingStatus: string;
    bcSuicaHoldingStatus: string;
    cdHoldingStatus: string;
    addCheckChangeData: any;
}

@Injectable()
export class AddCheckChangeStore extends Store<AddCheckChangeState> {
    private keysArr: any[] = [];

    constructor(
        private editService: EditService,
        private ngZone: NgZone,
    ) {
        super();
        this.initState();
    }

    private initState() {
        this.state = {
            questions: [],
            showChats: [],
            idDocList: {},
            currentFileInfo: {},
            currentCif: {},
            tabletApplyId: '',
            receptionTenban: '',
            currentFileInfoscreenId: {},
            customerId: '',
            bcNameRoma: {},
            nameKana: '',
            nameAlphabet: '',
            nationalityCode: '',
            holderNameFurigana: '',
            holderNameAlphabet: '',
            cardInfo: {},
            bcHoldingStatus: '',
            bcSuicaHoldingStatus: '',
            cdHoldingStatus: '',
            addCheckChangeData: {}
        };
    }

    @ActionBind(AddCheckChangeActionType.PRESENT)
    private onPresent(data) {
        this.initState();
        this.state.currentCif = data.cifInfoInquiry;
        this.state.idDocList = {...data.changeDocumentImages, ...data.nameIdentiAddressImage};
        this.state.nameKana = data.nameKana;
        this.state.nameAlphabet = data.nameAlphabet;
        this.state.nationalityCode = data.nationalityCode;
        this.state.holderNameFurigana = data.holderNameFurigana;
        this.state.holderNameAlphabet = data.holderNameAlphabet;
        this.state.customerId = data.customerId;
        this.state.cardInfo = data.cardInfo;
        this.state.addCheckChangeData.firstNameRoma = data.firstNameRoma;
        this.state.addCheckChangeData.lastNameRoma = data.lastNameRoma;
        this.state.addCheckChangeData.cardDeliveryCategory = null;
        this.state.addCheckChangeData.bcSuica = null;
        this.state.addCheckChangeData.americanSuggestionInformationStatus = null;
        this.state.cdHoldingStatus = data.cdHoldingStatus;
        this.state.bcHoldingStatus = data.bcHoldingStatus;
        this.state.bcSuicaHoldingStatus = data.bcSuicaHoldingStatus;

        // 申請ID
        this.state.tabletApplyId = data.tabletApplyId;
        // 受付店舗番号
        this.state.receptionTenban = data.receptionTenban;
    }

    @ActionBind(AddCheckChangeActionType.SET_NAME_ROMA)
    private setNameRoma(data: any) {
        if (data && data.zFirstNameKana) {
            const kanaToRomaji = new KanaToRomaji();
            this.setStateData('firstNameRoma', kanaToRomaji.convert(data.zFirstNameKana));
            this.setStateData('lastNameRoma', kanaToRomaji.convert(data.zLastNameKana));
        } else if (data && data.zFirstNameAlphabet) {
            this.setStateData('firstNameRoma', data.zFirstNameAlphabet);
            this.setStateData('lastNameRoma', data.zLastNameAlphabet);
        }
    }

    @ActionBind(AddCheckChangeActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(AddCheckChangeStateSignal.GET_QUESTION, params.pageIndex);
        }
    }

    @ActionBind(AddCheckChangeActionType.CHAT_FLOW_COMPLETE)
    private chatFlowComplete(value: any) {
        this.sendSignal(AddCheckChangeStateSignal.CHAT_FLOW_COMPLETE, value);
    }

    @ActionBind(AddCheckChangeActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: { order: number, pageIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .min<ChatFlowMessageInterface>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: item.question,
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order
                        };
                        this.state.showChats.push(qus);
                        this.sendSignal(AddCheckChangeStateSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: item.question,
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order
                        };
                        this.state.showChats.push(qus);
                        this.sendSignal(AddCheckChangeStateSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => {
                // DO NOTHING
            });
        });
    }

    @ActionBind(AddCheckChangeActionType.EDIT_CHAT)
    private editAnswer(params: { order: number, pageIndex: number, answerOrder: number, showChatIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;

        let i = -1;
        let index = -1;
        if (params.showChatIndex) {
            index = params.showChatIndex;
        } else {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order) {
                    index = i;
                }
            });
        }

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }
        this.cleanStateData(answerOrder);
    }

    @ActionBind(AddCheckChangeActionType.RESET_LAST_NODE)
    private resetLastNode(params: { order: number, pageIndex: number }) {
        const lastNode = this.getState().showChats.pop();
        this.getNextChatByAnswer({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    @ActionBind(AddCheckChangeActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    private cleanStateData(remain: number) {
        this.keysArr = this.keysArr.slice(0, remain);
        for (const item in this.state.addCheckChangeData) {
            if (item.startsWith('get')) {
                continue;
            }
            if (this.keysArr.indexOf(item) < 0) {
                this.state.addCheckChangeData[item] = undefined;
            }
        }
    }

    /**
     * submit dataをセットする
     *
     * @param key キー
     * @param value 値
     */
    private setStateData(key, value) {
        if (key !== undefined) {
            this.state.addCheckChangeData[key] = value;
            this.keyPush(key, value);
        }
    }

    /**
     * キーと値を配列に保存する
     *
     * @param key キー
     * @param value 値
     */
    private keyPush(key: any, value: any) {
        if (value === null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                this.keysArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1) {
            this.keysArr.push(key);
        }
    }

    // 顧客入力情報をstateにセット
    @ActionBind(AddCheckChangeActionType.SET_ANSWER)
    private setAnswer(answer: { order: number, text: string, value: Array<{ key: string, value: string }> }) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        answer.order = this.keysArr.length;
        chat.answer = answer;
        if (answer.value) {
            answer.value.forEach((item) => {
                this.setStateData(item.key, item.value);
            });
        }
    }

    // カード交付方法に郵送をセット)
    @ActionBind(AddCheckChangeActionType.SET_DATA)
    private setMailDelivery() {
        this.setStateData('cardDeliveryCategory', CashCardDeliveryType.MAIL_CODE);
    }

    @ActionBind(AddCheckChangeActionType.CLEAR_ANSWER)
    private clearAnswer(answer: string) {
        this.setStateData(answer, null);
    }

}
