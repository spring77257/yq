import { AfterViewChecked, Component, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { LabelService } from 'adep/services';
import { AddCheckChangeAction } from 'dhdt/branch/pages/add-check-change/action/add-check-change.action';
import { ADD_CHECK_CHANGE_RENDERER } from 'dhdt/branch/pages/add-check-change/chat-flow/add-check-change.render';
import {
    AddCheckChangeState, AddCheckChangeStateSignal, AddCheckChangeStore
} from 'dhdt/branch/pages/add-check-change/store/add-check-change.store';
import { ScreenTransition } from 'dhdt/branch/pages/change/change-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { AbstractChatFlowControlComponent } from 'dhdt/branch/shared/modules/chat-flow/components/abstract-chat-flow-control.component';
import {
    ChatFlowHeaderInterfaces, ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { App, Content } from 'ionic-angular';

/**
 * 諸届変更　追加確認のチャット
 * @export
 * @class AddCheckChangeChatComponent
 * @extends {AbstractChatFlowControlComponent}
 * @implements {OnInit}
 * @implements {OnDestoroy}
 */
@Component({
        selector: 'add-check-change-chat-component',
        templateUrl: 'add-check-change-chat.component.html'
})
export class AddCheckChangeChatComponent extends AbstractChatFlowControlComponent implements OnInit, OnDestroy, AfterViewChecked {
    @ViewChild(Content) public content: Content;
    public state: AddCheckChangeState;
    public headerOptions: ChatFlowHeaderInterfaces.Options;

    constructor(
        private store: AddCheckChangeStore,
        private action: AddCheckChangeAction,
        private labelService: LabelService,
        private app: App,
        injector: Injector
    ) {
        super(action, injector);
        this.state = this.store.getState();
    }

    /**
     * 初期化処理として以下を行う
     * AbstractChatFlowControlComponent`の初期化メソッド(`initChatFlowControl`)を実行する。
     * ChatFlowHeaderComponent`用のオプションをセットアップする。
     * Storeからのシグナルを登録する。
     *
     * @memberof AddcheckActionTypeChatComponent
     */
    public ngOnInit() {
        this.initChatFlowControl();
        this.setupHeaderOptions();

        this.action.onPresent(this.chatFlowNavParam);
        this.store.registerSignalHandler(AddCheckChangeStateSignal.CHAT_FLOW_COMPLETE, (value) => {
            if (value === ScreenTransition.BACK_TO_TOP) {
                this.app.getRootNav().setRoot(TopComponent).then(() => {
                    this.viewCtrl.dismiss(undefined, undefined, { animate: false });
                });
                return;
            }
            if (this.state.bcHoldingStatus === '0') {
                this.action.clearAnswer('firstNameRoma');
                this.action.clearAnswer('lastNameRoma');
            }
            if (this.state.bcSuicaHoldingStatus === '0') {
                this.action.clearAnswer('bcSuica');
            }
            if (this.state.cdHoldingStatus === '0') {
                this.action.clearAnswer('cardDeliveryCategory');
            }
            const data = {
                cardDeliveryCategory: this.state.addCheckChangeData.cardDeliveryCategory,
                bcSuica: this.state.addCheckChangeData.bcSuicaResult,
                americanSuggestionInformationStatus: this.state.addCheckChangeData.americanSuggestionInformationStatus,
                firstNameRoma: this.state.addCheckChangeData.firstNameRoma,
                lastNameRoma: this.state.addCheckChangeData.lastNameRoma
            };
            this.viewCtrl.dismiss(data);
        });
        this.store.registerSignalHandler(AddCheckChangeStateSignal.GET_QUESTION, (pageIndex: number) => {
            this.onYamlDidLoad(pageIndex);
        });
        this.store.registerSignalHandler(AddCheckChangeStateSignal.SEND_ANSWER, (data) => {
            this.onNextMessage(data);
        });
    }

    /**
     * クリーンアップ処理として以下を行う
     * AbstractChatFlowControlComponent`のクリーンアップメソッド(`destoyChatFlowControl`)を実行する。
     * Storeシグナルの登録を解除する。
     *
     * @memberof AddchecChangeChatComponent
     */
    public ngOnDestroy() {
        this.destoyChatFlowControl();
        this.store.unregisterSignalHandler(AddCheckChangeStateSignal.CHAT_FLOW_COMPLETE);
        this.store.unregisterSignalHandler(AddCheckChangeStateSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(AddCheckChangeStateSignal.SEND_ANSWER);
    }

    /**
     * ViewCheck後（Viewが変更された後）にメッセージコンテナを最下部へスクロールする。
     *
     * @memberof AddcheckChangeChatComponent
     */
    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    /**
     * Cancel emitter handler
     */
    public cancelEmitterHandler() {
        super.cancelEmitterHandler();
    }

    /**
     * ページのIndexに対して、コンポーネントの名前を取得する
     *
     * @Param {number} index
     */
    protected getRendererNameByIndex(index: number) {
        const componentNameMap = {
            0: ADD_CHECK_CHANGE_RENDERER,
        };

        let componentName = componentNameMap[index];
        if (!componentName) {
            componentName = ADD_CHECK_CHANGE_RENDERER;
        }

        return componentName;
    }

    /**
     * 店舗マスタを更新する
     */
    // tslint:disable-next-line: no-empty
    protected branchStatusUpdate(): void {
    }

    private setupHeaderOptions() {
        this.headerOptions = {
            showReturnTopButton: true,
            title: this.labelService.labels.change.basic.changeName,
            topComponent: TopComponent,
            leftButtonType: ChatFlowHeaderOptions.LeftButtonType.CALL_CLERK
        };
    }
}
