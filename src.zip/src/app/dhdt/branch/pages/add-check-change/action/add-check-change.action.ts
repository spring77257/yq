import { Injectable } from '@angular/core';
import { Action } from 'adep/flux';
import { API_URL } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ChatFlowActionInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-action.interface';
import { HttpService } from 'dhdt/branch/shared/services/http.service';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';

export namespace AddCheckChangeActionType {
    export const SET_ANSWER = 'AddCheckChangeActionType_SET_ANSWER';
    export const SET_DATA = 'AddCheckChangeActionType_SET_DATA';
    export const SET_NAME_ROMA = 'AddCheckChangeType_SET_NAME_ROMA';
    export const PRESENT = 'AddCheckChangeActionType_PRESENT';
    export const GET_SAVING_QUESTION_TEMPLATE = 'AddCheckChangeActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const CHAT_FLOW_COMPLETE = 'AddCheckChangeActionType_CHAT_FLOW_COMPLETE';
    export const NEXT_CHAT = 'AddCheckChangeActionType_NEXT_CHAT';
    export const EDIT_CHAT = 'AddCheckChangeActionType_EDIT_CHAT';
    export const RESET_LAST_NODE = 'AddCheckChangeActionType_RESET_LAST_NODE';
    export const CLEAR_SHOW_CHATS = 'AddCheckChangeActionType_CLEAR_SHOW_CHATS';
    export const SUBMIT_DATA_BACKUP = 'AddCheckChangeActionType_SUBMIT_DATA_BACKUP';
    export const CLEAR_ANSWER = 'AddCheckChangeActionType.CLEAR_ANSWER';
}

@Injectable()
export class AddCheckChangeAction extends Action implements ChatFlowActionInterface {

    constructor(
        private httpService: HttpService
    ) {
        super();
    }

    public setAnswer(answer: {text: string, value: Array<{key: string, value: string}>}) {
        this.dispatcher.dispatch({
            actionType: AddCheckChangeActionType.SET_ANSWER,
            data: answer
        });
    }

    public setMailDelivery() {
        this.dispatcher.dispatch({
            actionType: AddCheckChangeActionType.SET_DATA,
        });
    }

    public setNameRoma(params: any) {
        this.dispatcher.dispatch({
            actionType: AddCheckChangeActionType.SET_NAME_ROMA,
            data: params
        });
    }

    public chatFlowCompelete(value: any) {
        this.dispatcher.dispatch({
            actionType: AddCheckChangeActionType.CHAT_FLOW_COMPLETE,
            data: value
        });
    }

    public onPresent(data) {
        this.dispatcher.dispatch({
            actionType: AddCheckChangeActionType.PRESENT,
            data: data
        });
    }

    public loadTemplate(file: string, pageIndex: number) {
        this.httpService.get(API_URL.CHATFLOW_DEFINITION + file, null, null, SpinnerType.NO_SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: AddCheckChangeActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfo
                }
            });
        });
    }

    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: AddCheckChangeActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    public editAnswer(order: number, pageIndex: number, answerOrder: number, showChatIndex?: number): void {
        this.dispatcher.dispatch({
            actionType: AddCheckChangeActionType.EDIT_CHAT,
            data: {
                order: order, pageIndex: pageIndex, answerOrder: answerOrder, showChatIndex: showChatIndex
            }
        });
    }

    public resetLastNode(): void {
        this.dispatcher.dispatch({
            actionType: AddCheckChangeActionType.RESET_LAST_NODE
        });
    }

    public clearShowChats(): void {
        this.dispatcher.dispatch({
            actionType: AddCheckChangeActionType.CLEAR_SHOW_CHATS
        });
    }

    public submitDataBackup(): void {
        this.dispatcher.dispatch ({
            actionType: AddCheckChangeActionType.SUBMIT_DATA_BACKUP
        });
    }

    public clearAnswer(answer: string) {
        this.dispatcher.dispatch ({
            actionType: AddCheckChangeActionType.CLEAR_ANSWER,
            data: answer
        });
    }
}
