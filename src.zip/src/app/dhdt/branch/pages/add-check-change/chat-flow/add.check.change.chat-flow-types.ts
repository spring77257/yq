import { ChatFlowQuestionTypes } from 'dhdt/branch/shared/modules/chat-flow/chat-flow-question-types';

export class AddCheckChangeChatFlowTypes extends ChatFlowQuestionTypes {
    public static readonly BUTTON = 'button';
    public static readonly PRINTNAME = 'printName';
    public static readonly JUDGE = 'judge';
    public static readonly COMPLETE = 'complete';
}
