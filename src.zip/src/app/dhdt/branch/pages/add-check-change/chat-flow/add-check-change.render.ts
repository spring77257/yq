import { Injectable } from '@angular/core';
import { AddCheckChangeAction } from 'dhdt/branch/pages/add-check-change/action/add-check-change.action';
import { AddCheckInputChangeHandler } from 'dhdt/branch/pages/add-check-change/chat-flow/add-check-input-change.handler';
import { AddCheckChangeChatFlowTypes } from 'dhdt/branch/pages/add-check-change/chat-flow/add.check.change.chat-flow-types';
import { AddCheckChangeState, AddCheckChangeStore } from 'dhdt/branch/pages/add-check-change/store/add-check-change.store';
import { ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { Age, COMMON_CONSTANTS, CountryCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { MaxLength } from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { PrintNameInputComponent } from 'dhdt/branch/shared/components/print-name-input/print-name-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';

export const ADD_CHECK_CHANGE_RENDERER = 'AddCheckChangeRenderer';

@Injectable()
@ChatFlowRendererDefinition({
    rendererName: ADD_CHECK_CHANGE_RENDERER,
    templateYaml: 'chat-flow-def-add-check-confirmation-change.yml',
})

export class AddCheckChangeRenderer extends DefaultChatFlowRenderer {
    public processType: number = -1;
    private state: AddCheckChangeState;
    private changeState: ChangeState;

    constructor(
        private action: AddCheckChangeAction,
        private store: AddCheckChangeStore,
        private changeStore: ChangeStore,
        inputHandler: AddCheckInputChangeHandler,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.changeState = this.changeStore.getState();
    }

    @Renderer(AddCheckChangeChatFlowTypes.PRINTNAME)
    public onPrintName(entity: ChatFlowMessageInterface, pageIndex: number) {
        if (entity.name === 'bcNameRoma') {
            if (this.state.addCheckChangeData.firstNameRoma === '' || this.state.addCheckChangeData.firstNameRoma === undefined) {
                if (this.state.nationalityCode === CountryCode.Japan) {
                    const nameKanaArr = this.state.holderNameFurigana ?
                        this.state.holderNameFurigana.split(' ') : this.state.nameKana.split('　');
                    const firstNameKana = nameKanaArr[1];
                    const lastNameKana = nameKanaArr[0];
                    const params = {
                        zFirstNameKana: StringUtils.convertHankaku2Zankaku(firstNameKana),
                        zLastNameKana: StringUtils.convertHankaku2Zankaku(lastNameKana)
                    };
                    this.action.setNameRoma(params);
                }
            }
            const nameAlphabet = this.state.holderNameAlphabet ? this.state.holderNameAlphabet : this.state.nameAlphabet;
            const options = {
                validationRules: entity.validationRules,
                defaultValues: this.state.nationalityCode === CountryCode.Japan
                    ? [this.state.addCheckChangeData.firstNameRoma + ' ' + this.state.addCheckChangeData.lastNameRoma, '']
                    : [nameAlphabet, ''],
                maxLength: MaxLength.MAX_LENGTH_19,
                logInfo: {
                    screenName: this.state.currentFileInfo.screenId,
                    yamlId: this.state.currentFileInfo.yamlId,
                    yamlOrder: entity.order
                }
            };

            this.emitRenderEvent({
                class: PrintNameInputComponent,
                data: entity.choices,
                options: options
            }, entity, pageIndex);
        }
    }

    @Renderer(AddCheckChangeChatFlowTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        const idDocWithPhoto = /01|02|03|04|06|07|20|21|22|24|27/;
        const hasldDocKey = Object.keys(this.state.idDocList);
        const hasldDocWithPhotoKey = hasldDocKey.filter((element) => element.match(idDocWithPhoto)); // 撮影書類のうち顔写真付書類のID
        // hasldDocWithPhotoKeyから16歳未満の(=顔写真のない)在留カード・特別永住者証明書,在留カード,特別永住者証明書を除外した書類のID
        const hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto = this.isUnder16YearsOld()
            ? hasldDocWithPhotoKey.filter((element) => !/04|21|22/.test(element))
            : hasldDocWithPhotoKey;
        const isWelfareNotebook = (element) => element.match(/07/); // 各種福祉手帳
        const isOtherOfficialDocumentWithPhoto = (element) => element.match(/24/); // その他官公庁から発行された書類（写真付）
        const isHealthInsuranceCard = (element) => element.match(/06/); // 各種健康保険証
        const isResidenceCardOrSpecialPermanent = (element) => element.match(/04|21|22/); // 在留カード・特別永住者証明書,在留カード,特別永住者証明書
        let judgeResult: string;

        switch (entity.name) {
            case 'cashCardType':
                // CD即発チェック
                if (this.state.cdHoldingStatus) {
                    judgeResult = this.state.cdHoldingStatus === '1' ? '01' : '02';
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'bcCardType':
                // バンクカードチェック
                if (this.state.bcHoldingStatus) {
                    judgeResult = this.state.bcHoldingStatus === '1' ? '01' : '02';
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'bcSuicaCardType':
                // BC suicaチェック
                if (this.state.bcSuicaHoldingStatus) {
                    judgeResult = this.state.bcSuicaHoldingStatus === '1' ? '01' : '02';
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'idWithPhoto':
                // 顔写真付き本人確認書類かのチェック
                if (hasldDocKey.length > 0) {
                    for (const result of hasldDocKey) {
                        if (result.match(idDocWithPhoto)) {
                            judgeResult = '01';
                            break;
                        } else {
                            judgeResult = '02';
                        }
                    }
                } else {
                    judgeResult = '02';
                }
                if (judgeResult === '02') {
                    this.action.setMailDelivery();
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'judgeIdentificationDocument':
                if (hasldDocKey.some(isWelfareNotebook)
                    || hasldDocKey.some(isOtherOfficialDocumentWithPhoto)
                    || (hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.length > 0
                        && hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.every(isHealthInsuranceCard))) {
                    // 撮影書類に「各種福祉手帳」「その他官公庁から発行された書類（写真付）」のいずれかが含まれる
                    // もしくは撮影書類のうち顔写真付書類が「各種健康保険証」のみである場合: '01'
                    judgeResult = '01';
                } else if (hasldDocWithPhotoKey.length > 0
                    && hasldDocWithPhotoKey.every(isResidenceCardOrSpecialPermanent)) {
                    // 撮影書類のうち顔写真付書類が「在留カード・特別永住者証明書」「在留カード」「特別永住者証明書」のいずれかのみである場合: '02'
                    judgeResult = '02';
                } else {
                    // 上記以外の場合: '03'
                    judgeResult = '03';
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'judgeWhetherTakenDocumentIsInsuranceCardOrNot':
                if (hasldDocKey.some(isWelfareNotebook)
                    || hasldDocKey.some(isOtherOfficialDocumentWithPhoto)) {
                    // 撮影書類に「各種福祉手帳」「その他官公庁から発行された書類（写真付）」のいずれかが含まれる場合: '01'
                    judgeResult = '01';
                } else if (hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.length > 0
                    && hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.every(isHealthInsuranceCard)) {
                    // 撮影書類のうち顔写真付書類が「各種健康保険証」のみである場合: '02'
                    judgeResult = '02';
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'judgeWhetherTakenDocumentIsWelfareNotebookOrNot':
                // 撮影書類のうち顔写真付書類が「各種福祉手帳」のみである場合: '01'
                // 上記以外の場合: '02'
                judgeResult = (hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.length > 0
                    && hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.every(isWelfareNotebook)) ? '01' : '02';
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'isUnder16YearsOld':
                // 16歳未満であるかの判定 (16歳未満の場合: 'true');
                judgeResult = this.isUnder16YearsOld() ? 'true' : 'false';
                if (judgeResult === 'true') {
                    this.action.setMailDelivery();
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'isNameKanaChanged':
                // カナ氏名変更が行われているかの判定(変更前後を半角変換&拗音を大文字変換して比較)
                judgeResult = (this.state.holderNameFurigana &&
                    StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku(this.state.holderNameFurigana))
                    !== StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku(this.state.nameKana)))
                    ? '01' : '02';
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            default:
                break;
        }
    }

    @Renderer(AddCheckChangeChatFlowTypes.COMPLETE)
    private onComplete(entity: ChatFlowMessageInterface) {
        this.action.chatFlowCompelete(entity.name);
    }

    protected get userAnswers(): any {
        return null;
    }

    @Renderer(AddCheckChangeChatFlowTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfoscreenId,
                yamlId: this.state.currentFileInfo,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    private nextChatByJudge(entity: ChatFlowMessageInterface, pageIndex: number, result: string) {
        for (const choice of entity.choices) {
            if (choice.value === result) {
                // 次のチャットを開始させる
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
            }
        }
    }

    /**
     * 16歳未満であるか判定する
     */
    private isUnder16YearsOld(): boolean {
        const birthdayMo = moment(this.changeState.submitData.birthdate, COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
        const todayMo = moment(this.changeState.submitData.bankclerkAuthenticationStartDate);
        return todayMo.isSameOrBefore(birthdayMo.add(Age.Age_16, 'y'));
    }

}
