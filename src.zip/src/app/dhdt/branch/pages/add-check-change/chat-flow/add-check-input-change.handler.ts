import { Injectable } from '@angular/core';
import { AddCheckChangeAction } from 'dhdt/branch/pages/add-check-change/action/add-check-change.action';
import { AddCheckChangeChatFlowTypes } from 'dhdt/branch/pages/add-check-change/chat-flow/add.check.change.chat-flow-types';
import { ScreenTransition } from 'dhdt/branch/pages/change/change-consts';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';

@Injectable()
export class AddCheckInputChangeHandler extends DefaultChatFlowInputHandler {

    constructor(
        private action: AddCheckChangeAction
    ) {
        super(action);
    }

    @InputHandler(AddCheckChangeChatFlowTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name === ScreenTransition.NEXT_TO_COMPLETE) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
            return;
        }
        if (entity.name === ScreenTransition.BACK_TO_TOP) {
            this.action.chatFlowCompelete(entity.name);

        } else {
            if ((entity.name === 'canNotIssueCardImmediately' && answer.value === COMMON_CONSTANTS.YML_GENERAL_YES)
                || entity.name === 'haveFacePhoto' && answer.value === COMMON_CONSTANTS.YML_GENERAL_NO) {
                this.action.setMailDelivery();
            }
            this.action.setAnswer({
                text: answer.text,
                value: [
                    {key: entity.name, value: answer.value}
                ]
            });
        }
        this.emitMessageRetrivalEvent(answer.next, pageIndex);
    }

    @InputHandler(AddCheckChangeChatFlowTypes.PRINTNAME)
    private onPrintName(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer.text.indexOf(COMMON_CONSTANTS.HALF_POINT_NO_SPACE) !== -1) {
            answer.text = answer.text.replace(/\./g, COMMON_CONSTANTS.FULL_POINT);
        }
        // 最初の半角スペースによってローマ字氏名を分割する。
        // 前の部分をfirstNameRomaとして、後ろの部分はlastNameRomaとして
        const fullNameRoma = answer.value[0].value;
        const firstSpaceIndex = fullNameRoma.indexOf(COMMON_CONSTANTS.SPACE);
        const firstNameRoma = fullNameRoma.substring(0, firstSpaceIndex);
        const lastNameRoma = fullNameRoma.substring(firstSpaceIndex + 1);
        const answerValue = [
            {
                key: 'firstNameRoma',
                value: firstNameRoma
            },
            {
                key: 'lastNameRoma',
                value: lastNameRoma
            },
        ];
        this.setAnswer({ text: answer.text, value: answerValue});
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }
}
