/**
 * 生存状況ENUM
 */
export enum SurvivalStatusEnum {
    LIVE = 1,
    DEATH_BEFORE = 2,
    DEATH_AFTER = 3
}
