import { NgModule, Type } from '@angular/core';
import { HttpModule } from '@angular/http';
import { LoginModule } from 'dhdt/branch/pages/common/login/login.module';
import { TopModule } from 'dhdt/branch/pages/common/top/top.module';
import { InheritSimplifyGoldProtectionHandler } from 'dhdt/branch/pages/inherit//chat-flow/inherit-simplify-gold-protection.handler';
import { InheritSimplifyGoldProtectionRenderer } from 'dhdt/branch/pages/inherit//chat-flow/inherit-simplify-gold-protection.renderer';
import { ServerInfoService } from 'dhdt/branch/pages/inherit//services/server-info.service';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import {
    InheritAncestorModifyModifyHandler
} from 'dhdt/branch/pages/inherit/chat-flow/chat-flow-modify/inherit-ancestor-modify.input-handler';
import { InheritAncestorModifyRenderer } from 'dhdt/branch/pages/inherit/chat-flow/chat-flow-modify/inherit-ancestor-modify.renderer';
import {
    InheritApplicantModifyInputHandler
} from 'dhdt/branch/pages/inherit/chat-flow/chat-flow-modify/inherit-applicant-modify.input-handler';
import { InheritApplicantModifyRenderer } from 'dhdt/branch/pages/inherit/chat-flow/chat-flow-modify/inherit-applicant-modify.renderer';
import { InheritAncestorInputInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-ancestor-input.input-handler';
import { InheritAncestorInputRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-ancestor-input.renderer';
import { InheritApplicantInputInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-applicant-input.input-handler';
import { InheritApplicantInputRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-applicant-input.renderer';
import { InheritInactiveInputInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-inactive.input-handler';
import { InheritInheritanceMethodHandle } from 'dhdt/branch/pages/inherit/chat-flow/inherit-inheritance-method.handle';
import { InheritInheritanceMethodRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-inheritance-method.renderer';
import { InheritPasswordInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-password.input-handler';
import { InheritPasswordRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-password.renderer';

import {
    InheritExpertIntroductionVerifyInputHandler
} from 'dhdt/branch/pages/inherit/chat-flow/inherit-expert-introduction-verify.input-handler';
import {
    InheritExpertIntroductionVerifyRenderer
} from 'dhdt/branch/pages/inherit/chat-flow/inherit-expert-introduction-verify.renderer';
import {
    InheritPaymentInfoInputHandler
} from 'dhdt/branch/pages/inherit/chat-flow/inherit-payment-info.input-handler';
import {
    InheritPaymentInfoRenderer
} from 'dhdt/branch/pages/inherit/chat-flow/inherit-payment-info.renderer';
import {
    InheritRepresentativeHeirInputInputHandler
} from 'dhdt/branch/pages/inherit/chat-flow/inherit-representative-heir-input.input-handler';
import {
    InheritRepresentativeHeirInputRenderer
} from 'dhdt/branch/pages/inherit/chat-flow/inherit-representative-heir-input.renderer';

import {
    InheritRepresentativeHeirModifyInputHandler
} from 'dhdt/branch/pages/inherit/chat-flow/chat-flow-modify/inherit-representative-heir-modify.input-handler';
import {
    InheritRepresentativeHeirModifyRenderer
} from 'dhdt/branch/pages/inherit/chat-flow/chat-flow-modify/inherit-representative-heir-modify.renderer';
import { InheritAddressInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-address.input-handler';
import { InheritAddressRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-address.renderer';
import { InheritInactiveRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-inactive.renderer';
import { InheritReceptionShopEntryInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-reception-shop-entry.input-handler';
import { InheritReceptionShopEntryRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-reception-shop-entry.renderer';
import { InheritSimpleChangeInfoInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simple-change-info.input-handler';
import { InheritSimpleChangeInfoRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simple-change-info.renderer';
import { InheritSimplifyBankCardHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-bank-card.handler';
import { InheritSimplifyBankCardRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-bank-card.renderer';
import { InheritSimplifyBondHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-bond.handler';
import { InheritSimplifyBondRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-bond.renderer';
import { InheritSimplifyDomesticLoanHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-domestic-loan.handler';
import { InheritSimplifyDomesticLoanRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-domestic-loan.renderer';
import { InheritSimplifyForexHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-forex.handler';
import { InheritSimplifyForexRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-forex.renderer';
import { InheritSimplifyInvestmentTrustHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-investment-trust.handler';
import { InheritSimplifyInvestmentTrustRenderer } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-investment-trust.renderer';
import { InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InheritChatModifyComponent } from 'dhdt/branch/pages/inherit/view/inherit-chat-modify.component';
import { InheritChatComponent } from 'dhdt/branch/pages/inherit/view/inherit-chat.component';
import { InheritContentConfirmComponent } from 'dhdt/branch/pages/inherit/view/inherit-content-confirm.component';
import {
    InheritExpertIntroductionVerifyChatComponent
} from 'dhdt/branch/pages/inherit/view/inherit-expert-introduction-verify-chat.component';
import { InheritPaymentChatComponent } from 'dhdt/branch/pages/inherit/view/inherit-payment-chat.component';
import {
    InheritProcedureGuideComponent
} from 'dhdt/branch/pages/inherit/view/inherit-procedure.guide.component';
import { InheritRelationTreeComponent } from 'dhdt/branch/pages/inherit/view/inherit-relation-tree.component';
import { InheritRelationshipComponent } from 'dhdt/branch/pages/inherit/view/inherit-relationship.component';
import { SimplifyChatComponent } from 'dhdt/branch/pages/inherit/view/simplify-chat.component';
import { SimplyInfoChangeChatComponent } from 'dhdt/branch/pages/inherit/view/simply-info-change-chat.component';
import { StaffConfirmSimpleResultComponent } from 'dhdt/branch/pages/inherit/view/staff-confirm-simple-result.component';
import { StaffConfirmSimpleComponent } from 'dhdt/branch/pages/inherit/view/staff-confirm-simple.component';
import { StaffConfirmationComponent } from 'dhdt/branch/pages/inherit/view/staff-confirmation.component';
import { AddressModule } from 'dhdt/branch/shared/components/address/address.module';
import { BranchModule } from 'dhdt/branch/shared/components/branch/branch.module';
import { ConfirmPageCommonModule } from 'dhdt/branch/shared/components/confirmpage-common/confirmpage.common.module';
import { ModalPasswordModule } from 'dhdt/branch/shared/components/modal/modal-password/modal-password.module';
import { PickerModule } from 'dhdt/branch/shared/components/picker/picker.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { Config } from 'ionic-angular';
import { IonicModule } from 'ionic-angular/module';
import { InheritRceptionShopEntryComponent } from './view/inherit-reception-shop-entry.component';

export const SHARED_FORM_COMPONENT: Array<Type<any>> = [
    InheritChatComponent,
    InheritRelationshipComponent,
    InheritRelationTreeComponent,
    InheritProcedureGuideComponent,
    InheritPaymentChatComponent,
    InheritExpertIntroductionVerifyChatComponent,
    SimplifyChatComponent,
    InheritContentConfirmComponent,
    InheritChatModifyComponent,
    StaffConfirmationComponent,
    StaffConfirmSimpleComponent,
    StaffConfirmSimpleResultComponent,
    InheritRceptionShopEntryComponent,
    SimplyInfoChangeChatComponent
];

@NgModule({
    imports: [
        LoginModule,
        TopModule,
        IonicModule,
        SharedModule,
        AddressModule,
        BranchModule,
        HttpModule,
        PickerModule,
        ConfirmPageCommonModule,
        ModalPasswordModule
    ],
    declarations: [
        SHARED_FORM_COMPONENT,
    ],
    exports: [
        SHARED_FORM_COMPONENT,
        TopModule,
    ],
    entryComponents: [
        SHARED_FORM_COMPONENT,
    ],
    providers: [
        InheritAction,
        InheritStore,
        InheritPasswordInputHandler,
        InheritPasswordRenderer,
        InheritSimplifyDomesticLoanRenderer,
        InheritSimplifyDomesticLoanHandler,
        InheritSimplifyForexRenderer,
        InheritSimplifyForexHandler,
        InheritSimplifyBondRenderer,
        InheritSimplifyBondHandler,
        InheritSimplifyGoldProtectionRenderer,
        InheritSimplifyGoldProtectionHandler,
        InheritSimplifyInvestmentTrustRenderer,
        InheritSimplifyInvestmentTrustHandler,
        InheritSimplifyBankCardRenderer,
        InheritSimplifyBankCardHandler,
        InheritPaymentInfoInputHandler,
        InheritExpertIntroductionVerifyInputHandler,
        InheritPaymentInfoRenderer,
        InheritExpertIntroductionVerifyRenderer,
        InheritApplicantInputInputHandler,
        InheritApplicantInputRenderer,
        InheritAncestorInputInputHandler,
        InheritAncestorInputRenderer,
        InheritAncestorModifyModifyHandler,
        InheritAncestorModifyRenderer,
        InheritApplicantModifyInputHandler,
        InheritApplicantModifyRenderer,
        InheritRepresentativeHeirInputInputHandler,
        InheritRepresentativeHeirInputRenderer,
        InheritRepresentativeHeirModifyRenderer,
        InheritRepresentativeHeirModifyInputHandler,
        InheritSimpleChangeInfoInputHandler,
        InheritSimpleChangeInfoRenderer,
        InheritInheritanceMethodRenderer,
        InheritInheritanceMethodHandle,
        InheritInactiveRenderer,
        InheritInactiveInputInputHandler,
        InheritReceptionShopEntryRenderer,
        InheritReceptionShopEntryInputHandler,
        InheritAddressRenderer,
        InheritAddressInputHandler,
        ServerInfoService
    ]
})
export class InheritModule {
    constructor(private config: Config) {
        this.config.set('hideCaretOnScroll', false);
    }
}
