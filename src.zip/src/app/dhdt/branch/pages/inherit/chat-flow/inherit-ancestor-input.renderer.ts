import { Injectable } from '@angular/core';
import { COMMON_CONSTANTS, InheritName, JudgeResultStatus } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritAncestorInputInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-ancestor-input.input-handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputUtils } from 'dhdt/branch/pages/inherit/utils/input-utils';
import { DormantDepositInfoRequest } from 'dhdt/branch/pages/terminate/entity/dornant-deposit-info-request.entity';
import { InactiveAccountInfoInquiryRequest } from 'dhdt/branch/pages/terminate/entity/inactive-account-info-inquiry-request.entity';
import { InactiveAccountInfoCommon } from 'dhdt/branch/pages/terminate/entity/inactive-account-info-inquiry-response.entity';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { AccountInfoInputComponent } from 'dhdt/branch/shared/components/number-input/account-info-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import * as moment from 'moment';

export const INHERIT_ANCESTOR_INPUT_RENDERER_TYPE = 'InheritAncestorInputComponent';

/**
 * `DefaultChatFlowRenderer`において、死亡者情報入力画面Rendererを定義しているクラス。
 *
 * @export
 * @class InheritAncestorInputRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_ANCESTOR_INPUT_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-ancestor-input.yml'
})
export class InheritAncestorInputRenderer extends DefaultChatFlowRenderer {
    public margedInactiveAccountInfo: InactiveAccountInfoCommon[];
    public selectInactiveAccountInfo: InactiveAccountInfoCommon[];
    public processType = 0;
    private readonly INHERIT_BUSINESS_CODE = '15';
    private state: InheritState;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private loginStore: LoginStore,
        inputHandler: InheritAncestorInputInputHandler
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * ButtonタイプのデフォルトRenderer。
     *
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof DefaultChatFlowRenderer
     */
    @Renderer([
        InheritChatFlowQuestionTypes.BUTTON,
        InheritChatFlowQuestionTypes.BUTTON_THREE_COLS
    ])
    public onButtonDefaultRenderer(entity: ChatFlowMessageInterface, pageIndex: number): void {
        super.onButtonDefaultRenderer(entity, pageIndex);
    }

    /**
     * キーボードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(InheritChatFlowQuestionTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            // placeholderのデフォルト値を所得する
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * 分岐先を判定する
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @Renderer(InheritChatFlowQuestionTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        let judgeResult: any;

        switch (entity.name) {
            // 口座存在チェックで取得したCIF情報に生年月日が登録されているかどうか
            case 'isRegisteredBirthday':
                judgeResult = Boolean(this.state.ancestorCifInfoInquiry.birthdate);
                break;
            case 'isforeignCurrencySavingsFixedDeposit':
                judgeResult = Boolean(
                    this.state.submitData.ancestorAccountItem === InheritConsts.AvailableAccountType.foreignCurrencySavingsForSystem ||
                    this.state.submitData.ancestorAccountItem === InheritConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem);
                break;
            case 'judgeByInheritAccountStatus':
                judgeResult = this.judgeByInheritAccountStatus();
                break;
            case 'inactiveAccountSearchStatus':
                // CRM口座情報検索結果
                judgeResult = this.state.submitData.inactiveAccountSearchStatus === InheritConsts.Status.ON ? true : false;
                break;
            case 'inactiveAccountClosedStatus':
                // CRM口座情報検索結果から解約済み判定
                this.margedInactiveAccountInfo = this.state.submitData.inactiveAccountInfo
                    ? this.state.submitData.inactiveAccountInfo.accountInfo.concat(
                        this.state.submitData.inactiveAccountInfo.secondaryAccountInfo) : null;
                this.selectInactiveAccountInfo = this.getInputCrmAccount(this.margedInactiveAccountInfo);
                judgeResult = this.selectInactiveAccountInfo[0].closedStatus === InheritConsts.Status.ON ? true : false;
                break;
            case 'accountingCustomerInfo':
                // 勘定系CIF保有有無
                judgeResult = this.state.submitData.mejarCustomerStatus === InheritConsts.Status.OFF ||
                    (this.state.submitData.ancestorAccountItem === InheritConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem
                        || this.state.submitData.ancestorAccountItem === InheritConsts.AvailableAccountType.foreignCurrencySavingsForSystem)
                    ? true : false;
                break;
            case 'checkBranchType':
                // 入力した店番号から店舗種類を取得し分岐させる
                judgeResult = InputUtils.getBranchType(this.state.submitData.ancestorAccountBranchType);
                // 店舗種類がNULLだった場合、個別の廃止店一覧チェックを行う
                if (judgeResult === JudgeResultStatus.RESULT_2) {
                    let result: boolean = false;
                    if (InputUtils.isClosedBranch(this.state.submitData.ancestorAccountBranchNo)) {
                        result = true;
                    }
                    judgeResult = result ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                }
                break;
            case 'isCrmApiFlag':
                judgeResult = this.checkCrmApiFlag();
                break;
            case 'crmAccountFlag':
                judgeResult = this.state.submitData.inactiveAccountSearchStatus === InheritConsts.Status.ON
                    ? true : false;
                break;
            case 'inactiveAccountStatusCheck':
                judgeResult = this.checkDormantApiFlag();
                break;
        }
        for (const choice of entity.choices) {
            if (choice.value === judgeResult) {
                this.parentInputHandler.emitMessageRetrivalEvent(choice.next, pageIndex);
                return;
            }
        }
    }

    /**
     * Pickerのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer([
        InheritChatFlowQuestionTypes.DATE_PICKER,
        InheritChatFlowQuestionTypes.CURRENCY_CODE_PICKER])
    public onPicker(entity: ChatFlowMessageInterface, pageIndex: number): void {
        let validation: any;

        switch (entity.name) {
            case InheritName.INHERIT_ANCESTOR_DEATH_DATE:
                validation = {
                    ...entity.validationRules,
                    max: moment(this.state.submitData.customerApplyStartDate).add(1, COMMON_CONSTANTS.DATE_DAY)
                        .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                    min: moment(this.state.submitData.customerApplyStartDate).subtract(100, COMMON_CONSTANTS.DATE_YEAR)
                        .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                    default: moment(this.state.submitData.customerApplyStartDate).format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD)
                };
                break;
            case InheritName.INHERIT_ANCESTOR_DEATH_DATE_START:
                validation = {
                    ...entity.validationRules,
                    max: moment(this.state.submitData.customerApplyStartDate)
                        .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                    min: moment(this.state.submitData.customerApplyStartDate)
                        .subtract(100, COMMON_CONSTANTS.DATE_YEAR)
                        .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                    // 初期値: 先月初日
                    default: moment(this.state.submitData.customerApplyStartDate)
                        .subtract(1, COMMON_CONSTANTS.DATE_MONTH)
                        .startOf(COMMON_CONSTANTS.DATE_MONTH)
                        .format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD)
                };
                break;
            case InheritName.INHERIT_ANCESTOR_DEATH_DATE_END:
                const max =
                    moment(this.state.submitData.dateOfDeathStart)
                        .isBefore(moment(this.state.submitData.customerApplyStartDate), COMMON_CONSTANTS.DATE_MONTH)
                        ? moment(this.state.submitData.dateOfDeathStart).endOf(COMMON_CONSTANTS.DATE_MONTH)
                        : moment(this.state.submitData.customerApplyStartDate);
                const min =
                    moment(this.state.submitData.dateOfDeathStart).endOf(COMMON_CONSTANTS.DATE_MONTH)
                        .isAfter(moment(this.state.submitData.dateOfDeathStart), COMMON_CONSTANTS.DATE_DAY)
                        ? moment(this.state.submitData.dateOfDeathStart).add(1, COMMON_CONSTANTS.DATE_DAY)
                        : moment(this.state.submitData.dateOfDeathStart).endOf(COMMON_CONSTANTS.DATE_MONTH);
                const current =
                    moment(this.state.submitData.dateOfDeathStart).endOf(COMMON_CONSTANTS.DATE_MONTH)
                        .isAfter(moment(this.state.submitData.dateOfDeathStart), COMMON_CONSTANTS.DATE_DAY)
                        ? moment(this.state.submitData.dateOfDeathStart).add(1, COMMON_CONSTANTS.DATE_DAY)
                        : moment(this.state.submitData.dateOfDeathStart).endOf(COMMON_CONSTANTS.DATE_MONTH);
                validation = {
                    ...entity.validationRules,
                    max: max.add(1, COMMON_CONSTANTS.DATE_DAY).format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                    min: min.format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                    default: current.format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD)
                };
                break;
            case InheritName.INHERIT_SELECT_CURRENCY_CODE:
                validation = entity.validationRules;
                break;
            default:
                validation = {
                    ...entity.validationRules,
                    max: moment(this.state.submitData.customerApplyStartDate).add(1, COMMON_CONSTANTS.DATE_DAY)
                        .format(COMMON_CONSTANTS.DATE_FORMAT_YYYY_MM_DD),
                    default: entity.validationRules.default,
                };
        }

        const options = {
            validationRules: validation,
            type: entity.type,
            name: entity.name,
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: PickerCommonComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * 口座情報入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(InheritChatFlowQuestionTypes.ACCOUNT_INFO_INPUT)
    public onAccountInfoInput(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            help: entity.options.help,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: AccountInfoInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * キーボードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(InheritChatFlowQuestionTypes.PAYMENT_ACCOUNT)
    public onPaymentAccount(entity: ChatFlowMessageInterface, pageIndex: number): void {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    /**
     * リクエスト送信
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @Renderer(InheritChatFlowQuestionTypes.REQUEST)
    public onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        switch (entity.name) {
            // 内部API: 口座存在チェック
            case 'accountInfoCheck':
                this.checkAccountInfo(entity, pageIndex);
                break;
            // 入力した店科口の店番号より店名を取得する
            case 'existInputBranchNunmber':
                this.store.registerSignalHandler(InheritSignal.GET_BRANCH_NAME_BY_INPUT_BRANCHNO_COMPLETE, () => {
                    this.store.unregisterSignalHandler(InheritSignal.GET_BRANCH_NAME_BY_INPUT_BRANCHNO_COMPLETE);
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                });
                this.action.getBranchNameByInputBranchNo({
                    params: {
                        branchCode: this.state.submitData.ancestorAccountBranchNo,
                        inheritFlg: InheritConsts.InheritFlg.flagTrue
                    }
                });
                break;
            // 内部API：不活動口座照会
            case 'inactiveAccountInfo':
                this.getInactiveAccountInfo(entity, pageIndex);
                break;
            // 内部API: CIF情報照会
            case 'customerInfo':
                // 手入力口座が預金科目の場合
                if (this.state.submitData.ancestorAccountItem !== InheritConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem
                    && this.state.submitData.ancestorAccountItem !== InheritConsts.AvailableAccountType.foreignCurrencySavingsForSystem) {
                    // 不活動口座情報がある場合、CIF照会の呼出しをおこなう
                    if (this.state.submitData.inactiveAccountInfo.accountInfo
                        && this.state.submitData.inactiveAccountInfo.accountInfo.length > 0) {
                        this.getCustomerInfo(entity, pageIndex);
                    } else {
                        this.emitMessageRetrivalEvent(entity.next, pageIndex);
                    }
                } else {
                    // 手入力口座が外貨科目の場合
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                }
                break;
            // 内部API: 業務受付可否チェック
            case 'receptionInheritApplyCheck':
                this.receptionInheritApplyCheck(entity, pageIndex);
                break;
            // 内部API: 取引有無照会(本人死亡登録有無チェック)
            case 'isCrmDeathCheck':
                this.isCrmDeathCheck(entity, pageIndex);
                break;
            // 内部API: 休眠睡眠情報照会(索引情報有無をチェックする)
            case 'dormantDepositInfo':
                this.dormantDepositInfo(entity, pageIndex);
                break;
        }
    }

    /**
     * 内部API: 口座存在チェック
     * @param entity entity
     * @param pageIndex pageIndex
     */
    private checkAccountInfo(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // 口座存在チェックハンドルを追加
        this.store.unregisterSignalHandler(InheritSignal.GET_CHECK_ACCOUNT_EXISTING);
        this.store.registerSignalHandler(InheritSignal.GET_CHECK_ACCOUNT_EXISTING, (data) => {
            this.store.unregisterSignalHandler(InheritSignal.GET_CHECK_ACCOUNT_EXISTING);
            if (this.state.submitData.hasAncestorAccountExist) {
                if (this.state.accountSearchStatus === InheritConsts.Status.ON) {
                    // 口座元帳ありの場合
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                } else {
                    // 口座元帳なしの場合
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                }
            } else {
                // エラーの場合、口座再入力へ
                this.action.chatFlowReturn(InheritChatFlowQuestionTypes.ANCESTOR_ACCOUNT_INFO);
                this.action.clearAncestorAccountInfo();
            }
        });
        // 人格コードエラーの場合、エラーモーダルを表示する
        this.store.registerSignalHandler(InheritSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
            this.store.unregisterSignalHandler(InheritSignal.GET_CHECK_ACCOUNT_EXISTING);
            this.store.unregisterSignalHandler(InheritSignal.UNACCEPTABLES_NG);
            const errorInfo = InputUtils.checkErrorCode(response.errors.data);
            InputUtils.showErrorModalForInheritReceptionCheck(errorInfo);
            return;
        });
        // リクエストパラメータの設定
        const accountParam = {
            tabletApplyId: this.state.submitData.tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                tenban: this.state.submitData.ancestorAccountBranchNo,
                accountNo: this.state.submitData.ancestorAccountNo,
                accountType: this.setAccountType(this.state.submitData.ancestorAccountItem),
                businessCode: this.INHERIT_BUSINESS_CODE,
                currencyCode: this.state.submitData.selectCurrencyCode
                    ? this.state.submitData.selectCurrencyCode : null,
                inheritFlg: InheritConsts.InheritFlg.flagTrue
            }
        };
        this.action.checkAccountExisting(accountParam);
    }

    /**
     * 内部API: 口座存在チェック 科目コードパラメータ設定
     * @param entity entity
     * @param pageIndex pageIndex
     */
    private setAccountType(ancestorAccountItem: string) {
        switch (ancestorAccountItem) {
            // 入力された科目コードが「32:外貨普通」の場合、「71」に変換して口座存在チェックパラメータをセットする
            case InheritConsts.AvailableAccountType.foreignCurrencySavingsForSystem:
                return InheritConsts.AvailableAccountType.foreignCurrencySavings;
            // 入力された科目コードが「34:外貨定期」の場合、「73」に変換して口座存在チェックパラメータをセットする
            case InheritConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem:
                return InheritConsts.AvailableAccountType.foreignCurrencyFixedDeposit;
            default:
                return ancestorAccountItem;
        }
    }

    /**
     * 口座が存在する場合、口座の元帳状態を判定する
     * @param
     */
    private judgeByInheritAccountStatus() {
        let judgeResult: string;
        // 口座存在チェックで結果コードがZの場合
        if (this.state.submitData.hasAncestorAccountExist) {
            // 1:元帳内に口座ありの場合
            if (this.state.accountSearchStatus === InheritConsts.Status.ON) {
                switch (this.state.ancestorCifInfoInquiry.accountStatus) {
                    // 閉鎖済み・解約済み
                    case InheritConsts.InheritAccountStatus.Closed:
                        // 定期証書式（元帳状態：閉鎖済み）の場合は受付可とする
                        return judgeResult =
                            (this.state.ancestorCifInfoInquiry.subjectCode === InheritConsts.AvailableAccountType.fixedDeposit
                                && this.state.ancestorCifInfoInquiry.passbookCategory === InheritConsts.PassbookCategory.certificate)
                                ? '00' : '01';
                    // 新約取消済み
                    case InheritConsts.InheritAccountStatus.Canceled:
                        return judgeResult = '08';
                    // 口座移管済み
                    case InheritConsts.InheritAccountStatus.Transferd:
                        return judgeResult = '04';
                    // 活動中または雑益繰入/休眠移管済み
                    case InheritConsts.InheritAccountStatus.Active:
                    case InheritConsts.InheritAccountStatus.Dormant:
                    case InheritConsts.InheritAccountStatus.InactiveCancellation:
                    case InheritConsts.InheritAccountStatus.IncomeCancellation:
                        return judgeResult = '00';
                    default:
                        break;
                }
            } else {
                return judgeResult = '99';
            }
        }
    }

    /**
     * 内部API: 不活動口座照会
     */
    private getInactiveAccountInfo(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // SIGNAL HANDLER設置
        this.store.registerSignalHandler(InheritSignal.INACTIVE_ACCOUNT_INFO_INQUIRY, () => {
            this.store.unregisterSignalHandler(InheritSignal.INACTIVE_ACCOUNT_INFO_INQUIRY);
            if (this.state.submitData.hasAncestorAccountExist) {
                if (this.state.accountSearchStatus === InheritConsts.Status.ON) {
                    // 口座元帳ありの場合
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                } else {
                    // 口座元帳なしの場合
                    this.emitMessageRetrivalEvent(entity.skip, pageIndex);
                }
            }
        });
        // APIの入力パラメータ設置
        const param: InactiveAccountInfoInquiryRequest = {
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                // 入力した店番号
                tenban: this.state.submitData.ancestorAccountBranchNo,
                // 入力した科目コード
                accountType: this.state.submitData.ancestorAccountItem,
                // 入力した口座番号
                accountNo: this.state.submitData.ancestorAccountNo,
            }
        };
        this.action.inactiveAccountInfoInquiry(param);
    }

    /**
     * 内部API: CIF情報照会
     */
    private getCustomerInfo(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // APIの入力パラメータ設置
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                accounts: this.makeCifInfoParams(), // パラメータ編集
            }
        };

        this.store.registerSignalHandler(InheritSignal.GET_CUSTOMER_INFO_NG, (response: HttpStatusError) => {
            // CI照会エラーの場合、処理続行する
            this.store.unregisterSignalHandler(InheritSignal.GET_CUSTOMER_INFO);
            this.store.unregisterSignalHandler(InheritSignal.GET_CUSTOMER_INFO_NG);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });

        this.store.registerSignalHandler(InheritSignal.GET_CUSTOMER_INFO, () => {
            this.store.unregisterSignalHandler(InheritSignal.GET_CUSTOMER_INFO);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });

        // CIF情報照会
        this.action.getCustomerInfo(param);
    }

    /**
     * 業務受付可否チェック（勘定系口座元帳なし・MEJAR前口座手入力の場合）
     * @param entity
     * @param pageIndex
     */
    private receptionInheritApplyCheck(entity: ChatFlowMessageInterface, pageIndex: number) {
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                tenban: null,
                accountType: null,
                accountNo: null,
                businessCode: InheritConsts.ReceptionCheckBusinessCode.ANCESTOR_ACCOUNT, // 業務コード:15
                customerId: this.state.submitData.customerInfo.customerId // 顧客番号
            }
        };

        // 人格コードエラーの場合、エラーモーダルを表示する
        this.store.registerSignalHandler(InheritSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
            this.store.unregisterSignalHandler(InheritSignal.INHERIT_RECEPTION_CHECK);
            this.store.unregisterSignalHandler(InheritSignal.UNACCEPTABLES_NG);
            const errorInfo = InputUtils.checkErrorCode(response.errors.data);
            InputUtils.showErrorModalForInheritReceptionCheck(errorInfo);
            return;
        });

        // 業務受付可否チェック、結果コードZの場合
        this.store.registerSignalHandler(InheritSignal.INHERIT_RECEPTION_CHECK, () => {
            this.store.unregisterSignalHandler(InheritSignal.INHERIT_RECEPTION_CHECK);
            this.store.unregisterSignalHandler(InheritSignal.UNACCEPTABLES_NG);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });

        // 受付可否チェックAPIを呼び出す
        this.action.beforeMejarReceptionCheck(param);
    }

    /**
     * CIF照会APIのパラメータリスト作成
     */
    private makeCifInfoParams(): any {
        const accountsListArr = [];
        let account = {};
        // 不活動口座照会の顧客番号を設定
        account = {
            tenban: null,
            accountType: null,
            accountNo: null,
            customerId: this.state.submitData.inactiveCustomerInfo.customerId
        };
        accountsListArr.push(account);
        return accountsListArr;
    }

    /**
     * 不活動口座情報を呼出しするか判定
     * @param
     */
    private checkCrmApiFlag(): Boolean {
        // 預金科目の場合
        if (this.state.submitData.ancestorAccountItem !== InheritConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem
            && this.state.submitData.ancestorAccountItem !== InheritConsts.AvailableAccountType.foreignCurrencySavingsForSystem) {
            // 口座存在チェックで結果コードがZの場合
            if (this.state.submitData.hasAncestorAccountExist) {
                // 口座が存在する場合
                if (this.state.accountSearchStatus === InheritConsts.Status.ON) {
                    return this.state.ancestorCifInfoInquiry.accountStatus
                        === InheritConsts.InheritAccountStatus.Dormant ? true : false;
                } else {
                    // 口座が存在しない場合
                    return true;
                }
            }
        } else {
            // 外貨科目の場合
            return false;
        }
    }

    /**
     * 睡眠・休眠情報照会APIを呼出しするか判定
     * @param
     */
    private checkDormantApiFlag(): Boolean {
        let judgeResult: boolean = false;
        // 入力した店科口がある場合
        const ancestorAccountFlag =
            InputUtils.isAncestorAccountFlag(
                this.state.submitData.ancestorAccountBranchNo,
                this.state.submitData.ancestorAccountItem,
                this.state.submitData.ancestorAccountNo);
        // 手入力口座有り　かつ　口座存在チェックの結果がＺ
        if (ancestorAccountFlag && this.state.submitData.hasAncestorAccountExist) {
            // 口座状態照会ＡＰＩで口座が存在している　かつ　口座元帳状態が０５：雑繰/休眠
            if (this.state.accountSearchStatus === InheritConsts.Status.ON &&
                this.state.ancestorCifInfoInquiry.accountStatus === InheritConsts.InheritAccountStatus.Dormant &&
                this.state.submitData.inactiveAccountSearchStatus === InheritConsts.Status.OFF) {
                judgeResult = true;
            }
        }
        return judgeResult;
    }

    /**
     * 手入力したMEJAR前口座を不活動口座より抽出する
     */
    private getInputCrmAccount(margedInactiveAccountInfo: InactiveAccountInfoCommon[]): InactiveAccountInfoCommon[] {
        const selectAccount: InactiveAccountInfoCommon[] = [];
        margedInactiveAccountInfo.forEach((account) => {
            if (account.branchCode === this.state.submitData.ancestorAccountBranchNo
                && (account.subjectCode === this.state.submitData.ancestorAccountItem
                    || account.subjectCode === InheritConsts.AvailableAccountType.savingsAndDeposit)
                && account.bankAccountId === this.state.submitData.ancestorAccountNo) {
                selectAccount.push(account);
            }
        });
        return selectAccount;
    }

    /**
     * CIF情報照会で取得したCIFの本人死亡登録有無チェック
     * @param entity
     * @param pageIndex
     */
    private isCrmDeathCheck(entity: ChatFlowMessageInterface, pageIndex: number) {
        // シグナルを保存後、次のチャットに遷移する。
        this.store.registerSignalHandler(InheritSignal.GET_CRM_DEATH, () => {
            this.store.unregisterSignalHandler(InheritSignal.GET_CRM_DEATH);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
        // 取引有無照会API
        this.action.beforeMejarDeathCheck({
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                customerInfo: [
                    {
                        customerId: this.state.ancestorCifInfoInquiry.customerId,
                        nationalityCode: this.state.ancestorCifInfoInquiry.nationalityCode
                    }
                ]
            }
        });
    }

    /**
     * 休眠睡眠情報照会(索引情報有無をチェックする)
     * @param entity
     * @param pageIndex
     */
    private dormantDepositInfo(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // SIGNAL HANDLER設置
        this.store.registerSignalHandler(InheritSignal.GET_DORMANT_INDEX_INFO, () => {
            this.store.unregisterSignalHandler(InheritSignal.GET_DORMANT_INDEX_INFO);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
        // APIの入力パラメータ設置
        const param: DormantDepositInfoRequest = {
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                accountInfo: {
                    branchCode: this.state.submitData.ancestorAccountBranchNo,
                    branchName: this.state.submitData.ancestorAccountBranchName,
                    subjectCode: this.state.submitData.ancestorAccountItem,
                    bankAccountId: this.state.submitData.ancestorAccountNo,
                    accountStatus: this.state.ancestorCifInfoInquiry.accountStatus,
                    inactiveAccountStatus: null,
                    passbookCategory: null,
                    passbookTypeCode: null,
                    unacceptableInfo: null,
                    partnerAccountInfo: []
                }
            }
        };
        this.action.dormantIndexInfoCheck(param);
    }
}
