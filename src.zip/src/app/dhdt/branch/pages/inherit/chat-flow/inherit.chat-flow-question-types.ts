import { ChatFlowQuestionTypes } from 'dhdt/branch/shared/modules/chat-flow/chat-flow-question-types';

export class InheritChatFlowQuestionTypes extends ChatFlowQuestionTypes {
    public static readonly NEED_PASSWORD = 'needpassword';
    public static readonly PREFECTURE_PICKER = 'prefecturePicker';
    public static readonly COUNTRY_URBAN_VILLAGE_PICKER = 'countyUrbanVillagePicker';
    public static readonly SELECT_ADDRESS = 'selectAddress';
    public static readonly SELECT_STREET = 'selectStreet';
    public static readonly DATE_PICKER = 'datepicker';
    public static readonly ACCOUNT_INFO_INPUT = 'accountInfoInput';
    public static readonly BUTTON_TWO_COLS = 'buttonTwoCols';
    public static readonly BUTTON_THREE_COLS = 'buttonThreeCols';
    public static readonly PAYMENT_ACCOUNT = 'paymentAccount';
    public static readonly SELECT_BRANCH = 'selectbranch';
    public static readonly NUMBER_THOUSAND = 'numberThousand';
    public static readonly TRADE_LIST = 'tradeList';
    public static readonly BALANCE_ACCOUNT_LIST = 'balanceAccountList';
    public static readonly INACTIVE_ACCOUNT_LIST = 'inactiveAccountList';
    public static readonly SECURITY_ACCOUNT_LIST = 'securityAccountList';
    public static readonly INACTIVE_ACCOUNT = 'inactiveAccount';
    public static readonly SAVE_SUBMIT = 'saveSubmit';
    public static readonly COMPELETE = 'compelete';
    public static readonly SHOW_APPLICANT_ADDRESS = 'showApplicantAddress';
    // 相続人確認画面表示用
    public static readonly PRESENT_MODAL = 'presentModal';

    // 口座残高照会用
    public static readonly ACCOUNT_LIST = 'accountList';

    // バンクカード
    public static readonly BANK_CARD_LIST = 'bankCardList';

    // 金保護預かり残高一覧
    public static readonly GOLD_LIST = 'goldList';

    // 通貨コード(picker)
    public static readonly CURRENCY_CODE_PICKER = 'currencyCodePicker';

    // 被相続人口座入力
    public static readonly ANCESTOR_ACCOUNT_INFO= 'ancestorAccountInfo';

}
