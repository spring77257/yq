import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import {
    COMMON_CONSTANTS, Constants, CoreBankingConst, CssConsts, ImageInfoConsts, InheritModify,
    InheritName, InheritOption
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputUtils } from 'dhdt/branch/pages/inherit/utils/input-utils';
import { InheritContentConfirmComponent } from 'dhdt/branch/pages/inherit/view/inherit-content-confirm.component';
import { AccountExistCheckInterface } from 'dhdt/branch/shared/interface/account-exist-check.interface';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { App, NavController } from 'ionic-angular';
import * as moment from 'moment';

/**
 * `DefaultChatFlowInputHandler`において、死亡者情報入力画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class InheritAncestorModifyModifyHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritAncestorModifyModifyHandler extends DefaultChatFlowInputHandler {
    private readonly INHERIT_CONTENT_CONIRM_COMPONENT = 'InheritContentConfirmComponent';
    private readonly USE_DEFAULT_ACCOUNT_NAME = 'useDefaultAccountName';
    private readonly ANCESTOR_DEATH_DATE = 'ancestorDeathDate';

    private navCtrl: NavController;
    private state: InheritState;

    constructor(
        private action: InheritAction,
        app: App,
        private labelService: LabelService,
        private store: InheritStore,
        private modalService: ModalService,
        private loginStore: LoginStore
    ) {
        super(action);
        this.navCtrl = app.getActiveNavs()[0];
        this.state = this.store.getState();
    }

    /**
     * 回答の登録と次のメッセージの取得のみを行うハンドラ。
     *
     * @private
     * @param {*} entity
     * @param {number} pageIndex
     * @param {*} answer
     * @memberof CashCardConfirmPageRenderer
     */
    @InputHandler([
        InheritChatFlowQuestionTypes.PREFECTURE_PICKER,
        InheritChatFlowQuestionTypes.COUNTRY_URBAN_VILLAGE_PICKER,
        InheritChatFlowQuestionTypes.DATE_PICKER])
    protected simpleHandler(entity: any, pageIndex: number, answer: any) {
        if (entity.type !== InheritChatFlowQuestionTypes.DATE_PICKER) {
            const dict = [];
            const value = answer.value as Array<{ key: string, value: string }>;
            value.forEach((item) => {
                const basic = item.key.replace('holder', 'ancestor').replace('Furi', '');
                dict.push({ key: basic, value: item.value });
            });
            answer.value = dict;
        }

        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({
                text: COMMON_CONSTANTS.SKIP_TEXT,
                value: [{ key: entity.name, value: undefined }, { key: entity.name + 'Text', value: undefined }]
            });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        } else {
            if (entity.name === 'ancestorBirthdate') {
                answer.text = answer.text.replace(/\(満\d+歳\)/, '');
            }
            this.setAnswer({ ...answer, value: [...answer.value, { key: entity.name + 'Text', value: answer.text }] });

            if (entity.name === this.ANCESTOR_DEATH_DATE) {
                const todayDate = moment(this.state.submitData.customerApplyStartDate).format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDD);
                if (this.state.submitData.ancestorDeathDate > todayDate) {
                    this.showErrorModal(this.labelService.labels.inherit.ancestorDate.alertMsg, () => {
                        this.action.resetLastNode();
                    });
                    return;
                }

                // 被相続人の死亡日（開始日）をクリア
                this.action.setStateSubmitDataValue({
                    name: 'dateOfDeathStart', value: undefined
                });
                this.action.setStateSubmitDataValue({
                    name: 'dateOfDeathStartText', value: undefined
                });
            }

            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    @InputHandler([
        InheritChatFlowQuestionTypes.BUTTON,
        InheritChatFlowQuestionTypes.BUTTON_THREE_COLS
    ])
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            const answerValues = new Array();
            answerValues.push({ key: entity.name, value: answer.value });
            answerValues.push({ key: answer.name, value: answer.value });

            // コードに対して文字も保存する
            if (entity.type === InheritChatFlowQuestionTypes.BUTTON_THREE_COLS) {
                answerValues.push({ key: entity.name + COMMON_CONSTANTS.TEXT, value: answer.text });
            }

            this.setAnswer({
                text: answer.text,
                value: answerValues
            });
        }

        // 通帳または証書のご名義と[被相続者お名前(カナ)]」同じの場合
        if (entity.name === this.USE_DEFAULT_ACCOUNT_NAME && answer.value === '0') {
            this.action.setDefaultAncestorAccountName();
        }

        if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
            if (answer.action.value === this.INHERIT_CONTENT_CONIRM_COMPONENT) {
                this.navCtrl.setRoot(InheritContentConfirmComponent);
            } else if (answer.action.value === 'backToTop') {
                this.navCtrl.setRoot(TopComponent);
            } else {
                this.chatFlowCompelete(answer.action.value);
            }
        } else if (answer.action.type === COMMON_CONSTANTS.ACTION_TYPE_RETURN_TO_CHAT) {
            this.action.chatFlowReturn(answer.action.value);
            this.action.clearAncestorAccountInfo();
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(InheritChatFlowQuestionTypes.KEYBOARD)
    private onKeybordHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        let maxLenth;
        if (entity.choices && entity.choices.length > 0) {
            maxLenth = InputUtils.calculateMaxLength(entity.choices[0].name,
                this.state.submitData.ancestorAddressStreetNameKanaInput, this.state.submitData.ancestorAddressStreetNameKanaSelect);
        }

        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {// skipを選択の場合
            this.setAnswer({ text: this.labelService.labels.common.skipjp, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        } else {
            // 文字とフリガらによって、カタカナを転換する
            InputUtils.getKanjiToKana(answer.value, maxLenth).subscribe((results) => {
                const needSpace = InputUtils.needAddSpace(answer.value[0].key);
                if (needSpace) { // 全角スペース必要かを判断する
                    const text = answer.value[1].value.length > 0
                        ? answer.value[0].value + COMMON_CONSTANTS.FULL_SPACE + answer.value[1].value
                        : answer.value[0].value;
                    this.setAnswer({ text: text, value: [...results, { key: entity.name, value: text }] });
                } else {
                    this.setAnswer({ text: answer.text, value: [...results, { key: entity.name, value: answer.text }] });
                }
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            });
        }
    }

    @InputHandler(InheritChatFlowQuestionTypes.ACCOUNT_INFO_INPUT)
    private onAccountInfoInputHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        // 入力内容確認画面で口座番号欄の修正ボタンを押下時、submitDataの情報を初期化する
        this.action.clearAncestorAccountInfo();
        const branchNo = this.labelService.labels.account.branchNo + answer[0].value;
        const accountType = this.labelService.labels.account.type + answer[1].value;
        const accountNo = this.labelService.labels.account.no + answer[2].value;
        this.setAnswer({
            text: branchNo + COMMON_CONSTANTS.NEW_LINE + accountType + COMMON_CONSTANTS.NEW_LINE + accountNo,
            value: [
                { key: entity.choices[0].name, value: answer[0].value },
                { key: entity.choices[1].name, value: answer[1].value },
                { key: entity.choices[2].name, value: answer[2].value },
            ]
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(InheritChatFlowQuestionTypes.CURRENCY_CODE_PICKER)
    private onPickerHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(InheritChatFlowQuestionTypes.NUMBER_KEYBORD)
    private onNumberKeyboardHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name && entity.name === InheritModify.ANCESTOR_ADDRESS_INFO) {
            this.action.clearAncestorAddressInfo();
        }
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({ text: this.labelService.labels.common.skipjp, value: [] });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        } else {
            if (entity.option === InheritOption.ANCESTOR_ZIPCODE) {
                this.setAnswer({ text: this.labelService.labels.inherit.basic.zipCodeTag + answer.text, value: answer.value });
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            } else {
                this.setAnswer(answer);
            }
        }
    }

    @InputHandler(InheritChatFlowQuestionTypes.SELECT_ADDRESS)
    private onSelectAddressHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): void {
        const value = answer.value as Array<{ key: string, value: string }>;
        if (value && value.length > 0) {
            const dict = [];
            value.forEach((item) => {
                const basic = item.key.replace('holder', 'ancestor').replace('Furi', '');
                dict.push({ key: basic, value: item.value });
            });
            answer.value = dict;
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        } else {
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        }
    }

    @InputHandler(InheritChatFlowQuestionTypes.SELECT_STREET)
    private onSelectStreetHandler(entity: any, pageIndex: number, result: { isSkip: boolean, text: string, value: any }) {
        const answer = {
            text: result.text,
            value: [
                { key: 'ancestorAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                { key: 'ancestorAddressStreetNameKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) }
            ]
        };
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(result.isSkip ? entity.skip : entity.next, pageIndex);
    }

    private showErrorModal(errorMsg: string, callback?: any) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            errorMsg,
            null, ImageInfoConsts.ALERT_IMAGE_PNG, buttonList, CssConsts.CSS_CLASS_ALERT_MODAL,
            callback
        );
    }

}
