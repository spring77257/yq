import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { COMMON_CONSTANTS, HeirIsApplicantResult, ModifyRepresentHeirInfo } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputUtils } from 'dhdt/branch/pages/inherit/utils/input-utils';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

@Injectable()
export class InheritSimpleChangeInfoInputHandler extends DefaultChatFlowInputHandler {
    private readonly KEY_HOLDER = 'holder';
    private readonly KEY_REPRESENTATIVE_HEIR = 'representativeHeir';
    private readonly KEY_FURI = 'Furi';
    private readonly KEY_REPRESENTATIVE_HEIR_IS_APPLICANT = 'representativeHeirFlg';
    private readonly KEY_REPRESENTATIVE_HEIR_IS_ADDR_KNOWN = 'isKnowAddress';
    private phoneIsSkiped: boolean = false;
    private telIsSkiped: boolean = false;
    private state: InheritState;

    constructor(
                private action: InheritAction,
                private store: InheritStore,
                private labelService: LabelService,
                private modalService: ModalService,
            ) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler([
        InheritChatFlowQuestionTypes.BUTTON,
        InheritChatFlowQuestionTypes.BUTTON_THREE_COLS
    ])
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            const answerValues = new Array();
            answerValues.push({ key: entity.name, value: answer.value });
            answerValues.push({ key: answer.name, value: answer.value });

            // コードに対して文字も保存する
            if (entity.type === InheritChatFlowQuestionTypes.BUTTON_THREE_COLS) {
                answerValues.push({ key: entity.name + COMMON_CONSTANTS.TEXT, value: answer.text });
            }

            this.setAnswer({
                text: answer.text,
                value: answerValues
            });
        }

        // 相続体表と来店者と同じの場合、相続人代表に来店者の情報をコピーする
        if (entity.name === this.KEY_REPRESENTATIVE_HEIR_IS_APPLICANT &&
            answer.value[0] === HeirIsApplicantResult.SAME) {
            this.action.saveHeirInfo();
        }

        if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }

        // 相続人代表の住所は知らない場合、住所情報をクリア
        if (entity.name === this.KEY_REPRESENTATIVE_HEIR_IS_ADDR_KNOWN &&
            answer.value === COMMON_CONSTANTS.YML_GENERAL_NO) {
            this.action.clearRepresentHeirAddress();
        }
    }

    /**
     * keyboard typeのデフォルトハンドラ。
     *
     * @protected
     * @param {*} entity
     * @param {number} pageIndex
     * @param {*} answer
     * @memberof InheritRepresentativeHeirInputInputHandler
     */
    @InputHandler(InheritChatFlowQuestionTypes.KEYBOARD)
    private onKeybordHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        if (entity.name === ModifyRepresentHeirInfo.REPRESENT_NAME) {
            this.action.clearRepresentativeHeirName();
        }
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({ text: this.labelService.labels.common.skipjp, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
            return;
        }

        let maxLenth;
        if (entity.choices && entity.choices.length > 0) {
            maxLenth = InputUtils.calculateMaxLength(
                entity.choices[0].name, this.state.submitData.representativeHeirAddressStreetNameKanaInput,
                this.state.submitData.representativeHeirAddressStreetNameKanaSelect);
        }

        InputUtils.getKanjiToKana(answer.value, maxLenth).subscribe((results) => {
            const needSpace = InputUtils.needAddSpace(answer.value[0].key);
            if (needSpace) {
                const text = answer.value[1].value.length > 0 ? answer.value[0].value + COMMON_CONSTANTS.FULL_SPACE + answer.value[1].value
                    : answer.value[0].value;
                this.setAnswer({ text: text, value: [...results, { key: entity.name, value: text }] });
            } else {
                this.setAnswer({ text: answer.text, value: [...results, { key: entity.name, value: answer.text }] });
            }
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
    }

    @InputHandler(InheritChatFlowQuestionTypes.NUMBER_KEYBORD)
    private onNumberKeyboardHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name === ModifyRepresentHeirInfo.REPRESENT_ADDRESS_INFO) {
            this.action.clearRepresentHeirAddress();
        }
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            if (entity.choices && entity.choices[0].name === ModifyRepresentHeirInfo.REPRESENT_MOBILENO_FIRST) {
                this.action.clearRepresentativeHeirMobilePhoneInfo();
            }
            if (entity.choices && entity.choices[0].name === ModifyRepresentHeirInfo.REPRESENT_TELFIRST_NO) {
                this.action.clearRepresentativeHeirTelephoneInfo();
            }
            this.setAnswer({ text: this.labelService.labels.common.skipjp, value: [] });
        } else {
            if (entity.option === ModifyRepresentHeirInfo.REPRESENT_ZIPCODE) {
                this.setAnswer({ text: this.labelService.labels.inherit.basic.zipCodeTag + answer.text, value: answer.value });
            } else {
                this.setAnswer(answer);
            }
        }
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler([
        InheritChatFlowQuestionTypes.PREFECTURE_PICKER,
        InheritChatFlowQuestionTypes.COUNTRY_URBAN_VILLAGE_PICKER
    ])
    private onPickerHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.action.clearRepresentHeirAddress();
            this.setAnswer({ text: this.labelService.labels.common.skipjp, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        } else {
            const dict = [];
            const value = answer.value as Array<{ key: string, value: string }>;
            value.forEach((item) => {
                const basic = item.key.replace(this.KEY_HOLDER, this.KEY_REPRESENTATIVE_HEIR).replace(this.KEY_FURI, '');
                dict.push({ key: basic, value: item.value });
            });
            answer.value = dict;
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    @InputHandler(InheritChatFlowQuestionTypes.SELECT_ADDRESS)
    private onSelectAddressHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): void {
        const dict = [];
        const value = answer.value as Array<{ key: string, value: string }>;
        if (value && value.length > 0) {
            value.forEach((item) => {
                const basic = item.key.replace(this.KEY_HOLDER, this.KEY_REPRESENTATIVE_HEIR).replace(this.KEY_FURI, '');
                dict.push({ key: basic, value: item.value });
            });
            answer.value = dict;
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        } else {
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        }
    }

    @InputHandler(InheritChatFlowQuestionTypes.SELECT_STREET)
    private onSelectStreetHandler(entity: any, pageIndex: number, result: { isSkip: boolean, text: string, value: any }) {
        const answer = {
            text: result.text,
            value: [
                {
                    key: this.KEY_REPRESENTATIVE_HEIR + 'AddressStreetNameSelect',
                    value: (result.isSkip ? undefined : result.value.streetKanji)
                },
                {
                    key: this.KEY_REPRESENTATIVE_HEIR + 'AddressStreetNameKanaSelect',
                    value: (result.isSkip ? undefined : result.value.streetKana)
                }
            ]
        };
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(result.isSkip ? entity.skip : entity.next, pageIndex);
    }

    // if phone and tel are skiped , modal show
    private telSkip(name: string, isSkip: boolean): boolean {
        if (name === 'representativeHeirMobileNo') {
            this.phoneIsSkiped = isSkip;
        }
        if (name === 'representativeHeirTelephoneNo') {
            this.telIsSkiped = isSkip;
        }
        if (name === 'representativeHeirTelephoneNo' && this.phoneIsSkiped === true && this.telIsSkiped === true) {
            const buttonList = [
                { text: 'OK', buttonValue: 'ok' },
            ];
            this.modalService.showWarnAlert(
                this.labelService.labels.alert.warnTelTitle,
                buttonList,
                () => {
                    this.action.needInputPhoenNo();
                }
            );
            return true;
        }
        return false;
    }
}
