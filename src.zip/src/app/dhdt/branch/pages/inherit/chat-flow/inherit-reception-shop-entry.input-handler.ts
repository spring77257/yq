import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { COMMON_CONSTANTS, InheritName } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * `受付票起票店の店番入力画面インプットハンドラーを定義しているクラス。
 *
 * @export
 * @class InheritReceptionShopEntryInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritReceptionShopEntryInputHandler extends DefaultChatFlowInputHandler {
    private readonly KEY_PAGER_ENTRY = 'pagerEntry';
    private state: InheritState;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private loginStore: LoginStore,
        private modalService: ModalService,
        private labelService: LabelService,
        private errorMessageService: ErrorMessageService,
        private deviceService: DeviceService) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(InheritChatFlowQuestionTypes.NUMBER_KEYBORD)
    private onNumberKeyboardHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(InheritChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0
            && answer.name !== InheritName.INHERIT_INPUT_RECEPTION_BRANCH_REENTER) {
            const answerValues = new Array();
            answerValues.push({ key: entity.name, value: answer.value });
            answerValues.push({ key: answer.name, value: answer.value });

            this.setAnswer({
                text: answer.text,
                value: answerValues
            });
        } else if (answer.name === InheritName.INHERIT_FIX
                   || answer.name === InheritName.INHERIT_INPUT_RECEPTION_BRANCH_REENTER) {
            this.action.gobackReceptionShopEntryChat();
            this.action.clearReceptionBranchInfo();
        }
        if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }
}
