import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { COMMON_CONSTANTS, InheritModify, InheritOption } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputUtils } from 'dhdt/branch/pages/inherit/utils/input-utils';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * `DefaultChatFlowInputHandler`において、来店者さま情報入力画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class InheritApplicantModifyInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritApplicantModifyInputHandler extends DefaultChatFlowInputHandler {
    private phoneIsSkiped: boolean = false;
    private telIsSkiped: boolean = false;
    private state: InheritState;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private labelService: LabelService,
        private modalService: ModalService,
    ) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(InheritChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.value }
                ]
            });
        }

        if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    /**
     * keyboard typeのデフォルトハンドラ。
     *
     * @protected
     * @param {*} entity
     * @param {number} pageIndex
     * @param {*} answer
     * @memberof InheritApplicantInputInputHandler
     */
    @InputHandler(InheritChatFlowQuestionTypes.KEYBOARD)
    private onKeybordHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        let maxLenth;
        if (entity.choices && entity.choices.length > 0) {
            maxLenth = InputUtils.calculateMaxLength(entity.choices[0].name,
                this.state.submitData.applicantAddressStreetNameKanaInput, this.state.submitData.applicantAddressStreetNameKanaSelect);
        }

        InputUtils.getKanjiToKana(answer.value, maxLenth).subscribe((results) => {
            const needSpace = InputUtils.needAddSpace(answer.value[0].key);
            if (needSpace) {
                const text = answer.value[1].value.length > 0 ? answer.value[0].value + COMMON_CONSTANTS.FULL_SPACE + answer.value[1].value
                    : answer.value[0].value;
                this.setAnswer({ text: text, value: [...results, { key: entity.name, value: text }] });
            } else {
                this.setAnswer({ text: answer.text, value: [...results, { key: entity.name, value: answer.text }] });
            }
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
    }

    @InputHandler(InheritChatFlowQuestionTypes.NUMBER_KEYBORD)
    private onNumberKeyboardHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name && entity.name === InheritModify.APPLICANT_ADDRESS_INFO) {
            this.action.clearAddressInfo();
        }
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            if (entity.choices && entity.choices[0].name === InheritModify.APPLICANT_MOBILENO_FIRST) {
                this.action.clearMobilePhoneInfo();
            }
            if (entity.choices && entity.choices[0].name === InheritModify.APPLICANT_TELFIRST) {
                this.action.clearTelephoneInfo();
            }
            this.setAnswer({ text: this.labelService.labels.common.skipjp, value: [] });
        } else {
            if (entity.option === InheritOption.APPLICATION_ZIPCODE) {
                this.setAnswer({ text: this.labelService.labels.inherit.basic.zipCodeTag + answer.text, value: answer.value });
            } else {
                this.setAnswer(answer);
            }
        }
        const isShowModal = this.telSkip(entity.name, answer === COMMON_CONSTANTS.SIGN_SKIP);
        if (!isShowModal) {
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    @InputHandler([
        InheritChatFlowQuestionTypes.PREFECTURE_PICKER,
        InheritChatFlowQuestionTypes.COUNTRY_URBAN_VILLAGE_PICKER,
        InheritChatFlowQuestionTypes.DATE_PICKER
    ])
    private onPickerHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.type !== InheritChatFlowQuestionTypes.DATE_PICKER) {
            const dict = [];
            const value = answer.value as Array<{ key: string, value: string }>;
            value.forEach((item) => {
                const basic = item.key.replace('holder', 'applicant').replace('Furi', '');
                dict.push({ key: basic, value: item.value });
            });
            answer.value = dict;
        }

        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        }  else {
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    @InputHandler(InheritChatFlowQuestionTypes.SELECT_ADDRESS)
    private onSelectAddressHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): void {
        const value = answer.value as Array<{ key: string, value: string }>;
        if (value && value.length > 0) {
            const dict = [];
            value.forEach((item) => {
                const basic = item.key.replace('holder', 'applicant').replace('Furi', '');
                dict.push({ key: basic, value: item.value });
            });
            answer.value = dict;
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        } else {
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        }
    }

    @InputHandler(InheritChatFlowQuestionTypes.SELECT_STREET)
    private onSelectStreetHandler(entity: any, pageIndex: number, result: { isSkip: boolean, text: string, value: any }) {
        const answer = {
            text: result.text,
            value: [
                { key: 'applicantAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                { key: 'applicantAddressStreetNameKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) }
            ]
        };
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(result.isSkip ? entity.skip : entity.next, pageIndex);
    }

    // if phone and tel are skiped , modal show
    private telSkip(name: string, isSkip: boolean): boolean {
        if (name === 'applicantMobileNo') {
            this.phoneIsSkiped = isSkip;
        }
        if (name === 'applicantTelephoneNo') {
            this.telIsSkiped = isSkip;
        }
        if (name === 'applicantTelephoneNo' && this.phoneIsSkiped === true && this.telIsSkiped === true) {
            const buttonList = [
                { text: 'OK', buttonValue: 'ok' },
            ];
            this.modalService.showWarnAlert(
                this.labelService.labels.alert.warnTelTitle,
                buttonList,
                () => {
                    this.action.needInputPhoenNo();
                }
            );
            return true;
        }
        return false;
    }
}
