import { Injectable } from '@angular/core';
import { AddressMaxLength, COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import {
    InheritRepresentativeHeirInputInputHandler
} from 'dhdt/branch/pages/inherit/chat-flow/inherit-representative-heir-input.input-handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { ServerInfoService } from 'dhdt/branch/pages/inherit/services/server-info.service';
import { InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputUtils } from 'dhdt/branch/pages/inherit/utils/input-utils';
import { SelectAddressComponent } from 'dhdt/branch/shared/components/address/view/select-address.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

export const INHERIT_REPRESENTATIVE_HEIR_INPUT_RENDERER_TYPE = 'InheritRepresentativeHeirInputRenderer';

/**
 * `DefaultChatFlowRenderer`において、相続代表者情報入力画面Rendererを定義しているクラス。
 *
 * @export
 * @class InheritRepresentativeHeirInputRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_REPRESENTATIVE_HEIR_INPUT_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-representative-heir-input.yml'
})
export class InheritRepresentativeHeirInputRenderer extends DefaultChatFlowRenderer {
    public processType = -1;
    private readonly REPRESENTATIVE_HEIR_ADDRESS_HOUSE_NUMBER: string = 'representativeHeirAddressHouseNumber';
    private readonly REPRESENTATIVE_HEIR_ADDRESS_HOUSE_NUMBER_KANA: string = 'representativeHeirAddressHouseNumberKana';
    private state: InheritState;

    constructor(
        action: InheritAction, private store: InheritStore,
        private serverInfoService: ServerInfoService,
        inputHandler: InheritRepresentativeHeirInputInputHandler
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    protected validateKanaText = (key: string) => {
        if (key === 'useDefaultAddressKana') {
            if (this.state.submitData.representativeHeirAddressStreetNameInput) {
                return this.state.submitData.getRepresentativeHeirAddressStreetHouseKana();
            } else {
                return this.state.submitData.representativeHeirAddressHouseNumberKana;
            }
        }
        return undefined;
    }

    /**
     * ButtonタイプのデフォルトRenderer。
     *
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof DefaultChatFlowRenderer
     */
    @Renderer([
        InheritChatFlowQuestionTypes.BUTTON,
        InheritChatFlowQuestionTypes.BUTTON_THREE_COLS
    ])
    public onButtonDefaultRenderer(entity: ChatFlowMessageInterface, pageIndex: number): void {
        super.onButtonDefaultRenderer(entity, pageIndex);
    }

    /**
     * Judgeタイプの自定義。
     *
     * @protected
     * @param {(ChatFlowMessageInterface | number)} next
     * @param {number} pageIndex
     * @memberof ChatFlowRenderer
     */
    @Renderer(InheritChatFlowQuestionTypes.JUDGE, false)
    protected onJudgeDefaultRenderer(entity: ChatFlowMessageInterface, pageIndex: number): void {
        if (entity.options.type === COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE_URL) { // URLの場合
            // 返る値によって、次のノードを判断する
            this.serverInfoService.getInfoFormServe(entity.name).subscribe((result) => {
                for (const choice of entity.choices) {
                    if (result === choice.value) {
                        this.emitMessageRetrivalEvent(choice.next, pageIndex, 0);
                        return;
                    }
                }
            });
        } else if (entity.choices) { // 固定値の場合
            for (const choice of entity.choices) {
                if ((choice.value === COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE_UNDEFINE && this.userAnswers[entity.name] === undefined)
                    || choice.value === COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE_OTHER
                    || choice.value === this.userAnswers[entity.name]) {
                    this.emitMessageRetrivalEvent(choice.next, pageIndex, 0);
                    return;
                }
            }
        }
    }

    /**
     * キーボードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(InheritChatFlowQuestionTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        if (entity.choices[0].name === this.REPRESENTATIVE_HEIR_ADDRESS_HOUSE_NUMBER) {
            let addressStreetNameLength = null;
            if (this.state.submitData.representativeHeirAddressStreetNameInput) {
                addressStreetNameLength = this.state.submitData.representativeHeirAddressStreetNameInput.length;
            } else if (this.state.submitData.representativeHeirAddressStreetNameSelect) {
                addressStreetNameLength = 0;
            }
            entity.choices[0].validationRules.max = AddressMaxLength.ADDRESS_MAX_LENGTH - addressStreetNameLength;
        }
        if (entity.choices[0].name === this.REPRESENTATIVE_HEIR_ADDRESS_HOUSE_NUMBER_KANA) {
            let addressStreetNameKanaLength = null;
            if (this.state.submitData.representativeHeirAddressStreetNameKanaInput) {
                addressStreetNameKanaLength = this.state.submitData.representativeHeirAddressStreetNameKanaInput.length;
            }
            entity.choices[0].validationRules.max = AddressMaxLength.ADDRESSKANA_MAX_LENGTH - addressStreetNameKanaLength;
        }
        const options = {
            validationRules: entity.validationRules,
            // placeholderのデフォルト値を所得する
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * 数字キーボードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(InheritChatFlowQuestionTypes.NUMBER_KEYBORD)
    public onNumberKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: NumberInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * Pickerのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer([
        InheritChatFlowQuestionTypes.PREFECTURE_PICKER,
        InheritChatFlowQuestionTypes.COUNTRY_URBAN_VILLAGE_PICKER])
    public onPicker(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // 市区町村の場合、パラメタを設定する
        const params = (entity.type === InheritChatFlowQuestionTypes.COUNTRY_URBAN_VILLAGE_PICKER) ?
            { prefectureKanji: this.state.submitData.representativeHeirAddressPrefecture } : undefined;

        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            name: entity.name,
            params: params,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            skip: entity.skip
        };

        this.emitRenderEvent({
            class: PickerCommonComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * 住所選択のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(InheritChatFlowQuestionTypes.SELECT_ADDRESS)
    public onSelectAddress(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            params: {
                zipCode:
                    this.state.submitData.representativeHeirFirstZipCode + this.state.submitData.representativeHeirLastZipCode
            },
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: SelectAddressComponent,
            data: entity.type,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * 住所選択のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(InheritChatFlowQuestionTypes.SELECT_STREET)
    public onSelectStreet(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const params = {
            // 都道府県
            prefectureKanji: this.state.submitData.representativeHeirAddressPrefecture,
            // 市区町村
            countyUrbanVillageKanji: this.state.submitData.representativeHeirAddressCountyUrbanVillage
        };
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: SelectStreetComponent,
            data: params,
            options: options,
        }, entity, pageIndex);
    }
}
