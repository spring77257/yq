import { Injectable } from '@angular/core';
import { InputReceptionBranchNumber, JudgeResultStatus } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritReceptionShopEntryInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-reception-shop-entry.input-handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputUtils } from 'dhdt/branch/pages/inherit/utils/input-utils';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

export const INHERIT_RECEPTION_SHOP_ENTRY_RENDERER_TYPE = 'InheritReceptionShopEntryRenderer';

/**
 * `受付票起票店の店番入力画面レンダラーを定義しているクラス。
 *
 * @export
 * @class InheritDeadInputRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_RECEPTION_SHOP_ENTRY_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-reception-shop-entry.yml'
})
export class InheritReceptionShopEntryRenderer extends DefaultChatFlowRenderer {
    public processType = -1;
    private state: InheritState;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        inputHandler: InheritReceptionShopEntryInputHandler
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * 店番入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(InheritChatFlowQuestionTypes.NUMBER_KEYBORD)
    public onNumberKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: NumberInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * 分岐先を判定する
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @Renderer(InheritChatFlowQuestionTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        let judgeResult: boolean | string;
        switch (entity.name) {
            // 入力した店番号から店舗種類を取得し分岐させる
            case 'checkReceptionBranchType':
                const branchNo = this.state.submitData.inputReceptionBranchNunmber;
                judgeResult = InputUtils.getBranchType(this.state.submitData.inputReceptionBranchType);
                // 店舗種類がNULLだった場合
                if (judgeResult === JudgeResultStatus.RESULT_2) {
                    judgeResult = JudgeResultStatus.RESULT_0;
                } else {
                    // 店舗種類が0（通常店）・3（喪失店）・9（廃止店）のとき・店番100・162は入力可とする
                    if (judgeResult === JudgeResultStatus.RESULT_1 ||
                        branchNo === InputReceptionBranchNumber.HeadquartersNumber ||
                        branchNo === InputReceptionBranchNumber.InheritSupportCenterNumber) {
                        judgeResult = JudgeResultStatus.RESULT_1;
                    }
                    // 店番162は、固定値を設定する（店番号:162、店名:相続サポートセンター）
                    if (branchNo === InputReceptionBranchNumber.InheritSupportCenterNumber) {
                        this.action.setStateSubmitDataValue({
                            name: 'inputReceptionBranchName',
                            value: InputReceptionBranchNumber.InheritSupportCenterName
                        });
                    }
                }
                break;
        }
        for (const choice of entity.choices) {
            if (choice.value === judgeResult) {
                this.emitMessageRetrivalEvent(choice.next, pageIndex, 0);
                return;
            }
        }
    }

    /**
     * 入力された店番が存在するかを判定
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @Renderer(InheritChatFlowQuestionTypes.REQUEST)
    public onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        if (entity.name === 'existReceptionBranchNunmber') {
            this.store.registerSignalHandler(InheritSignal.GET_BRANCH_NAME_BY_BRANCHNO_COMPLETE, () => {
                this.store.unregisterSignalHandler(InheritSignal.GET_BRANCH_NAME_BY_BRANCHNO_COMPLETE);
                this.emitMessageRetrivalEvent(entity.next, pageIndex, 0);
            });
            this.action.getBranchNameByBranchNo({
                params: {
                    branchCode: this.state.submitData.inputReceptionBranchNunmber,
                    inheritFlg: InheritConsts.InheritFlg.flagTrue
                }
            });
        }
    }
}
