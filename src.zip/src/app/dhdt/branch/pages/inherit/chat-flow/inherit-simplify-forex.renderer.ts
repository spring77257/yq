import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { ObjectUtils } from 'adep/utils';
import { COMMON_CONSTANTS, Constants, YesNoAnswer } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritSimplifyForexHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-forex.handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { TransPresenceEntity } from 'dhdt/branch/pages/inherit/entity/trans-presence.entity';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputUtils } from 'dhdt/branch/pages/inherit/utils/input-utils';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

export const INHERIT_SIMPLIFY_FOREX_RENDERER_TYPE = 'InheritSimplifyForexRenderer';

/**
 * `DefaultChatFlowRenderer`において、死亡者情報入力画面Rendererを定義しているクラス。
 *
 * @export
 * @class InheritSimplifyForexRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_SIMPLIFY_FOREX_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-simplify-forex.yml'
})
export class InheritSimplifyForexRenderer extends DefaultChatFlowRenderer {
    public processType = -1;

    private state: InheritState;
    private labels: any;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private loginStore: LoginStore,
        labelService: LabelService,
        inputHandler: InheritSimplifyForexHandler,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.labels = labelService.labels;
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    @Renderer(InheritChatFlowQuestionTypes.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.store.unregisterSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY);
        this.store.registerSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY, (result) => {
            this.store.unregisterSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY);

            const choice = entity.choices.find((item) => item.value === result);
            this.emitMessageRetrivalEvent(choice.next, pageIndex);
        });
        this.action.forexAccountsBalanceInquiry(entity, {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                customerId: this.state.submitData.allCustomerId,
                inheritFlg: InheritConsts.InheritFlg.flagTrue
            }
        });
    }

    @Renderer(InheritChatFlowQuestionTypes.ACCOUNT_LIST)
    private onAccountList(entity: ChatFlowMessageInterface, pageIndex: number) {
        let exsistsInputAccount: boolean = false;
        const inputAccountBranchCode = this.state.submitData.ancestorAccountBranchNo;
        const inputAccountsubjectCode = this.state.submitData.ancestorAccountItem;
        const inputAccountNo = this.state.submitData.ancestorAccountNo;
        const inputAccountCurrencyCode = this.state.submitData.selectCurrencyCode;
        const inputAccountBranchName = this.state.submitData.ancestorAccountBranchName;
        const inputAccountsubjectName = InputUtils.convertSubjectName(this.state.submitData.ancestorAccountItem);
        const inputAncestorNameKana = this.state.submitData.ancestorNameKana;
        const inputAncestorName = this.state.submitData.ancestorName;
        const inputAncestorBirthDate = this.state.submitData.ancestorBirthdate;
        const inputAncestorFirstZipCode = this.state.submitData.ancestorFirstZipCode;
        const inputAncestorLastZipCode = this.state.submitData.ancestorLastZipCode;
        const inputAncestorPrefecture = this.state.submitData.ancestorAddressPrefecture;
        const inputAncestorCountyUrbanVillage = this.state.submitData.ancestorAddressCountyUrbanVillage;
        const inputAncestorStreet = this.state.submitData.ancestorAddressStreetNameSelect ||
            this.state.submitData.ancestorAddressStreetNameInput;
        const inputAncestorSubAddress = this.state.submitData.ancestorAddressHouseNumber;
        const inputAncestorPrefectureKana = this.state.submitData.ancestorAddressPrefectureKana;
        const inputAncestorCountyUrbanVillageKana = this.state.submitData.ancestorAddressCountyUrbanVillageKana;
        const inputAncestorStreetKana = this.state.submitData.ancestorAddressStreetNameKanaSelect ||
            this.state.submitData.ancestorAddressStreetNameKanaInput;
        const inputAncestorSubAddressKana = this.state.submitData.ancestorAddressHouseNumberKana;
        const mejarCustomerStatus = this.state.submitData.mejarCustomerStatus;
        const matchesApplicantAddress = this.state.submitData.matchesApplicantAddress;
        // 入力された店科口の有無を判定
        if (InputUtils.isAncestorAccountFlag(
            this.state.submitData.ancestorAccountBranchNo,
            this.state.submitData.ancestorAccountItem,
            this.state.submitData.ancestorAccountNo)) {
            // 入力された店科口が外貨である場合、外貨口座Listに存在するか探索
            if (inputAccountsubjectCode === InheritConsts.AvailableAccountType.foreignCurrencySavingsForSystem ||
                inputAccountsubjectCode === InheritConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem) {
                if (this.state.submitData.ancestorCustomerId
                    && this.state.submitData.ancestorCustomerId.length > 0) {
                    exsistsInputAccount = this.state.forexAccountInfo.accounts.some((account) =>
                        account.branchCode === inputAccountBranchCode &&
                        account.subjectCode === inputAccountsubjectCode &&
                        account.accountNo === inputAccountNo &&
                        account.currencyCode === inputAccountCurrencyCode);
                }
                // 存在しない場合、顧客番号9999999999で入力された店科口をListに追加
                if (!exsistsInputAccount) {
                    if (this.state.submitData.ancestorCustomerId
                        && this.state.submitData.ancestorCustomerId.length > 0) {
                        // 口座存在チェックで存在した場合
                        if (this.state.accountSearchStatus === InheritConsts.Status.ON) {
                            const secondaryInputAccount = {
                                customerId: this.state.ancestorCifInfoInquiry.customerId,
                                branchCode: inputAccountBranchCode,
                                branchName: inputAccountBranchName,
                                subjectCode: inputAccountsubjectCode,
                                subjectName: inputAccountsubjectName,
                                accountNo: inputAccountNo,
                                currencyCode: inputAccountCurrencyCode
                            };
                            const secondaryNewAccounts = [...this.state.forexAccountInfo.accounts, secondaryInputAccount];
                            const secondaryOtherInputAccount = {
                                customerId: this.state.ancestorCifInfoInquiry.customerId,
                                branchCode: inputAccountBranchCode,
                                subjectCode: inputAccountsubjectCode,
                                bankAccountId: inputAccountNo,
                                currencyCode: inputAccountCurrencyCode,
                                accountStatus:
                                    (this.state.ancestorCifInfoInquiry.accountStatus === InheritConsts.InheritAccountStatus.InactiveCancellation ||
                                        this.state.ancestorCifInfoInquiry.accountStatus === InheritConsts.InheritAccountStatus.IncomeCancellation) ?
                                        InheritConsts.Status.ON : null,
                                cancelDate: null,
                                depositDetailsInfo: [],
                                exchangeRate: null,
                                forexAccoutSearchStatus: null,
                                forexBalance: null,
                                yenBalance: null
                            };
                            const secondaryNewOther = [...this.state.forexAccountInfo.other, secondaryOtherInputAccount];
                            const secondaryNewForexAccountInfo = ObjectUtils.clone({
                                ...this.state.forexAccountInfo, accounts: secondaryNewAccounts, other: secondaryNewOther
                            });
                            this.action.restoreStateWithBackupData({ forexAccountInfo: secondaryNewForexAccountInfo });
                        } else {
                            // 口座存在チェックで存在しなかった場合
                            const inputAccount = {
                                customerId: inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO,
                                branchCode: inputAccountBranchCode,
                                branchName: inputAccountBranchName,
                                subjectCode: inputAccountsubjectCode,
                                subjectName: inputAccountsubjectName,
                                accountNo: inputAccountNo,
                                currencyCode: inputAccountCurrencyCode
                            };
                            const newAccounts = [...this.state.forexAccountInfo.accounts, inputAccount];
                            const otherInputAccount = {
                                customerId: inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO,
                                branchCode: inputAccountBranchCode,
                                subjectCode: inputAccountsubjectCode,
                                bankAccountId: inputAccountNo,
                                currencyCode: inputAccountCurrencyCode,
                                accountStatus: null,
                                cancelDate: null,
                                depositDetailsInfo: [],
                                exchangeRate: null,
                                forexAccoutSearchStatus: null,
                                forexBalance: null,
                                yenBalance: null
                            };
                            const newOther = [...this.state.forexAccountInfo.other, otherInputAccount];
                            const newForexAccountInfo = ObjectUtils.clone({
                                ...this.state.forexAccountInfo, accounts: newAccounts, other: newOther
                            });
                            this.action.restoreStateWithBackupData({ forexAccountInfo: newForexAccountInfo });
                            // 被相続人情報の設定編集
                            const inputTransPresence = new TransPresenceEntity();
                            inputTransPresence.customerId = mejarCustomerStatus === InheritConsts.Status.ON ?
                                this.state.ancestorCifInfoInquiry.customerId :
                                inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO;
                            inputTransPresence.ancestorNameKana = inputAncestorNameKana;
                            inputTransPresence.ancestorName = inputAncestorName;
                            inputTransPresence.ancestorBirthDate = inputAncestorBirthDate;
                            inputTransPresence.ancestorZipCode = matchesApplicantAddress === YesNoAnswer.YES ?
                                InputUtils.setAncestorZipCode(this.state.submitData) :
                                inputAncestorFirstZipCode + inputAncestorLastZipCode;
                            inputTransPresence.ancestorPrefecture = inputAncestorPrefecture;
                            inputTransPresence.ancestorCountyUrbanVillage = inputAncestorCountyUrbanVillage;
                            inputTransPresence.ancestorStreet = inputAncestorStreet;
                            inputTransPresence.ancestorSubAddress = inputAncestorSubAddress;
                            inputTransPresence.ancestorPrefectureKana = inputAncestorPrefectureKana;
                            inputTransPresence.ancestorCountyUrbanVillageKana = inputAncestorCountyUrbanVillageKana;
                            inputTransPresence.ancestorStreetKana = inputAncestorStreetKana;
                            inputTransPresence.ancestorSubAddressKana = inputAncestorSubAddressKana;
                            inputTransPresence.ancestorAddress = matchesApplicantAddress === YesNoAnswer.YES ?
                                InputUtils.setAncestorAddress(this.state.submitData) : null;
                            inputTransPresence.ancestorAddressKana = matchesApplicantAddress === YesNoAnswer.YES ?
                                InputUtils.setAncestorAddressKana(this.state.submitData) : null;
                            inputTransPresence.representativeCustomerIdFlag = null;
                            inputTransPresence.transType = mejarCustomerStatus === InheritConsts.Status.ON ?
                                InputUtils.setTransType(this.state.submitData) : [];
                            this.action.setStateSubmitDataValue({
                                name: 'transPresenceInfo',
                                value: [...this.state.submitData.transPresenceInfo, inputTransPresence]
                            });
                        }
                    } else {
                        const inputForexAccounts: any[] = [];
                        const otherInputForexAccounts: any[] = [];
                        const inputTransPresenceList = new Array<TransPresenceEntity>();
                        inputForexAccounts.push(
                            {
                                customerId: inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO,
                                branchCode: inputAccountBranchCode,
                                branchName: inputAccountBranchName,
                                subjectCode: inputAccountsubjectCode,
                                subjectName: inputAccountsubjectName,
                                accountNo: inputAccountNo,
                                currencyCode: inputAccountCurrencyCode
                            }
                        );
                        otherInputForexAccounts.push(
                            {
                                customerId: inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO,
                                branchCode: inputAccountBranchCode,
                                subjectCode: inputAccountsubjectCode,
                                bankAccountId: inputAccountNo,
                                currencyCode: inputAccountCurrencyCode,
                                accountStatus: null,
                                cancelDate: null,
                                depositDetailsInfo: [],
                                exchangeRate: null,
                                forexAccoutSearchStatus: null,
                                forexBalance: null,
                                yenBalance: null
                            }
                        );
                        const forexAccountInfo = {
                            status: null,
                            flg: null,
                            other: otherInputForexAccounts,
                            accounts: inputForexAccounts,
                            amount: null
                        };
                        this.action.setStateValue({ key: 'forexAccountInfo', value: forexAccountInfo });
                        // 被相続人情報の設定編集
                        inputTransPresenceList.push(
                            {
                                customerId: inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO,
                                ancestorNameKana: inputAncestorNameKana,
                                ancestorName: inputAncestorName,
                                ancestorBirthDate: inputAncestorBirthDate,
                                ancestorZipCode: matchesApplicantAddress === YesNoAnswer.YES ?
                                    InputUtils.setAncestorZipCode(this.state.submitData) :
                                    inputAncestorFirstZipCode + inputAncestorLastZipCode,
                                ancestorPrefecture: inputAncestorPrefecture,
                                ancestorCountyUrbanVillage: inputAncestorCountyUrbanVillage,
                                ancestorStreet: inputAncestorStreet,
                                ancestorSubAddress: inputAncestorSubAddress,
                                ancestorPrefectureKana: inputAncestorPrefectureKana,
                                ancestorCountyUrbanVillageKana: inputAncestorCountyUrbanVillageKana,
                                ancestorStreetKana: inputAncestorStreetKana,
                                ancestorSubAddressKana: inputAncestorSubAddressKana,
                                ancestorAddress: matchesApplicantAddress === YesNoAnswer.YES ?
                                    InputUtils.setAncestorAddress(this.state.submitData) : null,
                                ancestorAddressKana: matchesApplicantAddress === YesNoAnswer.YES ?
                                    InputUtils.setAncestorAddressKana(this.state.submitData) : null,
                                representativeCustomerIdFlag: null,
                                transType: []
                            }
                        );
                        this.action.setStateSubmitDataValue({
                            name: 'transPresenceInfo',
                            value: inputTransPresenceList
                        });
                    }
                }
            }
        }
        Reflect.defineProperty(this, Constants.INHERIT_ACCOUNTS_PROPERTIES, {
            value: {
                properties: this.labels.inherit.forexAccounttList.properties,
                transform: (data, key) => {
                    if (key === 'bankAccountName') {
                        if (data[key] === null || data[key] === undefined) {
                            return COMMON_CONSTANTS.FULL_HYPHEN;
                        }
                    }
                    if (key === 'balance') {
                        if (data[key] === null || data[key] === undefined) {
                            if (data.customerId === inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO) {
                                return COMMON_CONSTANTS.FULL_HYPHEN + InputUtils.getAlphabetCurrencyName(data.currencyCode);
                            } else {
                                return COMMON_CONSTANTS.FULL_HYPHEN;
                            }
                        }
                        return StringUtils.toCurrency(data[key], false) + data.currencyName;
                    }
                    if (key === 'rate') {
                        if (data[key] === null || data[key] === undefined) {
                            data[key] = COMMON_CONSTANTS.FULL_HYPHEN;
                        }
                        return this.labels.inherit.forexAccounttList.others.title + data[key];
                    }
                    return data[key];
                },
                cssClass: 'text-align-max-height-11',
                statistics: {
                    title: this.labels.inherit.forexAccounttList.statistics.title,
                    unit: this.labels.inherit.forexAccounttList.statistics.unit,
                    calculation: () => {
                        // 合計金額算出時、入力口座のみの場合'ー'を表示する
                        return this.state[entity.name] &&
                            this.state[entity.name].accounts.length === 1 &&
                            this.state[entity.name].accounts[0].customerId ===
                            inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO ?
                            COMMON_CONSTANTS.FULL_HYPHEN :
                            StringUtils.toCurrency(this.state[entity.name].amount, false);
                    }
                }
            }
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    /**
     * Judgeタイプの自定義。
     *
     * @private
     * @param {(ChatFlowMessageInterface | number)} next
     * @param {number} pageIndex
     * @memberof ChatFlowRenderer
     */
    @Renderer(InheritChatFlowQuestionTypes.JUDGE, false)
    private onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        switch (entity.name) {
            case 'existsInputForexAccount': {
                const inputAccountsubjectCode = this.state.submitData.ancestorAccountItem;
                // 入力された科目が外貨普通または外貨定期であるか判定
                const judgeResult = (inputAccountsubjectCode === InheritConsts.AvailableAccountType.foreignCurrencySavingsForSystem ||
                    inputAccountsubjectCode === InheritConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem) ?
                    true : false;
                for (const choice of entity.choices) {
                    if (choice.value === judgeResult) {
                        this.action.getNextChatByAnswer(choice.next, pageIndex);
                    }
                }
                break;
            }
            case 'hasCustomerInfo': {
                const judgeResult = Boolean(
                    this.state.submitData.ancestorCustomerId && this.state.submitData.ancestorCustomerId.length > 0);
                for (const choice of entity.choices) {
                    if (choice.value === judgeResult) {
                        this.action.getNextChatByAnswer(choice.next, pageIndex);
                    }
                }
                break;
            }
        }
    }

}
