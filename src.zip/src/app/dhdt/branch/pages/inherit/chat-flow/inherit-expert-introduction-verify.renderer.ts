import { Injectable } from '@angular/core';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import {
    InheritExpertIntroductionVerifyInputHandler
} from 'dhdt/branch/pages/inherit/chat-flow/inherit-expert-introduction-verify.input-handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { ServerInfoService } from 'dhdt/branch/pages/inherit/services/server-info.service';
import { InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

export const INHERIT_EXPERT_INTRODUCTION_VERIFY_RENDERER_TYPE = 'InheritExpertIntroductionVerifyRenderer';

/**
 * `DefaultChatFlowRenderer`において、遺産整理、税理士の紹介入力画面Rendererを定義しているクラス。
 *
 * @export
 * @class InheritExpertIntroductionVerifyRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_EXPERT_INTRODUCTION_VERIFY_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-expert-introduction-verify.yml'
})
export class InheritExpertIntroductionVerifyRenderer extends DefaultChatFlowRenderer {
    public processType = -1;
    private state: InheritState;

    constructor(
        action: InheritAction,
        private store: InheritStore,
        private serverInfoService: ServerInfoService,
        inputHandler: InheritExpertIntroductionVerifyInputHandler
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * ButtonタイプのデフォルトRenderer。
     *
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof DefaultChatFlowRenderer
     */
    @Renderer([
        InheritChatFlowQuestionTypes.BUTTON,
        InheritChatFlowQuestionTypes.BUTTON_THREE_COLS
    ])
    public onButtonDefaultRenderer(entity: ChatFlowMessageInterface, pageIndex: number): void {
        super.onButtonDefaultRenderer(entity, pageIndex);
    }

}
