import { Injectable, NgZone } from '@angular/core';
import { LabelService } from 'adep/services/label.service';
import { Constants, SubmitDataKey } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritInheritanceMethodHandle } from 'dhdt/branch/pages/inherit/chat-flow/inherit-inheritance-method.handle';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InheritRelationshipComponent } from 'dhdt/branch/pages/inherit/view/inherit-relationship.component';
import { StaffConfirmSimpleComponent } from 'dhdt/branch/pages/inherit/view/staff-confirm-simple.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController } from 'ionic-angular';

export const INHERIT_INHERITANCE_METHOD_RENDERER = 'InheritInheritanceMethodRenderer';

/**
 * `DefaultChatFlowRenderer`において、取引状況表示画面Rendererを定義しているクラス。
 *
 * @export
 * @class InheritSimplifyDomesticLoanRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_INHERITANCE_METHOD_RENDERER,
    templateYaml: 'chat-flow-def-inherit-inheritance-method.yml'
})
export class InheritInheritanceMethodRenderer extends DefaultChatFlowRenderer {
    public processType = -1;
    private state: InheritState;
    private labels: any;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private loginStore: LoginStore,
        private modalController: ModalController,
        private zone: NgZone,
        labelService: LabelService,
        inputHandler: InheritInheritanceMethodHandle,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.labels = labelService.labels;
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    @Renderer(InheritChatFlowQuestionTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: {
                skip: entity.skip
            },
        }, entity, pageIndex);
    }

    @Renderer(InheritChatFlowQuestionTypes.SAVE_SUBMIT)
    private onSaveSubmit(entity: ChatFlowMessageInterface, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((item: any) => {
                this.action.setStateSubmitDataValue(item);
            });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    @Renderer(InheritChatFlowQuestionTypes.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.store.unregisterSignalHandler(InheritSignal.SIMPLIFIED_JUDGMENT_CHECK);
        this.store.registerSignalHandler(InheritSignal.SIMPLIFIED_JUDGMENT_CHECK, (result) => {
            this.store.unregisterSignalHandler(InheritSignal.SIMPLIFIED_JUDGMENT_CHECK);
            const choice = entity.choices.find((item) => item.value === result);
            this.emitMessageRetrivalEvent(choice ? choice.next : entity.next, pageIndex);
        });

        const {
            domesticLoanAccountInfo,
            forexAccountInfo,
            investmentTrustInfo,
            bondAccountInfo,
            bankCardInfo,
            goldProtectionAccounts,
        } = this.state;

        this.action.simplifiedJudgmentCheck({
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo, // 取次店番
                inheritanceMethod: this.state.submitData.inheritanceMethod, // 相続方法
                targetConfirm: this.state.submitData.targetConfirm, // 来店者法定相続人確認フラグ
                passbookConfirm: this.state.submitData.passbookConfirm, // 被相続人通帳・届出印確認フラグ
                domesticLoanAccountTotalAmount: domesticLoanAccountInfo ? domesticLoanAccountInfo.amount : undefined, // 国内預金・融資基本残高の合計金額
                forexAccountTotalAmount: forexAccountInfo ? forexAccountInfo.amount : undefined, // 外貨預金残高の合計金額
                investmentTrustTotalAmount: investmentTrustInfo ? investmentTrustInfo.amount : undefined, // 投資信託の合計金額
                bondAccountTotalAmount: bondAccountInfo ? bondAccountInfo.amount : undefined, // 債券口座の合計金額
                familyTreeInfo: this.state.submitData.relationshipList, // 相続人情報
                domesticLoanAccountInfo: domesticLoanAccountInfo ? domesticLoanAccountInfo.other : undefined, // 国内預金・融資基本口座情報
                transPresenceInfo: this.state.submitData.transPresenceInfo, // 取引有無情報
                inactiveAccount: this.state.submitData.inactiveAccount, // 不動口座情報
                goldProtectionAccounts: goldProtectionAccounts ? goldProtectionAccounts.accounts : undefined, // 金保護口座情報
                forexAccountInfo: forexAccountInfo ? forexAccountInfo.other
                    : this.state.accountSearchStatus === InheritConsts.Status.OFF
                        && (this.state.submitData.ancestorAccountItem ===
                            InheritConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem
                            || this.state.submitData.ancestorAccountItem ===
                            InheritConsts.AvailableAccountType.foreignCurrencySavingsForSystem)
                        ? forexAccountInfo.other : undefined, // 外貨預金口座情報
                investmentTrustInfo: investmentTrustInfo ? investmentTrustInfo.accounts : undefined, // 投資信託情報
                bondAccountInfo: bondAccountInfo ? bondAccountInfo.other : undefined, // 債券口座情報
                bankCardInfo: bankCardInfo ? bankCardInfo.accounts : undefined, // バンクカード情報
                loanAccountInfo: bankCardInfo ? bankCardInfo.other : undefined, // 融資基本口座情報
                domesticAccountSearchStatus: domesticLoanAccountInfo ? domesticLoanAccountInfo.status : undefined,  // 国内預金口座検索結果
                forexAccountSearchStatus: forexAccountInfo ? forexAccountInfo.status : undefined, // 外貨預金口座検索結果
                bondAccountSearchStatus: bondAccountInfo ? bondAccountInfo.status : undefined, // 債券口座検索結果
                bankCardSearchStatus: bankCardInfo ? bankCardInfo.status : undefined, // バンクカード検索結果

                // 注意コード情報
                attentionInfo: this.getAttentionInfoList(),

                // 外国籍の有無
                foreignNationalityStatus: this.state.submitData.hasForeignHeir,
                // 北朝鮮在住の有無
                northKoreaResidenceStatus: this.state.submitData.hasNorthKoreaHeir,
                // 紛議の有無
                disputesStatus: this.state.submitData.hasHeirDisputes,
                // 配偶者自署押印可否
                spouseSignatureAndSealPropriety: this.state.submitData.spouseSignatureAndSealPropriety,
            }
        });
    }

    private getAttentionInfoList() {
        // 「同一名義人照会（相続）」で取得した
        let list: any[];
        if (this.state.ancestorInquiryResults && this.state.ancestorInquiryResults.length > 0) {
            list = this.state.ancestorInquiryResults.reduce((previous, current) => {
                const accounts = current.customerId.map((id) => {
                    const account = current.duplicateAccount.find((item) => item.customerId === id);
                    if (account) {
                        return {
                            customerId: account.customerId || null,
                            unacceptables: account.unacceptables || null,
                            nationalityCode: account.nationalityCode || null,
                            unacceptableCodeInfo: account.unacceptableCodeInfo || null
                        };
                    }
                    return null;
                });
                return previous.concat(accounts);
            }, []);
        } else {
            list = [];
        }

        // 入力口座CIFの全店名寄せ照会結果に含まれる各CIFについて、注意コード情報を設定する
        if (this.state.ancestorInquiryResultsDefault && this.state.ancestorInquiryResultsDefault.length > 0) {
            const defaultList = this.state.ancestorInquiryResultsDefault.reduce((previous, current) => {
                const accounts = current.customerId.map((id) => {
                    const account = current.duplicateAccount.find((item) => item.customerId === id);
                    if (account) {
                        return {
                            customerId: account.customerId || null,
                            unacceptables: account.unacceptables || null,
                            nationalityCode: account.nationalityCode || null,
                            unacceptableCodeInfo: account.unacceptableCodeInfo || null
                        };
                    }
                    return null;
                });
                return previous.concat(accounts);
            }, []);
            return defaultList.concat(list);
        } else {
            return list;
        }
    }

    @Renderer(InheritChatFlowQuestionTypes.ACCOUNT_LIST)
    private onAccountList(entity: ChatFlowMessageInterface, pageIndex: number) {
        Reflect.defineProperty(this, Constants.INHERIT_ACCOUNTS_PROPERTIES, {
            value: {
                properties: this.labels.inherit.ancestorAccountList.properties,
                transform: (data, key) => {
                    if (key === 'balance') {
                        return StringUtils.toCurrency(data[key]);
                    }
                    if (key === 'custodyNumber' && data.subjectCode !== '20') {
                        return '';
                    }
                    return data[key];
                },
                cssClass: 'text-align-max-height-09',
                statistics: {
                    title: this.labels.inherit.ancestorAccountList.statistics.title,
                    unit: this.labels.inherit.ancestorAccountList.statistics.unit,
                    calculation: () => {
                        return StringUtils.toCurrency(this.state[entity.name] ? this.state[entity.name].amount : undefined, false);
                    }
                }
            }
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(InheritChatFlowQuestionTypes.JUDGE)
    private onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        if (entity.name === 'conditionDivergent') {
            let judgeResult: string;
            // 超簡易手続き、簡易手続き200、一般手続き
            judgeResult = this.state.submitData.simplifiedJudgment;
            // 簡易手続き300 自署押印可能
            if (judgeResult === '3') {
                if (this.state.submitData.spouseSignatureAndSealPropriety === '0') {
                    judgeResult = '5';
                }
            }
            for (const choice of entity.choices) {
                if (choice.value === judgeResult) {
                    this.emitMessageRetrivalEvent(choice.next, pageIndex);
                }
            }
        } else {
            const choice = entity.choices ? entity.choices.find((item) => item.value === this.state.submitData[entity.name]) : undefined;
            this.emitMessageRetrivalEvent(choice ? choice.next : entity.next, pageIndex);
        }
    }

    @Renderer(InheritChatFlowQuestionTypes.PRESENT_MODAL)
    private onPresentRelationshipView(entity: ChatFlowMessageInterface, pageIndex: number) {
        if (entity.name === SubmitDataKey.RELATIONSHIP_LIST) {
            const modal = this.modalController.create(InheritRelationshipComponent, undefined, {
                cssClass: 'full-modal', enableBackdropDismiss: false
            });
            modal.onDidDismiss((value) => {
                if (value === 'back') {
                    this.action.popToView(StaffConfirmSimpleComponent);
                } else {
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                }
            });
            this.zone.run(() => modal.present());
        }
    }
}
