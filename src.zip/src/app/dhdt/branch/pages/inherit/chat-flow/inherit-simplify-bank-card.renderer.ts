import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { COMMON_CONSTANTS, Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritSimplifyBankCardHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-bank-card.handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { SimplifyBankCardListComponent } from 'dhdt/branch/shared/components/simplify-bank-card-list/simplify-bank-card-list.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

export const INHERIT_SIMPLIFY_BANK_CARD_RENDERER_TYPE = 'InheritSimplifyBankCardRenderer';

/**
 * `DefaultChatFlowRendererバンクカード残高一覧画面クラス。
 *
 * @export
 * @class InheritSimplifyInvestmentTrustRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_SIMPLIFY_BANK_CARD_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-simplify-bank-card.yml'
})
export class InheritSimplifyBankCardRenderer extends DefaultChatFlowRenderer {
    public processType = -1;

    private state: InheritState;
    private labels: any;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private loginStore: LoginStore,
        labelService: LabelService,
        inputHandler: InheritSimplifyBankCardHandler,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.labels = labelService.labels;
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * Judgeタイプの自定義。
     *
     * @protected
     * @param {(ChatFlowMessageInterface | number)} next
     * @param {number} pageIndex
     * @memberof ChatFlowRenderer
     */
    @Renderer(InheritChatFlowQuestionTypes.JUDGE, false)
    protected onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        switch (entity.name) {
            case 'hasCustomerInfo': {
                const judgeResult = Boolean(
                    this.state.submitData.ancestorCustomerId && this.state.submitData.ancestorCustomerId.length > 0);
                for (const choice of entity.choices) {
                    if (choice.value === judgeResult) {
                        this.action.getNextChatByAnswer(choice.next, pageIndex);
                    }
                }
                break;
            }
        }
    }

    @Renderer(InheritChatFlowQuestionTypes.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.store.unregisterSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY);
        this.store.registerSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY, (result) => {
            this.store.unregisterSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY);

            const choice = entity.choices.find((item) => item.value === result);
            this.emitMessageRetrivalEvent(choice.next, pageIndex);
        });
        this.action.bankCardAccountsBalanceInquiry(entity, {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                customerId: this.state.submitData.allCustomerId,
                inheritFlg: InheritConsts.InheritFlg.flagTrue
            }
        });
    }

    @Renderer(InheritChatFlowQuestionTypes.BANK_CARD_LIST)
    private onBankCardList(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.store.registerSignalHandler(InheritSignal.RESET_LIST, (result) => {
            this.store.unregisterSignalHandler(InheritSignal.RESET_LIST);
            const options = {
                skip: entity.skip
            };

            this.emitRenderEvent({
                class: SimplifyBankCardListComponent,
                data: { list: this.state.bankCardInfo.accounts, amount: this.state.bankCardInfo.amount },
                options: options,
            }, entity, pageIndex);
        });
        this.action.resetList({
            key: 'bankCardInfo',
            backupKey: 'bankCardInfoBackup'
        });
    }

    @Renderer(InheritChatFlowQuestionTypes.ACCOUNT_LIST)
    private onAccountList(entity: ChatFlowMessageInterface, pageIndex: number) {
        Reflect.defineProperty(this, Constants.INHERIT_ACCOUNTS_PROPERTIES, {
            value: {
                properties: this.labels.inherit.bankCardList.properties,
                transform: (data, key) => {
                    if (key === 'shoppingBalance' || key === 'cashingInterest') {
                        if (data[key] || data[key] === 0) {
                            return StringUtils.toCurrency(data[key]);
                        } else {
                            return COMMON_CONSTANTS.FULL_SPACE + this.labels.inherit.bankCardList.yen;
                        }
                    }
                    if (key === 'cashingBalance') {
                        if (data[key] || data[key] === 0) {
                            return StringUtils.toCurrency(data[key]);
                        } else {
                            return COMMON_CONSTANTS.FULL_SPACE + this.labels.inherit.bankCardList.yen;
                        }
                    }
                    return data[key];
                },
                statistics: {
                    title: this.labels.inherit.bankCardList.statistics.title,
                    unit: this.labels.inherit.bankCardList.statistics.unit,
                    calculation: () => {
                        return StringUtils.toCurrency(this.state.bankCardInfo.amount, false);
                    }
                },

            }
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }
}
