import { Injectable } from '@angular/core';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';

/**
 * `DefaultChatFlowInputHandler`において、死亡者口座一覧表示画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class InheritSimplifyDomesticLoanHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritSimplifyDomesticLoanHandler extends DefaultChatFlowInputHandler {
    private state: InheritState;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private loginStore: LoginStore
    ) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(InheritChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            const answerValues = new Array();
            answerValues.push({ key: entity.name, value: answer.value });
            answerValues.push({ key: answer.name, value: answer.value });

            this.setAnswer({
                text: answer.text,
                value: answerValues
            });
        }

        if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }
}
