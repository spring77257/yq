import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * `DefaultChatFlowInputHandler`において、専門家案内要否・入力に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class InheritDeadInputInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritExpertIntroductionVerifyInputHandler extends DefaultChatFlowInputHandler {
    private state: InheritState;

    constructor(private action: InheritAction,
                private store: InheritStore,
                private loginStore: LoginStore,
                private modalService: ModalService,
                private labelService: LabelService,
                private errorMessageService: ErrorMessageService,
                private deviceService: DeviceService) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler([InheritChatFlowQuestionTypes.BUTTON,
        InheritChatFlowQuestionTypes.BUTTON_THREE_COLS])
    private onButtonHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {

            if (entity.name.length > 0 && answer.value.length > 0) {
                const answerValues = new Array();
                answerValues.push({ key: entity.name, value: answer.value });
                answerValues.push({ key: answer.name, value: answer.value });

                this.setAnswer({
                    text: answer.text,
                    value: answerValues
                });
            }

            if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
                this.chatFlowCompelete(answer.action.value);
            } else if (answer.next !== -1) {
                this.emitMessageRetrivalEvent(answer.next, pageIndex);
            }
    }

}
