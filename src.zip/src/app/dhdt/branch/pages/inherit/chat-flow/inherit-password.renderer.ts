import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { ChangeConfirmComponent } from 'dhdt/branch/pages/change/view/change-confirm.component';
import { COMMON_CONSTANTS, CoreBankingConst, InheritRequestType } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritPasswordInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-password.input-handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { ChatFlowQuestionTypes } from 'dhdt/branch/shared/modules/chat-flow/chat-flow-question-types';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { App, NavController } from 'ionic-angular';

export const INHERIT_PASSWORD_RENDERER_TYPE = 'InheritPasswordComponent';

/**
 * `DefaultChatFlowRenderer`において、相続手続き開始画面Rendererを定義しているクラス。
 *
 * @export
 * @class InheritPasswordRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_PASSWORD_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-password.yml'
})
export class InheritPasswordRenderer extends DefaultChatFlowRenderer {
    public processType = 0;
    private state: InheritState;
    private navCtrl: NavController;
    private readonly KEY_APPLICANT_CARD_AUTHENTICATION = 'applicantCardAuthentication';
    private readonly KEY_APPLICANT_CARD_AUTHENTICATION_SUCCESS = '1';

    constructor(private action: InheritAction, private store: InheritStore,
                private modalService: ModalService, private labelService: LabelService,
                private loginStore: LoginStore, private deviceService: DeviceService,
                app: App, inputHandler: InheritPasswordInputHandler) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.navCtrl = app.getActiveNavs()[0];
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * JudgeタイプのデフォルトRenderer。
     *
     * @protected
     * @param {(ChatFlowMessageInterface | number)} next
     * @param {number} pageIndex
     * @memberof ChatFlowRenderer
     */
    @Renderer(ChatFlowQuestionTypes.JUDGE)
    protected onJudgeDefaultRenderer(entity: ChatFlowMessageInterface, pageIndex: number): void {
        if (entity.choices) {
            const choice = entity.choices.find((item) => this.state.submitData[entity.name] === item.value);
            this.emitMessageRetrivalEvent(choice ? choice.next : entity.next, pageIndex, 0);
        }
    }
}
