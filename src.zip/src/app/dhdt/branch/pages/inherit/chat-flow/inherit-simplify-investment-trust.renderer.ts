import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { COMMON_CONSTANTS, Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritSimplifyInvestmentTrustHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-investment-trust.handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

export const INHERIT_SIMPLIFY_INVESTMENTRUST_RENDERER_TYPE = 'InheritSimplifyInvestmentTrustRenderer';

/**
 * `DefaultChatFlowRenderer`において、死亡者情報入力画面Rendererを定義しているクラス。
 *
 * @export
 * @class InheritSimplifyInvestmentTrustRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_SIMPLIFY_INVESTMENTRUST_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-simplify-investment-trust.yml'
})
export class InheritSimplifyInvestmentTrustRenderer extends DefaultChatFlowRenderer {
    public processType = -1;

    private state: InheritState;
    private labels: any;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private loginStore: LoginStore,
        labelService: LabelService,
        inputHandler: InheritSimplifyInvestmentTrustHandler,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.labels = labelService.labels;
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * Judgeタイプの自定義。
     *
     * @protected
     * @param {(ChatFlowMessageInterface | number)} next
     * @param {number} pageIndex
     * @memberof ChatFlowRenderer
     */
    @Renderer(InheritChatFlowQuestionTypes.JUDGE, false)
    protected onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        switch (entity.name) {
            case 'hasCustomerInfo': {
                const judgeResult = Boolean(
                    this.state.submitData.ancestorCustomerId && this.state.submitData.ancestorCustomerId.length > 0);
                for (const choice of entity.choices) {
                    if (choice.value === judgeResult) {
                        this.action.getNextChatByAnswer(choice.next, pageIndex);
                    }
                }
                break;
            }
        }
    }

    @Renderer(InheritChatFlowQuestionTypes.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.store.unregisterSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY);
        this.store.registerSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY, (result) => {
            this.store.unregisterSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY);

            const choice = entity.choices.find((item) => item.value === result);
            this.emitMessageRetrivalEvent(choice.next, pageIndex);
        });
        this.action.investmentTrustAccountsBalanceInquiry(entity, {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                customerId: this.state.submitData.allCustomerId,
                inheritFlg: InheritConsts.InheritFlg.flagTrue
            }
        });
    }

    @Renderer(InheritChatFlowQuestionTypes.ACCOUNT_LIST)
    private onAccountList(entity: ChatFlowMessageInterface, pageIndex: number) {
        Reflect.defineProperty(this, Constants.INHERIT_ACCOUNTS_PROPERTIES, {
            value: {
                properties: this.labels.inherit.investmentTrustList.properties,
                transform: (data, key) => {
                    // 残高：口座のみ存在し、ファンド・銘柄がない場合は「ー」を表示する。
                    if (key === 'balance') {
                        if (!data.fundName) {
                            return COMMON_CONSTANTS.FULL_HYPHEN;
                        } else {
                            return StringUtils.toCurrency(data[key]);
                        }
                    }
                    // 口数：口座のみ存在し、ファンド・銘柄がない場合は「ー」を表示する。
                    if (key === 'fundCount') {
                        if (!data.fundName) {
                            return COMMON_CONSTANTS.FULL_HYPHEN;
                        } else {
                            return this.labels.inherit.investmentTrustList.others.title + StringUtils.toCurrency(data[key], false);
                        }
                    }
                    // ファンド名：ファンド・銘柄：口座のみ存在し、ファンド・銘柄がない場合は「ー」を表示する。
                    if (key === 'fundName') {
                        if (!data.fundName) {
                            return COMMON_CONSTANTS.FULL_HYPHEN;
                        } else if (data.specificDepositCategoryName) {
                            return data.fundName
                                + COMMON_CONSTANTS.FULL_SPACE
                                + data.specificDepositCategoryName;
                        }
                    }
                    return data[key];
                },
                cssClass: 'text-align-max-height-11',
                statistics: {
                    title: this.labels.inherit.investmentTrustList.statistics.title,
                    unit: this.labels.inherit.investmentTrustList.statistics.unit,
                    calculation: () => {
                        return StringUtils.toCurrency(this.state[entity.name] ? this.state[entity.name].amount : undefined, false);
                    }
                },
            }
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }
}
