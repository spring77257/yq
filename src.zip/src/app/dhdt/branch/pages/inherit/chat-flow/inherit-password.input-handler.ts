import { Injectable } from '@angular/core';
import { AppProperties } from 'app.properties';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { Observable } from 'rxjs';

/**
 * `DefaultChatFlowInputHandler`において、相続手続き開始画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class InheritPasswordInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritPasswordInputHandler extends DefaultChatFlowInputHandler {

    constructor(private action: InheritAction,
                private modalService: ModalService,
        ) {
            super(action);
    }

    @InputHandler(InheritChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            if (!answer.action ||
                (answer.action.value !== 'noticeButtonModal' &&
                answer.action.type !== COMMON_CONSTANTS.ACTION_TYPE_MODAL)) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value },
                            { key: answer.name, value: answer.value }
                        ]
                    });
            }
        }
        if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        } else if (answer.action.type.length > 0) {
            this.configAction(entity, answer, pageIndex);
        }
    }

    private configAction(entity: any, choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'modal') {
            this.modalService.showModal(
                action.value, { imgSrc: COMMON_CONSTANTS.INHERIT_INHERITANCE_PROCEDURES});
            Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                this.action.resetLastNode();
            });
        }
    }

}
