import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * `DefaultChatFlowInputHandler`において、入金口座選択・入力に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class InheritDeadInputInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritPaymentInfoInputHandler extends DefaultChatFlowInputHandler {
    private readonly KEY_PAGER_ENTRY = 'pagerEntry';
    private state: InheritState;

    constructor(private action: InheritAction,
                private store: InheritStore,
                private loginStore: LoginStore,
                private modalService: ModalService,
                private labelService: LabelService,
                private errorMessageService: ErrorMessageService,
                private deviceService: DeviceService) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(InheritChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            // skipを選択の場合
            this.action.clearPaymentAccountInfo();
            this.setAnswer({ text: this.labelService.labels.common.skipjp, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        } else {
            if (entity.name.length > 0 && answer.value.length > 0) {
                const answerValues = new Array();
                answerValues.push({ key: entity.name, value: answer.value });
                answerValues.push({ key: answer.name, value: answer.value });

                this.setAnswer({
                    text: answer.text,
                    value: answerValues
                });
            }

            if (entity.name === this.KEY_PAGER_ENTRY) {
                this.action.clearPaymentAccountInfo();
            }

            if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
                this.chatFlowCompelete(answer.action.value);
            } else if (answer.next !== -1) {
                this.emitMessageRetrivalEvent(answer.next, pageIndex);
            }
        }

    }

    @InputHandler(InheritChatFlowQuestionTypes.SELECT_BRANCH)
    private onSelectBranchHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({
            text: answer.text,
            value: [{
                key: entity.name,
                value: answer.branchNo
            }]
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(InheritChatFlowQuestionTypes.KEYBOARD)
    private onKeybordHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        const text = answer.value[0].value + COMMON_CONSTANTS.FULL_SPACE + answer.value[1].value;
        this.setAnswer({ text: text, value: answer.value });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(InheritChatFlowQuestionTypes.NUMBER_KEYBORD)
    private onNumberKeyboardHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        this.setAnswer(answer);

        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                tenban: this.state.submitData.representativeHeirAccountBranchNo,
                accountType: this.state.submitData.representativeHeirAccountItem,
                accountNo: answer.value[0].value, // 口座番号
                businessCode: '00', // 業務コード
            }
        };

        // 口座存在チェックハンドルを追加
        this.store.unregisterSignalHandler(InheritSignal.GET_CHECK_ACCOUNT_EXISTING_PAYMENT);
        this.store.registerSignalHandler(InheritSignal.GET_CHECK_ACCOUNT_EXISTING_PAYMENT, () => {
            this.store.unregisterSignalHandler(InheritSignal.GET_CHECK_ACCOUNT_EXISTING_PAYMENT);

            // 受付可否チェック
            this.store.unregisterSignalHandler(InheritSignal.RECEPTION_CHECK);
            this.store.registerSignalHandler(InheritSignal.RECEPTION_CHECK, () => {
                this.store.unregisterSignalHandler(InheritSignal.RECEPTION_CHECK);
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            });
            // 受付可否チェックAPIを呼び出す
            this.action.receptionCheck(param);
        });

        const accountParam = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                tenban: this.state.submitData.representativeHeirAccountBranchNo,
                accountType: this.state.submitData.representativeHeirAccountItem,
                accountNo: answer.value[0].value, // 口座番号
                businessCode: entity.options.businessCode,
                inheritFlg: InheritConsts.InheritFlg.flagFalse
            }
        };

        this.action.checkAccountExistingPayment(accountParam);
    }
}
