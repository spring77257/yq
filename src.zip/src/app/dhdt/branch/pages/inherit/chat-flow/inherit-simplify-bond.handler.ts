import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * `DefaultChatFlowInputHandler`において、死亡者口座一覧表示画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class InheritSimplifyForexHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritSimplifyBondHandler extends DefaultChatFlowInputHandler {
    private readonly KEY_ADD_ACCOUNT = 'addAccount';
    private readonly KEY_ADD_ABANDONED_ACCOUNT = 'addAbandonedAccount';
    private readonly KEY_ADD_BROKERAGE_ACCOUNT = 'addBrokerageAccount';
    private readonly KEY_EXISTING_ACCOUNT = '1';
    private readonly KEY_CANNOT_FIND_ACCOUNT = '2';
    private state: InheritState;

    constructor(private action: InheritAction, private labelService: LabelService,
                private store: InheritStore, private modalService: ModalService,
                private deviceService: DeviceService) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(InheritChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            const answerValues = new Array();
            answerValues.push({ key: entity.name, value: answer.value });
            answerValues.push({ key: answer.name, value: answer.value });

            this.setAnswer({
                text: answer.text,
                value: answerValues
            });
        }

        if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }
}
