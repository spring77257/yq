import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services/label.service';
import { Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritSimplifyDomesticLoanHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-domestic-loan.handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

export const INHERIT_SIMPLIFY_DOMESTIC_LOAN_TYPE = 'InheritSimplifyDomesticLoanRenderer';

/**
 * `DefaultChatFlowRenderer`において、死亡者情報入力画面Rendererを定義しているクラス。
 *
 * @export
 * @class InheritSimplifyDomesticLoanRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_SIMPLIFY_DOMESTIC_LOAN_TYPE,
    templateYaml: 'chat-flow-def-inherit-simplify.yml'
})
export class InheritSimplifyDomesticLoanRenderer extends DefaultChatFlowRenderer {
    public processType = -1;
    private state: InheritState;
    private labels: any;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private loginStore: LoginStore,
        labelService: LabelService,
        inputHandler: InheritSimplifyDomesticLoanHandler,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.labels = labelService.labels;
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * Judgeタイプの自定義。
     *
     * @protected
     * @param {(ChatFlowMessageInterface | number)} next
     * @param {number} pageIndex
     * @memberof ChatFlowRenderer
     */
    @Renderer(InheritChatFlowQuestionTypes.JUDGE, false)
    protected onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        switch (entity.name) {
            case 'hasCustomerInfo': {
                const judgeResult = Boolean(
                    this.state.submitData.ancestorCustomerId && this.state.submitData.ancestorCustomerId.length > 0);
                for (const choice of entity.choices) {
                    if (choice.value === judgeResult) {
                        this.action.getNextChatByAnswer(choice.next, pageIndex);
                    }
                }
                break;
            }
        }
    }

    @Renderer(InheritChatFlowQuestionTypes.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.store.unregisterSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY);
        this.store.registerSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY, (result) => {
            this.store.unregisterSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY);

            const choice = entity.choices.find((item) => item.value === result);
            this.emitMessageRetrivalEvent(choice.next, pageIndex);
        });
        this.action.domesticLoanAccountsBalanceInquiry(entity, {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                customerId: this.state.submitData.allCustomerId,
                inheritFlg: InheritConsts.InheritFlg.flagTrue
            }
        });
    }

    @Renderer(InheritChatFlowQuestionTypes.ACCOUNT_LIST)
    private onAccountList(entity: ChatFlowMessageInterface, pageIndex: number) {
        Reflect.defineProperty(this, Constants.INHERIT_ACCOUNTS_PROPERTIES, {
            value: {
                properties: this.labels.inherit.ancestorAccountList.properties,
                transform: (data, key) => {
                    if (key === 'subjectName') {
                        return data.subjectName.replace('（', '\n（');
                    }
                    if (key === 'balance') {
                        return StringUtils.toCurrency(data[key]);
                    }
                    if (key === 'custodyNumber' && data.subjectCode !== '20') {
                        return '';
                    }
                    return data[key];
                },
                cssClass: 'text-align-max-height-09',
                statistics: {
                    title: this.labels.inherit.ancestorAccountList.statistics.title,
                    unit: this.labels.inherit.ancestorAccountList.statistics.unit,
                    calculation: () => {
                        return StringUtils.toCurrency(this.state[entity.name] ? this.state[entity.name].amount : undefined, false);
                    }
                }
            }
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }
}
