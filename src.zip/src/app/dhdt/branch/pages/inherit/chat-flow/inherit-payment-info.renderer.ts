import { Injectable } from '@angular/core';
import { AccountType, COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritPaymentInfoInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-payment-info.input-handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

export const INHERIT_PAYMENT_CHAT_RENDERER_TYPE = 'InheritPaymentInfoRenderer';

/**
 * `DefaultChatFlowRenderer`において、入金口座選択・入力画面Rendererを定義しているクラス。
 *
 * @export
 * @class InheritDeadInputRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_PAYMENT_CHAT_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-payment-input.yml'
})
export class InheritPaymentInfoRenderer extends DefaultChatFlowRenderer {
    public processType = -1;
    private state: InheritState;

    constructor(
        private action: InheritAction, private store: InheritStore,
        inputHandler: InheritPaymentInfoInputHandler
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * Judgeタイプの自定義。
     *
     * @protected
     * @param {(ChatFlowMessageInterface | number)} next
     * @param {number} pageIndex
     * @memberof ChatFlowRenderer
     */
    @Renderer(InheritChatFlowQuestionTypes.JUDGE, false)
    protected onJudgeDefaultRenderer(entity: ChatFlowMessageInterface, pageIndex: number): void {
        if (entity.choices) { // 固定値の場合
            for (const choice of entity.choices) {
                if ((choice.value === COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE_UNDEFINE && StringUtils.isEmpty(this.userAnswers[entity.name]))
                    || choice.value === COMMON_CONSTANTS.ELEMENT_TYPE_JUDGE_OTHER
                    || choice.value === this.userAnswers[entity.name]) {
                    this.emitMessageRetrivalEvent(choice.next, pageIndex, 0);
                    return;
                }
            }
        }
    }

    /**
     * ButtonタイプのデフォルトRenderer。
     *
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof DefaultChatFlowRenderer
     */
    @Renderer(InheritChatFlowQuestionTypes.BUTTON)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type, name: entity.name,
            maxColNum: entity.name === 'representativeHeirAccountItem' ?  3 : undefined // 科目選択の場合3列
        };

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * キーボードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(InheritChatFlowQuestionTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * 入金口座の口座番号を入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(InheritChatFlowQuestionTypes.NUMBER_KEYBORD)
    public onNumberKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = { validationRules: entity.validationRules, skip: entity.skip, type: entity.type, name: entity.name };
        this.emitRenderEvent({
            class: NumberInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * 店舗コンポーネント表示
     * @param entity ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    @Renderer(InheritChatFlowQuestionTypes.SELECT_BRANCH)
    public onSelectBranch(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxColNum: 2,
            accountType: AccountType.INHERIT
        };
        this.emitRenderEvent({
            class: SelectBranchComponent,
            data: undefined,
            options: options
        }, entity, pageIndex);
    }

    /**
     * ユーザのInputを必要としないType（TextやImage）用のRenderer。
     *
     * @protected
     * @param {(ChatFlowMessageInterface | number)} next
     * @param {number} pageIndex
     * @param {number} [nextChatDelay]
     * @memberof DefaultChatFlowRenderer
     */
    @Renderer(InheritChatFlowQuestionTypes.PAYMENT_ACCOUNT)
    protected onNonQuestionDefaultRenderer(next: ChatFlowMessageInterface | number, pageIndex: number, nextChatDelay?: number) {
        super.onNonQuestionDefaultRenderer(next, pageIndex, nextChatDelay);
    }

    @Renderer(InheritChatFlowQuestionTypes.SAVE_SUBMIT)
    private onSaveSubmit(entity: ChatFlowMessageInterface, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((item: any) => {
                this.action.setStateSubmitDataValue(item);
            });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }
}
