import { Injectable } from '@angular/core';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';

/**
 * `DefaultChatFlowInputHandler`において、死亡者口座一覧表示画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class InheritSimplifyForexHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritSimplifyBankCardHandler extends DefaultChatFlowInputHandler {
    private state: InheritState;

    constructor(private action: InheritAction,
                private store: InheritStore) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(InheritChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            const answerValues = new Array();
            answerValues.push({ key: entity.name, value: answer.value });
            answerValues.push({ key: answer.name, value: answer.value });

            this.setAnswer({
                text: answer.text,
                value: answerValues
            });
        }

        if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(InheritChatFlowQuestionTypes.BANK_CARD_LIST)
    private onBankCardListHandler(entity, pageIndex, answer) {
        let next = entity.next;
        if (answer.answerText === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({
                text: COMMON_CONSTANTS.SKIP_TEXT,
                value: [],
            });
            next = entity.skip;
            this.store.registerSignalHandler(InheritSignal.RESET_LIST, () => {
                this.store.unregisterSignalHandler(InheritSignal.RESET_LIST);
                this.emitMessageRetrivalEvent(next, pageIndex);
            });
            this.action.resetList({
                key: 'bankCardInfo',
                backupKey: 'bankCardInfoBackup'
            });
        } else {
            this.setAnswer({
                text: answer.answerText,
                value: [],
            });
            this.action.setStateValue({ key: 'bankCardInfo', value: {...this.state.bankCardInfo, amount: answer.totalAmount} });
            this.emitMessageRetrivalEvent(next, pageIndex);
        }
    }
}
