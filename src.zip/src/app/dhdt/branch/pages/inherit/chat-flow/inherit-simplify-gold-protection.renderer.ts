import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { COMMON_CONSTANTS, Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritSimplifyGoldProtectionHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-simplify-gold-protection.handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { SimplifyGoldListComponent } from 'dhdt/branch/shared/components/simplify-gold-list/simplify-gold-list.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

export const INHERIT_SIMPLIFY_GOLD_PROTECTION_RENDERER_TYPE = 'InheritSimplifyGoldProtectionRenderer';

/**
 * `DefaultChatFlowRenderer`金保護預かり残高一覧。
 *
 * @export
 * @class InheritSimplifyInvestmentTrustRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_SIMPLIFY_GOLD_PROTECTION_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-simplify-gold-protection.yml'
})
export class InheritSimplifyGoldProtectionRenderer extends DefaultChatFlowRenderer {
    public processType = -1;

    private state: InheritState;
    private labels: any;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private loginStore: LoginStore,
        labelService: LabelService,
        inputHandler: InheritSimplifyGoldProtectionHandler,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.labels = labelService.labels;
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * Judgeタイプの自定義。
     *
     * @protected
     * @param {(ChatFlowMessageInterface | number)} next
     * @param {number} pageIndex
     * @memberof ChatFlowRenderer
     */
    @Renderer(InheritChatFlowQuestionTypes.JUDGE, false)
    protected onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        switch (entity.name) {
            case 'hasCustomerInfo': {
                const judgeResult = Boolean(
                    this.state.submitData.ancestorCustomerId && this.state.submitData.ancestorCustomerId.length > 0);
                for (const choice of entity.choices) {
                    if (choice.value === judgeResult) {
                        this.action.getNextChatByAnswer(choice.next, pageIndex);
                    }
                }
                break;
            }
        }
    }

    @Renderer(InheritChatFlowQuestionTypes.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.store.unregisterSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY);
        this.store.registerSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY, (result) => {
            this.store.unregisterSignalHandler(InheritSignal.ACCOUNTS_BALANCE_INQUIRY);

            const choice = entity.choices.find((item) => item.value === result);
            this.emitMessageRetrivalEvent(choice.next, pageIndex);
        });
        this.action.goldProtectionAccountsBalanceInquiry(entity, {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                customerId: this.state.submitData.allCustomerId,
                inheritFlg: InheritConsts.InheritFlg.flagTrue
            }
        });
    }

    @Renderer(InheritChatFlowQuestionTypes.GOLD_LIST)
    private onBankCardList(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.store.registerSignalHandler(InheritSignal.RESET_LIST, (result) => {
            this.store.unregisterSignalHandler(InheritSignal.RESET_LIST);
            const options = {
                skip: entity.skip
            };
            this.emitRenderEvent({
                class: SimplifyGoldListComponent,
                data: this.state.goldProtectionAccounts.accounts,
                options: options,
            }, entity, pageIndex);
        });
        this.action.resetList({
            key: 'goldProtectionAccounts',
            backupKey: 'goldProtectionAccountsBackup'
        });
    }

    @Renderer(InheritChatFlowQuestionTypes.ACCOUNT_LIST)
    private onAccountList(entity: ChatFlowMessageInterface, pageIndex: number) {
        Reflect.defineProperty(this, Constants.INHERIT_ACCOUNTS_PROPERTIES, {
            value: {
                properties: this.labels.inherit.simplifyGoldList.properties,
                transform: (data, key) => {
                    if (key === 'depositAmount') {
                        if (data[key] || data[key] === 0) {
                            return StringUtils.toCurrency(data[key], this.labels.inherit.simplifyGoldList.grame);
                        } else {
                            return COMMON_CONSTANTS.FULL_SPACE + this.labels.inherit.simplifyGoldList.grame;
                        }
                    }
                    if (key === 'currentDayConvertingPrice') {
                        if (data[key] || data[key] === 0) {
                            return StringUtils.toCurrency(data[key], this.labels.inherit.simplifyGoldList.yenGrame);
                        } else {
                            return COMMON_CONSTANTS.FULL_SPACE + this.labels.inherit.simplifyGoldList.yenGrame;
                        }
                    }
                    if (key === 'balance') {
                        if (data[key] || data[key] === 0) {
                            return StringUtils.toCurrency(data[key]);
                        } else {
                            return COMMON_CONSTANTS.FULL_SPACE + this.labels.inherit.simplifyGoldList.yen;
                        }
                    }
                    if (key === 'customerId') {
                        if (!data.customerId) {
                            // 顧客番号が存在しない場合は「-」を表示する。
                            return COMMON_CONSTANTS.FULL_HYPHEN;
                        }
                    }
                    if (key === 'branchName') {
                        if (!data.branchName) {
                            // 店名が存在しない場合は「-」を表示する。
                            return COMMON_CONSTANTS.FULL_HYPHEN;
                        }
                    }
                    if (key === 'accountName') {
                        if (!data.accountName) {
                            // 口座名義が存在しない場合は「-」を表示する。
                            return COMMON_CONSTANTS.FULL_HYPHEN;
                        }
                    }
                    return data[key];
                },
                cssClass: 'text-align-max-height-14a',
                statistics: {
                    title: this.labels.inherit.simplifyGoldList.statistics.title,
                    unit: this.labels.inherit.simplifyGoldList.statistics.unit,
                    calculation: () => {
                        if (this.state.submitData[entity.name].isModifyFlag) {
                            const amount = this.state.submitData[entity.name].amount;
                            return StringUtils.toCurrency(amount, false);
                        }
                    }
                },
            }
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(InheritChatFlowQuestionTypes.COMPELETE)
    private onCompelete(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.action.chatFlowCompelete(entity.example);
    }
}
