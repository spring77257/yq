import { Injectable } from '@angular/core';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';

/**
 * `DefaultChatFlowInputHandler`において、死亡者口座一覧表示画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class InheritSimplifyForexHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritSimplifyGoldProtectionHandler extends DefaultChatFlowInputHandler {
    private state: InheritState;

    constructor(private action: InheritAction,
                private store: InheritStore) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(InheritChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            const answerValues = new Array();
            answerValues.push({ key: entity.name, value: answer.value });
            answerValues.push({ key: answer.name, value: answer.value });

            this.setAnswer({
                text: answer.text,
                value: answerValues
            });
        }

        if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
            this.chatFlowCompelete(answer.action.value);
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(InheritChatFlowQuestionTypes.GOLD_LIST)
    private onGoldListHandler(entity, pageIndex, answer) {
        let next = entity.next;
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({
                text: COMMON_CONSTANTS.SKIP_TEXT,
                value: [],
            });
            next = entity.skip;
            this.store.registerSignalHandler(InheritSignal.RESET_LIST, () => {
                this.store.unregisterSignalHandler(InheritSignal.RESET_LIST);
                this.action.setStateSubmitDataValue({
                    name: 'goldProtectionAccounts',
                    value: this.state.goldProtectionAccounts,
                });
                this.emitMessageRetrivalEvent(next, pageIndex);
            });
            this.action.resetList({
                key: 'goldProtectionAccounts',
                backupKey: 'goldProtectionAccountsBackup'
            });
        } else {
            this.setAnswer({
                text: answer,
                value: [{ key: entity.name, value: answer }],
            });
            let goldProtectionTotalAmount = 0;
            let isModifyFlag = false;
            this.state.goldProtectionAccounts.accounts.forEach((item: any) => {
                if ((item.depositAmount || item.depositAmount === 0) &&
                (item.currentDayConvertingPrice || item.currentDayConvertingPrice === 0)) {
                    item.balance = item.depositAmount * item.currentDayConvertingPrice;
                    goldProtectionTotalAmount = goldProtectionTotalAmount + Number.parseInt(item.balance);
                    isModifyFlag = true;
                }
            });
            this.action.setStateSubmitDataValue({
                name: 'goldProtectionAccounts',
                value: {...this.state.goldProtectionAccounts, amount: goldProtectionTotalAmount, isModifyFlag: isModifyFlag},
            });
            this.emitMessageRetrivalEvent(next, pageIndex);
        }
    }
}
