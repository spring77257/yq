import { Injectable } from '@angular/core';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';

/**
 * `DefaultChatFlowInputHandler`において、取引状況表示画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class InheritInheritanceMethodHandle
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritInheritanceMethodHandle extends DefaultChatFlowInputHandler {
    private state: InheritState;

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private loginStore: LoginStore
    ) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(InheritChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        const { text, value, next } = answer === COMMON_CONSTANTS.SIGN_SKIP ?
            {
                text: COMMON_CONSTANTS.SKIP_TEXT,
                value: [],
                next: entity.skip
            } : {
                text: answer.text,
                value: [{ key: entity.name, value: answer.value}],
                next: answer.next
            };
        this.setAnswer({
            text: text,
            value: value
        });
        this.emitMessageRetrivalEvent(next, pageIndex);
    }
}
