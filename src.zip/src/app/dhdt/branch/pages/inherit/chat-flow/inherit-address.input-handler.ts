import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { COMMON_CONSTANTS, InheritOption } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputUtils } from 'dhdt/branch/pages/inherit/utils/input-utils';
import { InheritContentConfirmComponent } from 'dhdt/branch/pages/inherit/view/inherit-content-confirm.component';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { App, NavController } from 'ionic-angular';

/**
 * 被相続人の住所情報（勘定系CIF取得不可の場合）インプットハンドラーを定義しているクラス。
 *
 * @export
 * @class InheritAddressInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritAddressInputHandler extends DefaultChatFlowInputHandler {
    private readonly INHERIT_CONTENT_CONIRM_COMPONENT = 'InheritContentConfirmComponent';
    private navCtrl: NavController;
    private state: InheritState;

    constructor(
        private action: InheritAction,
        app: App,
        private store: InheritStore,
        private loginStore: LoginStore,
        private labelService: LabelService,
        private modalService: ModalService,
    ) {
        super(action);
        this.navCtrl = app.getActiveNavs()[0];
        this.state = this.store.getState();
    }

    @InputHandler(InheritChatFlowQuestionTypes.BUTTON)
    private onButtonHandler(entity, pageIndex, answer) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.value }
                ]
            });
        }

        if (answer.action.type === InheritChatFlowQuestionTypes.ROUTE) {
            if (answer.action.value === this.INHERIT_CONTENT_CONIRM_COMPONENT) {
                this.navCtrl.setRoot(InheritContentConfirmComponent);
            } else {
                this.chatFlowCompelete(answer.action.value);
            }
        } else if (answer.next !== -1) {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    /**
     * keyboard typeのデフォルトハンドラ。
     *
     * @protected
     * @param {*} entity
     * @param {number} pageIndex
     * @param {*} answer
     * @memberof InheritApplicantInputInputHandler
     */
    @InputHandler(InheritChatFlowQuestionTypes.KEYBOARD)
    private onKeybordHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {

        let maxLenth;
        if (entity.choices && entity.choices.length > 0) {
            maxLenth = InputUtils.calculateMaxLength(entity.choices[0].name,
                this.state.submitData.ancestorAddressStreetNameKanaInput, this.state.submitData.ancestorAddressStreetNameKanaSelect);
        }

        InputUtils.getKanjiToKana(answer.value, maxLenth).subscribe((results) => {
            const needSpace = InputUtils.needAddSpace(answer.value[0].key);
            if (needSpace) {
                const text = answer.value[1].value.length > 0 ? answer.value[0].value + COMMON_CONSTANTS.FULL_SPACE + answer.value[1].value
                    : answer.value[0].value;
                this.setAnswer({ text: text, value: [...results, { key: entity.name, value: text }] });
            } else {
                this.setAnswer({ text: answer.text, value: [...results, { key: entity.name, value: answer.text }] });
            }
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
    }

    @InputHandler(InheritChatFlowQuestionTypes.NUMBER_KEYBORD)
    private onNumberKeyboardHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({ text: this.labelService.labels.common.skipjp, value: [] });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        } else {
            if (entity.option === InheritOption.ANCESTOR_ZIPCODE) {
                this.setAnswer({ text: this.labelService.labels.inherit.basic.zipCodeTag + answer.text, value: answer.value });
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            } else {
                this.setAnswer(answer);
            }
        }
    }

    @InputHandler([
        InheritChatFlowQuestionTypes.PREFECTURE_PICKER,
        InheritChatFlowQuestionTypes.COUNTRY_URBAN_VILLAGE_PICKER,
        InheritChatFlowQuestionTypes.DATE_PICKER
    ])
    private onPickerHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.type !== InheritChatFlowQuestionTypes.DATE_PICKER) {
            const dict = [];
            const value = answer.value as Array<{ key: string, value: string }>;
            value.forEach((item) => {
                const basic = item.key.replace('holder', 'ancestor').replace('Furi', '');
                dict.push({ key: basic, value: item.value });
            });
            answer.value = dict;
        }

        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        } else {
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }

    }

    @InputHandler(InheritChatFlowQuestionTypes.SELECT_ADDRESS)
    private onSelectAddressHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): void {
        const value = answer.value as Array<{ key: string, value: string }>;
        if (value && value.length > 0) {
            const dict = [];
            value.forEach((item) => {
                const basic = item.key.replace('holder', 'ancestor').replace('Furi', '');
                dict.push({ key: basic, value: item.value });
            });
            answer.value = dict;
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        } else {
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        }
    }

    @InputHandler(InheritChatFlowQuestionTypes.SELECT_STREET)
    private onSelectStreetHandler(entity: any, pageIndex: number, result: { isSkip: boolean, text: string, value: any }) {
        const answer = {
            text: result.text,
            value: [
                { key: 'ancestorAddressStreetNameSelect', value: (result.isSkip ? undefined : result.value.streetKanji) },
                { key: 'ancestorAddressStreetNameKanaSelect', value: (result.isSkip ? undefined : result.value.streetKana) }
            ]
        };
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(result.isSkip ? entity.skip : entity.next, pageIndex);
    }
}
