import { Injectable, ViewContainerRef } from '@angular/core';
import { LabelService } from 'adep/services';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { COMMON_CONSTANTS, Constants, InheritRequestType, YesNoAnswer } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritInactiveInputInputHandler } from 'dhdt/branch/pages/inherit/chat-flow/inherit-inactive.input-handler';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { InactiveAccountEntity } from 'dhdt/branch/pages/inherit/entity/inactive-account.entity';
import { TransPresenceEntity } from 'dhdt/branch/pages/inherit/entity/trans-presence.entity';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import { ServerInfoService } from 'dhdt/branch/pages/inherit/services/server-info.service';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { InputUtils } from 'dhdt/branch/pages/inherit/utils/input-utils';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

export const INHERIT_SIMPLIFY_INACTIVE_RENDERER_TYPE = 'InheritInactiveRenderer';

/**
 * `DefaultChatFlowRenderer`において、死亡者情報入力画面Rendererを定義しているクラス。
 *
 * @export
 * @class InheritInactiveRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_SIMPLIFY_INACTIVE_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-inactive.yml'
})
export class InheritInactiveRenderer extends DefaultChatFlowRenderer {
    public processType = -1;
    public savingAction: SavingsAction;
    private state: InheritState;
    private readonly APPLY_BUSI_TYPE = '99';
    private labels: any;
    private readonly KEY_ADD_ABANDONED_ACCOUNT = 'addAbandonedAccount';

    constructor(
        private action: InheritAction,
        private store: InheritStore,
        private loginStore: LoginStore,
        private serverInfoService: ServerInfoService,
        labelService: LabelService,
        inputHandler: InheritInactiveInputInputHandler,
        public errorMessageService: ErrorMessageService
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.labels = labelService.labels;
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * Judgeタイプの自定義。
     *
     * @protected
     * @param {(ChatFlowMessageInterface | number)} next
     * @param {number} pageIndex
     * @memberof ChatFlowRenderer
     */
    @Renderer(InheritChatFlowQuestionTypes.JUDGE, false)
    protected onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        switch (entity.name) {
            case 'existsInputAccount': {
                // 前提：名寄せがあり、不活動口座情報がない場合
                const inputAccountBranchNo = this.state.submitData.ancestorAccountBranchNo;
                const inputAccountsubjectCode = this.state.submitData.ancestorAccountItem;
                const inputAccountNo = this.state.submitData.ancestorAccountNo;
                // 入力された店科口が外貨でない場合、国内預金口座を探索し存在すればtrue
                // 上記でない場合false
                let judgeResult: boolean = false;
                if (inputAccountsubjectCode === InheritConsts.AvailableAccountType.foreignCurrencySavingsForSystem ||
                    inputAccountsubjectCode === InheritConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem) {
                    judgeResult = true;
                } else {
                    if (this.state.domesticLoanAccountInfo) {
                        judgeResult = this.state.domesticLoanAccountInfo.accounts.some((account) =>
                            account.branchCode === inputAccountBranchNo &&
                            account.subjectCode === inputAccountsubjectCode &&
                            account.accountNo === inputAccountNo);
                    } else {
                        judgeResult = false;
                    }
                }
                if (judgeResult === false) {
                    // 手入力口座がない場合（例：融資基本や債券、CLを申告してきた場合）、かつ、取引有無照会の不活動口座情報がない場合はtrueを設定
                    if (StringUtils.isEmpty(this.state.submitData.ancestorAccountItem)) {
                        judgeResult = !(this.state.submitData.inactiveAccount && this.state.submitData.inactiveAccount.length > 0) ?
                            true : false;
                    } else {
                        // 手入力した口座が預金科目の場合（MEJAR前の場合）はfalseを設定
                        judgeResult = false;
                        // 但し、手入力した口座がMEJAR後マイナス残の場合は、国内預金口座Listにないため、trueを設定
                        if (!StringUtils.isEmpty(this.state.accountSearchStatus)
                            && this.state.accountSearchStatus === InheritConsts.Status.ON) {
                            judgeResult = (this.state.ancestorCifInfoInquiry.accountStatus === InheritConsts.InheritAccountStatus.Active
                                && (this.state.ancestorCifInfoInquiry.subjectCode === InheritConsts.AvailableAccountType.current
                                    || this.state.ancestorCifInfoInquiry.subjectCode === InheritConsts.AvailableAccountType.savings)
                                && Number(this.state.ancestorCifInfoInquiry.balance) < 0);
                        }
                    }
                }
                if (InputUtils.afterMejarTenYearsPastFlag(
                    this.state,
                    this.state.submitData)) {
                    judgeResult = true;
                }
                for (const choice of entity.choices) {
                    if (choice.value === judgeResult) {
                        this.action.getNextChatByAnswer(choice.next, pageIndex);
                    }
                }
                break;
            }
            case 'hasInactiveAccountInfo': {
                const choice = entity.choices.find((item) => {
                    return item.value === this.state.submitData[entity.name];
                });
                this.action.getNextChatByAnswer(choice ? choice.next : entity.next, pageIndex);
                break;
            }
            case 'hasCustomerInfo': {
                const judgeResult = Boolean(
                    this.state.submitData.ancestorCustomerId && this.state.submitData.ancestorCustomerId.length > 0);
                for (const choice of entity.choices) {
                    if (choice.value === judgeResult) {
                        this.action.getNextChatByAnswer(choice.next, pageIndex);
                    }
                }
                break;
            }
            case 'hasInputAccount': {
                const judgeResult = Boolean(
                    !StringUtils.isEmpty(this.state.submitData.ancestorAccountBranchNo)
                    && !StringUtils.isEmpty(this.state.submitData.ancestorAccountItem)
                    && !StringUtils.isEmpty(this.state.submitData.ancestorAccountNo)
                    && this.state.submitData.ancestorAccountItem !== InheritConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem
                    && this.state.submitData.ancestorAccountItem !== InheritConsts.AvailableAccountType.foreignCurrencySavingsForSystem);
                for (const choice of entity.choices) {
                    if (choice.value === judgeResult) {
                        this.action.getNextChatByAnswer(choice.next, pageIndex);
                    }
                }
                break;
            }
        }
    }

    /**
     * Send request
     * @param entity entity
     * @param pageIndex pageIndex
     */
    @Renderer(InheritChatFlowQuestionTypes.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        switch (entity.name) {
            // 022-口座残高照会_MEJAR管理外
            case InheritRequestType.INACTIVE_ACCOUNT_LIST: {
                this.getInactiveAccountList(entity, pageIndex);
                break;
            }
        }
    }

    @Renderer(InheritChatFlowQuestionTypes.INACTIVE_ACCOUNT)
    private onAccountList(entity: ChatFlowMessageInterface, pageIndex: number) {
        let existsInputAccountInDomestic: boolean = false;
        let existsInputAccountInInactive: boolean = false;
        const inputAccountBranchCode = this.state.submitData.ancestorAccountBranchNo;
        const inputAccountsubjectCode = this.state.submitData.ancestorAccountItem;
        const inputAccountNo = this.state.submitData.ancestorAccountNo;
        const inputAccountBranchName = this.state.submitData.ancestorAccountBranchName;
        const inputAccountsubjectName = InputUtils.convertSubjectName(this.state.submitData.ancestorAccountItem);
        const inputAncestorNameKana = this.state.submitData.ancestorNameKana;
        const inputAncestorName = this.state.submitData.ancestorName;
        const inputAncestorBirthDate = this.state.submitData.ancestorBirthdate;
        const inputAncestorFirstZipCode = this.state.submitData.ancestorFirstZipCode;
        const inputAncestorLastZipCode = this.state.submitData.ancestorLastZipCode;
        const inputAncestorPrefecture = this.state.submitData.ancestorAddressPrefecture;
        const inputAncestorCountyUrbanVillage = this.state.submitData.ancestorAddressCountyUrbanVillage;
        const inputAncestorStreet = this.state.submitData.ancestorAddressStreetNameSelect ||
            this.state.submitData.ancestorAddressStreetNameInput;
        const inputAncestorSubAddress = this.state.submitData.ancestorAddressHouseNumber;
        const inputAncestorPrefectureKana = this.state.submitData.ancestorAddressPrefectureKana;
        const inputAncestorCountyUrbanVillageKana = this.state.submitData.ancestorAddressCountyUrbanVillageKana;
        const inputAncestorStreetKana = this.state.submitData.ancestorAddressStreetNameKanaSelect ||
            this.state.submitData.ancestorAddressStreetNameKanaInput;
        const inputAncestorSubAddressKana = this.state.submitData.ancestorAddressHouseNumberKana;
        const mejarCustomerStatus = this.state.submitData.mejarCustomerStatus;
        const matchesApplicantAddress = this.state.submitData.matchesApplicantAddress;
        // 入力された店科口の有無を判定
        if (InputUtils.isAncestorAccountFlag(
            this.state.submitData.ancestorAccountBranchNo,
            this.state.submitData.ancestorAccountItem,
            this.state.submitData.ancestorAccountNo)) {
            // 入力された店科口が外貨でない場合下記探索を実施
            if (!(inputAccountsubjectCode === InheritConsts.AvailableAccountType.foreignCurrencySavingsForSystem ||
                inputAccountsubjectCode === InheritConsts.AvailableAccountType.foreignCurrencyFixedDepositForSystem)) {
                // 入力された店科口がMEJAR後済支払後10年経過先でない場合下記探索を実施
                if (!InputUtils.afterMejarTenYearsPastFlag(
                    this.state,
                    this.state.submitData
                )) {
                    if (this.state.submitData.ancestorCustomerId
                        && this.state.submitData.ancestorCustomerId.length > 0) {
                        // 入力された店科口が国内預金口座Listに存在するか探索
                        existsInputAccountInDomestic =
                            this.state.domesticLoanAccountInfo.accounts.some((account) =>
                                account.branchCode === inputAccountBranchCode &&
                                account.subjectCode === inputAccountsubjectCode &&
                                account.accountNo === inputAccountNo);

                        // 入力された店科口がCRM整理済口座List（不活動口座情報List）に存在するか探索-
                        existsInputAccountInInactive = this.state.submitData.inactiveAccount.some((account) =>
                            account.branchCode === inputAccountBranchCode &&
                            account.subjectCode === this.convertInputSubjectCodeToCrmSubjectCode(inputAccountsubjectCode) &&
                            account.accountNo === inputAccountNo);

                        // 入力した店科口がMEJAR後定期証書式（元帳状態：閉鎖済み）の場合、国内預金口座Listに存在するに塗り替える
                        // 入力した店科口がMEJAR後活動中・マイナス残の口座の場合、国内預金口座Listに存在するに塗り替える（マージしないように考慮する）
                        if (!existsInputAccountInDomestic) {
                            if (!StringUtils.isEmpty(this.state.accountSearchStatus)
                                && this.state.accountSearchStatus === InheritConsts.Status.ON) {
                                existsInputAccountInDomestic =
                                    (this.state.ancestorCifInfoInquiry.subjectCode === InheritConsts.AvailableAccountType.fixedDeposit
                                        && this.state.ancestorCifInfoInquiry.accountStatus === InheritConsts.InheritAccountStatus.Closed
                                        && this.state.ancestorCifInfoInquiry.passbookCategory
                                        === InheritConsts.PassbookCategory.certificate) ||
                                    (this.state.ancestorCifInfoInquiry.accountStatus === InheritConsts.InheritAccountStatus.Active
                                        && (this.state.ancestorCifInfoInquiry.subjectCode === InheritConsts.AvailableAccountType.current
                                            || this.state.ancestorCifInfoInquiry.subjectCode === InheritConsts.AvailableAccountType.savings)
                                        && Number(this.state.ancestorCifInfoInquiry.balance) < 0);
                            }
                        }
                    }
                    // いずれにも存在しない場合、顧客番号9999999999で入力された店科口をListに追加
                    if (!existsInputAccountInDomestic && !existsInputAccountInInactive) {
                        if (this.state.submitData.ancestorCustomerId &&
                            this.state.submitData.ancestorCustomerId.length > 0) {
                            const inputAccount = new InactiveAccountEntity();
                            inputAccount.customerId = inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO;
                            inputAccount.branchCode = inputAccountBranchCode;
                            inputAccount.branchName = inputAccountBranchName;
                            inputAccount.subjectCode = this.setInactiveSubjectCode({
                                branchCode: inputAccountBranchCode,
                                subjectCode: inputAccountsubjectCode,
                                accountNo: inputAccountNo
                            });
                            inputAccount.subjectName = inputAccountsubjectName;
                            inputAccount.accountNo = inputAccountNo;
                            inputAccount.accountName = mejarCustomerStatus === InheritConsts.Status.ON ?
                                this.state.submitData.customerInfo.nameKana :
                                this.state.submitData.inactiveAccountSearchStatus === InheritConsts.Status.ON ?
                                    this.state.submitData.inactiveCustomerInfo.kanaName :
                                    null;
                            this.action.setStateSubmitDataValue({
                                name: 'inactiveAccount',
                                value: [...this.state.submitData.inactiveAccount, inputAccount]
                            });
                            // 被相続人情報の設定編集
                            const inputTransPresence = new TransPresenceEntity();
                            inputTransPresence.customerId = mejarCustomerStatus === InheritConsts.Status.ON ?
                                this.state.ancestorCifInfoInquiry.customerId :
                                inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO;
                            inputTransPresence.ancestorNameKana = inputAncestorNameKana;
                            inputTransPresence.ancestorName = inputAncestorName;
                            inputTransPresence.ancestorBirthDate = inputAncestorBirthDate;
                            inputTransPresence.ancestorZipCode = matchesApplicantAddress === YesNoAnswer.YES ?
                                InputUtils.setAncestorZipCode(this.state.submitData) :
                                inputAncestorFirstZipCode + inputAncestorLastZipCode;
                            inputTransPresence.ancestorPrefecture = inputAncestorPrefecture;
                            inputTransPresence.ancestorCountyUrbanVillage = inputAncestorCountyUrbanVillage;
                            inputTransPresence.ancestorStreet = inputAncestorStreet;
                            inputTransPresence.ancestorSubAddress = inputAncestorSubAddress;
                            inputTransPresence.ancestorPrefectureKana = inputAncestorPrefectureKana;
                            inputTransPresence.ancestorCountyUrbanVillageKana = inputAncestorCountyUrbanVillageKana;
                            inputTransPresence.ancestorStreetKana = inputAncestorStreetKana;
                            inputTransPresence.ancestorSubAddressKana = inputAncestorSubAddressKana;
                            inputTransPresence.ancestorAddress = matchesApplicantAddress === YesNoAnswer.YES ?
                                InputUtils.setAncestorAddress(this.state.submitData) : null;
                            inputTransPresence.ancestorAddressKana = matchesApplicantAddress === YesNoAnswer.YES ?
                                InputUtils.setAncestorAddressKana(this.state.submitData) : null;
                            inputTransPresence.representativeCustomerIdFlag = null;
                            inputTransPresence.transType = mejarCustomerStatus === InheritConsts.Status.ON ?
                                InputUtils.setTransType(this.state.submitData) : [];
                            this.action.setStateSubmitDataValue({
                                name: 'transPresenceInfo',
                                value: [...this.state.submitData.transPresenceInfo, inputTransPresence]
                            });
                        } else {
                            const inputAccountList = new Array<InactiveAccountEntity>();
                            const inputTransPresenceList = new Array<TransPresenceEntity>();
                            inputAccountList.push(
                                {
                                    customerId: inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO,
                                    branchName: inputAccountBranchName,
                                    branchCode: inputAccountBranchCode,
                                    subjectCode: this.setInactiveSubjectCode({
                                        branchCode: inputAccountBranchCode,
                                        subjectCode: inputAccountsubjectCode,
                                        accountNo: inputAccountNo
                                    }),
                                    subjectName: inputAccountsubjectName,
                                    accountNo: inputAccountNo,
                                    currencyCode: undefined,
                                    closeAccountDate: null,
                                    accountName: this.state.submitData.inactiveAccountSearchStatus === InheritConsts.Status.ON ?
                                        this.state.submitData.inactiveCustomerInfo.kanaName : null,
                                    balance: null
                                }
                            );
                            this.action.setStateSubmitDataValue({
                                name: 'inactiveAccount',
                                value: inputAccountList
                            });
                            // 被相続人情報の設定編集
                            inputTransPresenceList.push(
                                {
                                    customerId: inputAccountBranchCode + InheritConsts.customerNo.ADDITIONAL_ACCOUNT_CUSTOMER_NO,
                                    ancestorNameKana: inputAncestorNameKana,
                                    ancestorName: inputAncestorName,
                                    ancestorBirthDate: inputAncestorBirthDate,
                                    ancestorZipCode: matchesApplicantAddress === YesNoAnswer.YES ?
                                        InputUtils.setAncestorZipCode(this.state.submitData) :
                                        inputAncestorFirstZipCode + inputAncestorLastZipCode,
                                    ancestorPrefecture: inputAncestorPrefecture,
                                    ancestorCountyUrbanVillage: inputAncestorCountyUrbanVillage,
                                    ancestorStreet: inputAncestorStreet,
                                    ancestorSubAddress: inputAncestorSubAddress,
                                    ancestorPrefectureKana: inputAncestorPrefectureKana,
                                    ancestorCountyUrbanVillageKana: inputAncestorCountyUrbanVillageKana,
                                    ancestorStreetKana: inputAncestorStreetKana,
                                    ancestorSubAddressKana: inputAncestorSubAddressKana,
                                    ancestorAddress: matchesApplicantAddress === YesNoAnswer.YES ?
                                        InputUtils.setAncestorAddress(this.state.submitData) : null,
                                    ancestorAddressKana: matchesApplicantAddress === YesNoAnswer.YES ?
                                        InputUtils.setAncestorAddressKana(this.state.submitData) : null,
                                    representativeCustomerIdFlag: null,
                                    transType: []
                                }
                            );
                            this.action.setStateSubmitDataValue({
                                name: 'transPresenceInfo',
                                value: inputTransPresenceList
                            });
                        }
                    }
                }
            }
        }
        Reflect.defineProperty(this, Constants.INHERIT_ACCOUNTS_PROPERTIES, {
            value: {
                properties: this.labels.inherit.inactiveAccountTable.properties,
                transform: (data, key) => {
                    if (key === 'subjectName') {
                        if (data[key] === null || data[key] === undefined) {
                            const addKey = 'subjectCode';
                            return data[addKey];
                        }
                    }
                    if (key === 'accountName') {
                        if (data[key] === null || data[key] === undefined) {
                            return COMMON_CONSTANTS.FULL_HYPHEN;
                        }
                    }
                    if (key === 'balance') {
                        if (data[key] === null || data[key] === undefined) {
                            return COMMON_CONSTANTS.FULL_HYPHEN;
                        } else {
                            return StringUtils.toCurrency(data[key]);
                        }
                    }
                    return data[key];
                },
                cssClass: 'text-align-max-height-09',
                statistics: {
                    title: this.labels.inherit.inactiveAccountTable.statistics.title,
                    unit: this.labels.inherit.inactiveAccountTable.statistics.unit,
                    calculation: (data) => {
                        let balanceSum: number = 0;
                        let allNullFlg: boolean = true;
                        if (data) {
                            data.forEach((element) => {
                                if (element.balance !== undefined && element.balance !== null) {
                                    allNullFlg = false;
                                }
                                if (!allNullFlg) {
                                    balanceSum += element.balance == null ? 0 : Number(element.balance);
                                }
                            });
                            return allNullFlg ? COMMON_CONSTANTS.FULL_HYPHEN
                                : StringUtils.toCurrency(balanceSum, false);
                        }
                    }
                },
            }
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    private getInactiveAccountList(entity: ChatFlowMessageInterface, pageIndex: number): void {
        // SIGNAL HANDLER設置
        this.store.registerSignalHandler(InheritSignal.GET_INACTIVE_ACCOUNT_LIST, () => {
            this.store.unregisterSignalHandler(InheritSignal.GET_INACTIVE_ACCOUNT_LIST);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
        // API の入力バラメータ設置
        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                // customerId: this.state.submitData.ancestorCustomerId // 顧客番号
                customerId: this.state.submitData.allCustomerId, // 顧客番号
                inheritFlg: InheritConsts.InheritFlg.flagTrue
            }
        };
        this.action.getInactiveAccountList(param);
    }

    private convertInputSubjectCodeToCrmSubjectCode(inputAccountSubjectCode: string) {
        let convertedSubjectCode = inputAccountSubjectCode;
        switch (inputAccountSubjectCode) {
            /** 当座 */
            case InheritConsts.AvailableAccountType.current: {
                convertedSubjectCode = InheritConsts.CrmAccountType.current;
                break;
            }
            /** 普通・貯蓄 */
            case InheritConsts.AvailableAccountType.savings:
            case InheritConsts.AvailableAccountType.deposit: {
                convertedSubjectCode = InheritConsts.CrmAccountType.savings;
                break;
            }
            /** 納準 */
            case InheritConsts.AvailableAccountType.taxPrepare: {
                convertedSubjectCode = InheritConsts.CrmAccountType.taxPrepare;
                break;
            }
            /** 通知 */
            case InheritConsts.AvailableAccountType.notification: {
                convertedSubjectCode = InheritConsts.CrmAccountType.notification;
                break;
            }
            /** 別段 */
            case InheritConsts.AvailableAccountType.separateDeposit: {
                convertedSubjectCode = InheritConsts.CrmAccountType.separateDeposit;
                break;
            }
            /** 定期 */
            case InheritConsts.AvailableAccountType.fixedDeposit: {
                convertedSubjectCode = InheritConsts.CrmAccountType.fixedDeposit;
                break;
            }
            /** 積定 */
            case InheritConsts.AvailableAccountType.installmentDeposit: {
                convertedSubjectCode = InheritConsts.CrmAccountType.installmentDeposit;
                break;
            }
            /** 上記一致しない場合、入力科目を無編集で返す */
            default:
                break;
        }
        return convertedSubjectCode;
    }

    /**
     * apiに送信する不活動口座の科目コードを設定
     * @param inputAccountInfo 入力した口座情報
     * @returns
     */
    private setInactiveSubjectCode(inputAccountInfo: { branchCode: string, subjectCode: string, accountNo: string }): string {
        if (this.state.submitData.inactiveAccountSearchStatus === InheritConsts.Status.ON &&
            (inputAccountInfo.subjectCode === InheritConsts.AvailableAccountType.savings ||
                inputAccountInfo.subjectCode === InheritConsts.AvailableAccountType.deposit)) {
            const margedInactiveAccountInfo = this.state.submitData.inactiveAccountInfo.accountInfo.concat(
                this.state.submitData.inactiveAccountInfo.secondaryAccountInfo);
            const res = InputUtils.ifSavingsOrDepositAccountExists(margedInactiveAccountInfo, inputAccountInfo);
            return res.result ? res.subjectCode : this.convertInputSubjectCodeToCrmSubjectCode(inputAccountInfo.subjectCode);
        } else {
            return this.convertInputSubjectCodeToCrmSubjectCode(inputAccountInfo.subjectCode);
        }
    }
}
