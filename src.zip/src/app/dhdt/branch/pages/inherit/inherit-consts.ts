/**
 * 解約用定数 Constants.
 */
export namespace InheritConsts {

    /**
     * 入力可能な解約口座科目
     */
    export enum AvailableAccountType {
        /** 当座 */
        current = '11',
        /** 普通 */
        savings = '12',
        /** 貯蓄 */
        deposit = '13',
        /** 納税準備 */
        taxPrepare = '14',
        /** 通知 */
        notification = '16',
        /** 別段 */
        separateDeposit = '19',
        /** 定期 */
        fixedDeposit = '20',
        /** 積立定期 */
        installmentDeposit = '26',
        /** 外貨普通（勘定系） */
        foreignCurrencySavingsForSystem = '32',
        /** 外貨定期（勘定系） */
        foreignCurrencyFixedDepositForSystem = '34',
        /** 外貨普通（タブレット用） */
        foreignCurrencySavings = '71',
        /** 外貨定期（タブレット用） */
        foreignCurrencyFixedDeposit = '73',
        /** 融資基本 */
        loan = '41',
        /** 貸越専用CL */
        cardLoan = '48',
        /** 債券 */
        bond = '35',
        /** 普通・貯蓄預金 */
        savingsAndDeposit = '99'
    }

    /**
     * 通貨コード
     */
    export enum CurrencyCode {
        USD = '01',
        EUR = '53',
        STG = '02',
        SFR = '04',
        ADL = '15',
        CNY = '16',
        NZD = '19',
    }

    /**
     * 通貨名
     */
    export enum CurrencyName {
        /** 米ドル */
        USD = '米ドル',
        /** スイス・フラン */
        SFR = 'スイス・フラン',
        /** 中国・元 */
        CNY = '中国・元',
        /** ユーロ */
        EUR = 'ユーロ',
        /** 英・ポンド */
        STG = '英・ポンド',
        /** ニュージランド・ドル */
        NZD = 'ニュージランド・ドル',
        /** オーストラリア・ドル */
        ADL = 'オーストラリア・ドル'
    }

    /**
     * 通貨（英字）
     */
    export enum AlphabetCurrencyName {
        /** 米ドル */
        USD = 'USD',
        /** スイス・フラン */
        SFR = 'SFR',
        /** 中国・元 */
        CNY = 'CNY',
        /** ユーロ */
        EUR = 'EUR',
        /** 英・ポンド */
        STG = 'STG',
        /** ニュージランド・ドル */
        NZD = 'NZD',
        /** オーストラリア・ドル */
        ADL = 'ADL'
    }

    /**
     * 通貨コード
     */
    export enum tabletSubjectName {
        /** 外貨普通 */
        foreignCurrencySavings = '外貨普通預金',
        /** 外貨定期 */
        foreignCurrencyFixedDeposit = '外貨定期預金',
        /** 当座 */
        current = '当座預金',
        /** 普通 */
        savings = '普通預金',
        /** 貯蓄 */
        deposit = '貯蓄預金',
        /** 納税準備 */
        taxPrepare = '納税準備',
        /** 通知 */
        notification = '通知預金',
        /** 別段 */
        separateDeposit = '別段預金',
        /** 定期 */
        fixedDeposit = '定期預金',
        /** 積立定期 */
        installmentDeposit = '積立定期',
        /** 債券 */
        bond = '債券',
        /** 融資基本 */
        loan = '融資基本',
        /** 貸越専用CL */
        cardLoan = '貸越専用カードローン',
        /** 普通・貯蓄預金 */
        savingsAndDeposit = '普通・貯蓄預金',
        /** 活動中の納税準備預金を手入力した場合に科目名を変換 */
        AccountTaxPrepare = '納税準備預金'
    }

    /**
     * 顧客番号
     */
    export enum customerNo {
        /** 入力口座追加時に設定する顧客番号 */
        ADDITIONAL_ACCOUNT_CUSTOMER_NO = '9999999'
    }

    /**
     * CRM整理済口座科目
     */
    export enum CrmAccountType {
        /** 普通・貯蓄 */
        savings = '01',
        /** 積立定期 */
        installmentDeposit = '03',
        /** 定期 */
        fixedDeposit = '04',
        /** 通知 */
        notification = '05',
        /** 別段 */
        separateDeposit = '07',
        /** 納税準備 */
        taxPrepare = '08',
        /** 当座 */
        current = '09'
    }

    /**
     * フラグ表示
     */
    export enum Status {
        ON = '1',
        OFF = '0'
    }

    /**
     * 口座状態
     */
    export enum InheritAccountStatus {
        /** 活動中 */
        Active = '00',
        /** 閉鎖済または解約済 */
        Closed = '01',
        /** 移管済 */
        Transferd = '04',
        /** 雑益繰入済または休眠移管済 */
        Dormant = '05',
        /** 新約取消済 */
        Canceled = '08',
        /** 雑益繰入解約 */
        IncomeCancellation = '51',
        /** 不活動繰入解約 */
        InactiveCancellation = '52'
    }

    /** 受付番号（EQ番号） */
    export enum ReceptionNumber {
        /** 相続解約 */
        SC_INHERIT = '000'
    }

    /**
     * 廃止店
     */
    export enum NotExistingBranchMaster {
        /** 店舗マスタに存在しなかった時の店名 */
        closedBranch = '廃止店'
    }

    /**
     * 相続業務フラグ
     */
    export enum InheritFlg {
        /** 相続業務の場合 */
        flagTrue = '1',
        /** 相続業務の以外（相続人の入金口座入力含め）の場合 */
        flagFalse = '0'
    }

    /**
     * 廃止店一覧
     */
    export enum ClosedBranchList {
        /** 新桜ヶ丘出張所 */
        shinsakuragaokaSubBranch = '329',
        /** 今宿出張所 */
        imajukuSubBranch = '330',
        /** 明神台団地出張所 */
        myoujindaidanchiSubBranch = '336',
        /** 上飯田出張所 */
        kamiiidaSubBranch = '355',
        /** 公田出張所 */
        kudenSubBranch = '357',
        /** ＹＢＰ出張所 */
        ybpSubBranch = '368',
        /** 市大附属病院出張所 */
        shidaifuzokuhospitalSubBranch = '369',
        /** 子安支店 */
        koyasuBranch = '372',
        /** 横浜東口支店 */
        yokohamaEastExitBranch = '376',
        /** 横浜シティ支店 */
        yokohamaCityBranch = '377',
        /** 戸部支店 */
        tobeBranch = '381',
        /** そごう横浜店出張所 */
        sogoyokohamaSubBranch = '383',
        /** 霧が丘出張所 */
        kirigaokaSubBranch = '386',
        /** 南日吉出張所 */
        minamihiyoshiSubBranch = '399',
        /** 六浦出張所 */
        mutsuuraSubBranch = '552',
        /** 野比出張所 */
        nobiSubBranch = '553',
        /** 南が丘出張所 */
        minamigaokaSubBranch = '664',
        /** 中沼代理店 */
        nakanumaSubBranch = '790',
        /** 王禅寺出張所 */
        ouzenjiSubBranch = '836',
        /** 梶が谷出張所 */
        kajigayaSubBranch = '839',
        /** 丸ノ内支店 */
        marunouchiBranch = '901',
        /** 三田支店 */
        mitaBranch = '903',
        /** 五反田支店 */
        gotandaBranch = '905',
        /** 市ケ谷支店 */
        ichigayaBranch = '908',
        /** 新宿新都心支店 */
        shinjukushintoshinBranch = '909',
        /** 八王子出張所 */
        hachioujiSubBranch = '913',
        /** 青山支店 */
        aoyamaBranch = '918',
        /** 東京流通センター支店 */
        tokyoryuutucenterBranch = '919',
        /** 祐天寺駅支店 */
        yuutenjiStationBranch = '924',
        /** 玉川学園出張所 */
        tamagawagakuenSunBranch = '937',
        /** 千葉支店 */
        chibaBranch = '955'
    }

    /**
     * 店舗種類
     */
    export enum BranchType {
        /** 通常店 */
        nomalTypeBranch = '0',
        /** 非勘定店 */
        notAccountBranch = '2',
        /** 喪失店 */
        lossBranch = '3',
        /** 廃止店 */
        closedBranch = '9'
    }

    export enum ReceptionCheckBusinessCode {
        /** 相続（被相続人） */
        ANCESTOR_ACCOUNT = '15'
    }

    /**
     * 被相続人口座情報知るかどうか
     */
    export enum HasAncestorAccount {
        /** 知らない */
        NO = '1'
    }

    /**
     * 通帳証書区分
     */
    export enum PassbookCategory {
        /** 証書 */
        certificate = '2'
    }
}
