import { Injectable, NgZone } from '@angular/core';
import { Action } from 'adep/flux';
import { ReceptionInfoEntity } from 'dhdt/branch/pages/bank-savings-deposit/entity/reception-info.entity';
import {
    API_URL, Constants, HostErrorCodeReceptionNG, HostResultCode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TradingPresenceInquiryRequest } from 'dhdt/branch/pages/common/entity/trading-presence-inquiry-request.entity';
import { InheritChatFlowQuestionTypes } from 'dhdt/branch/pages/inherit/chat-flow/inherit.chat-flow-question-types';
import { DormantDepositInfoRequest } from 'dhdt/branch/pages/terminate/entity/dornant-deposit-info-request.entity';
import { InactiveAccountInfoInquiryRequest } from 'dhdt/branch/pages/terminate/entity/inactive-account-info-inquiry-request.entity';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { ChatFlowActionInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-action.interface';
import { HostErrorService } from 'dhdt/branch/shared/services/host-error.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { HttpService, HttpStatus } from 'dhdt/branch/shared/services/http.service';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export namespace InheritActionType {
    export const GET_SAVING_QUESTION_TEMPLATE: string = 'InheritActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const NEXT_CHAT: string = 'InheritActionType_NEXT_CHAT';
    export const CLEAR: string = 'InheritActionType_LOAD_TEMPLATE_CLEAR';
    export const CLEAR_SHOW_CHATS: string = 'InheritActionType_CLEAR_SHOW_CHATS';
    export const STATE_BACKUP: string = 'InheritActionType_STATE_BACKUP';
    export const RESET_STATE: string = 'InheritActionType_RESET_STATE';
    export const BRANCH_STATUS_UPDATE: string = 'InheritActionType_BRANCH_STATUS_UPDATE';
    export const SET_CUSTOMER_APPLY_START_DATE: string = 'InheritActionType_SET_CUSTOMER_APPLY_START_DATE';
    export const SET_ANSWER: string = 'InheritActionType_SET_ANSWER';
    export const EDIT_CHAT: string = 'InheritActionType_EDIT_CHAT';
    export const SET_STATE_SUBMIT_DATA_VALUE: string = 'InheritActionType_SET_STATE_SUBMIT_DATA_VALUE';
    export const SUBMIT_DATA_BACKUP: string = 'InheritActionType_SUBMIT_DATA_BACKUP';
    export const SUBMIT_DATA_RESTORE: string = 'InheritActionType_SUBMIT_DATA_RESTORE';
    export const RETRIEVE_DROP_LIST: string = 'InheritActionType_RETRIEVE_DROP_LIST';
    export const BRANCH_INFO_INSERT: string = 'InheritActionType_BRANCH_INFO_INSERT';
    export const CHAT_FLOW_COMPELETE = 'InheritACTIONTYPE_CHAT_FLOW_COMPELETE';
    export const CHAT_FLOW_RETURN = 'InheritACTIONTYPE_CHAT_FLOW_RETURN';
    export const RESET_LAST_NODE = 'InheritACTIONTYPE_RESET_LAST_NODE';
    export const GO_BACK_RELATE_HAS_ACCOUNT_CHAT = 'InheritACTIONTYPE_GO_BACK_RELATE_HAS_ACCOUNT_CHAT';
    export const GO_BACK_TO_RELATE_CHAT = 'InheritACTIONTYPE_GO_BACK_TO_RELATE_CHAT';
    export const GET_BRANCH_INFO_BY_ADDR = 'GET_BRANCH_INFO_BY_ADDR';
    export const SET_CUSTOMER_APPLY_END_DATE: string = 'InheritActionType_SET_CUSTOMER_APPLY_END_DATE';
    export const SET_BANKCLERK_CONFIRM_START_DATE: string = 'SET_BANKCLERK_CONFIRM_START_DATE';
    export const GET_CONFIRM_PAGE_TEMPLATE: string = 'GET_CONFIRM_PAGE_TEMPLATE';
    export const SET_SWIPE_INFO: string = 'InheritActionType_SET_SWIPE_INFO';
    export const GET_ACCOUNT_EXISTING = 'InheritActionType_GET_ACCOUNT_EXISTING';
    export const GET_ACCOUNT_EXISTING_PAYMENT = 'InheritActionType_GET_ACCOUNT_EXISTING_PAYMENT';
    export const SET_CIF_INFORMATION = 'InheritActionType_SET_CIF_INFORMATION';
    export const SET_SIMPLE_CIF_INFORMATION = 'InheritActionType_SET_SIMPLE_CIF_INFORMATION';
    export const GET_ACCOUNT_INFO_WITH_CIF = 'InheritActionType_ACCOUNT_INFO_WITH_CIF';
    export const GET_ACCOUNT_INFO_WITHOUT_CIF = 'InheritActionType_ACCOUNT_INFO_WITHOUT_CIF';
    export const GET_BROKERAGE_ACCOUNT_LIST = 'InheritActionType_GET_BROKERAGE_ACCOUNT_LIST';
    export const ADD_BROKERAGE_ACCOUNT = 'InheritActionType_ADD_BROKERAGE_ACCOUNT';
    export const GET_SIMPLIFY_TRADE_STATUS = 'InheritActionType_GET_SIMPLIFY_TRADE_STATUS';
    export const SIMPLIFY_DETERMINATION = 'InheritActionType_SIMPLIFY_DETERMINATION';
    export const SET_SIMPLIFY_FLAG = 'InheritActionType_SET_SIMPLIFY_FLAG';
    export const SET_DEFAULT_ANCESTOR_ACCOUNT_NAME = 'InheritActionType_SET_DEFAULT_ANCESTOR_ACCOUNT_NAME';
    export const SET_PAYMENT_ACCOUNT_INPUT_STATUS = 'InheritActionType_SET_PAYMENT_ACCOUNT_INPUT_STATUS_FLAG';
    export const CLEAR_PAYMENT_ACCOUNT_INFO = 'InheritActionType_CLEAR_PAYMENT_ACCOUNT_INFO';
    export const GET_ZIP_CODE = 'InheritActionType_GET_ZIP_CODE';
    export const GET_IDENTITYDOCUMENT_INFO = 'InheritActionType_GET_IDENTITYDOCUMENT_INFO';
    export const SET_PAYMENT_ACCOUNT_INFO = 'InheritActionType_SET_PAYMENT_ACCOUNT_INFO';
    export const SET_BANKCLERK_ID = 'InheritActionType_SET_BANKCLERK_ID';
    export const SET_AGENCY_BRANCH_INFO = 'InheritActionType_SET_AGENCY_BRANCH_INFO';
    export const INHERIT_INFO_UPDATE = 'InheritActionType_INHERIT_INFO_UPDATE';
    export const SET_BANKCLERK_CONFIRM_DATE = 'InheritActionType_SET_BANKCLERK_CONFIRM_DATE';
    export const CLEAR_SIMPLE_INFO = 'InheritActionType_CLEAR_SIMPLE_INFO';
    export const ADD_ABANDONE_ACCOUNT_INFO = 'InheritActionType_ADD_ABANDONE_ACCOUNT_INFO';
    export const SET_ABANDONE_ACCOUNT_INFO = 'InheritActionType_SET_ABANDONE_ACCOUNT_INFO';
    export const AFTER_EDIT_DELETE_ACCOUNT_INFO = 'InheritActionType_AFTER_EDIT_DELETE_ACCOUNT_INFO';
    export const CLEAR_HEIR_INFO = 'InheritActionType_CLEAR_HEIR_INFO';
    export const SET_INPUTCONTENT_CONFIRMATION_DATE = 'InheritActionType_SET_INPUTCONTENT_CONFIRMATION_DATE';
    export const SET_PROCEDUREGUIDE_COMPLETE_DATE = 'InheritActionType_SET_PROCEDUREGUIDE_COMPLETE_DATE';
    export const GET_CHANGE_BIRTHDAY_DATA = 'InheritActionType_GET_CHANGE_BIRTHDAY_DATA';
    export const GET_CHANGE_DEATH_DATA = 'InheritActionType_GET_CHANGE_DEATH_DATA';
    export const GET_CHANGE_APPLICANT_BIRTHDATE = 'InheritActionType_GET_CHANGE_APPLICANT_BIRTHDATE';
    export const SAVE_HEIR_INFO = 'InheritActionType_SAVE_HEIR_INFO';
    export const SORT_ANCESTOR_ACCOUNT_LIST = 'INHERITACTIONTYPE_SORT_ANCESTOR_ACCOUNT_LIST';
    export const GET_BRANCH_NAME_BY_BRANCHNO = 'INHERITACTIONTYPE_GET_BRANCH_NAME_BY_BRANCHNO';
    export const CLEAR_RESPRESENTATIVE_HEIR_ADDRESS = 'InheritSignal_CLEAR_RESPRESENTATIVE_HEIR_ADDRESS';
    export const CLEAR_REPRESENTATIVE_HEIR_NAME = 'InheritActionType_CLEAR_REPRESENTATIVE_HEIR_NAME';
    export const CLEAR_REPRESENTATIVE_HEIR_KANA = 'InheritActionType_CLEAR_REPRESENTATIVE_HEIR_KANA';
    export const SORT_RELATIONSHIP_LIST = 'InheritActionType_RELATIONSHIP_LIST';
    export const CLEAR_MOBILE_PHONE_INFO = 'InheritActionType_CLEAR_MOBILE_PHONE_INFO';
    export const CLEAR_TELEPHONE_INFO = 'InheritActionType_CLEAR_TELEPHONE_INFO';
    export const CLEAR_ANCESTOR_ACCOUNT_INFO = 'InheritActionType_CLEAR_ANCESTOR_ACCOUNT_INFO';
    export const CLEAR_RESPRESENTATIVE_HEIR_MOBILE_PHONE_INFO = 'InheritActionType_CLEAR_RESPRESENTATIVE_HEIR_MOBILE_PHONE_INFO';
    export const CLEAR_RESPRESENTATIVE_HEIR_TELEPHONE_INFO = 'InheritActionType_CLEAR_RESPRESENTATIVE_HEIR_TELEPHONE_INFO';
    export const CLEAR_ADDRESS_INFO = 'InheritActionType_CLEAR_ADDRESS_INFO';
    export const CLOSE_PAYMENT_CHATS = 'InheritActionType_CLOSE_PAYMENT_CHATS';
    export const SET_STATE_VALUE = 'InheritActionType_SET_STATE_VALUE';
    export const GET_INACTIVE_ACCOUNT_LIST = 'InheritActionType_GET_INACTIVE_ACCOUNT_LIST';
    export const RESET_INACTIVE_ACCOUNT_LIST = 'InheritActionType_RESET_INACTIVE_ACCOUNT_LIST';
    export const ADD_INACTIVE_ACCOUNT_INFO = 'InheritActionType_ADD_INACTIVE_ACCOUNT_INFO';
    export const SET_INACTIVE_ACCOUNT_INFO = 'InheritActionType_SET_INACTIVE_ACCOUNT_INFO';
    export const SET_ACCOUNT_BALANCE = 'InheritActionType_SET_ACCOUNT_BALANCE';
    export const SET_ACCOUNT_NO = 'InheritActionType_SET_ACCOUNT_NO';
    export const NEED_INPUT_PHONE_NO = 'SavingsActionType_NEED_INPUT_PHONE_NO';
    export const ACCOUNTS_BALANCE_INQUIRY = 'AccountsBalanceInquiry_ACCOUNTS_BALANCE_INQUIRY';
    export const RESET_LIST = 'RESET_LIST';
    export const SIMPLIFIED_JUDGMENT_CHECK = 'InheritActionType_SIMPLIFIED_JUDGMENT_CHECK';
    export const INHERIT_INFO_REGISTER = 'InheritActionType_INHERIT_INFO_REGISTER';
    export const POPTO_VIEW = 'InheritActionType_POPTO_VIEW';
    export const RECEPTION_CHECK = 'RECEPTION_CHECK';
    export const RESET_PAYMENT_SELECT = 'InheritACTIONTYPE_RESET_PAYMENT_SELECT';
    export const CLEAR_RECEPTION_BRANCH_INFO = 'InheritACTIONTYPE_CLEAR_RECEPTION_BRANCH_INFO';
    export const RESET_CHAT = 'InheritACTIONTYPE_RESET_CHAT';
    export const GO_BACK_RECEPTION_SHOP_ENTRY_CHAT = 'InheritACTIONTYPE_GO_BACK_RECEPTION_SHOP_ENTRY_CHAT';
    export const GET_BRANCH_NAME_BY_INPUT_BRANCHNO = 'INHERITACTIONTYPE_GET_BRANCH_NAME_BY_INPUT_BRANCHNO';
    export const INACTIVE_ACCOUNT_INFO_INQUIRY = 'InheritActionType_INACTIVE_ACCOUNT_INFO_INQUIRY';
    export const GET_CUSTOMER_INFO = 'InheritActionType_GET_CUSTOMER_INFO';
    export const GET_CUSTOMER_INFO_NG = 'InheritActionType_GET_CUSTOMER_INFO_NG';
    export const CLEAR_ANCESTOR_ADDRESS_INFO = 'InheritActionType_CLEAR_ANCESTOR_ADDRESS_INFO';
    export const UNACCEPTABLES_NG = 'InheritActionType_UNACCEPTABLES_NG';
    export const INHERIT_RECEPTION_CHECK = 'InheritActionType_INHERIT_RECEPTION_CHECK';
    export const RESTORE_STATE_WITH_BACKUPDATA = 'InheritActionType_RESTORE_STATE_WITH_BACKUPDATA';
    export const SET_ANCESTOR_ADDRESS_CHANGED = 'InheritActionType_SET_ANCESTOR_ADDRESS_CHANGED';
    export const GET_HOLDER_ZIP_CODE = 'InheritActionType_GET_HOLDER_ZIP_CODE';
    export const BEFORE_MEJAR_DEATH_CHECK = 'InheritActionType_BEFORE_MEJAR_DEATH_CHECK';
    export const DORMANT_INDEX_INFO_CHECK = 'InheritActionType_DORMANT_INDEX_INFO_CHECK';

    // キーのバックアップと戻る
    export const KEYS_ARY_BACKUP = 'InheritActionType_KEYS_ARY_BACKUP';
    export const KEYS_ARY_ROLLBACK = 'InheritActionType_KEYS_ARY_ROLLBACK';
}

// 口座照会結果
export enum InheritAccountInquiryResult {
    Success = '0',
    Fail = '1',
}

@Injectable()
export class InheritAction extends Action implements ChatFlowActionInterface {
    constructor(
        private httpService: HttpService,
        private hostErrorService: HostErrorService,
        private ngZone: NgZone,
    ) {
        super();
    }

    public needInputPhoenNo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.NEED_INPUT_PHONE_NO,
        });
    }

    /**
     * チャットテンプレートをロードする
     * @param file yamlファイル名
     * @param pageIndex ページインデックス
     */
    public loadTemplate(file: string, pageIndex: number) {
        this.httpService.get('/chatflow/definition/' + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos
                }
            });
        });
    }

    /**
     * タブレット申し込み情報にデータを更新する
     * @param params タブレット申し込み情報
     */
    public branchStatusUpdate(params: any) {
        this.httpService.post('/tabletInfo/update', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.BRANCH_STATUS_UPDATE,
                data: response.result
            });
        });
    }

    /**
     * 次のステップを取得する
     * @param order オーダー
     * @param pageIndex ページインデックス
     */
    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    /**
     * 回答を編集する。
     *
     * @param {number} order
     * @param {number} pageIndex
     * @memberof ChatFlowActionInterface
     */
    public editAnswer(order: number, pageIndex: number, answerOrder: number, showChatIndex?: number) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.EDIT_CHAT,
            data: {
                order: order, pageIndex: pageIndex, answerOrder: answerOrder, showChatIndex: showChatIndex
            }
        });
    }

    /**
     * ユーザからの回答をStateに保存する。
     *
     * @param {{ text: string, value: Array<{ key: string, value: string }> }} answer
     * @memberof ChatFlowActionInterface
     */
    public setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_ANSWER,
            data: answer
        });
    }

    /**
     * ChatFlowを完了させる。
     *
     * @param {string} nextChatName
     * @memberof ChatFlowActionInterface
     */
    public chatFlowCompelete(nextChatName: string) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CHAT_FLOW_COMPELETE,
            data: nextChatName
        });
    }

    public gobackToRelateChat(index: number) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.GO_BACK_TO_RELATE_CHAT,
            data: index
        });
    }

    public gobackReceptionShopEntryChat() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.GO_BACK_RECEPTION_SHOP_ENTRY_CHAT
        });
    }

    /**
     * 現在のChatFlowの最後のMessageを初期化する。
     *
     * @memberof ChatFlowActionInterface
     */
    public resetLastNode() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.RESET_LAST_NODE
        });
    }

    /**
     * チャットをリセットする
     * @param index チャットのorder
     */
    public resetChat(index: number) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.RESET_CHAT,
            data: index
        });
    }

    /**
     * ストアをクリアする
     */
    public clearStore() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR
        });
    }

    /**
     * チャットの表示内容をクリアする
     */
    public clearShowChats() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_SHOW_CHATS
        });
    }

    public stateBackupInProcess(process) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.STATE_BACKUP,
            data: process
        });
    }

    public resetStateToProcess(process) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.RESET_STATE,
            data: process
        });
    }

    /**
     * 顧客申し込み開始時間を設定する
     */
    public setCustomerApplyStartDate() {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.SET_CUSTOMER_APPLY_START_DATE,
                data: {
                    systemTime: response.result.value
                }
            });
        });
    }

    /**
     * 顧客申し込み完了時間を設定する
     */
    public setCustomerApplyEndDate() {
        this.setSystemTime(InheritActionType.SET_CUSTOMER_APPLY_END_DATE);
    }

    /**
     * 行員認証開始時間を設定する
     */
    public setBankclerkAuthenticationStartDate() {
        this.setSystemTime(InheritActionType.SET_BANKCLERK_CONFIRM_START_DATE);
    }

    /**
     * 行員認証時間を設定する
     */
    public setBankclerkAuthenticationEndDate() {
        this.setSystemTime(InheritActionType.SET_BANKCLERK_CONFIRM_DATE);
    }

    /**
     * 入力内容確認完了時間を設定する
     */
    public setInputContentConfirmationDate() {
        this.setSystemTime(InheritActionType.SET_INPUTCONTENT_CONFIRMATION_DATE);
    }

    /**
     * 手続き案内完了時間を設定する
     */
    public setProcedureGuideCompleteDate() {
        this.setSystemTime(InheritActionType.SET_PROCEDUREGUIDE_COMPLETE_DATE);
    }

    /**
     * サブミットデータに値を設定する
     *
     * @param param 項目値
     */
    public setStateSubmitDataValue(param: any) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_STATE_SUBMIT_DATA_VALUE,
            data: param
        });
    }

    /**
     * コードマスタの情報を取得する
     *
     * @param params
     */
    public retrieveDropList(params: any) {
        this.httpService.get('/categoryCodes/retrieve', params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.RETRIEVE_DROP_LIST,
                data: response.result
            });
        });
    }
    /**
     * 修正用テンプレートをロードする
     * @param params パラメーター
     */
    public loadConfirmPageTemplate(file: string, pageIndex: number) {

        this.httpService.get('/chatflow/definition/' + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_CONFIRM_PAGE_TEMPLATE,
                data: { data: response.result.questions, pageIndex: pageIndex }
            });
        });
    }

    /**
     * 行員認証情報をサブミットする
     *
     * @param params データ
     */
    public saveSubmitData(params: any) {
        this.httpService.post('/branchInfo/tabletInfo/bankclerk-confirm-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.BRANCH_INFO_INSERT,
                data: response.result
            });
        });
    }

    /**
     * 相続情報インサートAPI呼び出し。
     * @param params リクエストパラメータ
     */
    public inheritInfoInsert(params: any) {
        this.httpService.post(API_URL.INHERIT_INFO_REGISTER, params, {}, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.INHERIT_INFO_REGISTER,
                data: response.result
            });
        });
    }

    /**
     * 回答中のChatFlowのデータのバックアップを行う。
     */
    public submitDataBackup() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SUBMIT_DATA_BACKUP
        });
    }

    /**
     * バックアップの回答中のChatFlowのデータを復元する。
     */
    public submitDataRestore() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SUBMIT_DATA_RESTORE
        });
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param params QRコード受付情報
     */
    public setSwipeInfo(params: ReceptionInfoEntity) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_SWIPE_INFO,
            data: params
        });
    }

    /**
     * 画面遷移
     * @param view 遷移先
     */
    public popToView(view) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.POPTO_VIEW,
            data: view
        });
    }

    /**
     * 口座開設店番を取得して記録する
     * @param {string} prefectureKanji
     * @param {string} countyUrbanVillageKanji
     * @param {string} streetKanji
     */
    public getBranchInfoByAddr(prefectureKanji, countyUrbanVillageKanji, streetKanji: string) {
        const params = {
            prefectureKanji: prefectureKanji,
            countyUrbanVillageKanji: countyUrbanVillageKanji,
            streetKanji: streetKanji
        };

        this.httpService.get('/belong-to-branch-no/searchbyaddr', { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_BRANCH_INFO_BY_ADDR,
                data: {
                    belongToBranchNo: response.result.belongToBranchNo,
                    branchNameKanji: response.result.branchNameKanji
                }
            });
        });
    }

    /**
     * 口座存在チェック
     * @param params 口座存在チェック用パラメータ
     */
    public checkAccountExisting(params: any) {
        this.httpService.post(API_URL.CB_CHECK_ACCOUNT_INFO, params, null, SpinnerType.SHOW_TRANSPARENT, true).subscribe((response) => {
            if (response.status === HttpStatus.SUCCESS) {
                this.dispatcher.dispatch({
                    actionType: InheritActionType.GET_ACCOUNT_EXISTING,
                    data: {
                        result: response.result,
                        hasAncestorAccountExist: true,
                    }
                });
            } else if (response.status === HttpStatus.HOST_ERROR) {
                if (response.errors.data && response.errors.data.resultCode === HostResultCode.SUPPORT
                    && response.errors.data.errorCode === HostErrorCodeReceptionNG.B_STR_005) {
                    // 人格コードエラーの場合
                    this.dispatcher.dispatch({
                        actionType: InheritActionType.UNACCEPTABLES_NG,
                        data: response
                    });
                    return;
                } else {
                    this.hostErrorService.push({
                        resultCode: response.errors.data.resultCode,
                        errorCode: response.errors.data.errorCode,
                        message: response.errors.message,
                        handel: () => {
                            this.chatFlowReturn(InheritChatFlowQuestionTypes.ANCESTOR_ACCOUNT_INFO);
                            this.clearAncestorAccountInfo();
                        }
                    });
                }
            } else {
                this.ngZone.runTask(() => {
                    throw new HttpStatusError(API_URL.CB_CHECK_ACCOUNT_INFO, response.status, response.errors);
                });
            }
        });
    }

    /**
     * 内部API: 不活動口座照会
     */
    public inactiveAccountInfoInquiry(params: InactiveAccountInfoInquiryRequest) {
        this.httpService.post(API_URL.INACTIVE_ACCOUNT_INFO_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.INACTIVE_ACCOUNT_INFO_INQUIRY,
                data: response.result
            });
        });
    }

    /**
     * 内部API: CIF情報照会（入力した店科口・MEJAR前の場合）
     */
    public getCustomerInfo(params: any) {
        this.httpService.post(API_URL.CB_CIF_INFOS_INQUIRY, params, null, SpinnerType.SHOW, true).
            subscribe((response: any) => {
                if (response instanceof HttpStatusError) {
                    // エラー発生時
                    if (response.errors && response.errors.data) {
                        this.dispatcher.dispatch({
                            actionType: InheritActionType.GET_CUSTOMER_INFO_NG,
                            data: response
                        });
                        return;
                    } else {
                        // 上記以外のエラーの場合、共通エラーハンドリング処理にて処理する
                        this.ngZone.runTask(() => {
                            throw response;
                        });
                        return;
                    }
                }

                this.dispatcher.dispatch({
                    actionType: InheritActionType.GET_CUSTOMER_INFO,
                    data: response.result
                });
            });
    }

    /**
     * 21入金画面_口座存在チェック
     * @param params 口座存在チェック用パラメータ
     */
    public checkAccountExistingPayment(params: any) {
        this.httpService.post(API_URL.CB_CHECK_ACCOUNT_INFO, params, null, SpinnerType.SHOW_TRANSPARENT, true).subscribe((response) => {
            if (response.status === HttpStatus.SUCCESS) {
                this.dispatcher.dispatch({
                    actionType: InheritActionType.GET_ACCOUNT_EXISTING_PAYMENT,
                    data: {
                        result: response.result
                    }
                });
            } else if (response.status === HttpStatus.HOST_ERROR) {
                this.hostErrorService.push({
                    resultCode: response.errors.data.resultCode,
                    errorCode: response.errors.data.errorCode,
                    message: response.errors.message,
                    handel: () => {
                        this.resetPaymentSelect();
                    }
                });
            }
        });
    }

    /**
     * CIF情報照会
     * @param params CIF情報照会用パラメータ
     */
    public getCifInformation(cifParams: SimpleCifInfoInquiryInterface, inputParams: any) {
        this.httpService.post(API_URL.CB_GET_CIF_INFORMATION, cifParams).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.SET_CIF_INFORMATION,
                data: { data: response.result, inputParams: inputParams }
            });
        });
    }

    /**
     * CIF情報照会
     * @param params CIF情報照会用パラメータ
     */
    public getSimpleCifInformation(cifParams: SimpleCifInfoInquiryInterface, inputParams: any) {
        this.httpService.post(API_URL.CB_GET_SIMPLE_CIF_INFORMATION, cifParams).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.SET_SIMPLE_CIF_INFORMATION,
                data: { data: response.result, inputParams: inputParams }
            });
        });
    }

    /**
     * get holderZipCode 郵便番号
     * @param ancestorAddressPrefecture 都道府県
     * @param ancestorAddressCountyUrbanVillage 市区町村
     * @param ancestorAddressStreetNameSelect 町丁名
     */
    public getHolderZipCode(prefectureKanji: string, countyUrbanVillageKanji: string, streetKanji: string) {
        const params = {
            prefectureKanji: prefectureKanji,
            countyUrbanVillageKanji: countyUrbanVillageKanji,
            streetKanji: streetKanji
        };
        this.httpService.get(API_URL.ADDRESS_ZIP_CODE_SEARCH, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_HOLDER_ZIP_CODE,
                data: response.result.zipCode
            });
        }
        );
    }

    /**
     * お亡くなりになった方の口座を取得する
     *
     * @param params
     */
    public getAccountInfoWithoutCif(params: any) {
        // TL01-R-API016_口座残高照会_預金
        this.httpService.post(API_URL.DOMESTIC_LOAN_ACCOUNTS_BALANCE, params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_ACCOUNT_INFO_WITHOUT_CIF,
                data: { result: response.result, params: params }
            });
        });
    }

    /**
     * 口座残高照会_預金
     */
    public domesticLoanAccountsBalanceInquiry(entity, data: { tabletApplyId, params: { receptionTenban, customerId, inheritFlg } }) {
        this.httpService.post(API_URL.DOMESTIC_LOAN_ACCOUNTS_BALANCE, data, null, SpinnerType.SHOW).pipe(
            map((res) => {
                const {
                    domesticLoanAccountTotalAmount,
                    domesticLoanAccountInfo,
                    tmpDomesticAccountInfo,
                    domesticAccountSearchStatus
                } = res.result;

                return {
                    result: domesticLoanAccountInfo && domesticLoanAccountInfo.length > 0
                        ? InheritAccountInquiryResult.Success
                        : InheritAccountInquiryResult.Fail,
                    data: {
                        key: entity.name,
                        value: {
                            amount: domesticLoanAccountTotalAmount,
                            accounts: domesticLoanAccountInfo,
                            other: tmpDomesticAccountInfo,
                            status: domesticAccountSearchStatus,
                        }
                    }
                };
            })
        ).subscribe((res) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.ACCOUNTS_BALANCE_INQUIRY,
                data: res
            });
        });
    }

    /**
     * 口座残高照会_外貨預金
     */
    public forexAccountsBalanceInquiry(entity, data: { tabletApplyId, params: { receptionTenban, customerId, inheritFlg } }) {
        this.httpService.post(API_URL.FOREX_ACCOUNTS_BALANCE, data, null, SpinnerType.SHOW).pipe(
            map((res) => {
                const {
                    forexAccountTotalAmount,
                    forexAccountSearchStatus,
                    cancelAccountFlag,
                    forexAccountInfo,
                    tmpForexAccountInfo,
                } = res.result;

                return {
                    result: forexAccountInfo && forexAccountInfo.length > 0
                        ? InheritAccountInquiryResult.Success
                        : InheritAccountInquiryResult.Fail,
                    data: {
                        key: entity.name,
                        value: {
                            amount: forexAccountTotalAmount,
                            accounts: forexAccountInfo,
                            other: tmpForexAccountInfo,
                            status: forexAccountSearchStatus,
                            flg: cancelAccountFlag,
                        }
                    }
                };
            })
        ).subscribe((res) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.ACCOUNTS_BALANCE_INQUIRY,
                data: res
            });
        });
    }

    /**
     * 口座残高照会_投資信託
     */
    public investmentTrustAccountsBalanceInquiry(entity, data: { tabletApplyId, params: { receptionTenban, customerId, inheritFlg } }) {
        this.httpService.post(API_URL.INVESTMENT_TRUST_ACCOUNTS_BALANCE, data, null, SpinnerType.SHOW).pipe(
            map((res) => {
                const { investmentTrustTotalAmount, investmentTrustInfo } = res.result;

                return {
                    result: investmentTrustInfo && investmentTrustInfo.length > 0
                        ? InheritAccountInquiryResult.Success
                        : InheritAccountInquiryResult.Fail,
                    data: {
                        key: entity.name,
                        value: {
                            amount: investmentTrustTotalAmount,
                            accounts: investmentTrustInfo
                        }
                    }
                };
            })
        ).subscribe((res) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.ACCOUNTS_BALANCE_INQUIRY,
                data: res
            });
        });
    }

    /**
     * 口座残高照会_公共債
     */
    public bondAccountsBalanceInquiry(entity, data: { tabletApplyId, params: { receptionTenban, customerId, inheritFlg } }) {
        this.httpService.post(API_URL.BOND_ACCOUNTS_BALANCE, data, null, SpinnerType.SHOW).pipe(
            map((res) => {
                const {
                    bondAccountTotalAmount,
                    bondAccountSearchStatus,
                    bondAccountInfo,
                    tmpBondAccountInfo,
                } = res.result;

                return {
                    result: bondAccountInfo && bondAccountInfo.length > 0
                        ? InheritAccountInquiryResult.Success
                        : InheritAccountInquiryResult.Fail,
                    data: {
                        key: entity.name,
                        value: {
                            amount: bondAccountTotalAmount,
                            accounts: bondAccountInfo,
                            other: tmpBondAccountInfo,
                            status: bondAccountSearchStatus,
                        }
                    }
                };
            })
        ).subscribe((res) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.ACCOUNTS_BALANCE_INQUIRY,
                data: res
            });
        });
    }

    /**
     * バンクカード一覧を初期化する。
     */
    public resetList(params: { key: string; backupKey: string }) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.RESET_LIST,
            data: params
        });
    }

    /**
     * 口座残高照会_バンクカード
     */
    public bankCardAccountsBalanceInquiry(entity, data: { tabletApplyId, params: { receptionTenban, customerId, inheritFlg } }) {
        this.httpService.post(API_URL.BANK_CARD_ACCOUNTS_BALANCE, data, null, SpinnerType.SHOW).pipe(
            map((res) => {
                const {
                    bankCardSearchStatus,
                    bankCardInfo,
                    loanAccountInfo,
                } = res.result;

                let bankCardTotalAmount = 0;
                if (bankCardInfo && bankCardInfo.length > 0) {
                    bankCardInfo.forEach((element) => {
                        // 初期表示の金額の表示
                        bankCardTotalAmount = bankCardTotalAmount + (Number.parseInt(element.cashingBalance));
                    });
                }

                return {
                    result: bankCardInfo && bankCardInfo.length > 0
                        ? InheritAccountInquiryResult.Success
                        : InheritAccountInquiryResult.Fail,
                    data: {
                        key: entity.name,
                        value: {
                            amount: bankCardTotalAmount,
                            accounts: bankCardInfo,
                            other: loanAccountInfo,
                            status: bankCardSearchStatus,
                        }
                    }
                };
            })
        ).subscribe((res) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.ACCOUNTS_BALANCE_INQUIRY,
                data: res
            });
        });
    }

    /**
     * 口座残高照会_金保護預かり残高一覧画面
     */
    public goldProtectionAccountsBalanceInquiry(entity, data: { tabletApplyId, params: { receptionTenban, customerId, inheritFlg } }) {
        this.httpService.post(API_URL.INACTIVE_ACCOUNTS_BALANCE, data, null, SpinnerType.SHOW).pipe(
            map((res) => {
                const { goldProtectionAccounts } = res.result;

                return {
                    result: goldProtectionAccounts && goldProtectionAccounts.length > 0
                        ? InheritAccountInquiryResult.Success
                        : InheritAccountInquiryResult.Fail,
                    data: {
                        key: entity.name,
                        value: {
                            accounts: goldProtectionAccounts
                        }
                    }
                };
            })
        ).subscribe((res) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.ACCOUNTS_BALANCE_INQUIRY,
                data: res
            });
        });
    }

    /**
     * お亡くなりになった方の口座を追加する
     *
     * @param params
     */
    public getAccountInfoWithCif(params: any) {
        this.httpService.post(API_URL.CB_ANCESTOR_ACCOUNT_INFO_CIF_INQUIRY, params, null, null, true).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_ACCOUNT_INFO_WITH_CIF,
                data: { result: response.result, params: params }
            });
        });
    }

    /**
     * 不動口座を追加する
     *
     * @param params 店番号、科目、口座番号、固定番号
     */
    public addAbandonedAccountInfo(params: {
        branchNo: string, accountItem: string, accountNo: string, detailNo: string, branchName: string
    }) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.ADD_ABANDONE_ACCOUNT_INFO,
            data: params
        });
    }

    /**
     * お亡くなりになった方の証券口座を取得する
     *
     * @param params
     */
    public getBrokerageAccountList(params: any) {
        this.httpService.post(API_URL.CB_SECURITY_ACCOUNT_LIST_INQUIRY, params, null, null, true).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_BROKERAGE_ACCOUNT_LIST,
                data: response.result
            });
        });
    }

    /**
     * お亡くなりになった方の証券口座を追加する
     *
     * @param params
     */
    public addBrokerageAccount(params: any) {
        this.httpService.post(API_URL.CB_SECURITY_ACCOUNT_ADD, params, null, null, true).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.ADD_BROKERAGE_ACCOUNT,
                data: response.result
            });
        });
    }

    /**
     * 該当取引を取得する
     *
     * @param params
     */
    public getSimplifyTradeStatus() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.GET_SIMPLIFY_TRADE_STATUS,
        });
    }

    /**
     * 簡素化判定
     */
    public simplifiedJudgmentCheck(params) {
        this.httpService.post(API_URL.SIMPLIFIED_JUDGMENT_CHECK, params).subscribe((response) => {
            const { simplifiedJudgment, simplifiedJudgmentBaseAmount } = response.result;
            this.dispatcher.dispatch({
                actionType: InheritActionType.SIMPLIFIED_JUDGMENT_CHECK,
                data: { simplifiedJudgment, simplifiedJudgmentBaseAmount }
            });
        });
    }

    /**
     * 簡素化判定
     */
    public simplifyDetermination() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SIMPLIFY_DETERMINATION,
        });
    }

    /**
     * 簡素化判定状態を設定する
     *
     * @param simplifyFlag
     */
    public setSimplifyFlag(simplifyFlag: boolean) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_SIMPLIFY_FLAG,
            data: simplifyFlag
        });
    }

    /**
     * 被相続人口座名義を設定する
     *
     * @param params
     */
    public setDefaultAncestorAccountName() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_DEFAULT_ANCESTOR_ACCOUNT_NAME,
        });
    }

    /**
     * 入金口座情報を設定する
     */
    public setPaymentAccountInfo(params: any) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_PAYMENT_ACCOUNT_INFO,
            data: params
        });
    }

    /**
     * 入金口座入力状態を設定する
     *
     * @param params
     */
    public setPaymentAccountInputStatus(status: boolean) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_PAYMENT_ACCOUNT_INPUT_STATUS,
            data: status
        });
    }

    /**
     * 入金口座情報をクリアする
     */
    public clearPaymentAccountInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_PAYMENT_ACCOUNT_INFO
        });
    }

    /**
     * get ZipCode 郵便番号
     * @param prefectureKanji 住所・都道府県
     * @param countyUrbanVillageKanji 住所・市区町村
     * @param streetKanji 住所・町丁名
     */
    public getZipCode(prefectureKanji: string, countyUrbanVillageKanji: string, streetKanji: string) {
        const params = {
            prefectureKanji: prefectureKanji,
            countyUrbanVillageKanji: countyUrbanVillageKanji,
            streetKanji: streetKanji
        };
        this.httpService.get(API_URL.ADDRESS_ZIPCODE_SEARCH, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_ZIP_CODE,
                data: response.result.zipCode
            });
        });
    }

    /**
     * アップロードイメージ情報を加工する
     * @param params
     */
    public processUploadedImagesData(params: any) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.GET_IDENTITYDOCUMENT_INFO,
            data: params
        });
    }

    /**
     * 行員登録画面に遷移するとき、入力する行員IDを記録する
     * @param bankclerkId 行員ID
     */
    public setBankclerkId(bankclerkId: string) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_BANKCLERK_ID,
            data: { bankclerkId: bankclerkId }
        });
    }

    /**
     * 取次店番を記録する
     * @param branchNo 店番号
     */
    public setAgencyBranchInfo(branchNo: string) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_AGENCY_BRANCH_INFO,
            data: { branchNo: branchNo }
        });
    }

    /**
     * 相続情報をDBに保存。
     *
     * @param params
     */
    public updateInheritInfo(params: any) {
        this.httpService.post(API_URL.INHERIT_INFO_UPDATE_URL, params, {}, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.INHERIT_INFO_UPDATE,
                data: response.result
            });
        });
    }

    /**
     * 簡素化判定情報をクリアする
     */
    public clearSimpleInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_SIMPLE_INFO
        });
    }

    /**
     * 相続人確認をクリアする
     */
    public clearHeirInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_HEIR_INFO
        });
    }

    /**
     * お亡くなりになった方の情報-お亡くなりになった日
     * @param params お亡くなりになった方の情報-お亡くなりになった日用パラメータ
     */
    public getChangeDeathDate(params: any) {
        this.httpService.get(API_URL.INHERIT_INFO_CONVERTDATE_URL, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_CHANGE_DEATH_DATA,
                data: response.result
            });
        });
    }

    /**
     * 相続体表と来店者と同じの場合、相続人代表に来店者の情報をコピーする
     */
    public saveHeirInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SAVE_HEIR_INFO
        });
    }

    /**
     * 口座残高一覧をソートします
     *
     * ①店番 昇順
     * ②科目 昇順
     * ③口座番号 昇順
     * ④固有番号・証番 昇順
     */
    public sortAncestorAccountList() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SORT_ANCESTOR_ACCOUNT_LIST
        });
    }

    /**
     * 店番より店名取得。
     * @param param 店番
     */
    public getBranchNameByBranchNo(params: any) {
        this.httpService.get(API_URL.BRANCH_NAME, params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_BRANCH_NAME_BY_BRANCHNO,
                data: response.result
            });
        });
    }

    /**
     * 入力した店科口の店番より店名取得。
     * @param param 店番
     */
    public getBranchNameByInputBranchNo(params: any) {
        this.httpService.get(API_URL.BRANCH_NAME, params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_BRANCH_NAME_BY_INPUT_BRANCHNO,
                data: response.result
            });
        });
    }

    /**
     * 被相続人ー口座ー店名、科目名を取得
     * @param params 店番、科目
     */
    public getAncestorAccountInfoName(params: { branchNo, accountItem }): Observable<{ branchName, accountName }> {
        return Observable.forkJoin(
            this.httpService.get(API_URL.BRANCH_NAME, { params: { branchCode: params.branchNo } })
                .pipe(
                    map((res) => res.result),
                    // 店名取得
                    map((res) => res ? { branchName: res.branchName } : undefined)
                ),
            this.httpService.get(API_URL.CATEGORY_CODES_RETRIEVE, { params: { categoryCode: Constants.SUBJECT_CODE } })
                .pipe(
                    map((res) => res.result),
                    // 汎用コードの中に、科目を探す
                    map((res) => res ? res.find((item) => item.codeValue === params.accountItem) : undefined),
                    // 科目名取得
                    map((res) => res ? { accountName: res.data } : undefined)
                )
        ).pipe(
            map((res: any[]) => {
                // { branchName: xxx, accountName: xxx } のようなobjectを返却
                return res.reduce((previous, current) => previous = { ...previous, ...current }, {});
            })
        );
    }

    /**
     * 相続代表者住所情報をクリアする
     */
    public clearRepresentHeirAddress() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_RESPRESENTATIVE_HEIR_ADDRESS
        });
    }

    /*
     * 相続人代表の氏名情報をクリア。
     */
    public clearRepresentativeHeirName() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_REPRESENTATIVE_HEIR_NAME,
        });
    }

    /*
     * 相続人代表のカナ情報をクリア。
     */
    public clearRepresentativeHeirKana() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_REPRESENTATIVE_HEIR_KANA,
        });
    }

    /**
     * 相続代表者電話番号情報をクリアする
     */
    public clearRepresentativeHeirMobilePhoneInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_RESPRESENTATIVE_HEIR_MOBILE_PHONE_INFO
        });
    }

    /**
     * 相続代表者さま情報-ご自宅電話番号をクリアする
     */
    public clearRepresentativeHeirTelephoneInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_RESPRESENTATIVE_HEIR_TELEPHONE_INFO
        });
    }

    /*
     * 来店者さま情報-携帯電話番号をクリアする
     */
    public clearMobilePhoneInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_MOBILE_PHONE_INFO
        });
    }

    /*
     * 来店者さま情報-ご自宅電話番号をクリアする
     */
    public clearTelephoneInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_TELEPHONE_INFO
        });
    }

    /*
     * 来店者さま情報-取引店の店番号・店名・店舗種類・科目・口座番号をクリアする
     */
    public clearAncestorAccountInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_ANCESTOR_ACCOUNT_INFO
        });
    }

    /*
     * 受付票起票店の店番号・店名・店舗種類をクリアする
     */
    public clearReceptionBranchInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_RECEPTION_BRANCH_INFO
        });
    }

    /**
     * 来店者さま情報-住所をクリアする
     */
    public clearAddressInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_ADDRESS_INFO
        });
    }

    /**
     * 被相続人-住所情報をクリアする
     */
    public clearAncestorAddressInfo() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLEAR_ANCESTOR_ADDRESS_INFO
        });
    }

    /**
     * 会話を閉じる
     */
    public closeChats() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CLOSE_PAYMENT_CHATS
        });
    }

    /**
     * State値を設定
     * @param params key value
     */
    public setStateValue(params: { key, value }) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_STATE_VALUE,
            data: params
        });
    }

    /**
     * 022-MEJAR管理外
     * @param params MEJAR管理外パラメータ
     */
    public getInactiveAccountList(params: any) {
        this.httpService.post(API_URL.INACTIVE_ACCOUNTS_BALANCE, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.GET_INACTIVE_ACCOUNT_LIST,
                data: response.result
            });
        });
    }

    /**
     * 初期化する。
     */
    public resetInheritAccountList() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.RESET_INACTIVE_ACCOUNT_LIST
        });
    }

    /**
     * 口座の情報を更新
     * @param params 顧客入力情報
     */
    public setAccountNo(params: any[]) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_ACCOUNT_NO,
            data: params
        });
    }

    /**
     * 受付可否チェック
     * @param params 受付可否チェックパラメータ
     */
    public receptionCheck(params: any) {
        this.httpService.post(API_URL.RECEPTION_CHECK, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.RECEPTION_CHECK,
                data: response.result
            });
        });
    }

    /**
     * 業務受付可否チェック（MEJAR前口座・勘定系CIF取得可の場合）
     * @param params 受付可否チェックパラメータ
     */
    public beforeMejarReceptionCheck(params: any) {
        this.httpService.post(API_URL.RECEPTION_CHECK, params, null, SpinnerType.SHOW, true).
            subscribe((response: any) => {
                // エラー発生時
                if (response instanceof HttpStatusError) {
                    // 事故取引禁止注意コードエラーの場合
                    if (response.errors && response.errors.data) {
                        this.dispatcher.dispatch({
                            actionType: InheritActionType.UNACCEPTABLES_NG,
                            data: response
                        });
                        return;
                    } else {
                        // 上記以外のエラーの場合、共通エラーハンドリング処理にて処理する
                        this.ngZone.runTask(() => {
                            throw response;
                        });
                        return;
                    }
                }

                // 次の業務に移動する
                this.dispatcher.dispatch({
                    actionType: InheritActionType.INHERIT_RECEPTION_CHECK,
                    data: response.result
                });
            });
    }

    /**
     * 本人死亡登録有無チェック（MEJAR前口座・勘定系CIF取得可の場合）
     * @param params 受付可否チェックパラメータ
     */
    public beforeMejarDeathCheck(params: any) {
        this.httpService.post(API_URL.TRADING_PRESENCE_INQUIRY, params, undefined, SpinnerType.SHOW, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.TRADING_PRESENCE_INQUIRY, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: InheritActionType.BEFORE_MEJAR_DEATH_CHECK,
                        data: {
                            data: response instanceof HttpStatusError ? response.errors.data : response.result
                        }
                    });
                }
            }
        );
    }

    /**
     * 内部API: 睡眠・休眠情報照会
     * @param params
     */
    public dormantIndexInfoCheck(params: DormantDepositInfoRequest) {
        this.httpService.post(API_URL.DORMANT_DEPOSIT_INFO_INQIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: InheritActionType.DORMANT_INDEX_INFO_CHECK,
                data: response.result
            });
        });
    }

    /**
     * 入金口座情報入力 お取引店選択チャットに戻る
     */
    public resetPaymentSelect() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.RESET_PAYMENT_SELECT,
        });
    }

    /**
     * keysAryをバックアップ
     */
    public keysAryBackup() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.KEYS_ARY_BACKUP
        });
    }

    /**
     * keysAryを戻す
     */
    public keysAryRollback() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.KEYS_ARY_ROLLBACK
        });
    }

    /**
     * 指定するチャットに戻る
     * @param nextChatName チャット名
     * @param options
     */
    public chatFlowReturn(nextChatName: string) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.CHAT_FLOW_RETURN,
            data: {
                name: nextChatName
            }
        });
    }

    /**
     * state配下に格納した情報を復元
     * @param backupData バックアップしたデータ
     */
    public restoreStateWithBackupData(backupData: any) {
        this.dispatcher.dispatch({
            actionType: InheritActionType.RESTORE_STATE_WITH_BACKUPDATA,
            data: backupData
        });
    }

    /**
     * 被相続人住所修正ありをstateに格納
     */
    public setAncestorAddressChanged() {
        this.dispatcher.dispatch({
            actionType: InheritActionType.SET_ANCESTOR_ADDRESS_CHANGED
        });
    }

    private setSystemTime(inheritActionType: string) {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: inheritActionType,
                data: {
                    systemTime: response.result.value
                }
            });
        });
    }
}
