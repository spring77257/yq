import { Injectable } from '@angular/core';
import { DeviceService } from 'dhd/common/services/device.service';
import { CoreBankingConst } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InheritAction } from 'dhdt/branch/pages/inherit/action/inherit.action';
import { InheritSignal, InheritState, InheritStore } from 'dhdt/branch/pages/inherit/store/inherit.store';
import { AddressAction } from 'dhdt/branch/shared/components/address/action/address.action';
import { AddressSignal, AddressState, AddressStore } from 'dhdt/branch/shared/components/address/store/address.store';
import { Observable } from 'rxjs';

namespace REQUEST_TYPE {
    export const GET_AGENT_ADDRESS_FROM_ZIPCODE = 'getApplicantAddressFromZipcode';
    export const GET_AGENT_STREET_INITIALS_KANA = 'getApplicantStreetInitialsKana';
    export const GET_ACCOUNT_LIST = 'getAccountList';
    export const GET_SECURITY_ACCOUNT_LIST = 'getSecurityAccountList';
    export const GET_SIMPLIFY_TRADE_STATUS = 'getSimplifyTradeStatus';
    export const GET_REPRESENTATIVE_HEIR_ADDRESS_FROM_ZIPCODE = 'getRepresentativeHeirAddressFromZipcode';
    export const GET_REPRESENTATIVE_HEIR_STREET_INITIALS_KANA = 'getRepresentativeHeirStreetInitialsKana';
    export const SIMPLIFY_DETERMINATION = 'simplifyDetermination';
    export const GET_AGENT_ANCESTOR_ADDRESS_FROM_ZIPCODE = 'getAncestorAddressFromZipcode';
    export const GET_AGENT_ANCESTOR_STREET_INITIALS_KANA = 'getAncestorStreetInitialsKana';
}

namespace RESPONSE_TYPE {
    export const HAS_VALUES = '0';
    export const EMPTY = '1';
}

/**
 * サーバー情報取得サービス
 */
@Injectable()
export class ServerInfoService {
    private addressState: AddressState;
    private inheritState: InheritState;
    constructor(
        private addressAction: AddressAction, private addressStore: AddressStore,
        private inheritAction: InheritAction, private inheritStore: InheritStore,
        private loginStore: LoginStore,
        private deviceService: DeviceService
    ) {
        this.addressState = this.addressStore.getState();
        this.inheritState = this.inheritStore.getState();
    }

    /**
     * タイプによって、サーバー情報を取得する
     *
     * @param {string} type
     */
    public getInfoFormServe(type: string, processNo?): Observable<string> {
        switch (type) {
            case REQUEST_TYPE.GET_AGENT_ADDRESS_FROM_ZIPCODE:
                return this.getAddressFromPostnumber(this.inheritState.submitData.getApplicantZipCode());
            case REQUEST_TYPE.GET_AGENT_STREET_INITIALS_KANA:
                return this.getStreetInitialsKana(
                    this.inheritState.submitData.applicantAddressPrefecture,
                    this.inheritState.submitData.applicantAddressCountyUrbanVillage
                );
            case REQUEST_TYPE.GET_ACCOUNT_LIST: {
                const params = {
                    tabletApplyId: this.inheritState.submitData.tabletApplyId,
                    userMngNo: this.inheritState.submitData.userMngNo,
                    bankNo: CoreBankingConst.bankNo,
                    receptionTenban: this.inheritState.submitData.receptionBranchNo,
                    receptionNo: this.inheritState.submitData.receptionNo,
                    terminalNo: this.deviceService.getDeviceId(),
                    cifInfoInquiryResponseBeanList: this.inheritState.cifInfoInquiryResponseList,
                    wholeCif: this.inheritState.wholeCif
                };

                return this.getAccountList(
                    processNo
                        ? {
                            tabletApplyId: this.inheritState.submitData.tabletApplyId,
                            userMngNo: this.inheritState.submitData.userMngNo,
                            bankNo: CoreBankingConst.bankNo,
                            receptionTenban: this.inheritState.submitData.receptionBranchNo,
                            receptionNo: this.inheritState.submitData.receptionNo,
                            terminalNo: this.deviceService.getDeviceId(),
                            cifInfoInquiryResponseBeanList: this.inheritState.cifInfoInquiryResponseList,
                            wholeCif: this.inheritState.wholeCif,
                            processNo
                        }
                        : params
                );
            }
            case REQUEST_TYPE.GET_SECURITY_ACCOUNT_LIST: {
                const params = {
                    tabletApplyId: this.inheritState.submitData.tabletApplyId,
                    userMngNo: this.inheritState.submitData.userMngNo,
                    bankNo: CoreBankingConst.bankNo,
                    receptionTenban: this.inheritState.submitData.receptionBranchNo,
                    receptionNo: this.inheritState.submitData.receptionNo,
                    terminalNo: this.deviceService.getDeviceId(),
                    ancestorAccountInfoList: this.inheritState.submitData.branchCifList
                };
                return this.getSecurityAccountList(
                    processNo
                        ? {
                            tabletApplyId: this.inheritState.submitData.tabletApplyId,
                            userMngNo: this.inheritState.submitData.userMngNo,
                            bankNo: CoreBankingConst.bankNo,
                            receptionTenban: this.inheritState.submitData.receptionBranchNo,
                            receptionNo: this.inheritState.submitData.receptionNo,
                            terminalNo: this.deviceService.getDeviceId(),
                            ancestorAccountInfoList: this.inheritState.submitData.branchCifList,
                            processNo
                        }
                        : params
                );
            }
            case REQUEST_TYPE.GET_SIMPLIFY_TRADE_STATUS:
                return this.getSimplifyTradeStatus();
            case REQUEST_TYPE.GET_REPRESENTATIVE_HEIR_ADDRESS_FROM_ZIPCODE:
                return this.getAddressFromPostnumber(
                    this.inheritState.submitData.representativeHeirFirstZipCode +
                    this.inheritState.submitData.representativeHeirLastZipCode
                );
            case REQUEST_TYPE.GET_REPRESENTATIVE_HEIR_STREET_INITIALS_KANA:
                return this.getStreetInitialsKana(
                    this.inheritState.submitData.representativeHeirAddressPrefecture,
                    this.inheritState.submitData.representativeHeirAddressCountyUrbanVillage
                );
            case REQUEST_TYPE.SIMPLIFY_DETERMINATION:
                return this.simplifyDetermination();
            case REQUEST_TYPE.GET_AGENT_ANCESTOR_ADDRESS_FROM_ZIPCODE:
                return this.getAddressFromPostnumber(this.inheritState.submitData.getAncestorZipCode());
            case REQUEST_TYPE.GET_AGENT_ANCESTOR_STREET_INITIALS_KANA:
                return this.getStreetInitialsKana(
                    this.inheritState.submitData.ancestorAddressPrefecture,
                    this.inheritState.submitData.ancestorAddressCountyUrbanVillage
                );
            default:
                return undefined;
        }
    }

    /**
     * 郵便番号によって、漢字住所所得する
     *
     * @param {string} zipCode
     */
    private getAddressFromPostnumber(zipCode: string): Observable<string> {
        const result = new Observable<string>((subscriber) => {
            const params = {
                zipCode: zipCode
            };
            this.addressAction.getAddressFromPostnumber({ params: params });
            this.addressStore.registerSignalHandler(AddressSignal.ADDRESS_COMPLETE, () => {
                subscriber.next(this.addressState.addressEntities.length > 1 ? RESPONSE_TYPE.HAS_VALUES : RESPONSE_TYPE.EMPTY);
                this.addressStore.unregisterSignalHandler(AddressSignal.ADDRESS_COMPLETE);
            });
        });
        return result;
    }

    /**
     * 選択した都道府県、市区町村に該当する町丁名の先頭１文字取得する
     *
     * @param {string} prefectureKanji
     * @param {string} countyUrbanVillageKanji
     */
    private getStreetInitialsKana(prefectureKanji: string, countyUrbanVillageKanji: string): Observable<string> {
        const result = new Observable<string>((subscriber) => {
            const params = {
                prefectureKanji: prefectureKanji,
                countyUrbanVillageKanji: countyUrbanVillageKanji
            };
            this.addressAction.getStreetInitialsKana({ params: params });

            this.addressStore.registerSignalHandler(AddressSignal.STREET_KANA_COMPLETE, () => {
                subscriber.next(this.addressState.streetKanaArr.length > 0 ? RESPONSE_TYPE.HAS_VALUES : RESPONSE_TYPE.EMPTY);
                this.addressStore.unregisterSignalHandler(AddressSignal.STREET_KANA_COMPLETE);
            });
        });
        return result;
    }

    /**
     * お亡くなりになった方の口座を取得する
     */
    private getAccountList(params: any) {
        const result = new Observable<string>((subscriber) => {

            this.inheritStore.registerSignalHandler(InheritSignal.GET_ACCOUNT_INFO_WITHOUT_CIF_COMPLETE, () => {
                const domesticLoanAccountInfo = this.inheritState.submitData.domesticLoanAccountInfo;
                subscriber.next(
                    domesticLoanAccountInfo && domesticLoanAccountInfo.length > 0 ? RESPONSE_TYPE.HAS_VALUES : RESPONSE_TYPE.EMPTY,
                );
                this.inheritStore.unregisterSignalHandler(InheritSignal.GET_ACCOUNT_INFO_WITHOUT_CIF_COMPLETE);
            });

        });
        return result;
    }

    /**
     * お亡くなりになった方の証券口座を取得する
     */
    private getSecurityAccountList(params) {
        const result = new Observable<string>((subscriber) => {
            if (this.inheritState.submitData.ancestorBrokerageAccountList) {
                subscriber.next(
                    this.inheritState.submitData.ancestorBrokerageAccountList.length > 0 ? RESPONSE_TYPE.HAS_VALUES : RESPONSE_TYPE.EMPTY
                );
                return;
            }

            if (!this.inheritState.submitData.branchCifList || this.inheritState.submitData.branchCifList.length <= 0) {
                subscriber.next(RESPONSE_TYPE.EMPTY);
                return;
            }

            this.inheritStore.registerSignalHandler(InheritSignal.GET_BROKERAGE_ACCOUNT_LIST_COMPLETE, () => {
                subscriber.next(
                    this.inheritState.submitData.ancestorBrokerageAccountList.length > 0 ? RESPONSE_TYPE.HAS_VALUES : RESPONSE_TYPE.EMPTY
                );
                this.inheritStore.unregisterSignalHandler(InheritSignal.GET_BROKERAGE_ACCOUNT_LIST_COMPLETE);
            });
            this.inheritAction.getBrokerageAccountList(params);
        });
        return result;
    }

    /**
     * 該当取引を取得する
     */
    private getSimplifyTradeStatus() {
        const result = new Observable<string>((subscriber) => {
            this.inheritStore.registerSignalHandler(InheritSignal.GET_SIMPLIFY_TRADE_STATUS_COMPLETE, (data) => {
                subscriber.next(this.inheritState.submitData.judgeCanSimplifyImplementation);
                this.inheritStore.unregisterSignalHandler(InheritSignal.GET_SIMPLIFY_TRADE_STATUS_COMPLETE);
            });
            this.inheritAction.getSimplifyTradeStatus();
        });
        return result;
    }

    /**
     * 簡素化判定
     */
    private simplifyDetermination() {
        const result = new Observable<string>((subscriber) => {
            this.inheritStore.registerSignalHandler(InheritSignal.SIMPLIFY_DETERMINATION_COMPLETE, () => {
                subscriber.next(this.inheritState.submitData.simplificationDecisionResultAuto);
                this.inheritStore.unregisterSignalHandler(InheritSignal.SIMPLIFY_DETERMINATION_COMPLETE);
            });
            this.inheritAction.simplifyDetermination();
        });
        return result;
    }
}
