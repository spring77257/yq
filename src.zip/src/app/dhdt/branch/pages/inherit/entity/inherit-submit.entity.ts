import { JsonProperty } from 'adep/json';
import { AccountEntity } from 'dhdt/branch/pages/inherit/entity/account.entity';
import { AncestorDuplicateCustomerId } from 'dhdt/branch/pages/inherit/entity/ancestor-duplicate-account.entity';
import { BranchCifEntity } from 'dhdt/branch/pages/inherit/entity/branch-cif.entity';
import { BrokerageAccountEntity } from 'dhdt/branch/pages/inherit/entity/brokerage-account.entity';
import { DormantDepositInfo } from 'dhdt/branch/pages/terminate/entity/dornant-deposit-info-response.entity';
import { InactiveAccountEntity } from 'dhdt/branch/pages/inherit/entity/inactive-account.entity';
import { RelationshipInfoEntity } from 'dhdt/branch/pages/inherit/entity/relationship-info.entity';
import { TransPresenceEntity } from 'dhdt/branch/pages/inherit/entity/trans-presence.entity';
import { CustomerInfo } from 'dhdt/branch/pages/terminate/entity/account-status-info-inquiry-response.entity';
import {
    InactiveAccountInfo, InactiveCustomerInfo
} from 'dhdt/branch/pages/terminate/entity/inactive-account-info-inquiry-response.entity';

export class InheritSubmitEntity {
    @JsonProperty({ clazz: InactiveAccountEntity })
    public inactiveAccount: InactiveAccountEntity[];     // 休眠口座番入力情報
    @JsonProperty({ clazz: TransPresenceEntity })
    public transPresenceInfo: TransPresenceEntity[];         // 取引有無情報

    public hasEntryAncestorAccountInfo: boolean;             // 店番・科目・口座番入力あり・なし
    public hasAncestorAccountExist: boolean;                 // 店番・科目・口座番号存在あり・なし
    public applicantName: string;                           // 来店者ー氏名
    public applicantNameKana: string;                       // 来店者ー氏名（フリガナ）
    public applicantFirstName: string;                      // 来店者ー姓
    public applicantLastName: string;                       // 来店者ー名
    public applicantFirstNameKana: string;                  // 来店者ー姓（フリガナ）
    public applicantLastNameKana: string;                   // 来店者ー名（フリガナ）
    public applicantNameNonConvert: string;                 // 来店者ー姓名漢字表示する
    public applicantGender: string;                         // 来店者ー性別
    public applicantBirthdate: string;                      // 来店者ー生（設立）年月日（西暦）
    public applicantBirthdateText: string;                  // 来店者ー生年月日（和暦）
    public applicantFirstZipCode: string;                   // 来店者ー郵便番号・前３位
    public applicantLastZipCode: string;                    // 来店者ー郵便番号・後４位
    public applicantZipCode: string;                        // 来店者ー郵便番号
    public applicantAddressPrefecture: string;              // 来店者ー住所・都道府県
    public applicantAddressPrefectureKana: string;      // 来店者ー住所・都道府県（フリカナ）
    public applicantAddressCountyUrbanVillage: string;      // 来店者ー住所・市区町村
    public applicantAddressCountyUrbanVillageKana: string; // 来店者ー住所・市区町村（フリカナ）
    public applicantAddressStreetNameSelect: string;        // 来店者ー住所・町丁名（選択）
    public applicantAddressStreetNameInput: string;         // 来店者ー住所・町丁名（入力）
    public applicantAddressStreetNameKanaSelect: string; //  来店者ー住所・町丁名（フリカナ）（選択）
    public applicantAddressStreetNameKanaInput: string; // 来店者ー住所・町丁名（フリカナ）（入力）
    public applicantAddressHouseNumber: string;             // 来店者ー住所・番地以降
    public applicantAddressHouseNumberKana: string;     // 来店者ー住所・番地以降（フリカナ）
    public applicantMobileNoFirst: string;                  // 来店者ー携帯電話番号・一部
    public applicantMobileNoSecond: string;                 // 来店者ー携帯電話番号・二部
    public applicantMobileNoThird: string;                  // 来店者ー携帯電話番号・三部
    public applicantMobileNo: string;                       // 来店者ー携帯電話番号
    public applicantTelFirst: string;                       // 来店者ー固定電話番号・一部
    public applicantTelSecond: string;                      // 来店者ー固定電話番号・二部
    public applicantTelThird: string;                       // 来店者ー固定電話番号・三部
    public applicantTelephoneNo: string;                    // 来店者ー固定電話番号
    public applicantCareer: string;                         // 来店者ー職業
    public applicantCareerOtherDetail: string;              // 来店者ー職業・その他詳細
    public applicantWorkPlace: string;                      // 来店者ー勤め先名称
    public applicantIdentityDocument: number;               // 来店者ー本人確認書類
    public applicantRelationship: string;                   // 来店者ー被相続人との関係（コード）
    public applicantRelationshipText: string;               // 来店者ー被相続人との関係（文言）
    public applicantRelationshipDetail: string;             // 来店者ー被相続人との関係・その他詳細
    public withoutHeirSupportingDocument: string;       // 来店者ー相続人証明書類なし
    public applicantCardAuthentication: string = '0';         // 来店者ーカード暗証認証あり
    public files: any[];                           // 来店者ー書類情報を加工
    public isKnowAddress: string;
    public ancestorName: string;                          // 被相続人ー氏名
    public ancestorNameKana: string;                      // 被相続人ー氏名（フリガナ）
    public ancestorFirstName: string;                     // 被相続人ー姓
    public ancestorLastName: string;                      // 被相続人ー名
    public ancestorFirstNameKana: string;                 // 被相続人ー姓（フリガナ）
    public ancestorLastNameKana: string;                  // 被相続人ー名（フリガナ）
    public ancestorGender: string;                        // 被相続人ー性別
    public ancestorDeathDate: string;                     // 被相続人ー死亡年月日（西暦）
    public ancestorDeathDateText: string;                 // 被相続人ー死亡年月日（和暦）
    public dateOfDeathStart: string;                      // 被相続人ー死亡期間開始日
    public dateOfDeathStartText: string;                  // 被相続人ー死亡期間開始日
    public dateOfDeath: string;                           // 被相続人ー死亡期間終了日
    public dateOfDeathText: string;                       // 被相続人ー死亡期間終了日
    public ancestorAccountBranchName: string;             // 被相続人ー口座-店名
    public ancestorAccountBranchType: string;             // 被相続人ー口座-店舗種類
    public ancestorAccountBranchNo: string;               // 被相続人ー口座-店番
    public ancestorAccountItem: string;                   // 被相続人ー口座-科目
    public ancestorAccountNo: string;                     // 被相続人ー口座-口座番号
    public selectCurrencyCode: string;                    // 被相続人ー口座-通貨コード
    public ancestorBranchCif: string;                     // 被相続人ー店別CIF
    public ancestorAccountName: string;                   // 被相続人ー口座-名義
    public ancestorAccountFirstName: string;              // 被相続人ー口座-名義ー姓（フリガナ）
    public ancestorAccountLastName: string;               // 被相続人ー口座-名義ー名（フリガナ）
    public ancestorBirthdate: string;                     // 被相続人ー生年月日（西暦）
    public ancestorBirthdateText: string;                 // 被相続人ー生年月日（和暦）
    public ancestorFirstZipCode: string;                  // 被相続人ー郵便番号・前３位
    public ancestorLastZipCode: string;                   // 被相続人ー郵便番号・後４位
    public ancestorZipCode: string;                       // 被相続人ー郵便番号
    public ancestorAddressPrefecture: string;             // 被相続人ー住所・都道府県
    public ancestorAddressPrefectureKana: string;         // 被相続人ー住所・都道府県（フリカナ）
    public ancestorAddressCountyUrbanVillage: string;     // 被相続人ー住所・市区町村
    public ancestorAddressCountyUrbanVillageKana: string; // 被相続人ー住所・市区町村（フリカナ）
    public ancestorAddressStreetNameSelect: string;       // 被相続人ー住所・町丁名（選択）
    public ancestorAddressStreetNameInput: string;        // 被相続人ー住所・町丁名（入力）
    public ancestorAddressStreetNameKanaSelect: string;   // 被相続人ー住所・町丁名（フリカナ）（選択）
    public ancestorAddressStreetNameKanaInput: string;    // 被相続人ー住所・町丁名（フリカナ）（入力）
    public ancestorAddressHouseNumber: string;            // 被相続人ー住所・番地以降
    public ancestorAddressHouseNumberKana: string;        // 被相続人ー住所・番地以降（フリカナ）
    public ancestorAddressInfoChanged: boolean;           // 被相続人ー住所情報が修正されたか
    public matchesApplicantAddress: string;              // 被相続人ー住所情報が相続人ー住所情報と同じか
    public hasAncestorAccount: string;                   // 被相続人ー口座番号を知っているか

    public ancestorCustomerId: string[];                  // 被相続人ー 顧客番号
    public ancestorCustomerIdSelected: AncestorDuplicateCustomerId[];          // 選択された名寄せ
    public allCustomerId: string[];                  // 被相続人ー 名寄せ顧客番号

    @JsonProperty({ clazz: BranchCifEntity })
    public branchCifList: BranchCifEntity[];          // 被相続人-Cif情報リスト
    @JsonProperty({ clazz: AccountEntity })
    public ancestorAccountList: AccountEntity[];      // 被相続人-預金口座
    @JsonProperty({ clazz: BrokerageAccountEntity })
    public ancestorBrokerageAccountList: BrokerageAccountEntity[]; // 被相続人-証券口座
    public balanceSum: number;                        // 簡素化判定-残高合計
    public existSafeDepositBox: string;               // 簡素化判定-貸金庫あり
    public existPublicDebtInvestmentTrust: string;    // 簡素化判定-公共債・投資信託あり
    public existFundAccommodation: string;            // 簡素化判定-融資取引あり
    public withoutWill: string;                       // 簡素化判定-遺言書作成なし
    public existUnanimouslyAgree: string;             // 簡素化判定-相続人全員同意あり
    public withoutDispute: string;                    // 簡素化判定-相続人間紛議なし
    public judgeCanSimplifyImplementation: string;    // 簡素化判定-簡素化判定実施結果
    public simplificationDecisionResultAuto: string;  // 簡素化判定-簡素化判定結果(自動)
    public simplificationDecisionResultFixed: string; // 簡素化判定-簡素化判定結果(確定)
    public applicantHasHeirIdentityDocument: string; // 来店者さまは、相続人であることを確認できる書類をお持ち

    public representativeHeirFlg: string;             // 相続人代表情報-来店者と同一
    public representativeHeirName: string;		      // 相続人代表情報-氏名
    public representativeHeirNameKana: string;        // 被相続人ー氏名（フリガナ）
    public representativeHeirFirstName: string;		  // 相続人代表情報-姓
    public representativeHeirLastName: string;	      // 相続人代表情報-名
    public representativeHeirFirstNameKana: string;   // 相続人代表情報-姓（フリガナ）
    public representativeHeirLastNameKana: string;	  // 相続人代表情報-名（フリガナ）
    public representativeHeirBirthdate: string;		  // 相続人代表情報-生年月日
    public representativeHeirZipCode: string;		  // 相続人代表情報-郵便番号
    public representativeHeirFirstZipCode: string;    // 相続人代表情報ー郵便番号・前３位
    public representativeHeirLastZipCode: string;     // 相続人代表情報ー郵便番号・後４位
    public representativeHeirAddressPrefecture: string;        // 相続人代表情報ー住所・都道府県
    public representativeHeirAddressCountyUrbanVillage: string; // 相続人代表情報ー住所・市区町村
    public representativeHeirAddressStreetNameSelect: string;  // 相続人代表情報ー住所・町丁名（選択）
    public representativeHeirAddressStreetNameInput: string;   // 相続人代表情報ー住所・町丁名（入力）
    public representativeHeirAddressHouseNumber: string;       // 相続人代表情報ー住所・番地以降
    public representativeHeirAddressPrefectureKana: string;        // 相続人代表情報ー住所・都道府県（フリガナ）
    public representativeHeirAddressCountyUrbanVillageKana: string; // 相続人代表情報ー住所・市区町村（フリガナ）
    public representativeHeirAddressStreetNameKanaSelect: string;  // 相続人代表情報ー住所・町丁名（選択）（フリガナ）
    public representativeHeirAddressStreetNameKanaInput: string;   // 相続人代表情報ー住所・町丁名（入力）（フリガナ）
    public representativeHeirAddressHouseNumberKana: string;       // 相続人代表情報ー住所・番地以降（フリガナ）
    public representativeHeirMobileNo: string;		  // 相続人代表情報-携帯電話番号
    public representativeHeirMobileNoFirst: string;   // 相続人代表情報-携帯電話番号・一部
    public representativeHeirMobileNoSecond: string;  // 相続人代表情報-携帯電話番号・二部
    public representativeHeirMobileNoThird: string;   // 相続人代表情報-携帯電話番号・三部
    public representativeHeirTelephoneNo: string;	  // 相続人代表情報-自宅電話番号
    public representativeHeirTelFirst: string;        // 相続人代表情報-自宅電話番号・一部
    public representativeHeirTelSecond: string;       // 相続人代表情報-自宅電話番号・二部
    public representativeHeirTelThird: string;        // 相続人代表情報-自宅電話番号・三部
    public representativeHeirRelationship: string;	  // 相続人代表情報-被相続者続柄（コード）
    public representativeHeirRelationshipText: string; // 相続人代表情報-被相続者続柄（文言）
    public representativeHeirRelationshipDetail: string; // 相続人代表情報-被相続者続柄その他詳細
    public representativeHeirAccountBranchName: string; // 相続人代表情報-口座-店名
    public representativeHeirAccountBranchNo: string; // 相続人代表情報-口座-店番
    public representativeHeirAccountItem: string;	  // 相続人代表情報-口座-科目
    public representativeHeirAccountNo: string;		  // 相続人代表情報-口座-口座番号
    public representativeHeirAccountName: string;	  // 相続人代表情報-口座-名義
    public representativeAccountFirstName: string;    // 相続人代表情報ー口座-名義ー姓（フリガナ）
    public representativeAccountLastName: string;     // 相続人代表情報ー口座-名義ー名（フリガナ）

    public hasForeignHeir: string;             // 相続人に外国籍の方有無
    public hasNorthKoreaHeir: string;             // 相続人に北朝鮮在住の有無
    public hasHeirDisputes: string;             // 相続人間に紛議有無

    public spouseSignatureAndSealPropriety: string;   // 配偶者自署押印可否 0：配偶者自署押印不可能 1：配偶者自署押印可能

    public inheritanceMethod: string; // 相続方法
    public targetConfirm: string; // 来店者法定相続人確認フラグ
    public passbookConfirm: string; // 被相続人通帳・届出印確認フラグ

    @JsonProperty({ clazz: RelationshipInfoEntity })
    public relationshipList: RelationshipInfoEntity[];  // 相続人情報

    public customerApplyStartDate: string;             // 行員認証入力完了日時
    public bankclerkAuthenticationStartDate: string;
    public bankclerkAuthenticationEndDate: string;     // 入力内容確認完了行員認証時間
    public customerApplyEndDate: string;               // 入力内容確認完了時間
    public applyDate: string;                          // 手続き案内完了時間

    public branchNo: string;
    public branchNameKanji: string;

    public tabletApplyId: number;
    public userMngNo: string;
    public accountNo: string;
    public businessCode: string;
    public agencyBranchNo: string;     // 取次店番
    public bankNo: string; // 銀行番号
    public terminalNo: string; // 端末番号
    public customerId: string; // 顧客番号

    public receptionNumber: string; // 受付番号

    // バンクカードの合計金額
    public totalAmount: number;

    //  税理士の紹介を希望する
    public taxAccountant: string;

    // 遺産整理紹介必要
    public heritageRearrangingService: string;

    // 受付票起票店番号
    public inputReceptionBranchNunmber: string;

    // 受付票起票店名
    public inputReceptionBranchName: string;

    // 受付票起票店舗種類
    public inputReceptionBranchType: string;

    // キャッシュカード有り 来店者情報
    public applicantInfo: {
        branchName: string;              // 店舗名
        subjectName: string;             // 科目名
        customerId: string;              // 顧客番号
        nameKanjiBackup: string;         // 来店者ー氏名漢字
        nameKanji: string;               // 来店者ー氏名
        nameKana: string;                // 来店者ー氏名カナ
        nameAlphabet: string;            // 英文氏名
        birthdateWithAge: string;        // 来店者ー生年月日（和暦）
        zipCode: string;                 // 来店者ー郵便番号
        address: string;                 // 来店者ー住所
        nameNonConvert: string;          // 来店者ー姓名漢字表示する
        addressKana: string;             // 来店者ー住所カナ
        holderTelNo1: string;            // 来店者ー電話番号１
        holderTelNo2: string;            // 来店者ー電話番号２
        holderTelNo3: string;            // 来店者ー電話番号３
        nationalityCode: string;         // 来店者ー国籍コード
        cardInfo: any;   // キャッシュカード情報
    };

    // 払戻金入金先
    public refundCardInfo: {
        branchName: string;              // 店舗名
        branchCode: string;              // 店舗番号
        subjectName: string;             // 科目名
        subjectCode: string;             // 科目番号
        nameKanji: string;               // 来店者ー氏名
        nameKana: string;                // 来店者ー氏名カナ
        nameNonConvert: string;          // 来店者ー姓名漢字表示する
        accountNo: string;                // 口座番号
    };

    // QRコード受付情報
    public swipeCif: string;                           // スワイプ店CIF
    public receptionBranchNo: string;                  // 受付店番
    public receptionNo: string;                        // 受付番号
    public receptionTime: string;                      // 受付年月日時分秒
    public swipeBranchNo: string;                      // カード店番
    public swipeAccountNo: string;                     // カード口座番号
    public swipeAccountType: string;                   // カード科目
    public swipeCardType: string;                      // 本人カードタイプ

    // 入金先希望口座
    public domesticLoanAccountInfo: any[];
    public domesticLoanAccountTotalAmount: string | number;
    public bankCardTotalAmount: string;
    public paymentResultFlg: string;

    // 貸金庫・ホームケース
    public depositBoxInfo: string[];
    // 住宅ローン等一般融資
    public generalLoanInfo: string[];

    // 簡素化判定結果
    public simplifiedJudgment: string;
    // 簡易手続判定基準金額
    public simplifiedJudgmentBaseAmount: string;

    public fileInfo?: any;

    // お亡くなりになった方の金保護預かり情報
    public goldProtectionAccounts: any;

    // 内部API: 不活動口座照会
    /** 口座検索結果 */
    public inactiveAccountSearchStatus: string;
    /** CRM整理済顧客情報 */
    public inactiveCustomerInfo: InactiveCustomerInfo;
    /** CRM整理済口座情報 */
    public inactiveAccountInfo: InactiveAccountInfo;
    // 内部API: CIF情報照会
    /** 勘定系顧客保有有無 */
    public mejarCustomerStatus: string;
    /** CIF情報 */
    public customerInfo: CustomerInfo;
    /** 人格コード・確認できる、確認できない */
    public selectPersonalityCode: string;
    /** 本人死亡登録有無（CRMCIF） */
    public crmDeathFlag: boolean;
    /** 事故情報名称（CRMCIF) */
    public crmDispUnacceptableCodeInfo: any[];
    // 内部API: 睡眠・休眠情報照会
    /** 索引情報検索結果 */
    public dormantDepositSearchStatus: string;
    /** 睡眠・休眠預金情報 */
    public dormantDepositInfo: DormantDepositInfo;


    // キャッシュカードあり、なし
    public get hasSwipeCard(): boolean {
        if (this.applicantInfo) {
            return this.applicantInfo.cardInfo !== undefined && this.applicantInfo.cardInfo !== null;
        }
        return false;
    }

    /**
     * 来店者-郵便番号を取得する
     */
    public getApplicantZipCode(): string {
        return this.applicantFirstZipCode + this.applicantLastZipCode;
    }

    /**
     * 来店者-住所・町丁名（フリカナ）を取得する
     */
    public getApplicantAddressStreetNameKana(): string {
        if (this.applicantAddressStreetNameKanaSelect || this.applicantAddressStreetNameKanaInput) {
            return this.applicantAddressStreetNameKanaSelect
                ? this.applicantAddressStreetNameKanaSelect : this.applicantAddressStreetNameKanaInput;
        }

        return '';
    }

    /**
     * 来店者-住所・都道府県 （フリカナ）+ 市区町村（フリカナ） + 町丁名（フリカナ）+ 番地以降（フリカナ）を取得する
     */
    public getApplicantAddressKana(): string {
        return this.applicantAddressPrefectureKana +
            this.applicantAddressCountyUrbanVillageKana +
            this.getApplicantAddressStreetNameKana() +
            this.applicantAddressHouseNumberKana;
    }

    /**
     * 来店者-住所・町丁名（フリカナ）+ 番地以降（フリカナ）を取得する
     */
    public getApplicantAddressStreetHouseKana(): string {
        return this.getApplicantAddressStreetNameKana() +
            this.applicantAddressHouseNumberKana;
    }

    /**
     * 来店者-住所・町丁名を取得する
     */
    public getApplicantAddressStreetName(): string {
        if (this.applicantAddressStreetNameSelect || this.applicantAddressStreetNameInput) {
            return this.applicantAddressStreetNameSelect
                ? this.applicantAddressStreetNameSelect : this.applicantAddressStreetNameInput;
        }

        return '';
    }

    /**
     * 被相続人-郵便番号を取得する
     */
    public getAncestorZipCode(): string {
        return this.ancestorFirstZipCode + this.ancestorLastZipCode;
    }

    /**
     * 被相続人-住所・町丁名（フリカナ）を取得する
     */
    public getAncestorAddressStreetNameKana(): string {
        if (this.ancestorAddressStreetNameKanaSelect || this.ancestorAddressStreetNameKanaInput) {
            return this.ancestorAddressStreetNameKanaSelect
                ? this.ancestorAddressStreetNameKanaSelect : this.ancestorAddressStreetNameKanaInput;
        }

        return '';
    }

    /**
     * 被相続人-住所・都道府県 （フリカナ）+ 市区町村（フリカナ） + 町丁名（フリカナ）+ 番地以降（フリカナ）を取得する
     */
    public getAncestorAddressKana(): string {
        return this.ancestorAddressPrefectureKana +
            this.ancestorAddressCountyUrbanVillageKana +
            this.getAncestorAddressStreetNameKana() +
            this.ancestorAddressHouseNumberKana;
    }

    /**
     * 被相続人-住所・町丁名（フリカナ）+ 番地以降（フリカナ）を取得する
     */
    public getAncestorAddressStreetHouseKana(): string {
        return this.getAncestorAddressStreetNameKana() +
            this.ancestorAddressHouseNumberKana;
    }

    /**
     * 被相続人-住所・町丁名を取得する
     */
    public getAncestorAddressStreetName(): string {
        if (this.ancestorAddressStreetNameSelect || this.ancestorAddressStreetNameInput) {
            return this.ancestorAddressStreetNameSelect
                ? this.ancestorAddressStreetNameSelect : this.ancestorAddressStreetNameInput;
        }

        return '';
    }

    /**
     * 相続人代表-住所・町丁名を取得する
     */
    public getRepresentativeHeirAddressStreetName(): string {
        if (this.representativeHeirAddressStreetNameSelect || this.representativeHeirAddressStreetNameInput) {
            return this.representativeHeirAddressStreetNameSelect
                ? this.representativeHeirAddressStreetNameSelect : this.representativeHeirAddressStreetNameInput;
        }

        return '';
    }

    /**
     * 相続人代表-住所・町丁名（フリカナ）を取得する
     */
    public getRepresentativeHeirAddressStreetNameKana(): string {
        if (this.representativeHeirAddressStreetNameKanaSelect || this.representativeHeirAddressStreetNameKanaInput) {
            return this.representativeHeirAddressStreetNameKanaSelect
                ? this.representativeHeirAddressStreetNameKanaSelect : this.representativeHeirAddressStreetNameKanaInput;
        }

        return '';
    }

    /**
     * 相続人代表-住所・都道府県 （フリカナ）+ 市区町村（フリカナ） + 町丁名（フリカナ）+ 番地以降（フリカナ）を取得する
     */
    public getRepresentativeHeirAddressKana(): string {
        return this.representativeHeirAddressPrefectureKana +
            this.representativeHeirAddressCountyUrbanVillageKana +
            this.getRepresentativeHeirAddressStreetNameKana() +
            this.representativeHeirAddressHouseNumberKana;
    }

    /**
     * 町丁名（フリカナ）+ 番地以降（フリカナ）を取得する
     */
    public getRepresentativeHeirAddressStreetHouseKana(): string {
        return this.getRepresentativeHeirAddressStreetNameKana() +
            this.representativeHeirAddressHouseNumberKana;
    }

    constructor() {
        // 内部API: 不活動口座照会
        this.inactiveAccountSearchStatus = undefined;
        this.inactiveCustomerInfo = undefined;
        this.inactiveAccountInfo = undefined;
        // 内部API: CIF情報照会（勘定系顧客保有有無）
        this.mejarCustomerStatus = undefined;
        this.customerInfo = undefined;
        // 内部API: 睡眠・休眠情報照会
        this.dormantDepositInfo = undefined;
        this.dormantDepositSearchStatus = undefined;
    }
}
