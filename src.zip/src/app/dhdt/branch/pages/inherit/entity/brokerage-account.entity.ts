/**
 * 証券口座
 */
export class BrokerageAccountEntity {
    public cif: string;                                 // 店別CIF
    public wholeCif: string;                            // 全店CIF
    public cifName: string;                             // CIF氏名
    public cifNameKana: string;                         // CIF氏名カナ
    public cifBirthdate: string;                        // CIF生年月日
    public branchName: string; // 支店名
    public branchNo: string; // 店番
    public transactionType: string; // 取引種類
    public accountItem: string; // 科目
    public accountNo: string; // 口座番号
    public accountName: string; // 名義
    public isAbandonedAccount: string; // 不動口座である
    public fundIssue: string; // ファンド名／銘柄名
    public balanceUnitNumber: number; // 口数
    public parValue: number; // 額面金額
    public bondMutualfund: string; // 債券／投資信託区分 債券：1 投資信託：2
    public deathRegistrationType: string; // 死亡登録有無区分 有り：1 、無し：0
    public safeDepositBoxType: string; // 貸金庫取引有無区分 有り：1 、無し：0
    public loanType: string; // 融資取引有無区分 有り：1 、無し：0
    public creditCardType: string; // クレジットカード取引有無区分 有り：1 、無し：0
    public smallSavingsTaxExemptionType: string; // マル優該当有無区分 有り：1 、無し：0
    public nameNonConvert: string; // 漢字登録不可フラグ 登録不可：1 、登録可：0
}
