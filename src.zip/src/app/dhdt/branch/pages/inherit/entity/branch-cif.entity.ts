/**
 * 店別CIF
 */
export class BranchCifEntity {
    public branchCif: string; // 店別CIF
    public tenban: string; // 店番
    public branchName: string; // 店名
    public deathRegistrationType: string; // 死亡登録有無区分 有り：1 、無し：0
}
