/**
 * CIF 情報
 */
export interface AncestorCifInfo {
    tenban: string;
    branchName: string;
    subjectCode: string;
    subjectName: string;
    accountNo: string;
    accountStatus: string;
    passbookCategory: string;
    balance: string;
    customerId: string;
    individualCompanyType: string;
    zipCode: string;
    zipCode2: string;
    address: string;
    address2: string;
    addressNonConvert: string;
    addressNonConvert2: string;
    addressKana: string;
    addressKana2: string;
    nameKanji: string;
    nameNonConvert: string;
    nameKana: string;
    nameAlphabet: string;
    gender: string;
    genderText: string;
    birthdate: string;
    birthdateWithAge: string;
    agentNameRegisterType: string;
    holderTelNo1: string;
    holderTelNo2: string;
    holderTelNo3: string;
    identificationCode: string;
    nationalityCode: string;
    myNoEntryStatus: string;
    nonDelivery: string;
    ageClassification: string;
    unacceptables: Unacceptable[];
    unacceptableCodeInfo: UnacceptableCodeInfo[];
    dispUnacceptableCodeInfo: string[];
}

interface Unacceptable {
    unacceptableCode: string;
    unacceptableName: string;
}

interface UnacceptableCodeInfo {
    customerInfo: CustomerInfo;
    accountDetailsInfo: AccountDetailsInfo;
}

interface CustomerInfo {
    unacceptableCode: string;
}

interface AccountDetailsInfo {
    branchCode: string;
    subjectCode: string;
    bankAccountId: string;
    depositNo: string;
    unacceptableCode: string;
}
