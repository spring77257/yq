/**
 * 被相続人口座情報
 */
export interface AncestorDuplicateAccount {
    branchNo: string;
    branchName: string;
    customerId: string;
    nameKana: string;
    nameKanji: string;
    nameNonConvert: string;
    birthdate: string;
    zipCode: string;
    address: string;
    addressNonConvert: string;
    holderTelNo1: string;
    holderTelNo2: string;
    holderTelNo3: string;
    bankCardHoldingStatus: string;
    compoundAccountFlag: null;
    accountHoldingFlag: string;
    attributeMismatchFlag: string;
    nationalityCode: string;
    accountInfos: AccountInfo[];
    unacceptables: Unacceptable[];
    inheritCustomerStatus: string;
    identificationCode;
    status: string;
    unacceptableCodeInfo: UnacceptableCodeInfo[];
    dispUnacceptableCodeInfo: string[];
}

/**
 * 同一名義照会API実施後選択された顧客番号と状態
 */
export interface AncestorDuplicateCustomerId {
    customerId: string[];
    dataBelongs: 0 | 1;  // 0:名寄せ検索選択されたデータ 1:旧姓検索選択されたデータ
}

interface AccountInfo {
    tenban: string;
    accountType: string;
    accountNo: string;
    accountName: string;
}

interface Unacceptable {
    unacceptableCode: string;
    unacceptableName: string;
}

interface UnacceptableCodeInfo {
    customerInfo: CustomerInfo;
    accountDetailsInfo: AccountDetailsInfo;
}

interface CustomerInfo {
    unacceptableCode: string;
}

interface AccountDetailsInfo {
    branchCode: string;
    subjectCode: string;
    bankAccountId: string;
    depositNo: string;
    unacceptableCode: string;
}
