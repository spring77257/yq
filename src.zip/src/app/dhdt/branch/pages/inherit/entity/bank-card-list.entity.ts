/**
 * バンクカードエンティティ。
 */
export class BankCardListEntity {
    // 店番号
    public branchNo: string;
    // 科目コード
    public accountType: string;
    // 科目名
    public accountTypeName: string;
    // 口座番号
    public accountNo: string;
    // お預かり番号
    public custodyNumber: string;
    // 利率
    public rateMark: string;
    // 中途解約利息
    public interest: string;
    // 預入日
    public depositDate: string;
    // 預入日_フォーマット済
    public depositDateFormat: string;
    // 満期日
    public dueDate: string;
    // 満期日_フォーマット済
    public dueDateFormat: string;
    // 再発行回次
    public reissueTimes: string;
    // 預入金額
    public depositAmount: string;
    // 払戻解約希望金額
    public cancelAmount: string;
    // 解約不可情報有無
    public closeImpossibleFlag: string;
    // Web口座表示
    public webAccountStatus: string;
    // 重量用紙種類コード
    public passbookInfoCode: string;
    // 総合口座有無
    public compoundAccountStatus: string;
    // 総合口座の店番号
    public compoundBranchNo: string;
    // 総合口座の科目コード
    public compoundAccountType: string;
    // 総合口座の口座番号
    public compoundAccountNo: string;
    // 商品コード
    public productCode: string;
    // 解約対象商品数、リストの上から昇順
    public count: number;
    // 解約対象か否かのチェック用
    public id: boolean;
    // 解約金額
    public totalCancelAmount: string;
    // 解約フラグ（共通PayoutAccountComponent表示用フラグ）
    public isCancel: boolean;
}
