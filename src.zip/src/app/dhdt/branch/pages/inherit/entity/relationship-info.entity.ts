/**
 * 相続人関係Entity
 */
export class RelationshipInfoEntity {
    // 連番
    public serialNumber: number;
    // 氏名
    public name: string;
    // 続柄
    public relationshipName: string;
    // 続柄コード
    public relationshipCode: string;
    // 生存ステータス
    public survivalStatus: number;
    // 被代襲相続人連番
    public rootSerialNumber: number;
    // 必要書類
    public requiredDocument: string;
    // 補足情報
    public additionalInfo: string;
    // 定番
    public fixedNumber?: string;
    // 子ノードのブロックキー
    public childBlockKey?: string;
}
