/**
 * 取引有無情報
 */
export class TransPresenceEntity {
    public customerId: string; // 顧客番号
    public ancestorNameKana: string; // 被相続人カナ氏名
    public ancestorName: string; // 被相続人漢字氏名
    public ancestorBirthDate: string; // 被相続人生年月日
    public ancestorZipCode: string; // 被相続人郵便番号
    public ancestorPrefecture: string; // 被相続人の住所・都道府県
    public ancestorCountyUrbanVillage: string; // 被相続人の住所・市区町村
    public ancestorStreet: string; // 被相続人の住所・町丁名
    public ancestorSubAddress: string; // 被相続人の住所・番地以降
    public ancestorPrefectureKana: string; // 被相続人の住所・都道府県（フリカナ）
    public ancestorCountyUrbanVillageKana: string; // 被相続人の住所・市区町村（フリカナ）
    public ancestorStreetKana: string; // 被相続人の住所・町丁名（フリカナ）
    public ancestorSubAddressKana: string; // 被相続人の住所・番地以降（フリカナ）
    public ancestorAddress: string; // 被相続人の住所
    public ancestorAddressKana: string; // 被相続人の住所カナ
    public representativeCustomerIdFlag: string; // 代表顧客番号フラグ
    public transType: string[]; // 取引種類
}
