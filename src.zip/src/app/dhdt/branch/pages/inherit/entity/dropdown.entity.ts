export class DropdownEntity {
    public key: string;
    public value: string;
    public filler1: string;
    public filler2: string;
    public filler3: string;
    public filler5: string;
}
