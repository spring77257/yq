/**
 * 休眠口座
 */
export class InactiveAccountEntity {
    public customerId: string; // 顧客番号
    public branchName: string; // 支店名 NO.1
    public branchCode: string; // 店番
    public subjectCode: string; // 科目番号
    public subjectName: string; // 科目名 NO.2
    public accountNo: string; // 口座番号 NO.3
    public currencyCode: string;  // 通貨コード
    public closeAccountDate: string; // 口座閉鎖日
    public accountName: string; // 口座名義  NO.4
    public balance: string; // 残高 NO.5
}
