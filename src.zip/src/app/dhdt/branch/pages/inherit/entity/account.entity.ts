/**
 * 預金口座
 */
export class AccountEntity {
    public cif: string; // 店別CIF
    public wholeCif: string; // 全店CIF
    public cifName: string; // CIF氏名
    public cifNameKana: string; // CIF氏名カナ
    public cifBirthdate: string; // CIF生年月日
    public branchName: string; // 支店名
    public branchNo: string; // 店番
    public transactionType: string; // 取引種類
    public accountItem: string; // 科目
    public accountNo: string; // 口座番号
    public accountName: string; // 名義
    public detailNo: string; // 固有番号
    public balanceYen: number; // 残高(円)
    public currencyCode: string; // 通貨コード
    public balanceForeignCurrency: number; // 残高(外貨)
    public isAbandonedAccount: string; // 不動口座である
    public deathRegistrationType: string; // 死亡登録有無区分 有り：1 、無し：0
    public safeDepositBoxType: string; // 貸金庫取引有無区分 有り：1 、無し：0
    public loanType: string; // 融資取引有無区分 有り：1 、無し：0
    public creditCardType: string; // クレジットカード取引有無区分 有り：1 、無し：0
    public smallSavingsTaxExemptionType: string; // マル優該当有無区分 有り：1 、無し：0
}
