import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { AppProperties } from 'app.properties';
import { DeviceService } from 'dhd/common/services/device.service';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { Constants, DeliveryStatus } from 'dhdt/branch/pages/change/change-consts';
import { PageQuestionsModel } from 'dhdt/branch/pages/change/entity/change-questions.model';
import { ChangeConfirmPageCommonService } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import { ChangeSignal, ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { ChangeCompletionComponent } from 'dhdt/branch/pages/change/view/change-completion.component';
import { AgentInternalError, ApplyDate, COMMON_CONSTANTS, UnsetNonDeliveryStatus } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { DialogWithoutImageComponent } from 'dhdt/branch/shared/components/dialog-without-image/dialog-without-image.component';
import { DialogComponent } from 'dhdt/branch/shared/components/dialog/dialog.component';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { LoadingService } from 'dhdt/branch/shared/services/loading.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { Modal, ModalController, NavController, NavParams, ViewController } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';

@Component({
    selector: 'change-confirm-component',
    templateUrl: 'change-confirm.component.html'
})

export class ChangeConfirmComponent extends BaseComponent implements OnInit, OnDestroy {
    public confirmationChecked: boolean = false;      // 契約状況確認 checkbox status
    public receiptMethodChecked: boolean = false;      // カードお受取方法 checkbox status

    public state: ChangeState;

    public editedList: any = {};
    public saveShowChats: any = {};

    public tabletApplyId: number;
    public receptionTenban: string;

    public showChats: PageQuestionsModel[];

    // private showChatParams: ShowChartParam;
    // password
    public showCardPassword: string = '';
    public showConfirmPassword: string = '';
    public getUserInfo: any = {};
    public confirmPageCommonParams: Map<string, any> = null;

    public processType: number = 1;     // 進捗状況default: 1 必要情報入力

    public type: COMMON_CONSTANTS.BusinessFlowType;
    // 届出内容の変更
    public title: string = '';
    public cifParam: SimpleCifInfoInquiryInterface;
    public inputParam: any;
    public callBack: any;       // 呼び出す箇所のコールバック関数
    public branchHidden: boolean = false;
    public itemChanged: boolean = false;    // some items have been changed
    public pageTitle = this.labels.change.confirm.title; // お客さま情報確認
    public changedDict = {
        changed: false
    };
    public accountShopShow: boolean = false;
    public loading = false;
    public inheritChanged: boolean = false;
    public disableName = false;
    public isTelErrorShow = false;
    public isErrorShow: boolean = false;

    // カードお受取方法
    // public receiptMethod: string;

    private nameChanged = false;
    private addressChanged = false;
    private telephoneNoChanged = false;

    private fromChange = false;
    private passwordHasError: boolean = false;
    // 電話番号入力チェックを行う
    private needPhoneNo: boolean = false;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private navCtrl: NavController,
        private modalCtrl: ModalController,
        private changeConfirmPageCommonService: ChangeConfirmPageCommonService,
        private loginStore: LoginStore,
        private changeDetectorRef: ChangeDetectorRef,
        private navParams: NavParams,
        private logging: LoggingService,
        private deviceService: DeviceService,
        private viewCtrl: ViewController,
        private errorService: ErrorMessageService,
        private serverInfoService: ServerInfoService,
        private loadingService: LoadingService,
        private audioService: AudioService,
        private rsaService: RsaEncryptService,
        private modalService: ModalService,
        private savingStore: SavingsStore,
        private changeUtils: ChangeUtils,
    ) {
        super();

        this.type = navParams.get('type');
        this.processType = navParams.get('processType');
        this.cifParam = navParams.get('cifParam');
        this.inputParam = navParams.get('inputParams');
        this.callBack = navParams.get('callBack');
        this.nameChanged = navParams.get('nameChanged') || false;
        this.fromChange = navParams.get('fromChange') || false;
        this.isTelErrorShow = navParams.get('isTelErrorShow') || false;
        this.state = this.store.getState();
        this.action.setStateSubmitDataValue({
            name: ApplyDate.TABLET_START_DATE,
            value: this.serverInfoService.getSubmitEntityValue(ApplyDate.TABLET_START_DATE)
        });
        this.action.setStateSubmitDataValue({
            name: ApplyDate.CUSTOMER_APPLY_START_DATE,
            value: this.serverInfoService.getSubmitEntityValue(ApplyDate.CUSTOMER_APPLY_START_DATE)
        });
        // cif情報をchangeのstateに格納
        const cifinfo = navParams.get('cifInfo');
        Object.keys(cifinfo).forEach((key) => {
            this.action.setStateSubmitDataValue({
                name: key,
                value: cifinfo[key]
            });
        });
        // stateのsubmitDataをバックアップする
        this.action.submitDataBackup();

        // stateにtabletApplyIdをセットする。
        this.tabletApplyId = navParams.get('tabletApplyId');
        this.receptionTenban = navParams.get('receptionTenban');   // 取次店番
        if (this.tabletApplyId && this.receptionTenban) {
            this.action.setSwipeInfo({
                swipeInfo: undefined,
                tabletApplyId: this.tabletApplyId,
                receptionTenban: this.receptionTenban,
            });
        }
    }

    /**
     * 初期化の時、CIF情報取得処理を行う、ページ内容を更新する
     */
    public ngOnInit(): void {
        this.changeConfirmPageCommonService.loadConfirmTemplate();

        // ハンドルのリスナーを定義する
        this.registerHandler();

        // 各業務フローからのQrコードをstateにセット
        this.action.setSwipeInfoFromChatFlow(this.inputParam);

        this.store.registerSignalHandler(ChangeSignal.RETURN_TOP_COMPLETE, () => {
            this.store.unregisterSignalHandler(ChangeSignal.RETURN_TOP_COMPLETE);
            this.navCtrl.setRoot(TopComponent);
        });
        this.loading = true;

        switch (this.type) {
            // キャッシュカードフロー
            case COMMON_CONSTANTS.BusinessFlowType.CashCard: {
                this.title = this.labels.cashcard.title;
                break;
            }
            // 既存ー普通預金口座開設
            case COMMON_CONSTANTS.BusinessFlowType.ExistingSavings: {
                this.title = this.labels.change.headerTitle;
                break;
            }
            // 既存ー貯蓄預金口座開設
            case COMMON_CONSTANTS.BusinessFlowType.ExistingStorage: {
                this.title = this.labels.existingStorage.title;
                break;
            }
            // クレジットカードフロー
            case COMMON_CONSTANTS.BusinessFlowType.CreditCard: {
                this.title = this.labels.creditcard.titleHeader;
                this.branchHidden = true;
                this.accountShopShow = false;
                break;
            }
            // 定期解約フロー
            case COMMON_CONSTANTS.BusinessFlowType.Cancel: {
                this.title = this.labels.header.cancel.title;
                break;
            }
            // 定期&積立預金口座開設
            case COMMON_CONSTANTS.BusinessFlowType.ExistingReserve: {
                this.title = this.labels.existingReserve.title;
                this.branchHidden = true;
                break;
            }
            case COMMON_CONSTANTS.BusinessFlowType.Student: {
                this.title = this.labels.student.changeTitle;
                break;
            }
            // 相続のお手続きフロー
            case COMMON_CONSTANTS.BusinessFlowType.Inherit: {
                this.title = this.labels.inherit.title;
                this.pageTitle = this.labels.change.confirm.clientTitle; // 来店者さま情報確認
                this.inheritChanged = true;
                break;
            }
            case COMMON_CONSTANTS.BusinessFlowType.PointService: {
                this.title = this.labels.pointService.title;
                break;
            }
            case COMMON_CONSTANTS.BusinessFlowType.DirectBanking: {
                this.title = this.labels.directBanking.title;
                // 緊急連絡先が必要となるため、いずれかの電話番号が入力されていることを確認
                this.needPhoneNo = true;
                break;
            }
            // 自動振込
            case COMMON_CONSTANTS.BusinessFlowType.AutomaticTransfer: {
                this.title = this.labels.automaticTransfer.title;
                break;
            }
            // 定期預金書替フロー
            case COMMON_CONSTANTS.BusinessFlowType.TimeDepositRewriting: {
                this.title = this.labels.timeDepositRewriting.title;
                break;
            }
            // 諸届変更フロー
            default: {
                this.title = this.labels.change.confirm.headerTitle;
            }
        }

        // get 修正 detail
        this.confirmPageCommonParams = this.changeConfirmPageCommonService.getChangeConfirmPageComponentParams();
        this.state.showChats.forEach((item) => {
            if (item.type !== 'judge') {
                this.saveShowChats[item.name] = item;
            }
        });

        this.viewCtrl.willEnter.subscribe(() => {
            // 勘定API更新系をハンドルする
            this.store.registerSignalHandler(ChangeSignal.UPDATE_CHANGE_SUCCESS_TELEPHONE_NO, (data) => {
                // 完了コード(CODE)=NGの場合、当該errReasonが返って表示する
                if (data.errorResponse && data.errorResponse.wsp_res.code === COMMON_CONSTANTS.PROCESS_CODE_NG) {
                    this.errorService.handleExternalErrorByReason(data.errorResponse.values.errReason, undefined, () => {
                        // 次の業務に移動する
                        this.naviNextFlow();
                    });
                } else {
                    // 次の業務に移動する
                    this.naviNextFlow();
                }
            });
        });

        this.viewCtrl.willLeave.subscribe(() => {
            this.store.unregisterSignalHandler(ChangeSignal.UPDATE_CHANGE_SUCCESS_TELEPHONE_NO);
        });

        this.loadingService.dismissAllLoading();

        if (this.changeUtils.isHostError(this.state.submitData.errorCode)) {
            this.isErrorShow = true;
            const errorParams = {
                imgSrc: 'icon_hourgrass@2x.png',
                message: this.labels.common.error.host.support,
                subMessage: `<span class="font-color-red">（${this.state.submitData.errorCode}
                ${this.state.submitData.unacceptableCode}）</span>`,
                buttonList: [{ text: 'OK', buttonValue: 'ok' }]
            };
            const errorModal: Modal = this.modalCtrl.create(
                DialogComponent, errorParams, { cssClass: 'settings-error-modal', enableBackdropDismiss: false }
            );
            this.audioService.subject.next(true);
            errorModal.present();
        }
    }

    /**
     * カナ住所に漢字が混在した状態をチェック
     */
    public get checkContainKanjiValidation(): boolean {
        if (!StringUtils.validateKana(this.state.submitData.holderAddressPrefectureFuriKana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressCountyUrbanVillageFuriKana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressStreetNameFuriKanaInput ||
            this.state.submitData.holderAddressStreetNameFuriKanaSelect)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressHouseNumberFuriKana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressPrefectureFurigana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressCountyUrbanVillageFurigana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressStreetFurigana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressHouseNumberFurigana)) {
            return false;
        }

        return true;
    }

    /**
     * CIF情報取得処理のサブスクリプションをキャンセルする
     */
    public ngOnDestroy(): void {
        this.store.unregisterSignalHandler(ChangeSignal.GET_CIF_INFORMATION);
        this.store.unregisterSignalHandler(ChangeSignal.INQUIRE_ACCOUNT_BALANCE);
    }

    public getShowText(name: string): string {
        if (!this.saveShowChats || !this.saveShowChats[name] || !this.saveShowChats[name].answer) {
            return '';
        }
        return this.saveShowChats[name].answer.text;
    }

    /**
     * click 行員認証ページへ
     */
    public pushCompletionPage() {
        if (this.itemChanged && this.type !== COMMON_CONSTANTS.BusinessFlowType.Change) {
            this.branchStatusInsert();
        }

        if (this.itemChanged && this.state.submitData.nonDelivery === DeliveryStatus.NON_DELIVERY && !this.state.isAddressChanged) {

            this.modalService.showComponentModal(
                DialogWithoutImageComponent,
                {
                    message: this.labels.change.nonDelivery.message,
                    subMessage: this.labels.change.nonDelivery.subMessage,
                    buttonList: [
                        { text: this.labels.change.nonDelivery.button.noChange, buttonValue: 'noChange' },
                        { text: this.labels.change.nonDelivery.button.change, buttonValue: 'change' },
                    ]
                },
                (item) => {
                    // ボタン選択が住所変更なしの場合、暗証番号入力後に、行員認証画面に遷移する。
                    if (item.buttonValue === 'noChange') {
                        this.unsetNonDeliveryStatus();
                        this.showPasswordModal();
                    }
                });
        } else {

            this.logging.saveCustomOperationLog(
                this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
                this.labels.logging.ChangeInformation.nextButton,
            );
            this.action.setCustomerApplyEndDate();

            // 何も変更されない場合は次の業務に行きます
            if (!this.itemChanged) {
                // スワイプCIFの住所コードがマスタに存在しない場合、住所変更へ誘導する
                if (this.state.submitData.isNotExistingAddressCodeStatus) {
                    this.modalService.showComponentModal(
                        DialogWithoutImageComponent,
                        {
                            message: this.labels.change.addressCodeNotExist.message,
                            subMessage: this.labels.change.addressCodeNotExist.subMessage,
                            buttonList: [
                                { text: this.labels.change.nonDelivery.button.noChange, buttonValue: 'noChange' },
                                { text: this.labels.change.nonDelivery.button.change, buttonValue: 'change' },
                            ]
                        },
                        (item) => {
                            // 変更なしの場合、エラーモーダルを表示する
                            if (item.buttonValue === 'noChange') {
                                this.showErrorModal(AgentInternalError.ERROR_CODE_N_006);
                            } else if (item.buttonValue === 'change') {
                                // 住所変更する場合、諸届へ遷移される
                                this.naviChangeFlow();
                            }
                        });
                } else {
                    // 次の業務に移動する
                    this.naviNextFlow();
                }
                return;
            }

            // 変更あった場合はパスワード入力させて、行員認証画面に行きます。
            this.showPasswordModal();
        }
    }

    // application button disable
    public getApplicationBtnDisable(): boolean {
        // CIF情報が取得できない場合、次のボタンがDisabledにする
        if (!this.state.submitData.holderName) {
            return true;
        }

        if (this.fromChange && !this.itemChanged) {
            return true;
        }

        if (this.needPhoneNo) {
            // 固定電話番号・携帯電話番号のいずれも入力されていない場合はDisabled
            if (
                (!this.state.submitData.holderTelephoneNo ||
                    !this.state.submitData.holderTelephoneNo.trim()) &&
                (!this.state.submitData.holderMobileNo ||
                    !this.state.submitData.holderMobileNo.trim())
            ) {
                return true;
            }
        }

        return !this.checkContainKanjiValidation || this.passwordHasError;
    }

    public getCompleteButtonDisable(): boolean {
        if ((!this.itemChanged && this.type === COMMON_CONSTANTS.BusinessFlowType.Change) || this.isErrorShow) {
            return true;
        }
        return false;
    }

    /**
     * 変更項目を設定
     * @param data 変更項目
     */
    public handleItemChangedEmitter(data) {
        this.editedList = data.editList;

        if (this.editedList) {
            this.nameChanged = this.editedList.holderName || this.editedList.holderNameAlphabets;
            this.addressChanged = this.editedList.holderAddress;
            this.telephoneNoChanged = this.editedList.holderMobileNo || this.editedList.holderTelephoneNo;

            this.itemChanged = this.nameChanged || this.addressChanged || this.telephoneNoChanged;
        }

        const addressInfo = data.addressChangedInfo;
        if (this.addressChanged) {
            this.getHolderZipCode(addressInfo.needRequestCode);
        }

        // 住所変更した場合は、Stateに登録
        // if (this.editedList.holderAddress) {
        //     this.action.setAddressChangeFlg(true);
        // }

        // 氏名変更した場合は、Stateに登録
        // if (this.editedList.holderName || this.editedList.holderNameAlphabets) {
        //     this.action.setNameChangeFlg(true);
        // }

        // 電話番号変更した場合は、Stateに登録
        // if (this.editedList.holderTelephoneNo || this.editedList.holderMobileNo) {
        //     this.action.setTelphoneChangeFlg(true);
        // }
        // if (this.editedList.holderMobileNo || this.editedList.holderTelephoneNo) {
        //     this.action.setTelChangeFlg(true);
        // }
    }

    /**
     * handle passwordValidEmitter
     */
    public handlePasswordValidEmitter(passwordHasError: boolean) {
        this.passwordHasError = passwordHasError;
        this.getApplicationBtnDisable();
    }

    /**
     * 現在の確認画面が諸届業務の中かどうか
     *
     * @returns
     * @memberof ChangeConfirmComponent
     */
    public isInChangeStage(): boolean {
        return this.type === COMMON_CONSTANTS.BusinessFlowType.Change;
    }

    public naviChangeFlow() {
        this.naviNextFlow(true);
    }

    /**
     * 郵便番号
     * @param needRequestCode
     */
    private getHolderZipCode(needRequestCode: boolean) {
        if (needRequestCode) {
            if (this.state.submitData.holderAddressPrefecture && this.state.submitData.holderAddressCountyUrbanVillage) {
                this.action.getHolderZipCode(
                    this.state.submitData.holderAddressPrefecture,
                    this.state.submitData.holderAddressCountyUrbanVillage,
                    this.state.submitData.getHolderAddressStreetName());
            } else {
                this.action.setDefaultZipCode();
            }
        }
    }

    private branchStatusInsert() {
        const params = {
            deviceId: this.deviceService.getDeviceId(),   // 作成端末ID
            agencyBranchNo: this.loginStore.getState().belongToBranchNo,    // 取次店番
            userMngNo: this.loginStore.getState().bankclerkId,               // 行員ID
            status: Constants.DBConsts.insertStatus,
        };
        this.action.branchStatusInsert(params);
    }
    private registerHandler() {
        // CIF情報照会を取得してから、ページ更新
        this.store.registerSignalHandler(ChangeSignal.GET_CIF_INFORMATION, () => {
            this.loading = false;
            this.changeDetectorRef.detectChanges();
        });

        this.store.registerSignalHandler(ChangeSignal.INQUIRE_ACCOUNT_BALANCE, () => {
            this.disableName = false;
        });
    }

    private naviNextFlow(selectChange?: boolean) {
        if (this.type !== COMMON_CONSTANTS.BusinessFlowType.Change
            && (!this.itemChanged)) {
            this.navCtrl.popToRoot({ animate: false }, () => {
                Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                    this.callBack({
                        submitData: this.state.submitData,
                        selectChange: selectChange ? true : false
                    });
               });

            });
        } else {
            this.navCtrl.push(ChangeCompletionComponent,
                {
                    type: this.type,
                    callBack: this.callBack,
                    title: this.labels.change.confirm.headerTitle,
                    editedList: this.editedList,
                });
        }
    }

    /**
     * 暗証番号モーダルの呼出し
     * @param needRequestCode
     */
    private showPasswordModal() {
        const param = {
            tabletApplyId: this.state.tabletApplyId || this.tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            terminalNo: this.deviceService.getDeviceId(),
            accountNo: this.state.submitData.accountNo,
            tenban: this.state.submitData.branchNo,
            accountType: this.state.submitData.swipeCif ?
                this.state.submitData.accountType : COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL
        };

        const modal = this.modalCtrl.create(
            ModalPasswordComponent,
            {
                data: {
                    text: this.labels.change.changeModal.text,
                    subText: this.labels.change.passwordModal.subText,
                    units: 4,
                    errorMessage: this.labels.change.changeModal.errorMessage,
                    needConfirm: false,
                    validation: (password) => this.action.validatePasswordNotSetCifIno({
                        tabletApplyId: this.state.tabletApplyId || this.tabletApplyId, // タブレット申込管理ID
                        params: {
                            receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                            tenban: this.state.submitData.cardInfo.branchNo, // 店番
                            accountType: this.state.submitData.cardInfo.accountType, // 科目
                            accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                            icCardInfo: this.savingStore.getState().icData,  // カード情報を入れる
                            passcode: this.rsaService.encrypt(password)  // 暗証番号
                        }
                    }),
                    cashcardParams: param
                }
            },
            { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.onDidDismiss((value) => {
            if (value) {
                // 次の業務に移動する
                this.naviNextFlow();
            }
        });
        modal.present();
    }

    private unsetNonDeliveryStatus() {
        this.state.unsetNonDeliveryStatus = UnsetNonDeliveryStatus.SET_STATUS;
    }

    /**
     * エラーモーダルを表示する（受付可否チェック以外のエラー用）
     */
    private showErrorModal(errorCode: string) {
        const errorParams = {
            imgSrc: 'icon_hourgrass@2x.png',
            message: this.labels.common.error.host.support,
            subMessage: `<span class="font-color-red">${errorCode}</span>`,
            buttonList: [{ text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK }]
        };
        const errorModal = this.modalCtrl.create(
            DialogComponent, errorParams, { cssClass: 'settings-error-modal', enableBackdropDismiss: false }
        );
        this.audioService.subject.next(true);
        errorModal.present();
    }
}
