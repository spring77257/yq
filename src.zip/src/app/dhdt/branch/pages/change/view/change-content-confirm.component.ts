import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { DeviceService } from 'dhd/common/services/device.service';
import { SavingsStore } from 'dhdt/branch/pages/bank-savings-deposit/store/savings.store';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { PageQuestionsModel } from 'dhdt/branch/pages/change/entity/change-questions.model';
import { ChangeConfirmPageCommonService } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import { ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { ChangeCompletionComponent } from 'dhdt/branch/pages/change/view/change-completion.component';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { NewestInitConfirmComponent } from 'dhdt/branch/pages/newest/view/newest-initconfirm.component';
import { ReissueInitConfirmComponent } from 'dhdt/branch/pages/loss-reissue-finding/view/reissue-initconfirm.component';
import { ReplacementInitConfirmComponent } from 'dhdt/branch/pages/replacement/view/replacement-initconfirm.component';
import { ModalPasswordComponent } from 'dhdt/branch/shared/components/modal/modal-password/view/modal-password.component';
import { LoadingService } from 'dhdt/branch/shared/services/loading.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { RsaEncryptService } from 'dhdt/branch/shared/services/rsa-encrypt.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController, NavParams } from 'ionic-angular';

@Component({
    selector: 'change-content-confirm-component',
    templateUrl: 'change-content-confirm.component.html'
})

export class ChangeContentConfirmComponent extends BaseComponent implements OnInit {
    public state: ChangeState;

    public editedList: any = {};
    public saveShowChats: any = {};

    public showChats: PageQuestionsModel[];

    public confirmPageCommonParams: Map<string, any> = null;

    public processType: number = 2;

    public type: COMMON_CONSTANTS.BusinessFlowType.Change;
    // 届出内容の変更
    public title: string = this.labels.change.confirm.headerTitle;
    public callBack: any;       // 呼び出す箇所のコールバック関数
    public itemChanged: boolean = true;
    public pageTitle = this.labels.change.confirm.title; // お客さま情報確認
    public accountShopShow: boolean = false;
    public inheritChanged: boolean = false;
    public isTelErrorShow = false;
    public savingsPasswordChangeRequiredFlag: boolean = false;
    public savingDepositPasswordChangeRequiredFlag: boolean = false;
    protected ChangeUtils: ChangeUtils;
    private passwordHasError: boolean = false;
    private nameChanged = false;
    private addressChanged = false;
    private telephoneNoChanged = false;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private navCtrl: NavController,
        private changeConfirmPageCommonService: ChangeConfirmPageCommonService,
        private navParams: NavParams,
        private logging: LoggingService,
        private loadingService: LoadingService,
        private deviceService: DeviceService,
        private modalCtrl: ModalController,
        private rsaService: RsaEncryptService,
        private loginStore: LoginStore,
        private savingStore: SavingsStore,
        private changeUtils: ChangeUtils
    ) {
        super();
        this.state = this.store.getState();

        // stateのsubmitDataをバックアップする
        this.action.submitDataBackup();
    }

    /**
     * 初期化の時、CIF情報取得処理を行う、ページ内容を更新する
     */
    public ngOnInit(): void {
        // 氏名で変更するボタン押下の場合は青色背景
        // 住所・電話番号でSWCifと差分がある項目は青色背景
        this.editedList = {
            holderName: this.state.submitData.isNameChange,
            holderAddress: this.isAddressChangeCheckForSWCif(),
            holderMobileNo: this.isTelphoneChangeCheckForSWCif(),
            holderTelephoneNo: this.isTelphoneChangeCheckForSWCif()
        };

        // get 修正 detail
        this.changeConfirmPageCommonService.loadConfirmTemplate();
        this.confirmPageCommonParams = this.changeConfirmPageCommonService.getChangeConfirmPageComponentParams();
        this.state.showChats.forEach((item) => {
            if (item.type !== 'judge') {
                this.saveShowChats[item.name] = item;
            }
        });

        this.loadingService.dismissAllLoading();

    }

    /**
     * カナ住所に漢字が混在した状態をチェック
     */
    public get checkContainKanjiValidation(): boolean {
        if (!StringUtils.validateKana(this.state.submitData.holderAddressPrefectureFuriKana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressCountyUrbanVillageFuriKana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressStreetNameFuriKanaInput ||
            this.state.submitData.holderAddressStreetNameFuriKanaSelect)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressHouseNumberFuriKana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressPrefectureFurigana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressCountyUrbanVillageFurigana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressStreetFurigana)) {
            return false;
        }

        if (!StringUtils.validateKana(this.state.submitData.holderAddressHouseNumberFurigana)) {
            return false;
        }

        return true;
    }

    public getShowText(name: string): string {
        if (!this.saveShowChats || !this.saveShowChats[name] || !this.saveShowChats[name].answer) {
            return '';
        }
        return this.saveShowChats[name].answer.text;
    }

    /**
     * click 行員認証ページへ
     */
    public pushCompletionPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.ChangeInformation.nextButton,
        );
        this.action.setCustomerApplyEndDate();
        this.showPasswordModal();

    }

    /**
     * click 申込内容確認画面（再発行・発見）へ
     */
    public pushReissueInitConfirmPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.ChangeInformation.nextButton,
        );
        this.navCtrl.push(ReissueInitConfirmComponent, {
            changeState: this.state
        });
    }

    /**
     * click 申込内容確認画面（差替発行）へ
     */
    public pushReplacementInitConfirmPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.ChangeInformation.nextButton,
        );
        this.navCtrl.push(ReplacementInitConfirmComponent, {
            changeState: this.state,
            editedList: this.editedList,
        });
    }

    /**
     * click 申込内容確認画面（カード新規発行）へ
     */
    public pushNewestInitConfirmPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.ChangeInformation.nextButton,
        );
        this.navCtrl.push(NewestInitConfirmComponent, {
            changeState: this.state,
            editedList: this.editedList,
        });
    }
    /**
     * 変更項目を設定
     * @param data 変更項目
     */
    public handleItemChangedEmitter(data) {
        this.editedList = data.editList;

        if (this.editedList) {
            this.nameChanged = this.editedList.holderName || this.editedList.holderNameAlphabets;
            this.addressChanged = this.editedList.holderAddress;
            this.telephoneNoChanged = this.editedList.holderMobileNo || this.editedList.holderTelephoneNo;

            this.itemChanged = this.nameChanged || this.addressChanged || this.telephoneNoChanged;
        }
        this.editedList = {
            holderAddress: this.isAddressChangeCheckForSWCif(),
            holderMobileNo: this.isTelphoneChangeCheckForSWCif(),
            holderTelephoneNo: this.isTelphoneChangeCheckForSWCif()
        };
    }

    /**
     * handle passwordValidEmitter
     */
    public handlePasswordValidEmitter(passwordHasError: boolean) {
        this.passwordHasError = passwordHasError;
        this.getApplicationBtnDisable();
    }

    // application button disable
    public getApplicationBtnDisable(): boolean {
        return !this.checkContainKanjiValidation || this.passwordHasError;
    }

    public savingsPasswordChangeRequiredEmitter(value: boolean) {
        this.savingsPasswordChangeRequiredFlag = value;
    }

    public savingDepositPasswordChangeRequiredEmitter(value: boolean) {
        this.savingDepositPasswordChangeRequiredFlag = value;
    }

    // footer button disable
    public get footerBtnDisable() {
        let totalValid = false;
        if (!this.savingsPasswordChangeRequiredFlag && !this.savingDepositPasswordChangeRequiredFlag) {
            // キャッシュカードの暗証番号が要修正でない場合、フッターボタン活性化
            totalValid = true;
        }
        return totalValid;
    }

    /**
     * 暗証番号モーダルの呼出し
     * @param needRequestCode
     */
    private showPasswordModal() {
        const param = {
            tabletApplyId: this.state.tabletApplyId,
            receptionTenban: this.state.submitData.receptionBranchNo,
            receptionNo: this.state.submitData.receptionNo,
            terminalNo: this.deviceService.getDeviceId(),
            accountNo: this.state.submitData.accountNo,
            tenban: this.state.submitData.branchNo,
            accountType: this.state.submitData.swipeCif ?
                this.state.submitData.accountType : COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL
        };

        const modal = this.modalCtrl.create(
            ModalPasswordComponent,
            {
                data: {
                    text: this.labels.change.changeModal.text,
                    subText: this.labels.change.passwordModal.subText,
                    units: 4,
                    errorMessage: this.labels.change.changeModal.errorMessage,
                    needConfirm: false,
                    validation: (password) => this.action.validatePasswordNotSetCifIno({
                        tabletApplyId: this.state.tabletApplyId, // タブレット申込管理ID
                        params: {
                            receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                            tenban: this.state.submitData.cardInfo.branchNo, // 店番
                            accountType: this.state.submitData.cardInfo.accountType, // 科目
                            accountNo: this.state.submitData.cardInfo.accountNo, // 口座番号
                            icCardInfo: this.savingStore.getState().icData,  // カード情報を入れる
                            passcode: this.rsaService.encrypt(password)  // 暗証番号
                        }
                    }),
                    cashcardParams: param
                }
            },
            { cssClass: 'settings-modal', enableBackdropDismiss: false });
        modal.onDidDismiss((value) => {
            if (value) {
                // 次の業務に移動する
                this.naviNextFlow();
            }
        });
        modal.present();
    }

    private naviNextFlow() {
        this.navCtrl.push(ChangeCompletionComponent,
            {
                type: this.type,
                title: this.labels.change.confirm.headerTitle,
                editedList: this.editedList,
                callBack: this.callBack
            });
    }

    /**
     * 住所変更ありの場合、SWCIFに対して住所差分チェックを実施
     */
    private isAddressChangeCheckForSWCif() {
        let isAddressChangeForSWCif: boolean = false;
        if (this.state.submitData.isAddressChange) {
            // SWCIFを取得
            const swipeCifInfo = this.state.submitData.allCifInfos
                .filter((cifInfo: CifInfo) => cifInfo.customerId === this.state.submitData.customerId);
            // SWCIFと入力住所の差分比較
            isAddressChangeForSWCif = this.changeUtils.isAddressDiference(swipeCifInfo[0], this.state.submitData.holderAddressCode,
                this.state.submitData.holderAddressHouseNumberFurigana);
        }
        return isAddressChangeForSWCif;
    }

    /**
     * 電話番号変更ありの場合、SWCIFに対して電話番号差分チェックを実施
     */
    private isTelphoneChangeCheckForSWCif() {
        let isTelphoneChangeForSWCif: boolean = false;
        if (this.state.submitData.isTelphoneChange) {
            const holderTelList = this.changeUtils.makePhoneNoList(
                this.state.submitData.holderTelNo1, this.state.submitData.holderTelNo2, this.state.submitData.holderTelNo3);
            const holderMobileNo: string = this.state.submitData.firstMobileNo ?
                (this.state.submitData.firstMobileNo + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.secondMobileNo
                    + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdMobileNo) : undefined;
            const holderTelephoneNo: string = this.state.submitData.firstTel ?
                (this.state.submitData.firstTel + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.secondTel
                    + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdTel) : undefined;
            const phoneNoList = this.changeUtils.makePhoneNoList(holderMobileNo, holderTelephoneNo, undefined);
            // 入力した電話番号とSWCIFの電話番号の差分有無
            isTelphoneChangeForSWCif = this.changeUtils.isTelDifference(holderTelList, phoneNoList);
        }
        return isTelphoneChangeForSWCif;
    }

}
