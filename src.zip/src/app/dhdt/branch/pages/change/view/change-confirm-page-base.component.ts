import { OnDestroy, OnInit } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';

import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ChangeConfirmPageCommonService } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import { ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { ModalDigitalStore } from 'dhdt/branch/shared/components/modal/modal-digital/store/modal-digital.store';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';

/**
 * 諸届変更用ベースコンポーネント
 */
export abstract class ChangeConfirmPageBaseComponent extends BaseComponent implements OnInit, OnDestroy {
    protected readonly action: ChangeAction;
    protected readonly store: ChangeStore;
    protected readonly confirmPageCommonService: ChangeConfirmPageCommonService;
    // protected readonly commitDataProcessUtils: CommitDataProcessUtils;
    protected readonly ChangeUtils: ChangeUtils;
    protected readonly loginStore: LoginStore;
    protected readonly loginState: LoginState;
    protected readonly modalDigitalStore: ModalDigitalStore;
    public state: ChangeState;
    protected _labels;
    public changeHolderMobileNoFlag: boolean = false;

    public open: boolean = true;
    public saveShowChats: any = {};
    public tabletApplyId: number;
    public confirmPageCommonParams: Map<string, any> = null;

    constructor() {
        super();
        this.action = InjectionUtils.injector.get(ChangeAction);
        this.store = InjectionUtils.injector.get(ChangeStore);
        this.confirmPageCommonService = InjectionUtils.injector.get(ChangeConfirmPageCommonService);
        // this.commitDataProcessUtils = InjectionUtils.injector.get(CommitDataProcessUtils);
        this.ChangeUtils = InjectionUtils.injector.get(ChangeUtils);
        this.loginStore = InjectionUtils.injector.get(LoginStore);
        this.loginState = this.loginStore.getState();
        this.modalDigitalStore = InjectionUtils.injector.get(ModalDigitalStore);
        this.state = this.store.getState();
        const labelService = InjectionUtils.injector.get(LabelService);
        this._labels = labelService.labels;
    }

    public ngOnInit() {
        // this.setSubComponentParameters();
        this.saveShowChatsData();
        this.setPageInitialData();
        this.registerSignalHandlers();
    }

    public ngOnDestroy() {
        this.unregisterSignalHandlers();
    }

    public get headerTitle(): string {
        if (!this.state.submitData.accountType || !this.state.submitData.accountTypeText) {
            return '';
        }
        return this.state.submitData.accountTypeText;
    }

    public submit() {
        this.submitAccountApplyInfo();
    }

    public clearMemory() {
        this.action.clearStore();
    }

    public saveShowChatsData() {
        this.state.showChats.forEach((item) => {
            this.saveShowChats[item.name] = item;
        });
    }

    public changeHolderMobileNoEmitter(value) {
        this.changeHolderMobileNoFlag = value;
    }

    public abstract processSubmitData(): any;

    public abstract pushNextPage();

    public abstract submitProcessedData(submitData: any);

    public abstract registerSignalHandlers();
    public abstract unregisterSignalHandlers();

    protected submitAccountApplyInfo() {
        const submitData = this.processSubmitData();
        this.submitProcessedData(submitData);
    }

    private setPageInitialData() {
        // 行員登録画面に遷移するとき、入力する行員IDを記録する
        this.action.setBankclerkId(this.modalDigitalStore.getState().bankclerkId);
    }
}
