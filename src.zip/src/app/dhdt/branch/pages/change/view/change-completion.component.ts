import { Component } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ChangeChatComponent } from 'dhdt/branch/pages/change/chat-flow/change-chat.component';
import { ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { ChangeFinishComponent } from 'dhdt/branch/pages/change/view/change.component';
import { ClearChangeImagesClickRecordType, COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { ModalDigitalComponent } from 'dhdt/branch/shared/components/modal/modal-digital/view/modal-digital.component';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { NavController, NavParams } from 'ionic-angular';
import { ModalController } from 'ionic-angular/components/modal/modal-controller';

@Component({
    selector: 'change-completion-component',
    templateUrl: 'change-completion.component.html'
})

/**
 * Completion component(入力完了画面).
 */
export class ChangeCompletionComponent extends BaseComponent {
    public imgUrl = '';
    public buttonTitle = '';
    public type: COMMON_CONSTANTS.BusinessFlowType;
    // 届出変更
    public title: string = '';
    public processType: number = 1;
    public editedList: any = {};    // 変更項目リスト
    // 行員認証 行員IDとパスワードを入力してください
    private modalInfor: { title: string, subTitle: string, showInput: string, tabletApplyId: number };
    private state: ChangeState;
    private isItemChanged: boolean;
    constructor(
        private modalCtrl: ModalController,
        private navCtrl: NavController,
        private audioService: AudioService,
        navParams: NavParams,
        private logging: LoggingService,
        store: ChangeStore,
        private action: ChangeAction,
    ) {
        super();
        this.type = navParams.get('type') || COMMON_CONSTANTS.BusinessFlowType.Change;
        this.title = navParams.get('title') || '';
        this.editedList = navParams.get('editedList');
        this.state = store.getState();

        this.initModalData();

        this.isItemChanged = this.editedList.holderName || this.editedList.holderAddress
            || this.editedList.holderMobileNo || this.editedList.holderTelephoneNo;

        this.imgUrl = COMMON_CONSTANTS.FLOW_TYPE_CHANGE_NAME;
        // 行員認証に固定する
        this.processType = COMMON_CONSTANTS.ProcessType.BankClerkConfirm;
        this.buttonTitle = this.labels.change.userConfirm;
    }

    /**
     * View did enter
     */
    public ionViewDidEnter() {
        this.audioService.subject.next(true);
    }

    public presentModal() {
        this.showModal();
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.buttonTitle + this.labels.logging.InfoComfirm.DialogConfirmButton,
        );
    }

    private initModalData() {
        this.modalInfor = {
            title: this.labels.change.userConfirm,
            subTitle: this.labels.change.inputPassword,
            showInput: 'two-inputs',
            tabletApplyId: this.state.tabletApplyId
        };
    }

    private showModal() {
        const modal = this.modalCtrl.create(
            ModalDigitalComponent,
            { data: this.modalInfor },
            { cssClass: 'two-inputs' }
        );
        modal.onDidDismiss((success) => {
            if (success) {
                const modalSub = this.modalCtrl.create(ChangeChatComponent,
                    { pageIndex: 4, editedList: this.editedList },
                    { cssClass: 'full-modal', enableBackdropDismiss: false });

                modalSub.onDidDismiss((changeData) => {
                    if (changeData === undefined || changeData === null || changeData === 'close') {
                        return;
                    }
                    if (changeData === 'bankClerkConfirm') {
                        this.action.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.CHANGE_DOCUMENT);
                    }

                    if (changeData === 'backConfirm') {
                        this.navCtrl.popTo(this.navCtrl.getByIndex(this.navCtrl.length() - 3));
                        this.action.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.CHANGE_DOCUMENT);
                    } else {
                        // ChangeFinishComponentを取得する、フィルタニングメソッドを呼ぶ。名前変更ある場合は実施フィルダニング実施する
                        const controller = this.navCtrl.getActive();
                        if (controller.instance.filterInquiry) {
                            controller.instance.filterInquiry();
                        }
                    }
                });
                modalSub.present();
                this.navCtrl.push(ChangeFinishComponent, {
                    editedList: this.editedList
                });
            }
        });
        modal.present();
    }
}
