import { Component, Input, ViewChild } from '@angular/core';
import { LabelService } from 'adep/services';
import { AppProperties } from 'app.properties';
import { SavingsAction } from 'dhdt/branch/pages/bank-savings-deposit/action/savings.action';
import { ChatComponent } from 'dhdt/branch/pages/bank-savings-deposit/core/chat.component';
import { ChangeChatComponent } from 'dhdt/branch/pages/change/chat-flow/change-chat.component';
import { ChangeSignal } from 'dhdt/branch/pages/change/store/change.store';
import { ChangeConfirmPageBaseComponent } from 'dhdt/branch/pages/change/view/change-confirm-page-base.component';
import {
    ApplyDate, ClearChangeImagesClickRecordType, COMMON_CONSTANTS, HostResultCode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { LossReissueFindingAction } from 'dhdt/branch/pages/loss-reissue-finding/action/loss-reissue-finding.action';
import { LossReissueFindingSubmitEntity } from 'dhdt/branch/pages/loss-reissue-finding/entity/loss-reissue-finding-questions.model';
import { ReissueConfirmComponent } from 'dhdt/branch/pages/loss-reissue-finding/view/reissue-confirm.component';
import { ReplacementAction } from 'dhdt/branch/pages/replacement/action/replacement.action';
import { ReplacementSubmitEntity } from 'dhdt/branch/pages/replacement/entity/replacement-questions.model';
import { ReplacementConfirmComponent } from 'dhdt/branch/pages/replacement/view/replacement-confirm.component';
import { NewestSubmitEntity } from 'dhdt/branch/pages/newest/entity/newest-questions.model';
import { NewestConfirmComponent } from 'dhdt/branch/pages/newest/view/newest-confirm.component';
import { NewestAction } from 'dhdt/branch/pages/newest/action/newest.action';
import {
    AddCheckConfirmationChangeComponent
} from 'dhdt/branch/shared/components/confirmpage-common/change/add-check-confirmation-change.component';
import { ChangeConfirmMethodComponent } from 'dhdt/branch/shared/components/confirmpage-common/change/change-confirm-method.component';
import { FilteringParameterEntity } from 'dhdt/branch/shared/entity/filtering-parameter.entity';
import { DocumentCategoryService } from 'dhdt/branch/shared/modules/document-category/service/document-category.service';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ConfirmUtil } from 'dhdt/branch/shared/utils/confirm-util';
import { ModalController, NavController } from 'ionic-angular';
import { NavParams } from 'ionic-angular/navigation/nav-params';
import { ViewController } from 'ionic-angular/navigation/view-controller';
import { Observable } from 'rxjs/Observable';

@Component({
    selector: 'change-component',
    templateUrl: 'change.component.html'
})
export class ChangeFinishComponent extends ChangeConfirmPageBaseComponent {
    public processType;
    public nameChanged = false;
    public type: COMMON_CONSTANTS.BusinessFlowType;
    public callBack: any;       // 呼び出す箇所のコールバック関数
    public editedList: any = {};    // 変更項目リスト
    public isFromChange: boolean = true;
    // 届出変更
    public title: string = this.labels.change.completion.headerTitle;
    // #22427: 氏名変更の場合に、チェックボックスをチェックされていないと「認証する」ボタンが活性化されない
    public selected = false;
    public receptionNumber: string = this.state.isCalledFromLoss
        && this.state.submitData.receptionNumber !== undefined
        && this.state.submitData.receptionNumber !== null ? this.state.submitData.receptionNumber : '';
    public addCheckFinished: boolean = true;   // 追加確認チャット完了のフラグ
    public activeAddButton: boolean = true;    // 追加確認チャットのボタンの活性/非活性
    @Input() public confirmPageCommonParams: Map<string, any> = new Map();

    @ViewChild(ChangeConfirmMethodComponent)
    private changeConfirmMethodComponent: ChangeConfirmMethodComponent;
    @ViewChild(AddCheckConfirmationChangeComponent)

    private originShowChats: any[];

    // 名寄せコンポネントに渡すデータ
    get existingAccount() {
        const obj: any = {};
        // 受付APIの店番名はtenban
        // 同一名義人APIの店番名はbranchNo
        // 一緒に使用するため
        obj.account = { ...this.state.copySubmitData, branchNo: this.state.submitData.tenban };
        // 重複CIF情報
        obj.existing = this.state.duplicateAccountTenpoInfo;
        return obj;
    }

    get nayoseImageFlag() {
        return this.state.orderNameIdentiDocument && this.state.orderNameIdentiDocument.length > 0 ? true : false;
    }

    private insertImageType: string = COMMON_CONSTANTS.InsertImageType.image;
    private readonly MASKING_CHECKBOX_NAME = 'isAllMaskingStatus';

    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private modalService: ModalService,
        private savingsAction: SavingsAction,
        private logging: LoggingService,
        private categoryService: DocumentCategoryService,
        private viewCtrl: ViewController,
        private modalCtrl: ModalController,
        private lossReissueFindingAction: LossReissueFindingAction,
        private replacementAction: ReplacementAction,
        private newestAction: NewestAction,
        public confirmUtil: ConfirmUtil,
        private labelService: LabelService,
        private errorMessageService: ErrorMessageService
    ) {
        super();
        this.type = navParams.data.type || COMMON_CONSTANTS.BusinessFlowType.Change;
        this.title = this.labels.change.confirm.headerTitle;
        this.editedList = navParams.get('editedList');
        this.nameChanged = this.editedList.holderName;
        this.processType = COMMON_CONSTANTS.ProcessType.BankClerkConfirm;
        this.action.setAsSystemTime(ApplyDate.BANKCLERK_AUTHENTICATION_START_DATE);
        this.viewCtrl.willEnter.subscribe(() => this.categoryService.addObserver((data) => {
            this.action.setDocumentCategory(data);
        }, this));

        this.viewCtrl.willLeave.subscribe(() => this.categoryService.removeObserver(this));

        // stateのsubmitDataをバックアップする
        this.action.submitDataBackup();
        this.action.setOriginChangeSubmitData();
        this.originShowChats = [...this.state.showChats];
    }

    public get changeDocumentImages() {
        return this.state.changeDocumentImages;
    }

    public get showImages() {
        if (this.state.changeDocumentImages && Object.keys(this.state.changeDocumentImages).length > 0) {
            return true;
        } else if (this.state.nameIdentiAddressImage && Object.keys(this.state.nameIdentiAddressImage).length > 0) {
            return true;
        } else if (this.state.nameIdentiAccountImage && Object.keys(this.state.nameIdentiAccountImage).length > 0) {
            return true;
        } else if (this.state.addIdentityImage && Object.keys(this.state.addIdentityImage).length > 0) {
            return true;
        } else {
            return false;
        }
    }

    // 本人確認チャットでの撮影順
    public get orderChangeDocument() {
        return this.state.orderChangeDocument;
    }

    // 本人確認チャットでの撮影順とマッピング名前順
    public get orderChangeDocumentName() {
        return this.state.orderChangeDocumentName;
    }

    // 名寄せチャットでの撮影順
    public get orderNameIdentiDocument() {
        return this.state.orderNameIdentiDocument;
    }

    // 追加確認チャットでの撮影順
    public get orderAddIdentityDocument() {
        return this.state.orderAddIdentityDocument;
    }

    // 追加確認チャットでの撮影書類
    get addIdentityImage() {
        return this.state.addIdentityImage;
    }

    get nameIdentiAddressImage() {
        return this.state.nameIdentiAddressImage;
    }

    get nameIdentiAccountImage() {
        return this.state.nameIdentiAccountImage;
    }

    public get activeAddCheckButton() {
        return this.activeAddButton || this.state.activeAddButton;
    }

    public updataSubmitData(item) {
        this.action.setStateSubmitDataValue(item);
    }

    public submitProcessedData(submitData: any) {
        this.action.updateChangedInfo(submitData);

    }

    /**
     * 登録データを加工する
     */
    public processSubmitData(): any {
        const registerParams: any = {};

        // base部分を作成
        registerParams.tabletApplyId = this.state.tabletApplyId;

        const eyeCueNo = this.receptionNumber;

        // 変更後の情報
        const afterChangeInfo: any = {};
        afterChangeInfo.holderName = this.state.submitData.holderName ? this.state.submitData.holderName : undefined;
        afterChangeInfo.holderNameFurigana = this.state.submitData.holderNameFurigana;
        afterChangeInfo.holderNameAlphabet = this.state.submitData.holderNameAlphabet ?
            this.state.submitData.holderNameAlphabet : undefined;
        afterChangeInfo.holderZipCode = this.state.submitData.holderZipCode;
        afterChangeInfo.holderKanaAddress = this.state.submitData.holderAddressPrefectureFuriKana ?
            this.state.submitData.holderAddressPrefectureFuriKana
            + this.state.submitData.holderAddressCountyUrbanVillageFuriKana
            + (this.state.submitData.holderAddressStreetNameFuriKanaSelect ?
                this.state.submitData.holderAddressStreetNameFuriKanaSelect : '')
            : undefined;
        afterChangeInfo.holderKanaAuxiliaryAddress = this.state.submitData.holderAddressHouseNumberFuriKana;
        afterChangeInfo.holderPrefectureKana = this.state.submitData.holderAddressPrefectureFuriKana;
        afterChangeInfo.holderCountyUrbanVillageKana = this.state.submitData.holderAddressCountyUrbanVillageFuriKana;
        afterChangeInfo.holderStreetKana = this.state.submitData.holderAddressStreetNameFuriKanaSelect;
        afterChangeInfo.holderSubAddressKana = this.state.submitData.holderAddressHouseNumberFuriKana;
        afterChangeInfo.holderPrefecture = this.state.submitData.holderAddressPrefecture;
        afterChangeInfo.holderCountyUrbanVillage = this.state.submitData.holderAddressCountyUrbanVillage;
        afterChangeInfo.holderStreet = this.state.submitData.holderAddressStreetNameSelect ?
            this.state.submitData.holderAddressStreetNameSelect : undefined;
        afterChangeInfo.holderSubAddress = this.state.submitData.holderAddressHouseNumber;
        afterChangeInfo.holderAddressCode = this.state.submitData.holderAddressCode;
        afterChangeInfo.holderMobileNo = this.state.submitData.holderMobileNo ? this.state.submitData.holderMobileNo : undefined;
        afterChangeInfo.holderTelephoneNo = this.state.submitData.holderTelephoneNo ?
            this.state.submitData.holderTelephoneNo : undefined;

        // 電話番号変更するを選択の場合、SWCIFに対して、電話番号差分チェックを実施し、
        // isTelphoneChangeを電話番号差分有無のフラグに変更する
        // holderTelList：スワイプCIFの電話番号リスト
        // phoneNoList：入力した電話番号リスト
        if (this.state.submitData.isTelphoneChange) {
            const holderTelList = this.ChangeUtils.makePhoneNoList(
                this.state.submitData.holderTelNo1, this.state.submitData.holderTelNo2, this.state.submitData.holderTelNo3);
            const phoneNoList = this.ChangeUtils.makePhoneNoList(
                afterChangeInfo.holderMobileNo, afterChangeInfo.holderTelephoneNo, undefined);
            const result = this.ChangeUtils.isTelDifference(holderTelList, phoneNoList);
            this.action.setStateSubmitDataValue({ name: 'isTelphoneChange', value: result });
        }

        // 諸届更新APIへ送信する顧客情報リストを作成
        registerParams.params = this.ChangeUtils.makeRequestParamsForUpdateNameAddressTel(eyeCueNo, this.loginState,
            this.state.submitData, afterChangeInfo, this.state.changeDocumentImages, this.state.orderChangeDocument,
            this.state.submitData.mediumInfos.mediumInfo,
            this.state.isNameDifference, this.state.isAddressDifference, this.state.isTelphoneDifference, this.state.addIdentityImage);

        return registerParams;
    }

    /**
     * 次のページへ遷移する
     */
    public pushNextPage() {
        if (this.type === COMMON_CONSTANTS.BusinessFlowType.Change) {
            // 諸届変更の場合、申込完了になりました。
            this.modalService.showCompleteModal().subscribe({
                next: (event) => {
                    switch (event) {
                        case COMMON_CONSTANTS.BACK_TYPE_REAPPLY_MENU:
                            this.navCtrl.setRoot(ChatComponent, { reapplyFlg: true });
                            break;
                        default:
                            this.navCtrl.setRoot(TopComponent);
                    }
                },
                complete: () => {
                    this.savingsAction.clearStore();
                }
            });
        } else {
            // 1回目の諸届け完了時
            const buttonList = [
                { text: this.labels.alert.backToTopBtn, buttonValue: COMMON_CONSTANTS.BACK_TYPE_TOP },
                { text: this.labels.alert.continueBtn, buttonValue: COMMON_CONSTANTS.BUTTON_TYPE_CONTINUE }
            ];
            this.modalService.showInfoAlert(
                this.labels.alert.applyCompletionTitle,
                buttonList,
                (item) => {
                    if (item.buttonValue === COMMON_CONSTANTS.BUTTON_TYPE_CONTINUE) {
                        this.action.clearPartStore();
                        this.navCtrl.popToRoot({ animate: false }, () => {
                            Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                                this.callBack(this.state.submitData);
                            });
                        });
                    } else {
                        this.navCtrl.setRoot(TopComponent);
                    }
                }
            );
        }
    }

    // 勘定API更新系のリスナーを追加する
    public registerSignalHandlers() {
        this.store.registerSignalHandler(ChangeSignal.UPDATE_CHANGE_SUCCESS, (data) => {
            if (data.resultCode === HostResultCode.SUCCESS) {
                this.pushNextPage();
            } else {
                this.errorMessageService.showMessageModal(this.labelService.labels.common.error.host.applyErrorMessage, () => {
                    this.navCtrl.setRoot(TopComponent);
                    this.action.clearStore();
                    this.savingsAction.clearStore();
                });
            }
        });
    }

    // 勘定API更新系のリスナーをアンインストールする
    public unregisterSignalHandlers() {
        this.store.unregisterSignalHandler(ChangeSignal.UPDATE_CHANGE_SUCCESS);
    }

    /**
     * Back action
     */
    public back() {
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    // 申込画面に戻るので、マスキング未確認オブジェクトをクリア
                    this.action.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.CLEAR);
                    // 追加確認聴取書類クリア
                    this.action.clearAddIdentityData();
                    // マスキングがチェックされるときに、値にfalseをセット
                    if (this.state.checkboxStatus.isAllMaskingStatus) {
                        this.checkboxStatusEmmiterHandler(this.MASKING_CHECKBOX_NAME);
                    }
                    if (this.type === COMMON_CONSTANTS.BusinessFlowType.Change) {
                        this.action.clearStoreDocuments();
                        this.action.clearIdentiData();
                        this.navCtrl.popToRoot();
                    } else {
                        this.navCtrl.popTo(this.navCtrl.getByIndex(this.navCtrl.length() - 3));
                    }

                    this.logging.saveCustomOperationLog(
                        this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
                        this.labels.logging.AccountConfirm.backConfirmButton,
                    );
                }
            }
        );
    }

    /**
     * 認証ボタンが押される
     *
     * @memberof ChangeFinishComponent
     */
    public submit() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.AccountConfirm.confirmButton,
        );

        // APIに更新内容を送ります。
        this.submitAccountApplyInfo();

    }

    /**
     * 行員確認画面（再発行・発見）へ
     */
    public pushReissueConfirmPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.ChangeInformation.nextButton,
        );
        const originSubmitData: LossReissueFindingSubmitEntity = this.navParams.get('originSubmitData');
        this.navCtrl.push(ReissueConfirmComponent,
            {
                originSubmitData: originSubmitData,
                receptionNumber: this.receptionNumber
            }
        );
    }

    /**
     * 行員確認画面（差替発行）へ
     */
    public pushReplacementConfirmPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.ChangeInformation.nextButton,
        );
        const originSubmitData: ReplacementSubmitEntity = this.navParams.get('originSubmitData');
        this.navCtrl.push(ReplacementConfirmComponent,
            {
                originSubmitData: originSubmitData,
                receptionNumber: this.receptionNumber
            }
        );
    }

    /**
     * 行員確認画面（カード新規発行）へ
     */
    public pushNewestConfirmPage() {
        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.logging.ChangeInformation.nextButton,
        );
        const originSubmitData: NewestSubmitEntity = this.navParams.get('originSubmitData');
        this.navCtrl.push(NewestConfirmComponent,
            {
                originSubmitData: originSubmitData,
                receptionNumber: this.receptionNumber
            }
        );
    }

    /**
     * 申込内容確認画面（新規発行諸届）へ
     */
    public popToNewestChangeInitConfirmPage() {
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    this.logging.saveCustomOperationLog(
                        this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
                        this.labels.logging.AccountConfirm.backConfirmButton,
                    );
                    // 新規発行submitDataを書類聴取チャット実施直前の状態に復元する
                    this.newestAction.setStateData({ submitData: this.navParams.get('originSubmitData') });
                    // 申込内容確認に戻るので、未マスキング状態管理オブジェクト（新規発行側）をクリア
                    this.newestAction.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.CLEAR);
                    // 新規発行StateのcheckboxStatusを初期化（falseをセット）する
                    this.newestAction.resetCheckboxStatus();
                    this.resetChangeData();
                    this.navCtrl.popToRoot(); // 申込内容確認画面（諸届）へ
                }
            }
        );
    }

    /**
     * 申込内容確認画面（諸届）へ
     */
    public popToChangeInitConfirmPage() {
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    this.logging.saveCustomOperationLog(
                        this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
                        this.labels.logging.AccountConfirm.backConfirmButton,
                    );
                    // 喪失submitDataを書類聴取チャット実施直前の状態に復元する
                    this.lossReissueFindingAction.setStateData({ submitData: this.navParams.get('originSubmitData') });
                    // 申込内容確認に戻るので、未マスキング状態管理オブジェクト（喪失側）をクリア
                    this.lossReissueFindingAction.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.CLEAR);
                    // 喪失StateのcheckboxStatusを初期化（falseをセット）する
                    this.lossReissueFindingAction.resetCheckboxStatus();
                    this.resetChangeData();
                    this.navCtrl.popToRoot(); // 申込内容確認画面（諸届）へ
                }
            }
        );
    }

    /**
     * 申込内容確認画面（カード差替諸届）へ
     */
    public popToReplacementChangeInitConfirmPage() {
        const buttonList = [
            { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
            { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
        ];
        this.modalService.showWarnAlert(
            this.labels.alert.backToConfirmTitle,
            buttonList,
            (item) => {
                if (item.buttonValue === 'back') {
                    this.logging.saveCustomOperationLog(
                        this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
                        this.labels.logging.AccountConfirm.backConfirmButton,
                    );
                    // 差替submitDataを書類聴取チャット実施直前の状態に復元する
                    this.replacementAction.setStateData({ submitData: this.navParams.get('originSubmitData') });
                    // 申込内容確認に戻るので、未マスキング状態管理オブジェクト（差替側）をクリア
                    this.replacementAction.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.CLEAR);
                    // 差替StateのcheckboxStatusを初期化（falseをセット）する
                    this.replacementAction.resetCheckboxStatus();
                    this.resetChangeData();
                    this.navCtrl.popToRoot(); // 申込内容確認画面（諸届）へ
                }
            }
        );
    }

    /**
     * ChangeState配下のデータ（未マスキング状態管理オブジェクト、マスキング確認チェックボックス、本人確認書類）を初期化する
     * ChangeState配下のsubmitDataを書類聴取チャット実施前の状態に復元する
     */
    public resetChangeData() {
        this.action.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.CLEAR);
        if (this.state.checkboxStatus.isAllMaskingStatus) {
            this.checkboxStatusEmmiterHandler(this.MASKING_CHECKBOX_NAME);
        }
        this.action.clearStoreDocuments();
        this.action.clearIdentiData();
    }

    /**
     * 「認証する」ボタン活性化
     */
    public disableNextButton() {
        if (this.state.submitData.holderIdentityDocumentType) {
            return false;
        }
        return true;
    }

    /**
     * 認証ボタンを活性化・非活性
     * 以下条件を満足
     * * 受付番号入力済かつ追加確認チャット終了
     * * マスキングチェックボックスが存在する場合はチェックする
     *
     * @returns false:非活性 true:活性
     * @memberof ChangeFinishComponent
     */
    public checkInputValidation() {
        return this.addCheckFinished && this.receptionNumber.match(/^[0-9]{3}$/g) !== null
            && (!this.changeConfirmMethodComponent || this.state.checkboxStatus.isAllMaskingStatus);
    }

    /**
     * 顔写真のある本人確認の画像登録 or テキスト登録タイプ設定
     * @param event 画像・テキスト登録タイプ
     */
    public handleImageTypeChangedEmitter(event?: any) {
        this.insertImageType = event || this.insertImageType;
    }

    /**
     * 名寄せ処理で途中でキャンセルされた場合
     *
     * @param {*} data
     * @memberof ChangeFinishComponent
     */
    public onAddButton() {
        this.activeAddButton = true;
    }

    /**
     * eyecube番号を記録
     *
     * @param {*} data
     * @memberof ChangeFinishComponent
     */
    public onChangeReceptionNumber(data) {
        const item = data.find((element: any) => element.key === 'receptionNumber');
        if (item) {
            this.receptionNumber = item.value;
        }
    }

    public registAddCheckData(data) {
        this.addCheckFinished = true;
        this.action.registAddCheckData(data);
    }

    /**
     * 修正ボタン Emitハンドラー
     */
    public onEditIdentityDocument() {
        this.action.backupChangeIdentiDocs();
        this.action.submitDataBackup();

        const modalSub = this.modalCtrl.create(ChangeChatComponent,
            { pageIndex: 4, name: 'bankClerkConfirm', isCurrentPage: true },
            { cssClass: 'full-modal', enableBackdropDismiss: false });

        modalSub.onDidDismiss((changeData) => {
            if (changeData === undefined || changeData === null || changeData === 'close') {
                return;
            }
            if (changeData === 'modify') {
                // マスキングがチェックされるときに、値にfalseをセット
                if (this.state.checkboxStatus.isAllMaskingStatus) {
                    this.checkboxStatusEmmiterHandler(this.MASKING_CHECKBOX_NAME);
                }
                // 最新の写真によってマスキング未確認データをセットする
                this.action.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.CHANGE_DOCUMENT);
            }
        });
        modalSub.present();

        this.logging.saveCustomOperationLog(
            this.state.submitData.fileInfo ? this.state.submitData.fileInfo[0].screenId : '',
            this.labels.change.modifyChat.headerTitle1 + this.labels.logging.InfoComfirm.modifyButton,
        );
    }

    get addCheckData() {
        return {
            receiptMethod: this.state.submitData.receiptMethod,
            bcSuicaResult: this.state.submitData.bcSuicaResult,
            americanSuggestionInformationStatus: this.state.submitData.americanSuggestionInformationStatus,
            firstNameRoma: this.state.submitData.firstNameRoma,
            lastNameRoma: this.state.submitData.lastNameRoma
        };
    }

    /**
     * checkboxStatusEmmiterHandler
     * @param checboxItem checboxItem info
     */
    public checkboxStatusEmmiterHandler(checboxItem) {
        this.action.modifyCheckboxStatus(checboxItem);
    }

    public onMaskingConfirmEmmiterHandler(maskingConfirmImgStatus) {
        this.action.removeNotMaskingConfirmImages(maskingConfirmImgStatus);
    }

    /**
     * 画像マスキング修正を反映する
     *
     * @param {{ index: number, fieldName: string, value: string }} data
     * @memberof AccountComponent
     */
    public onImageMaskingComplete(data: { index: number, fieldName: string, code?: string, value: string }) {
        // 書類種別が指定されている場合、入れ子構造として画像を登録する
        if (data.code !== null) {
            this.action.editSubmitDataNested(data.index, data.fieldName, data.code, data.value);
        } else {
            this.action.editSubmitData(data.index, data.fieldName, data.value);
        }
    }

    /**
     * 同一名義人APIリクエストのパラメータ作成
     *
     * @private
     * @returns {*}
     * @memberof ChangeFinishComponent
     */
    private makeSameHolderRequestParams(): any {
        const params = {
            receptionTenban: this.loginStore.getState().belongToBranchNo,
            nameKana: this.state.copySubmitData.nameKana,
            nameKanji: this.state.copySubmitData.nameKanji,
            birthdate: this.state.copySubmitData.birthdate,
            address: this.state.copySubmitData.address,
            searchMode: '2',
            phoneNo1: this.state.copySubmitData.holderTelNo1,
            phoneNo2: this.state.copySubmitData.holderTelNo2,
            phoneNo3: this.state.copySubmitData.holderTelNo3,
        };

        const sameHolderParams = {
            tabletApplyId: this.state.tabletApplyId,
            params: params
        };

        return sameHolderParams;
    }

    /**
     * コード有の画像ファイルリストのコードなしの再作成
     *
     * @private
     * @param {stateImageDoc} 画像ファイル
     * @returns {any} コードなしの画像ファイルリスト
     * @memberof ChangeFinishComponent
     */
    private setConfirmImage(stateImageDoc: any): any {
        let imageDoc: string[] = Array<string>();
        const imageKeys = Object.keys(stateImageDoc);
        for (const i in imageKeys) {
            imageDoc = imageDoc.concat(stateImageDoc[imageKeys[i]]);
        }
        return imageDoc;
    }

    private filterInquiry() {
        // 名前変更なしの場合は、フィルタニングから離脱
        if (!this.nameChanged && !this.state.isNameDifference) {
            return;
        }

        const param = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                nameKanji: null,
                nameKana: null,
                nameAlphabet: null,
                birthdate: this.state.submitData.birthdate,
                address: this.state.submitData.holderAddressPrefecture ? (this.state.submitData.holderAddressPrefecture
                    + this.state.submitData.holderAddressCountyUrbanVillage + this.state.submitData.getHolderAddressStreetName()
                    + this.state.submitData.holderAddressHouseNumber)
                    : this.state.copySubmitData.address,
                bankClerkId: this.loginStore.getState().clerkInfo.bankClerkId,
            }
        };

        if (this.nameChanged) {
            param.params.nameKanji = this.state.submitData.holderName ? this.state.submitData.holderName : null;
            param.params.nameKana = this.state.submitData.holderNameFurigana;
            param.params.nameAlphabet = this.state.submitData.holderNameAlphabet ? this.state.submitData.holderNameAlphabet : null;
        } else {
            param.params.nameKanji = this.state.submitData.nameKanji ? this.state.submitData.nameKanji : null;
            param.params.nameKana = this.state.submitData.nameKana;
            param.params.nameAlphabet = this.state.submitData.nameAlphabet ? this.state.submitData.nameAlphabet : null;
        }

        const curFilteringParamters = new FilteringParameterEntity();
        curFilteringParamters.nameKanji = param.params.nameKanji;
        curFilteringParamters.nameKana = param.params.nameKana;
        curFilteringParamters.nameAlphabet = param.params.nameAlphabet;

        // 前回のパラメータと比較
        const isChanged = this.confirmUtil.isFilteringParameterChanged(this.state.lastFilteringParameter, curFilteringParamters);
        if (isChanged) {
            this.action.filterInquiry(param);
            // 今回のパラメータを保存
            this.action.setLastFilteringParameters(curFilteringParamters);
        } else {
            // 前回のフィルタリング照会結果を表示変数に渡す
            this.action.setLastFilteringResult(this.state.lastFilteringResult);
        }
    }
}
