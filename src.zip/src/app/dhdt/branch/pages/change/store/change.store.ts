import { Injectable, NgZone } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { LabelService } from 'adep/services';
import { AppProperties } from 'app.properties';
import { ChangeActionType } from 'dhdt/branch/pages/change/action/change.action';
import { BcSuicaResult, CashCardDeliveryType, Constants, CustomerSearch, DeliveryStatus } from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import {
    AllCiftradingConditions,
    ChangeDifferenceEntity,
    ChangeSubmitEntity, DropDownListEntity, TradingConditionCode
} from 'dhdt/branch/pages/change/entity/change-questions.model';
import { CifInfosResponse } from 'dhdt/branch/pages/change/entity/customer-infos-response.entity';
import {
    DuplicateAccountAndAcceptResultAccount, DuplicateAccountInfoResponse, DuplicateAccountTenpoInfo
} from 'dhdt/branch/pages/change/entity/duplicate-accountInfo-response.entity';
import { ChangeConfirmComponentParamName } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import {
    ClearChangeImagesClickRecordType, COMMON_CONSTANTS, CountryCode, OutStatus, OutStatusText, SubmitDataKey, ZipCode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { MediumInfosResponse } from 'dhdt/branch/pages/common/entity/medium-infos-response.entity';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import {
    AcceptionResult, AcceptionResultAccount, AcceptionResultTradingCondition
} from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { CharacterCheckResult } from 'dhdt/branch/shared/components/change-flow/entity/character.check.entity';
import { RENDER_TYPE } from 'dhdt/branch/shared/components/change-flow/enum/change-flow.enum';
import { CifInfoInquiryResponseEntity } from 'dhdt/branch/shared/entity/cif-info-inquiry-response.entity';
import { CifInfoEntity } from 'dhdt/branch/shared/entity/cif-info.entity';
import { FilteringParameterEntity } from 'dhdt/branch/shared/entity/filtering-parameter.entity';
import { RegionCodeEntity } from 'dhdt/branch/shared/entity/region-code.entity';
import {
    ChatFlowMessageInterface, ChatFlowMessageWithPageIndexInterface
} from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { CifInformationUtils } from 'dhdt/branch/shared/utils/cif-information-utils';
import * as moment from 'moment';
import { Observable } from 'rxjs/Observable';

export interface ChangeState extends State {
    questions: ChatFlowMessageInterface[][];
    showChats: ChatFlowMessageWithOrderIndexInterface[];
    submitData: ChangeSubmitEntity; // 住所・電話変更後の内容
    tabletStartDate: string;
    customerApplyStartDate: string;
    tabletApplyId: number; // 申請ID
    receptionTenban: string; // 受付店舗番号
    identityDocuments: string[];
    additionalInfoDocuments: string[];
    otherInfo: string[];
    copySubmitData: ChangeSubmitEntity; // 住所・電話変更前の内容
    submitDataBackup: ChangeSubmitEntity;
    originChangeSubmitData: ChangeSubmitEntity;
    dropDownList: DropDownListEntity[];
    currentFileInfo: any;
    cifInfoInquiryList: CifInfoInquiryResponseEntity[];
    cifInfoInquiry: CifInfoInquiryResponseEntity;
    cifInfo: CifInfoEntity[];
    getCifInfoFlag: boolean;
    transactionList: AcceptionResultTradingCondition[]; // 取引ぶりリストを格納
    selectedNameIdentityInfos: DuplicateAccountAndAcceptResultAccount[]; // 名寄せ処理中に選択した口座情報
    changeDocumentImages: any; // 本人確認チャットのでの撮影写真（パターンXABC）
    orderChangeDocument: string[]; // 書類の撮影順の格納
    orderChangeDocumentName: string[]; // 書類の撮影順の書類名格納
    copyChangeDocumentImages: any; // 本人確認チャットのでの撮影写真のコピー
    copyOrderChangeDocument: string[]; // 書類の撮影順のコピー
    copyOrderChangeDocumentName: string[]; // 書類の撮影順の書類名のコピー
    copyAddIdentityImage: any; // 追加確認チャットのでの撮影写真のコピー
    copyOrderAddIdentityDocument: string[]; // 追加確認書類の撮影順のコピー
    orderNameIdentiDocument: string[]; // 名寄せ書類の撮影順の格納
    nameIdentiAddressImage: any; // 名寄せ処理中に撮影した住所資料
    nameIdentiAccountImage: any; // 名寄せチャット属性情報撮影書類
    addIdentityImage: any; // 追加確認で撮影した資料
    orderAddIdentityDocument: string[]; // 追加確認書類の撮影順の格納
    documentListAddName: string; // 追加確認書類のその他書類名称
    duplicateAccountTenpoInfo: DuplicateAccountTenpoInfo[]; // 同一名義人APIから返却してきた結果
    duplicateAccountCustomerSearchStatus: string; // 同一名義人APIの顧客検索結果
    isAddressDifference: boolean; // 住所差分あるかどうか
    isNameDifference: boolean; // 名前差分あるかどうか
    isTelphoneDifference: boolean; // 電話番号差分あるかどうか
    isAddressDifferenceBackup: boolean; // 住所差分バックアップ
    isNameDifferenceBackup: boolean; // 名前差分バックアップ
    isTelphoneDifferenceBackup: boolean; // 電話番号差分バックアップ
    isAddressChanged: boolean; // 住所変更したかどうか
    isNameChanged: boolean; // 名前変更したかどうか
    isTelChanged: boolean; // 電話番号変更したかどうか
    isTelphoneChanged: boolean;
    activeAddButton: boolean; // 追加確認チャットのボタンを活性化する
    americanSuggestionInfo: string; // 米国人示唆情報
    nonDeliveryReleaseFlag: string; // 氏名変更時郵便不着解除フラグ
    unsetNonDeliveryStatus: string; // 郵便不着コード解除有無
    isSelectedSkipButtonA: boolean; // 本人確認チャットで書類パターンA聴取時、スキップボタンが押下されたか
    isSelectedSkipButtonB: boolean; // 本人確認チャットで書類パターンB聴取時、スキップボタンが押下されたか

    regionCodeInfo: RegionCodeEntity;
    identificationDocument3XDisplayedName: string; // 本人確認チャットでの書類パターンX表示名称
    isAlreadyConfirmC: boolean; // 本人確認チャットにおける書類パターンCの聴取有無
    isAlreadyConfirmB: boolean; // 本人確認チャットにおける書類パターンBの聴取有無
    lastFilteringParameter: FilteringParameterEntity; // 前回フィルタリング照会のパラメータ
    lastFilteringResult: any;  // 前回フィルタリング照会の結果
    /**
     * 入り口で届出事項変更をした場合に次に利用する申込ID
     * メニューボタンで届出事項変更を押したとき以外に変更OPをした場合は、
     * 最初のtabletApplyIdを届出事項変更とし、
     * 次のtabletApplyIdをメニューボタンで選択された業務とする。
     */
    nextTabletApplyId: number;
    nameIdentityCustomerInfos: CifInfosResponse; // 名寄せ対象の顧客情報
    checkboxStatus: { isAllMaskingStatus: boolean };
    existingAccountResetFlg: boolean;
    // 受付可否チェックAPIの結果
    acceptCheckResult: Array<{ keyType: string, key: string, value: AcceptionResultAccount }>;

    // 諸届けの各書類の画像について、masking確認完了されたない画像のIndexを格納するオブジェクト
    notMaskingConfirmImages: { changeDocumentImages: number[], nameIdentiAddressImage: number[], addIdentityImage: number[] };
    idDocNameX: string; // パターンXにて撮影した書類名
    idDocNameA: string; // パターンAにて撮影した書類名
    idDocNameB: string; // パターンBにて撮影した書類名
    idDocNameC: string; // パターンCにて撮影した書類名
    nayoseIdDocNameA: string; // 名寄せでパターンAにて撮影した書類名
    nayoseIdDocNameB: string; // 名寄せでパターンBにて撮影した書類名
    nayoseIdDocNameC: string; // 名寄せでパターンCにて撮影した書類名
    addIdDocName: string; // 追加確認にて撮影した書類名
    isLineGuided: boolean; // LINE登録案内したかどうか

    // 喪失からの呼出フラグ(喪失系業務からの諸届変更チャットかどうか)
    isCalledFromLoss: boolean;

    // 差替からの呼出フラグ(差替系業務からの諸届変更チャットかどうか)
    isCalledFromReplace: boolean;

    // カード新規発行からの呼出フラグ(カード新規発行系業務からの諸届変更チャットかどうか)
    isCalledFromNewest: boolean;
}

export interface ChatFlowMessageWithOrderIndexInterface extends ChatFlowMessageWithPageIndexInterface {
    orderIndex?: number;
}

export interface ChatFlowMessageWithOrderIndexInterface extends ChatFlowMessageWithPageIndexInterface {
    orderIndex?: number;
}

export const
    ChangeSignal = {
        SEND_ANSWER: 'SEND_ANSWER',
        GET_QUESTION: 'GET_QUESTION',
        GET_INFO_OCR_COMPLETE: 'GET_INFO_OCR_COMPLETE',
        SUCCESS_VALIDATION: 'SUCCESS_VALIDATION',
        FAILED_VALIDATION: 'FAILED_VALIDATION',
        SUCCESS_INSERT_INFO: 'SUCCESS_INSERT_INFO',
        CHAT_FLOW_COMPELETE: 'CHAT_FLOW_COMPELETE',
        SUCCESS_INSERT_IMAGES_INFO: 'SUCCESS_INSERT_IMAGES_INFO',  // イメージアップロードAPIが正しく実行完了
        UPDATE_USER_INFO: 'UPDATE_USER_INFO',
        CHANGE_USER_INFO: 'CHANGE_USER_INFO',
        GET_CHECK_ACCOUNT_EXISTING: 'GET_CHECK_ACCOUNT_EXISTING',              // 口座存在チェック結果
        GET_CIF_INFORMATION: 'GET_CIF_INFORMATION',              // CIF情報照会
        UPDATE_CHANGE_SUCCESS: 'ChangeSignal_UPDATE_CHANGE_SUCCESS',
        UPDATE_CHANGE_SUCCESS_TELEPHONE_NO: 'ChangeSignal_UPDATE_CHANGE_SUCCESS_TELEPHONE_NO',
        INQUIRE_ACCOUNT_BALANCE: 'ChangeSignal_INQUIRE_ACCOUNT_BALANCE',
        RETURN_TOP_COMPLETE: 'ChangeSignal_RETURN_TOP_COMPLETE',
        GET_CUSTOMERS_INFOS_DATA: 'ChangeSignal_GET_CUSTOMERS_INFOS_DATA',
        SUCCESS_SET_CUST_START_TIME: 'ChangeSignal_SUCCESS_SET_CUST_START_TIME',
        ACCEPT_TARGET_FOR_NAME_DIF_CIF: 'ChangeSignal_ACCEPT_TARGET_FOR_NAME_DIF_CIF',
        ACCEPT_TARGET_FOR_TEL_DIF_CIF: 'ChangeSignal_ACCEPT_TARGET_FOR_TEL_DIF_CIF',
        ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF: 'ChangeSignal_ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF',
        SEARCH_REGION_CODE_COMPLETE: 'ChangeSignal_SEARCH_REGION_CODE_COMPLETE',
        CHARACTER_CHECK: 'ChangeSignal_CHARACTER_CHECK', // 文字チェック
        GET_SAME_CUSTOMERS_INFO: 'ChangeSignal_GET_SAME_CUSTOMERS_INFO',
        GET_MEDIUM_INFO: 'ChangeSignal_GET_MEDIUM_INFO',
        ACCEPT_CHECK_SWIPE_CIF: 'ChangeSignal_ACCEPT_CHECK_SWIPE_CIF', // スワイプCifの受付可否チェック
        UNACCEPTABLES_NG: 'ChangeSignal_UNACCEPTABLES_NG',
        GET_ADDRESS_CODE: 'ChangeSignal_GET_ADDRESS_CODE',
        GET_HOLDER_ZIP_CODE: 'ChangeSignal_GET_HOLDER_ZIP_CODE',
        CUSTOMER_INFOS_LIST: 'ChangeSignal_CUSTOMER_INFOS_LIST'
    };

@Injectable()
export class ChangeStore extends Store<ChangeState> {
    private replaceValues: Array<{ key: string, value: any }>;
    private keysArr: any[] = [];
    private readonly APPLY_BUSI_TYPE = '99';
    private tempPayload: string[];
    private changeDocArr: any[] = [];
    private orderChangeDocArr: any[] = [];
    private orderChangeDocNameArr: any[] = [];
    private addIdentiArr: any[] = [];
    private addPhotoOrderArr: any[] = [];

    constructor(
        private ngZone: NgZone,
        private errorMessageService: ErrorMessageService,
        private changeUtils: ChangeUtils,
        private labelService: LabelService,
        private loginStore: LoginStore,
        private editService: EditService,
    ) {
        super();
        this.initState();
    }

    /**
     * Stateを初期化する
     *
     * @private
     * @memberof ChangeStore
     */
    private initState() {
        this.state = {
            questions: [],
            showChats: [],
            submitData: new ChangeSubmitEntity(),
            tabletStartDate: '',
            customerApplyStartDate: '',
            tabletApplyId: -1,
            receptionTenban: '',
            identityDocuments: [],
            additionalInfoDocuments: [],
            otherInfo: [],
            copySubmitData: null,
            submitDataBackup: new ChangeSubmitEntity(),
            originChangeSubmitData: new ChangeSubmitEntity(),
            dropDownList: [],
            currentFileInfo: {},
            cifInfoInquiryList: new Array<CifInfoInquiryResponseEntity>(),
            cifInfoInquiry: new CifInfoInquiryResponseEntity(),
            cifInfo: new Array<CifInfoEntity>(),
            getCifInfoFlag: false,
            transactionList: [],
            duplicateAccountTenpoInfo: [],
            selectedNameIdentityInfos: [],
            changeDocumentImages: {},
            orderChangeDocument: [],
            orderChangeDocumentName: [],
            copyChangeDocumentImages: {},
            copyOrderChangeDocument: [],
            copyOrderChangeDocumentName: [],
            copyAddIdentityImage: {},
            copyOrderAddIdentityDocument: [],
            orderNameIdentiDocument: [],
            nameIdentiAccountImage: [],
            nameIdentiAddressImage: {},
            addIdentityImage: {},
            orderAddIdentityDocument: [],
            documentListAddName: '',
            duplicateAccountCustomerSearchStatus: '0', // 0：全件検索済み 1：後続明細あり
            isAddressDifference: false, // false: 差分なし　true:差分ある
            isNameDifference: false, // false: 差分なし　true:差分ある
            isTelphoneDifference: false, // false: 差分なし　true:差分ある
            isAddressDifferenceBackup: false, // false: 差分なし　true:差分ある
            isNameDifferenceBackup: false, // false: 差分なし　true:差分ある
            isTelphoneDifferenceBackup: false, // false: 差分なし　true:差分ある
            isAddressChanged: false, // false: 変更なし　true:変更した
            isNameChanged: false, // false: 変更なし　true:変更した
            activeAddButton: false, // false: 非活性　true:活性
            isTelChanged: false, // false: 変更なし　true:変更した
            isTelphoneChanged: false,
            nextTabletApplyId: -1,
            nameIdentityCustomerInfos: undefined,
            americanSuggestionInfo: '',
            nonDeliveryReleaseFlag: '',
            unsetNonDeliveryStatus: '0', // 0: 解除しない　1: 解除する
            checkboxStatus: {
                isAllMaskingStatus: false
            },
            existingAccountResetFlg: false,
            isSelectedSkipButtonA: false,
            isSelectedSkipButtonB: false,
            acceptCheckResult: [],
            regionCodeInfo: new RegionCodeEntity(),
            identificationDocument3XDisplayedName: '',
            isAlreadyConfirmC: false,
            isAlreadyConfirmB: false,
            notMaskingConfirmImages: {
                changeDocumentImages: [],
                nameIdentiAddressImage: [],
                addIdentityImage: []
            },
            lastFilteringParameter: new FilteringParameterEntity(),
            lastFilteringResult: {},
            idDocNameX: '',
            idDocNameA: '',
            idDocNameB: '',
            idDocNameC: '',
            nayoseIdDocNameA: '',
            nayoseIdDocNameB: '',
            nayoseIdDocNameC: '',
            addIdDocName: '',
            isLineGuided: false,
            isCalledFromLoss: false,
            isCalledFromReplace: false,
            isCalledFromNewest: false
        };
    }

    /**
     * 住所差分あることを登録
     *
     * @private
     * @param {boolean} result
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SET_ADDRESS_DIFFERENCE_FLG)
    private setAddressDifferenceFlg(result: boolean) {
        this.state.isAddressDifference = result;
    }

    /**
     * 氏名差分あることを登録
     *
     * @private
     * @param {boolean} result
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SET_NAME_DIFFERENCE_FLG)
    private setNameDifferenceFlg(result: boolean) {
        this.state.isNameDifference = result;
    }

    /**
     * 電話番号差分あることを登録
     *
     * @private
     * @param {boolean} result
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SET_TELPHONE_DIFFERENCE_FLG)
    private setTelphoneDifferenceFlg(result: boolean) {
        this.state.isTelphoneDifference = result;
    }

    @ActionBind(ChangeActionType.SET_TEL_CHANGE_FLG)
    private setTelChanged(result: boolean) {
        this.state.isTelChanged = result;
    }

    /**
     * LINE登録ご案内のフラグを設定
     *
     * @private
     * @param {boolean} result
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SET_LINE_GUIDE_FLG)
    private setLineGuided() {
        this.state.isLineGuided = true;
    }

    /**
     * 名寄せ処理のデータをクリア
     * * 選択した口座
     * * 撮影した写真
     */
    @ActionBind(ChangeActionType.CLEAR_NAME_IDENTITY_DATA)
    private clearNameIdentityData() {
        // 選択した口座
        this.state.selectedNameIdentityInfos = [];
        // 名寄せで撮った住所確認写真、認証APIのパラメタ設定で使われる
        this.state.nameIdentiAddressImage = {};
        // 名寄せで撮った住所確認写真の撮影順、行員認証画面の画像表示に使われる
        this.state.orderNameIdentiDocument = [];
        // 名寄せで撮った本人確認写真、認証APIのパラメタ設定で使われる
        this.state.nameIdentiAccountImage = [];
        // 名寄せ対象のCIF情報、認証APIのパラメタ設定で使われる
        this.state.nameIdentityCustomerInfos = undefined;
        // マスキングのチェックボックスをクリア
        this.state.checkboxStatus.isAllMaskingStatus = false;
    }

    /**
     * 追加確認の画像データをクリア
     * * 撮影した写真
     */
    @ActionBind(ChangeActionType.CLEAR_ADD_IDENTITY_DATA)
    private clearAddIdentityData() {
        // 追加確認で撮った確認写真、認証APIのパラメタ設定で使われる
        this.state.addIdentityImage = {};
        // 追加確認で撮った確認写真の撮影順、行員認証画面の画像表示に使われる
        this.state.orderAddIdentityDocument = [];
        // マスキングのチェックボックスをクリア
        this.state.checkboxStatus.isAllMaskingStatus = false;
    }

    /**
     * 住所変更ボタンが押されるときに取得した取引ぶりリストを格納
     *
     * @param {Array<{ tradingConditionCode: string; tradingConditionName: string; }>} transactionList
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.TRANSFER_SELF_TRADING_LIST)
    private setTransactionList(transactionList: AcceptionResultTradingCondition[]) {
        this.state.transactionList = transactionList;
    }

    /**
     * 本人書類確認処理中に撮影した写真をchange stateに格納
     *
     * @private
     * @param {string[]}
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SAVE_DOCUMENT_IMAGES)
    private saveDocumentImages(param: { image: string, name: string, code: string }) {
        if (!this.state.changeDocumentImages) {
            this.state.changeDocumentImages = {};
        }
        if (!this.state.orderChangeDocument) {
            this.state.orderChangeDocument = [];
        }
        if (!this.state.orderChangeDocumentName) {
            this.state.orderChangeDocumentName = [];
        }
        if (param.image) {
            this.state.changeDocumentImages[param.code] = this.state.changeDocumentImages[param.code] ?
                [...this.state.changeDocumentImages[param.code], param.image] : [param.image];
            this.state.orderChangeDocument.push(param.code);
            this.state.orderChangeDocumentName.push(param.name);
        }
        // バックアップの最新要素を上書き(撮影時は回答チャットの表示がないため、書類種類のチャット時点としてバックアップする)
        this.changeDocArr.pop();
        this.changeDocArr.push(JSON.parse(JSON.stringify(this.state.changeDocumentImages)));
        this.orderChangeDocArr.pop();
        this.orderChangeDocArr.push(JSON.parse(JSON.stringify(this.state.orderChangeDocument)));
        this.orderChangeDocNameArr.pop();
        this.orderChangeDocNameArr.push(JSON.parse(JSON.stringify(this.state.orderChangeDocumentName)));

    }

    /**
     * 追加撮影した写真をstateに保存する
     */
    @ActionBind(ChangeActionType.SAVE_ADD_DOCUMENT_IMAGES)
    private saveAddDocumentImages(param: any) {
        switch (param.key) {
            case 'nameIdentiImageAdd':
                if (!this.state.addIdentityImage) {
                    this.state.addIdentityImage = {};
                }
                if (!this.state.orderAddIdentityDocument) {
                    this.state.orderAddIdentityDocument = [];
                }
                if (param.image) {
                    this.state.addIdentityImage[param.code] = this.state.addIdentityImage[param.code]
                        ? [...this.state.addIdentityImage[param.code], param.image] : [param.image];
                    this.state.orderAddIdentityDocument.push(param.code);
                    // バックアップの最新要素を上書き(撮影時は回答チャットの表示がないため、書類種類のチャット時点としてバックアップする)
                    this.addIdentiArr.pop();
                    this.addIdentiArr.push(JSON.parse(JSON.stringify(this.state.addIdentityImage)));
                    this.addPhotoOrderArr.pop();
                    this.addPhotoOrderArr.push(JSON.parse(JSON.stringify(this.state.orderAddIdentityDocument)));
                }
                break;
            default:
                break;
        }
    }

    /**
     * 本人確認チャットでの書類パターン(A/B)ごとのスキップボタン押下有無を格納
     *
     * @private
     * @param param 書類パターンA/Bの撮影書類
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SAVE_SKIPPED_DOCUMENT_PATTERN)
    private saveSkippedDocumentPattern(param: { identificationDocument3A: string; identificationDocument3B: string; }) {
        this.state.isSelectedSkipButtonA = false;
        this.state.isSelectedSkipButtonB = false;
        if (param.identificationDocument3A === COMMON_CONSTANTS.SKIP_TEXT) {
            this.state.isSelectedSkipButtonA = true;
        }
        if (param.identificationDocument3B === COMMON_CONSTANTS.SKIP_TEXT) {
            this.state.isSelectedSkipButtonB = true;
        }
    }

    /**
     * 本人確認チャットでの書類パターンXの表示名称を保存
     *
     * @private
     * @param param 本人確認チャットでの書類パターンXの表示名称
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SAVE_DOCUMENT_X_NAME)
    private saveDocumentXName(param: { identificationDocument3XDisplayedName: string }) {
        this.state.identificationDocument3XDisplayedName = param.identificationDocument3XDisplayedName;
    }

    /**
     * 撮影した書類名を保存
     * @param param
     */
    @ActionBind(ChangeActionType.SAVE_DOCUMENT_NAMES)
    private saveDocumentNames(param) {
        if (param.idDocXName || param.idDocXName === '') {
            this.state.idDocNameX = param.idDocXName;
        }
        if (param.idDocAName || param.idDocAName === '') {
            this.state.idDocNameA = param.idDocAName;
        }
        if (param.idDocBName || param.idDocBName === '') {
            this.state.idDocNameB = param.idDocBName;
        }
        if (param.idDocCName || param.idDocCName === '') {
            this.state.idDocNameC = param.idDocCName;
        }
    }

    /**
     * 名寄せで撮影した書類名を保存
     * @param param
     */
    @ActionBind(ChangeActionType.SAVE_NAYOSE_DOCUMENT_NAMES)
    private saveNayoseDocumentNames(param) {
        if (param.idDocAName || param.idDocAName === '') {
            this.state.nayoseIdDocNameA = param.idDocAName;
        }
        if (param.idDocBName || param.idDocBName === '') {
            this.state.nayoseIdDocNameB = param.idDocBName;
        }
        if (param.idDocCName || param.idDocCName === '') {
            this.state.nayoseIdDocNameC = param.idDocCName;
        }
    }

    /**
     * 追加確認で撮影した書類名を保存
     * @param param
     */
    @ActionBind(ChangeActionType.SAVE_ADD_DOCUMENT_NAMES)
    private saveAddDocumentNames(param) {
        if (param.documentListAddName) {
            this.state.addIdDocName = param.documentListAddName;
        } else if (param.idDocAddName || param.idDocAddName === '') {
            this.state.addIdDocName = param.idDocAddName;
        }
    }

    /**
     * 本人確認チャットにおける書類パターンCの聴取有無を保存
     *
     * @private
     * @param param 本人確認チャットにおける書類パターンCの聴取有無
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SAVE_IS_ALREADY_CONFIRM_C)
    private saveIsAlreadyConfirmC(param: { isAlreadyConfirmC: boolean }) {
        this.state.isAlreadyConfirmC = param.isAlreadyConfirmC;
    }

    /**
     * 本人確認チャットにおける書類パターンBの聴取有無を保存
     *
     * @private
     * @param param 本人確認チャットにおける書類パターンCの聴取有無
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SAVE_IS_ALREADY_CONFIRM_B)
    private saveIsAlreadyConfirmB(param: { isAlreadyConfirmB: boolean }) {
        this.state.isAlreadyConfirmB = param.isAlreadyConfirmB;
    }

    /**
     * 行員認証段階の名寄せ処理で選択した口座情報と撮影した写真
     *
     * @private
     * @param {*} data
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.REGIST_NAME_IDENTITY_INFO)
    private registerNameIdentity(param: any) {
        this.state.existingAccountResetFlg = false;
        // 選択した口座情報
        this.state.selectedNameIdentityInfos = param.selectedDatas;
        // 写真のクリア・撮影順のクリア
        this.state.nameIdentiAddressImage = {};
        this.state.orderNameIdentiDocument = [];
        this.state.nameIdentiAccountImage = undefined;

        // 撮影した写真
        if (param.nameIdentiImage) {
            // 名寄せの住所写真
            this.state.nameIdentiAddressImage = param.nameIdentiImage;
        }
        if (param.propertiesConfrimImage && param.propertiesConfrimImage.length > 0) {
            // 名寄せの本人属性写真
            this.state.nameIdentiAccountImage = param.propertiesConfrimImage;
        }

        // 撮影順序を格納する
        if (param.photoOrder) {
            this.state.orderNameIdentiDocument = param.photoOrder;
        }
    }

    @ActionBind(ChangeActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.saveCurrentYamlInfo(params.fileInfo[0]);

            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(ChangeSignal.GET_QUESTION, params.pageIndex);
        }
    }

    @ActionBind(ChangeActionType.BRANCH_STATUS_INSERT)
    private branchStatusInsert(data: any) {
        console.log(data);
        if (data) {
            this.state.nextTabletApplyId = data;
            this.setSubmitData('nextTabletApplyId', data);
        }
    }

    @ActionBind(ChangeActionType.CLEAR)
    private clearStore() {
        this.initState();
    }

    /**
     * 連続諸届けで1回目終わるとき、クリアすべき部分データをクリア
     *
     * @private
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.CLEAR_PARTS)
    private clearPartStore() {
        this.state.transactionList = [];
        this.state.selectedNameIdentityInfos = [];
        this.state.changeDocumentImages = {};
        this.state.orderChangeDocument = [];
        this.state.orderChangeDocumentName = [];
        this.state.orderNameIdentiDocument = [];
        this.state.nameIdentiAccountImage = [];
        this.state.nameIdentiAddressImage = {};
        this.state.addIdentityImage = {};
        this.state.orderAddIdentityDocument = [];
        this.state.documentListAddName = '';
        this.state.duplicateAccountTenpoInfo = [];
        this.state.duplicateAccountCustomerSearchStatus = '0';
        this.state.isAddressChanged = false;
        this.state.isTelChanged = false;
        this.state.nameIdentityCustomerInfos = undefined;
        this.state.isNameChanged = false;
        this.state.submitData.nonDelivery = DeliveryStatus.ARRIVED;
        this.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.CLEAR);
        this.state.isLineGuided = false;
    }

    /**
     * 取引ぶりをtempPayloadに保存
     */
    private tradingCondition(name: string) {
        let tempPayload: string[] = [];

        switch (name) {
            case 'swipeCif':
                this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions.forEach((tradingCondition) => {
                    if (tradingCondition.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.houseLoan &&
                        tradingCondition.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.bondCustomers &&
                        tradingCondition.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.goldBullion &&
                        tradingCondition.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.safeDepositBox) {
                        tempPayload.push(this.getTradingConditionName(
                            this.state.submitData.birthdate, tradingCondition));
                    }
                });
                break;
            case 'nameUpdateCif':
                tempPayload = this.getTempPayload(this.state.submitData.nameidentiNameDifCifAcceptCheckResult);
                break;
            case 'addressUpdateCif':
                tempPayload = this.getTempPayload(this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt);
                break;
            case 'telUpdateCif':
                tempPayload = this.getTempPayload(this.state.submitData.nameidentiTelDifCifAcceptCheckResult);
                break;
            case 'allCif':
                if (this.state.submitData.isNameChange) {
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions.forEach((tradingCondition) => {
                        if ((tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.loanCreditOwned
                            || tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.Investment
                            || tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.specialDeposit)
                            && tempPayload.indexOf(tradingCondition.tradingConditionName) === -1) {
                            tempPayload.push(tradingCondition.tradingConditionName);
                        }
                    });
                }
                if (this.state.submitData.isAddressChange) {
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions.forEach((tradingCondition) => {
                        if ((tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.other
                            || tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.Investment
                            || tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.specialDeposit)
                            && tempPayload.indexOf(tradingCondition.tradingConditionName) === -1) {
                            tempPayload.push(tradingCondition.tradingConditionName);
                        }
                    });
                }
                if (this.state.isNameDifference) {
                    this.state.submitData.nameidentiNameDifCifAcceptCheckResult.forEach((item) => {
                        item.accounts.tradingConditions.forEach((tradingCondition) => {
                            if ((tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.loanCreditOwned
                                || tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.Investment
                                || tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.specialDeposit)
                                && tempPayload.indexOf(tradingCondition.tradingConditionName) === -1) {
                                tempPayload.push(tradingCondition.tradingConditionName);
                            }
                        });
                    });
                }
                if (this.state.isAddressDifference) {
                    this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt.forEach((item) => {
                        item.accounts.tradingConditions.forEach((tradingCondition) => {
                            if ((tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.other
                                || tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.Investment
                                || tradingCondition.tradingConditionCode === Constants.DBConsts.SpecTransactionCode.specialDeposit)
                                && tempPayload.indexOf(tradingCondition.tradingConditionName) === -1) {
                                tempPayload.push(tradingCondition.tradingConditionName);
                            }
                        });
                    });
                }
                break;
        }

        this.tempPayload = tempPayload;
    }

    /**
     * itemListにて表示する取引ぶりリストの作成
     */
    private getTempPayload(acceptCheckResult: Array<{ customerId: string, accounts: AcceptionResultAccount }>) {
        const tempPayload: string[] = [];
        acceptCheckResult.forEach((item) => {
            item.accounts.tradingConditions.forEach((tradingCondition) => {
                if ((tradingCondition.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.houseLoan &&
                    tradingCondition.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.bondCustomers &&
                    tradingCondition.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.goldBullion &&
                    tradingCondition.tradingConditionCode !== Constants.DBConsts.SpecTransactionCode.safeDepositBox) &&
                    tempPayload.indexOf(tradingCondition.tradingConditionName) === -1) {
                    const cifInfo = this.state.submitData.allCifInfos.filter(
                        (element) => element.customerId === item.customerId
                    );
                    tempPayload.push(this.getTradingConditionName(
                        cifInfo[0].birthDate, tradingCondition));
                }
            });
        });

        return tempPayload;
    }

    private getTradingConditionName(birthdate, tradingCondition) {
        return this.changeUtils.juniorNisaCheck(birthdate, tradingCondition) ?
            tradingCondition.tradingConditionName + COMMON_CONSTANTS.JPN_ERAS_UNDER_18_AGE :
            tradingCondition.tradingConditionName;
    }

    // カード交付方法に郵送をセット
    @ActionBind(ChangeActionType.SET_DATA)
    private setMailDelivery() {
        this.setSubmitData('receiptMethod', CashCardDeliveryType.MAIL_CODE);
    }

    // BCバンクカードSuica喪失届出済をセット
    @ActionBind(ChangeActionType.SET_BC_SUICA_LOST)
    private setBcSuicaLost() {
        this.setSubmitData('bcSuicaResult', BcSuicaResult.LOST);
    }

    @ActionBind(ChangeActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: any) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .min<ChatFlowMessageInterface>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus: ChatFlowMessageWithOrderIndexInterface = {
                            ...item,
                            question: this.replaceParams(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order
                        };
                        this.state.showChats.push(qus);
                        this.sendSignal(ChangeSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        const qus: ChatFlowMessageWithOrderIndexInterface = {
                            ...item,
                            question: this.replaceParams(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (qus.choices) {
                            qus.choices.filter((choice) => choice.imgSrc).forEach((choice) => {
                                choice.imgSrc.replace('./assets/imgs/', AppProperties.IMG_ROOT);
                            });
                        }
                        if (!item.options) {
                            item.options = {};
                        }
                        if (item.type === RENDER_TYPE.ITEM_LIST) {
                            this.tradingCondition(item.name);
                            qus.payload = [...this.tempPayload];
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order
                        };
                        const repeatOrderArr = this.state.showChats.filter((filterItem) => filterItem.order === params.order);
                        // orderは繰り返しの場合、orderIndexを追加する。
                        (repeatOrderArr && repeatOrderArr.length > 0) ? qus.orderIndex = repeatOrderArr.length : qus.orderIndex = 0;
                        this.state.showChats.push(qus);
                        this.sendSignal(ChangeSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => { console.log('Outside Done!'); });
        });
    }

    private replaceParams(str: string): string {
        if (str.indexOf('@') === -1) {
            return str;
        }

        this.replaceValues = [
            {
                key: '@nameKanji',
                value: this.state.submitData.holderName || this.state.submitData.firstName !== undefined ?
                    this.state.submitData.firstName + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastName :
                    this.state.submitData.firstNamegana !== undefined ?
                        this.state.submitData.firstNamegana + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNamegana :
                        this.state.submitData.firstNameKana !== undefined ?
                            this.state.submitData.firstNameKana + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKana :
                            this.labelService.labels.change.chat.customer
            },

            { key: '@FirstName', value: this.state.submitData.firstName },
            { key: '@LastName', value: this.state.submitData.lastName },
            {
                key: '@CustomerName',
                value: this.state.submitData.holderName || this.state.submitData.firstName !== undefined ?
                    this.state.submitData.firstName + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastName :
                    this.state.submitData.firstNamegana !== undefined ?
                        this.state.submitData.firstNamegana + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNamegana :
                        this.state.submitData.firstNameKana !== undefined ?
                            this.state.submitData.firstNameKana + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastNameKana :
                            this.state.submitData.nameKanjiBackup !== undefined ?
                                this.state.submitData.nameKanjiBackup :
                                this.state.submitData.nameKanji !== undefined ? this.state.submitData.nameKanji :
                                    this.state.submitData.nameKana
            },
            {
                key: '@AddressKana',
                value:
                    this.state.submitData.holderAddressPrefectureFurigana +
                    this.state.submitData.holderAddressCountyUrbanVillageFurigana +
                    (
                        this.state.submitData.holderAddressStreetNameFuriganaInput ||
                        this.state.submitData.holderAddressStreetNameFuriganaSelect ||
                        this.state.submitData.holderAddressStreetNameFuriKanaInput ||
                        this.state.submitData.holderAddressStreetFurigana || ''
                    ) + this.state.submitData.holderAddressHouseNumberFurigana || ''
            },
            { key: '@holderAddressPrefecture', value: this.state.submitData.holderAddressPrefectureFurigana },
            { key: '@holderAddressCountyUrbanVillage', value: this.state.submitData.holderAddressCountyUrbanVillageFurigana },
            {
                key: '@holderAddressStreetNameSelect',
                value:
                    (
                        this.state.submitData.holderAddressStreetNameFuriganaInput ||
                        this.state.submitData.holderAddressStreetNameFuriganaSelect ||
                        this.state.submitData.holderAddressStreetNameFuriKanaInput ||
                        this.state.submitData.holderAddressStreetFurigana ||
                        this.state.submitData.holderAddressStreetNameFuriKanaSelect || ''
                    )
            },
            {
                key: '@AddressWithoutHouseKana', value: this.state.submitData.holderAddressPrefectureFurigana +
                    this.state.submitData.holderAddressCountyUrbanVillageFurigana
            },
            {
                key: '@Address', value: this.state.submitData.holderAddressPrefecture +
                    this.state.submitData.holderAddressCountyUrbanVillage +
                    this.state.submitData.holderAddressStreet +
                    this.state.submitData.holderAddressHouseNumber
            },
            { key: '@NameKana', value: this.state.submitData.firstNameKana + this.state.submitData.lastNameKana },
            { key: '@Name', value: this.state.submitData.firstName + this.state.submitData.lastName },
            { key: '@ZipCode', value: this.state.submitData.firstZipCode + '-' + this.state.submitData.lastZipCode },
            {
                key: '@identificationDocument3X',
                value: this.changeUtils.getIdentificationDocument3(this.state.submitData.identificationDocument3X)
            }, {
                key: '@identificationDocument3A',
                value: this.changeUtils.getIdentificationDocument3(this.state.submitData.identificationDocument3A)
            }, {
                key: '@identificationDocument3B',
                value: this.changeUtils.getIdentificationDocument3(this.state.submitData.identificationDocument3B)
            }, {
                key: '@identificationDocument3C',
                value: this.changeUtils.getIdentificationDocument3(this.state.submitData.identificationDocument3C)
            }, {
                key: '@inputOtherDocument3X',
                value: this.state.submitData.documentListNameX
            }, {
                key: '@nameIdentityDocumentImg',
                value: this.state.submitData.nameIdentityDocumentImg
            }, {
                key: '@addressDocumentImg',
                value: this.state.submitData.addressDocumentImg
            }, {
                key: '@changeIdentityDocumentImg',
                value: this.state.submitData.changeIdentityDocumentImg
            }
        ];

        let result = str;
        this.replaceValues.forEach((element) => {
            if (result.indexOf(element.key) !== -1) {
                result = result.replace(element.key, element.value);
            }
        });
        return result;
    }

    @ActionBind(ChangeActionType.EDIT_CHAT)
    private editChat(params: any) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;
        const orderIndex = params.orderIndex;

        let i = -1;
        let index = -1;
        if (orderIndex !== null && orderIndex !== undefined) {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order && message.orderIndex === orderIndex) {
                    index = i;
                }
            });
        } else {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order) {
                    index = i;
                }
            });
        }

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }

        this.cleanSubmitData(answerOrder);
        this.resetIdentificationDocument(order, pageIndex);
    }

    @ActionBind(ChangeActionType.SET_ANSWER)
    private setAnswer(answer: { order: number, text: string, value: Array<{ key: string, value: string }> }) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        answer.order = this.getTopOrder();
        // modify answer
        const value = answer.value.map((item) => {
            if (item.key !== undefined && item.key.indexOf('Kana') !== -1) {
                item.key = item.key.replace('Kana', 'gana');
            }
            return item;
        });
        answer.value = value;
        chat.answer = answer;
        if (answer.value) {
            answer.value.forEach((item) => {
                this.setSubmitData(item.key, item.value);
            });
        }
    }

    /**
     * Skip node
     * @param nextOrder the order skip to
     */
    @ActionBind(ChangeActionType.SKIP)
    private skip() {
        this.state.showChats.pop();
    }

    @ActionBind(ChangeActionType.SET_STATE_SUBMIT_DATA_VALUE)
    private setStateSubmitDataValue(data: any) {
        if (data) {
            this.setSubmitData(data.name, data.value);
        }
    }

    @ActionBind(ChangeActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    @ActionBind(ChangeActionType.SET_SHOW_NAME_PAGE)
    private setshowNamePage(data: any) {
        this.setSubmitData('showNamePage', data);
        console.log(data);
    }

    @ActionBind(ChangeActionType.SET_SHOW_ADRRESS_PAGE)
    private setshowAddressPage(data: any) {
        this.setSubmitData('showAddressPage', data);
        console.log(data);
    }

    @ActionBind(ChangeActionType.COPY_SUBMIT_DATA)
    private copySubmitData() {
        this.state.copySubmitData = Object.assign(new ChangeSubmitEntity(), this.state.submitData);
    }

    @ActionBind(ChangeActionType.SUBMIT_DATA_BACKUP)
    private submitDataBackup() {
        this.state.submitDataBackup = Object.assign(new ChangeSubmitEntity(), this.state.submitData);
    }

    @ActionBind(ChangeActionType.BACKUP_CHANGE_IDENTI_DOCS)
    private backupChangeIdentiDocs() {
        this.state.copyChangeDocumentImages = this.state.changeDocumentImages;
        this.state.copyOrderChangeDocument = this.state.orderChangeDocument;
        this.state.copyOrderChangeDocumentName = this.state.orderChangeDocumentName;
        this.state.copyAddIdentityImage = this.state.addIdentityImage;
        this.state.copyOrderAddIdentityDocument = this.state.orderAddIdentityDocument;
    }

    @ActionBind(ChangeActionType.BACKUP_ADD_IMAGES)
    private backupAddImages() {
        // 追加確認聴取書類のバックアップ
        this.state.copyAddIdentityImage = this.state.addIdentityImage;
        this.state.copyOrderAddIdentityDocument = this.state.orderAddIdentityDocument;
        // 追加確認書類のクリア
        this.state.addIdentityImage = {};
        this.state.orderAddIdentityDocument = [];
        // マスキングのチェックボックスをクリア
        this.state.checkboxStatus.isAllMaskingStatus = false;
    }

    @ActionBind(ChangeActionType.RESET_SUBMIT_DATA)
    private resetSubmitData(param: any) {
        this.state.showChats = param;
        this.state.submitData = this.state.submitDataBackup;
        this.state.submitDataBackup = null;
    }

    @ActionBind(ChangeActionType.RESET_CHANGE_IDENTI_DOCUMENTS)
    private resetChangeIdentiDocuments(params: any) {
        this.state.changeDocumentImages = params.copyChangeDocumentImages;
        this.state.orderChangeDocument = params.copyOrderChangeDocument;
        this.state.orderChangeDocumentName = params.copyOrderChangeDocumentName;
        this.state.addIdentityImage = this.state.copyAddIdentityImage;
        this.state.orderAddIdentityDocument = this.state.copyOrderAddIdentityDocument;
    }

    @ActionBind(ChangeActionType.BACKUP_ADD_IMAGES_RESTORE)
    private backupAddImagesRestore(params: any) {
        // 追加確認聴取書類のバックアップを戻す
        this.state.addIdentityImage = this.state.copyAddIdentityImage;
        this.state.orderAddIdentityDocument = this.state.copyOrderAddIdentityDocument;
    }

    @ActionBind(ChangeActionType.CLEAR_IDENTI_DATA)
    private clearIdentiData() {
        this.state.submitData = this.state.originChangeSubmitData;
    }

    @ActionBind(ChangeActionType.CLEAR_CHANGE_IDENTI_DOCS)
    private clearChangeIdentiDocs() {
        this.state.changeDocumentImages = {};
        this.state.orderChangeDocument = [];
        this.state.orderChangeDocumentName = [];
        // クリアしたchangeDocumentImagesをバックアップ
        this.setSubmitData('clearChangeIdentiDocs', 'clearChangeIdentiDocs');
    }

    @ActionBind(ChangeActionType.CLEAR_ADD_CHECK_DATA)
    private clearAddCheckData() {
        this.setStateSubmitDataValue({ name: 'receiptMethod', value: undefined });
        this.setStateSubmitDataValue({ name: 'bcSuicaResult', value: undefined });
        this.setStateSubmitDataValue({ name: 'americanSuggestionInformationStatus', value: undefined });
        this.setStateSubmitDataValue({ name: 'firstNameRoma', value: undefined });
        this.setStateSubmitDataValue({ name: 'lastNameRoma', value: undefined });
    }

    @ActionBind(ChangeActionType.SET_ORIGIN_SUBMIT_DATA)
    private setOriginChangeSubmitData() {
        this.state.originChangeSubmitData = Object.assign(new ChangeSubmitEntity(), this.state.submitData);
    }

    @ActionBind(ChangeActionType.DIFFERENCE_FLG_BACKUP)
    private differenceFlgBackup() {
        this.state.isNameDifferenceBackup = this.state.isNameDifference;
        this.state.isAddressDifferenceBackup = this.state.isAddressDifference;
        this.state.isTelphoneDifferenceBackup = this.state.isTelphoneDifference;
    }

    @ActionBind(ChangeActionType.RETRIEVE_DROP_LIST)
    private retrieveDropList(data) {
        this.state.dropDownList = data;
    }

    @ActionBind(ChangeActionType.BRANCH_INFO_INSERT)
    private branchInfoInsert(data) {
        this.sendSignal(ChangeSignal.SUCCESS_INSERT_INFO);
    }

    @ActionBind(ChangeActionType.CHAT_FLOW_COMPELETE)
    private chatFlowCompelete(nextChatName: string) {
        this.sendSignal(ChangeSignal.CHAT_FLOW_COMPELETE, nextChatName);
    }

    @ActionBind(ChangeActionType.RESET_LAST_NODE)
    private resetLastNode() {
        const lastNode = this.getState().showChats.pop();
        this.getNextChatByAnswer({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    /**
     * 指定した順番をレセット
     * @param params パラメーター
     */
    @ActionBind(ChangeActionType.RESET_TO_ORDER)
    private resetToOrder(params: { order: number, pageIndex: number }) {
        this.getState().showChats.pop();
        this.getNextChatByAnswer(params);
    }

    @ActionBind(ChangeActionType.SET_BANKCLERK_ID)
    private setBankclerkId(params: any) {
        this.setSubmitData('userMngNo', params.bankclerkId);
    }

    /**
     * cif情報をセット
     */
    @ActionBind(ChangeActionType.SET_CIF_INFO)
    private setCifInfo(info: any) {
        Object.keys(info).forEach((key) => {
            this.setSubmitData(key, info[key]);
        });
    }

    /**
     * ConfirmデータをStateにセットする
     * @param params
     */
    @ActionBind(ChangeActionType.GET_CONFIRM_PAGE_TEMPLATE)
    private loadConfirmTemplate(params: any) {
        if (params) {
            this.state.questions[params.pageIndex] = params.data;
            this.state.submitData.fileInfo = params.fileInfo;
        }
    }

    /**
     * Save yaml file Information
     */
    private saveCurrentYamlInfo(params: any) {
        this.state.currentFileInfo.yamlId = params.id;
        this.state.currentFileInfo.screenId = params.screenId;
        this.state.currentFileInfo.screenName = params.screenName;
    }

    /**
     * Deal with customer status
     * @param params info in chat flow
     */
    @ActionBind(ChangeActionType.ACCEPT_CHECK_SWIPE_CIF)
    private requestCustomerStatus(params: any) {

        // レスポンスをsubmitDataに格納
        this.setSubmitData('swipeCifAcceptCheckResult',
            { customerId: this.state.submitData.customerId, account: params.response.accounts[0] });

        this.sendSignal(ChangeSignal.ACCEPT_CHECK_SWIPE_CIF);
    }

    /**
     * 受付可否チェック(住変)にてエラーになった旨送信する
     * @param data
     */
    @ActionBind(ChangeActionType.UNACCEPTABLES_NG)
    private signalUnacceptablesNg(data: any) {
        this.sendSignal(ChangeSignal.UNACCEPTABLES_NG, data);
    }

    /**
     * 口座存在チェック結果設定
     * @param data response data
     */
    @ActionBind(ChangeActionType.GET_ACCOUNT_EXISTING)
    private signalAccountExistenceCheckResult(data: any) {
        // 口座存在チェック結果を発送する
        this.sendSignal(ChangeSignal.GET_CHECK_ACCOUNT_EXISTING, data);
    }

    /**
     * CIF情報照会設定
     * @param data response data
     */
    @ActionBind(ChangeActionType.SET_CIF_INFORMATION)
    private setCifInformation(data: any) {
        if (data && data.errorResponse && data.errorResponse.values) {
            const {
                processNo,
                uri,
                errorResponse: {
                    values: { errReason = '' }
                }
            } = data;
            if (errReason && uri) {
                if (this.errorMessageService.applyBusinessType === this.APPLY_BUSI_TYPE) {
                    this.errorMessageService.handleExternalError({
                        errReason,
                        processNo,
                        applyBusinessType: this.APPLY_BUSI_TYPE,
                        uri
                    },
                        '',
                        () => {
                            if (errReason === 'Q00161') {
                                // 当申込はタブレットでは受付できません。（CIF件数オーバー）
                                this.sendSignal(ChangeSignal.RETURN_TOP_COMPLETE);
                            }
                            if (errReason === 'Q00004') {
                                this.state.getCifInfoFlag = true;
                            }
                        });
                    if (!this.state.getCifInfoFlag) {
                        return;
                    }
                } else {
                    this.errorMessageService.handleExternalErrorByReason(errReason);
                }
            }
        }
        this.state.cifInfoInquiryList = data.cifInfoInquiryResponseList;
        this.state.cifInfo = data.cifInfo;   // 店舗名リスト用
        let entity: CifInfoInquiryResponseEntity;

        entity = data.cifInfoInquiryResponse;

        // SubmitDataに本人基本情報設定を行う
        this.state.cifInfoInquiry = entity;

        // 基本情報を設定する
        CifInformationUtils.setCifBasicInfoForCommon(this.state.submitData, this.keysArr, entity);

        // 地域コード
        this.setSubmitData('holderRegionCode', entity.regionCode);
        // swipeCif
        this.setSubmitData('swipeCif', entity.branchCif);

        // 店舗名
        this.setSubmitData('branchName', entity.branchName);

        // 全店CIF
        this.setSubmitData('wholeCif', data.wholeCif);

        // 情報取得完了
        this.sendSignal(ChangeSignal.GET_CIF_INFORMATION);
    }

    /**
     * 変更内容→CIF情報照会へ転換する
     * @param data 変更データ
     */
    @ActionBind(ChangeActionType.TRANSFER_TO_CIF_INFORMATION)
    private transferModifyToCifInfo(data: any) {
        for (const key in data) {
            this.setSubmitData(key, data[key]);
        }
    }

    /**
     * 電話番号変更フロー中に、携帯電話、自宅電話番号をスキップする場合
     * 携帯電話入力チャットに戻る
     */
    @ActionBind(ChangeActionType.NEED_INPUT_PHONE_NO)
    private needInputPhoenNo() {
        const chats = this.state.showChats.splice(-4, 4);
        if (chats && chats.length > 0) {
            const chat = chats[0];

            this.getNextChatByAnswer({
                order: chat.order,
                pageIndex: chat.pageIndex
            });
        }
    }

    /**
     * 暗号番号認証後、入力したパスワードを保存する
     * @param data パスワード
     */
    @ActionBind(ChangeActionType.SAVING_PASSWORD)
    private settingPassword(data: string) {
        this.setSubmitData('cashCardFirstPwd4bits', data);
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param data QRコード受付情報
     */
    @ActionBind(ChangeActionType.SET_SWIPE_INFO)
    private setSwipeInfo(data: any) {
        // 申請ID
        this.state.tabletApplyId = data.tabletApplyId;
        this.setSubmitData('tabletApplyId', data.tabletApplyId);
        // 受付店舗番号
        this.state.receptionTenban = data.receptionTenban;
        this.setSubmitData('receptionTenban', data.receptionTenban);
    }

    /**
     * 本人情報更新結果を発送。
     * @param data 本人情報更新結果
     */
    @ActionBind(ChangeActionType.GET_UPDATE_HOLDER_INFO)
    private sendUpdateHolderInfoResult(data: any) {
        this.sendSignal(ChangeSignal.UPDATE_CHANGE_SUCCESS, data);
    }

    /**
     * 本人情報更新結果（電話番号変更だけ）を発送。
     * @param data 本人情報更新結果
     */
    @ActionBind(ChangeActionType.GET_UPDATE_HOLDER_INFO_TELEPHONE_NO)
    private sendUpdateHolderTelephoneNo(data: any) {
        this.sendSignal(ChangeSignal.UPDATE_CHANGE_SUCCESS_TELEPHONE_NO, data);
    }

    /**
     * 口座開設支店店番を設定する
     * @param params 支店情報
     */
    @ActionBind(ChangeActionType.SET_AGENCY_BRANCH_INFO)
    private setAgencyBranchInfo(params: any) {
        this.setSubmitData('branchNo', params.branchNo);
    }

    private setSubmitData(key, value) {
        if (key !== undefined) {
            this.state.submitData[key] = value;
            this.keyPush(key, value);
        }
    }

    private keyPush(key: any, value: any) {
        if (value === null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                this.keysArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1) {
            this.keysArr.push(key);
            this.backupData();
        } else {
            const index = this.keysArr.indexOf(key);
            this.keysArr[index] = moment().format(COMMON_CONSTANTS.DATE_FORMAT_YYYYMMDDHHMMSS);
            this.keysArr.push(key);
            this.backupData();
        }
    }

    /**
     * 写真、撮影順序をバックアップする。
     */
    private backupData() {
        const backupChangeDocImage = this.state.changeDocumentImages ?
            JSON.parse(JSON.stringify(this.state.changeDocumentImages)) : {};
        this.changeDocArr.push(backupChangeDocImage);
        const backupOrderChangeDoc = this.state.orderChangeDocument ?
            JSON.parse(JSON.stringify(this.state.orderChangeDocument)) : [];
        this.orderChangeDocArr.push(backupOrderChangeDoc);

        const backupOrderChangeDocName = this.state.orderChangeDocumentName ?
            JSON.parse(JSON.stringify(this.state.orderChangeDocumentName)) : [];
        this.orderChangeDocNameArr.push(backupOrderChangeDocName);

        const backupAddIdentiImage = this.state.addIdentityImage ?
            JSON.parse(JSON.stringify(this.state.addIdentityImage)) : {};
        this.addIdentiArr.push(backupAddIdentiImage);
        const backupPhotoOrder = this.state.orderAddIdentityDocument ?
            JSON.parse(JSON.stringify(this.state.orderAddIdentityDocument)) : [];
        this.addPhotoOrderArr.push(backupPhotoOrder);
    }

    private cleanSubmitData(remain: number) {
        this.keysArr = this.keysArr.slice(0, remain);

        for (const item in this.state.submitData) {
            if (item.startsWith('get')) {
                continue;
            }
            if (this.keysArr.indexOf(item) < 0 && item !== SubmitDataKey.LOG_FILE_INFO) {
                this.state.submitData[item] = undefined;
            }
        }

        this.changeDocArr = this.changeDocArr.slice(0, remain);
        this.state.changeDocumentImages = this.changeDocArr[remain - 1] ?
            JSON.parse(JSON.stringify(this.changeDocArr[remain - 1])) : {};
        this.orderChangeDocArr = this.orderChangeDocArr.slice(0, remain);
        this.state.orderChangeDocument = this.orderChangeDocArr[remain - 1] ?
            JSON.parse(JSON.stringify(this.orderChangeDocArr[remain - 1])) : [];

        this.orderChangeDocNameArr = this.orderChangeDocNameArr.slice(0, remain);
        this.state.orderChangeDocumentName = this.orderChangeDocNameArr[remain - 1] ?
            JSON.parse(JSON.stringify(this.orderChangeDocNameArr[remain - 1])) : [];

        this.addIdentiArr = this.addIdentiArr.slice(0, remain);
        this.state.addIdentityImage = this.addIdentiArr[remain - 1] ?
            JSON.parse(JSON.stringify(this.addIdentiArr[remain - 1])) : {};
        this.addPhotoOrderArr = this.addPhotoOrderArr.slice(0, remain);
        this.state.orderAddIdentityDocument = this.addPhotoOrderArr[remain - 1] ?
            JSON.parse(JSON.stringify(this.addPhotoOrderArr[remain - 1])) : [];
    }

    private getTopOrder() {
        return this.keysArr.length;
    }

    /**
     * 口座残高照会
     * @param data 口座残高照会のリスポンス
     */
    @ActionBind(ChangeActionType.INQUIRE_ACCOUNT_BALANCE)
    private inquireAccountBalance(data: any) {
        this.setSubmitData('swipeCardType', data.responseList[0].holderCardType);
        this.setSubmitData('holderCardDesign', data.responseList[0].holderCardDesign);
        this.setSubmitData('holderCardType', data.responseList[0].holderCardType);
        this.setSubmitData('holderCardMsIcType', data.responseList[0].holderCardMsIcType);
        // 情報取得完了
        this.sendSignal(ChangeSignal.INQUIRE_ACCOUNT_BALANCE);
    }

    /**
     * 各業務フローからのQrコードをstateにセット。
     * @param params 各業務フローからのQrコード情報
     */
    @ActionBind(ChangeActionType.SET_SWIPE_INFO_FROM_CHAT_FLOW)
    private setSwipeInfoFromChatFlow(params: any) {
        if (params) {
            // キャッシュカードのパスワード
            this.setSubmitData('cashCardFirstPwd4bits', params.password);
            this.state.tabletApplyId = params.tabletApplyId;

            // スワイプ情報をセット
            this.setSubmitData('swipeCif', params.swipeCif);
            this.setSubmitData('accountNo', params.accountNo);
            this.setSubmitData('branchNo', params.branchNo);
            this.setSubmitData('accountType', params.accountType);
            this.setSubmitData('receptionBranchNo', params.receptionBranchNo);
            this.setSubmitData('receptionNo', params.receptionNo);
            this.setSubmitData('receptionTime', params.receptionTime);
        }
    }

    /**
     * 本人確認書類データをクリアする
     */
    @ActionBind(ChangeActionType.CLEAR_DOCUMENTS)
    private clearStoreDocuments() {
        // 本人確認書類をクリアする
        this.state.changeDocumentImages = {};
        this.state.orderChangeDocument = [];
        this.state.orderChangeDocumentName = [];
        // コピー徴求ができない理由
        this.setSubmitData('holderNoCopyReason', null);
        // 発行元
        this.setSubmitData('holderPublisher', null);
        // 発行日
        this.setSubmitData('holderPublishDate', null);
        // 記号番号
        this.setSubmitData('holderSignNo', null);
    }

    /**
     * Set the item as the current time of server
     * @param data system time and the key of item
     */
    @ActionBind(ChangeActionType.SET_SYSTEM_TIME)
    private setAsSystemTime(data: any) {
        this.setSubmitData(data.key, data.systemTime);
    }

    /**
     * get holderZipCode 郵便番号
     * @param data データ
     */
    @ActionBind(ChangeActionType.GET_HOLDER_ZIP_CODE)
    private getHolderZipCode(data: any) {
        this.setSubmitData('firstZipCode', data.substring(0, 3));
        this.setSubmitData('lastZipCode', data.substring(3, 7));
        this.sendSignal(ChangeSignal.GET_HOLDER_ZIP_CODE);
    }

    /**
     * get holderZipCode 郵便番号
     * @param data データ
     */
    @ActionBind(ChangeActionType.SET_DEFAULT_ZIP_CODE)
    private setDefaultZipCode() {
        this.setSubmitData('firstZipCode', ZipCode.FIRST_ZIP_CODE);
        this.setSubmitData('lastZipCode', ZipCode.LAST_ZIP_CODE);
    }

    /**
     * 同一名義人の重複CIF情報をStateに設定
     *
     * @private
     * @param {DuplicateAccountInfoResponse} data
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.GET_SAME_CUSTOMERS_INFO)
    private setDuplicateAccountInfos(data: DuplicateAccountInfoResponse) {
        // 本人口座がかならずがあるので、1件以上変えてくる
        if (data.duplicateAccountInfos && data.duplicateAccountInfos.length > 0) {
            // リスポンス情報から本人の口座を外してSTATEに設定する
            this.state.duplicateAccountTenpoInfo = data.duplicateAccountInfos.filter(
                (item) => {
                    return item.customerId !== this.state.submitData.customerId;
                }
            );
        }

        // 顧客検索結果を保存
        this.state.duplicateAccountCustomerSearchStatus = data.customerSearchStatus;
        // 名寄せ口座がない場合は、追加確認チャットボタン活性化
        if (data.duplicateAccountInfos.length === 1 || data.customerSearchStatus === CustomerSearch.UN_PRINTED) {
            this.state.activeAddButton = true;
        }
        this.sendSignal(ChangeSignal.GET_SAME_CUSTOMERS_INFO);
    }

    @ActionBind(ChangeActionType.REGEST_ADD_CHECK_DATA)
    private registAddCheckData(data: any) {
        this.state.submitData.receiptMethod = data.receiptMethod;
        this.state.submitData.americanSuggestionInformationStatus = data.americanSuggestionInformationStatus;
        this.state.submitData.firstNameRoma = data.firstNameRoma;
        this.state.submitData.lastNameRoma = data.lastNameRoma;
        this.state.submitData.bcSuica = data.bcSuica;
        this.state.addIdentityImage = data.addIdentityImage;
        this.state.orderAddIdentityDocument = data.orderAddIdentityDocument;
        this.state.documentListAddName = data.documentListAddName;
        this.saveAddDocumentNames(data);
        if (this.state.addIdentityImage && this.state.orderAddIdentityDocument) {
            this.resetNotMaskingConfirmImages(ClearChangeImagesClickRecordType.ADD_IDENTITY);
        }
    }

    // modify checkbox status
    @ActionBind(ChangeActionType.MODIFY_CHECKBOX_STATUS)
    private modifyCheckboxStatus(name: string) {
        this.state.checkboxStatus[name] = !this.state.checkboxStatus[name];    // ture
    }

    @ActionBind(ChangeActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES)
    private removeNotMaskingConfirmImages(data) {
        const { documentName, index } = data;
        this.state.notMaskingConfirmImages[documentName].splice(index, 1);
    }

    @ActionBind(ChangeActionType.RESET_NOT_MASKING_CONFIRM_IMAGES)
    private resetNotMaskingConfirmImages(type: ClearChangeImagesClickRecordType) {
        const _changeDocumentClearFn = () => {
            // 本人確認住所写真の枚数によってリセット
            let index = 0;
            this.state.notMaskingConfirmImages.changeDocumentImages = [];
            Object.keys(this.state.changeDocumentImages).forEach(
                (item) => {
                    this.state.changeDocumentImages[item].forEach(() => {
                        this.state.notMaskingConfirmImages.changeDocumentImages.push(index);
                        index++;
                    });
                });
            // 名寄せ分のリセット
            this.state.notMaskingConfirmImages.nameIdentiAddressImage = [];
            // 追加確認分のリセット
            let addIndex = 0;
            this.state.notMaskingConfirmImages.addIdentityImage = [];
            Object.keys(this.state.addIdentityImage).forEach(
                (item) => {
                    this.state.addIdentityImage[item].forEach(() => {
                        this.state.notMaskingConfirmImages.addIdentityImage.push(addIndex + index);
                        addIndex++;
                    });
                });
        };

        const _nameIdentiAddressClearFn = () => {
            // 名寄せ確認住所写真の枚数によってリセット
            let index = 0;
            let plusIndex = 0;
            Object.keys(this.state.changeDocumentImages).forEach((item) => {
                this.state.changeDocumentImages[item].forEach(() => {
                    plusIndex++;
                });
            });
            this.state.notMaskingConfirmImages.nameIdentiAddressImage = [];
            Object.keys(this.state.nameIdentiAddressImage).forEach(
                (item) => {
                    this.state.nameIdentiAddressImage[item].forEach(() => {
                        this.state.notMaskingConfirmImages.nameIdentiAddressImage.push(index + plusIndex);
                        index++;
                    });
                });
            // 追加確認分のリセット
            this.state.notMaskingConfirmImages.addIdentityImage = [];
        };

        const _addIdentiAddressClearFn = () => {
            // 追加確認写真の枚数によってリセット
            let index = 0;
            let plusIndex = 0;
            let addIndex = 0;
            Object.keys(this.state.changeDocumentImages).forEach((item) => {
                this.state.changeDocumentImages[item].forEach(() => {
                    plusIndex++;
                });
            });
            Object.keys(this.state.nameIdentiAddressImage).forEach(
                (item) => {
                    this.state.nameIdentiAddressImage[item].forEach(() => {
                        index++;
                    });
                });
            this.state.notMaskingConfirmImages.addIdentityImage = [];
            Object.keys(this.state.addIdentityImage).forEach(
                (item) => {
                    this.state.addIdentityImage[item].forEach(() => {
                        this.state.notMaskingConfirmImages.addIdentityImage.push(addIndex + index + plusIndex);
                        addIndex++;
                    });
                });
        };
        switch (type) {
            case ClearChangeImagesClickRecordType.CHANGE_DOCUMENT:
                // 本人確認住所写真の枚数によってリセット
                _changeDocumentClearFn();
                break;
            case ClearChangeImagesClickRecordType.NAME_IDENTITY:
                // 名寄せ確認住所写真の枚数によってリセット
                _nameIdentiAddressClearFn();
                break;
            case ClearChangeImagesClickRecordType.ADD_IDENTITY:
                // 追加確認写真の枚数によってリセット
                _addIdentiAddressClearFn();
                break;
            case ClearChangeImagesClickRecordType.CLEAR:
                this.state.notMaskingConfirmImages.nameIdentiAddressImage = [];
                this.state.notMaskingConfirmImages.changeDocumentImages = [];
                this.state.notMaskingConfirmImages.addIdentityImage = [];
                break;

            default:
                break;
        }
    }

    @ActionBind(ChangeActionType.EDIT_SUBMIT_DATA)
    private editSubmitData(data: { index, key, val }) {
        if (data.key) {
            // indexが存在するときに、配列のフィールドに画像を設定する。
            // indexが存在しないときに、配列ではないフィールドに画像を設定する
            (data.index !== undefined && data.index !== null) ?
                this.state[data.key][data.index] = data.val :
                this.state[data.key] = data.val;
        }
    }

    @ActionBind(ChangeActionType.EDIT_SUBMIT_DATA_NESTED)
    private editSubmitDataNested(data: { index, key, nestKey, val }) {
        if (data.key) {
            // indexが存在するときに、入れ子のキーに紐づく配列の中のフィールドに画像を設定する。
            // indexが存在しないときに、入れ子のキーに紐づく配列ではないフィールドに画像を設定する。
            (data.index !== undefined && data.index !== null) ?
                this.state[data.key][data.nestKey][data.index] = data.val :
                this.state[data.key][data.nestKey] = data.val;
        }
    }
    @ActionBind(ChangeActionType.CLEAR_EXISTING_ACCOUNT)
    private clearExistingAccount() {

        // 選択した口座情報
        this.state.selectedNameIdentityInfos = [];
        // 写真のクリア・撮影順のクリア
        this.state.nameIdentiAddressImage = {};
        this.state.orderNameIdentiDocument = [];
        this.state.nameIdentiAccountImage = [];

        this.state.existingAccountResetFlg = true;
    }

    @ActionBind(ChangeActionType.SET_CUSTOMER_APPLY_START_DATE)
    private setCustomerApplyStartDate(data: { systemTime: string }) {
        this.setSubmitData('customerApplyStartDate', data.systemTime);
        this.sendSignal(ChangeSignal.SUCCESS_SET_CUST_START_TIME);
    }

    @ActionBind(ChangeActionType.ACCEPT_CHECK_FOR_NAME_DIF_CIF)
    private onAcceptCheckForNameDifCif(data: { res: AcceptionResult, difItems: ChangeDifferenceEntity[] }) {

        // Stateに登録,送信レコードと受信レコードをマッピングする
        const sendedAccount: CifInfo[] = this.getSendedAccount(data.difItems);

        const acceptResult: Array<{ customerId: string, accounts: AcceptionResultAccount }>
            = this.getAcceptCheckResult(sendedAccount, data);

        this.setSubmitData('nameidentiNameDifCifAcceptCheckResult', acceptResult);

        this.sendSignal(ChangeSignal.ACCEPT_TARGET_FOR_NAME_DIF_CIF, data.res);
    }

    @ActionBind(ChangeActionType.ACCEPT_CHECK_FOR_TEL_DIF_CIF)
    private onAcceptCheckForTelDifCif(data: { res: AcceptionResult, difItems: ChangeDifferenceEntity[] }) {

        // Stateに登録,送信レコードと受信レコードをマッピングする
        const sendedAccount: CifInfo[] = this.getSendedAccount(data.difItems);

        const acceptResult: Array<{ customerId: string, accounts: AcceptionResultAccount }>
            = this.getAcceptCheckResult(sendedAccount, data);

        this.setSubmitData('nameidentiTelDifCifAcceptCheckResult', acceptResult);

        this.sendSignal(ChangeSignal.ACCEPT_TARGET_FOR_TEL_DIF_CIF, data.res);
    }

    @ActionBind(ChangeActionType.ACCEPT_CHECK_FOR_ADDRESS_DIF_CIF)
    private onAcceptCheckForAddressDifCif(data: { res: AcceptionResult, difItems: ChangeDifferenceEntity[] }) {

        // Stateに登録,送信レコードと受信レコードをマッピングする
        const sendedAccount: CifInfo[] = this.getSendedAccount(data.difItems);

        const acceptResult: Array<{ customerId: string, accounts: AcceptionResultAccount }>
            = this.getAcceptCheckResult(sendedAccount, data);

        this.setSubmitData('nameidentiAddressDifCifAcceptCheckRestlt', acceptResult);

        this.sendSignal(ChangeSignal.ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF, data.res);
    }

    /**
     * 受付可否チェックにかけたCIFの配列の作成
     */
    private getSendedAccount(difItems: ChangeDifferenceEntity[]) {
        const sendedAccount: CifInfo[] = [];

        this.state.submitData.allCifInfos.forEach((element) => {
            if (element.customerId !== this.state.submitData.customerId) {
                difItems.forEach((difItem) => {
                    if (element.customerId === difItem.customerId && difItem.isDifference) {
                        sendedAccount.push(element);
                    }
                });
            }
        });

        return sendedAccount;
    }

    private getAcceptCheckResult(sendedAccount: CifInfo[], data: { res: AcceptionResult, difItems: ChangeDifferenceEntity[] }) {
        const acceptResult: Array<{ customerId: string, accounts: AcceptionResultAccount }> = [];

        sendedAccount.forEach((item, index) => {
            data.difItems.forEach((difItem) => {
                if (item.customerId === difItem.customerId && difItem.isDifference) {
                    acceptResult.push({ customerId: item.customerId, accounts: data.res.accounts[index] });
                }
            });
        });

        return acceptResult;
    }

    /**
     * set 地域コード情報（地域コード と 地域コード判定方法)
     * @param data データ
     */
    @ActionBind(ChangeActionType.SEARCH_REGION_CODE)
    private setRegionCode(data: any) {
        this.state.regionCodeInfo.regionCode = data.regionCode;
        this.state.regionCodeInfo.regionCodeDeterminationMethod = data.regionCodeDeterminationMethod;
        this.sendSignal(ChangeSignal.SEARCH_REGION_CODE_COMPLETE, data);
    }

    /**
     * 文字チェック成功の場合、シグナル送信
     *
     * @private
     * @param {CharacterCheckResult} response
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.CHARACTER_CHECK)
    private characterCheck(response: CharacterCheckResult) {
        this.sendSignal(ChangeSignal.CHARACTER_CHECK);
    }

    private resetIdentificationDocument(order, pageIndex) {
        const chat = this.state.questions[pageIndex].find((item) => item.order === order);
        // 本人確認書類が「住民票の写し（原本）」を選択された場合、「記載あり」→「記載なし」変更された時に、本人確認書類が「null」になることを対応
        if (chat && /@\S+にマイナンバーは記載されていますか？/.test(chat.question)) {
            const propertyNm = chat.question.slice(1, chat.question.indexOf('に'));
            const filter = this.state.showChats.filter((show) => show.name === propertyNm);
            if (filter && filter.length > 0) {
                const answer = filter[filter.length - 1].answer;
                answer.value.forEach((element) => {
                    this.setSubmitData(element.key, element.value);
                });
                this.setSubmitData(propertyNm + 'Text', answer.text);
            }
        }
    }
    /**
     * 名寄せ候補の国籍コードを設定
     */
    @ActionBind(ChangeActionType.SET_NATIONALITY)
    private setNationality() {
        this.state.duplicateAccountTenpoInfo.forEach((item) => {
            for (const element of this.state.nameIdentityCustomerInfos.cifInfoInquiryResponses) {
                if (item.customerId === element.customerId) {
                    item.nationality = element.nationalityCode;
                    break;
                }
            }
        });
        this.state.nameIdentityCustomerInfos = undefined;
    }

    /**
     * フィルタリングシステム検索
     * @param params フィルタリングシステム検索パラメーター
     */
    @ActionBind(ChangeActionType.FILTERING_INQUIRY)
    private filterInquiry(data: any) {
        Object.keys(data).forEach((key) => {
            this.setSubmitData(key, data[key]);
        });
        this.setSubmitData('outStatusText', data.outStatus === OutStatus.OFF ? OutStatusText.OFF : OutStatusText.ON);
        this.state.lastFilteringResult = data;
        this.filterInquiryResultBackup();
    }

    /**
     * フィルタリング結果をバックアップ
     */
    private filterInquiryResultBackup() {
        this.state.submitDataBackup.outStatus = this.state.submitData.outStatus;
        this.state.submitDataBackup.outStatusText = this.state.submitData.outStatusText;
        this.state.originChangeSubmitData.outStatus = this.state.submitData.outStatus;
        this.state.originChangeSubmitData.outStatusText = this.state.submitData.outStatusText;
    }

    /**
     * フィルタリングシステムのパラメタを保存。
     */
    @ActionBind(ChangeActionType.SET_LAST_FILTERING_PARAMS)
    private setLastFilteringParams(data: FilteringParameterEntity) {
        this.state.lastFilteringParameter = data;
    }

    /**
     * 内部API: 保有通帳・カード・印鑑情報照会のレスポンスをstateにセットする
     * @param data APIのレスポンス
     */
    @ActionBind(ChangeActionType.SET_MEDIUM_INFO)
    private setMediumInfo(data: MediumInfosResponse) {
        this.setSubmitData('mediumInfos', data);
        this.sendSignal(ChangeSignal.GET_MEDIUM_INFO);
    }

    /**
     * ワンセットカードの暗証番号をクリア
     */
    @ActionBind(ChangeActionType.CLEAR_ONE_SET_CARD_PASSWORD)
    private clearOneSetCardPassword() {
        this.state.submitData.savingAccountFirstPwd4bits = undefined;
        this.state.submitData.savingsDepositAccountFirstPwd4bits = undefined;
    }

    /**
     * 住所コードを格納する
     * @param data APIのレスポンス
     */
    @ActionBind(ChangeActionType.SET_ADDRESS_CODE)
    private setAddressCode(data: any) {
        this.setSubmitData('holderAddressCode', data.addressCode);
        this.sendSignal(ChangeSignal.GET_ADDRESS_CODE);
    }

    /**
     * 郵便番号をクリア
     */
    @ActionBind(ChangeActionType.CLEAR_ZIP_CODE)
    private clearZipCode() {
        this.state.submitData.firstZipCode = undefined;
        this.state.submitData.lastZipCode = undefined;
    }

    @ActionBind(ChangeActionType.CLEAR_HOLDER_NAME)
    private clearHolderName() {
        if (this.state.submitData.nationalityCode === CountryCode.Japan) {
            this.setSubmitData('holderName', undefined);
            this.setSubmitData('firstName', undefined);
            this.setSubmitData('lastName', undefined);
            this.setSubmitData('holderNameFurigana', undefined);
            this.setSubmitData('firstNameKana', undefined);
            this.setSubmitData('lastNameKana', undefined);
            this.setSubmitData('firstNamegana', undefined);
            this.setSubmitData('lastNamegana', undefined);
        } else {
            this.setSubmitData('holderName', undefined);
            this.setSubmitData('firstName', undefined);
            this.setSubmitData('lastName', undefined);
            this.setSubmitData('holderNameFurigana', undefined);
            this.setSubmitData('firstNameKana', undefined);
            this.setSubmitData('lastNameKana', undefined);
            this.setSubmitData('firstNamegana', undefined);
            this.setSubmitData('lastNamegana', undefined);
            this.setSubmitData('holderNameAlphabet', undefined);
            this.setSubmitData('firstNameAlphabet', undefined);
            this.setSubmitData('lastNameAlphabet', undefined);
        }
    }

    @ActionBind(ChangeActionType.CLEAR_HOLDER_ADDRESS)
    private clearHolderAddress() {
        this.setSubmitData('holderZipCode', undefined);
        this.setSubmitData('firstZipCode', undefined);
        this.setSubmitData('lastZipCode', undefined);
        this.setSubmitData('holderAddressPrefecture', undefined);
        this.setSubmitData('holderAddressPrefectureFurigana', undefined);
        this.setSubmitData('holderAddressPrefectureFuriKana', undefined);
        this.setSubmitData('holderAddressCountyUrbanVillage', undefined);
        this.setSubmitData('holderAddressCountyUrbanVillageFurigana', undefined);
        this.setSubmitData('holderAddressCountyUrbanVillageFuriKana', undefined);
        this.setSubmitData('holderAddressStreetNameSelect', undefined);
        this.setSubmitData('holderAddressStreetNameFuriganaSelect', undefined);
        this.setSubmitData('holderAddressStreetNameFuriKanaSelect', undefined);
        this.setSubmitData('holderAddressStreetNameInput', undefined);
        this.setSubmitData('holderAddressStreetNameFuriganaInput', undefined);
        this.setSubmitData('holderAddressStreetNameFuriKanaInput', undefined);
        this.setSubmitData('holderAddressStreet', undefined);
        this.setSubmitData('holderAddressStreetFurigana', undefined);
        this.setSubmitData('showStreet', undefined);
        this.setSubmitData('streetWork', undefined);
        this.setSubmitData('holderAddressHouseNumber', undefined);
        this.setSubmitData('holderAddressHouseNumberFurigana', undefined);
        this.setSubmitData('holderAddressHouseNumberFuriKana', undefined);
    }

    @ActionBind(ChangeActionType.CLEAR_HOLDER_PHONE_NO)
    private clearHolderPhoneNo() {
        this.setSubmitData('holderMobileNo', undefined);
        this.setSubmitData('firstMobileNo', undefined);
        this.setSubmitData('secondMobileNo', undefined);
        this.setSubmitData('thirdMobileNo', undefined);
        this.setSubmitData('holderTelephoneNo', undefined);
        this.setSubmitData('firstTel', undefined);
        this.setSubmitData('secondTel', undefined);
        this.setSubmitData('thirdTel', undefined);
    }

    /**
     * 撮影した書類名称を保存
     * @param params
     */
    @ActionBind(ChangeActionType.SAVE_DOCUMENT_NAME)
    private saveDocumentName(params: { key: string, value: string }) {
        this.setSubmitData(params.key, params.value);
    }

    /**
     * 名寄せリストを格納
     * @param data
     */
    @ActionBind(ChangeActionType.CUSTOMER_INFOS_LIST)
    private customerInfosList(data) {
        const allCiftradingConditions: AllCiftradingConditions = new AllCiftradingConditions();
        allCiftradingConditions.tradingConditons = [];
        const customerInfos = data.res.customerInfo;
        customerInfos.forEach((customerInfo) => {
            customerInfo.tradingConditions.forEach((tradingCondition) => {
                const tradingConditons: TradingConditionCode = new TradingConditionCode();
                tradingConditons.tradingConditionCode = tradingCondition;
                allCiftradingConditions.tradingConditons.push(tradingConditons);

            });
        });
        this.setSubmitData('allCifTradingConditions', allCiftradingConditions);
        this.sendSignal(ChangeSignal.CUSTOMER_INFOS_LIST);
    }

    /**
     *
     * 喪失からの呼出フラグをセットする
     * @private
     * @param {boolean} result
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SET_IS_CALLED_FROM_LOSS)
    private setIsCalledFromLoss(result: boolean) {
        this.state.isCalledFromLoss = result;
    }

    /**
     * 喪失系業務からの呼び出しの際、LoginStateのtabletApplyIdをセットする
     */
    @ActionBind(ChangeActionType.SET_LOGIN_TABLET_APPLY_ID)
    private setLoginTabletApplyId() {
        this.state.tabletApplyId = +this.loginStore.getState().tabletApplyId;
    }

    /**
     *
     * 差替からの呼出フラグをセットする
     * @private
     * @param {boolean} result
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SET_IS_CALLED_FROM_REPLACE)
    private setIsCalledFromReplace(result: boolean) {
        this.state.isCalledFromReplace = result;
    }

    /**
     * 差替系業務からの呼び出しの際、LoginStateのtabletApplyIdをセットする
     */
    @ActionBind(ChangeActionType.SET_LOGIN_TABLET_APPLY_ID)
    private setLoginTabletApplyIdReplace() {
        this.state.tabletApplyId = +this.loginStore.getState().tabletApplyId;
    }

    /**
     *
     * カード新規発行からの呼出フラグをセットする
     * @private
     * @param {boolean} result
     * @memberof ChangeStore
     */
    @ActionBind(ChangeActionType.SET_IS_CALLED_FROM_NEWEST)
    private setIsCalledFromNewest(result: boolean) {
        this.state.isCalledFromNewest = result;
    }

    /**
     * 差替系業務からの呼び出しの際、LoginStateのtabletApplyIdをセットする
     */
    @ActionBind(ChangeActionType.SET_LOGIN_TABLET_APPLY_ID)
    private setLoginTabletApplyIdNewest() {
        this.state.tabletApplyId = +this.loginStore.getState().tabletApplyId;
    }
}
