import { Injectable } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { InjectionUtils } from 'adep/utils';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ChangeStore } from 'dhdt/branch/pages/change/store/change.store';

export namespace ChangeConfirmComponentParamName {
    export const BASICINFO_HOLERNAME: string = 'BASICINFO_HOLERNAME';   // お名前
    export const BASICINFO_HOLDERADDRESS: string = 'BASICINFO_HOLDERADDRESS';   // ご住所
    export const BASICINFO_HOLDERMOBILENO: string = 'BASICINFO_HOLDERMOBILENO';   // 電話番号
    export const BASICINFO_ISSMSPHONE: string = 'BASICINFO_ISSMSPHONE';   // SMS受信
    export const BASICINFO_CARDDESIGN: string = 'BASICINFO_CARDDESIGN';    // キャッシュカードデザイン
    export const PASSWORD_CARDPASSWORD: string = 'PASSWORD_CARDPASSWORD';   // キャッシュカード暗証番号
    export const PRINT_SEAL_SLIP: string = 'PRINT_SEAL_SLIP';    // 印鑑変更
    export const BASICINFO_HOLERNAME_KANJI: string = 'BASICINFO_HOLERNAME_KANJI';   // お名前漢字
    export const BASICINFO_IDENTIFICATION_DOCUMENT: string = 'BASICINFO_IDENTIFICATION_DOCUMENT';   // 本人確認書類
    export const BASICINFO_ADD_CHECK: string = 'BASICINFO_ADD_CHECK';   // 追加確認
    export const HOLDER_CAREER = 'ChangeConfirmComponentParamName_HOLDER_CAREER';    // 職業
    export const CHANGE_HOLDER_CAREER: string = 'CHANGE_HOLDER_CAREER';    // 職業（諸届）
    export const CHANGE_HOLDER_PURPOSE: string = 'CHANGE_HOLDER_PURPOSE';    // 目的（諸届）
    export const ORDINARY_DEPOSIT_ACCOUNT_PASSWORD = 'ORDINARY_DEPOSIT_ACCOUNT_PASSWORD'; //    ワンセットカード普通預金口座暗証番号
    export const SAVINGS_DEPOSIT_ACCOUNT_PASSWORD = 'SAVINGS_DEPOSIT_ACCOUNT_PASSWORD'; //    ワンセットカード貯蓄預金口座暗証番号
}

export namespace ChartID {
    export const CHANGE_NAME = 1;
    export const CHANGE_ADDRESS = 2;
    export const CHANGE_TEL = 3;
    export const CHANGE_IDENTIFICATION_DOCUMENT = 4;
    export const CHANGE_ADD_CHECK = 5;
}

@Injectable()
export class ChangeConfirmPageCommonService extends BaseComponent {
    private params: Map<string, any>;
    private action: ChangeAction;
    private store: ChangeStore;

    constructor() {
        super();
        this.action = InjectionUtils.injector.get(ChangeAction);
        this.store = InjectionUtils.injector.get(ChangeStore);
        this.params = new Map();
    }

    public loadConfirmTemplate() {
        this.action.loadConfirmPageTemplate('chat-flow-def-change-name.yml', ChartID.CHANGE_NAME);
        this.action.loadConfirmPageTemplate('chat-flow-def-change-address.yml', ChartID.CHANGE_ADDRESS);
        this.action.loadConfirmPageTemplate('chat-flow-def-change-tel.yml', ChartID.CHANGE_TEL);
        this.action.loadConfirmPageTemplate('chat-flow-def-change-identification-document.yml', ChartID.CHANGE_IDENTIFICATION_DOCUMENT);
        this.action.loadConfirmPageTemplate('chat-flow-def-change-add-check-confirmation.yml', ChartID.CHANGE_ADD_CHECK);

    }

    public getChangeConfirmPageComponentParams() {
        const params: Map<string, any> = new Map();
        // お名前の変更
        params.set(ChangeConfirmComponentParamName.BASICINFO_HOLERNAME,
            {
                startOrder: 3, endOrder: 204, type: ChangeConfirmComponentParamName.BASICINFO_HOLERNAME,
                currentTitle: this._labels.change.basic.changeName, yaml: 'chat-flow-def-change-name.yml',
                name: 'holderName', pageIndex: ChartID.CHANGE_NAME, isCurrentPage: true, processType: -1
            });
        // ご住所の変更
        params.set(ChangeConfirmComponentParamName.BASICINFO_HOLDERADDRESS,
            {
                startOrder: 2, endOrder: 164, type: ChangeConfirmComponentParamName.BASICINFO_HOLDERADDRESS,
                currentTitle: this._labels.change.basic.changeAddress, yaml: 'chat-flow-def-change-address.yml',
                name: 'holderAddress', pageIndex: ChartID.CHANGE_ADDRESS, isCurrentPage: true, processType: -1
            });
        // 携帯電話番号の変更
        params.set(ChangeConfirmComponentParamName.BASICINFO_HOLDERMOBILENO,
            {
                startOrder: 2, endOrder: 40, type: ChangeConfirmComponentParamName.BASICINFO_HOLDERMOBILENO,
                currentTitle: this._labels.change.basic.changeMobile, yaml: 'chat-flow-def-change-tel.yml',
                name: 'holderMobileNo', pageIndex: ChartID.CHANGE_TEL, isCurrentPage: true, processType: -1
            });
        // 職業の変更
        params.set(ChangeConfirmComponentParamName.CHANGE_HOLDER_CAREER,
            {
                startOrder: 42, endOrder: 42, type: ChangeConfirmComponentParamName.CHANGE_HOLDER_CAREER,
                currentTitle: this._labels.change.basic.changeCareer, yaml: 'chat-flow-def-change-tel.yml',
                name: 'changeHolderCareer', pageIndex: ChartID.CHANGE_TEL, isCurrentPage: true, processType: -1
            });
        // 目的の変更
        params.set(ChangeConfirmComponentParamName.CHANGE_HOLDER_PURPOSE,
            {
                startOrder: 43, endOrder: 43, type: ChangeConfirmComponentParamName.CHANGE_HOLDER_PURPOSE,
                currentTitle: this._labels.change.basic.changePurpose, yaml: 'chat-flow-def-change-tel.yml',
                name: 'changeHolderPurpose', pageIndex: ChartID.CHANGE_TEL, isCurrentPage: true, processType: -1
            });
        // ワンセットカード普通預金口座暗証番号
        params.set(ChangeConfirmComponentParamName.ORDINARY_DEPOSIT_ACCOUNT_PASSWORD,
            {
                startOrder: 134, endOrder: 199, type: ChangeConfirmComponentParamName.ORDINARY_DEPOSIT_ACCOUNT_PASSWORD,
                currentTitle: this._labels.change.oneSetCard.modifyTitle, yaml: 'chat-flow-def-change-name.yml',
                name: 'savingAccountPassword', pageIndex: ChartID.CHANGE_NAME, isCurrentPage: true, processType: -1
            });
        // ワンセットカード貯蓄預金口座暗証番号
        params.set(ChangeConfirmComponentParamName.SAVINGS_DEPOSIT_ACCOUNT_PASSWORD,
            {
                startOrder: 136, endOrder: 199, type: ChangeConfirmComponentParamName.SAVINGS_DEPOSIT_ACCOUNT_PASSWORD,
                currentTitle: this._labels.change.oneSetCard.modifyTitle, yaml: 'chat-flow-def-change-name.yml',
                name: 'savingsDepositAccountPassword', pageIndex: ChartID.CHANGE_NAME, isCurrentPage: true, processType: -1
            });
        // 本人確認書類
        params.set(ChangeConfirmComponentParamName.BASICINFO_IDENTIFICATION_DOCUMENT,
            {
                startOrder: 0, endOrder: 199, type: ChangeConfirmComponentParamName.BASICINFO_IDENTIFICATION_DOCUMENT,
                currentTitle: this._labels.change.modifyChat.headerTitle2, yaml: 'chat-flow-def-change-identification-document.yml',
                name: 'bankClerkConfirm', pageIndex: ChartID.CHANGE_IDENTIFICATION_DOCUMENT, isCurrentPage: true, processType: -1
            });
        // 追加確認
        params.set(ChangeConfirmComponentParamName.BASICINFO_ADD_CHECK,
            {
                startOrder: 1, endOrder: 89, type: ChangeConfirmComponentParamName.BASICINFO_ADD_CHECK,
                currentTitle: this._labels.change.modifyChat.headerTitle2, yaml: 'chat-flow-def-change-add-check-confirmation.yml',
                name: 'addCheckConfirmation', pageIndex: ChartID.CHANGE_ADD_CHECK, isCurrentPage: true, processType: -1
            });
        // キャッシュカードデザインの変更
        params.set(ChangeConfirmComponentParamName.BASICINFO_CARDDESIGN,
            {
                startOrder: 12, endOrder: 13, type: ChangeConfirmComponentParamName.BASICINFO_CARDDESIGN,
                currentTitle: this._labels.change.basic.changeDesign, yaml: 'chat-flow-def-change-edit-page.yml',
                name: 'cardDesign'
            });
        // キャッシュカード暗証番号の変更
        params.set(ChangeConfirmComponentParamName.PASSWORD_CARDPASSWORD,
            {
                startOrder: 13, endOrder: 13, type: ChangeConfirmComponentParamName.PASSWORD_CARDPASSWORD,
                currentTitle: this._labels.change.basic.changePassword, yaml: 'chat-flow-def-change-edit-page.yml',
                name: 'cardPassword'
            });
        // 印鑑変更
        params.set(ChangeConfirmComponentParamName.PRINT_SEAL_SLIP,
            {
                startOrder: 16, endOrder: 16, type: ChangeConfirmComponentParamName.PRINT_SEAL_SLIP,
                currentTitle: this._labels.change.cashcard.printSealSlip, yaml: 'chat-flow-def-change-edit-page.yml',
                name: 'printSealSlipFlag'
            });
        // お名前漢字の変更
        params.set(ChangeConfirmComponentParamName.BASICINFO_HOLERNAME_KANJI,
            {
                startOrder: 10, endOrder: 10, type: ChangeConfirmComponentParamName.BASICINFO_HOLERNAME_KANJI,
                currentTitle: this._labels.change.basic.changeName, yaml: 'chat-flow-def-change-edit-page.yml',
                name: 'holderName'
            });
        return params;
    }
}
