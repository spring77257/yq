/**
 * 取確用本人確認書類情報
 */
export class IdentiDocInfo {
    public idInfoDoc1: string;
    public identityDocument1Name: string;
    public identityDocument1ExpirationDate: string;
    public otherImageDoc1: string[];
    public idInfoDoc2: string;
    public identityDocument2Name: string;
    public identityDocument2ExpirationDate: string;
    public otherImageDoc2: string[];
    public addressConfirmationDocumentName: string;
    public addressConfirmationDocumentExpirationDate: string;
    public otherImageAddressDoc: string[];
}
