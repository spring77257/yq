/**
 * 複数顧客情報リスポンス
 *
 * @export
 * @class DuplicateAccountInfoResponse
 */
export class CifInfosResponse {
    public cifInfoInquiryResponses: CifInfo[];
}

/**
 * 顧客情報
 *
 * @export
 * @class DuplicateAccountTenpoInfo
 */
export class CifInfo {
    public resultCode: string;
    public errorType: string;
    public errorCode: string;
    public tenban: string;
    public branchName: string;
    public customerId: string;
    public individualCompanyType: string;
    public zipCode: string;
    public address: string;
    public addressNonConvert: string;
    public addressKana: string;
    public nameKanji: string;
    public nameNonConvert: string;
    public nameKana: string;
    public gender: string;
    public genderText: string;
    public birthdate: string;
    public agentNameRegisterType: string;
    public holderTelNo1: string;
    public holderTelNo2: string;
    public holderTelNo3: string;
    public identificationCode: string;
    public zipCode2: string;
    public address2: string;
    public addressNonConvert2: string;
    public addressKana2: string;
    public myNoEntryStatus: string;
    public nonDelivery: string;
    public nameAlphabet: string;
    public nationalityCode: string;

}
