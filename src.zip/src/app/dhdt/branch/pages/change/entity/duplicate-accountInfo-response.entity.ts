import { AcceptionResultAccount } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';

/**
 * 同一名義人リスポンス
 *
 * @export
 * @class DuplicateAccountInfoResponse
 */
export class DuplicateAccountInfoResponse {
    public resultCode: string;
    public errorType: string;
    public errorCode: string;
    public customerSearchStatus: string;
    public duplicateAccountInfos: DuplicateAccountTenpoInfo[];
}

/**
 * 同一名義人リスポンス サブ階層
 *
 * @export
 * @class DuplicateAccountTenpoInfo
 */
export class DuplicateAccountTenpoInfo {
    public branchNo: string;
    public branchName: string;
    public customerId: string;
    public nameKana: string;
    public nameKanji: string;
    public nameNonConvert: string;
    public birthdate: string;
    public zipCode: string;
    public address: string;
    public addressNonConvert: string;
    public holderTelNo1: string;
    public holderTelNo2: string;
    public holderTelNo3: string;
    public bankCardHoldingFlag: string;
    public accountHoldingFlag: string;
    public attributeMismatchFlag: string;
    public accountInfos: TenKaKo[];
    public nameAlphabet: string;
    public firstNameAlphabet: string;
    public lastNameAlphabet: string;
    public nationality: string;
    public holderName: string;
    public bcNameRoma: string;
    public receiptMethod: string;
    public printSealSlipFlag: string;
    public americanSuggestionInfo: string;
    public nonDeliveryReleaseFlag: string;
}

/**
 * 同一名義人リスポンス サブ階層
 *
 * @export
 * @class TenKaKo
 */
export class TenKaKo {
    public tenban: string;
    public accountType: string;
    public accountNo: string;

}

export class DuplicateAccountAndAcceptResultAccount extends DuplicateAccountTenpoInfo {
    public acceptResult: AcceptionResultAccount;
}
