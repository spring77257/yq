import { JsonProperty } from 'adep/json';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { MediumInfosResponse } from 'dhdt/branch/pages/common/entity/medium-infos-response.entity';
import { AcceptionResultAccount } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';

class ValidationRules {
    public min: { value: number };
    public max: { value: number };
    public required: { value: boolean };
}

export class ChangeQuestionsModel {
    public order: number;
    public next: number;
    public type: string;
    public question: string;
    public example: string;
    public choices: any[];
    public options: any;
    public name: string;
    @JsonProperty({ clazz: ValidationRules })
    public validationRules: ValidationRules;
    public skip: number;
}

export class PageQuestionsModel {
    public order: number;
    public next: number;
    public type: string;
    public example: string;
    public choices: any[];
    public options: any;
    @JsonProperty({ clazz: ValidationRules })
    public validationRules: ValidationRules;
    public question: string;
    public name: string;
    public answer: { order: number, text: string, value: any };
    public pageIndex: number;
    public skip: number;
}

export class DropDownListEntity {
    public key: string;
    public value: string;
    public filler1: string;
    public filler2: string;
    public filler3: string;
}

export class ChangeDifferenceEntity {
    public customerId: string;
    public isDifference: boolean;
}

export class ChangeDifferenceEntityForMynumber {
    public isDifference: boolean;
    public accountBranchCode: string;
    public accountBranchName: string;
    public customerId: string;
    public nameDiff: string;
    public addressDiff: string;
    public telDiff: any;
    public birthDateDiff: string;
    public nationalityDiff: string;
}

export class ChangeDifferencePayload {
    public customerId: string;
    public branchName: string;
    public nameDiffFlg: boolean;
    public addressDiffFlg: boolean;
    public telDiffFlg: boolean;
}

export class AllCiftradingConditions {
    public tradingConditons: TradingConditionCode[];
}

export class TradingConditionCode {
    public tradingConditionCode: string;
}

export class ChangeSubmitEntity {
    [x: string]: any;
    // 共用
    // タブレット申込管理番号
    public tabletApplyId: number;
    // 申込業務区分
    public applyBusinessType: string;
    // ステータス
    public status: string;
    // 途中離脱理由
    public leaveReason: string;
    // 番号札
    public numberTag: number;
    // 番号札発行日時
    public numberTagPublishDate: string;

    // 全店名寄せ情報
    public allCifInfos: CifInfo[];
    // 氏名差分情報
    public nameDifferenceInfos: ChangeDifferenceEntityForMynumber[];
    // 住所差分情報
    public addressDifferenceInfos: ChangeDifferenceEntityForMynumber[];
    // 電話番号差分情報
    public telDifferenceInfos: ChangeDifferenceEntityForMynumber[];
    // 国籍差分情報
    public nationalityDifInfos: ChangeDifferenceEntityForMynumber[];
    // 生年月日差分情報
    public birthdayDifInfos: ChangeDifferenceEntityForMynumber[];

    // 保有通帳・カード・印鑑情報
    public mediumInfos: MediumInfosResponse;

    // ワンセットカード保有口座情報
    public oneSetAccountInfo: OneSetAccountInfo;

    // スワイプCIFの受付可否チェック結果
    public swipeCifAcceptCheckResult: {customerId: string, account: AcceptionResultAccount};
    // 氏名に差分があるCIFの受付可否チェック結果
    public nameidentiNameDifCifAcceptCheckResult: Array<{customerId: string, accounts: AcceptionResultAccount}>;
    // 住所に差分があるCIFの受付可否チェック結果
    public nameidentiAddressDifCifAcceptCheckRestlt: Array<{customerId: string, accounts: AcceptionResultAccount}>;
    // 電話番号に差分があるCIFの受付可否チェックの結果
    public nameidentiTelDifCifAcceptCheckResult: Array<{customerId: string, accounts: AcceptionResultAccount}>;

    // PID配下すべてのCIFの取引ぶり
    public allCifTradingConditions: AllCiftradingConditions;

    // 氏名変更有無
    public isNameChange: boolean;
    // 住所変更有無
    public isAddressChange: boolean;
    // 電話番号変更有無
    public isTelphoneChange: boolean;

    // QRコード受付情報
    // スワイプ店CIF
    public swipeCif: string;
    // スワイプ店番
    public swipeBranchNo: string;
    // スワイプ口座番号
    public swipeAccountNo: string;
    public receptionBranchNo: string;        // 受付店番
    public receptionNo: string;        // 受付番号
    public receptionTime: string;        // 受付年月日時分秒

    public swipeCardType: string;

    // タブレット入力開始日時
    public tabletStartDate: string;
    // 顧客申込入力開始日時
    public customerApplyStartDate: string;
    // 顧客申込入力完了日時
    public customerApplyEndDate: string;
    // RQ番号
    public rqNo: string;
    // 店番
    public branchNo: string;
    // 店名
    public branchKanji: string;
    // 行員ID
    public userMngNo: string;
    // 行員認証入力開始日時
    public bankclerkAuthenticationStartDate: string;
    // 行員認証入力完了日時
    public bankclerkAuthenticationEndDate: string;
    // 名前
    public holderName: string;
    // 名前（フリガナ）
    public holderNameFurigana: string;
    // 性別
    public holderGender: string;
    // 生年月日
    public holderBirthdate: string;
    // 郵便番号
    public holderZipCode: string;
    // 住所・都道府県
    public holderAddressPrefecture: string;
    // 住所・都道府県・Code
    public holderAddressPrefectureCode: string;
    // 住所・市区町村
    public holderAddressCountyUrbanVillage: string;
    // 住所・市区町村・Code
    public holderAddressCountyUrbanVillageCode: string;
    // 住所・町丁名
    public holderAddressStreet: string;
    // 住所・番地以降
    public holderAddressHouseNumber: string;
    // 住所・都道府県（フリガナ）
    public holderAddressPrefectureFurigana: string;
    // 住所・市区町村（フリガナ）
    public holderAddressCountyUrbanVillageFurigana: string;
    // 住所・町丁名（フリガナ）
    public holderAddressStreetFurigana: string;
    // 住所・番地以降（フリガナ）
    public holderAddressHouseNumberFurigana: string;
    // 「その他」の場合は、町丁名(例：湊町４丁目)
    public holderAddressStreetNameInput: string;

    // 固定電話番号
    public holderTelephoneNo: string;
    // 携帯電話番号
    public holderMobileNo: string;
    // 行員確認ID
    public bankclerkConfirmId: string;
    // 行員確認日時
    public bankclerkConfirmDate: string;
    // 名義人―遠隔地等住所などの場合の理由
    public holderRemoteAddressReadon: string;
    // 名義人―本人確認書類の種類
    public holderIdentityDocumentType: string;
    // カードの交付方法
    public cashCardReceiptMethod: string;
    // 名義人―コピー徴求ができない理由
    public holderNoCopyReason: string;
    // 名義人―発行元
    public holderPublisher: string;
    // 名義人―発行日
    public holderPublishDate: string;
    // 名義人―記号番号
    public holderSignNo: string;
    // 名義人―本人確認書類（顔写真ない）の補完書類の種類
    public holderIdentityDocumentPhotographType: string;
    // 名義人―本人確認書類（住所異なる）の補完書類の種類
    public holderIdentityDocumentAddressType: string;
    // 名義人―本人確認書類の補完書類のコピー徴求ができない理由
    public holderIdentityDocumentNoCopyReason: string;
    // 名義人―本人確認書類の住所が相違する理由
    public addressDiffrentReason: string;
    // 名義人―本人確認書類の補完種類の補完書類の発行元
    public holderIdentityDocumentPublisher: string;
    // 名義人―本人確認書類の補完種類の補完書類発行日
    public holderIdentityDocumentPublishDate: string;
    // 名義人―本人確認書類の補完書類の記号番号
    public holderIdentityDocumentSignNo: string;

    // カード再発行依頼書情報
    // 整理番号（番号札に同じ？）
    public orderNo: string;
    // 本人カード新カード
    public selfCardNewCard: string;
    // 代理人カード新カード
    public agentCardNewCard: string;
    // 本人カード口座識別（要確認）
    public selfCardAccountFlg: string;
    // 本人カード種類
    public selfCardType: string;
    // 代理人カード口座識別（要確認）
    public agentCardAccountFlg: string;
    // 代理人カード種類
    public agentCardType: string;
    // 科目
    public accountType: string;
    // 口座番号
    public accountNo: string;
    // 受取方法
    public receiptMethod: string;
    // カード種類
    public cardType: string;
    // カード区分（要確認）
    public selfAgentCard: string;
    // 依頼内容（要確認）
    public requestContent: string;
    // キャッシュカードデザイン
    public cashCardDesign: string;
    // カードPassword
    public cashCardPassword: string;
    // カードPassword
    public cashCardFirstPwd4bits: string;
    public accountTypeText: string;
    public leaveType: string;
    public firstName: string;
    public lastName: string;
    public showAddressPage: boolean;
    public showNamePage: boolean;
    public passworduser: string;
    public firstNameKana: string;
    public lastNameKana: string;
    public firstZipCode: string;
    public lastZipCode: string;
    public holderAddressStreetSelect: string;
    public holderAddressStreetFuriganaSelect: string;
    public firstMobileNo: string;
    public secondMobileNo: string;
    public thirdMobileNo: string;
    public firstTel: string;
    public secondTel: string;
    public thirdTel: string;
    public nameKanji: string;
    public nameKana: string;
    public nameAlphabet: string;

    // 国籍-本店所在国
    public nationalityCode: string;

    // 郵便不着コード
    public nonDelivery: string;

    // 勘定系APIからデータを取得するためSubmitDataのを用意する
    public holderAddressStreetNameSelect: string; // selected street
    public holderAddressPrefectureFuriKana: string;
    public holderAddressCountyUrbanVillageFuriKana: string;
    public holderAddressStreetNameFuriKanaInput: string;
    public holderAddressStreetNameFuriKanaSelect: string; // selected street
    public holderAddressHouseNumberFuriKana: string;
    public holderRegionCode: string;
    public holderCardDesign: string; // キャッシュカードのグデザイン

    public fileInfo?: any;
    public branchName: string;                          // CIF情報からの店舗名

    public printSealSlipFlag: string;                   // 印鑑票発行フラグ

    public publishFlag: string; // キャッシュカード即時発行フラグ

    public wholeCif: string;

    public holderCardMsIcType: string;
    public holderCardType: string;

    public changeDiffInfoList: ChangeDifferencePayload[]; // 変更有無リスト

    public getHolderMobileNo(): string {
        if (!this.firstMobileNo || !this.secondMobileNo || !this.thirdMobileNo) {
            return '';
        }
        return this.firstMobileNo + this.secondMobileNo + this.thirdMobileNo;
    }

    public getHolderTelephoneNo(): string {
        if (!this.firstTel || !this.secondTel || !this.thirdTel) {
            return '';
        }
        return this.firstTel + this.secondTel + this.thirdTel;
    }

    public getShowAddressPage(): boolean {
        return this.showAddressPage;
    }

    public getShowNamePage(): boolean {
        return this.showNamePage;
    }

    public getHolderName(): string {
        return this.firstName + this.lastName;
    }

    public getHolderNameFurigana(): string {
        return this.firstNameKana + '　' + this.lastNameKana;
    }

    public getHolderZipCode(): string {
        return this.firstZipCode + this.lastZipCode;
    }

    /**
     * AddressStreetName 取得する
     */
    public getHolderAddressStreetName(): string {
        if (this.holderAddressStreetNameSelect || this.holderAddressStreetNameInput) {
            return this.holderAddressStreetNameSelect
                ? this.holderAddressStreetNameSelect : this.holderAddressStreetNameInput;
        }

        return '';
    }
}

export class OneSetAccountInfo {
    public customerId: string;
    public accounts: AccountInfo[];
}

export class AccountInfo {
    public branchName: string;
    public branchNo: string;
    public accountType: string;
    public accountNo: string;
}
