export namespace Constants {
    export class PageConsts {
        public static readonly backToTopStayTime = 5000;
    }

    /**
     * DBに格納する指定文言
     */
    export class DBConsts {
        public static readonly deviceId = '111';

        public static applyBusinessType = '12'; // 申込業務区分 //readonly削除
        public static readonly insertStatus = '00'; // ステータス
        public static leaveReason = { // 普通預金離脱理由
            corporation: '001', // 法人の場合（離脱）
            against: '002', // 反社の場合（離脱）
            importantForeigner: '003', // 外国の重要な公的地位（離脱）
            notInJapan: '004', // 居住地が日本以外（離脱)
            agentNoConfirmFile: '005', // 代理人が本人確認資料未所持（離脱）
            noCohabitation: '006', // 代理人が同居の親族ではない（離脱）
            noConfirmFile: '007' // 本人が本人確認資料未所持（離脱）
        };
        public static updateStatus = { // ステータス
            corporation: '90', // 法人の場合（離脱）
            against: '90', // 反社の場合（離脱）
            importantForeigner: '90', // 外国の重要な公的地位（離脱）
            notInJapan: '90', // 居住地が日本以外（離脱)
            agentNoConfirmFile: '90', // 代理人が本人確認資料未所持（離脱）
            noCohabitation: '90', // 代理人が同居の親族ではない（離脱）
            noConfirmFile: '90' // 本人が本人確認資料未所持（離脱）
        };
        public static readonly changeConfirmFlow = 99;
        public static SpecTransactionCode = {
            maruyu: '01', // マル優
            marutoku: '02', // マル特
            maruzai: '03', // マル財取引
            eduFinacialAdmin: '04', // 教育資金管理契約あり
            bussinessLoan: '05', // 事業性融資先
            currentAccount: '10', // 当座預金先
            houseLoan: '06', // 住宅ローン
            other: '07', // その他
            Investment: '08', // 投信有
            specialDeposit: '09', // 特定口座あり
            electronicBond: '11', // 電債取引ある
            bondCustomers: '12', // 債券顧客保有先
            goldBullion: '29', // 金保護預かり利用先
            safeDepositBox: '31', // 貸金庫契約先
            loanCreditOwned: '39' // 融資債権保有先
        };
    }
}

// タブレット申込管理 ステータス
export class TabletApplyStatus {
    // 申込開始
    public static readonly START = '00';
    // 未印刷
    public static readonly NOT_PRINTED = '01';
    // 印刷済
    public static readonly PRINTED = '02';
    // 途中離脱
    public static readonly QUIET_MIDWAY = '90';
    // 異常終了
    public static readonly OBNORMAL_END = '99';
}

export class AccountType {
    // 氏名変更
    public static readonly CHANGE_NAME = 'CHANGE_NAME';
    // 住所変更
    public static readonly CHANGE_ADDRESS = 'CHANGE_ADDRESS';
    // 氏名・住所変更
    public static readonly CHANGE_NAME_ADDRESS = 'CHANGE_NAME_ADDRESS';
}

export class ApplyBusinessType {
    // 氏名変更
    public static readonly CHANGE_NAME = '20';
}

export class NumChanged {
    // 変更なし
    public static readonly NO_CHANGE = '0';
    // 変更する
    public static readonly CHANGED = '1';
    // 削除する
    public static readonly DELETED = '2';
}

export class CashCardDeliveryType {
    // 即時発行コード
    public static readonly IMMEDIARY_CODE = '3';
    // 郵送コード
    public static readonly MAIL_CODE = '1';
}

export class BcSuicaResult {
    // 回収できる
    public static readonly COLLECT = '1';
    // 回収できない
    public static readonly NOT_COLLECT = '0';
    // 喪失届済み
    public static readonly LOST = '2';
}

// 画面遷移
export class ScreenTransition {
    // TOPに戻る
    public static readonly BACK_TO_TOP = 'top';
    public static readonly COMPLETE = 'complete';
    public static readonly CLERK_CONFIRM_COMPLETE = 'clerkConfirmComplete';
    // 「次へ」ボタン
    public static readonly NEXT_TO_COMPLETE = 'nextToComplete';
}

export class AmericanSuggestionInfo {
    // 米国人示唆情報ありコード
    public static readonly IS_HAVE_AMERICAN_SUGGESTIONS_CODE = '1';
    // 米国人示唆情報なしコード
    public static readonly IS_NOT_HAVE_AMERICAN_SUGGESTIONS_CODE = '0';
}

export class DeliveryStatus {
    // 変更なし
    public static readonly NON_DELIVERY = '1';
    // 変更する
    public static readonly ARRIVED = '0';
}

export class CdHoldingStatus {
    // CD保有
    public static readonly HOLDING = '1';
    // CD保有なし
    public static readonly NOT_HOLDING = '0';
}

export class BcHoldingStatus {
    // BC保有
    public static readonly HOLDING = '1';
    // BC保有なし
    public static readonly NOT_HOLDING = '0';
}

export class LossCardStatus {
    // カード喪失
    public static readonly LOSS = '1';
    // カード喪失なし
    public static readonly NOT_LOSS = '0';
}

export class TheftCardStatus {
    // 盗難表示あり
    public static readonly THEFT = '1';
    // 盗難表示なし
    public static readonly NOT_THEFT = '0';
}

// 業務コード
export class BussinessCode {
    // 届出事項変更（氏名変更メニュー選択時）
    public static readonly NAME_MENU_CHANGE = '19';
    // 届出事項変更（住所変更・電話番号変更メニュー選択時）
    public static readonly CHANGE = '05';
    // 諸届事項（氏名）の変更（名寄せ時）
    public static readonly NAME_CHANGE = '10';
    // 諸届事項（電話番号or住所・氏名）の変更（名寄せ時）
    public static readonly ADDRESS_TEL_NAME_CHANGE = '11';
    // 諸届事項（電話番号or住所）の変更（名寄せ時）
    public static readonly ADDRESS_TEL_CHANGE = '09';
    // 届出事項変更（氏名変更を含まない住所変更・電話番号変更メニュー選択時）
    public static readonly ADDRESS_TEL_MENU_CHANGE = '24';
}

// 同一人候補の検索結果
export class CustomerSearch {
    // 未出力明細あり
    public static readonly UN_PRINTED = '1';
    // 検索済
    public static readonly PRINTED = '0';
}

export class ErrorCode {
    // 郵便不着コード
    public static readonly NON_DELIVERY = '203';
}

export class JudgeResultStatus {
    public static readonly RESULT_01 = '01';
    public static readonly RESULT_02 = '02';
    public static readonly RESULT_03 = '03';
    public static readonly RESULT_04 = '04';
    public static readonly RESULT_05 = '05';
    public static readonly RESULT_0 = '0';
    public static readonly RESULT_1 = '1';

    // 離脱
    public static readonly SECESSION = 'secession';
    // 離脱しない
    public static readonly NOT_SECESSION = 'notSecession';

    // 持っている
    public static readonly HAVE = 'have';
    // 持っていない
    public static readonly NOT_HAVE = 'notHave';
}
// 取引振りレベル
export class TransactionLevel {
    // 受付不可の取引振り
    public static readonly NOT_ACCEPTED = '1';
}

// 諸届変更ボタン種類
export class PressButtonType {
    // 氏名変更時の押下ボタン名称
    public static readonly HOLDER_NAME_BUTTON = 'holderName';
    // 住所変更時の押下ボタン名称
    public static readonly HOLDER_ADDRESS_BUTTON = 'holderAddress';
    // 電話番号変更時の押下ボタン名称
    public static readonly HOLDER_MOBILENO_BUTTON = 'holderMobileNo';
}

// ワンセット表示
export class OsStatus {
    // ワンセットカード保有あり
    public static readonly OS_STATUS_ON = '1';
    // ワンセットカード保有なし
    public static readonly OS_STATUS_OFF = '0';
}

// MC表示
export class McStatus {
    // MC保有あり
    public static readonly MC_STATUS_ON = '1';
    // MC保有なし
    public static readonly MC_STATUS_OFF = '0';
}

// IC表示
export class IcStatus {
    // IC保有あり
    public static readonly IC_STATUS_ON = '1';
    // IC保有なし
    public static readonly IC_STATUS_OFF = '0';
}

// BC表示
export class BcStatus {
    // BC保有あり
    public static readonly BC_STATUS_ON = '1';
    // BC保有なし
    public static readonly BC_STATUS_OFF = '0';
}

// 複数BC表示
export class DoubleBcStatus {
    // 複数BC保有あり
    public static readonly DOUBLE_BC_STATUS_ON = '1';
    // 複数BC保有なし
    public static readonly DOUBLE_BC_STATUS_OFF = '0';
}

// 複数ワンセット表示
export class DoubleOsStatus {
    // 複数ワンセットカード保有あり
    public static readonly DOUBLE_OS_STATUS_ON = '1';
    // 複数ワンセットカード保有なし
    public static readonly DOUBLE_OS_STATUS_OFF = '0';
}

// カード使用中
export class CardInUse {
    // カード使用中
    public static readonly CARD_IN_USE = 'カード使用中';
}

/**
 * 本人確認書類コード
 */
export enum IdentificationDocumentCode {
    // 在留カード・特別永住者証明書
    RESIDENCE_CARD_SPECIAL_PERMANENT_RESIDENT_CERTIFICATE = '04',
    // 在留カード
    RESIDENCE_CARD = '21',
    // 特別永住者証明書
    SPECIAL_PERMANENT_RESIDENT_CERTIFICATE = '22',
    // パスポート（所持人記入欄なし）
    PASSPORT_WITHOUT_SELF_INPUT = '26',
    // 福祉手帳
    WELFARE_NOTEBOOK = '07',
    // 戸籍記載事項証明書（3か月）
    FAMILY_REGISTER_ENTRY_CERTIFICATE_3_MONTHS = '08',
    // 戸籍記載事項証明書（6か月）
    FAMILY_REGISTER_ENTRY_CERTIFICATE_6_MONTHS = '09'
}

/**
 * 本人確認書類方法
 */
export enum IdentificationDocumentMethod {
    // １種類提示
    PRESENT_ONE_TYPE = 1,
    // ２種類提示
    PRESENT_TWO_TYPE = 2,
}

export enum NameIdentityDocumentImg {
    // 書類Xを聴取
    TYPE_X = 'X',
    TYPE_X_IMG = 'img_name_identity_verification_documents_x@2x.png',
    // 書類XとAを聴取
    TYPE_XA = 'XA',
    TYPE_XA_IMG = 'img_name_identity_verification_documents_xa@2x.png',
    // 書類XとCを聴取
    TYPE_XC = 'XC',
    TYPE_XC_IMG = 'img_name_identity_verification_documents_xc@2x.png',
    // 書類X、A、Cを聴取
    TYPE_XAC = 'XAC',
    TYPE_XAC_IMG = 'img_name_identity_verification_documents_xac@2x.png',
}

export enum AddressDocumentImg {
    // 書類Bを聴取
    TYPE_B = 'B',
    TYPE_B_IMG = 'img_address_verification_documents_b@2x.png',
    // 書類Cを聴取
    TYPE_C = 'C',
    TYPE_C_IMG = 'img_address_verification_documents_c@2x.png',
    // 書類BとCを聴取
    TYPE_BC = 'BC',
    TYPE_BC_IMG = 'img_address_verification_documents_bc@2x.png',
}

export enum ChangeDocumentImg {
    // 書類Xを聴取
    TYPE_X = 'X',
    TYPE_X_IMG = 'X.png',
    // 書類XとAを聴取
    TYPE_XA = 'XA',
    TYPE_XA_IMG = 'XA.png',
    // 書類XとCを聴取
    TYPE_XC = 'XC',
    TYPE_XC_IMG = 'XC.png',
    // 書類X、A、Cを聴取
    TYPE_XAC = 'XAC',
    TYPE_XAC_IMG = 'XAC.png',
    // 書類Bを聴取
    TYPE_B = 'B',
    TYPE_B_IMG = 'B.png',
    // 書類Cを聴取
    TYPE_C = 'C',
    TYPE_C_IMG = 'C.png',
    // 書類BとCを聴取
    TYPE_BC = 'BC',
    TYPE_BC_IMG = 'BC.png',
    // 書類XABを聴取
    TYPE_XAB = 'XAB',
    TYPE_XAB_IMG = 'XAB.png',
    // 書類XABCを聴取
    TYPE_XABC = 'XABC',
    TYPE_XABC_IMG = 'XABC.png',
}

export class DoNotHaveIdentificationDoc {
    // 持っていない（郵送）
    public static readonly DO_NOT_HAVE_IDENTIFICATION_DOC = '99';
}

export class IdentificationDocCode {
    // その他官公庁から発行された書類（顔写真付き）
    public static readonly OTHER_IDENTIFICATION_DOCUMENT = '24';
    // その他官公庁から発行された書類
    public static readonly OTHER_IDENTIFICATION_NO_PHOTO_DOCUMENT = '25';
    // パターンCにて聴取したその他官公庁から発行された書類
    public static readonly OTHER_OFFICAL = '28';
    // 各種福祉手帳
    public static readonly WELFARE = '07';
}

export class IdentificationDocument {
    // 運転免許証
    public static readonly DRIVE_CARD = '01';
    // パスポート（所持人記入欄あり）
    public static readonly PWD = '02';
    // マイナンバーカード
    public static readonly MY_NUMBER_CARD = '03';
    // 在留カード・特別永住者証明書
    public static readonly RESIDENT = '04';
    // 各種年金手帳
    public static readonly PENSION_BOOK = '05';
    // 各種健康保険証
    public static readonly INSURANCE = '06';
    // 各種福祉手帳
    public static readonly WELFARE = '07';
    // 戸籍謄本・抄本（３か月）
    public static readonly FAMILY_REGISTER_COPY_3 = '08';
    // 戸籍謄本・抄本（６か月）
    public static readonly FAMILY_REGISTER_COPY_6 = '09';
    // 印鑑登録証明書（３か月）
    public static readonly SEAL_CERTIFICATE_3 = '10';
    // 印鑑登録証明書（６か月）
    public static readonly SEAL_CERTIFICATE_6 = '11';
    // 住民票の写し（３か月）
    public static readonly CERTIFICATE_OF_RESIDENCE_3 = '12';
    // 住民票の写し（６か月）
    public static readonly CERTIFICATE_OF_RESIDENCE_6 = '13';
    // 住民票記載事項証明書（３か月）
    public static readonly CERTIFICATE_OF_ITEMS_STATED_IN_RESIDENT_REGISTER_3 = '14';
    // 住民票記載事項証明書（６か月）
    public static readonly CERTIFICATE_OF_ITEMS_STATED_IN_RESIDENT_REGISTER_6 = '15';
    // 住民基本台帳カード
    public static readonly BASIC_RESIDENT_REGISTER_CARD = '20';
    // 在留カード
    public static readonly RESIDENT_CARD = '21';
    // 特別永住者証明書
    public static readonly SP_RESIDENT_CERTIFICATE = '22';
    // その他官公庁から発行された書類（写真付）
    public static readonly OTHER_OFFICIAL_WITH_PHOTO = '24';
    // その他官公庁から発行された書類(パターンX)
    public static readonly OTHER_OFFICIAL_X = '25';
    // パスポート（所持人記入欄なし）
    public static readonly PWD_NO_ENTRY_FIELD_OWNER = '26';
    // 運転経歴証明書
    public static readonly DRIVERS_CAREER_LICENSE = '27';
    // その他官公庁から発行された書類(パターンC)
    public static readonly OTHER_OFFICIAL_C = '28';
}

export enum UnacceptableCode {
    // エラーモーダルの1行に表示する注意コード最大数
    UNACCEPTABLE_CODE_MAX = 3,
}

export class InterruptionOfTelephone {
    // 電話番号不通有無
    public static readonly ON = '1';
}
