import { Injectable, NgZone } from '@angular/core';
import { Action } from 'adep/flux';
import { DeviceService } from 'dhd/common/services/device.service';
import { NumChanged } from 'dhdt/branch/pages/change/change-consts';
import { ChangeDifferenceEntity, ChangeQuestionsModel } from 'dhdt/branch/pages/change/entity/change-questions.model';
import { DuplicateAccountTenpoInfo } from 'dhdt/branch/pages/change/entity/duplicate-accountInfo-response.entity';
import { ChangeState } from 'dhdt/branch/pages/change/store/change.store';
import {
    API_URL, ApplyDate, ClearChangeImagesClickRecordType, CodeCategory,
    CoreBankingConst, HostResultCode, RegionCodeDeterminationMethod
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { AcceptionResult, AcceptionResultTradingCondition } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { ModalDigitalStore } from 'dhdt/branch/shared/components/modal/modal-digital/store/modal-digital.store';
import { FilteringParameterEntity } from 'dhdt/branch/shared/entity/filtering-parameter.entity';
import { RegionCodeEntity, RegionCodeSearchRequestEntity } from 'dhdt/branch/shared/entity/region-code.entity';
import { AccountBalanceInquiryInterface } from 'dhdt/branch/shared/interface/account-balance-inquiry.interface';
import { AccountExistCheckInterface } from 'dhdt/branch/shared/interface/account-exist-check.interface';
import {
    AddressChangeParamsBase, ChangeBaseInterface, CoreBankingChangeParamsBase, NameChangeParamsBase, TelephoneChangeParamsBase
} from 'dhdt/branch/shared/interface/core-banking-base.interface';
import { FormerInfo } from 'dhdt/branch/shared/interface/former-info.interface';
import { SimpleCifInfoInquiryInterface } from 'dhdt/branch/shared/interface/simple-cif-info-inquiry.interface';
import { TabletApplyTimeInfo } from 'dhdt/branch/shared/interface/tablet-apply-time-info.interface';
import { TelephoneChangeInterface, TelephoneChangeParams } from 'dhdt/branch/shared/interface/telephone-change.interface';
import { ChatFlowActionInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-action.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { DocumentCategorySubjectData } from 'dhdt/branch/shared/modules/document-category/entity/document-category.entity';
import { HostErrorService } from 'dhdt/branch/shared/services/host-error.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { HttpService, HttpStatus } from 'dhdt/branch/shared/services/http.service';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { tap } from 'rxjs/operators/tap';

export namespace ChangeActionType {
    export const GET_SAVING_QUESTION_TEMPLATE: string = 'ChangeActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const NEXT_CHAT: string = 'ChangeActionType_NEXT_CHAT';
    export const GET_NEXT_CHAT: string = 'ChangeActionType_GET_NEXT_CHAT';
    export const CLEAR: string = 'ChangeActionType_LOAD_TEMPLATE_CLEAR';
    export const CLEAR_PARTS: string = 'ChangeActionType_LOAD_TEMPLATE_CLEAR_PARTS';
    export const CLEAR_SHOW_CHATS: string = 'ChangeActionType_CLEAR_SHOW_CHATS';
    export const BRANCH_STATUS_INSERT: string = 'ChangeActionType_BRANCH_STATUS_INSERT';
    export const BRANCH_STATUS_UPDATE: string = 'ChangeActionType_BRANCH_STATUS_UPDATE';
    export const SET_ANSWER: string = 'ChangeActionType_SET_ANSWER';
    export const EDIT_CHAT: string = 'ChangeActionType_EDIT_CHAT';
    export const SET_STATE_SUBMIT_DATA_VALUE: string = 'ChangeActionType_SET_STATE_SUBMIT_DATA_VALUE';
    export const SUBMIT_DATA_BACKUP: string = 'ChangeActionType_SUBMIT_DATA_BACKUP';
    export const COPY_SUBMIT_DATA: string = 'ChangeActionType_COPY_SUBMIT_DATA';
    export const RESET_SUBMIT_DATA: string = 'ChangeActionType_RESET_SUBMIT_DATA';
    export const RETRIEVE_DROP_LIST: string = 'ChangeActionType_RETRIEVE_DROP_LIST';
    export const GET_HOLDER_ZIP_CODE = 'ChangeActionType_GET_HOLDER_ZIP_CODE';
    export const BRANCH_INFO_INSERT: string = 'ChangeActionType_BRANCH_INFO_INSERT';
    export const SET_TABLE_START_DATE = 'ChangeActionType_SET_TABLE_START_DATE';
    export const CHAT_FLOW_COMPELETE = 'ChangeActionType_CHAT_FLOW_COMPELETE';
    export const RESET_LAST_NODE = 'ChangeActionType_RESET_LAST_NODE';
    export const RESET_TO_ORDER = 'ChangeActionType_RESET_TO_ORDER';
    export const SUBMIT_TIME_SAVING_APPLY_INFO = 'SUBMIT_TIME_SAVING_APPLY_INFO';
    export const SET_BANKCLERK_ID: string = 'SET_BANKCLERK_ID';
    export const SET_BRANCH_INFO: string = 'SET_BRANCH_INFO';
    export const SET_AGENCY_BRANCH_INFO: string = 'SET_AGENCY_BRANCH_INFO';
    export const SET_CIF_INFO: string = 'SET_CIF_INFO';
    export const REGIST_NAME_IDENTITY_INFO: string = 'REGIST_NAME_IDENTITY_INFO';
    export const SET_INTEREST_COMPUTATION_METHOD: string = 'SET_INTEREST_COMPUTATION_METHOD';
    export const CLEAR_OPEN_ACCOUNT_PURPOSE: string = 'CLEAR_OPEN_ACCOUNT_PURPOSE';
    export const TRANSFER_SELF_TRADING_LIST: string = 'TRANSFER_SELF_TRADING_LIST';

    export const SET_SHOW_NAME_PAGE = 'ChangeActionType_SET_SHOW_NAME_PAGE';
    export const SET_SHOW_ADRRESS_PAGE = 'ChangeActionType_SET_SHOW_ADRRESS_PAGE';
    export const GET_UPDATE_USER_INFO = 'ChangeActionType_GET_UPDATE_USER_INFO';
    export const CHANGE_INFO_INSERT = 'CHANGE_INFO_INSERT';
    export const GET_CONFIRM_PAGE_TEMPLATE = 'GET_CONFIRM_PAGE_TEMPLATE';

    export const ACCEPT_CHECK_SWIPE_CIF = 'ChangeActionType_ACCEPT_CHECK_SWIPE_CIF';

    export const GET_ACCOUNT_EXISTING = 'ChangeActionType_GET_ACCOUNT_EXISTING';  // 口座存在チェック
    export const SET_CIF_INFORMATION = 'ChangeActionType_SET_CIF_INFORMATION';  // CIF情報照会
    export const TRANSFER_TO_CIF_INFORMATION = 'ChangeActionType_TRANSFER_TO_CIF_INFORMATION';  // 変更内容→CIF情報照会へ転換
    export const SAVING_PASSWORD = 'ChangeActionType_SAVING_PASSWORD';  // パスワード保存
    export const SET_SWIPE_INFO: string = 'ChangeActionType_SET_SWIPE_INFO';
    export const GET_UPDATE_HOLDER_INFO_TELEPHONE_NO: string = 'ChangeActionType_GET_UPDATE_HOLDER_INFO_TELEPHONE_NO';
    export const GET_UPDATE_HOLDER_INFO: string = 'ChangeActionType_GET_UPDATE_HOLDER_INFO';
    export const INQUIRE_ACCOUNT_BALANCE: string = 'ChangeActionType_INQUIRE_ACCOUNT_BALANCE';
    export const SET_SWIPE_INFO_FROM_CHAT_FLOW: string = 'ChangeActionType_SET_SWIPE_INFO_FROM_CHAT_FLOW';
    export const CLEAR_DOCUMENTS: string = 'CLEAR_DOCUMENTS';
    export const SET_SYSTEM_TIME = 'ChangeActionType_SET_SYSTEM_TIME';
    export const SET_DEFAULT_ZIP_CODE = 'ChangeActionType_SET_DEFAULT_ZIP_CODE'; // 郵便番号 default value

    export const GET_SAME_CUSTOMERS_INFO = 'ChangeActionType_GET_SAME_CUSTOMERS_INFO'; // 同一名義人
    export const SAVE_DOCUMENT_IMAGES = 'ChangeActionType_SAVE_DOCUMENT_IMAGES'; // 撮影した写真を保存
    export const SAVE_SKIPPED_DOCUMENT_PATTERN = 'ChangeActionType_SAVE_SKIPPED_DOCUMENT_PATTERN'; // 書類パターン(A/B)ごとのスキップボタン押下有無を保存
    export const SAVE_DOCUMENT_X_NAME = 'ChangeActionType_SAVE_DOCUMENT_X_NAME'; // 本人確認チャットでの書類パターンXの表示名称を保存
    export const SAVE_IS_ALREADY_CONFIRM_C = 'ChangeActionType_SAVE_IS_ALREADY_CONFIRM_C'; // 本人確認チャットにおける書類パターンCの聴取有無を保存
    export const CLEAR_NAME_IDENTITY_DATA = 'ChangeActionType_CLEAR_NAME_IDENTITY_DATA'; // 名寄せ処理のデータをクリア`
    export const SET_ADDRESS_DIFFERENCE_FLG = 'ChangeActionType_SET_ADDRESS_DIFFERENCE_FLG'; // 住所差分あることを登録`
    export const SET_NAME_DIFFERENCE_FLG = 'ChangeActionType_SET_NAME_DIFFERENCE_FLG'; // `氏名差分あることを登録`
    export const SET_TELPHONE_DIFFERENCE_FLG = 'ChangeActionType_SET_TELPHONE_DIFFERENCE_FLG'; // 電話番号差分あることを登録`
    export const SAVE_IS_ALREADY_CONFIRM_B = 'ChangeActionType_SAVE_IS_ALREADY_CONFIRM_B'; // 本人確認チャットにおける書類パターンBの聴取有無を保存
    export const SET_ADDRESS_CHANGE_FLG = 'ChangeActionType_SET_ADDRESS_CHANGE_FLG'; // `住所変更したことを登録`
    export const SET_NAME_CHANGE_FLG = 'ChangeActionType_SET_NAME_CHANGE_FLG'; // `氏名変更したことを登録`
    export const SET_TEL_CHANGE_FLG = 'ChangeActionType_SET_TEL_CHANGE_FLG'; // `電話変更したことを登録`
    export const GET_CUSTOMERS_INFOS_DATA = 'ChangeActionType_GET_CUSTOMERS_INFOS_DATA'; // 複数顧客情報を取得

    export const REGEST_ADD_CHECK_DATA = 'ChangeActionType_REGEST_ADD_CHECK_DATA';

    export const SET_BC_HOLDING_STATUS = 'ChangeActionType_SET_BC_HOLDING_STATUS';
    export const SET_CD_HOLDING_STATUS = 'ChangeActionType_SET_CD_HOLDING_STATUS';
    export const MODIFY_CHECKBOX_STATUS = 'ChangeActionType_MODIFY_CHECKBOX_STATUS'; // チェックボックス変更イベント
    export const EDIT_SUBMIT_DATA = 'ChangeActionType_EDIT_SUBMIT_DATA'; // submitDataの編集
    export const EDIT_SUBMIT_DATA_NESTED = 'ChangeActionType_EDIT_SUBMIT_DATA_NESTED'; // submitDataの編集(入れ子構造のデータ編集)
    export const SET_STATE_DATA = 'ChangeActionType_SET_STATE_DATA'; // stateのある項目値を変更
    export const REMOVE_NOT_MASKING_CONFIRM_IMAGES = 'ChangeActionType_REMOVE_NOT_MASKING_CONFIRM_IMAGES'; // 写真未確認状態管理オブジェクトから確認済内容を削除

    export const CLEAR_EXISTING_ACCOUNT = 'ChangeActionType_CLEAR_EXISTING_ACCOUNT';
    export const SET_CUSTOMER_APPLY_START_DATE = 'ChangeActionType_SET_CUSTOMER_APPLY_START_DATE';
    export const NEED_INPUT_PHONE_NO = 'ChangeActionType_NEED_INPUT_PHONE_NO';
    export const ACCEPT_CHECK_FOR_NAME_DIF_CIF = 'ChangeActionType_ACCEPT_CHECK_FOR_NAME_DIF_CIF';
    export const ACCEPT_CHECK_FOR_TEL_DIF_CIF = 'ChangeActionType_ACCEPT_CHECK_FOR_TEL_DIF_CIF';
    export const ACCEPT_CHECK_FOR_ADDRESS_DIF_CIF = 'ChangeActionType_ACCEPT_CHECK_FOR_ADDRESS_DIF_CIF';
    export const SEARCH_REGION_CODE = 'ChangeActionType_SEARCH_REGION_CODE';
    export const CHARACTER_CHECK = 'ChangeActionType_CHARACTER_CHECK'; // 文字チェック

    export const SET_NATIONALITY = 'ChangeActionType_SET_NATIONALITY';
    export const FILTERING_INQUIRY = 'ChangeActionType_FILTERING_INQUIRY';
    export const SET_LAST_FILTERING_PARAMS = 'ChangeActionType.SET_LAST_FILTERING_PARAMS';

    export const SET_MEDIUM_INFO = 'ChangeActionType.SET_MEDIUM_INFO';
    export const UNACCEPTABLES_NG = 'ChangeActionType.UNACCEPTABLES_NG';
    export const RESET_NOT_MASKING_CONFIRM_IMAGES = 'ChangeActionType_RESET_NOT_MASKING_CONFIRM_IMAGES'; // 写真未確認状態管理オブジェクト変更イベント;
    export const MAKE_ALL_CIF_DIFFERENCE_LIST = 'ChangeActionType_MAKE_ALL_CIF_DIFFERENCE_LIST';
    export const SET_DATA = 'ChangeActionType_SET_DATA';
    export const SET_BC_SUICA_LOST = 'ChangeActionType_SET_BC_SUICA_LOST';
    export const CLEAR_ONE_SET_CARD_PASSWORD = 'ChangeActionType_CLEAR_ONE_SET_CARD_PASSWORD';
    export const CLEAR_HOLDER_NAME = 'ChangeActionType_CLEAR_HOLDER_NAME';
    export const CLEAR_HOLDER_ADDRESS = 'ChangeActionType_CLEAR_HOLDER_ADDRESS';
    export const CLEAR_HOLDER_PHONE_NO = 'ChangeActionType_CLEAR_HOLDER_PHONE_NO';
    export const RESET_SHOW_CHATS = 'ChangeActionType_RESET_SHOW_CHATS';
    export const RESET_CHANGE_IDENTI_DOCUMENTS = 'ChangeActionType_RESET_CHANGE_IDENTI_DOCUMENTS';
    export const CLEAR_IDENTI_DATA = 'ChangeActionType_RESET_CLEAR_IDENTI_DATA';
    export const BACKUP_CHANGE_IDENTI_DOCS = 'ChangeActionType_BACKUP_CHANGE_IDENTI_DOCS';
    export const SET_ORIGIN_SUBMIT_DATA = 'ChangeActionType_SET_ORIGIN_SUBMIT_DATA';
    export const CLEAR_ADD_CHECK_DATA = 'ChangeActionType_CLEAR_ADD_CHECK_DATA';
    export const CLEAR_CHANGE_IDENTI_DOCS = 'ChangeActionType_CLEAR_CHANGE_IDENTI_DOCS';
    export const SKIP = 'ChangeActionType_SKIP';
    export const SET_ADDRESS_CODE = 'ChangeActionType_SET_ADDRESS_CODE';
    export const CLEAR_ZIP_CODE = 'ChangeActionType_CLEAR_ZIP_CODE';
    export const DIFFERENCE_FLG_BACKUP = 'ChangeActionType_DIFFERENCE_FLG_BACKUP';
    export const SAVE_DOCUMENT_NAMES = 'ChangeActionType_SAVE_DOCUMENT_NAMES';
    export const SAVE_NAYOSE_DOCUMENT_NAMES = 'ChangeActionType_SAVE_NAYOSE_DOCUMENT_NAMES';
    export const SET_LINE_GUIDE_FLG = 'ChangeActionType_SET_LINE_GUIDE_FLG';
    export const SAVE_DOCUMENT_NAME = 'ChangeActionType_SAVE_DOCUMENT_NAME';
    export const CUSTOMER_INFOS_LIST = 'ChangeActionType_CUSTOMER_INFOS_LIST';
    export const SAVE_ADD_DOCUMENT_IMAGES = 'ChangeActionType_SAVE_ADD_DOCUMENT_IMAGES';
    export const SAVE_ADD_DOCUMENT_NAMES = 'ChangeActionType_SAVE_ADD_DOCUMENT_NAMES';
    export const CLEAR_ADD_IDENTITY_DATA = 'ChangeActionType_CLEAR_ADD_IDENTITY_DATA';
    export const SET_IS_CALLED_FROM_LOSS = 'ChangeActionType_SET_IS_CALLED_FROM_LOSS';
    export const SET_IS_CALLED_FROM_NEWEST = 'ChangeActionType_SET_IS_CALLED_FROM_NEWEST';
    export const SET_IS_CALLED_FROM_REPLACE = 'ChangeActionType_SET_IS_CALLED_FROM_REPLACE';
    export const SET_LOGIN_TABLET_APPLY_ID = 'ChangeActionType_SET_LOGIN_TABLET_APPLY_ID';
    export const BACKUP_ADD_IMAGES = 'BACKUP_ADD_IMAGES';
    export const BACKUP_ADD_IMAGES_RESTORE = 'ChangeActionType.BACKUP_ADD_IMAGES_RESTORE';
}

@Injectable()
export class ChangeAction extends Action implements ChatFlowActionInterface {
    constructor(
        private httpService: HttpService,
        private deviceService: DeviceService,
        private modalDigitalStore: ModalDigitalStore,
        private hostErrorService: HostErrorService,
        private ngZone: NgZone,
        private logging: LoggingService,
        private changeUtils: ChangeUtils
    ) {
        super();
    }

    // modify checkbox status
    public modifyCheckboxStatus(name: string) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.MODIFY_CHECKBOX_STATUS,
            data: name
        });
    }

    /**
     * submitDataを編集する
     *
     * @param {*} data
     * @memberof SavingsAction
     */
    public editSubmitData(index: number, key: string, val: any) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.EDIT_SUBMIT_DATA,
            data: {
                index: index,
                key: key,
                val: val
            }
        });
    }

    /* 写真未確認状態管理オブジェクトから確認済内容を削除
    *
    * @param {*} maskingConfirmImgStatus
    * @memberof ChangeAction
    */
    public removeNotMaskingConfirmImages(maskingConfirmImgStatus: { documentName: string, index: number }) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.REMOVE_NOT_MASKING_CONFIRM_IMAGES,
            data: maskingConfirmImgStatus
        });
    }

    /**
     * 入れ子構造のsubmitDataを編集する
     * マスキング確認完了しないオブジェクトをリセット。
     *
     * @param {ClearChangeImagesClickRecordType} type リセットタイプ
     * @memberof ChangeAction
     */
    public resetNotMaskingConfirmImages(type: ClearChangeImagesClickRecordType) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.RESET_NOT_MASKING_CONFIRM_IMAGES,
            data: type
        });
    }

    /**
     * submitDataの値を変更する
     *
     * @param {*} data
     * @memberof SavingsAction
     */
    public editSubmitDataNested(index: number, key: string, nestKey: string, val: any) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.EDIT_SUBMIT_DATA_NESTED,
            data: {
                index: index,
                key: key,
                nestKey: nestKey,
                val: val
            }
        });
    }

    public setAddressDifferenceFlg(isDifference: boolean) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_ADDRESS_DIFFERENCE_FLG,
            data: isDifference
        });
    }

    public setNameDifferenceFlg(isDifference: boolean) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_NAME_DIFFERENCE_FLG,
            data: isDifference
        });
    }

    public setTelphoneDifferenceFlg(isDifference: boolean) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_TELPHONE_DIFFERENCE_FLG,
            data: isDifference
        });
    }

    /**
     * 電話番号変更フラグを設定
     *
     * @param {boolean} isChanged
     * @memberof ChangeAction
     */
    public setTelChangeFlg(isChanged: boolean) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_TEL_CHANGE_FLG,
            data: isChanged
        });
    }

    /**
     * LINE登録ご案内のフラグを設定
     *
     * @param {boolean} isChanged
     * @memberof ChangeAction
     */
    public setLineGuideFlg() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_LINE_GUIDE_FLG,
        });
    }

    public transferSelfTradingList(value: AcceptionResultTradingCondition[]) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.TRANSFER_SELF_TRADING_LIST,
            data: value
        });
    }

    /**
     * 名寄せドキュメントを保存
     *
     * @param {string[]} images
     * @memberof ChangeAction
     */
    public registNameIdentityData(data) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.REGIST_NAME_IDENTITY_INFO,
            data: data
        });
    }

    public async validatePasswordNotSetCifIno(params: any) {
        // ICログ
        try {
            this.logging.saveCustomOperationLog(
                'change',
                'ic-data:' + (params.params.icCardInfo ? params.params.icCardInfo.length : 'null')
            );
        } catch (ex) {
            this.logging.saveCustomOperationLog('change', 'Exception');
        }
        return new Promise((resolve, reject) => {
            this.httpService.post(API_URL.CARD_CERTIFICATION_CHECK, params, null, SpinnerType.SHOW_TRANSPARENT, true)
                .pipe(
                    tap((res) => {
                        // this.setCifInfo(res.result.cifInfoInquiryResponse);
                    })
                ).subscribe(
                    (result) => {
                        if (result.status === HttpStatus.SUCCESS) {
                            resolve(true);
                        } else if (result.status === HttpStatus.HOST_ERROR) {
                            this.hostErrorService.push({
                                resultCode: result.errors.data.resultCode,
                                errorCode: result.errors.data.errorCode,
                                message: result.errors.message,
                                handel: () => {
                                    resolve(false);
                                }
                            });
                        } else {
                            throw new HttpStatusError(API_URL.CARD_CERTIFICATION_CHECK, result.status, result.errors);
                        }
                    }, (error) => {
                        reject(error);
                    });
        });
    }

    /**
     * cif情報をセット
     * @param info cif情報
     */
    public setCifInfo(info: any) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_CIF_INFO,
            data: info
        });
    }
    /**
     * ドキュメントを保存
     *
     * @param {string[]} images
     * @memberof ChangeAction
     */
    public saveDocumentImages(params: { image: string, name: string, code: string }) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SAVE_DOCUMENT_IMAGES,
            data: params
        });
    }

    /**
     * ドキュメントを保存
     *
     * @param {string[]} images
     * @memberof ChangeAction
     */
    public saveAddDocumentImages(params: { image: string, code: string }) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SAVE_ADD_DOCUMENT_IMAGES,
            data: params
        });
    }

    /**
     * 書類パターン(A/B)ごとのスキップボタン押下有無を保存
     *
     * @param identificationDocument3A 書類パターンAの撮影書類
     * @param identificationDocument3B 書類パターンBの撮影書類
     * @memberof ChangeAction
     */
    public saveSkippedDocumentPattern(identificationDocument3A: string, identificationDocument3B: string) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SAVE_SKIPPED_DOCUMENT_PATTERN,
            data: {
                identificationDocument3A: identificationDocument3A,
                identificationDocument3B: identificationDocument3B,
            }
        });
    }

    /**
     * 本人確認チャットでの書類パターンXの表示名称を保存
     *
     * @param identificationDocument3XDisplayedName 書類パターンXの表示名称
     * @memberof ChangeAction
     */
    public saveDocumentXName(identificationDocument3XDisplayedName: string) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SAVE_DOCUMENT_X_NAME,
            data: {
                identificationDocument3XDisplayedName: identificationDocument3XDisplayedName
            }
        });
    }

    /**
     * 追加確認で撮影した書類名を保存
     * @param param
     */
    public saveAddDocumentNames(param) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SAVE_ADD_DOCUMENT_NAMES,
            data: param
        });
    }

    public saveDocumentNames(param) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SAVE_DOCUMENT_NAMES,
            data: param
        });
    }

    public saveNayoseDocumentNames(param) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SAVE_NAYOSE_DOCUMENT_NAMES,
            data: param
        });
    }

    /**
     * 本人確認チャットにおける書類パターンCの聴取有無を保存
     *
     * @param isAlreadyConfirmC 書類パターンXの表示名称
     * @memberof ChangeAction
     */
    public saveIsAlreadyConfirmC(isAlreadyConfirmC: boolean) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SAVE_IS_ALREADY_CONFIRM_C,
            data: {
                isAlreadyConfirmC: isAlreadyConfirmC
            }
        });
    }

    /**
     * 本人確認チャットにおける書類パターンBの聴取有無を保存
     *
     * @param isAlreadyConfirmB 書類パターンXの表示名称
     * @memberof ChangeAction
     */
    public saveIsAlreadyConfirmB(isAlreadyConfirmB: boolean) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SAVE_IS_ALREADY_CONFIRM_B,
            data: {
                isAlreadyConfirmB: isAlreadyConfirmB
            }
        });
    }

    /**
     * 口座開設支店店番を設定する
     * @param branchNo 口座開設支店番号
     */
    public setAgencyBranchInfo(branchNo: string) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_AGENCY_BRANCH_INFO,
            data: { branchNo: branchNo }
        });
    }

    public setBankclerkId(bankclerkId: string) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_BANKCLERK_ID,
            data: { bankclerkId: bankclerkId }
        });
    }

    public loadTemplate(file: string, pageIndex: number) {

        this.httpService.get('/chatflow/definition/' + file).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    fileInfo: response.result.fileInfos,
                    pageIndex: pageIndex
                }
            });
        });
    }

    public branchStatusInsert(params: any) {
        this.httpService.post('/branch-info/tabletInfo/insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.BRANCH_STATUS_INSERT,
                data: response.result
            });
        });
    }

    public branchStatusUpdate(params: any) {
        this.httpService.post(API_URL.BRANCH_STATUS_UPDATE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.BRANCH_STATUS_UPDATE,
                data: response.result
            });
        });
    }

    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    public clearStore() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR
        });
    }

    /**
     * 連続諸届けで1回目終わるとき、クリアすべき部分データをクリア
     *
     * @memberof ChangeAction
     */
    public clearPartStore() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_PARTS
        });
    }

    public clearShowChats() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_SHOW_CHATS
        });
    }

    /**
     * 名寄せ処理のデータをクリア
     *
     * @memberof ChangeAction
     */
    public clearNameIdentityDatas() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_NAME_IDENTITY_DATA,
            data: null
        });
    }

    public setCustomerApplyEndDate() {
        this.setAsSystemTime(ApplyDate.CUSTOMER_APPLY_END_DATE);
    }

    public setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_ANSWER,
            data: answer
        });
    }

    public setStateSubmitDataValue(param: any) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_STATE_SUBMIT_DATA_VALUE,
            data: param
        });
    }

    public saveSubmitData(params: any) {
        this.httpService.post('/branch-info/tabletInfo/bankclerk-confirm-insert', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.BRANCH_INFO_INSERT,
                data: response.result
            });
        });
    }

    /**
     * 変更前の情報をコピーする
     *
     * @memberof ChangeAction
     */
    public copySubmitData() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.COPY_SUBMIT_DATA
        });
    }

    public submitDataBackup() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SUBMIT_DATA_BACKUP
        });
    }

    public resetSubmitData(param: any) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.RESET_SUBMIT_DATA,
            data: param
        });
    }

    public backupChangeIdentiDocs() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.BACKUP_CHANGE_IDENTI_DOCS,
        });
    }

    public backupAddImages() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.BACKUP_ADD_IMAGES,
        });
    }

    public backupAddImagesRestore() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.BACKUP_ADD_IMAGES_RESTORE,
        });
    }

    public clearIdentiData() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_IDENTI_DATA,
        });
    }

    public clearChangeIdentiDocs() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_CHANGE_IDENTI_DOCS,
        });
    }

    public clearAddCheckData() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_ADD_CHECK_DATA,
        });
    }

    public resetChangeIdentiDocuments(params: any) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.RESET_CHANGE_IDENTI_DOCUMENTS,
            data: params
        });
    }

    public setOriginChangeSubmitData() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_ORIGIN_SUBMIT_DATA,
        });
    }

    /**
     * 差分のフラグをバックアップする
     */
    public differenceFlgBackup() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.DIFFERENCE_FLG_BACKUP,
        });
    }

    /**
     * submit dataを更新
     *
     * @param data 書類カテゴリと選択された書類
     * @param isHolderPage 本人確認画面フラグ
     * @param isHolder 本人フラグ
     */
    public setDocumentCategory(data: DocumentCategorySubjectData) {
        switch (data.code) {
            // コピー徴求ができない理由
            case CodeCategory.CODE_CATEGORY_NO_COPY_REASON:
            // 住所が相違する理由
            case CodeCategory.CODE_CATEGORY_DIFFERENT_ADDRESS_REASON:
                this.setStateSubmitDataValue({
                    name: data.key,
                    value: data.entity ? data.entity.data : null
                });
                break;
        }
    }

    public retrieveDropList(params: any) {
        this.httpService.get('/categoryCodes/retrieve', params).subscribe((response: any) => {
            // this.httpClient.get('./assets/datas/drop-down-list-account.json', params).subscribe((response: any) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.RETRIEVE_DROP_LIST,
                data: response.result
            });
        });
    }

    public setTabletStartDate() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_TABLE_START_DATE
        });
    }

    public chatFlowCompelete(nextChatName: string) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CHAT_FLOW_COMPELETE,
            data: nextChatName
        });
    }

    public resetLastNode() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.RESET_LAST_NODE
        });
    }

    /**
     * 指定した順番をリセット。
     *
     * @param {number} order
     * @param {number} pageIndex
     */
    public resetToNode(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.RESET_TO_ORDER,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    public setshowNamePage(setshowNamePage: boolean) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_SHOW_NAME_PAGE,
            data: setshowNamePage
        });
    }

    public setshowAddressPage(setshowAddrssePage: boolean) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_SHOW_ADRRESS_PAGE,
            data: setshowAddrssePage
        });
    }

    public loadConfirmPageTemplate(file: string, pageIndex: number) {

        this.httpService.get('/chatflow/definition/' + file, null, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.GET_CONFIRM_PAGE_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos,
                }
            });
        });
    }

    /**
     * Request customer status
     * @param questions ymlファイルの格納データ
     * @param pageIndex ページ番号
     */
    public acceptCheckForSwipeCif(questions: ChangeQuestionsModel, dict: any) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, dict, undefined, SpinnerType.SHOW, true).subscribe((response: any) => {

            // エラー発生時
            if (response instanceof HttpStatusError) {
                // 事故取引禁止注意コードエラーの場合、受付可否チェック（住変）NGとしてSignalを送信する
                if (response.errors && response.errors.data && this.changeUtils.isHostError(response.errors.data.errorCode)) {
                    this.dispatcher.dispatch({
                        actionType: ChangeActionType.UNACCEPTABLES_NG,
                        data: response
                    });
                    return;
                } else {
                    // 上記以外のエラーの場合、共通エラーハンドリング処理にて処理する
                    this.ngZone.runTask(() => {
                        throw response;
                    });
                    return;
                }
            }

            const result: AcceptionResult = response.result || {};
            // 次の業務に移動する
            this.dispatcher.dispatch({
                actionType: ChangeActionType.ACCEPT_CHECK_SWIPE_CIF,
                data: {
                    item: questions,
                    response: result || {}
                }
            });
        });
    }

    /**
     * 口座存在チェック
     * @param params 口座存在チェック用パラメータ
     */
    public checkAccountExisting(params: AccountExistCheckInterface) {
        this.httpService.post(API_URL.CB_CHECK_ACCOUNT_EXISTING, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.GET_ACCOUNT_EXISTING,
                data: response.result
            });
        });
    }

    /**
     * CIF情報照会
     * @param params CIF情報照会用パラメータ
     */
    public getCifInformation(cifParams: SimpleCifInfoInquiryInterface) {
        this.httpService.post(API_URL.CB_GET_CIF_INFORMATION, cifParams, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.SET_CIF_INFORMATION,
                data: response.result
            });
        });
    }

    /**
     * 変更内容→CIF情報照会へ転換する
     * @param data 変更データ
     */
    public transferModifyToCifInfo(data: any) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.TRANSFER_TO_CIF_INFORMATION,
            data: data
        });
    }

    /**
     * 暗号番号認証後、入力したパスワードを保存する
     * @param data パスワード
     */
    public savePassword(data: string) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SAVING_PASSWORD,
            data: data
        });
    }

    /**
     * QRに含まれる情報をstateにセット。
     * @param params QRコード受付情報
     */
    public setSwipeInfo(params: any) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_SWIPE_INFO,
            data: params
        });
    }

    /**
     * 電話番号の変更に対しての更新系APIを呼び出す
     * @param changeItems 変更項目フラグ
     * @param data 格納データ
     */
    public updateTelephoneChangedInfo(changeItems: any, data: ChangeState) {

        const baseParamsForCoreBanking = this.createCoreBankingRequestBaseParams(data);
        // 電話番号変更の更新系APIを呼び出す
        const baseParams: ChangeBaseInterface<TelephoneChangeParams> = this.createChangeRequestBaseParams(
            CoreBankingConstants.ApiPathConsts.TELEPHONE_CHANGE, data);
        const telephoneBaseParams = this.createTelephoneBaseParams(changeItems, data, baseParams.formerInfo);
        baseParams.params = {
            ...baseParamsForCoreBanking,
            ...telephoneBaseParams
        };
        const params: TelephoneChangeInterface = {
            ...baseParams
        };

        this.httpService.post(API_URL.CB_UPDATE_TELEPHONE, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.GET_UPDATE_HOLDER_INFO_TELEPHONE_NO,
                data: response.result
            });
        });
    }

    /**
     * 住所、電話番号の変更に対しての更新系APIを呼び出す
     * @param data 送信内容
     */
    public updateChangedInfo(data: any) {
        this.httpService.post(API_URL.CB_UPDATE_ADDRESS_TEL, data, undefined, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.GET_UPDATE_HOLDER_INFO,
                data: response.result
            });
        });
    }

    /**
     * 複数顧客の情報を取得
     * @param data 名寄せ対象
     * @param tabletApplyId
     * @param receptionTenban
     */
    public getDuplicateCifInfos(data: DuplicateAccountTenpoInfo[], tabletApplyId: number, receptionTenban: string) {
        // 送信パラメータを作成
        const sendParams: any = {};
        sendParams.tabletApplyId = tabletApplyId;
        const params: any = {};
        params.receptionTenban = receptionTenban;
        params.accounts = [];
        data.forEach((item) => {
            const obj: any = {};
            if (item.accountInfos && item.accountInfos.length > 0) {
                obj.tenban = item.accountInfos[0].tenban;
                obj.accountType = item.accountInfos[0].accountType;
                obj.accountNo = item.accountInfos[0].accountNo;
            } else {
                obj.customerId = item.customerId;
            }

            params.accounts.push(obj);
        });

        sendParams.params = params;

        // サーバに送信する
        this.httpService.post(API_URL.CB_CIF_INFOS_INQUIRY, sendParams).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.GET_CUSTOMERS_INFOS_DATA,
                data: response.result
            });
        });
    }

    /**
     * 名寄せ候補に国籍を設定
     */
    public setNationality() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_NATIONALITY,
        });
    }

    /**
     * 口座残高照会
     * @param params 口座残高照会用パラメータ
     */
    public inquireAccountBalance(params: AccountBalanceInquiryInterface) {
        this.httpService.post(API_URL.CB_GET_ACCOUNT_BALANCE, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.INQUIRE_ACCOUNT_BALANCE,
                data: response.result
            });
        });
    }

    /**
     * 各業務フローからのQrコードをstateにセット。
     * @param inputParams: 各業務フローからのQrコード情報
     */
    public setSwipeInfoFromChatFlow(inputParams: any) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_SWIPE_INFO_FROM_CHAT_FLOW,
            data: inputParams
        });
    }

    /**
     * クリア本人確認資料
     */
    public clearStoreDocuments() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_DOCUMENTS
        });
    }

    /**
     * get holderZipCode 郵便番号
     * @param prefectureKanji 都道府県
     * @param countyUrbanVillageKanji 市区町村
     * @param streetKanji 町丁名
     */
    public getHolderZipCode(prefectureKanji: string, countyUrbanVillageKanji: string, streetKanji: string) {
        const params = {
            prefectureKanji: prefectureKanji,
            countyUrbanVillageKanji: countyUrbanVillageKanji,
            streetKanji: streetKanji
        };
        this.httpService.get(API_URL.ADDRESS_ZIP_CODE_SEARCH, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.GET_HOLDER_ZIP_CODE,
                data: response.result.zipCode
            });
        }
        );
    }

    /**
     * set the item value as the current time of server
     * @param key the checbox item need to modify status
     */
    public setAsSystemTime(key: string) {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.SET_SYSTEM_TIME,
                data: {
                    key: key,
                    systemTime: response.result.value
                }
            });
        });
    }

    /**
     * 郵便番号　default value
     */
    public setDefaultZipCode() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_DEFAULT_ZIP_CODE,
        });
    }

    /**
     * 同一名義人APIを実行
     *
     * @memberof ChangeAction
     */
    public findDuplicateAccountInfos(params: any) {
        this.httpService.post(API_URL.CB_SAME_CUSTOMERS, params, undefined, undefined).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.GET_SAME_CUSTOMERS_INFO,
                data: response.result
            });
        });
    }

    public registAddCheckData(data) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.REGEST_ADD_CHECK_DATA,
            data: data,
        });
    }

    /**
     * 名寄せ先は選択前の状態に戻す
     *
     * @memberof ChangeAction
     */
    public clearExistingAccount() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_EXISTING_ACCOUNT
        });
    }

    /**
     * 顧客申し込み開始時間を設定する
     */
    public setCustomerApplyStartDate() {
        this.httpService.get(API_URL.SERVER_SYSTEM_TIME_URL).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.SET_CUSTOMER_APPLY_START_DATE,
                data: {
                    systemTime: response.result.value
                }
            });
        });
    }

    /**
     * 追加確認先は選択前の状態に戻す
     *
     * @memberof ChangeAction
     */
    public clearAddIdentityData() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_ADD_IDENTITY_DATA
        });
    }

    /**
     * フィルタリングシステム検索
     * @param params フィルタリングシステム検索パラメーター
     */
    public filterInquiry(params: any) {
        this.httpService.post(API_URL.FILTERING_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.FILTERING_INQUIRY,
                data: response.result
            });
        });
    }

    /**
     * 携帯電話入力始めるのチャットに戻る
     *
     * @memberof ChangeFlowAction
     */
    public needInputPhoenNo() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.NEED_INPUT_PHONE_NO,
        });
    }
    /**
     * フィルタリングシステムへの照会パラメータを保存
     *
     * @param {FilteringParameterEntity} curFilteringParamters
     * @memberof ChangeAction
     */
    public setLastFilteringParameters(curFilteringParamters: FilteringParameterEntity) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_LAST_FILTERING_PARAMS,
            data: curFilteringParamters
        });
    }

    /**
     * 回答内容を編集する
     *
     * @param order オーダー
     * @param pageIndex ページインデックス
     * @param answerOrder 回答順
     */
    public editAnswer(order: number, pageIndex: number, answerOrder: number, orderIndex?: number) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.EDIT_CHAT,
            data: { order: order, pageIndex: pageIndex, answerOrder: answerOrder, orderIndex: orderIndex }
        });
    }

    public acceptCheckForNameDifCif(params: any, difInfos: ChangeDifferenceEntity[]) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, params, undefined, SpinnerType.SHOW, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.ADDRESS_CHANGE_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: ChangeActionType.ACCEPT_CHECK_FOR_NAME_DIF_CIF,
                        data: {
                            res: response instanceof HttpStatusError ? response.errors.data : response.result,
                            difItems: difInfos
                        }
                    });
                }
            }
        );
    }

    public acceptCheckForTelDifCif(params: any, difInfos: ChangeDifferenceEntity[]) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, params, undefined, SpinnerType.SHOW, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.ADDRESS_CHANGE_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: ChangeActionType.ACCEPT_CHECK_FOR_TEL_DIF_CIF,
                        data: {
                            res: response instanceof HttpStatusError ? response.errors.data : response.result,
                            difItems: difInfos
                        }
                    });
                }
            }
        );
    }

    public acceptCheckForAddressDifCif(params: any, difInfos: ChangeDifferenceEntity[]) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, params, undefined, SpinnerType.SHOW, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.ADDRESS_CHANGE_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: ChangeActionType.ACCEPT_CHECK_FOR_ADDRESS_DIF_CIF,
                        data: {
                            res: response instanceof HttpStatusError ? response.errors.data : response.result,
                            difItems: difInfos
                        }
                    });
                }
            }
        );
    }

    /**
     * 文字チェック
     * @param params 文字チェックパラメータ
     */
    public characteCheck(params: any, handel?: any) {
        this.httpService.post(API_URL.CHARACTER_CHECK, params, null, SpinnerType.SHOW_TRANSPARENT, true)
            .subscribe((result) => {
                if (result.status === HttpStatus.SUCCESS) {
                    this.dispatcher.dispatch({
                        actionType: ChangeActionType.CHARACTER_CHECK,
                        data: result.result
                    });
                } else if (result.status === HttpStatus.HOST_ERROR) {
                    if (result.errors.data &&
                        result.errors.data.resultCode &&
                        result.errors.data.resultCode === HostResultCode.REENTER) {
                        this.hostErrorService.push({
                            resultCode: result.errors.data.resultCode,
                            errorCode: result.errors.data.errorCode,
                            message: result.errors.message,
                            handel: handel
                        });
                    }
                } else {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.CHARACTER_CHECK, result.status, result.errors);
                    });
                    return;
                }
            });
    }
    /**
     * 地域コードを検索する(WebAPI呼び出し)
     * @param params 地域コード検索条件
     */
    public searchRegionCode(params: RegionCodeSearchRequestEntity) {
        // 検索条件不足の場合はWebAPI呼ばない
        if (StringUtils.isEmpty(params.streetKanji)) {
            const regionCode = new RegionCodeEntity();
            regionCode.regionCodeDeterminationMethod = RegionCodeDeterminationMethod.WITHOUT_STREET;
            this.dispatcher.dispatch({
                actionType: ChangeActionType.SEARCH_REGION_CODE,
                data: regionCode
            });
        } else {
            this.httpService.get(API_URL.REGION_CODE_SEARCH, { params: params }).subscribe((response) => {
                this.dispatcher.dispatch({
                    actionType: ChangeActionType.SEARCH_REGION_CODE,
                    data: response.result
                });
            });
        }
    }

    /**
     * フィルタリングシステムへの照会結果を保存
     *
     * @param {*} data
     * @memberof ChangeAction
     */
    public setLastFilteringResult(data: any) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.FILTERING_INQUIRY,
            data: data
        });
    }

    /**
     * 内部API: 保有通帳・カード・印鑑情報照会
     * @param params
     */
    public getMediumInfo(params: any) {
        this.httpService.post(API_URL.MEDIUM_INFO_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.SET_MEDIUM_INFO,
                data: response.result
            });
        });
    }

    /**
     * 内部API：住所コード取得
     * @param params
     */
    public getAddressCode(params: any) {
        this.httpService.get(API_URL.GET_ADDRESS_CODE, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: ChangeActionType.SET_ADDRESS_CODE,
                data: response.result
            });
        });
    }

    /**
     * 郵便番号をクリア
     */
    public clearZipCode() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_ZIP_CODE,
        });
    }

    /**
     *  カード交付方法に郵送をセット
     */
    public setMailDelivery() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_DATA,
        });
    }

    /**
     * BCバンクカードSuica喪失届出済をセット
     */
    public setBcSuicaLost() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_BC_SUICA_LOST,
        });
    }

    /**
     * ワンセットカードの暗証番号をクリア
     */
    public clearOneSetCardPassword() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_ONE_SET_CARD_PASSWORD,
        });
    }

    /**
     * 修正チャットモーダルを開く際、変更後の氏名をクリア
     */
    public clearHolderName() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_HOLDER_NAME,
        });
    }

    /**
     * 修正チャットモーダルを開く際、変更後の住所をクリア
     */
    public clearHolderAddress() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_HOLDER_ADDRESS,
        });
    }

    /**
     * 修正チャットモーダルを開く際、変更後の電話番号をクリア
     */
    public clearHolderPhoneNo() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.CLEAR_HOLDER_PHONE_NO,
        });
    }

    /**
     * Skip node
     * @param nextOrder the order skip to
     */
    public skip() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SKIP,
        });
    }

    /**
     * 選択した撮影書類名を保存
     * @param param
     */
    public saveDocumentName(param) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SAVE_DOCUMENT_NAME,
            data: param
        });
    }

    /**
     *  喪失からの呼出フラグを設定
     *
     * @param {boolean} isChanged
     * @memberof ChangeAction
     */
    public setIsCalledFromLoss(isCalledFromLoss: boolean) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_IS_CALLED_FROM_LOSS,
            data: isCalledFromLoss
        });
    }
    /**
     *  喪失系業務からの呼出しの際、LoginStateのtabletApplyIdをセットするメソッドの処理
     */
    public setLoginTabletApplyId() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_LOGIN_TABLET_APPLY_ID,
        });
    }

    /**
     *  差替からの呼出フラグを設定
     *
     * @param {boolean} isChanged
     * @memberof ChangeAction
     */
    public setIsCalledFromReplace(isCalledFromReplace: boolean) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_IS_CALLED_FROM_REPLACE,
            data: isCalledFromReplace
        });
    }
    /**
     *  差替系業務からの呼出しの際、LoginStateのtabletApplyIdをセットするメソッドの処理
     */
    public setLoginTabletApplyIdReplace() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_LOGIN_TABLET_APPLY_ID,
        });
    }

    /**
     *  カード新規発行からの呼出フラグを設定
     *
     * @param {boolean} isChanged
     * @memberof ChangeAction
     */
    public setIsCalledFromNewest(isCalledFromNewest: boolean) {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_IS_CALLED_FROM_NEWEST,
            data: isCalledFromNewest
        });
    }
    /**
     *  カード新規発行系業務からの呼出しの際、LoginStateのtabletApplyIdをセットするメソッドの処理
     */
    public setLoginTabletApplyIdNewest() {
        this.dispatcher.dispatch({
            actionType: ChangeActionType.SET_LOGIN_TABLET_APPLY_ID,
        });
    }

    /**
     * 名寄せリスト作成APIを実行
     * @param params
     */
    public cutomerInfosList(params: any) {
        this.httpService.post(API_URL.CUSTOMER_INFOS_LIST, params, undefined, SpinnerType.SHOW, true).subscribe(
            (response) => {
                this.dispatcher.dispatch({
                    actionType: ChangeActionType.CUSTOMER_INFOS_LIST,
                    data: {
                        res: response instanceof HttpStatusError ? response.errors.data : response.result,
                    }
                });
            }
        );
    }

    private createFormerInfo(data: ChangeState): any {
        const formerInfo: FormerInfo = {
            formerName: data.cifInfoInquiry.nameKanji,
            formerNameFurigana: StringUtils.convertZankaku2Hankaku(data.cifInfoInquiry.nameKana),
            formerGender: data.cifInfoInquiry.sex,
            formerRegionCode: data.cifInfoInquiry.regionCode,
            formerZipCode: (data.cifInfoInquiry.zipCode) ? data.cifInfoInquiry.zipCode.replace(/[-]/g, '') : data.cifInfoInquiry.zipCode,
            formerPrefectureKanji: data.cifInfoInquiry.prefectureKanji,
            formerCountyUrbanVillageKanji: data.cifInfoInquiry.countyUrbanVillageKanji,
            formerStreetKanji: data.cifInfoInquiry.streetKanji,
            formerPrefectureKana: data.cifInfoInquiry.prefectureKana,
            formerCountyUrbanVillageKana: data.cifInfoInquiry.countyUrbanVillageKana,
            formerStreetKana: data.cifInfoInquiry.streetKana,
            formerSubAddress: data.cifInfoInquiry.subAddress,
            formerSubAddressFurigana: data.cifInfoInquiry.subAddressKana,
            formerTelephoneNo: data.cifInfoInquiry.telephoneNo,
            formerMobileNo: data.cifInfoInquiry.mobileNo ? data.cifInfoInquiry.mobileNo.replace(/[-]/g, '') : data.cifInfoInquiry.mobileNo,
            formerBirthDate: data.cifInfoInquiry.birthday
        };
        return formerInfo;
    }

    private createChangeRequestBaseParams<T>(path: string, data: ChangeState) {
        const changeRequestBaseParams: ChangeBaseInterface<T> = {
            path: path,
            tabletApplyId: data.tabletApplyId,
            userMngNo: this.getUserMngNo(),
            formerInfo: this.createFormerInfo(data),
            timeInfo: this.createTabletApplyTimeInfo(data),
            params: undefined
        };
        return changeRequestBaseParams;
    }

    private createCoreBankingRequestBaseParams(data: ChangeState) {
        const coreBankingParamsBase: CoreBankingChangeParamsBase = {
            bankNo: CoreBankingConst.bankNo,
            receptionTenban: data.submitData.receptionBranchNo,
            receptionNo: data.submitData.receptionNo,
            terminalNo: this.deviceService.getDeviceId(),
            cifInfo: data.cifInfo,
            tabletApplyId: data.tabletApplyId
        };
        return coreBankingParamsBase;
    }

    private createTelephoneBaseParams(changeItems: any, data: ChangeState, formerInfo: FormerInfo) {
        const telephoneChanged = NumChanged.NO_CHANGE;
        const mobileChanged = NumChanged.NO_CHANGE;

        const telephoneChangeParamsBase: TelephoneChangeParamsBase = {
            telephoneNo: data.submitData.holderTelephoneNo,
            mobileNo: data.submitData.holderMobileNo.replace(/[-]/g, ''),
            telephoneChanged: telephoneChanged,
            mobileChanged: mobileChanged
        };
        return telephoneChangeParamsBase;
    }

    private createNameBaseParams(data: ChangeState) {
        const nameChangeParamsBase: NameChangeParamsBase = {
            name: data.submitData.holderName,
            nameKana: StringUtils.convertZankaku2Hankaku(data.submitData.holderNameFurigana),
        };
        return nameChangeParamsBase;
    }
    private createAddressBaseParams(data: ChangeState) {
        const addressChangeParamsBase: AddressChangeParamsBase = {
            zipcode: data.submitData.holderZipCode.replace(/[-]/g, ''),
            prefectureKanji: data.submitData.holderAddressPrefecture,
            countyUrbanVillageKanji: data.submitData.holderAddressCountyUrbanVillage,
            streetKanji: data.submitData.holderAddressStreetNameSelect,
            prefectureKana: data.submitData.holderAddressPrefectureFuriKana,
            countyUrbanVillageKana: data.submitData.holderAddressCountyUrbanVillageFuriKana,
            streetKana: data.submitData.holderAddressStreetNameFuriKanaSelect,
            address: data.submitData.holderAddressHouseNumber,
            addressKana: data.submitData.holderAddressHouseNumberFuriKana
        };
        return addressChangeParamsBase;
    }

    private createTabletApplyTimeInfo(data: ChangeState) {
        const timeInfo: TabletApplyTimeInfo = {
            tabletStartDate: data.submitData.tabletStartDate,
            customerApplyStartDate: data.submitData.customerApplyStartDate,
            customerApplyEndDate: data.submitData.customerApplyEndDate,
            bankclerkAuthenticationStartDate: data.submitData.bankclerkAuthenticationStartDate,
            bankclerkAuthenticationEndDate: data.submitData.bankclerkAuthenticationEndDate,
            swipeCardType: data.submitData.swipeCardType,
            wholeCif: data.submitData.wholeCif
        };
        return timeInfo;
    }

    private getUserMngNo(): string {
        if (!this.modalDigitalStore) {
            return null;
        }
        return this.modalDigitalStore.getState().bankclerkId;
    }

}
