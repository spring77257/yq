import { NgModule, Type } from '@angular/core';
import { HttpModule } from '@angular/http';
import { TopModule } from 'dhdt/branch/pages/common/top/top.module';

import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ChangeChatComponent } from 'dhdt/branch/pages/change/chat-flow/change-chat.component';
import { ChangeModifyChatComponent } from 'dhdt/branch/pages/change/chat-flow/change-modify-chat.component';
import { ChangeAddCheckInputHandler } from 'dhdt/branch/pages/change/chat-flow/handler/change-add-check.handler';
import {
    ChangeAddressHandler
} from 'dhdt/branch/pages/change/chat-flow/handler/change-address.handler';
import {
    ChangeDifferencialConfirmationInputHandler
} from 'dhdt/branch/pages/change/chat-flow/handler/change-diffierencial-confirmation.handler';
import {
    ChangeIdentificationDocumentInputHandler
} from 'dhdt/branch/pages/change/chat-flow/handler/change-identification-document.handler';
import { ChangeNameInputHandler } from 'dhdt/branch/pages/change/chat-flow/handler/change-name.handler';
import { ChangeTelInputHandler } from 'dhdt/branch/pages/change/chat-flow/handler/change-tel-input-handler';
import { ChangeAddCheckRenderer } from 'dhdt/branch/pages/change/chat-flow/rendere/change-add-check.render';
import {
    ChangeAddressRenderer
} from 'dhdt/branch/pages/change/chat-flow/rendere/change-address.renderer';
import {
    ChangeDifferencialConfirmationRenderer
} from 'dhdt/branch/pages/change/chat-flow/rendere/change-differencial-confirmation.renderer';
import { ChangeIdentificationDocumentRenderer } from 'dhdt/branch/pages/change/chat-flow/rendere/change-identification-document.renderer';
import { ChangeNameRenderer } from 'dhdt/branch/pages/change/chat-flow/rendere/change-name.renderer';
import { ChangeTelRenderer } from 'dhdt/branch/pages/change/chat-flow/rendere/change-tel.renderer';
import { ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { ChangeCompletionComponent } from 'dhdt/branch/pages/change/view/change-completion.component';
import { ChangeConfirmComponent } from 'dhdt/branch/pages/change/view/change-confirm.component';
import { ChangeContentConfirmComponent } from 'dhdt/branch/pages/change/view/change-content-confirm.component';
import { ChangeFinishComponent } from 'dhdt/branch/pages/change/view/change.component';
import { ChangeFlowModule } from 'dhdt/branch/shared/components/change-flow/change-flow.module';
import { ConfirmPageCommonModule } from 'dhdt/branch/shared/components/confirmpage-common/confirmpage.common.module';
import { ModalPasswordModule } from 'dhdt/branch/shared/components/modal/modal-password/modal-password.module';
import { PickerModule } from 'dhdt/branch/shared/components/picker/picker.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';

export const SHARED_FORM_COMPONENT: Array<Type<any>> = [
    ChangeFinishComponent,
    ChangeConfirmComponent,
    ChangeContentConfirmComponent,
    ChangeCompletionComponent
];

@NgModule({
    imports: [
        IonicModule,
        SharedModule,
        HttpModule,
        PickerModule,
        ConfirmPageCommonModule,
        TopModule,
        ModalPasswordModule,
        ChangeFlowModule,
    ],
    declarations: [
        SHARED_FORM_COMPONENT,
        ChangeChatComponent,
        ChangeModifyChatComponent
    ],
    exports: [
        SHARED_FORM_COMPONENT,
        TopModule,
        ChangeChatComponent,
        ChangeModifyChatComponent
    ],
    entryComponents: [
        ChangeChatComponent,
        SHARED_FORM_COMPONENT,
        ChangeModifyChatComponent
    ],
    providers: [
        ChangeAction,
        ChangeStore,
        ChangeDifferencialConfirmationRenderer,
        ChangeDifferencialConfirmationInputHandler,
        ChangeTelRenderer,
        ChangeTelInputHandler,
        ChangeAddressRenderer,
        ChangeAddressHandler,
        ChangeNameRenderer,
        ChangeNameInputHandler,
        ChangeIdentificationDocumentRenderer,
        ChangeIdentificationDocumentInputHandler,
        ChangeAddCheckRenderer,
        ChangeAddCheckInputHandler
    ]
})
export class ChangeModule {
}
