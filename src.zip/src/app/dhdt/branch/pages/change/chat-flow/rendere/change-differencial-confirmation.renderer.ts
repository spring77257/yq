import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { ChangeAction } from 'dhdt/branch//pages/change/action/change.action';
import { BussinessCode, JudgeResultStatus, UnacceptableCode } from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import {
    ChangeDifferencialConfirmationInputHandler
} from 'dhdt/branch/pages/change/chat-flow/handler/change-diffierencial-confirmation.handler';
import { ChangeSignal, ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { AgentInternalError, COMMON_CONSTANTS, Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { AcceptionResult, AcceptionResultAccount } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { DialogComponent } from 'dhdt/branch/shared/components/dialog/dialog.component';
import { SelectChangeItemsComponent } from 'dhdt/branch/shared/components/select-change-items/select-change-items.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { App, NavController } from 'ionic-angular';

export const CHANGE_DIFFERENCIAL_CONFIRMATION_RENDERER = 'ChangeDifferencialConfirmationRendere';

/**
 * 諸届変更項目選択チャットのrenderer
 *
 * @export
 * @class AutomaticTransferCancelRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CHANGE_DIFFERENCIAL_CONFIRMATION_RENDERER,
    templateYaml: 'chat-flow-def-change-differencial-confirmation.yml'
})
export class ChangeDifferencialConfirmationRenderer extends DefaultChatFlowRenderer {
    public processType: number = COMMON_CONSTANTS.ProcessType.RequiredInput;
    private state: ChangeState;
    private loginState: LoginState;
    private navCtrl: NavController;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private inputHandler: ChangeDifferencialConfirmationInputHandler,
        private changeUtils: ChangeUtils,
        private loginStore: LoginStore,
        private modalService: ModalService,
        private audioService: AudioService,
        app: App
    ) {
        super(action, inputHandler);

        this.state = store.getState();
        this.loginState = loginStore.getState();
        this.navCtrl = app.getActiveNavs()[0];
    }

    @Renderer(ChangeChatFlowTypes.REQUEST_SWIPE_CIF)
    public requestSwipeCifStatus(entity: ChatFlowMessageInterface, pageIndex: number) {

        // 喪失/差替/カード新規発行からの呼び出しかつ変更なしの場合、受付可否チェックを行わない(氏名変更は修正不可のため判定しない)
        if ((this.state.isCalledFromLoss || this.state.isCalledFromReplace || this.state.isCalledFromNewest)
            && (!this.state.submitData.isAddressChange && !this.state.submitData.isTelphoneChange)) {
            // 諸届業務ではスワイプCIFの受付可否チェックの実行が必ず行われた前提で進むため、空の受付可否チェック結果を設定する
            const emptyAccount: AcceptionResultAccount = {
                resultCode: undefined,
                errorType: undefined,
                errorCode: undefined,
                tenban: undefined,
                accountType: undefined,
                accountNo: undefined,
                unacceptables: [],
                tradingConditions: [],
                bcHoldingStatus: undefined,
                bcSuicaHoldingStatus: undefined,
                cdHoldingStatus: undefined,
                unprintableKanji: undefined
            };
            this.action.setStateSubmitDataValue({
                name: 'swipeCifAcceptCheckResult',
                value: {
                    customerId: this.state.submitData.customerId,
                    account: emptyAccount
                }
            });
            // 次チャットへ進む
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
            return;
        }

        const businessCode = this.state.submitData.isNameChange ? BussinessCode.NAME_MENU_CHANGE : BussinessCode.ADDRESS_TEL_MENU_CHANGE;

        // スワイプCIFの受付可否チェック
        const params = {
            receptionTenban: this.loginState.belongToBranchNo,    // 受付店番
            accounts: [{
                customerId: this.state.submitData.customerId    // 顧客番号
            }], // 口座情報
            businessCode: businessCode, // 業務コード
        };
        const dict = {
            tabletApplyId: this.state.tabletApplyId,
            params: params,
        };

        this.store.registerSignalHandler(ChangeSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
            // 事故取引禁止注意エラーの場合、注意コードを取得の上エラーモーダルを表示する
            this.store.unregisterSignalHandler(ChangeSignal.UNACCEPTABLES_NG);
            const errorInfo = this.checkErrorCode(response.errors.data);
            this.showErrorModal(errorInfo);
        });

        this.store.registerSignalHandler(ChangeSignal.ACCEPT_CHECK_SWIPE_CIF, () => {
            this.store.unregisterSignalHandler(ChangeSignal.ACCEPT_CHECK_SWIPE_CIF);
            this.emitMessageRetrivalEvent(entity.next, pageIndex, Constants.NO_WAITING_TIME);
        });

        this.action.acceptCheckForSwipeCif(entity, dict);
    }

    @Renderer(ChangeChatFlowTypes.SELECT_CHANGE_ITEMS)
    public onSelectChangeItems(entity: ChatFlowMessageInterface, pageIndex: number) {
        // パラメータの生成
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            businessCode: this.state.submitData.businessCode,
            // 喪失業務または差替業務、またはカード新規発行業務からの呼び出しの場合、氏名変更不可とする
            unableNameChange: this.state.isCalledFromLoss || this.state.isCalledFromReplace || this.state.isCalledFromNewest
        };
        // 変更情報確認コンポーネントの表示
        this.emitRenderEvent({
            class: SelectChangeItemsComponent,
            data: this.state.submitData,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        let judgeResult: string;
        let level;

        switch (entity.name) {
            case 'addressDifCheck':
                this.action.setAddressDifferenceFlg(false);
                const swipeCifInfo = this.state.submitData.allCifInfos.find((cifInfo) => cifInfo.customerId ===
                    this.state.submitData.customerId);
                const addressCode = swipeCifInfo.addressInfo.addressCode;
                const kanaAuxiliaryAddress = swipeCifInfo.addressInfo.kanaAuxiliaryAddress;
                this.action.setStateSubmitDataValue({
                    name: 'addressDifferenceInfos',
                    value: this.changeUtils.getAddressDifInfo(this.state.submitData.allCifInfos, this.state.submitData.customerId,
                        addressCode, kanaAuxiliaryAddress)
                });
                judgeResult = JudgeResultStatus.RESULT_02;
                for (const element of this.state.submitData.addressDifferenceInfos) {
                    if (element.isDifference) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                        this.action.setAddressDifferenceFlg(true);
                        break;
                    }
                }
                // 住所差分がありの場合、スワイプ情報の補助住所に変更不可文字あるかどうかをチェック
                // 変更不可文字ある場合は、エラーメッセージを表示、チャットをとまる
                if (judgeResult === JudgeResultStatus.RESULT_01
                    && swipeCifInfo.addressInfo.isAuxiliaryAddressUnconvert === '1') {
                    this.showErrorModalWithAudio(AgentInternalError.ERROR_CODE_N_005);
                    return;
                }
                break;
            case 'isNotAddressChange':
                judgeResult = !this.state.submitData.isAddressChange ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                break;
            case 'acceptCheckForAddressDifCif':
                this.acceptCheckForUpdateCif(entity, pageIndex);
                break;
            case 'acceptCheckForSwipeCif':
                judgeResult = JudgeResultStatus.RESULT_02;
                level = this.changeUtils.getTransactionLevel(
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                // ジュニアNISA対応
                const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(this.state.submitData.birthdate,
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                if (level.levelOne || isHaveJuniorNisa) {
                    judgeResult = JudgeResultStatus.RESULT_01;
                }
                break;
            case 'isCalledFromLoss':
                // 喪失業務からの呼び出しか判定する
                judgeResult = this.state.isCalledFromLoss ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                break;
            case 'isCalledFromReplace':
                // 差替業務からの呼び出しか判定する
                judgeResult = this.state.isCalledFromReplace ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                break;
            case 'isCalledFromNewest':
                // カード新規発行業務からの呼び出しか判定する
                judgeResult = this.state.isCalledFromNewest ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                break;
        }
        this.nextChatByJudge(entity, pageIndex, judgeResult);
    }

    @Renderer(ChangeChatFlowTypes.BUTTON)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.ITEM_LIST)
    public onItemLIst(entity: any, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.REQUEST_CUSTOMER_INFOS_LIST)
    public onRequestCustomerInfosList(entity: any, pageIndex: number) {
        const param = {
            receptionTenban: this.loginState.belongToBranchNo,
            customerId: this.state.submitData.customerId,
            address: this.state.submitData.address,
            phoneNo1: this.state.submitData.holderTelNo1,
            phoneNo2: this.state.submitData.holderTelNo2,
            phoneNo3: this.state.submitData.holderTelNo3,
            businessCode: BussinessCode.NAME_MENU_CHANGE
        };

        const dict = {
            tabletApplyId: this.state.tabletApplyId,
            params: param
        };

        this.store.registerSignalHandler(ChangeSignal.CUSTOMER_INFOS_LIST, () => {
            this.store.unregisterSignalHandler(ChangeSignal.CUSTOMER_INFOS_LIST);
            this.emitMessageRetrivalEvent(entity.next, pageIndex, Constants.NO_WAITING_TIME);
        });

        this.action.cutomerInfosList(dict);
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * judgeの場合、次のチャットへ遷移する制御を行う
     * @param entity
     * @param pageIndex
     * @param result
     */
    private nextChatByJudge(entity: ChatFlowMessageInterface, pageIndex: number, result: string) {
        for (const choice of entity.choices) {
            if (choice.value === result) {
                // 次のチャットを開始させる
                this.emitMessageRetrivalEvent(choice.next, pageIndex, Constants.NO_WAITING_TIME);

            }
        }
    }

    /**
     * スワイプCIF専用のエラーメッセージ作成処理
     */
    private checkErrorCode(acceptCheckResult: AcceptionResult) {
        let errorInfo: any;
        let isNeedBr = 1;
        let index = 0;
        const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        for (const account of acceptCheckResult.accounts) {
            if (this.changeUtils.isHostError(account.errorCode)) {
                let unacceptables = '';
                const swipeCifInfo =
                    this.state.submitData.allCifInfos.filter((cifInfo: CifInfo) => cifInfo.customerId === this.state.submitData.customerId);
                errorInfo = swipeCifInfo[0].customerManagementBranchCode + COMMON_CONSTANTS.FULL_COLON + account.errorCode;

                for (const unacceptable of account.unacceptables) {
                    unacceptables = unacceptable.unacceptableCode;
                    if (index === 0) {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SPACE + unacceptables;
                    } else if (isNeedBr > maxArr) {
                        // 1行に最大3つの注意コードを表示する
                        // 超える場合は改行して店番＋エラー情報＋注意コードを表示する
                        errorInfo = errorInfo + COMMON_CONSTANTS.NEW_LINE + errorInfo.slice(0, 14) + unacceptables;
                        isNeedBr = 1;
                    } else {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SLASH + unacceptables;
                    }
                    index++;
                    isNeedBr++;
                }
            }
        }
        return errorInfo;
    }

    private showErrorModal(errorInfo: any, callback?: any) {
        const labels = InjectionUtils.injector.get(LabelService).labels;
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            labels.common.error.host.support,
            errorInfo, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }

    /**
     * エラーモーダルを表示する（受付可否チェック以外のエラー用）
     */
    private showErrorModalWithAudio(errorCode: string) {
        this.showErrorModal(errorCode);
        // this.audioService.subject.next(true);
    }

    private acceptCheckForUpdateCif(entity: ChatFlowMessageInterface, pageIndex: number) {
        // 名寄せの住所更新対象に対して受付可否チェック実施
        this.action.acceptCheckForAddressDifCif(this.makeAcceptCheckApiParams(), this.state.submitData.addressDifferenceInfos);

        let judgeResult;
        let level;

        this.store.registerSignalHandler(ChangeSignal.ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF, (acceptCheckResult: AcceptionResult) => {
            this.store.unregisterSignalHandler(ChangeSignal.ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF);
            const errMessageArr: Array<{ customerId: string, message: string }> = [];
            // レスポンスパラメータの中に、受付可否チェック検出対象がいたら離脱
            for (const item of this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                let branchCode: string = '';
                for (const cifInfo of this.state.submitData.allCifInfos) {
                    if (item.customerId === cifInfo.customerId && this.changeUtils.isHostError(item.accounts.errorCode)) {
                        branchCode = cifInfo.customerManagementBranchCode;
                        if (item.accounts.unacceptables && item.accounts.unacceptables.length > 0) {
                            // 受付不可情報がある場合、表示メッセージは「エラー理由 ＋ 事故・取引禁止・注意コード」。
                            for (const acceptItem of item.accounts.unacceptables) {
                                errMessageArr.push({
                                    customerId: cifInfo.customerId, message: branchCode + COMMON_CONSTANTS.FULL_COLON
                                        + item.accounts.errorCode + COMMON_CONSTANTS.SPACE + acceptItem.unacceptableCode
                                });
                            }
                        } else {
                            // 受付不可情報がない場合、表示メッセージは「エラー理由」のみ。
                            errMessageArr.push({
                                customerId: cifInfo.customerId, message: branchCode
                                    + COMMON_CONSTANTS.FULL_COLON + item.accounts.errorCode
                            });
                        }
                    }
                }
            }
            const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
            let index = 0;
            let isNeedBr = 1;
            let message: string = '';
            let messageBefore: { customerId: string, message: string } = { customerId: undefined, message: undefined };
            if (errMessageArr.length > 0) {
                for (const err of errMessageArr) {
                    if (index === 0) {
                        message = err.message;
                    } else if (messageBefore.customerId === err.customerId && maxArr > isNeedBr) {
                        isNeedBr++;
                        message = message + COMMON_CONSTANTS.SLASH + err.message.substring(err.message.length - 3);
                    } else {
                        isNeedBr = 1;
                        message = message + COMMON_CONSTANTS.NEW_LINE + err.message;
                    }
                    index++;
                    messageBefore = err;
                }
                this.showErrorModal(message);
                return;
            }
            judgeResult = JudgeResultStatus.RESULT_02;
            if (this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt.forEach((acceptResult) => {
                    // ジュニアNISA対応
                    const cifInfo =
                        this.state.submitData.allCifInfos.filter((item) => item.customerId === acceptResult.customerId);
                    const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(cifInfo[0].birthDate,
                        acceptResult.accounts.tradingConditions);
                    level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                    if (level.levelOne || isHaveJuniorNisa) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                    }
                });
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        });
    }

    /**
     * 受付可否チェックパラメータ生成
     */
    private makeAcceptCheckApiParams() {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((element) => {
            this.state.submitData.addressDifferenceInfos.forEach((difItem) => {
                if (element.customerId !== this.state.submitData.customerId &&
                    element.customerId === difItem.customerId && difItem.isDifference) {
                    accounts.push({
                        customerId: element.customerId
                    });
                }
            });
        });

        const acceptCheckApiParams = {
            tabletApplyId: this.state.tabletApplyId,
            params: {
                receptionTenban: this.loginState.belongToBranchNo,
                accounts: accounts,
                businessCode: BussinessCode.ADDRESS_TEL_MENU_CHANGE,
            }
        };

        return acceptCheckApiParams;
    }
}
