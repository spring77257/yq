import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ScreenTransition } from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import { ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { AddCarema, COMMON_CONSTANTS, SubmitDataKey } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';

/**
 * 諸届変更本人確認書類聴取チャットのhandler
 *
 * @export
 * @class ChangeDifferencialConfirmationInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class ChangeIdentificationDocumentInputHandler extends DefaultChatFlowInputHandler {
    private state: ChangeState;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private labelService: LabelService,
    ) {
        super(action);
        this.state = store.getState();
    }

    @InputHandler(ChangeChatFlowTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        // 撮影書類選択時、書類名を保存
        if (entity.name === 'identificationDocument3X' ||
            entity.name === 'identificationDocument3A' ||
            entity.name === 'identificationDocument3B' ||
            entity.name === 'identificationDocument3C') {
            if (answer === 'skip') {
                this.action.saveDocumentName({
                    key: entity.name + 'Name',
                    value: ''
                });
            } else {
                this.action.saveDocumentName({
                    key: entity.name + 'Name',
                    value: answer.text
                });
            }
        }
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.action.setAnswer({
                text: COMMON_CONSTANTS.SKIP_TEXT,
                value: [
                    { key: entity.name, value: COMMON_CONSTANTS.SKIP_TEXT }
                ]});
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
            return;
        }
        if (entity.name.length > 0 && answer.value.length > 0) {
            if (entity.name === SubmitDataKey.ADD_IDENTITY_DOCUMENT_IMG
                    && answer.value === AddCarema.YES) {
                const choice = entity.choices ? entity.choices.find((item) => item.value === answer.value) : undefined;
                this.action.resetToNode(choice ? choice.next : entity.order, pageIndex);
            } else {
                this.action.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.text }
                    ]
                });
            }
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
            return;
        } else if (answer.action.type && answer.action.type === ScreenTransition.BACK_TO_TOP) {
            this.chatFlowCompelete(answer.action.type);
            return;
        } else {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
            return;
        }
    }

    @InputHandler(ChangeChatFlowTypes.KEYBOARD)
    private onKeybord(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({ text: answer.text, value: answer.value });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(ChangeChatFlowTypes.CAMERA_BUTTON)
    private onCamera(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({
                text: COMMON_CONSTANTS.SKIP_TEXT,
                value: []
            });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        } else {
            const param = {
                image: answer.image,
                name: entity.name,
                code: this.getCode(entity.name)
            };
            // 写真を保存
            this.action.saveDocumentImages(param);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    /**
     * `entity.nameに対応する本人確認書類コードを返却する。
     */
    private getCode(name: string) {
        switch (name) {
            case 'nameIdentiImageX':
                return this.state.submitData.identificationDocument3X;
            case 'nameIdentiImageA':
                return this.state.submitData.identificationDocument3A;
            case 'nameIdentiImageB':
                return this.state.submitData.identificationDocument3B;
            case 'nameIdentiImageC':
                return this.state.submitData.identificationDocument3C;
            case 'propertiesConfrimImage':
                return undefined;
        }
    }
}
