import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services/label.service';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ScreenTransition } from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import { ChangeSignal, ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { NavController } from 'ionic-angular';

/**
 * 諸届変更項目選択チャットのhandler
 *
 * @export
 * @class ChangeAddressHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class ChangeAddressHandler extends DefaultChatFlowInputHandler {
    private state: ChangeState;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private loginStore: LoginStore,
        private audioService: AudioService,
        private labelservice: LabelService,
        private modalService: ModalService) {
        super(action);

        this.state = store.getState();

    }

    @InputHandler(ChangeChatFlowTypes.KEYBOARD)
    private onKeyboardHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.fullwidthHalfwidthDivisionCode === 1 && answer !== COMMON_CONSTANTS.SIGN_SKIP) {
            this.store.unregisterSignalHandler(ChangeSignal.CHARACTER_CHECK);
            // 文字チェックが失敗するときに、httpserviceの共通処理で処理するので、ここにこない。
            this.store.registerSignalHandler(ChangeSignal.CHARACTER_CHECK, () => {
                // 文字チェック成功に来る場合
                this.store.unregisterSignalHandler(ChangeSignal.CHARACTER_CHECK);
                // 処理の継続
                this.dynamicMaxLength(entity, this.state, answer, this.action);
                // 次のチャットへ
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            });
            // 文字チェックを始まる
            const params = {
                tabletApplyId: this.loginStore.getState().tabletApplyId,
                params: {
                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                    checkStrings: [{
                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                        checkString: answer.text
                    }]
                }
            };
            this.action.characteCheck(params, () => {
                const chats = this.state.showChats.splice(-1, 1);
                if (chats && chats.length > 0) {
                    const chat = chats[0];
                    this.action.getNextChatByAnswer(chat.order, pageIndex);
                }
            });
        } else {
            // 処理の継続
            this.dynamicMaxLength(entity, this.state, answer, this.action);
            // 次のチャットへ
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    private dynamicMaxLength(entity: any, state: ChangeState, answer: any, action: ChangeAction) {
        let maxLength: number;
        if (entity.choices && entity.choices.length > 0) {
            maxLength = InputUtils.calculateMaxLength(entity.choices[0].name,
                this.state.submitData.holderAddressStreetNameFuriKanaInput, this.state.submitData.holderAddressStreetNameFuriganaSelect);
        }
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            action.setAnswer({ text: this.labelservice.labels.common.skipjp, value: [] });
        } else {
            InputUtils.getKanjiToKana(answer.value, maxLength).subscribe((results) => {
                action.setAnswer({ text: answer.text, value: results });
            });
        }
    }

    @InputHandler(ChangeChatFlowTypes.NUMBER_KEYBORD)
    private onNumberKeyboardHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            // skip時はvalueは設定しない
            this.setAnswer({
                text: COMMON_CONSTANTS.SKIP_TEXT,
                value: [{ key: entity.name, value: undefined }]
            });
        } else {
           this.setAnswer({ text: answer.text, value: answer.value });
        }
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    // 郵便番号入力後の住所選択時動作
    @InputHandler(ChangeChatFlowTypes.SELECT_ADDRESS)
    private onSelectAddressHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): void {
        if (answer.value) {
            this.setAnswer(answer);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        } else {
            this.action.skip();
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        }
    }

    @InputHandler(ChangeChatFlowTypes.SELECT_STREET)
    private onSelectStreetHandler(entity: any, pageIndex: number, result: { isSkip: boolean, text: string, value: any }) {
        const answer = {
            text: result.text,
            value: [
                { key: 'holderAddressStreet', value: (result.isSkip ? undefined : result.value.streetKanji) },
                { key: 'holderAddressStreetFurigana', value: (result.isSkip ? undefined : result.value.streetKana) }
            ]
        };
        this.action.clearZipCode();
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(result.isSkip ? entity.skip : entity.next, pageIndex);
    }

    @InputHandler([
        ChangeChatFlowTypes.PREFECTURE_PICKER,
        ChangeChatFlowTypes.COUNTRY_URBAN_VILLAGE_PICKER])
    private onPickerHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(ChangeChatFlowTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
            return;
        }
        if (entity.name === 'addressChangeNoDelivery' || entity.name === 'addressChangeAddressCode') {
            let addressChangeFlg: boolean = false;
            if (answer.name === 'doChange') {
                // 郵便不着有先で住所変更する場合、住所変更フラグをオンに更新する。
                addressChangeFlg = true;
            }
            this.action.setStateSubmitDataValue({
                name: 'isAddressChange',
                value: addressChangeFlg
            });
        }
        if (entity.name.length > 0 && answer.value.length > 0) {
            this.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.value }
                ]
            });
        }
        if (answer.action.type.length > 0) {
            this.configAction(answer);
        } else if (answer.next !== -1) {
            // 指定したチャットを表示
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    private configAction(answer: any) {
        if (answer.action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labelservice.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labelservice.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (answer.action.type === ScreenTransition.BACK_TO_TOP) {
            this.action.chatFlowCompelete(answer.action.type);
        }
    }
}
