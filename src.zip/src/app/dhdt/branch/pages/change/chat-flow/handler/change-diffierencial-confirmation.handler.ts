import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ScreenTransition } from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import { ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * 諸届変更項目選択チャットのhandler
 *
 * @export
 * @class ChangeDifferencialConfirmationInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class ChangeDifferencialConfirmationInputHandler extends DefaultChatFlowInputHandler {
    private state: ChangeState;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private audioService: AudioService,
        private modalService: ModalService,
        private labelService: LabelService
    ) {
        super(action);

        this.state = store.getState();

    }

    @InputHandler(ChangeChatFlowTypes.SELECT_CHANGE_ITEMS)
    private onSelectChangeItems(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {

        // 変更情報をstateに保存
        answer.forEach((data) => {
            this.action.setStateSubmitDataValue(data);
        });

        // 回答を保存
        const answerText = this.getSelectItemAnswerText(answer);
        this.action.setAnswer({
            text: answerText,
            value: [{
                key: 'selectItemText',
                value: answerText
            }]
        });

        // 次のチャットへ
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(ChangeChatFlowTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {

        if (answer.action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labelService.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labelService.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (answer.action.type === ScreenTransition.BACK_TO_TOP) {
            this.chatFlowCompelete(answer.action.type);
        } else if (answer.action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            this.modalService.showModal('noticeButtonModal', { imgSrc: COMMON_CONSTANTS.LINE_OFFICIAL_ACCOUNT_CHANGE },
                (result) => {
                    this.emitMessageRetrivalEvent(answer.next, pageIndex);
            });
        } else if (answer.next !== -1) {
            // 指定したチャットを表示
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    /**
     * トグルで選択した結果の、画面表示用テキストを生成
     * @param answer
     */
    private getSelectItemAnswerText(answer: any) {
        // それぞれの変更あるなしの文言取得
        const nameChangeStatusText: string = this.state.submitData.isNameChange ?
            this.labelService.labels.change.doChange.changed : this.labelService.labels.change.doChange.notChanged;
        const addressChangeStatusText: string = this.state.submitData.isAddressChange ?
            this.labelService.labels.change.doChange.changed : this.labelService.labels.change.doChange.notChanged;
        const telphoneChangeStatusText: string = this.state.submitData.isTelphoneChange ?
            this.labelService.labels.change.doChange.changed : this.labelService.labels.change.doChange.notChanged;

        // それぞれの文言取得
        const nameChangeText = this.labelService.labels.change.selectItems.name +
            COMMON_CONSTANTS.FULL_SPACE + this.labelService.labels.change.selectItems.colon + nameChangeStatusText;
        const addressChangeText = this.labelService.labels.change.selectItems.address +
            COMMON_CONSTANTS.FULL_SPACE + this.labelService.labels.change.selectItems.colon + addressChangeStatusText;
        const telphoneChangeText = this.labelService.labels.change.selectItems.telephoneNo +
            this.labelService.labels.change.selectItems.colon + telphoneChangeStatusText;

        // 改行を入れて返却
        return nameChangeText + COMMON_CONSTANTS.NEW_LINE +
            addressChangeText + COMMON_CONSTANTS.NEW_LINE +
            telphoneChangeText;
    }

}
