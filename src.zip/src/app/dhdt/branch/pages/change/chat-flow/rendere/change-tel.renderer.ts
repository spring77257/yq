import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import {
    BussinessCode, DeliveryStatus, InterruptionOfTelephone, JudgeResultStatus, ScreenTransition, UnacceptableCode
} from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import { ChangeTelInputHandler } from 'dhdt/branch/pages/change/chat-flow/handler/change-tel-input-handler';
import { ChangeSignal, ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { AccountType, COMMON_CONSTANTS, IdentificationCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { AcceptionResult } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { App, NavController } from 'ionic-angular';

export const CHANGE_TEL_RENDERER = 'ChangeTelRenderer';

@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CHANGE_TEL_RENDERER,
    templateYaml: 'chat-flow-def-change-tel.yml'
})

export class ChangeTelRenderer extends DefaultChatFlowRenderer {
    public processType: number = 1;
    public state: ChangeState;
    private navCtrl: NavController;
    private loginState: LoginState;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private loginStore: LoginStore,
        private changeUtils: ChangeUtils,
        inputHandler: ChangeTelInputHandler,
        private labelService: LabelService,
        private modalService: ModalService,
        app: App,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
        this.navCtrl = app.getActiveNavs()[0];
        this.loginState = loginStore.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    @Renderer(ChangeChatFlowTypes.TEXT)
    public onText(entity: ChatFlowMessageInterface, pageIndex: number): void {
        console.log('onText next:' + entity.next);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.ITEM_LIST)
    public onItemLIst(entity: any, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.REQUEST_SWIPE_CIF)
    public requestSwipeCifStatus(entity: ChatFlowMessageInterface, pageIndex: number) {
        // スワイプCIFの受付可否チェック
        const params = {
            receptionTenban: this.loginState.belongToBranchNo,    // 受付店番
            accounts: [{
                customerId: this.state.submitData.customerId    // 顧客番号
            }], // 口座情報
            businessCode: BussinessCode.ADDRESS_TEL_MENU_CHANGE, // 業務コード
        };
        const dict = {
            tabletApplyId: this.state.tabletApplyId,
            params: params,
        };

        this.store.registerSignalHandler(ChangeSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
            // 事故取引禁止注意エラーの場合、注意コードを取得の上エラーモーダルを表示する
            this.store.unregisterSignalHandler(ChangeSignal.UNACCEPTABLES_NG);
            const errorInfo = this.checkErrorCode(response.errors.data);
            this.showErrorModal(errorInfo);
        });

        this.store.registerSignalHandler(ChangeSignal.ACCEPT_CHECK_SWIPE_CIF, () => {
            this.store.unregisterSignalHandler(ChangeSignal.ACCEPT_CHECK_SWIPE_CIF);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });

        this.action.acceptCheckForSwipeCif(entity, dict);
    }

    @Renderer(ChangeChatFlowTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        let judgeResult: string;

        switch (entity.name) {
            case 'isTelChange': {
                judgeResult = this.state.submitData.isTelphoneChange ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            case 'telDifferenceCheck': {
                this.action.setTelphoneDifferenceFlg(false);
                if (this.state.submitData.isTelphoneChange) {
                    let changedHolderMobileNo: string = '';
                    let changedHolderTelephoneNo: string = '';
                    if (this.state.submitData.firstMobileNo) {
                        changedHolderMobileNo = this.state.submitData.firstMobileNo + COMMON_CONSTANTS.HALF_HYPHEN
                            + this.state.submitData.secondMobileNo + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdMobileNo;
                    }
                    if (this.state.submitData.firstTel) {
                        changedHolderTelephoneNo = this.state.submitData.firstTel + COMMON_CONSTANTS.HALF_HYPHEN
                            + this.state.submitData.secondTel + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdTel;
                    }
                    this.action.setStateSubmitDataValue({
                        name: 'telDifferenceInfos',
                        value: this.changeUtils.getTelDiffInfo(this.state.submitData.allCifInfos, this.state.submitData.customerId,
                            this.makeHolderTelList(changedHolderMobileNo, changedHolderTelephoneNo))
                    });
                } else {
                    this.action.setStateSubmitDataValue({
                        name: 'telDifferenceInfos',
                        value: this.changeUtils.getTelDiffInfo(this.state.submitData.allCifInfos, this.state.submitData.customerId,
                            this.makeHolderTelList(this.state.submitData.holderTelNo1, this.state.submitData.holderTelNo2,
                                this.state.submitData.holderTelNo3))
                    });
                }

                judgeResult = JudgeResultStatus.RESULT_0;
                for (const item of this.state.submitData.telDifferenceInfos) {
                    if (item.isDifference) {
                        judgeResult = JudgeResultStatus.RESULT_1;
                        this.action.setTelphoneDifferenceFlg(true);
                        break;
                    }
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            case 'acceptCheckForTelDifCif': {
                this.acceptCheckForUpdateCif(entity, pageIndex);
                break;
            }
            // 修正チャットであるかの判定
            case 'isModify': {
                judgeResult = this.state.submitData.isModify ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            // 喪失業務からの呼び出しか判定する
            case 'isCalledFromLoss': {
                // 喪失業務からの呼び出しか判定する
                judgeResult = this.state.isCalledFromLoss ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            // 差替業務からの呼び出しか判定する
            case 'isCalledFromReplace': {
                // 喪失業務からの呼び出しか判定する
                judgeResult = this.state.isCalledFromReplace ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            // カード新規発行業務からの呼び出しか判定する
            case 'isCalledFromNewest': {
                // カード新規発行業務からの呼び出しか判定する
                judgeResult = this.state.isCalledFromNewest ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            // 電話番号不通
            case 'isNonCall': {
                judgeResult = this.state.submitData.interruptionOfTelephone === InterruptionOfTelephone.ON ?
                    JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            // 電話不通有先で電話番号変更する場合、スワイプCIFの受付可否チェック必要かないか
            // 喪失・再発行かつ住所変更なし（電話番号は[変更なし]の前提）の場合、
            // スワイプCIFの受付可否チェックを実施し、取引ぶりを判定
            case 'needAcceptCheckForSwipeCif': {
                judgeResult = (this.state.isCalledFromLoss || this.state.isCalledFromReplace || this.state.isCalledFromNewest) && !this.state.submitData.isAddressChange ?
                    JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            case 'acceptCheckForSwipeCif': {
                judgeResult = JudgeResultStatus.RESULT_0;
                const level = this.changeUtils.getTransactionLevel(
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                // ジュニアNISA対応
                const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(this.state.submitData.birthdate,
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                if (level.levelOne || isHaveJuniorNisa) {
                    judgeResult = JudgeResultStatus.RESULT_1;
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            // 諸届の申し込みチャットで以下の条件を満足するかどうかを判断
            //  氏名、住所、電話番号の変更がなし
            //  PID配下のCIF情報を比較して、変更なし
            //  PID配下に郵便不着情報がない
            //  PID配下に電話番号不通がない
            case 'isHaveDifference': {
                // 0は差分あり、1は差分なし離脱
                judgeResult = JudgeResultStatus.RESULT_0;

                // 電話番号変更ありの場合、SWCIFに対して、電話番号差分チェックを実施
                let isTelphoneChange: boolean = false;
                if (this.state.submitData.isTelphoneChange) {
                    const holderTelList = this.changeUtils.makePhoneNoList(
                        this.state.submitData.holderTelNo1, this.state.submitData.holderTelNo2, this.state.submitData.holderTelNo3);
                    const holderMobileNo: string = this.state.submitData.firstMobileNo ?
                        (this.state.submitData.firstMobileNo + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.secondMobileNo
                            + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdMobileNo) : undefined;
                    const holderTelephoneNo: string = this.state.submitData.firstTel ?
                        (this.state.submitData.firstTel + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.secondTel
                            + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdTel) : undefined;
                    const phoneNoList = this.changeUtils.makePhoneNoList(holderMobileNo, holderTelephoneNo, undefined);
                    isTelphoneChange = this.changeUtils.isTelDifference(holderTelList, phoneNoList);
                }

                const isChange = this.state.submitData.isNameChange
                    || this.state.submitData.isAddressChange
                    || isTelphoneChange;

                const isDifference = this.state.isNameDifference
                    || this.state.isAddressDifference
                    || this.state.isTelphoneDifference;

                let isHaveNonDelivery = false;
                // PID配下の全てCIF情報に「郵便不着」あれば、０ルートに行きます
                this.state.submitData.allCifInfos.forEach(
                    (cifInfo: CifInfo) => {
                        if (cifInfo.nonDelivery === DeliveryStatus.NON_DELIVERY) {
                            isHaveNonDelivery = true;
                        }
                    }
                );

                let isHaveNonCall = false;
                // PID配下の全てCIF情報に「電話番号不通」あれば、０ルートに行きます
                this.state.submitData.cifInfosList.forEach(
                    (cifInfo) => {
                        if (cifInfo.interruptionOfTelephone === InterruptionOfTelephone.ON) {
                            isHaveNonCall = true;
                        }
                    }
                );

                //  氏名、住所、電話番号の変更がなし
                //  PID配下のCIF情報を比較して、変更なし
                //  PID配下に郵便不着情報がない
                //  PID配下に電話番号不通がない
                //  諸届業務
                if (!isChange && !isDifference && !isHaveNonDelivery && !isHaveNonCall
                    && this.state.submitData.accountType === AccountType.CHANGE) {
                    judgeResult = JudgeResultStatus.RESULT_1;
                }

                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            case 'isHaveTelDifference': {
                // 0は差分あり、1は差分なしのためチャット表示あり
                judgeResult = JudgeResultStatus.RESULT_0;

                // 電話番号変更ありの場合、SWCIFに対して、電話番号差分チェックを実施
                let isTelphoneChange: boolean = false;
                if (this.state.submitData.isTelphoneChange) {
                    const holderTelList = this.changeUtils.makePhoneNoList(
                        this.state.submitData.holderTelNo1, this.state.submitData.holderTelNo2, this.state.submitData.holderTelNo3);
                    const holderMobileNo: string = this.state.submitData.firstMobileNo ?
                        (this.state.submitData.firstMobileNo + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.secondMobileNo
                            + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdMobileNo) : undefined;
                    const holderTelephoneNo: string = this.state.submitData.firstTel ?
                        (this.state.submitData.firstTel + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.secondTel
                            + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdTel) : undefined;
                    const phoneNoList = this.changeUtils.makePhoneNoList(holderMobileNo, holderTelephoneNo, undefined);
                    isTelphoneChange = this.changeUtils.isTelDifference(holderTelList, phoneNoList);
                }

                let isHaveNonCall = false;
                // PID配下の全てCIF情報に「電話番号不通」あれば、０ルートに行きます
                this.state.submitData.cifInfosList.forEach(
                    (cifInfo) => {
                        if (cifInfo.interruptionOfTelephone === InterruptionOfTelephone.ON) {
                            isHaveNonCall = true;
                        }
                    }
                );

                // 電話番号番号差分なし かつ 電話不通なしの場合チャットを１ルート
                if (!isTelphoneChange && !this.state.isTelphoneDifference && !isHaveNonCall) {
                    judgeResult = JudgeResultStatus.RESULT_1;
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            default:
                break;
        }
    }

    @Renderer(ChangeChatFlowTypes.NUMBER_KEYBORD)
    public onNumberKeyboard(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: NumberInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);

    }

    @Renderer(ChangeChatFlowTypes.BUTTON)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.CHANGE_CONTENT)
    public onChangeContent(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.ROUTE)
    private onRoute(entity: ChatFlowMessageInterface) {
        // チャットを終了する
        if (entity.example === ScreenTransition.COMPLETE) {
            this.action.chatFlowCompelete(entity.example);
        }
    }

    private acceptCheckForUpdateCif(entity: ChatFlowMessageInterface, pageIndex: number) {
        // 名寄せの電話番号更新対象に対して受付可否チェック実施
        this.action.acceptCheckForTelDifCif(this.makeAcceptCheckApiParams(), this.state.submitData.telDifferenceInfos);

        let judgeResult;
        let level;

        this.store.registerSignalHandler(ChangeSignal.ACCEPT_TARGET_FOR_TEL_DIF_CIF, (acceptCheckResult: AcceptionResult) => {
            this.store.unregisterSignalHandler(ChangeSignal.ACCEPT_TARGET_FOR_TEL_DIF_CIF);
            const errMessageArr: Array<{ customerId: string, message: string }> = [];
            // レスポンスパラメータの中に、受付可否チェック検出対象がいたら離脱
            for (const item of this.state.submitData.nameidentiTelDifCifAcceptCheckResult) {
                let branchCode: string = '';
                for (const cifInfo of this.state.submitData.allCifInfos) {
                    if (item.customerId === cifInfo.customerId && this.changeUtils.isHostError(item.accounts.errorCode)) {
                        branchCode = cifInfo.customerManagementBranchCode;
                        if (item.accounts.unacceptables && item.accounts.unacceptables.length > 0) {
                            // 受付不可情報がある場合、表示メッセージは「エラー理由 ＋ 事故・取引禁止・注意コード」。
                            for (const acceptItem of item.accounts.unacceptables) {
                                errMessageArr.push({
                                    customerId: cifInfo.customerId, message: branchCode + COMMON_CONSTANTS.FULL_COLON
                                        + item.accounts.errorCode + COMMON_CONSTANTS.SPACE + acceptItem.unacceptableCode
                                });
                            }
                        } else {
                            // 受付不可情報がない場合、表示メッセージは「エラー理由」のみ。
                            errMessageArr.push({
                                customerId: cifInfo.customerId, message: branchCode
                                    + COMMON_CONSTANTS.FULL_COLON + item.accounts.errorCode
                            });
                        }
                    }
                }
            }
            const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
            let index = 0;
            let isNeedBr = 1;
            let message: string = '';
            let messageBefore: { customerId: string, message: string } = { customerId: undefined, message: undefined };
            if (errMessageArr.length > 0) {
                for (const err of errMessageArr) {
                    if (index === 0) {
                        message = err.message;
                    } else if (messageBefore.customerId === err.customerId && maxArr > isNeedBr) {
                        isNeedBr++;
                        message = message + COMMON_CONSTANTS.SLASH + err.message.substring(err.message.length - 3);
                    } else {
                        isNeedBr = 1;
                        message = message + COMMON_CONSTANTS.NEW_LINE + err.message;
                    }
                    index++;
                    messageBefore = err;
                }
                this.showErrorModal(message);
                return;
            }
            judgeResult = JudgeResultStatus.RESULT_02;
            if (this.state.submitData.nameidentiTelDifCifAcceptCheckResult) {
                this.state.submitData.nameidentiTelDifCifAcceptCheckResult.forEach((acceptResult) => {
                    // ジュニアNISA対応
                    const cifInfo =
                        this.state.submitData.allCifInfos.filter((item) => item.customerId === acceptResult.customerId);
                    const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(cifInfo[0].birthDate,
                        acceptResult.accounts.tradingConditions);
                    level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                    if (level.levelOne || isHaveJuniorNisa) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                    }
                });
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        });
    }

    /**
     * スワイプCIF専用のエラーメッセージ作成処理
     */
    private checkErrorCode(acceptCheckResult: AcceptionResult) {
        let errorInfo: any;
        let isNeedBr = 1;
        let index = 0;
        const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        for (const account of acceptCheckResult.accounts) {
            if (this.changeUtils.isHostError(account.errorCode)) {
                let unacceptables = '';
                const swipeCifInfo =
                    this.state.submitData.allCifInfos.filter((cifInfo: CifInfo) => cifInfo.customerId === this.state.submitData.customerId);
                errorInfo = swipeCifInfo[0].customerManagementBranchCode + COMMON_CONSTANTS.FULL_COLON + account.errorCode;

                for (const unacceptable of account.unacceptables) {
                    unacceptables = unacceptable.unacceptableCode;
                    if (index === 0) {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SPACE + unacceptables;
                    } else if (isNeedBr > maxArr) {
                        // 1行に最大3つの注意コードを表示する
                        // 超える場合は改行して店番＋エラー情報＋注意コードを表示する
                        errorInfo = errorInfo + COMMON_CONSTANTS.NEW_LINE + errorInfo.slice(0, 14) + unacceptables;
                        isNeedBr = 1;
                    } else {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SLASH + unacceptables;
                    }
                    index++;
                    isNeedBr++;
                }
            }
        }
        return errorInfo;
    }

    /**
     * typeがjudgeの際に、分岐して次のチャットを開始させる
     *
     * @param entity
     * @param pageIndex
     * @param judgeResult
     */
    private nextChatByJudge(entity: ChatFlowMessageInterface, pageIndex: number, judgeResult: string) {
        entity.choices.forEach((choice) => {
            if (choice.value === judgeResult) {
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
                return;
            }
        });
    }

    private makeHolderTelList(telNo1: string, telNo2: string, telNo3?: string) {
        const holderTelList = [];
        if (telNo1) {
            holderTelList.push(telNo1);
        }
        if (telNo2) {
            holderTelList.push(telNo2);
        }
        if (telNo3) {
            holderTelList.push(telNo3);
        }
        return holderTelList;
    }

    /**
     * 受付可否チェックパラメータ生成
     */
    private makeAcceptCheckApiParams() {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((element) => {
            this.state.submitData.telDifferenceInfos.forEach((difItem) => {
                if (element.customerId !== this.state.submitData.customerId &&
                    element.customerId === difItem.customerId && difItem.isDifference) {
                    accounts.push({
                        customerId: element.customerId
                    });
                }
            });
        });

        const acceptCheckApiParams = {
            tabletApplyId: this.state.tabletApplyId,
            params: {
                receptionTenban: this.loginState.belongToBranchNo,
                accounts: accounts,
                businessCode: BussinessCode.ADDRESS_TEL_MENU_CHANGE,
            }
        };

        return acceptCheckApiParams;
    }

    private showErrorModal(errorCode: string, callback?: any) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            this.labelService.labels.common.error.host.support,
            errorCode, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }
}
