import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { AppProperties } from 'app.properties';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ScreenTransition } from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { Observable } from 'rxjs';

@Injectable()
export class ChangeTelInputHandler extends DefaultChatFlowInputHandler {
    private isMobileSkiped: boolean = false;
    private isTelSkiped: boolean = false;

    constructor(
        private action: ChangeAction,
        private labelService: LabelService,
        private audioService: AudioService,
        private modalService: ModalService
    ) {
        super(action);
    }

    @InputHandler(ChangeChatFlowTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name === 'changeNonCallPhoneNumber') {
            let telChangeFlg: boolean = false;
            if (answer.name === 'doChange') {
                // 電話不通有先で電話番号変更する場合、電話番号変更フラグをオンに更新する。
                telChangeFlg = true;
            }
            this.action.setStateSubmitDataValue({
                name: 'isTelphoneChange',
                value: telChangeFlg
            });
        }
        if (entity.name.length > 0 && answer.value.length > 0) {
            this.action.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.text }
                ]
            });
        }
        if (answer.action.type.length > 0) {
            this.configAction(answer);
        } else if (answer.next !== -1) {
            // 指定したチャットを表示
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(ChangeChatFlowTypes.NUMBER_KEYBORD)
    private onNumberKeyboard(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            const isShowModal = this.telSkip(entity.name, this.action, true);
            if (!isShowModal) {
                this.action.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
                if (entity.name === COMMON_CONSTANTS.HOLDER_MOBILE_NO) {
                    this.action.setStateSubmitDataValue({name: 'holderMobileNo', value: undefined});
                    this.action.setStateSubmitDataValue({name: 'firstMobileNo', value: undefined});
                    this.action.setStateSubmitDataValue({name: 'secondMobileNo', value: undefined});
                    this.action.setStateSubmitDataValue({name: 'thirdMobileNo', value: undefined});
                }
                if (entity.name === COMMON_CONSTANTS.HOLDER_TEL_NO) {
                    this.action.setStateSubmitDataValue({name: 'holderTelephoneNo', value: undefined});
                    this.action.setStateSubmitDataValue({name: 'firstTel', value: undefined});
                    this.action.setStateSubmitDataValue({name: 'secondTel', value: undefined});
                    this.action.setStateSubmitDataValue({name: 'thirdTel', value: undefined});
                }
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            }
        } else {
            if (entity.name === COMMON_CONSTANTS.HOLDER_MOBILE_NO && this.isMobileSkiped) {
                this.isMobileSkiped = false;
            }
            this.action.setAnswer({
                text: answer.text,
                value: answer.value
            });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    // if both mobile and tel are skiped , modal shows
    private telSkip(name: string, action: ChangeAction, isSkip: boolean): boolean {
        if (name === COMMON_CONSTANTS.HOLDER_MOBILE_NO) {
            this.isMobileSkiped = isSkip;
            this.isTelSkiped = false;
        }
        if (name === COMMON_CONSTANTS.HOLDER_TEL_NO) {
            this.isTelSkiped = isSkip;
        }
        if (this.isMobileSkiped === true && this.isTelSkiped === true) {
            const buttonList = [
                { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
            ];
            const modalService = InjectionUtils.injector.get(ModalService);
            modalService.showWarnAlert(
                this.labelService.labels.alert.warnTelTitle,
                buttonList, () => {
                    this.action.needInputPhoenNo();
                }
            );
            return true;
        }
        return false;
    }

    private configAction(answer: any) {
        const action = answer.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labelService.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labelService.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === ScreenTransition.BACK_TO_TOP) {
            this.chatFlowCompelete(action.type);
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            this.modalService.showModal(answer.action.value, { imgSrc: answer.action.imgSrc });
            Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                this.action.resetLastNode();
            });
        }
    }
}
