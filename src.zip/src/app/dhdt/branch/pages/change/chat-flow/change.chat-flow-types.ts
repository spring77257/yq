import { ChatFlowQuestionTypes } from 'dhdt/branch/shared/modules/chat-flow/chat-flow-question-types';

export class ChangeChatFlowTypes extends ChatFlowQuestionTypes {
    public static readonly CAMERA_BUTTON = 'cameraButton';
    public static readonly ITEM_LIST = 'itemList';
    public static readonly ROUTE = 'route';
    public static readonly TEXT = 'text';
    public static readonly SELECT_CHANGE_ITEMS = 'selectChangeItems';
    public static readonly SELECT_ADDRESS = 'selectAddress';
    public static readonly SELECT_STREET = 'selectStreet';
    public static readonly PREFECTURE_PICKER = 'prefecturePicker';
    public static readonly COUNTRY_URBAN_VILLAGE_PICKER = 'countyUrbanVillagePicker';
    public static readonly REQUEST_MEDIUM_INFO = 'requestMediumInfo';
    public static readonly PASSWORD_4BITS = 'password4bits';
    public static readonly REQUEST_SWIPE_CIF = 'requestSwipeCif';
    public static readonly PRINTNAME = 'printName';
    public static readonly DATEPICKER = 'datepicker';
    public static readonly SAVE_SUBMIT = 'saveSubmit';
    public static readonly MULTI_BUTTON = 'multiButton';
    public static readonly VERIFICATION_DOCUMENT_IMG_JUDGE = 'verificationDocumentImgJudge';
    public static readonly REQUEST_CUSTOMER_INFOS_LIST = 'requestCustomerInfosList';
    public static readonly CHANGE_CONTENT = 'changeContent';
}
