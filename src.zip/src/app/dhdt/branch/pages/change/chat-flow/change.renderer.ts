import { ViewContainerRef } from '@angular/core';
import { LabelService } from 'adep/services/label.service';
import { InjectionUtils } from 'adep/utils/injection.utils';
import { DeviceService } from 'dhd/common/services/device.service';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ChangeChatFlowAccessor } from 'dhdt/branch/pages/change/chat-flow/chat-flow.accessor';
import { ChangeChatFlowRenderer } from 'dhdt/branch/pages/change/chat-flow/chat-flow.renderer';
import { ChangeQuestionsModel } from 'dhdt/branch/pages/change/entity/change-questions.model';
import { ChangeSignal, ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { ChangeConfirmComponent } from 'dhdt/branch/pages/change/view/change-confirm.component';
import { COMMON_CONSTANTS, CoreBankingConst } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { AccountExistCheckInterface } from 'dhdt/branch/shared/interface/account-exist-check.interface';
import { CoreBankingConstants } from 'dhdt/branch/shared/modules/core-banking/core-banking.consts';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ErrorMessageService } from 'dhdt/branch/shared/services/error-message.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { ModalController, NavController } from 'ionic-angular';

/**
 * 情報入力画面(届出内容の変更)
 */
export class ChangeRenderer extends ChangeChatFlowRenderer {
    public processType = 1;

    public action: ChangeAction;
    private loginStore: LoginStore;
    private state: ChangeState;
    constructor(private chatFlowAccessor: ChangeChatFlowAccessor, private footerContent: ViewContainerRef,
                private store: ChangeStore, private modalService: ModalService,
                private audioService: AudioService, private navCtrl: NavController,
                private deviceService: DeviceService, private modalCtrl: ModalController,
                private labelService: LabelService, private errorService: ErrorMessageService) {
        super();
        this.state = this.store.getState();
        this.loginStore = InjectionUtils.injector.get(LoginStore);
    }

    public loadTemplate(pageIndex: number) {
        this.action.loadTemplate('chat-flow-def-change.yml', pageIndex);
    }

    public onJudge(entity: ChangeQuestionsModel, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((choice) => {
                if (entity.name === 'hasCashCardSwiped') {
                    this.getNextChat(this.hasCashCardSwiped() ? choice.swiped : choice.next, pageIndex);
                } else if (this.state.submitData[entity.name] === choice.value) {
                    this.getNextChat(choice.next, pageIndex);
                }
            });
        }
    }

    public onModal(entity: ChangeQuestionsModel): void {
        this.modalService.showModal(entity.type, undefined, () => {
            this.navCtrl.setRoot(entity.type);
        });
    }

    public onButton(entity: ChangeQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, ButtonGroupComponent, this.footerContent, options).subscribe((answer) => {
            if (entity.name.length > 0 && answer.value.length > 0) {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value }
                    ]
                });
            }
            this.getNextChat(answer.next, pageIndex);
        });
    }

    /**
     * キーボードのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onKeybord(entity: ChangeQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, KeyboardInputComponent,
            this.footerContent, options).subscribe((answer) => {
                this.chatFlowAccessor.clearComponent();
                this.setAnswer(answer);
                this.getNextChat(entity.next, pageIndex);
            });
    }

    /**
     * 口座入力のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onNumberKeybord(entity: ChangeQuestionsModel, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.choices, NumberInputComponent, this.footerContent, options).subscribe((answer) => {
                const accountNo: string = answer.value[0].value;    // 口座番号

                // 口座存在チェックハンドルを追加
                this.store.registerSignalHandler(ChangeSignal.GET_CHECK_ACCOUNT_EXISTING, (data) => {
                    this.store.unregisterSignalHandler(ChangeSignal.GET_CHECK_ACCOUNT_EXISTING);

                    // 完了コード(CODE)=NGの場合、当該errReasonが返って表示する
                    if (data.response.wsp_res.code === COMMON_CONSTANTS.PROCESS_CODE_NG) {
                        this.errorService.handleExternalErrorByReason(data.response.values.errReason, undefined, () => {
                            this.action.resetLastNode();
                        });
                    } else {
                        this.chatFlowAccessor.clearComponent();
                        this.setAnswer(answer);
                        this.getNextChat(entity.next, pageIndex);
                    }
                });

                const accountParam: AccountExistCheckInterface = {
                    path: CoreBankingConstants.ApiPathConsts.ACCOUNT_EXIST_CHECK,
                    tabletApplyId: this.state.tabletApplyId,
                    userMngNo: this.loginStore.getState().bankclerkId,
                    params: {
                        bankNo: CoreBankingConst.bankNo,
                        receptionTenban: this.state.submitData.receptionBranchNo,
                        receptionNo: this.state.submitData.receptionNo,
                        terminalNo: this.deviceService.getDeviceId(),
                        tenban: this.state.submitData.branchNo,
                        accountNo: accountNo,
                        accountType: COMMON_CONSTANTS.ACCOUNT_TYPE_NORMAL,
                        nameKana: StringUtils.convertZankaku2Hankaku(
                            this.state.submitData.getHolderNameFurigana())
                    }
                };

                console.log(accountParam);
                this.action.checkAccountExisting(accountParam);
            });
    }

    /**
     * タイプにより、各コンポーネントをレンダリング
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public rendererComponents(question: ChangeQuestionsModel, pageIndex: number) {
        super.rendererComponents(question, pageIndex);
        switch (question.type) {
            case 'ChangeConfirmComponent': {
                this.onChangeConfirm(question, pageIndex);
                break;
            }
            case 'selectbranch': {
                this.onSelectBranch(question, pageIndex);
                break;
            }
        }
    }

    /**
     * 取引店選択のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    public onSelectBranch(entity: ChangeQuestionsModel, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this._store.getState().currentFileInfo.screenId,
                yamlId: this._store.getState().currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.chatFlowAccessor.addComponent(entity.type, SelectBranchComponent, this.footerContent, options).subscribe((answer) => {
            console.log(this.state.submitData);
            this.chatFlowAccessor.clearComponent();
            this.setAnswer(answer);

            if (answer.value) {
                this.getNextChat(entity.next, pageIndex);
            } else {
                this.getNextChat(entity.skip, pageIndex);
            }
        });
    }

    /**
     * ChangeConfirmComponentへの遷移
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    private onChangeConfirm(entity: ChangeQuestionsModel, pageIndex: number): void {

        this.navCtrl.setRoot(ChangeConfirmComponent,
            {
                type: COMMON_CONSTANTS.BusinessFlowType.Change,
                processType: COMMON_CONSTANTS.ProcessType.RequiredInput,
                cifInfo: this.state.submitData,
                fromChange: true
            });
    }

    private hasCashCardSwiped(): boolean {
        return (this.state.submitData.accountNo && this.state.submitData.accountNo.length > 0) &&
            (this.state.submitData.accountType && this.state.submitData.accountType.length > 0) &&
            (this.state.submitData.branchNo && this.state.submitData.branchNo.length > 0);
    }
}
