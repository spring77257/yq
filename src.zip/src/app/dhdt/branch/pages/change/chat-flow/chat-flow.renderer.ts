import { EventEmitter, Output, ViewChild } from '@angular/core';
import { BaseComponent } from 'adep/components';
import { InjectionUtils } from 'adep/utils';

import { ChangeStore } from 'dhdt/branch/pages/change//store/change.store';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ChangeQuestionsModel } from 'dhdt/branch/pages/change/entity/change-questions.model';
import { Content } from 'ionic-angular';

export interface OnRenderer {
    onText?(entity: ChangeQuestionsModel, pageIndex: number): void;
    onButton?(entity: ChangeQuestionsModel, pageIndex: number): void;
    onKeybord?(entity: ChangeQuestionsModel, pageIndex: number): void;
    onNumberKeybord?(entity: ChangeQuestionsModel, pageIndex: number): void;
    onRoute?(entity: ChangeQuestionsModel, pageIndex: number): void;
    onJudge?(entity: ChangeQuestionsModel, pageIndex: number): void;
}
export abstract class ChangeChatFlowRenderer extends BaseComponent implements OnRenderer {
    public abstract processType: number;
    public action: ChangeAction;
    public _store: ChangeStore;
    @Output() public nextChatEvent = new EventEmitter();
    @ViewChild(Content) public content: Content;

    constructor() {
        super();
        this.action = InjectionUtils.injector.get(ChangeAction);
        this._store = InjectionUtils.injector.get(ChangeStore);

    }

    public abstract loadTemplate(pageIndex: number);

    public onText(entity: ChangeQuestionsModel, pageIndex: number): void {
        this.getNextChat(entity.next, pageIndex);
    }

    public onButton(entity: ChangeQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onButton');
    }

    public onKeybord(entity: ChangeQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onKeybord');
    }

    public onNumberKeybord(entity: ChangeQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onNumberKeybord');
    }

    public onJudge(entity: ChangeQuestionsModel, pageIndex: number): void {
        console.log('ChatFlowAccessor onJudge');
    }

    public rendererComponents(question: ChangeQuestionsModel, pageIndex: number) {
        switch (question.type) {
            case 'text': {
                this.onText(question, pageIndex);
                break;
            }
            case 'button': {
                this.onButton(question, pageIndex);
                break;
            }
            case 'image': {
                this.getNextChat(question.next, pageIndex);
                break;
            }
            case 'judge': {
                this.onJudge(question, pageIndex);
                break;
            }
            case 'keybord': {
                this.onKeybord(question, pageIndex);
                break;
            }
            case 'numberKeybord': {
                this.onNumberKeybord(question, pageIndex);
                break;
            }
            case 'route': {
                this.chatFlowCompelete(question.example);
                this.getNextChat(question.next, pageIndex);
                break;
            }
        }
    }

    /**
     * Get next chat
     * @param order order
     * @param pageIndex pageIndex
     * @param password password
     */
    protected getNextChat(order: number, pageIndex: number) {
        const params: any = { order: order, pageIndex: pageIndex };
        this.nextChatEvent.emit(params);
    }

    /**
     * Set answer
     * @param answer answer
     */
    protected setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this.action.setAnswer(answer);
    }

    protected chatFlowCompelete(nextChatName?: string) {
        this.action.chatFlowCompelete(nextChatName);
    }
}
