import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { Constants, IdentificationDocument, JudgeResultStatus } from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import {
    ChangeIdentificationDocumentInputHandler
} from 'dhdt/branch/pages/change/chat-flow/handler/change-identification-document.handler';
import { ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { COMMON_CONSTANTS, CountryCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ButtonCameraComponent } from 'dhdt/branch/shared/components/button-group/button-camera.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { App, NavController } from 'ionic-angular';
import * as moment from 'moment';

export const CHANGE_IDENTIFICATION_DOCUMENT_RENDERER = 'ChangeIdentificationDocumentRenderer';

/**
 * 諸届本人確認書類聴取チャットのrenderer
 *
 * @export
 * @class ChangeIdentificationDocumentRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CHANGE_IDENTIFICATION_DOCUMENT_RENDERER,
    templateYaml: 'chat-flow-def-change-identification-document.yml'
})

export class ChangeIdentificationDocumentRenderer extends DefaultChatFlowRenderer {
    public processType: number = COMMON_CONSTANTS.ProcessType.BankClerkConfirm;
    public state: ChangeState;
    private navCtrl: NavController;
    private needIdentiDoc: boolean = false;
    private needDoc3A: Boolean = false;
    private needDoc3B: Boolean = false;
    private needDoc3C: Boolean = false;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private changeUtils: ChangeUtils,
        private labelService: LabelService,
        inputHandler: ChangeIdentificationDocumentInputHandler,
        app: App,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    @Renderer(ChangeChatFlowTypes.ITEM_LIST)
    public onItemLIst(entity: any, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        const changeDocumentImages = this.state.changeDocumentImages;
        const confirmC = ['01', '02', '03', '05', '06', '07', '10', '11', '12', '13',
            '14', '15', '20', '21', '22', '24', '25', '27'];
        const possibleAdressIdentifications = ['01', '02', '03', '13', '05', '06', '07', '11', '15', '20', '21', '22', '27'];
        const hasOtherOfficial = ['24', '25'];
        const confirmAddressA = ['10'];
        const confirmAddressB = ['12', '14'];
        const skipPaperA = ['09', '11'];
        const skipPaperB = ['13', '15'];
        const branchPaperX = ['01', '02', '03', '13', '05', '06', '07', '11', '15', '20', '21', '22', '27', '24', '25'];
        let judgeResult: string;
        let received = [];

        if (changeDocumentImages) {
            received = Object.keys(changeDocumentImages);
        }

        if (entity.option === 'change') {
            switch (entity.name) {
                case 'needIdentiDoc': {
                    this.confirmIdentiDoc();
                    // 氏名変更ありor氏名差分ありor（住所変更/差分ありかつ取引ぶり07/08/09あり）
                    judgeResult = (this.state.submitData.isNameChange || this.state.isNameDifference || this.needIdentiDoc) ?
                        JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                case 'nameChanged': {
                    // 氏名変更ありor氏名差分あり
                    judgeResult = (this.state.submitData.isNameChange || this.state.isNameDifference) ?
                        JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                case 'isHaveTradings': {
                    judgeResult = (this.needDoc3A || this.needDoc3B || this.needDoc3C) ?
                        JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
            }

        } else if (entity.option === 'confirm') {
            switch (entity.name) {
                // 書類Cの撮影が必要な場合02、スキップの場合01、撮影した書類の内容によって聴取必要な場合は03
                case 'confirmC': {
                    judgeResult = JudgeResultStatus.RESULT_01;
                    // 他のパターンにて書類撮影済みの場合、書類のチェックへ
                    if (received) {
                        const matchedCode = [];
                        received.forEach((receive) => {
                            if (confirmC.indexOf(receive) >= 0) {
                                matchedCode.push(receive);
                            }
                        });
                        // 書類聴取済みの場合
                        if (matchedCode.length > 0) {
                            // 住所変更なしかつ住所差分なしの場合（=氏名変更か氏名差分あり）、聴取済みのためスキップ
                            if (!this.state.submitData.isAddressChange && !this.state.isAddressDifference) {
                                judgeResult = JudgeResultStatus.RESULT_01;
                                break;
                            }
                            // 住所変更ありor住所差分ありの場合
                            // 本人確認書類聴取チャットにてパターンB確認済みの場合、住所確認をスキップする
                            const matchedCodePatternB = [];
                            received.forEach((receive) => {
                                if (confirmAddressB.indexOf(receive) >= 0) {
                                    matchedCodePatternB.push(receive);
                                }
                            });
                            if (matchedCodePatternB.length > 0 ||
                                this.state.submitData.identificationDocument3B === COMMON_CONSTANTS.SKIP_TEXT) {
                                judgeResult = JudgeResultStatus.RESULT_01;
                                break;
                            }
                            // 住所確認が必要の場合
                            judgeResult = JudgeResultStatus.RESULT_03;
                        } else {
                            // 書類未聴取の場合、撮影必要
                            judgeResult = JudgeResultStatus.RESULT_02;
                        }
                    } else {
                        // 他のパターンにて書類未撮影の場合、パターンCの撮影へ
                        judgeResult = JudgeResultStatus.RESULT_02;
                    }
                    break;
                }
                case 'nationalityCode': {
                    if (this.state.submitData.nationalityCode) {
                        judgeResult = this.state.submitData.nationalityCode === CountryCode.Japan ?
                            JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    }
                    break;
                }
                case 'isChoicedPaperA': {
                    // 期限のある書類を撮影済みかどうか(パターンＡ)
                    const matchedCode = [];

                    received.forEach((receive) => {
                        if (skipPaperA.indexOf(receive) >= 0) {
                            matchedCode.push(receive);
                        }
                    });
                    judgeResult = matchedCode.length > 0 ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                case 'isChoicedPaperB': {
                    // 期限のある書類を撮影済みかどうか(パターンB)
                    const matchedCode = [];

                    received.forEach((receive) => {
                        if (skipPaperB.indexOf(receive) >= 0) {
                            matchedCode.push(receive);
                        }
                    });
                    judgeResult = matchedCode.length > 0 ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                // 書類C前の取引振り判断し、必要な場合02、スキップの場合01
                case 'confirmBeforeC': {
                    judgeResult = this.needDoc3C ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                // 書類A前の取引振り判断し、必要な場合01、スキップの場合02
                case 'isSkipA': {
                    judgeResult = this.needDoc3A ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                // 書類B前の取引振り判断し、必要な場合01、スキップの場合02
                case 'isSkipB': {
                    judgeResult = this.needDoc3B ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                // 書類Cで重複聴取あり時、書類Xで住所確認できない場合、
                // 書類A聴取時は書類Aで住所確認可能か判断し、可能な場合01、不可能な場合02
                case 'addressConfirmCWithA': {
                    const matchedCode = [];

                    received.forEach((receive) => {
                        if (confirmAddressA.indexOf(receive) >= 0) {
                            matchedCode.push(receive);
                        }
                    });
                    judgeResult = matchedCode.length > 0 ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                case 'checkDocumentType3X': {
                    // パターンXにてマイナンバー撮影済みかどうか
                    judgeResult = this.state.submitData.identificationDocument3X === IdentificationDocument.MY_NUMBER_CARD ?
                        JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                case 'checkDocumentType3C': {
                    // パターンCにてマイナンバー撮影済みかどうか
                    judgeResult = this.state.submitData.identificationDocument3C === IdentificationDocument.MY_NUMBER_CARD ?
                        JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                    break;
                }
                case 'branchDocumentX': {
                    // 撮影した書類から、Xで撮影した書類コードに合致したものをmatchedCodeに格納する
                    const matchedCode = [];
                    received.forEach((receive) => {
                        if (branchPaperX.indexOf(receive) >= 0) {
                            matchedCode.push(receive);
                        }
                    });
                    const resultOtherOfficial = matchedCode.some((code) => hasOtherOfficial.indexOf(code) >= 0);
                    if (resultOtherOfficial) {
                        // Xで撮影した書類コードが'24'または'25'の場合
                        judgeResult = JudgeResultStatus.RESULT_01;
                        break;
                    } else {
                        // Xで撮影した書類コードが'24','25'以外の場合
                        judgeResult = JudgeResultStatus.RESULT_02;
                        break;
                    }
                }
            }
        }
        this.nextChatByJudge(entity, pageIndex, judgeResult);
    }

    @Renderer(ChangeChatFlowTypes.BUTTON)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        if (entity.name === 'identificationDocument3C') {
            entity.choices.forEach((choice) => {
                choice.options = {
                    cssClass: '',
                };
            });
        }
        const options = {
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        const changeDocumentImages = this.state.changeDocumentImages;
        let received = [];
        if (changeDocumentImages) {
            received = Object.keys(changeDocumentImages);
        }
        if (entity.name === 'identificationDocument3C') {
            for (const choice of entity.choices) {
                if (received.indexOf(choice.value) !== -1) {
                    choice.options = {
                        cssClass: 'disabled-button',
                    };
                }
            }
        }
        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);

    }

    @Renderer(ChangeChatFlowTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            fullwidthHalfwidthDivisionCode: entity.fullwidthHalfwidthDivisionCode
        };

        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);

    }

    @Renderer(ChangeChatFlowTypes.CAMERA_BUTTON)
    public onCamera(entity: ChatFlowMessageInterface, pageIndex: number) {
        let codeXABC = '';
        const options: any = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        // 写真を取ろうする書類の格納変数の値を取得
        codeXABC = this.getCode(entity.name);
        const currentImg = this.state.changeDocumentImages[codeXABC];
        // 書類に写真が存在する場合は、skipを渡す
        if (currentImg && currentImg.length > 0 && entity.skip) {
            options.skip = entity.skip;
        }
        this.emitRenderEvent({
            class: ButtonCameraComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.TEXT)
    public onText(entity: ChatFlowMessageInterface, pageIndex: number): void {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    /**
     * 書類パターンBまたはCが必要であるかを返却する
     */
    public need3Bor3C(): boolean {
        this.confirmIdentiDoc();
        return Boolean(this.needDoc3B || this.needDoc3C);
    }

    /**
     * typeがjudgeの際に、分岐して次のチャットを開始させる
     *
     * @param entity
     * @param pageIndex
     * @param judgeResult
     */
    private nextChatByJudge(entity: ChatFlowMessageInterface, pageIndex: number, judgeResult: string) {
        for (const choice of entity.choices) {
            if (choice.value === judgeResult) {
                // 次のチャットを開始させる
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
            }
        }
    }

    /**
     * 各書類が必要かないかを判定
     */
    private confirmIdentiDoc() {
        this.needIdentiDoc = false;
        this.needDoc3A = false;
        this.needDoc3B = false;
        this.needDoc3C = false;

        this.isNeedDoc();
        this.isNeed3A();
        this.isNeed3B();
        this.isNeed3C();

    }

    private isNeedDoc() {
        if (this.state.submitData.isAddressChange) {
            if (this.changeUtils.isHaveSpecTradingInTarget([
                Constants.DBConsts.SpecTransactionCode.Investment,
                Constants.DBConsts.SpecTransactionCode.specialDeposit,
                Constants.DBConsts.SpecTransactionCode.other,
            ], this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions)) {
                this.needIdentiDoc = true;
                return;
            }
        }
        if (this.state.isAddressDifference) {
            for (const item of this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                if (this.changeUtils.isHaveSpecTradingInTarget([
                    Constants.DBConsts.SpecTransactionCode.Investment,
                    Constants.DBConsts.SpecTransactionCode.specialDeposit,
                    Constants.DBConsts.SpecTransactionCode.other,
                ], item.accounts.tradingConditions)) {
                    this.needIdentiDoc = true;
                    break;
                }
            }
        }
    }

    private isNeed3A() {
        if (this.state.submitData.isNameChange) {
            if (this.changeUtils.isHaveSpecTradingInTarget([Constants.DBConsts.SpecTransactionCode.loanCreditOwned,
            ], this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions)) {
                this.needDoc3A = true;
                return;
            }
        }
        if (this.state.isNameDifference) {
            for (const item of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                if (this.changeUtils.isHaveSpecTradingInTarget([Constants.DBConsts.SpecTransactionCode.loanCreditOwned,
                ], item.accounts.tradingConditions)) {
                    this.needDoc3A = true;
                    break;
                }
            }
        }
    }

    private isNeed3B() {
        if (this.state.submitData.isAddressChange) {
            if (this.changeUtils.isHaveSpecTradingInTarget([Constants.DBConsts.SpecTransactionCode.other,
            ], this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions)) {
                this.needDoc3B = true;
                return;
            }
        }
        if (this.state.isAddressDifference) {
            for (const item of this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                if (this.changeUtils.isHaveSpecTradingInTarget([Constants.DBConsts.SpecTransactionCode.other,
                ], item.accounts.tradingConditions)) {
                    this.needDoc3B = true;
                    break;
                }
            }
        }
    }

    private isNeed3C() {
        if (this.state.submitData.isNameChange || this.state.submitData.isAddressChange) {
            const level = this.changeUtils.getTransactionLevel(this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
            if (level.levelThree) {
                this.needDoc3C = true;
                return;
            }
        }
        if (this.state.isNameDifference) {
            for (const item of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                const level = this.changeUtils.getTransactionLevel(item.accounts.tradingConditions);
                if (level.levelThree) {
                    this.needDoc3C = true;
                    return;
                }
            }
        }
        if (this.state.isAddressDifference) {
            for (const item of this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                const level = this.changeUtils.getTransactionLevel(item.accounts.tradingConditions);
                if (level.levelThree) {
                    this.needDoc3C = true;
                    break;
                }
            }
        }
    }

    /**
     * `entity.nameに対応する本人確認書類コードを返却する。
     */
    private getCode(name: string) {
        switch (name) {
            case 'nameIdentiImageX':
                return this.state.submitData.identificationDocument3X;
            case 'nameIdentiImageA':
                return this.state.submitData.identificationDocument3A;
            case 'nameIdentiImageB':
                return this.state.submitData.identificationDocument3B;
            case 'nameIdentiImageC':
                return this.state.submitData.identificationDocument3C;
        }
    }

}
