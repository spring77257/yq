import { Injectable } from '@angular/core';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { DoNotHaveIdentificationDoc, IdentificationDocument, ScreenTransition } from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import { ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { AddCarema, COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';

/**
 * 諸届変更追加確認のhandler
 *
 * @export
 * @class ChangeAddCheckInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class ChangeAddCheckInputHandler extends DefaultChatFlowInputHandler {
    private state: ChangeState;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private changeUtils: ChangeUtils
    ) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(ChangeChatFlowTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        // 撮影した書類名を保存
        if (entity.name === 'identificationDocument3Add') {
            if (answer.value === DoNotHaveIdentificationDoc.DO_NOT_HAVE_IDENTIFICATION_DOC) {
                this.action.saveDocumentName({
                    key: entity.name + 'Name',
                    value: ''
                });
            } else if (this.changeUtils.isUnder16YearsOld(this.state.submitData.birthdate,
                this.state.submitData.bankclerkAuthenticationStartDate)
                && (answer.value === IdentificationDocument.RESIDENT_CARD
                    || answer.value === IdentificationDocument.SP_RESIDENT_CERTIFICATE)) {
                // 16歳未満かつ、在留カードか特別永住者証明書の場合は書類名なし
                this.action.saveDocumentName({
                    key: entity.name + 'Name',
                    value: ''
                });
            } else {
                this.action.saveDocumentName({
                    key: entity.name + 'Name',
                    value: answer.text
                });
            }
        }
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
            return;
        }
        if (answer.action.type === ScreenTransition.BACK_TO_TOP) {
            this.action.chatFlowCompelete(answer.action.type);
        }
        if (entity.name) {
            if ((entity.name === 'canNotIssueCardImmediately' && answer.value === COMMON_CONSTANTS.YML_GENERAL_YES)
                || (entity.name === 'haveFacePhoto' && answer.value === COMMON_CONSTANTS.YML_GENERAL_NO)) {
                this.action.setMailDelivery();
            }
            if (entity.name === 'addIdentityDocumentImg' && answer.value === AddCarema.YES) {
                const choice = entity.choices ? entity.choices.find((item) => item.value === answer.value) : undefined;
                this.action.resetToNode(choice ? choice.next : entity.order, pageIndex);
            } else {
                this.action.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.text }
                    ]
                });
            }

        }
        this.emitMessageRetrivalEvent(answer.next, pageIndex);
    }

    @InputHandler(ChangeChatFlowTypes.PRINTNAME)
    private onPrintName(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer.text.indexOf(COMMON_CONSTANTS.HALF_POINT_NO_SPACE) !== -1) {
            answer.text = answer.text.replace(/\./g, COMMON_CONSTANTS.FULL_POINT);
        }
        // 最初の半角スペースによってローマ字氏名を分割する。
        // 前の部分をfirstNameRomaとして、後ろの部分はlastNameRomaとして
        const fullNameRoma = answer.value[0].value;
        const firstSpaceIndex = fullNameRoma.indexOf(COMMON_CONSTANTS.SPACE);
        const firstNameRoma = fullNameRoma.substring(0, firstSpaceIndex);
        const lastNameRoma = fullNameRoma.substring(firstSpaceIndex + 1);
        const answerValue = [
            {
                key: 'firstNameRoma',
                value: firstNameRoma
            },
            {
                key: 'lastNameRoma',
                value: lastNameRoma
            },
        ];
        this.setAnswer({ text: answer.text, value: answerValue });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(ChangeChatFlowTypes.CAMERA_BUTTON)
    private onCameraButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
            return;
        }
        const param = {
            image: answer.image,
            code: this.getCode(entity.name),
            key: entity.name,
        };
        // 写真を保存
        this.action.saveAddDocumentImages(param);

        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(ChangeChatFlowTypes.KEYBOARD)
    private onKeybord(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({ text: answer.text, value: [{ key: entity.name, value: answer.text }] });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    /**
     * `entity.nameに対応する本人確認書類コードを返却する。
     */
    private getCode(name: string) {
        switch (name) {
            case 'nameIdentiImageAdd':
                return this.state.submitData.identificationDocument3Add;
            default:
                break;
        }
    }

}
