import { Injectable } from '@angular/core';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import {
    BcHoldingStatus, CashCardDeliveryType, CdHoldingStatus, IdentificationDocument,
    IdentificationDocumentCode, IdentificationDocumentMethod, JudgeResultStatus,
    LossCardStatus, ScreenTransition, TheftCardStatus
} from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import { ChangeAddCheckInputHandler } from 'dhdt/branch/pages/change/chat-flow/handler/change-add-check.handler';
import { ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import {
    Age, CardClass, CardType, COMMON_CONSTANTS, CountryCode, IdentificationCode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { HoldingCardInfo, MediumInfo } from 'dhdt/branch/pages/common/entity/medium-infos-response.entity';
import { MaxLength } from 'dhdt/branch/pages/creditcard/creditcard-consts';
import { ButtonCameraComponent } from 'dhdt/branch/shared/components/button-group/button-camera.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PrintNameInputComponent } from 'dhdt/branch/shared/components/print-name-input/print-name-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { KanaToRomaji } from 'dhdt/branch/shared/utils/kana-to-romaji-util';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

export const CHANGE_ADD_CHECK_RENDERER = 'ChangeAddCheckRenderer';

@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CHANGE_ADD_CHECK_RENDERER,
    templateYaml: 'chat-flow-def-change-add-check-confirmation.yml',
})

export class ChangeAddCheckRenderer extends DefaultChatFlowRenderer {
    public processType: number = COMMON_CONSTANTS.ProcessType.BankClerkConfirm;
    private state: ChangeState;
    private swipedCifKanaNameDiffFlg: boolean = false;
    private kanaNameDiffInfos: string[] = [];

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private changeUtils: ChangeUtils,
        inputHandler: ChangeAddCheckInputHandler,
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    @Renderer(ChangeChatFlowTypes.PRINTNAME)
    public onPrintName(entity: ChatFlowMessageInterface, pageIndex: number) {
        let firstNameRoma: string = '';
        let lastNameRoma: string = '';

        if (this.state.submitData.firstNameRoma) {
            firstNameRoma = this.state.submitData.firstNameRoma;
            lastNameRoma = this.state.submitData.lastNameRoma;
        } else {
            if (this.state.submitData.nationalityCode === CountryCode.Japan) {
                const kanaToRomaji = new KanaToRomaji();
                if (this.state.submitData.firstNamegana) {
                    firstNameRoma = kanaToRomaji.convert(StringUtils.convertHankaku2Zankaku(this.state.submitData.lastNamegana));
                    lastNameRoma = kanaToRomaji.convert(StringUtils.convertHankaku2Zankaku(this.state.submitData.firstNamegana));
                } else {
                    const names = this.state.submitData.nameKana.split(COMMON_CONSTANTS.FULL_SPACE);
                    firstNameRoma = kanaToRomaji.convert(StringUtils.convertHankaku2Zankaku(names[1]));
                    lastNameRoma = kanaToRomaji.convert(StringUtils.convertHankaku2Zankaku(names[0]));
                }
            } else {
                if (this.state.submitData.firstNameAlphabet) {
                    firstNameRoma = this.state.submitData.lastNameAlphabet;
                    lastNameRoma = this.state.submitData.firstNameAlphabet;
                } else {
                    const names = this.state.submitData.nameAlphabet.split(COMMON_CONSTANTS.SPACE);
                    firstNameRoma = names[1];
                    lastNameRoma = names[0];
                }
            }
        }
        const options = {
            validationRules: entity.validationRules,
            defaultValues: [firstNameRoma + ' ' + lastNameRoma, ''],
            maxLength: MaxLength.MAX_LENGTH_19,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: PrintNameInputComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        const idDocWithPhoto = /01|02|03|04|06|07|20|21|22|24|27/;
        const hasldDocKey = Object.keys(this.state.changeDocumentImages);
        const hasldDocWithPhotoKey = hasldDocKey.filter((element) => element.match(idDocWithPhoto)); // 撮影書類のうち顔写真付書類のID
        // hasldDocWithPhotoKeyから16歳未満の(=顔写真のない)在留カード・特別永住者証明書,在留カード,特別永住者証明書を除外した書類のID
        const hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto =
            this.changeUtils.isUnder16YearsOld(this.state.submitData.birthdate,
                this.state.submitData.bankclerkAuthenticationStartDate)
                ? hasldDocWithPhotoKey.filter((element) => !/04|21|22/.test(element))
                : hasldDocWithPhotoKey;
        const isWelfareNotebook = (element) => element.match(/07/); // 各種福祉手帳
        const isOtherOfficialDocumentWithPhoto = (element) => element.match(/24/); // その他官公庁から発行された書類（写真付）
        const isHealthInsuranceCard = (element) => element.match(/06/); // 各種健康保険証
        const isResidenceCardOrSpecialPermanent = (element) => element.match(/04|21|22/); // 在留カード・特別永住者証明書,在留カード,特別永住者証明書
        let judgeResult: string = JudgeResultStatus.RESULT_02;

        const changeDocumentImages = this.state.changeDocumentImages;
        const oneTypeOfConfirmationDocument = ['01', '02', '03', '04', '07', '21', '22', '24'];
        let received = [];
        if (changeDocumentImages) {
            received = Object.keys(changeDocumentImages);
        }

        switch (entity.name) {
            case 'cashCardType':
                // CD即発チェック
                if (this.swipedCifKanaNameDiffFlg && this.state.submitData.swipeCifAcceptCheckResult.
                    account.cdHoldingStatus === CdHoldingStatus.HOLDING) {
                    judgeResult = JudgeResultStatus.RESULT_01;
                    this.nextChatByJudge(entity, pageIndex, judgeResult);
                    break;
                }
                cashCardType:
                for (const element of this.kanaNameDiffInfos) {
                    for (const item of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                        if (element === item.customerId && item.accounts.cdHoldingStatus === CdHoldingStatus.HOLDING) {
                            judgeResult = JudgeResultStatus.RESULT_01;
                            break cashCardType;
                        }
                    }
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'bcCardType':
                // バンクカードチェック
                if (this.swipedCifKanaNameDiffFlg && this.state.submitData.swipeCifAcceptCheckResult.
                    account.bcHoldingStatus === BcHoldingStatus.HOLDING) {
                    judgeResult = JudgeResultStatus.RESULT_01;
                    this.nextChatByJudge(entity, pageIndex, judgeResult);
                    break;
                }
                bcCardType:
                for (const element of this.kanaNameDiffInfos) {
                    for (const item of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                        if (element === item.customerId && item.accounts.bcHoldingStatus === BcHoldingStatus.HOLDING) {
                            judgeResult = JudgeResultStatus.RESULT_01;
                            break bcCardType;
                        }
                    }
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'bcSuicaCardType':
                // BC suicaチェック
                if (this.swipedCifKanaNameDiffFlg && this.state.submitData.swipeCifAcceptCheckResult.
                    account.bcSuicaHoldingStatus === BcHoldingStatus.HOLDING) {
                    judgeResult = JudgeResultStatus.RESULT_01;
                    this.nextChatByJudge(entity, pageIndex, judgeResult);
                    break;
                }
                bcSuicaCardType:
                for (const element of this.kanaNameDiffInfos) {
                    for (const item of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                        if (element === item.customerId && item.accounts.bcSuicaHoldingStatus === BcHoldingStatus.HOLDING) {
                            judgeResult = JudgeResultStatus.RESULT_01;
                            break bcSuicaCardType;
                        }
                    }
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'bcSuicaLossDeclared':
                // BCバンクカードSuicaは喪失届出済であるかないか
                // 01: 喪失届出済 02: 喪失未済\
                judgeResult = JudgeResultStatus.RESULT_02;
                if (this.swipedCifKanaNameDiffFlg) {
                    // 保有通帳・カード・印鑑情報照会のレスポンスからスワイプCIFを抽出
                    const mediumInfoSwipeCif = this.state.submitData.mediumInfos.mediumInfo.filter(
                        (mediumInfo) => mediumInfo.customerId === this.state.submitData.customerId);
                    if (mediumInfoSwipeCif[0].accountInfo) {
                        for (const accountInfo of mediumInfoSwipeCif[0].accountInfo) {
                            if (accountInfo.holdingCardInfo) {
                                for (const holdingCardInfo of accountInfo.holdingCardInfo) {
                                    if (this.isBcSuicaLoss(holdingCardInfo)) {
                                        judgeResult = JudgeResultStatus.RESULT_01;
                                        this.action.setBcSuicaLost();
                                    }
                                }
                            }
                        }
                    }
                }
                bcSuicaLossDeclared:
                for (const element of this.kanaNameDiffInfos) {
                    for (const mediumInfo of this.state.submitData.mediumInfos.mediumInfo) {
                        if (element === mediumInfo.customerId) {
                            if (mediumInfo.accountInfo) {
                                for (const accountInfo of mediumInfo.accountInfo) {
                                    if (accountInfo.holdingCardInfo) {
                                        for (const holdingCardInfo of accountInfo.holdingCardInfo) {
                                            if (this.isBcSuicaLoss(holdingCardInfo)) {
                                                judgeResult = JudgeResultStatus.RESULT_01;
                                                this.action.setBcSuicaLost();
                                                break bcSuicaLossDeclared;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'idWithPhoto':
                // 顔写真付き本人確認書類かのチェック
                if (hasldDocKey.length > 0) {
                    for (const result of hasldDocKey) {
                        if (result.match(idDocWithPhoto)) {
                            judgeResult = JudgeResultStatus.RESULT_01;
                            break;
                        }
                    }
                }
                if (judgeResult === JudgeResultStatus.RESULT_02) {
                    this.action.setMailDelivery();
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'judgeIdentificationDocument':
                // 撮影済の書類に顔写真付本人確認書類が含まれる場合の分岐
                // 01: 次の書類の判定に進む; 02: 16歳以上か未満の判定に進む; 03: キャッシュカード発行方法の質問に進む
                if (hasldDocKey.some(isWelfareNotebook)
                    || hasldDocKey.some(isOtherOfficialDocumentWithPhoto)
                    || (hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.length > 0
                        && hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.every(isHealthInsuranceCard))) {
                    // 撮影書類に「各種福祉手帳」「その他官公庁から発行された書類（写真付）」のいずれかが含まれる
                    // もしくは撮影書類のうち顔写真付書類が「各種健康保険証」のみである場合: '01'
                    judgeResult = JudgeResultStatus.RESULT_01;
                } else if (hasldDocWithPhotoKey.length > 0
                    && hasldDocWithPhotoKey.every(isResidenceCardOrSpecialPermanent)) {
                    // 撮影書類のうち顔写真付書類が「在留カード・特別永住者証明書」「在留カード」「特別永住者証明書」のいずれかのみである場合: '02'
                    judgeResult = JudgeResultStatus.RESULT_02;
                } else {
                    // 上記以外の場合: '03'
                    judgeResult = JudgeResultStatus.RESULT_03;
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'judgeWhetherTakenDocumentIsInsuranceCardOrNot':
                if (hasldDocKey.some(isWelfareNotebook)
                    || hasldDocKey.some(isOtherOfficialDocumentWithPhoto)) {
                    // 撮影書類に「各種福祉手帳」「その他官公庁から発行された書類（写真付）」のいずれかが含まれる場合: '01'
                    judgeResult = JudgeResultStatus.RESULT_01;
                } else if (hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.length > 0
                    && hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.every(isHealthInsuranceCard)) {
                    // 撮影書類のうち顔写真付書類が「各種健康保険証」のみである場合: '02'
                    judgeResult = JudgeResultStatus.RESULT_02;
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'judgeWhetherTakenDocumentIsWelfareNotebookOrNot':
                // 撮影書類のうち顔写真付書類が「各種福祉手帳」のみである場合: '01'
                // 上記以外の場合: '02'
                judgeResult = (hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.length > 0
                    && hasldDocWithPhotoKeyExceptResidenceCardWithoutPhoto.every(isWelfareNotebook)) ?
                    JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'isUnder16YearsOld':
                // 16歳未満であるかの判定 (16歳未満の場合: '01');
                judgeResult = this.changeUtils.isUnder16YearsOld(this.state.submitData.birthdate,
                    this.state.submitData.bankclerkAuthenticationStartDate)
                    ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                if (judgeResult === JudgeResultStatus.RESULT_01) {
                    this.action.setMailDelivery();
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'isNameKanaChanged':
                this.swipedCifKanaNameDiffFlg = false;
                this.kanaNameDiffInfos = [];
                // カナ氏名変更が行われているかの判定(変更前後を半角変換&拗音を大文字変換して比較)
                if (this.state.submitData.holderNameFurigana && StringUtils.converContractedSound2HankakuKata
                    (StringUtils.convertZankaku2Hankaku(this.state.submitData.holderNameFurigana))
                    !== StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku(this.state.submitData.nameKana))) {
                    judgeResult = JudgeResultStatus.RESULT_01;
                    this.swipedCifKanaNameDiffFlg = true;
                }
                if (this.state.isNameDifference) {
                    if (this.state.submitData.holderNameFurigana) {
                        for (const diffInfo of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                            for (const cifInfo of this.state.submitData.allCifInfos) {
                                if ((diffInfo.customerId === cifInfo.customerId) &&
                                    (StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku(cifInfo.kanaName))
                                        !== StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku
                                            (this.state.submitData.holderNameFurigana)))) {
                                    judgeResult = JudgeResultStatus.RESULT_01;
                                    this.kanaNameDiffInfos.push(cifInfo.customerId);
                                }
                            }
                        }
                    } else {
                        for (const diffInfo of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                            for (const cifInfo of this.state.submitData.allCifInfos) {
                                if (diffInfo.customerId === cifInfo.customerId &&
                                    StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku(cifInfo.kanaName))
                                    !== StringUtils.converContractedSound2HankakuKata(StringUtils.convertZankaku2Hankaku
                                        (this.state.submitData.nameKana))) {
                                    judgeResult = JudgeResultStatus.RESULT_01;
                                    this.kanaNameDiffInfos.push(cifInfo.customerId);
                                }
                            }
                        }
                    }
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            case 'checkDocumentTypeMyNubmer':
                // マイナンバー撮影済みかどうか
                judgeResult = this.state.submitData.identificationDocument3Add === IdentificationDocument.MY_NUMBER_CARD
                    ? '01' : '02';
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            // 喪失業務からの呼び出しか判定する
            case 'isCalledFromLoss': {
                // 喪失業務からの呼び出しか判定する
                judgeResult = this.state.isCalledFromLoss ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            default:
                break;
        }
    }

    @Renderer(ChangeChatFlowTypes.ROUTE)
    public onRoute(entity: ChatFlowMessageInterface) {
        if (entity.example === ScreenTransition.CLERK_CONFIRM_COMPLETE) {
            this.action.chatFlowCompelete(entity.example);
        }
    }

    @Renderer(ChangeChatFlowTypes.BUTTON)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        let code = '';
        const options: any = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo,
                yamlOrder: entity.order
            }
        };

        // 写真を取ろうする書類の格納変数の値を取得
        code = this.getCode(entity.name);
        const currentImg = this.state.addIdentityImage[code];
        // 書類に写真が存在する場合は、skipを渡す
        if (currentImg && currentImg.length > 0 && entity.skip) {
            options.skip = entity.skip;
        }
        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.CAMERA_BUTTON)
    public onCameraButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options: any = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        const received = { ...this.state.addIdentityImage };
        let codes: string[];
        if (received) {
            codes = Object.keys(received);
        }
        // 書類に写真が存在する場合は、skipを渡すisUnder16YearsOld
        if (entity.name === 'nameIdentiImageAdd' && entity.skip) {
            codes.forEach((element) => {
                if (this.state.submitData.identificationDocument3Add === element) {
                    options.skip = entity.skip;
                }
            });
        }

        this.emitRenderEvent({
            class: ButtonCameraComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number) {

        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.SAVE_SUBMIT)
    private onSaveSubmit(entity: ChatFlowMessageInterface, pageIndex: number): void {
        if (entity.choices) {
            entity.choices.forEach((item: any) => {
                this.action.setStateSubmitDataValue({
                    name: item.key,
                    value: item.value
                });
            });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    private nextChatByJudge(entity: ChatFlowMessageInterface, pageIndex: number, result: string) {
        for (const choice of entity.choices) {
            if (choice.value === result) {
                // 次のチャットを開始させる
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
            }
        }
    }

    /**
     * BCSuicaを保有していて、喪失届済であればtrue
     * @param holdingCardInfo
     */
    private isBcSuicaLoss(holdingCardInfo: HoldingCardInfo) {
        if (holdingCardInfo.cardClass !== CardClass.BANK_CARD) {
            // BCでなかった場合はfalseを返却
            return false;
        }

        if (!(holdingCardInfo.cardType === CardType.BC_SUICA ||
            holdingCardInfo.cardType === CardType.BC_SUICA_GOLD ||
            holdingCardInfo.cardType === CardType.BC_YOUNG_GOLD_SUICA)) {
            // BCSuicaまたはBCSuicaGOLDでない場合はfalseを返却
            return false;
        }

        if (!holdingCardInfo.unacceptableInfo ||
            (holdingCardInfo.unacceptableInfo.lossCardStatus === LossCardStatus.NOT_LOSS &&
                holdingCardInfo.unacceptableInfo.theftCardStatus === TheftCardStatus.NOT_THEFT)) {
            // カード喪失済みでない場合はfalseを返却
            return false;
        } else {
            // カード返却済の時はtrueを返却
            return true;
        }

    }

    /**
     * `entity.nameに対応する本人確認書類コードを返却する。
     */
    private getCode(name: string) {
        switch (name) {
            case 'addIdentityDocumentImg':
                return this.state.submitData.identificationDocument3Add;
            default:
                break;
        }
    }
}
