import { AfterViewChecked, Component, ElementRef, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ScreenTransition } from 'dhdt/branch/pages/change/change-consts';
import {
    CHANGE_DIFFERENCIAL_CONFIRMATION_RENDERER
} from 'dhdt/branch/pages/change/chat-flow/rendere/change-differencial-confirmation.renderer';
import {
    CHANGE_IDENTIFICATION_DOCUMENT_RENDERER
} from 'dhdt/branch/pages/change/chat-flow/rendere/change-identification-document.renderer';
import { ChangeConfirmComponentParamName } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import { ChangeSignal, ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { ChangeContentConfirmComponent } from 'dhdt/branch/pages/change/view/change-content-confirm.component';
import { COMMON_CONSTANTS, Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { MediumInfosResponse } from 'dhdt/branch/pages/common/entity/medium-infos-response.entity';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import {
    AbstractChatFlowControlComponent
} from 'dhdt/branch/shared/modules/chat-flow/components/abstract-chat-flow-control.component';
import {
    ChatFlowHeaderInterfaces, ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import {
    EditModalButtonValue, EditModalDismissEventValue
} from 'dhdt/branch/shared/modules/chat-flow/interfaces/edit-modal-dismiss-event-value.interface';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { App, Content, NavController, NavParams } from 'ionic-angular';
import { Observable } from 'rxjs';

@Component({
    selector: 'change-chat-component',
    templateUrl: 'change-chat.component.html'
})
export class ChangeChatComponent extends AbstractChatFlowControlComponent implements OnInit, OnDestroy, AfterViewChecked {
    @ViewChild(Content) public content: Content;
    @ViewChild('topBlockView', { read: ElementRef }) public topBlockView: ElementRef;
    @ViewChild('bottomBlockView', { read: ElementRef }) public bottomBlockView: ElementRef;
    public state: ChangeState;
    public headerOptions: ChatFlowHeaderInterfaces.Options;
    private currentEditShowchatIndex = -1;
    private originShowChats: any[];

    private readonly KEY_TABLET_APPLY_ID = 'tabletApplyId';
    private editedList = {};
    private name: string;
    private modalServiceChange: ModalService;

    constructor(
        private store: ChangeStore,
        private action: ChangeAction,
        private navParams: NavParams,
        private navController: NavController,
        injector: Injector,
        private app: App,
        private logging: LoggingService,
        private changeUtils: ChangeUtils
    ) {
        super(action, injector);
        this.modalServiceChange = injector.get(ModalService);
        this.state = this.store.getState();
        this.originShowChats = [...this.state.showChats];
        this.action.clearShowChats();
    }

    /**
     * 初期化処理として以下を行う。
     * * `AbstractChatFlowControlComponent`の初期化メソッド(`initChatFlowControl`)を実行する。
     * * `ChatFlowHeaderComponent`用のオプションをセットアップする。
     * * Storeからのシグナルを登録する。
     *
     * @memberof ChangeChatComponent
     */
    public ngOnInit() {
        if (this.navParams) {
            const submitData = this.navParams.get('submitData');
            if (submitData) {
                const dataKey = Object.keys(submitData);
                dataKey.forEach((element) => {
                    this.action.setStateSubmitDataValue({
                        name: element,
                        value: submitData[element]
                    });
                });
                // 喪失系業務からの呼び出しの際、保有媒体情報APIの戻り値をコピーする
                if (this.navParams.get('isCalledFromLoss')) {
                    const mediumInfos: MediumInfosResponse = {
                        /** 結果コード */
                        resultCode: undefined,
                        /** エラー種類 */
                        errorType: undefined,
                        /** エラー理由 */
                        errorCode: undefined,
                        /** 複数CIFバンクカード保有表示 */
                        doubleBc: submitData.doubleBC,
                        /** 複数CIFワンセットカード保有表示 */
                        doubleOs: submitData.doubleOS,
                        /** 媒体情報 */
                        mediumInfo: submitData.mediumInfo
                    };
                    this.action.setStateSubmitDataValue({
                        name: 'mediumInfos',
                        value: mediumInfos
                    });
                }
                // 差替系業務からの呼び出しの際、保有媒体情報APIの戻り値をコピーする
                if (this.navParams.get('isCalledFromReplace')) {
                    const mediumInfos: MediumInfosResponse = {
                        /** 結果コード */
                        resultCode: undefined,
                        /** エラー種類 */
                        errorType: undefined,
                        /** エラー理由 */
                        errorCode: undefined,
                        /** 複数CIFバンクカード保有表示 */
                        doubleBc: submitData.doubleBC,
                        /** 複数CIFワンセットカード保有表示 */
                        doubleOs: submitData.doubleOS,
                        /** 媒体情報 */
                        mediumInfo: submitData.mediumInfo
                    };
                    this.action.setStateSubmitDataValue({
                        name: 'mediumInfos',
                        value: mediumInfos
                    });
                }
                // カード新規発行系業務からの呼び出しの際、保有媒体情報APIの戻り値をコピーする
                if (this.navParams.get('isCalledFromNewest')) {
                    const mediumInfos: MediumInfosResponse = {
                        /** 結果コード */
                        resultCode: undefined,
                        /** エラー種類 */
                        errorType: undefined,
                        /** エラー理由 */
                        errorCode: undefined,
                        /** 複数CIFバンクカード保有表示 */
                        doubleBc: submitData.doubleBC,
                        /** 複数CIFワンセットカード保有表示 */
                        doubleOs: submitData.doubleOS,
                        /** 媒体情報 */
                        mediumInfo: submitData.mediumInfo
                    };
                    this.action.setStateSubmitDataValue({
                        name: 'mediumInfos',
                        value: mediumInfos
                    });
                }
                // 変更前の情報をコピーする
                this.action.copySubmitData();
            }

            if (this.navParams.get('tabletApplyId')) {
                this.action.setSwipeInfo({
                    tabletApplyId: this.navParams.get('tabletApplyId'),
                    receptionTenban: this.navParams.get('receptionTenban'),
                });
            }

            // 喪失系業務からの呼び出しの際、喪失からの呼出フラグをセットする
            if (this.navParams.get('isCalledFromLoss')) {
                this.action.setIsCalledFromLoss(this.navParams.get('isCalledFromLoss'));
                // 喪失系業務からの呼出しの際、LoginStateのtabletApplyIdをセットする
                this.action.setLoginTabletApplyId();
            }

            // 差替系業務からの呼び出しの際、差替からの呼出フラグをセットする
            if (this.navParams.get('isCalledFromReplace')) {
                this.action.setIsCalledFromReplace(this.navParams.get('isCalledFromReplace'));
                // 差替系業務からの呼出しの際、LoginStateのtabletApplyIdをセットする
                this.action.setLoginTabletApplyIdReplace();
            }

            // カード新規発行系業務からの呼び出しの際、カード新規発行からの呼出フラグをセットする
            if (this.navParams.get('isCalledFromNewest')) {
                this.action.setIsCalledFromNewest(this.navParams.get('isCalledFromNewest'));
                // カード新規発行系業務からの呼出しの際、LoginStateのtabletApplyIdをセットする
                this.action.setLoginTabletApplyIdNewest();
            }
        }

        if (this.navParams.data.editedList) {
            this.editedList = this.navParams.data.editedList;
        }

        if (this.navParams.data.name) {
            this.name = this.navParams.data.name;
        }

        this.initChatFlowControl();
        this.setupHeaderOptions();
        // 顧客申し込み開始時間を設定する
        this.action.setCustomerApplyStartDate();
        // 取得されたtabletApplyId設定する
        this.action.setStateSubmitDataValue({ name: this.KEY_TABLET_APPLY_ID, value: this.chatFlowNavParam.tabletApplyId });
        // 本人確認書類修正チャットの場合、データをクリア
        if (this.name === 'bankClerkConfirm') {
            Observable.timer(500).subscribe(() => {
                this.action.clearIdentiData();
                this.action.clearChangeIdentiDocs();
                this.action.clearAddIdentityData();
            });
        }
        this.store.registerSignalHandler(ChangeSignal.GET_QUESTION, (pageIndex: number) => {
            this.onYamlDidLoad(pageIndex);
        });
        this.store.registerSignalHandler(ChangeSignal.SEND_ANSWER, (data) => {
            this.onNextMessage(data);
        });
        this.store.registerSignalHandler(ChangeSignal.CHAT_FLOW_COMPELETE, (nextComponentType) => {
            if (nextComponentType === ScreenTransition.COMPLETE) {
                if (this.state.submitData.isNameChange) {
                    const dict = {
                        holderName: this.state.submitData.firstName ?
                            this.state.submitData.firstName + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastName : '',
                        holderNameFurigana: this.state.submitData.firstNamegana ?
                            this.state.submitData.firstNamegana + COMMON_CONSTANTS.SPACE + this.state.submitData.lastNamegana : '',
                        holderNameAlphabet: this.state.submitData.firstNameAlphabet ?
                            this.state.submitData.firstNameAlphabet + COMMON_CONSTANTS.SPACE + this.state.submitData.lastNameAlphabet : '',
                        printSealSlipFlag: this.state.submitData.printSealSlipFlag,
                        unprintableKanji: this.state.submitData.unprintableKanji
                    };
                    this.action.transferModifyToCifInfo(dict);
                }
                if (this.state.submitData.isAddressChange) {
                    const dict = {
                        holderAddressPrefecture: this.state.submitData.holderAddressPrefecture,
                        holderAddressPrefectureFuriKana: this.state.submitData.holderAddressPrefectureFurigana,
                        holderAddressCountyUrbanVillage: this.state.submitData.holderAddressCountyUrbanVillage,
                        holderAddressCountyUrbanVillageFuriKana: this.state.submitData.holderAddressCountyUrbanVillageFurigana,
                        holderAddressStreetNameSelect:
                            this.state.submitData.holderAddressStreetNameInput ||
                            this.state.submitData.holderAddressStreetNameSelect ||
                            this.state.submitData.holderAddressStreet,
                        holderAddressStreetNameFuriKanaSelect:
                            this.state.submitData.holderAddressStreetNameFuriganaInput ||
                            this.state.submitData.holderAddressStreetNameFuriganaSelect ||
                            this.state.submitData.holderAddressStreetNameFuriKanaInput ||
                            this.state.submitData.holderAddressStreetFurigana,
                        holderAddressHouseNumber: this.state.submitData.holderAddressHouseNumber,
                        holderAddressHouseNumberFuriKana: this.state.submitData.holderAddressHouseNumberFurigana,
                        holderZipCode: (this.state.submitData.firstZipCode + COMMON_CONSTANTS.HALF_HYPHEN +
                            this.state.submitData.lastZipCode),
                        changeConfirmComponentParamName: ChangeConfirmComponentParamName.BASICINFO_HOLDERADDRESS
                    };
                    this.action.transferModifyToCifInfo(dict);
                }
                if (this.state.submitData.isTelphoneChange) {
                    const dict = {
                        holderMobileNo: this.state.submitData.firstMobileNo ?
                            (this.state.submitData.firstMobileNo + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.secondMobileNo
                                + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdMobileNo)
                            : '',
                        holderTelephoneNo: this.state.submitData.firstTel ?
                            (this.state.submitData.firstTel + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.secondTel
                                + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdTel)
                            : ''
                    };
                    this.action.transferModifyToCifInfo(dict);
                }
                // 喪失業務からの呼び出しの場合、モーダルを閉じる
                if (this.state.isCalledFromLoss) {
                    this.viewCtrl.dismiss();
                    // 差替業務からの呼び出しの場合、モーダルを閉じる
                } else if (this.state.isCalledFromReplace) {
                    this.viewCtrl.dismiss();
                    // カード新規発行業務からの呼び出しの場合、モーダルを閉じる
                } else if (this.state.isCalledFromNewest) {
                    this.viewCtrl.dismiss();
                } else {
                    this.navController.setRoot(ChangeContentConfirmComponent);
                }
            } else if (nextComponentType === ScreenTransition.CLERK_CONFIRM_COMPLETE) {
                if (this.name === 'bankClerkConfirm') {
                    // 本人確認書類修正チャット
                    this.viewCtrl.dismiss('modify');
                } else {
                    this.viewCtrl.dismiss('bankClerkConfirm');
                }
            } else if (nextComponentType === ScreenTransition.BACK_TO_TOP) {
                Observable.timer(Constants.PageConsts.backToTopStayTime).subscribe(() => {
                    this.app.getRootNav().setRoot(TopComponent).then(() => {
                        this.viewCtrl.dismiss(undefined, undefined, { animate: false });
                    });
                    this.chatFlowInputField.clear();
                });
            } else {
                this.onChatFlowComplete(nextComponentType, TopComponent);
            }
        });
    }

    /**
     * クリーンアップ処理として以下を行う。
     * * `AbstractChatFlowControlComponent`のクリーンアップメソッド(`destoyChatFlowControl`)を実行する。
     * * Storeシグナルの登録を解除する。
     *
     * @memberof ChangeChatComponent
     */
    public ngOnDestroy() {
        this.destoyChatFlowControl();
        this.store.unregisterSignalHandler(ChangeSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(ChangeSignal.SEND_ANSWER);
        this.store.unregisterSignalHandler(ChangeSignal.CHAT_FLOW_COMPELETE);
    }

    /**
     * ViewCheck後（Viewが変更された後）にメッセージコンテナを最下部へスクロールする。
     *
     * @memberof ChangeChatComponent
     */
    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    /**
     * タイトルを取得する。
     *
     * @memberof ChangeChatComponent
     */
    public get headerTitle(): string {
        return this.labels.change.modifyChat.headerTitle1;
    }

    /**
     * Navigationを取得する。
     *
     * @memberof ChangeModifyChatComponent
     */
    public get processType(): number {
        if (this.name === 'bankClerkConfirm') {
            return -1;
        } else {
            return this.currentRenderer.processType;
        }
    }

    /**
     * Navigationを取得する。
     *
     * @memberof ChangeChatComponent
     */
    public get processItems() {
        if (this.name === 'bankClerkConfirm') {
            return [];
        } else {
            return [
                {
                    type: COMMON_CONSTANTS.ProcessType.RequiredInput,
                    value: this.labels.processType.requiredInput,
                },
                {
                    type: COMMON_CONSTANTS.ProcessType.ApplyInfoConfirm,
                    value: this.labels.processType.applyInfoConfirm,
                },
                {
                    type: COMMON_CONSTANTS.ProcessType.BankClerkConfirm,
                    value: this.labels.processType.bankClerkConfirm,
                },
                {
                    type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
                    value: this.labels.processType.completion,
                },
            ];
        }
    }

    /**
     * Editボタンが押下された際に`openEditModal`イベントを発火し、EditModalを表示する。
     *
     * @param order
     * @param pageIndex
     * @param answerOrder
     * @param showChatIndex
     */
    public editChat(order: number, pageIndex: number, answerOrder: number, orderIndex: number): void {
        this.currentEditShowchatIndex = orderIndex;
        super.onEdit(order, pageIndex, answerOrder);
    }

    /**
     * ユーザが回答を編集するかどうかを決定した際に呼び出されるハンドラ。
     *
     * @param {EditModalDismissEventValue} event
     */
    public onEditModalDismiss(event: EditModalDismissEventValue): void {
        const preventedItem = this.editService.endEdit();
        if (event.buttonValue === EditModalButtonValue.EDIT) {
            this.currentRenderer.resetEvents();
            this.action.editAnswer(event.order, event.pageIndex, event.answerOrder, this.currentEditShowchatIndex);
            this.chatFlowInputField.clear();
            this.currentRendererIndex = event.pageIndex;
            this.currentRenderer = this.setupRenderer(event.pageIndex);
            this.getNextChatMessage(event.order, event.pageIndex);
            const deleteCount = this.rendererList.length - this.currentRendererIndex - 1;
            this.rendererList.splice(this.currentRendererIndex + 1, deleteCount);
        } else {
            if (preventedItem) {
                this.getNextChatMessage(preventedItem.order, preventedItem.pageIndex);
            } else {
                this.onModalDismiss();
            }
        }
    }

    /**
     * 戻るボタンクリックHandler
     *
     */
    public cancelEmitterHandler() {
        this.saveOperationLog();

        // 本人確認書類チャットから申し込み画面に戻る
        if (this.navParams.data.pageIndex === 4 && this.name !== 'bankClerkConfirm') {
            const buttonList = [
                { text: this.labels.alert.cancelBtn, buttonValue: 'canel' },
                { text: this.labels.alert.backToConfirmBtn, buttonValue: 'back' }
            ];
            this.modalServiceChange.showWarnAlert(
                this.labels.alert.backToConfirmTitle,
                buttonList,
                (item) => {
                    if (item.buttonValue === 'back') {
                        this.action.clearIdentiData();
                        this.action.clearChangeIdentiDocs();
                        this.action.clearAddIdentityData();
                        this.viewCtrl.dismiss('backConfirm');
                    }
                }
            );
        } else {
            this.action.resetSubmitData(this.originShowChats);
            if (this.name === 'bankClerkConfirm') {
                const params = {
                    copyChangeDocumentImages: this.state.copyChangeDocumentImages,
                    copyOrderChangeDocument: this.state.copyOrderChangeDocument,
                    copyOrderChangeDocumentName: this.state.copyOrderChangeDocumentName
                };
                this.action.resetChangeIdentiDocuments(params);
            }
            super.cancelEmitterHandler();
        }
    }

    /**
     * ページのindexに対して、コンポーネントの名前を取得する
     *
     * @param {number} index
     */
    protected getRendererNameByIndex(index: number) {
        const componentNameMap = {
            0: CHANGE_DIFFERENCIAL_CONFIRMATION_RENDERER,
            4: CHANGE_IDENTIFICATION_DOCUMENT_RENDERER
        };

        let componentName = componentNameMap[index];
        if (!componentName) {
            componentName = CHANGE_DIFFERENCIAL_CONFIRMATION_RENDERER;
        }
        return componentName;
    }

    /**
     * 店舗マスタを更新する
     */
    // tslint:disable-next-line:no-empty
    protected branchStatusUpdate(): void {
    }

    private setupHeaderOptions() {
        if (this.name === 'bankClerkConfirm') {
            this.headerOptions = {
                showReturnTopButton: false,
                title: this.headerTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
            };
        } else if (this.navParams.data.pageIndex === 4) {
            this.headerOptions = {
                showReturnTopButton: true,
                topComponent: TopComponent,
                title: this.headerTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK_CONFIRM
            };
        } else {
            this.headerOptions = {
                showReturnTopButton: true,
                topComponent: TopComponent,
                title: this.headerTitle,
                leftButtonType: ChatFlowHeaderOptions.LeftButtonType.CALL_CLERK
            };
        }
    }

    /**
     *  操作ログ
     */
    private saveOperationLog() {
        const logInfo: IOperationInfo = {
            screenName: this.state.currentFileInfo.screenId,
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: this._labels.logging.Common.Header.CloseAction,
        };
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }
}
