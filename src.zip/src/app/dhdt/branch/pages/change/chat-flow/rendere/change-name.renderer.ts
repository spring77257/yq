import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { ChangeAction } from 'dhdt/branch//pages/change/action/change.action';
import {
    BcHoldingStatus, BcStatus, BussinessCode, CardInUse, CdHoldingStatus, DoubleBcStatus, DoubleOsStatus,
    IcStatus, JudgeResultStatus, McStatus, OsStatus, UnacceptableCode
} from 'dhdt/branch/pages/change/change-consts';
import { ChangeNameInputHandler } from 'dhdt/branch/pages/change/chat-flow//handler/change-name.handler';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import { AccountInfo } from 'dhdt/branch/pages/change/entity/change-questions.model';
import { ChangeSignal, ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import {
    AgentInternalError, COMMON_CONSTANTS, Constants, CountryCode,
    NameNonConvert
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { MediumInfosRequest } from 'dhdt/branch/pages/common/entity/medium-infos-request.entity';
import { LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { AcceptionResult } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PasswordInputComponent } from 'dhdt/branch/shared/components/number-input/password-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';

export const CHANGE_NAME_RENDERER = 'ChangeNameRendere';

/**
 * 諸届変更項目選択チャットのrenderer
 *
 * @export
 * @class AutomaticTransferCancelRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CHANGE_NAME_RENDERER,
    templateYaml: 'chat-flow-def-change-name.yml'
})
export class ChangeNameRenderer extends DefaultChatFlowRenderer {
    public processType: number = COMMON_CONSTANTS.ProcessType.RequiredInput;
    private state: ChangeState;
    private loginState: LoginState;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private loginStore: LoginStore,
        private inputHandler: ChangeNameInputHandler,
        private changeUtils: ChangeUtils,
        private labelService: LabelService,
        private modalService: ModalService
    ) {
        super(action, inputHandler);

        this.state = store.getState();
        this.loginState = loginStore.getState();

    }

    @Renderer(ChangeChatFlowTypes.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        let judgeResult: string;
        let hasNameChangeTarget: boolean;
        let level;

        switch (entity.name) {
            case 'isNameChange': // 氏名変更有無判定
                judgeResult = this.state.submitData.isNameChange ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                break;
            case 'nationalityCode': // 国籍判定(日本人 or 日本人以外)
                judgeResult = this.state.submitData.nationalityCode === CountryCode.Japan ?
                    JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                break;
            case 'nameDifCheck': // 氏名の差分チェック
                this.action.setNameDifferenceFlg(false);
                let isKanjiNameSkip: boolean = false;
                // 氏名変更かつ漢字氏名スキップ時の場合
                if (this.state.submitData.isNameChange && this.state.submitData.holderName === undefined) {
                    isKanjiNameSkip = true;
                }
                // 差分チェックメソッドに渡すパラメータ生成
                const data = {
                    customerId: this.state.submitData.customerId,
                    nationalityCode: this.state.submitData.nationalityCode,
                    nameKanji: this.state.submitData.holderName || this.state.submitData.holderName === '' ?
                        this.state.submitData.holderName : isKanjiNameSkip ?
                            '' : this.state.submitData.nameNonConvert === NameNonConvert.OFF ?
                                this.state.submitData.nameKanjiBackup : this.state.submitData.nameKanji,
                    nameKana: this.state.submitData.holderNameFurigana || this.state.submitData.holderNameFurigana === '' ?
                        this.state.submitData.holderNameFurigana : this.state.submitData.nameKana,
                    nameAlphabet: this.state.submitData.holderNameAlphabet || this.state.submitData.holderNameAlphabet === '' ?
                        this.state.submitData.holderNameAlphabet : this.state.submitData.nameAlphabet
                };
                this.action.setStateSubmitDataValue({
                    name: 'nameDifferenceInfos',
                    value: this.changeUtils.getNameDifInfo(this.state.submitData.allCifInfos, data)
                });
                judgeResult = JudgeResultStatus.RESULT_02;
                this.state.submitData.nameDifferenceInfos.forEach((element) => {
                    if (element.isDifference) {
                        hasNameChangeTarget = true;
                        this.action.setNameDifferenceFlg(true);
                    }
                });
                // 氏名変更無しかつ氏名差分ありかつスワイプCIF側で氏名漢字変換不可文字ありの場合
                if (!this.state.submitData.isNameChange && hasNameChangeTarget
                    && this.state.submitData.nameNonConvert === NameNonConvert.OFF) {
                    // 行員呼出
                    this.showErrorModal(AgentInternalError.ERROR_CODE_N_005);
                    return;
                }
                if (!hasNameChangeTarget && this.state.submitData.isNameChange) {
                    judgeResult = JudgeResultStatus.RESULT_02;
                } else if (hasNameChangeTarget) {
                    judgeResult = JudgeResultStatus.RESULT_01;
                } else {
                    judgeResult = JudgeResultStatus.RESULT_03;
                }
                break;
            case 'acceptCheckForUpdateCif': // 更新対象の取引ぶり判定
                this.acceptCheckForUpdateCif(entity, pageIndex);
                break;
            case 'isCardIssuance': // カード発行の有無判定
                judgeResult = JudgeResultStatus.RESULT_02;
                // スワイプCIFに対する判定
                if (this.state.submitData.isNameChange &&
                    (this.state.submitData.swipeCifAcceptCheckResult.account.cdHoldingStatus === CdHoldingStatus.HOLDING ||
                        this.state.submitData.swipeCifAcceptCheckResult.account.bcHoldingStatus === BcHoldingStatus.HOLDING)) {
                    judgeResult = JudgeResultStatus.RESULT_01;
                }
                // 氏名変更対象CIFに対する判定
                if (this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                    this.state.submitData.nameidentiNameDifCifAcceptCheckResult.forEach((acceptResult) => {
                        if (acceptResult.accounts.cdHoldingStatus === CdHoldingStatus.HOLDING ||
                            acceptResult.accounts.bcHoldingStatus === BcHoldingStatus.HOLDING) {
                            judgeResult = JudgeResultStatus.RESULT_01;
                        }
                    });
                }
                break;
            case 'hasOneSetCardCheck': // ワンセットカード保有有無判定
                const accountInfos: AccountInfo[] = [];
                let osCustomerId: String;
                this.state.submitData.mediumInfos.mediumInfo.forEach((element) => {
                    // 氏名差分情報から、対象CIFを抽出
                    // customerIdは一意のため、抽出した配列の先頭になる
                    const difItem = this.state.submitData.nameDifferenceInfos.filter((item) => item.customerId === element.customerId)[0];
                    if (element.accountInfo) {
                        element.accountInfo.forEach((account) => {
                            if (!difItem) {
                                if (account.osStatus === OsStatus.OS_STATUS_ON &&
                                    (this.state.submitData.isNameChange && this.state.submitData.customerId === element.customerId)) {
                                    // ワンセットカード保有口座情報を格納
                                    const accountInfo: AccountInfo = {
                                        branchName: account.branchName,
                                        branchNo: account.tenban,
                                        accountType: account.accountType,
                                        accountNo: account.accountNo
                                    };
                                    accountInfos.push(accountInfo);
                                }
                            } else {
                                if (account.osStatus === OsStatus.OS_STATUS_ON && difItem.isDifference) {
                                    // ワンセットカード保有口座情報を格納
                                    const accountInfo: AccountInfo = {
                                        branchName: account.branchName,
                                        branchNo: account.tenban,
                                        accountType: account.accountType,
                                        accountNo: account.accountNo
                                    };
                                    accountInfos.push(accountInfo);
                                }
                            }
                        });
                        if (accountInfos.length > 0 && !osCustomerId) {
                            osCustomerId = element.customerId;
                            const param = {
                                name: 'oneSetAccountInfo',
                                value: {
                                    customerId: element.customerId,
                                    accounts: accountInfos
                                }
                            };
                            this.action.setStateSubmitDataValue(param);
                        }
                    }
                });
                if (accountInfos.length === 0) {
                    const param = {
                        name: 'oneSetAccountInfo',
                        value: undefined
                    };
                    this.action.setStateSubmitDataValue(param);
                    this.action.setStateSubmitDataValue({ name: 'isOneSetCardModify', value: false });
                }
                judgeResult = this.state.submitData.oneSetAccountInfo ? JudgeResultStatus.HAVE : JudgeResultStatus.NOT_HAVE;
                if (this.state.submitData.savingAccountFirstPwd4bits && judgeResult === JudgeResultStatus.NOT_HAVE) {
                    this.action.clearOneSetCardPassword();
                }
                break;
            case 'ownedMediaCheck':
                judgeResult = JudgeResultStatus.NOT_SECESSION;
                if (this.state.submitData.mediumInfos.doubleBc === DoubleBcStatus.DOUBLE_BC_STATUS_ON ||
                    this.state.submitData.mediumInfos.doubleOs === DoubleOsStatus.DOUBLE_OS_STATUS_ON) {
                    // 複数CIFにバンクカード、または複数CIFにワンセットカード、または1CIFに複数ワンセットカードがある場合
                    judgeResult = JudgeResultStatus.SECESSION;
                    break;
                }
                this.state.submitData.mediumInfos.mediumInfo.forEach((mediumElement) => {
                    if (mediumElement.accountInfo) {
                        mediumElement.accountInfo.forEach((account) => {
                            if (account.mcStatus === McStatus.MC_STATUS_ON && account.icStatus === IcStatus.IC_STATUS_ON) {
                                // 同じ口座にMCとICがある場合
                                judgeResult = JudgeResultStatus.SECESSION;
                            } else if (account.mcStatus === McStatus.MC_STATUS_ON && account.bcStatus === BcStatus.BC_STATUS_ON) {
                                // 同じ口座にMCとBCがある場合
                                judgeResult = JudgeResultStatus.SECESSION;
                            } else if (account.icStatus === IcStatus.IC_STATUS_ON && account.bcStatus === BcStatus.BC_STATUS_ON) {
                                // 同じ口座にICとBCがある場合
                                judgeResult = JudgeResultStatus.SECESSION;
                            } else if (account.icStatus === IcStatus.IC_STATUS_ON && account.osStatus === OsStatus.OS_STATUS_ON) {
                                // 同じ口座にICとワンセットカードがある場合
                                judgeResult = JudgeResultStatus.SECESSION;
                            } else if (account.mcStatus === McStatus.MC_STATUS_ON && account.osStatus === OsStatus.OS_STATUS_ON) {
                                // 同じ口座にMCとワンセットカードがある場合
                                judgeResult = JudgeResultStatus.SECESSION;
                            }
                        });
                    }
                });
                break;
            case 'isPasswordSet': // ワンセットカードの暗証番号設定済みかないかの判定
                judgeResult = this.state.submitData.savingAccountFirstPwd4bits ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                break;
            case 'isOneSetCardModify': // ワンセットカード修正チャットであるかの判定
                judgeResult = this.state.submitData.isOneSetCardModify ? JudgeResultStatus.RESULT_01 : JudgeResultStatus.RESULT_02;
                break;
            case 'isModify': // 氏名の修正ボタンを押下したとき
                judgeResult = JudgeResultStatus.RESULT_0;
                if (this.state.submitData.pressButtonType === 'holderName') {
                    // 氏名の修正ボタンを押下したとき
                    // 無条件で受付可否チェックを実行する
                    judgeResult = JudgeResultStatus.RESULT_1;
                }
                break;
            case 'acceptCheckForSwipeCif': // スワイプCIFの取引ぶりを判定
                judgeResult = JudgeResultStatus.RESULT_02;
                level = this.changeUtils.getTransactionLevel(
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                // ジュニアNISA対応
                const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(this.state.submitData.birthdate,
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                if (level.levelOne || isHaveJuniorNisa) {
                    judgeResult = JudgeResultStatus.RESULT_01;
                }
                break;
            // 氏名変更なし　かつ　変換不可文字がある場合は　氏名変更を推奨する
            case 'isAdviceChangeName':
                // 喪失/差替/カード新規発行業務からの呼び出しの場合、氏名変更不可のため推奨しない
                if (this.state.isCalledFromLoss || this.state.isCalledFromReplace || this.state.isCalledFromNewest) {
                    judgeResult = JudgeResultStatus.RESULT_0;
                    break;
                }
                const compareData = {
                    customerId: this.state.submitData.customerId,
                    nationalityCode: this.state.submitData.nationalityCode,
                    nameKanji: this.state.submitData.holderName || this.state.submitData.holderName === '' ?
                        this.state.submitData.holderName : this.state.submitData.nameNonConvert === NameNonConvert.OFF ?
                            this.state.submitData.nameKanjiBackup : this.state.submitData.nameKanji,
                    nameKana: this.state.submitData.holderNameFurigana || this.state.submitData.holderNameFurigana === '' ?
                        this.state.submitData.holderNameFurigana : this.state.submitData.nameKana,
                    nameAlphabet: this.state.submitData.holderNameAlphabet || this.state.submitData.holderNameAlphabet === '' ?
                        this.state.submitData.holderNameAlphabet : this.state.submitData.nameAlphabet
                };

                const nameDifferenceInfos = this.changeUtils.getNameDifInfo(this.state.submitData.allCifInfos, compareData);
                let hasNameChangeTargets = false;
                nameDifferenceInfos.forEach((element) => {
                    if (element.isDifference) {
                        hasNameChangeTargets = true;
                    }
                });

                judgeResult = JudgeResultStatus.RESULT_0;
                if (!this.state.submitData.isNameChange
                    && this.state.submitData.nameNonConvert === NameNonConvert.OFF
                    && !hasNameChangeTargets) {
                    judgeResult = JudgeResultStatus.RESULT_1;
                }
                break;
        }
        this.nextChatByJudge(entity, pageIndex, judgeResult);
    }

    @Renderer(ChangeChatFlowTypes.BUTTON)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number) {
        const items = InputUtils.getDefaultValues(entity.name, this.state.submitData);
        const options = {
            validationRules: entity.validationRules,
            defaultValues: (entity.name === 'holderNameFurigana' && entity.choices.length === 1 && items[0] && items[1]) ?
                [items[0] + COMMON_CONSTANTS.FULL_SPACE + items[1]] : items,

            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            fullwidthHalfwidthDivisionCode: entity.fullwidthHalfwidthDivisionCode
        };

        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);

    }

    /**
     * 保有通帳・印鑑情報照会APIを実行
     * @param entity
     * @param pageIndex
     */
    @Renderer(ChangeChatFlowTypes.REQUEST_MEDIUM_INFO)
    public onRequestMediumInfo(entity: ChatFlowMessageInterface, pageIndex: number) {

        // 喪失/差替/カード新規発行業務からの呼び出しの場合、コールしない
        if (this.state.isCalledFromLoss || this.state.isCalledFromReplace || this.state.isCalledFromNewest) {
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        } else {
            this.store.registerSignalHandler(ChangeSignal.GET_MEDIUM_INFO, () => {
                this.store.unregisterSignalHandler(ChangeSignal.GET_MEDIUM_INFO);
                this.emitMessageRetrivalEvent(entity.next, pageIndex, Constants.NO_WAITING_TIME);
            });

            // APIの入力パラメータ設置
            const param = new MediumInfosRequest(
                Number(this.loginState.tabletApplyId),
                this.loginState.belongToBranchNo,
                this.state.submitData.allCifInfos
            );
            this.action.getMediumInfo(param);
        }

    }

    @Renderer(ChangeChatFlowTypes.PASSWORD_4BITS)
    public onPassword(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            validationRules: entity.validationRules,
            type: entity.type,
            skip: entity.skip,
            name: entity.name,
            birthday: this.state.submitData.birthdate,
            birthdayText: this.state.submitData.birthdateWithAge,
            telephone: [
                this.state.submitData.holderTelNo1,
                this.state.submitData.holderTelNo2,
                this.state.submitData.holderTelNo3,
                this.state.submitData.holderMobileNo,
                this.state.submitData.holderTelephoneNo
            ],
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: PasswordInputComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.ITEM_LIST)
    public onItemLIst(entity: any, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.VERIFICATION_DOCUMENT_IMG_JUDGE)
    public onVerificationDocumentImgJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        let isAllCif: boolean;
        switch (entity.name) {
            case 'allCif': {
                isAllCif = true;
                break;
            }
            case 'difCif': {
                isAllCif = false;
                break;
            }
        }
        const params = {
            isAllCif: isAllCif,
            isChange: this.state.submitData.isNameChange,
            isDifference: this.state.isNameDifference,
            allCifTradingConditions: this.state.submitData.allCifTradingConditions,
            identiDifCifAcceptCheckResult: this.state.submitData.nameidentiNameDifCifAcceptCheckResult
        };
        this.action.setStateSubmitDataValue({
            name: 'nameIdentityDocumentImg',
            value: this.changeUtils.verificationNameDocumentImgJudge(params)
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.CHANGE_CONTENT)
    public onChangeContent(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity, pageIndex);
    }

    /**
     * Request customer status
     * @param entity entity
     */
    @Renderer(ChangeChatFlowTypes.REQUEST_SWIPE_CIF)
    public requestSwipeCifStatus(entity: ChatFlowMessageInterface, pageIndex: number) {

        // スワイプCIFの受付可否チェック
        const params = {
            receptionTenban: this.loginState.belongToBranchNo,    // 受付店番
            accounts: [{
                customerId: this.state.submitData.customerId    // 顧客番号
            }], // 口座情報
            businessCode: BussinessCode.NAME_MENU_CHANGE, // 業務コード
        };
        const dict = {
            tabletApplyId: this.state.tabletApplyId,
            params: params,
        };

        this.store.registerSignalHandler(ChangeSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
            // 事故取引禁止注意エラーの場合、注意コードを取得の上エラーモーダルを表示する
            this.store.unregisterSignalHandler(ChangeSignal.UNACCEPTABLES_NG);
            const errorInfo = this.checkErrorCode(response.errors.data);
            this.showErrorModal(errorInfo);
        });

        this.store.registerSignalHandler(ChangeSignal.ACCEPT_CHECK_SWIPE_CIF, () => {
            this.store.unregisterSignalHandler(ChangeSignal.ACCEPT_CHECK_SWIPE_CIF);
            this.emitMessageRetrivalEvent(entity.next, pageIndex, Constants.NO_WAITING_TIME);
        });

        this.action.acceptCheckForSwipeCif(entity, dict);
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    /**
     * judgeの場合、次のチャットへ遷移する制御を行う
     * @param entity
     * @param pageIndex
     * @param result
     */
    private nextChatByJudge(entity: ChatFlowMessageInterface, pageIndex: number, result: string) {
        for (const choice of entity.choices) {
            if (choice.value === result) {
                // 次のチャットを開始させる
                console.log('this.emitMessageRetrivalEvent:' + choice.next);
                this.emitMessageRetrivalEvent(choice.next, pageIndex, Constants.NO_WAITING_TIME);

            }
        }
    }

    private acceptCheckForUpdateCif(entity: ChatFlowMessageInterface, pageIndex: number) {
        // 名寄せの氏名更新対象に対して受付可否チェック実施
        this.action.acceptCheckForNameDifCif(this.makeAcceptCheckApiParams(), this.state.submitData.nameDifferenceInfos);

        let judgeResult;
        let level;

        this.store.registerSignalHandler(ChangeSignal.ACCEPT_TARGET_FOR_NAME_DIF_CIF, (acceptCheckResult: AcceptionResult) => {
            this.store.unregisterSignalHandler(ChangeSignal.ACCEPT_TARGET_FOR_NAME_DIF_CIF);
            const errMessageArr: Array<{ customerId: string, message: string }> = [];
            // レスポンスパラメータの中に、受付可否チェック検出対象がいたら離脱
            for (const item of this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                let branchCode: string = '';
                for (const cifInfo of this.state.submitData.allCifInfos) {
                    if (item.customerId === cifInfo.customerId && this.changeUtils.isHostError(item.accounts.errorCode)) {
                        branchCode = cifInfo.customerManagementBranchCode;
                        if (item.accounts.unacceptables && item.accounts.unacceptables.length > 0) {
                            // 受付不可情報がある場合、表示メッセージは「エラー理由 ＋ 事故・取引禁止・注意コード」。
                            for (const acceptItem of item.accounts.unacceptables) {
                                errMessageArr.push({
                                    customerId: cifInfo.customerId, message: branchCode + COMMON_CONSTANTS.FULL_COLON
                                        + item.accounts.errorCode + COMMON_CONSTANTS.SPACE + acceptItem.unacceptableCode
                                });
                            }
                        } else {
                            // 受付不可情報がない場合、表示メッセージは「エラー理由」のみ。
                            errMessageArr.push({
                                customerId: cifInfo.customerId, message: branchCode
                                    + COMMON_CONSTANTS.FULL_COLON + item.accounts.errorCode
                            });
                        }
                    }
                }
            }
            const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
            let index = 0;
            let isNeedBr = 1;
            let message: string = '';
            let messageBefore: { customerId: string, message: string } = { customerId: undefined, message: undefined };
            if (errMessageArr.length > 0) {
                for (const err of errMessageArr) {
                    if (index === 0) {
                        message = err.message;
                    } else if (messageBefore.customerId === err.customerId && maxArr > isNeedBr) {
                        isNeedBr++;
                        message = message + COMMON_CONSTANTS.SLASH + err.message.substring(err.message.length - 3);
                    } else {
                        isNeedBr = 1;
                        message = message + COMMON_CONSTANTS.NEW_LINE + err.message;
                    }
                    index++;
                    messageBefore = err;
                }
                this.showErrorModal(message);
                return;
            }
            judgeResult = JudgeResultStatus.RESULT_02;
            if (this.state.submitData.nameidentiNameDifCifAcceptCheckResult) {
                this.state.submitData.nameidentiNameDifCifAcceptCheckResult.forEach((acceptResult) => {
                    // ジュニアNISA対応
                    const cifInfo =
                        this.state.submitData.allCifInfos.filter((item) => item.customerId === acceptResult.customerId);
                    const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(cifInfo[0].birthDate,
                        acceptResult.accounts.tradingConditions);
                    level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                    if (level.levelOne || isHaveJuniorNisa) {
                        judgeResult = JudgeResultStatus.RESULT_01;
                    }
                });
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        });
    }

    /**
     * 受付可否チェックパラメータ生成
     */
    private makeAcceptCheckApiParams() {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((element) => {
            this.state.submitData.nameDifferenceInfos.forEach((difItem) => {
                if (element.customerId !== this.state.submitData.customerId &&
                    element.customerId === difItem.customerId && difItem.isDifference) {
                    accounts.push({
                        customerId: element.customerId
                    });
                }
            });
        });

        const acceptCheckApiParams = {
            tabletApplyId: this.state.tabletApplyId,
            params: {
                receptionTenban: this.loginState.belongToBranchNo,
                accounts: accounts,
                businessCode: BussinessCode.NAME_MENU_CHANGE,
            }
        };

        return acceptCheckApiParams;
    }

    private showErrorModal(errorCode: string, callback?: any) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            this.labelService.labels.common.error.host.support,
            errorCode, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }

    /**
     * スワイプCIF専用のエラーメッセージ作成処理
     */
    private checkErrorCode(acceptCheckResult: AcceptionResult) {
        let errorInfo: any;
        let isNeedBr = 1;
        let index = 0;
        const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        for (const account of acceptCheckResult.accounts) {
            if (this.changeUtils.isHostError(account.errorCode)) {
                let unacceptables = '';
                const swipeCifInfo =
                    this.state.submitData.allCifInfos.filter((cifInfo: CifInfo) => cifInfo.customerId === this.state.submitData.customerId);
                errorInfo = swipeCifInfo[0].customerManagementBranchCode + COMMON_CONSTANTS.FULL_COLON + account.errorCode;

                for (const unacceptable of account.unacceptables) {
                    unacceptables = unacceptable.unacceptableCode;
                    if (index === 0) {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SPACE + unacceptables;
                    } else if (isNeedBr > maxArr) {
                        // 1行に最大3つの注意コードを表示する
                        // 超える場合は改行して店番＋エラー情報＋注意コードを表示する
                        errorInfo = errorInfo + COMMON_CONSTANTS.NEW_LINE + errorInfo.slice(0, 14) + unacceptables;
                        isNeedBr = 1;
                    } else {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SLASH + unacceptables;
                    }
                    index++;
                    isNeedBr++;
                }
            }
        }
        return errorInfo;
    }
}
