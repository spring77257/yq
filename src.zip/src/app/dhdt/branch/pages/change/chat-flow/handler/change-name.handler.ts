import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils } from 'adep/utils';
import { AppProperties } from 'app.properties';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ScreenTransition } from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import { ChangeSignal, ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { Observable } from 'rxjs';

/**
 * 諸届変更項目選択チャットのhandler
 *
 * @export
 * @class ChangeDifferencialConfirmationInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class ChangeNameInputHandler extends DefaultChatFlowInputHandler {
    private state: ChangeState;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private audioService: AudioService,
        private modalService: ModalService,
        private labelService: LabelService
    ) {
        super(action);

        this.state = store.getState();

    }

    @InputHandler(ChangeChatFlowTypes.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            this.action.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.text }
                ]
            });
        }

        // nameはisChangeNameReadableのボタンに対して、
        // 「はい」の場合isNameChangeをtrueに設定
        // 「いいえ」の場合isNameChangeをfalseに設定
        if (entity.name === 'isChangeNameReadable') {
            this.action.setStateSubmitDataValue(
                {
                    name: 'isNameChange',
                    value: answer.value === '1' ? true : false
                }
            );
        }

        if (answer.action.type.length > 0) {
            this.configAction(answer);
        } else if (answer.next !== -1) {
            // 指定したチャットを表示
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    @InputHandler(ChangeChatFlowTypes.KEYBOARD)
    private onKeybord(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {

        if (entity.fullwidthHalfwidthDivisionCode === 1 && answer !== COMMON_CONSTANTS.SIGN_SKIP) {
            this.store.unregisterSignalHandler(ChangeSignal.CHARACTER_CHECK);
            // 文字チェックが失敗するときに、httpserviceの共通処理で処理するので、ここにこない。
            this.store.registerSignalHandler(ChangeSignal.CHARACTER_CHECK, () => {
                // 文字チェック成功に来る場合
                this.store.unregisterSignalHandler(ChangeSignal.CHARACTER_CHECK);
                // 処理の継続
                this.getNextChatByKeyboard(entity, answer, pageIndex);
            });

            // 文字チェックを始まる
            const loginStore = InjectionUtils.injector.get(LoginStore);
            const params = {
                tabletApplyId: loginStore.getState().tabletApplyId,
                params: {
                    receptionTenban: loginStore.getState().belongToBranchNo,
                    checkStrings: [{
                        checkPattern: entity.fullwidthHalfwidthDivisionCode,
                        checkString: answer.text
                    }]
                }
            };
            this.action.characteCheck(params, () => {
                const chats = this.state.showChats.splice(-1, 1);
                if (chats && chats.length > 0) {
                    const chat = chats[0];
                    this.action.getNextChatByAnswer(chat.order, pageIndex);
                }
            });
        } else if (entity.name === 'holderNameAlphabet') {
            // 英語氏名入力の場合、submitDataに登録する時にfirstNameAlphabet,lastNameAlphabetに分けて登録します
            const nameAlphabet = InputUtils.getNameAlphabetAnswerObject(answer.value[0].value);
            // 英字氏名を大文字に固定する
            answer.text = answer.text.toUpperCase();
            nameAlphabet[0].value = nameAlphabet[0].value.toUpperCase();
            nameAlphabet[1].value = nameAlphabet[1].value.toUpperCase();
            this.getNextChatByKeyboard(entity, { text: answer.text, value: nameAlphabet }, pageIndex);
        } else if (entity.name === 'holderNameFurigana' && entity.choices.length === 1) {
            // 外国人のカナ氏名入力の場合、submitDataに登録する時にfirstNameKana,lastNameKanaに分けて登録します
            const nameKana = InputUtils.getNameKanaAnswerObject(answer.value[0].value);
            this.getNextChatByKeyboard(entity, { text: answer.text, value: nameKana }, pageIndex);
        } else {
            // 処理の継続
            this.getNextChatByKeyboard(entity, answer, pageIndex);
        }

    }

    @InputHandler(ChangeChatFlowTypes.PASSWORD_4BITS)
    private onPassword(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer(answer);
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    private configAction(answer: any) {
        const action = answer.action;
        if (action.type === COMMON_CONSTANTS.ACTION_TYPE_ADMIN) {
            this.audioService.subject.next(true);
            const buttonList = [{ text: this.labelService.labels.common.dialog.ok }];
            this.modalService.showAlert(
                this.labelService.labels.alert.waitTitle,
                null,
                'icon_hourgrass@2x.png',
                buttonList,
                COMMON_CONSTANTS.CSS_MODAL_W_480
            );
        } else if (action.type === ScreenTransition.BACK_TO_TOP) {
            this.chatFlowCompelete(action.type);
        } else if (action.type === COMMON_CONSTANTS.ACTION_TYPE_MODAL) {
            this.modalService.showModal(answer.action.value, { imgSrc: answer.action.imgSrc });
            Observable.timer(Number(AppProperties.CHAT_SPEED)).subscribe(() => {
                this.action.resetLastNode();
            });
        }
    }

    private getNextChatByKeyboard(entity: any, answer: any, pageIndex: number) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            // skipを選択の場合
            this.setAnswer({ text: this.labelService.labels.common.skipjp, value: [] });
            this.action.setStateSubmitDataValue({ name: 'holderName', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'firstName', value: undefined });
            this.action.setStateSubmitDataValue({ name: 'lastName', value: undefined });
            if (this.state.submitData.firstNamegana) {
                this.action.setStateSubmitDataValue({ name: 'holderNameFurigana', value: undefined });
                this.action.setStateSubmitDataValue({ name: 'firstNamegana', value: undefined });
                this.action.setStateSubmitDataValue({ name: 'lastNamegana', value: undefined });
                this.action.setStateSubmitDataValue({ name: 'firstNameKana', value: undefined });
                this.action.setStateSubmitDataValue({ name: 'lastNameKana', value: undefined });
            }
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        } else {
            // 文字とフリガナによって、カタカナを転換する
            InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                const needSpace = InputUtils.needAddSpace(answer.value[0].key);
                if (needSpace) { // 全角スペース必要かを判断する
                    // 外国籍諸届で英字氏名入力時はfirstNameAlphabetとlastNameAlphabetの間のスペースは半角とする
                    if (entity.name !== 'holderNameAlphabet') {
                        const text = answer.value[0].value + COMMON_CONSTANTS.FULL_SPACE + answer.value[1].value;
                        this.setAnswer({
                            text: text,
                            value: [...results, { key: entity.name, value: text }]
                        });
                    } else {
                        this.setAnswer({
                            text: answer.text,
                            value: [...results, { key: entity.name, value: answer.text }]
                        });
                    }
                } else {
                    this.setAnswer({
                        text: answer.text,
                        value: [...results, { key: entity.name, value: answer.text }]
                    });
                }
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            });
        }
    }

}
