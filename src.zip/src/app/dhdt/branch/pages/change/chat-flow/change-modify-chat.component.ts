import {
    AfterViewChecked,
    Component, Injector, OnDestroy, OnInit, ViewChild, ViewContainerRef
} from '@angular/core';
import { AppProperties } from 'app.properties';
import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ScreenTransition } from 'dhdt/branch/pages/change/change-consts';
import { CHANGE_ADD_CHECK_RENDERER } from 'dhdt/branch/pages/change/chat-flow/rendere/change-add-check.render';
import {
    CHANGE_ADDRESS_RENDERER
} from 'dhdt/branch/pages/change/chat-flow/rendere/change-address.renderer';
import {
    CHANGE_IDENTIFICATION_DOCUMENT_RENDERER
} from 'dhdt/branch/pages/change/chat-flow/rendere/change-identification-document.renderer';
import { CHANGE_NAME_RENDERER } from 'dhdt/branch/pages/change/chat-flow/rendere/change-name.renderer';
import { CHANGE_TEL_RENDERER } from 'dhdt/branch/pages/change/chat-flow/rendere/change-tel.renderer';
import { ChangeConfirmComponentParamName } from 'dhdt/branch/pages/change/service/confirmpage.common.service';
import { ChangeSignal, ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { COMMON_CONSTANTS, Constants } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import { AbstractChatFlowControlComponent } from 'dhdt/branch/shared/modules/chat-flow/components/abstract-chat-flow-control.component';
import {
    ChatFlowHeaderInterfaces, ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import {
    EditModalButtonValue, EditModalDismissEventValue
} from 'dhdt/branch/shared/modules/chat-flow/interfaces/edit-modal-dismiss-event-value.interface';
import { IOperationInfo, LoggingService } from 'dhdt/branch/shared/services/logging.service';
import { App, Content, NavController, NavParams } from 'ionic-angular';
import { Observable } from 'rxjs';

@Component({
    selector: 'change-confirmpage-chat-component',
    templateUrl: 'change-chat.component.html'
})

/**
 * 修正buttonのflow
 */
export class ChangeModifyChatComponent extends AbstractChatFlowControlComponent implements OnInit, OnDestroy, AfterViewChecked {

    @ViewChild(Content) public content: Content;

    public state: ChangeState; // changestate
    public headerOptions: ChatFlowHeaderInterfaces.Options;
    private currentEditShowchatIndex = -1;
    private originShowChats: any[];
    private name: string = '';
    private changeData: any = {};

    constructor(
        private store: ChangeStore,
        private action: ChangeAction,
        private loginStore: LoginStore,
        private navParams: NavParams,
        private app: App,
        private navController: NavController,
        private logging: LoggingService,
        injector: Injector) {

        super(action, injector);
        this.state = store.getState();
        this.originShowChats = [...this.state.showChats];
    }

    public ngOnInit() {
        this.initChatFlowControl();
        this.action.differenceFlgBackup();
        this.setupHeaderOptions();
        this.setModifyFlg();
        this.initData();
        this.store.registerSignalHandler(ChangeSignal.GET_QUESTION, (pageIndex: number) => {
            this.onYamlDidLoad(pageIndex);
        });
        this.store.registerSignalHandler(ChangeSignal.SEND_ANSWER, (data) => {
            this.onNextMessage(data);
        });
        this.store.registerSignalHandler(ChangeSignal.CHAT_FLOW_COMPELETE, (nextComponentType) => {
            if (nextComponentType === ScreenTransition.BACK_TO_TOP) {
                Observable.timer(Constants.PageConsts.backToTopStayTime).subscribe(() => {
                    this.app.getRootNav().setRoot(TopComponent).then(() => {
                        this.viewCtrl.dismiss(undefined, undefined, { animate: false });
                    });
                    this.chatFlowInputField.clear();
                });
            } else {
                this.onChatFlowComplete(nextComponentType, TopComponent);
            }
        });
    }

    public ngOnDestroy() {
        this.destoyChatFlowControl();
        this.store.unregisterSignalHandler(ChangeSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(ChangeSignal.SEND_ANSWER);
        this.store.unregisterSignalHandler(ChangeSignal.CHAT_FLOW_COMPELETE);
    }

    /**
     * ViewCheck後（Viewが変更された後）にメッセージコンテナを最下部へスクロールする。
     *
     * @memberof ChangeModifyChatComponent
     */
    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    /**
     * Navigationを取得する。
     *
     * @memberof ChangeModifyChatComponent
     */
    public get processItems() {
        return [];
    }

    /**
     * 修正チャットのprocessTypeを設定
     */
    public get processType() {
        return -1;
    }

    /**
     * 戻るボタンクリックHandler
     *
     */
    public cancelEmitterHandler() {
        this.saveOperationLog();
        switch (this.name) {
            case 'holderName':
                this.action.setNameDifferenceFlg(this.state.isNameDifferenceBackup);
                break;
            case 'holderAddress':
                this.action.setAddressDifferenceFlg(this.state.isAddressDifferenceBackup);
                break;
            case 'holderMobileNo':
                this.action.setTelphoneDifferenceFlg(this.state.isTelphoneDifferenceBackup);
                break;
            default:
                break;
        }
        this.action.resetSubmitData(this.originShowChats);
        super.cancelEmitterHandler();
    }

    /**
     * Editボタンが押下された際に`openEditModal`イベントを発火し、EditModalを表示する。
     *
     * @param order
     * @param pageIndex
     * @param answerOrder
     * @param showChatIndex
     */
    public editChat(order: number, pageIndex: number, answerOrder: number, orderIndex: number): void {
        this.currentEditShowchatIndex = orderIndex;
        super.onEdit(order, pageIndex, answerOrder);
    }

    /**
     * ユーザが回答を編集するかどうかを決定した際に呼び出されるハンドラ。
     *
     * @param {EditModalDismissEventValue} event
     */
    public onEditModalDismiss(event: EditModalDismissEventValue): void {
        const preventedItem = this.editService.endEdit();
        if (event.buttonValue === EditModalButtonValue.EDIT) {
            this.currentRenderer.resetEvents();
            this.action.editAnswer(event.order, event.pageIndex, event.answerOrder, this.currentEditShowchatIndex);
            this.chatFlowInputField.clear();
            this.currentRendererIndex = event.pageIndex;
            this.currentRenderer = this.setupRenderer(event.pageIndex);
            this.getNextChatMessage(event.order, event.pageIndex);
            const deleteCount = this.rendererList.length - this.currentRendererIndex - 1;
            this.rendererList.splice(this.currentRendererIndex + 1, deleteCount);
        } else {
            if (preventedItem) {
                this.getNextChatMessage(preventedItem.order, preventedItem.pageIndex);
            } else {
                this.onModalDismiss();
            }
        }
    }

    protected parseParam() {
        this.chatFlowNavParam = this.navParams.data.params;
        this.currentRendererIndex = this.chatFlowNavParam.pageIndex;
        this.chatFlowNavParam.needPassword = false;
        this.name = this.navParams.data.params.name;
    }

    protected getRendererNameByIndex(index: number): string {
        const componentNameMap = {
            1: CHANGE_NAME_RENDERER,
            2: CHANGE_ADDRESS_RENDERER,
            3: CHANGE_TEL_RENDERER,
            4: CHANGE_IDENTIFICATION_DOCUMENT_RENDERER,
            5: CHANGE_ADD_CHECK_RENDERER
        };
        return componentNameMap[index];
    }

    protected getNextChatMessage(order: number, pageIndex: number, displayingDelay?: number): void {
        if (this.chatFlowNavParam.startOrder != null && this.chatFlowNavParam.endOrder != null && order > this.chatFlowNavParam.endOrder) {
            this.modifyAnswer();
            this.viewCtrl.dismiss(this.changeData);
            return;
        }
        const chatSpeed = displayingDelay !== undefined ? displayingDelay : AppProperties.CHAT_SPEED;
        Observable.timer(Number(chatSpeed)).subscribe(() => {
            this.action.getNextChatByAnswer(order, pageIndex);
        });
    }

    // tslint:disable-next-line:no-empty
    protected branchStatusUpdate(): void {
    }

    private setModifyFlg() {
        if (this.name === 'savingAccountPassword' || this.name === 'savingsDepositAccountPassword') {
            this.action.setStateSubmitDataValue({name: 'isOneSetCardModify', value: true});
        } else if (this.name === 'addCheckConfirmation') {
            this.action.setStateSubmitDataValue({name: 'isAddCheckModify', value: true});
        } else {
            this.action.setStateSubmitDataValue({name: 'isModify', value: true});
        }
    }

    /**
     * 変更後のデータをクリア、フラグを立てる
     */
    private initData() {
        switch (this.name) {
            case 'holderName':
                this.action.clearHolderName();
                this.action.setStateSubmitDataValue({name: 'isNameChange', value: true});
                this.action.setStateSubmitDataValue({name: 'nameDifferenceInfos', value: undefined});
                this.action.setStateSubmitDataValue({name: 'nameidentiNameDifCifAcceptCheckResult', value: undefined});
                this.action.setNameDifferenceFlg(false);
                break;
            case 'holderAddress':
                this.action.clearHolderAddress();
                this.action.setStateSubmitDataValue({name: 'isAddressChange', value: true});
                this.action.setStateSubmitDataValue({name: 'addressDifferenceInfos', value: undefined});
                this.action.setStateSubmitDataValue({name: 'nameidentiAddressDifCifAcceptCheckRestlt', value: undefined});
                this.action.setAddressDifferenceFlg(false);
                break;
            case 'holderMobileNo':
                this.action.clearHolderPhoneNo();
                this.action.setStateSubmitDataValue({name: 'isTelphoneChange', value: true});
                this.action.setStateSubmitDataValue({name: 'telDifferenceInfos', value: undefined});
                this.action.setStateSubmitDataValue({name: 'nameidentiTelDifCifAcceptCheckResult', value: undefined});
                this.action.setTelphoneDifferenceFlg(false);
                break;
            case 'addCheckConfirmation':
                this.action.clearAddCheckData();
                break;
            default:
                break;
        }
    }

    private modifyAnswer() {
        switch (this.name) {
            case 'holderName': {
                const dict = {
                    holderName: this.state.submitData.firstName ?
                        this.state.submitData.firstName + COMMON_CONSTANTS.FULL_SPACE + this.state.submitData.lastName : '',
                    holderNameFurigana: this.state.submitData.firstNamegana ?
                        this.state.submitData.firstNamegana + COMMON_CONSTANTS.SPACE + this.state.submitData.lastNamegana : '',
                    holderNameAlphabet: this.state.submitData.firstNameAlphabet ?
                        this.state.submitData.firstNameAlphabet + COMMON_CONSTANTS.SPACE + this.state.submitData.lastNameAlphabet : '',
                    printSealSlipFlag: this.state.submitData.printSealSlipFlag,
                    unprintableKanji: this.state.submitData.unprintableKanji
                };
                this.action.transferModifyToCifInfo(dict);
                break;
            }
            case 'holderAddress': {
                const dict = {
                    holderAddressPrefecture: this.state.submitData.holderAddressPrefecture,
                    holderAddressPrefectureFuriKana: this.state.submitData.holderAddressPrefectureFurigana,
                    holderAddressCountyUrbanVillage: this.state.submitData.holderAddressCountyUrbanVillage,
                    holderAddressCountyUrbanVillageFuriKana: this.state.submitData.holderAddressCountyUrbanVillageFurigana,
                    holderAddressStreetNameSelect:
                        this.state.submitData.holderAddressStreetNameInput ||
                        this.state.submitData.holderAddressStreetNameSelect ||
                        this.state.submitData.holderAddressStreet,
                    holderAddressStreetNameFuriKanaSelect:
                        this.state.submitData.holderAddressStreetNameFuriganaInput ||
                        this.state.submitData.holderAddressStreetNameFuriganaSelect ||
                        this.state.submitData.holderAddressStreetNameFuriKanaInput ||
                        this.state.submitData.holderAddressStreetFurigana,
                    holderAddressHouseNumber: this.state.submitData.holderAddressHouseNumber,
                    holderAddressHouseNumberFuriKana: this.state.submitData.holderAddressHouseNumberFurigana,
                    holderZipCode: (this.state.submitData.firstZipCode + COMMON_CONSTANTS.HALF_HYPHEN +
                        this.state.submitData.lastZipCode),
                };
                this.action.transferModifyToCifInfo(dict);
                break;
            }
            case 'holderMobileNo': {
                const dict = {
                    holderMobileNo: this.state.submitData.firstMobileNo ?
                        (this.state.submitData.firstMobileNo + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.secondMobileNo
                            + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdMobileNo)
                        : '',
                    holderTelephoneNo: this.state.submitData.firstTel ?
                        (this.state.submitData.firstTel + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.secondTel
                            + COMMON_CONSTANTS.HALF_HYPHEN + this.state.submitData.thirdTel)
                        : ''
                };
                this.action.transferModifyToCifInfo(dict);
                break;
            }
            default:
                break;
        }
        this.changeData = {changedInfo: true};
    }

    private setupHeaderOptions() {
        this.headerOptions = {
            showReturnTopButton: false,
            title: this.chatFlowNavParam.currentTitle,
            leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
        };
    }

    /**
     *  操作ログ
     */
    private saveOperationLog() {
        const logInfo: IOperationInfo = {
            screenName: this.state.currentFileInfo.screenId,
            yamlId: undefined,
            yamlOrder: undefined,
            comType: undefined,
            value: this._labels.logging.Common.Header.CloseAction,
        };
        this.logging.log(this.logging.generalOperationParams(logInfo));
    }
}
