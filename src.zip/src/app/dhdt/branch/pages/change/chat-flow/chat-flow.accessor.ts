import { ComponentFactory, ComponentFactoryResolver, ComponentRef, EventEmitter } from '@angular/core';
import { InjectionUtils } from 'adep/utils';

import { ChangeAction } from 'dhdt/branch/pages/change/action/change.action';
import { ChangeChatFlowRenderer } from 'dhdt/branch/pages/change/chat-flow/chat-flow.renderer';
import { ChangeSignal, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import { ComponentProvider } from 'dhdt/branch/shared/components/component-provider';
import { Content } from 'ionic-angular';

export class ChangeChatFlowAccessor {

    protected action: ChangeAction;
    protected store: ChangeStore;

    private _chatFlowRenderer: ChangeChatFlowRenderer;

    private factory: ComponentFactory<ComponentProvider>;
    private qf: ComponentRef<ComponentProvider>;
    private componentFactoryResolver: ComponentFactoryResolver;

    constructor(public chatFlowRenderer?: ChangeChatFlowRenderer) {

        this.action = InjectionUtils.injector.get(ChangeAction);
        this.store = InjectionUtils.injector.get(ChangeStore);
        this.componentFactoryResolver = InjectionUtils.injector.get(ComponentFactoryResolver);

        this._chatFlowRenderer = chatFlowRenderer;

        this.addListioner();
    }

    public addComponent(datas: any, from: any, to: any, options: any = {}): EventEmitter<any> {
        this.factory = this.componentFactoryResolver.resolveComponentFactory(from);
        this.qf = to.createComponent(this.factory);
        this.qf.instance.datas = datas;
        this.qf.instance.options = options;
        this.qf.instance.content = this._chatFlowRenderer.content;
        this.qf.instance.footer = to;
        return this.qf.instance.launch;
    }

    public clearComponent() {
        if (this.qf) {
            this.qf.destroy();
        }
    }

    public destroy(): void {
        this.store.unregisterSignalHandler(ChangeSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(ChangeSignal.SEND_ANSWER);
    }

    public setContent(content: Content) {
        this._chatFlowRenderer.content = content;
    }

    public setRenderer(chatFlowRenderer?: ChangeChatFlowRenderer) {
        this._chatFlowRenderer = chatFlowRenderer;
    }

    private addListioner() {
        this.store.registerSignalHandler(ChangeSignal.GET_QUESTION, (pageIndex: number) => {
            // show first message
            this.clearComponent();
            this.action.getNextChatByAnswer(0, pageIndex);
        });
        this.store.registerSignalHandler(ChangeSignal.SEND_ANSWER, (datas) => {
            const question = datas.question;
            const pageIndex = datas.pageIndex;
            this.clearComponent();
            this._chatFlowRenderer.rendererComponents(question, pageIndex);
        });
    }

}
