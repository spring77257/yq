import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { InjectionUtils, ObjectUtils } from 'adep/utils';
import { ChangeAction } from 'dhdt/branch//pages/change/action/change.action';
import { BussinessCode, DeliveryStatus, UnacceptableCode } from 'dhdt/branch/pages/change/change-consts';
import { ChangeChatFlowTypes } from 'dhdt/branch/pages/change/chat-flow/change.chat-flow-types';
import {
    ChangeAddressHandler
} from 'dhdt/branch/pages/change/chat-flow/handler/change-address.handler';
import { ChangeQuestionsModel } from 'dhdt/branch/pages/change/entity/change-questions.model';
import { ChangeSignal, ChangeState, ChangeStore } from 'dhdt/branch/pages/change/store/change.store';
import {
    ChatOption, COMMON_CONSTANTS, Constants, JudgeResultStatus, RegionCodeDeterminationMethod
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { SelectAddressCommonComponent } from 'dhdt/branch/shared/components/address/view/select-address-common.component';
import { SelectStreetComponent } from 'dhdt/branch/shared/components/address/view/select-street.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { AcceptionResult } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { RegionCodeSearchRequestEntity } from 'dhdt/branch/shared/entity/region-code.entity';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ServerInfoService } from 'dhdt/branch/shared/services/server-info.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import { App } from 'ionic-angular';

export const CHANGE_ADDRESS_RENDERER = 'ChangeAddressRenderer';

/**
 * 諸届変更項目選択チャットのrenderer
 *
 * @export
 * @class AutomaticTransferCancelRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: CHANGE_ADDRESS_RENDERER,
    templateYaml: 'chat-flow-def-change-address.yml'
})
export class ChangeAddressRenderer extends DefaultChatFlowRenderer {
    public processType: number = COMMON_CONSTANTS.ProcessType.RequiredInput;
    private state: ChangeState;
    private loginState: LoginState;

    constructor(
        private action: ChangeAction,
        private store: ChangeStore,
        private inputHandler: ChangeAddressHandler,
        private changeUtils: ChangeUtils,
        private loginStore: LoginStore,
        app: App,
        private changeStore: ChangeStore,
        private labelService: LabelService,
        private modalService: ModalService) {
        super(action, inputHandler);

        this.state = store.getState();
        this.loginState = loginStore.getState();
    }

    @Renderer(ChangeChatFlowTypes.ITEM_LIST)
    public onItemLIst(entity: any, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.JUDGE)
    public onJudge(entity: ChangeQuestionsModel, pageIndex: number): void {
        let judgeResult: string;
        let params;
        switch (entity.name) {
            case 'isAddressChange': {
                // 住所変更時に0設定
                judgeResult = this.state.submitData.isAddressChange ? JudgeResultStatus.RESULT_0 : JudgeResultStatus.RESULT_1;
                break;
            }
            case 'allCifTradingConditionsJudge': {
                // PID配下全CIFの取引ぶりの判定
                this.cifTradingConditionsJudge(true, entity, pageIndex);
                return;
            }
            case 'isNonDelivery': {
                judgeResult = JudgeResultStatus.RESULT_1;
                // PID配下の全てCIF情報に「郵便不着」あれば、０ルートに行きます
                this.state.submitData.allCifInfos.forEach(
                    (cifInfo: CifInfo) => {
                        if (cifInfo.nonDelivery === DeliveryStatus.NON_DELIVERY) {
                            judgeResult = JudgeResultStatus.RESULT_0;
                        }
                    }
                );
                break;
            }
            case 'isNotExistingAddressCodeStatus': {
                judgeResult = this.state.submitData.isNotExistingAddressCodeStatus ?
                    JudgeResultStatus.RESULT_0 : JudgeResultStatus.RESULT_1;
                break;
            }
            case 'getAddressFromZipcode': {
                const serverInfoService = InjectionUtils.injector.get(ServerInfoService);
                let firstZipCode;
                let lastZipCode;
                if (this.state.submitData.firstZipCode) {
                    firstZipCode = this.state.submitData.firstZipCode;
                }
                if (this.state.submitData.lastZipCode) {
                    lastZipCode = this.state.submitData.lastZipCode;
                }
                const zipCode = firstZipCode + lastZipCode + '';
                params = { zipCode: zipCode };
                serverInfoService.getInfoFormServe(entity.name, params).subscribe((result) => {
                    entity.choices.forEach((choice) => {
                        if (result === choice.value) {
                            this.emitMessageRetrivalEvent(choice.next, pageIndex);
                            return;
                        }
                    });
                });
                break;
            }
            case 'getStreetInitialsKana': {
                const serverInfoService = InjectionUtils.injector.get(ServerInfoService);
                let prefecture;
                let village;
                if (this.state.submitData.holderAddressPrefecture) {
                    prefecture = this.state.submitData.holderAddressPrefecture;
                }
                if (this.state.submitData.holderAddressCountyUrbanVillage) {
                    village = this.state.submitData.holderAddressCountyUrbanVillage;
                }
                params = {
                    prefectureKanji: prefecture,
                    countyUrbanVillageKanji: village
                };
                serverInfoService.getInfoFormServe(entity.name, params).subscribe((result) => {
                    entity.choices.forEach((choice) => {
                        if (result === choice.value) {
                            this.emitMessageRetrivalEvent(choice.next, pageIndex);
                            return;
                        }
                    });
                });
                break;
            }
            case 'addressDifferenceCheckResult': {
                this.addressDifferenceCheck(entity, pageIndex);
                break;
            }
            case 'addressDifferenceAddressChange': {
                // 住所変更実施または住所差分ありのとき0、それ以外1
                judgeResult = this.state.submitData.isAddressChange || this.state.isAddressDifference ?
                    JudgeResultStatus.RESULT_0 : JudgeResultStatus.RESULT_1;
                break;
            }
            // スワイプCIFが住所変更後と変更前が同じかどうか、郵便不着フラグあるかどうかをチェックする
            case 'isSwCifAddressDifAndNoDelivery': {

                // デフォルトが変更前と変更後が違う
                let _judgeResult = JudgeResultStatus.RESULT_1;

                if (this.state.submitData.isAddressChange) {
                    // 住所コードを取得
                    const postCode = '';
                    const prefectureKana = this.state.submitData.holderAddressPrefectureFurigana;
                    const countyUrbanVillageKana = this.state.submitData.holderAddressCountyUrbanVillageFurigana;
                    const streetKana = this.state.submitData.holderAddressStreetNameFuriganaInput ||
                        this.state.submitData.holderAddressStreetNameFuriganaSelect ||
                        this.state.submitData.holderAddressStreetNameFuriKanaInput ||
                        this.state.submitData.holderAddressStreetFurigana ||
                        '';
                    const requestParams = {
                        postCode: postCode,
                        prefectureKana: prefectureKana,
                        countyUrbanVillageKana: countyUrbanVillageKana,
                        streetKana: streetKana
                    };
                    if (!this.state.submitData.firstZipCode) {
                        this.getHolderZipCode();
                        this.store.registerSignalHandler(ChangeSignal.GET_HOLDER_ZIP_CODE, () => {
                            this.store.unregisterSignalHandler(ChangeSignal.GET_HOLDER_ZIP_CODE);
                            requestParams.postCode = this.state.submitData.firstZipCode + this.state.submitData.lastZipCode;
                            this.action.getAddressCode(requestParams);
                        });
                    } else {
                        requestParams.postCode = this.state.submitData.firstZipCode + this.state.submitData.lastZipCode;
                        this.action.getAddressCode(requestParams);
                    }

                    this.store.registerSignalHandler(ChangeSignal.GET_ADDRESS_CODE, () => {
                        this.store.unregisterSignalHandler(ChangeSignal.GET_ADDRESS_CODE);

                        // スワイプCIFを取得
                        const swipeCifInfo =
                            this.state.submitData.allCifInfos.filter((cifInfo: CifInfo) =>
                                cifInfo.customerId === this.state.submitData.customerId);

                        const isDiff = this.changeUtils.isAddressDiference(swipeCifInfo[0], this.state.submitData.holderAddressCode,
                            this.state.submitData.holderAddressHouseNumberFurigana);

                        // 変更後と変更前が差異がなし　かつ　郵便不着フラグが存在しません
                        if (!isDiff && swipeCifInfo[0].nonDelivery !== DeliveryStatus.NON_DELIVERY) {
                            _judgeResult = JudgeResultStatus.RESULT_0;
                        }
                        this.nextChatByJudge(entity, pageIndex, _judgeResult);
                    });

                }
                break;
            }
            case 'doTabletCheck': {
                this.acceptCheckForUpdateCif(entity, pageIndex);
                break;
            }
            case 'updateCifTradingConditionsJudge': {
                // スワイプCIFまたは住所差分のあるCIFに関連する取引ぶりの判定
                this.cifTradingConditionsJudge(false, entity, pageIndex);
                return;
            }
            // スワイプCIFの受付可否実行判定（喪失/差替/カード新規発行側のみ）
            case 'isAcceptCheckForSwipeCif': {
                judgeResult = JudgeResultStatus.RESULT_1;
                if ((this.state.isCalledFromLoss || this.state.isCalledFromReplace || this.state.isCalledFromNewest)
                    && !this.state.submitData.isTelphoneChange
                    && (this.state.submitData.nonDelivery === DeliveryStatus.NON_DELIVERY
                        || this.state.submitData.isNotExistingAddressCodeStatus)) {
                    // 電話番号[変更なし]を選択（住所は[変更なし]の前提） かつ
                    // 郵便不着あり先、もしくは住所コード該当なし先で住所を変更する場合、スワイプCIFの受付可否を実施する
                    judgeResult = JudgeResultStatus.RESULT_0;
                }
                break;
            }
            case 'acceptCheckForSwipeCif': {
                judgeResult = JudgeResultStatus.RESULT_1;
                const level = this.changeUtils.getTransactionLevel(
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                // ジュニアNISA対応
                const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(this.state.submitData.birthdate,
                    this.state.submitData.swipeCifAcceptCheckResult.account.tradingConditions);
                if (level.levelOne || isHaveJuniorNisa) {
                    judgeResult = JudgeResultStatus.RESULT_0;
                }
                break;
            }
        }
        this.nextChatByJudge(entity, pageIndex, judgeResult);
    }

    @Renderer(ChangeChatFlowTypes.REQUEST_SWIPE_CIF)
    public requestSwipeCifStatus(entity: ChatFlowMessageInterface, pageIndex: number) {
        // スワイプCIFの受付可否チェック
        const params = {
            receptionTenban: this.loginState.belongToBranchNo,    // 受付店番
            accounts: [{
                customerId: this.state.submitData.customerId    // 顧客番号
            }], // 口座情報
            businessCode: BussinessCode.ADDRESS_TEL_MENU_CHANGE, // 業務コード
        };
        const dict = {
            tabletApplyId: this.state.tabletApplyId,
            params: params,
        };

        this.store.registerSignalHandler(ChangeSignal.UNACCEPTABLES_NG, (response: HttpStatusError) => {
            // 事故取引禁止注意エラーの場合、注意コードを取得の上エラーモーダルを表示する
            this.store.unregisterSignalHandler(ChangeSignal.UNACCEPTABLES_NG);
            const errorInfo = this.checkErrorCode(response.errors.data);
            this.showErrorModal(errorInfo);
        });

        this.store.registerSignalHandler(ChangeSignal.ACCEPT_CHECK_SWIPE_CIF, () => {
            this.store.unregisterSignalHandler(ChangeSignal.ACCEPT_CHECK_SWIPE_CIF);
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });

        this.action.acceptCheckForSwipeCif(entity, dict);
    }

    @Renderer(ChangeChatFlowTypes.NUMBER_KEYBORD)
    public onNumberKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            type: entity.type,
            name: entity.name,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: NumberInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * Pickerのコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer([
        ChangeChatFlowTypes.PREFECTURE_PICKER,
        ChangeChatFlowTypes.COUNTRY_URBAN_VILLAGE_PICKER])
    public onPicker(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            type: entity.type,
            name: entity.name,
            validationRules: entity.validationRules,
            submitData: this.state.submitData,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: PickerCommonComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.KEYBOARD)
    public onKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            defaultValues: InputUtils.getDefaultValues(entity.name, this.state.submitData),
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        let choices = null;
        // 「番地以降（漢字）」の場合
        if (entity.name === COMMON_CONSTANTS.KEY_HOLDER_ADDRESS_HOUSE_NUMBER_FOR_SHOW) {
            this.store.registerSignalHandler(ChangeSignal.SEARCH_REGION_CODE_COMPLETE, (data) => {
                this.store.unregisterSignalHandler(ChangeSignal.SEARCH_REGION_CODE_COMPLETE);
                choices = ObjectUtils.clone(entity.choices);
                // 地域コードに町丁名含まれない場合のみ、「町丁名（漢字）」入力済桁数により「番地以降（漢字）」入力可能最大桁数を調整する
                if (RegionCodeDeterminationMethod.WITHOUT_STREET === data.regionCodeDeterminationMethod) {
                    console.log('[dhdt] RegionCode is without street');
                    choices = this.reviseMaxlengthOfHolderAddressHouseNumberKanji(this.state, choices, entity);
                }
                // 入力キーボード配置
                this.emitRenderEvent({
                    class: KeyboardInputComponent,
                    data: choices,
                    options: options,
                }, entity, pageIndex);
            });
            const params = this.createRegionCodeSearchRequestParams(this.state);
            // change action へ実装
            this.action.searchRegionCode(params);
        } else {
            // 「番地以降（カナ）」の場合
            choices = ObjectUtils.clone(entity.choices);
            // 入力キーボード配置
            this.emitRenderEvent({
                class: KeyboardInputComponent,
                data: choices,
                options: options,
            }, entity, pageIndex);
        }
    }

    /**
     * 住所選択のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(ChangeChatFlowTypes.SELECT_ADDRESS)
    public onSelectAddress(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            submitData: this.state.submitData,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: SelectAddressCommonComponent,
            data: entity.type,
            options: options,
        }, entity, pageIndex);
    }

    /**
     * 住所選択のコンポーネントを追加
     * @param entity ymlファイルの格納データ
     * @param pageIndex 画面インデックス
     */
    @Renderer(ChangeChatFlowTypes.SELECT_STREET)
    public onSelectStreet(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        const params = {
            prefectureCode: this.state.submitData.holderAddressPrefectureCode,
            prefectureKanji: this.state.submitData.holderAddressPrefecture,
            countyUrbanVillageCode: this.state.submitData.holderAddressCountyUrbanVillageCode,
            countyUrbanVillageKanji: this.state.submitData.holderAddressCountyUrbanVillage,
        };
        this.emitRenderEvent({
            class: SelectStreetComponent,
            data: params,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.BUTTON)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            validationOn: null,
            kanaText: null,
            validationRules: null,
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        if (entity.option && entity.option === ChatOption.VALIDATION_ON) {
            let address = this.buildAddress();
            address = StringUtils.convertHankaku2Zankaku(address);
            options.validationOn = ChatOption.VALIDATION_ON;
            options.kanaText = address;
            options.validationRules = entity.validationRules;
        }
        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.VERIFICATION_DOCUMENT_IMG_JUDGE)
    public onVerificationDocumentImgJudge(entity: ChatFlowMessageInterface, pageIndex: number) {
        let isAllCif: boolean;
        switch (entity.name) {
            case 'allCif': {
                isAllCif = true;
                break;
            }
            case 'difCif': {
                isAllCif = false;
                break;
            }
        }
        const params = {
            isAllCif: isAllCif,
            isChange: this.state.submitData.isAddressChange,
            isDifference: this.state.isAddressDifference,
            allCifTradingConditions: this.state.submitData.allCifTradingConditions,
            identiDifCifAcceptCheckResult: this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt
        };
        const addressDocumentImg = this.changeUtils.verificationAddressDocumentImgJudge(params);
        if (addressDocumentImg) {
            this.action.setStateSubmitDataValue({ name: 'addressDocumentImg', value: addressDocumentImg });
        }
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(ChangeChatFlowTypes.CHANGE_CONTENT)
    public onChangeContent(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity, pageIndex);
    }

    protected get userAnswers(): any {
        return this.state.submitData;
    }

    private reviseMaxlengthOfHolderAddressHouseNumberKanji(state: ChangeState, choices: any, entity: any) {
        const holderAddressStreetLength = this.getStreetNameKanjiFromState(state).length;
        choices[0].validationRules.max = entity.choices[0].validationRules.max
            - holderAddressStreetLength;
        return choices;
    }

    private createRegionCodeSearchRequestParams(state: ChangeState): RegionCodeSearchRequestEntity {
        const params = new RegionCodeSearchRequestEntity();
        params.prefectureKanji = this.state.submitData.holderAddressPrefecture || '';
        params.countyUrbanVillageKanji = this.state.submitData.holderAddressCountyUrbanVillage || '';
        params.streetKanji = this.getStreetNameKanjiFromState(state) || '';
        return params;
    }

    private getStreetNameKanjiFromState(state: ChangeState): string {
        const holderAddressStreetNameInput = this.state.submitData.holderAddressStreetNameInput;
        const holderAddressStreetNameSelect = this.state.submitData.holderAddressStreetNameSelect;
        const holderAddressStreet = this.state.submitData.holderAddressStreet;

        let determinedHolderAddressStreet: string = '';
        if (holderAddressStreetNameInput) {
            // 町丁名漢字テキスト入力の場合
            determinedHolderAddressStreet = holderAddressStreetNameInput;
        } else if (holderAddressStreet) {
            // 町丁名単体の選択コンポネントで選択の場合
            determinedHolderAddressStreet = holderAddressStreet;
        } else if (holderAddressStreetNameSelect) {
            // 住所選択(都道府県～町丁名まで一括で選択)コンポネントで選択の場合
            determinedHolderAddressStreet = holderAddressStreetNameSelect;
        }
        return determinedHolderAddressStreet;
    }

    /*
    * typeがjudgeの際に、分岐しして次のチャットを開始させる
    *
    * @param entity
    * @param pageIndex
    * @param judgeResult
    */
    private nextChatByJudge(entity: ChangeQuestionsModel, pageIndex: number, judgeResult: string) {
        entity.choices.forEach((choice) => {
            if (choice.value === judgeResult) {
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
                return;
            }
        });
    }

    private cifTradingConditionsJudge(isAllCif: boolean, entity: ChangeQuestionsModel, pageIndex: number) {
        let judgeResult: string;
        const params = {
            isAllCif: isAllCif,
            isChange: this.state.submitData.isAddressChange,
            isDifference: this.state.isAddressDifference,
            allCifTradingConditions: this.state.submitData.allCifTradingConditions,
            identiDifCifAcceptCheckResult: this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt
        };
        judgeResult = (this.changeUtils.isNeed3B(params) || this.changeUtils.isNeed3C(params)) ?
            JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
        this.nextChatByJudge(entity, pageIndex, judgeResult);
    }

    /**
     * 郵便番号を住所マスターから取得
     */
    private getHolderZipCode() {
        const holderAddressPrefecture = this.state.submitData.holderAddressPrefecture;
        const holderAddressCountyUrbanVillage = this.state.submitData.holderAddressCountyUrbanVillage;
        const holderAddressStreetNameSelect =
            this.state.submitData.holderAddressStreetNameInput ||
            this.state.submitData.holderAddressStreetNameSelect ||
            this.state.submitData.holderAddressStreet ||
            '';
        this.action.getHolderZipCode(
            holderAddressPrefecture,
            holderAddressCountyUrbanVillage,
            holderAddressStreetNameSelect
        );
    }

    private addressDifferenceCheck(entity: ChangeQuestionsModel, pageIndex: number) {
        let judgeResult;
        if (this.state.submitData.isAddressChange) {
            this.action.setAddressDifferenceFlg(false);
            const postCode = '';
            const prefectureKana = this.state.submitData.holderAddressPrefectureFurigana;
            const countyUrbanVillageKana = this.state.submitData.holderAddressCountyUrbanVillageFurigana;
            const streetKana = this.state.submitData.holderAddressStreetNameFuriganaInput ||
                this.state.submitData.holderAddressStreetNameFuriganaSelect ||
                this.state.submitData.holderAddressStreetNameFuriKanaInput ||
                this.state.submitData.holderAddressStreetFurigana ||
                '';
            const requestParams = {
                postCode: postCode,
                prefectureKana: prefectureKana,
                countyUrbanVillageKana: countyUrbanVillageKana,
                streetKana: streetKana
            };
            if (!this.state.submitData.firstZipCode) {
                this.getHolderZipCode();
                this.store.registerSignalHandler(ChangeSignal.GET_HOLDER_ZIP_CODE, () => {
                    this.store.unregisterSignalHandler(ChangeSignal.GET_HOLDER_ZIP_CODE);
                    requestParams.postCode = this.state.submitData.firstZipCode + this.state.submitData.lastZipCode;
                    this.action.getAddressCode(requestParams);
                });
            } else {
                requestParams.postCode = this.state.submitData.firstZipCode + this.state.submitData.lastZipCode;
                this.action.getAddressCode(requestParams);
            }
            this.store.registerSignalHandler(ChangeSignal.GET_ADDRESS_CODE, () => {
                this.store.unregisterSignalHandler(ChangeSignal.GET_ADDRESS_CODE);
                this.action.setStateSubmitDataValue({
                    name: 'addressDifferenceInfos',
                    value: this.changeUtils.getAddressDifInfo(this.state.submitData.allCifInfos,
                        this.state.submitData.customerId, this.state.submitData.holderAddressCode,
                        this.state.submitData.holderAddressHouseNumberFurigana)
                });
                judgeResult = JudgeResultStatus.RESULT_1;
                for (const element of this.state.submitData.addressDifferenceInfos) {
                    if (element.isDifference) {
                        judgeResult = JudgeResultStatus.RESULT_0;
                        this.action.setAddressDifferenceFlg(true);
                        break;
                    }
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
            });
        } else if (this.state.submitData.addressDifferenceInfos && this.state.isAddressDifference) {
            judgeResult = JudgeResultStatus.RESULT_0;
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        } else {
            judgeResult = JudgeResultStatus.RESULT_1;
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        }
    }

    private acceptCheckForUpdateCif(entity: ChangeQuestionsModel, pageIndex: number) {
        // 名寄せの住所更新対象に対して受付可否チェック実施
        this.action.acceptCheckForAddressDifCif(this.makeAcceptCheckApiParams(), this.state.submitData.addressDifferenceInfos);

        let judgeResult;
        let level;

        this.store.registerSignalHandler(ChangeSignal.ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF, (acceptCheckResult: AcceptionResult) => {
            this.store.unregisterSignalHandler(ChangeSignal.ACCEPT_TARGET_FOR_ADDRESS_DIF_CIF);
            const errMessageArr: Array<{ customerId: string, message: string }> = [];
            // レスポンスパラメータの中に、受付可否チェック検出対象がいたら離脱
            for (const item of this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                let branchCode: string = '';
                for (const cifInfo of this.state.submitData.allCifInfos) {
                    if (item.customerId === cifInfo.customerId && this.changeUtils.isHostError(item.accounts.errorCode)) {
                        branchCode = cifInfo.customerManagementBranchCode;
                        if (item.accounts.unacceptables && item.accounts.unacceptables.length > 0) {
                            // 受付不可情報がある場合、表示メッセージは「エラー理由 ＋ 事故・取引禁止・注意コード」。
                            for (const acceptItem of item.accounts.unacceptables) {
                                errMessageArr.push({
                                    customerId: cifInfo.customerId, message: branchCode + COMMON_CONSTANTS.FULL_COLON
                                        + item.accounts.errorCode + COMMON_CONSTANTS.SPACE + acceptItem.unacceptableCode
                                });
                            }
                        } else {
                            // 受付不可情報がない場合、表示メッセージは「エラー理由」のみ。
                            errMessageArr.push({
                                customerId: cifInfo.customerId, message: branchCode
                                    + COMMON_CONSTANTS.FULL_COLON + item.accounts.errorCode
                            });
                        }
                    }
                }
            }
            const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
            let index = 0;
            let isNeedBr = 1;
            let message: string = '';
            let messageBefore: { customerId: string, message: string } = { customerId: undefined, message: undefined };
            if (errMessageArr.length > 0) {
                for (const err of errMessageArr) {
                    if (index === 0) {
                        message = err.message;
                    } else if (messageBefore.customerId === err.customerId && maxArr > isNeedBr) {
                        isNeedBr++;
                        message = message + COMMON_CONSTANTS.SLASH + err.message.substring(err.message.length - 3);
                    } else {
                        isNeedBr = 1;
                        message = message + COMMON_CONSTANTS.NEW_LINE + err.message;
                    }
                    index++;
                    messageBefore = err;
                }
                this.showErrorModal(message);
                return;
            }
            judgeResult = JudgeResultStatus.RESULT_1;
            if (this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt) {
                this.state.submitData.nameidentiAddressDifCifAcceptCheckRestlt.forEach((acceptResult) => {
                    // ジュニアNISA対応
                    const cifInfo =
                        this.state.submitData.allCifInfos.filter((item) => item.customerId === acceptResult.customerId);
                    const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(cifInfo[0].birthDate,
                        acceptResult.accounts.tradingConditions);
                    level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                    if (level.levelOne || isHaveJuniorNisa) {
                        judgeResult = JudgeResultStatus.RESULT_0;
                    }
                });
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        });
    }

    /**
     * 受付可否チェックパラメータ生成
     */
    private makeAcceptCheckApiParams() {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((element) => {
            this.state.submitData.addressDifferenceInfos.forEach((difItem) => {
                if (element.customerId !== this.state.submitData.customerId &&
                    element.customerId === difItem.customerId && difItem.isDifference) {
                    accounts.push({
                        customerId: element.customerId
                    });
                }
            });
        });

        const acceptCheckApiParams = {
            tabletApplyId: this.state.tabletApplyId,
            params: {
                receptionTenban: this.loginState.belongToBranchNo,
                accounts: accounts,
                businessCode: BussinessCode.ADDRESS_TEL_MENU_CHANGE,
            }
        };

        return acceptCheckApiParams;
    }

    private showErrorModal(errorCode: string, callback?: any) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            this.labelService.labels.common.error.host.support,
            errorCode, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }

    private buildAddress(): string {
        // 町丁名テキスト入力 / 住所・町丁名ボタン選択 / 住所選択で「町丁名無し住所」選択 の3パターン考慮する
        const streetNameFurigana = this.state.submitData.holderAddressStreetNameFuriganaSelect ||
            this.state.submitData.holderAddressStreetNameFuriganaInput || '';
        const address = (
            this.state.submitData.holderAddressPrefectureFurigana +
            this.state.submitData.holderAddressCountyUrbanVillageFurigana +
            streetNameFurigana +
            this.state.submitData.holderAddressHouseNumberFurigana
        ) || '';
        return address;
    }

    /**
     * スワイプCIF専用のエラーメッセージ作成処理
     */
    private checkErrorCode(acceptCheckResult: AcceptionResult) {
        let errorInfo: any;
        let isNeedBr = 1;
        let index = 0;
        const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        for (const account of acceptCheckResult.accounts) {
            if (this.changeUtils.isHostError(account.errorCode)) {
                let unacceptables = '';
                const swipeCifInfo =
                    this.state.submitData.allCifInfos.filter((cifInfo: CifInfo) => cifInfo.customerId === this.state.submitData.customerId);
                errorInfo = swipeCifInfo[0].customerManagementBranchCode + COMMON_CONSTANTS.FULL_COLON + account.errorCode;

                for (const unacceptable of account.unacceptables) {
                    unacceptables = unacceptable.unacceptableCode;
                    if (index === 0) {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SPACE + unacceptables;
                    } else if (isNeedBr > maxArr) {
                        // 1行に最大3つの注意コードを表示する
                        // 超える場合は改行して店番＋エラー情報＋注意コードを表示する
                        errorInfo = errorInfo + COMMON_CONSTANTS.NEW_LINE + errorInfo.slice(0, 14) + unacceptables;
                        isNeedBr = 1;
                    } else {
                        errorInfo = errorInfo + COMMON_CONSTANTS.SLASH + unacceptables;
                    }
                    index++;
                    isNeedBr++;
                }
            }
        }
        return errorInfo;
    }
}
