import { NgModule } from '@angular/core';
import { FATCAModifyHandler } from 'dhdt/branch/pages/common-business/business/fatca/handler/fatca-modify.handler';
import { FATCAModifyRenderer } from 'dhdt/branch/pages/common-business/business/fatca/renderer/fatca-modify.renderer';

@NgModule({
    providers: [
        FATCAModifyRenderer,
        FATCAModifyHandler
    ]
})
export class FATCAModifyModule { }
