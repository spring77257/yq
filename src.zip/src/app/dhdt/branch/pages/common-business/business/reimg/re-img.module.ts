import { NgModule } from '@angular/core';
import { ReImgHandler } from 'dhdt/branch/pages/common-business/business/reimg/handler/re-img.handler';
import { ReImgRenderer } from 'dhdt/branch/pages/common-business/business/reimg/renderer/re-img.renderer';

@NgModule({
    providers: [
        ReImgHandler,
        ReImgRenderer
    ]
})
export class ReImgModule { }
