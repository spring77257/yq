import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { CommonBusinessRendererType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';

/**
 * `DefaultChatFlowInputHandler`において、自動振込解約画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class OpenStoretInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class OpenStoretInputHandler extends DefaultChatFlowInputHandler {

    constructor(private action: CommonBusinessAction) {
        super(action);
    }

    @InputHandler(CommonBusinessRendererType.SELECT_BRANCH)
    private onSelectBranch(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.action.setAnswer({
            text: answer.text,
            value: [{
                key: entity.name,
                value: answer
            }]
        });
        this.chatFlowCompelete();
    }
}
