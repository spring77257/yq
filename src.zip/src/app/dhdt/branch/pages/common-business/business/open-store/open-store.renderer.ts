import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { OpenStoretInputHandler } from 'dhdt/branch/pages/common-business/business/open-store/open-store.handler';
import {
    CommonBusinessRenderer, CommonBusinessRendererType, CommonBusinessType
} from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import {
    CommonBusinessState, CommonBusinessStore
} from 'dhdt/branch/pages/common-business/store/common-business.store';
import { SelectBranchComponent } from 'dhdt/branch/shared/components/branch/view/select-branch.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

export const OPEN_STORE_RENDERER = 'OpenStoretRenderer';

/**
 * `DefaultChatFlowRenderer`において、自動振込解約画面に利用できるRendererを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferCancelRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: OPEN_STORE_RENDERER,
    templateYaml: 'chat-flow-def-open-store.change.yml'
})
@CommonBusinessRenderer({
    name: OPEN_STORE_RENDERER,
    type: CommonBusinessType.OpenStore
})
export class OpenStoretRenderer extends DefaultChatFlowRenderer {
    public processType: number = -1;
    private state: CommonBusinessState;

    constructor(
        private action: CommonBusinessAction,
        private store: CommonBusinessStore,
        inputHandler: OpenStoretInputHandler) {
        super(action, inputHandler);

        this.state = store.getState();
    }

    protected get userAnswers(): any {
        return null;
    }

    @Renderer(CommonBusinessRendererType.SELECT_BRANCH)
    public onSelectBranch(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            maxColNum: 2
        };
        this.emitRenderEvent({
            class: SelectBranchComponent,
            data: undefined,
            options: options
        }, entity, pageIndex);
    }
}
