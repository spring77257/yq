import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services/label.service';

@Injectable()
export class FATCAModifyService {
    private labels;

    constructor(labelService: LabelService) {
        this.labels = labelService.labels;
    }

    public get config() {
        const config = new Map();
        // Fatca Status
        config.set(FATCAModifyConfigName.FatcaStatus, {
            startOrder: 90,
            endOrder: 90,
            name: 'fatcaStatus',
            currentTitle: this.labels.fatcaTestTitle.status,
            pageIndex: 0,
            isCurrentPage: true
        });
        // Name
        config.set(FATCAModifyConfigName.FatcaCountry, {
            startOrder: 220,
            endOrder: 210,
            name: 'fatcaCountry',
            currentTitle: this.labels.fatcaTestTitle.fatcaCountry,
            pageIndex: 0,
            isCurrentPage: true
        });
        // Address
        config.set(FATCAModifyConfigName.SignFatca, {
            startOrder: 100,
            endOrder: 200,
            name: 'signFatca',
            currentTitle: this.labels.fatcaTestTitle.signFatca,
            pageIndex: 0,
            isCurrentPage: true
        });

        config.set(FATCAModifyConfigName.SignFatcaAgent, {
            startOrder: 1000,
            endOrder: 2000,
            name: 'signFatca',
            currentTitle: this.labels.fatcaTestTitle.signFatca,
            pageIndex: 0,
            isCurrentPage: true
        });

        return config;
    }

    public get mapping() {
        return {
            fatcaCountry: 'birthCountry',
            signFatca: 'signatureFatca',
        };
    }
}

export enum FATCAModifyConfigName {
    FatcaStatus     = 'fatcaStatus',
    FatcaCountry    = 'fatcaCountry',
    SignFatca       = 'signFatca',
    SignFatcaAgent  = 'signFatcaAgent',
}
