import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { UnacceptableCode } from 'dhdt/branch/pages/change/change-consts';
import { ChangeDifferenceEntity } from 'dhdt/branch/pages/change/entity/change-questions.model';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { ExistingAccountInputHandler } from 'dhdt/branch/pages/common-business/business/existing-account/existing-account.handler';
import { BussinessCode, JudgeResultStatus } from 'dhdt/branch/pages/common-business/common-business-consts';
import {
    CommonBusinessRenderer, CommonBusinessRendererType, CommonBusinessType
} from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import {
    CommonBusinessState, CommonBusinessStateSignal, CommonBusinessStore
} from 'dhdt/branch/pages/common-business/store/common-business.store';
import {
    AccountType, AgentInternalError, ApplyBC, BusinessCode, COMMON_CONSTANTS, ContractCategory, CountryCode, HasBankCard, ProductCode,
    ReceptionStatus
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { MediumInfosRequest } from 'dhdt/branch/pages/common/entity/medium-infos-request.entity';
import { LoginState, LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { AncestorDuplicateAccount } from 'dhdt/branch/pages/inherit/entity/ancestor-duplicate-account.entity';
import { AcceptionResult, AcceptionResultAccount } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { ExistingAccountTableComponent } from 'dhdt/branch/shared/components/existing-account-table/existing-account-table.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';

export const EXISTING_ACCOUNT_RENDERER = 'ExistingAccountRenderer';

/**
 * `DefaultChatFlowRenderer`において、自動振込解約画面に利用できるRendererを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferCancelRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: EXISTING_ACCOUNT_RENDERER,
    templateYaml: 'chat-flow-def-existing-account-confirmation.yml'
})
@CommonBusinessRenderer({
    name: EXISTING_ACCOUNT_RENDERER,
    type: CommonBusinessType.ExistingAccount
})
export class ExistingAccountRenderer extends DefaultChatFlowRenderer {
    public processType: number = -1;
    private state: CommonBusinessState;
    private loginState: LoginState;

    constructor(
        private action: CommonBusinessAction,
        private store: CommonBusinessStore,
        inputHandler: ExistingAccountInputHandler,
        private loginStore: LoginStore,
        private changeUtils: ChangeUtils,
        private modalService: ModalService,
        private labelService: LabelService,
    ) {
        super(action, inputHandler);

        this.state = store.getState();
        this.loginState = loginStore.getState();
    }

    protected get userAnswers(): any {
        return null;
    }

    @Renderer(CommonBusinessRendererType.EXISTING_ACCOUNT)
    public onExistingAccount(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: ExistingAccountTableComponent,
            data: this.state.data,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        let judgeResult: string;
        let tempResult: any;
        const customerInfo = this.state.data.account;
        switch (entity.name) {
            case 'nationalityCheck': {
                judgeResult = JudgeResultStatus.RESULT_0;
                if (customerInfo.accountType === '1' && customerInfo.isAgent === '0') {
                    judgeResult = JudgeResultStatus.RESULT_1;
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            case 'isDuplicatePid': {
                judgeResult = JudgeResultStatus.RESULT_1;
                const pidList: any = [];
                this.state.submitData.allCifInfos.forEach((cifInfo) => {
                    if (pidList.indexOf(cifInfo.personalId) === -1) {
                        pidList.push(cifInfo.personalId);
                    }
                });
                // PIDが2件以上存在する、離脱
                if (pidList.length > 1) {
                    judgeResult = JudgeResultStatus.RESULT_0;
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }

            case 'primaryAccountCheck': {
                let primaryCount: number = 0;  // 代表口座件数
                let relationCount: number = 0;  // 関連口座件数
                this.state.submitData.allCifInfos.forEach((cifInfo) => {
                    if (cifInfo.domesticAccountInfo) {
                        cifInfo.domesticAccountInfo.forEach((accountInfo) => {
                            if (accountInfo.ibContractInfo && accountInfo.ibContractInfo.contractCategory) {
                                accountInfo.ibContractInfo.contractCategory === ContractCategory.primary ?
                                primaryCount++ : relationCount++;
                            }
                        });
                    }
                });
                // PID配下口座なし、または代表口座ありの場合、次のチャットへ進む
                if ((primaryCount === 0 && relationCount === 0) || primaryCount > 0) {
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                } else {
                    // 代表口座なしかつ関連口座１件以上の場合、エラーモーダル
                    this.showErrorModal(AgentInternalError.ERROR_CODE_N_007);
                }
                break;
            }

            case 'hasDoubleCif': {
                if (!InputUtils.isTrngEnv()) {
                    // 研修環境以外の場合、二重CIF判定
                    if (this.doubleCifJudge()) {
                        this.showErrorModal(AgentInternalError.ERROR_CODE_N_004);
                    } else {
                        // 上記エラー事由に該当しない場合
                        this.emitMessageRetrivalEvent(entity.next, pageIndex);
                    }
                } else {
                    // 研修環境の場合
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
                }
                break;
            }

            case 'hasOrdinaryDepositAccount': {
                this.hasOrdinaryDepositAccountCheck(entity, pageIndex);
                break;
            }

            case 'receptionCheck': {

                this.store.registerSignalHandler(CommonBusinessStateSignal.UNACCEPTABLES_NG, (response) => {
                    // 受付可否チェックNGの場合、エラーモーダルを表示する
                    this.store.unregisterSignalHandler(CommonBusinessStateSignal.UNACCEPTABLES_NG);
                    // 受付可否チェックの結果と顧客番号を対応させる
                    const acceptionResult: Array<{ customerId: string, accounts: AcceptionResultAccount }>
                        = this.getAcceptCheckResult(this.state.submitData.existingAccount, response);
                    const errMessageArr: Array<{ customerId: string, message: string }> = [];
                    for (const item of acceptionResult) {
                        let branchCode: string = '';
                        for (const cifInfo of this.state.submitData.allCifInfos) {
                            if (item.customerId === cifInfo.customerId && this.changeUtils.isHostError(item.accounts.errorCode)) {
                                branchCode = cifInfo.customerManagementBranchCode;
                                if (item.accounts.unacceptables && item.accounts.unacceptables.length > 0) {
                                    // 受付不可情報がある場合、表示メッセージは「エラー理由 ＋ 事故・取引禁止・注意コード」。
                                    for (const acceptItem of item.accounts.unacceptables) {
                                        errMessageArr.push({
                                            customerId: cifInfo.customerId, message: branchCode + COMMON_CONSTANTS.FULL_COLON
                                                + item.accounts.errorCode + COMMON_CONSTANTS.SPACE + acceptItem.unacceptableCode
                                        });
                                    }
                                } else {
                                    // 受付不可情報がない場合、表示メッセージは「エラー理由」のみ。
                                    errMessageArr.push({
                                        customerId: cifInfo.customerId, message: branchCode
                                            + COMMON_CONSTANTS.FULL_COLON + item.accounts.errorCode
                                    });
                                }
                            }
                        }
                    }
                    const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
                    let index = 0;
                    let isNeedBr = 1;
                    let message: string = '';
                    let messageBefore: { customerId: string, message: string } = { customerId: undefined, message: undefined };
                    if (errMessageArr.length > 0) {
                        for (const err of errMessageArr) {
                            if (index === 0) {
                                message = err.message;
                            } else if (messageBefore.customerId === err.customerId && maxArr > isNeedBr) {
                                isNeedBr++;
                                message = message + COMMON_CONSTANTS.SLASH + err.message.substring(err.message.length - 3);
                            } else {
                                isNeedBr = 1;
                                message = message + COMMON_CONSTANTS.NEW_LINE + err.message;
                            }
                            index++;
                            messageBefore = err;
                        }
                        this.showErrorModal(message);
                        return;
                    }
                });

                this.store.unregisterSignalHandler(CommonBusinessStateSignal.RECEPTION_CHECK_ALL_CIF);
                this.store.registerSignalHandler(CommonBusinessStateSignal.RECEPTION_CHECK_ALL_CIF, () => {
                    judgeResult = JudgeResultStatus.RESULT_1;
                    this.nextChatByJudge(entity, pageIndex, judgeResult);
                });
                this.action.receptionCheckAllCif(entity, this.makeParam(customerInfo));
                break;
            }

            // BC申込判定
            case 'ifApplyBC': {
                judgeResult = this.state.data.account.ifApplyBC ===  ApplyBC.YES ? JudgeResultStatus.RESULT_0 : JudgeResultStatus.RESULT_1;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }

            // 名寄せCIFのBC受付可否チェック
            case 'bankCardApplyCheck': {
                this.store.registerSignalHandler(CommonBusinessStateSignal.BC_APPLY, (data: AcceptionResult[]) => {
                    this.store.unregisterSignalHandler(CommonBusinessStateSignal.BC_APPLY);
                    tempResult = this.checkAllAcceptionResult(data);
                    if (tempResult === ReceptionStatus.YES || tempResult === ReceptionStatus.NO) {
                        judgeResult = tempResult;
                        this.nextChatByJudge(entity, pageIndex, judgeResult);
                    } else {
                        // BC受付可否チェックエラーの場合、エラーモーダル表示
                        this.showErrorModal(tempResult);
                    }
                });

                // BC受付可否チェック実施
                this.action.bankCardApplyCheck(this.makeAcceptCheckApiParams());
                break;
            }

            // BC保有有無判定
            case 'ifhasBCCard': {
                judgeResult = JudgeResultStatus.RESULT_0;
                if (this.state.data.account.receptionCheckResult) {
                    // PID配下のBC保有有無判定は受付可否チェック（住変）のレスポンスbcHoldingStatusにて判定
                    this.state.data.account.receptionCheckResult.accounts.forEach((account) => {
                        if (account.bcHoldingStatus === HasBankCard.YES) {
                            judgeResult = JudgeResultStatus.RESULT_1;
                        }
                    });
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }

            case 'hasChanged': {
                judgeResult = JudgeResultStatus.RESULT_1;
                if (this.isNameDifference(customerInfo)
                    || this.isTelDifference(customerInfo)) {
                    judgeResult = JudgeResultStatus.RESULT_0;
                }
                this.isAddressDifference(customerInfo);
                this.store.registerSignalHandler(CommonBusinessStateSignal.IS_ADDRESS_DIFFERENCE_FLG, (data) => {
                    this.store.unregisterSignalHandler(CommonBusinessStateSignal.IS_ADDRESS_DIFFERENCE_FLG);
                    if (data) {
                        judgeResult = JudgeResultStatus.RESULT_0;
                    }
                    this.nextChatByJudge(entity, pageIndex, judgeResult);
                });
                break;
            }
        }
    }

    @Renderer(CommonBusinessRendererType.NAME_AGGREGATION)
    private onNameAggregationInquiry(entity: ChatFlowMessageInterface, pageIndex: number) {
        const customerIdList = this.state.submitData.customerId;
        const maxCnt = customerIdList.length;

        this.store.registerSignalHandler(CommonBusinessStateSignal.GET_NAME_AGGREGATION_INQUIRY, () => {
            this.store.unregisterSignalHandler(CommonBusinessStateSignal.GET_NAME_AGGREGATION_INQUIRY);

            // 画面表示データ作成
            this.processData(this.state.submitData.allSelectedCifInfo);
            this.action.setSubmitData({
                key: 'existingAccount',
                value: this.state.data.ancestorDuplicateAccountForAllCif
            });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });

        customerIdList.forEach((customerId) => {
            const param = {
                tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                params: {
                    receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                    customerId: customerId, // 全店顧客番号
                }
            };
            this.action.nameAggregationInquiry(param, maxCnt);
        });
    }

    @Renderer(CommonBusinessRendererType.CHANGE_ITEM_LIST)
    private onChangeItemList(entity: ChatFlowMessageInterface, pageIndex: number): void {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    /**
     * typeがjudgeの際に、分岐して次のチャットを開始させる
     *
     * @param entity
     * @param pageIndex
     * @param judgeResult
     */
    private nextChatByJudge(entity: ChatFlowMessageInterface, pageIndex: number, judgeResult: string) {
        entity.choices.forEach((choice) => {
            if (choice.value === judgeResult) {
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
                return;
            }
        });
    }

    private processData(sortedList: any) {
        this.state.data.ancestorDuplicateAccountForAllCif = [];
        this.action.setSubmitData({
            key: 'allCifInfos',
            value: []
        });
        sortedList.forEach((cifInfoList) => {
            let customerId = '';
            cifInfoList.forEach((cifInfo) => {
                if (customerId === '') {
                    this.state.submitData.customerId.forEach((cid) => {
                        if (cid === cifInfo.customerId) {
                            customerId = cifInfo.customerId;
                        }
                    });
                }
            });

            cifInfoList.forEach((cifInfo) => {
                const sameOwner = this.state.data.existing.find((account) => account.customerId === customerId);

                const dupicateAccount: AncestorDuplicateAccount = {
                    branchNo : cifInfo.customerManagementBranchCode,
                    branchName : cifInfo.customerManagementBranchName,
                    customerId : cifInfo.customerId,
                    nameKana : cifInfo.kanaName,
                    nameKanji : cifInfo.kanjiNameInfo.kanjiName,
                    nameNonConvert : cifInfo.kanjiNameInfo.unconvertibleCharStatus,
                    birthdate : cifInfo.birthDate,
                    zipCode : cifInfo.addressInfo.postCode,
                    address : cifInfo.addressInfo.kanjiAddress,
                    addressNonConvert : cifInfo.addressInfo.unconvertibleCharStatus,
                    holderTelNo1 : cifInfo.phoneNo1,
                    holderTelNo2 : cifInfo.phoneNo2,
                    holderTelNo3 : cifInfo.phoneNo3,
                    bankCardHoldingStatus: sameOwner.bankCardHoldingStatus,
                    compoundAccountFlag: null,
                    accountHoldingFlag: sameOwner.accountHoldingFlag,
                    attributeMismatchFlag: sameOwner.attributeMismatchFlag,
                    nationalityCode : cifInfo.nationality,
                    accountInfos: [],
                    unacceptables: [],
                    inheritCustomerStatus: '0',
                    status: '0',
                    identificationCode: cifInfo.identificationCode,
                    unacceptableCodeInfo: [],
                    dispUnacceptableCodeInfo: []
                };
                const alreadyPushedAccount = this.state.data.ancestorDuplicateAccountForAllCif.find(
                    (account) => account.customerId === cifInfo.customerId);
                if (alreadyPushedAccount === undefined) {
                    this.state.data.ancestorDuplicateAccountForAllCif.push(dupicateAccount);
                    this.state.submitData.allCifInfos.push(cifInfo);
                }
            });
        });
    }

    private makeParam(inputCustomerInfo: any) {
        const accounts = [];
        this.state.submitData.existingAccount.forEach((cifInfo) => {
            accounts.push({
                customerId: cifInfo.customerId
            });
        });

        const businessCode = inputCustomerInfo.accountType === AccountType.ORDINARY_DEPOSIT && inputCustomerInfo.applyBizCategory === '01' ?
            BussinessCode.DUPLICATE_ACCOUNT_JAPAN : BussinessCode.DUPLICATE_ACCOUNT_FOREIGNER;

        const acceptCheckApiParams = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                accounts: accounts,
                businessCode: businessCode,
            }
        };
        return acceptCheckApiParams;
    }

    private isNameDifference(inputCustomerInfo: any): boolean {
        // 差分チェックメソッドに渡すパラメータ生成
        let hasNameChangeTarget: boolean;
        hasNameChangeTarget = false;
        const nationalityCode = inputCustomerInfo.accountType === AccountType.ORDINARY_DEPOSIT
            && inputCustomerInfo.applyBizCategory === '01' ? CountryCode.Japan : '';

        const data = {
            customerId: inputCustomerInfo.customerId,
            nationalityCode: nationalityCode,
            nameKanji: inputCustomerInfo.holderName,
            nameKana: inputCustomerInfo.holderNameFurikana,
            nameAlphabet: inputCustomerInfo.nameAlphabet
        };
        const changeCifInfos: ChangeDifferenceEntity[] = this.changeUtils.getNameDifInfo(this.state.submitData.allCifInfos, data);
        this.action.setSubmitData({
            key: 'nameDifferenceInfos',
            value: changeCifInfos
        });
        changeCifInfos.forEach((element) => {
            if (element.isDifference) {
                hasNameChangeTarget = true;
            }
        });
        return hasNameChangeTarget;
    }

    private isAddressDifference(inputCustomerInfo: any) {
        let hasAddressChangeTarget: boolean;
        hasAddressChangeTarget = false;
        const requestParams = {
            postCode: inputCustomerInfo.holderZipCode.substring(0, 3) + inputCustomerInfo.holderZipCode.substring(4),
            prefectureKana: inputCustomerInfo.holderAddressPrefectureFuriKana,
            countyUrbanVillageKana: inputCustomerInfo.holderAddressCountyUrbanVillageFuriKana,
            streetKana: inputCustomerInfo.holderAddressStreetNameFuriKanaSelect ||
                        inputCustomerInfo.holderAddressStreetNameFuriKanaInput || ''
        };
        this.action.getAddressCode(requestParams);
        this.store.registerSignalHandler(CommonBusinessStateSignal.GET_ADDRESS_CODE, () => {
            this.store.unregisterSignalHandler(CommonBusinessStateSignal.GET_ADDRESS_CODE);
            const changeCifInfos: ChangeDifferenceEntity[] = this.changeUtils.getAddressDifInfo(
                this.state.submitData.allCifInfos, inputCustomerInfo.customerId,
                this.state.data.account.holderAddressCode, inputCustomerInfo.holderAddressHouseNumberFuriKana);
            this.action.setSubmitData({
                key: 'addressDifferenceInfos',
                value: changeCifInfos
            });
            changeCifInfos.forEach((element) => {
                if (element.isDifference) {
                    hasAddressChangeTarget = true;
                    return;
                }
            });
            this.store.sendSignal(CommonBusinessStateSignal.IS_ADDRESS_DIFFERENCE_FLG, hasAddressChangeTarget);
        });
    }

    private isTelDifference(inputCustomerInfo: any): boolean {
        let hasTelChangeTarget: boolean;
        hasTelChangeTarget = false;
        const changeCifInfos: ChangeDifferenceEntity[] = this.changeUtils.getTelDiffInfo(
            this.state.submitData.allCifInfos, inputCustomerInfo.customerId,
            this.makeHolderTelList(inputCustomerInfo.holderMobileNo, inputCustomerInfo.holderTelephoneNo));
        this.action.setSubmitData({
            key: 'telDifferenceInfos',
            value: changeCifInfos
        });
        changeCifInfos.forEach((element) => {
            if (element.isDifference) {
                hasTelChangeTarget = true;
            }
        });
        return hasTelChangeTarget;
    }

    private makeHolderTelList(telNo1: string, telNo2: string, telNo3?: string) {
        const holderTelList = [];
        if (telNo1) {
            holderTelList.push(telNo1);
        }
        if (telNo2) {
            holderTelList.push(telNo2);
        }
        if (telNo3) {
            holderTelList.push(telNo3);
        }
        return holderTelList;
    }

    private hasOrdinaryDepositAccountCheck(entity: ChatFlowMessageInterface, pageIndex: number) {
        // 普通預金口座を保有するCIFが1件以上存在する、離脱
        let judgeResult = JudgeResultStatus.RESULT_1;
        this.store.registerSignalHandler(CommonBusinessStateSignal.GET_MEDIUM_INFO, () => {
            this.store.unregisterSignalHandler(CommonBusinessStateSignal.GET_MEDIUM_INFO);
            if (this.state.submitData.mediumInfos && this.state.submitData.mediumInfos.mediumInfo) {
                hasOrdinaryDepositAccount:
                for (const mediumInfo of this.state.submitData.mediumInfos.mediumInfo) {
                    if (mediumInfo.accountInfo) {
                        for (const accountInfo of mediumInfo.accountInfo) {
                            if (accountInfo.productCode === ProductCode.OrdinaryDeposit) {
                                judgeResult = JudgeResultStatus.RESULT_0;
                                break hasOrdinaryDepositAccount;
                            }
                        }
                    }
                }
            }
            this.nextChatByJudge(entity, pageIndex, judgeResult);
        });
        // APIの入力パラメータ設置
        const param = new MediumInfosRequest(
            Number(this.loginState.tabletApplyId),
            this.loginState.belongToBranchNo,
            this.state.submitData.allCifInfos
        );
        this.action.getMediumInfo(param);
    }

    /**
     * 全店名寄せ照会APIの顧客リスト内で顧客管理店番号が重複するCIFが二件以上あるか判定
     */
    private doubleCifJudge(): boolean {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((cifInfo) => {
            accounts.push(cifInfo.customerManagementBranchCode);
        });
        const list = new Set(accounts);
        return accounts.length !== list.size;
    }

    /**
     * エラーモーダルを表示する
     */
    private showErrorModal(errorCode: string, callback?: any) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            this.labelService.labels.common.error.host.support,
            errorCode, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }

    private getAcceptCheckResult(sendAccount: CifInfo[], res: AcceptionResult)
        : Array<{ customerId: string, accounts: AcceptionResultAccount }> {
        // 受付可否チェック（住変氏名）では顧客番号が返却されないため、送信した順番で顧客番号と対応させる
        const acceptResult: Array<{ customerId: string, accounts: AcceptionResultAccount }> = [];
        sendAccount.forEach((item, index) => {
            acceptResult.push({ customerId: item.customerId, accounts: res.accounts[index] });
        });
        return acceptResult;
    }

    /**
     * BC受付可否チェックAPI
     * @param {*} params
     */
    private checkAllAcceptionResult(params: AcceptionResult[]) {
        for (const data of params) {
            const errorInfo = this.checkErrorCode(data);
            if (!errorInfo) {
                if (this.getBcHoldingStatus(data) === ReceptionStatus.NO) {
                    return  ReceptionStatus.NO;
                }
            } else {
                    return errorInfo;
            }
        }
        return  ReceptionStatus.YES;
    }

    private checkErrorCode(acceptCheckResult: AcceptionResult) {

        // 受付可否チェックの結果と顧客番号を対応させる
        const acceptionResult: Array<{ customerId: string, accounts: AcceptionResultAccount }>
            = this.getBankCheckResult(this.state.submitData.customerId, acceptCheckResult);
        const errMessageArr: Array<{ customerId: string, message: string }> = [];
        for (const item of acceptionResult) {
            let branchCode: string = '';
            for (const cifInfo of this.state.submitData.allCifInfos) {
                if (item.customerId === cifInfo.customerId && this.changeUtils.isHostError(item.accounts.errorCode)) {
                    branchCode = cifInfo.customerManagementBranchCode;
                    if (item.accounts.unacceptables && item.accounts.unacceptables.length > 0) {
                        // 受付不可情報がある場合、表示メッセージは「エラー理由 ＋ 事故・取引禁止・注意コード」。
                        for (const acceptItem of item.accounts.unacceptables) {
                            errMessageArr.push({
                                customerId: cifInfo.customerId, message: branchCode + COMMON_CONSTANTS.FULL_COLON
                                    + item.accounts.errorCode + COMMON_CONSTANTS.SPACE + acceptItem.unacceptableCode
                            });
                        }
                    } else {
                        // 受付不可情報がない場合、表示メッセージは「エラー理由」のみ。
                        errMessageArr.push({
                            customerId: cifInfo.customerId, message: branchCode
                                + COMMON_CONSTANTS.FULL_COLON + item.accounts.errorCode
                        });
                    }
                }
            }
        }
        const maxArr = UnacceptableCode.UNACCEPTABLE_CODE_MAX; // エラーコード1行に表示する注意コード最大数
        let index = 0;
        let isNeedBr = 1;
        let message: string = '';
        let messageBefore: { customerId: string, message: string } = { customerId: undefined, message: undefined };
        if (errMessageArr.length > 0) {
            for (const err of errMessageArr) {
                if (index === 0) {
                    message = err.message;
                } else if (messageBefore.customerId === err.customerId && maxArr > isNeedBr) {
                    isNeedBr++;
                    message = message + COMMON_CONSTANTS.SLASH + err.message.substring(err.message.length - 3);
                } else {
                    isNeedBr = 1;
                    message = message + COMMON_CONSTANTS.NEW_LINE + err.message;
                }
                index++;
                messageBefore = err;
            }
            return message;
        }

    }

    private getBcHoldingStatus(acceptCheckResult: AcceptionResult): string {
        let result: boolean = false;
        console.log(acceptCheckResult);
        for (const account of acceptCheckResult.accounts) {
            account.tradingConditions.forEach((tradingCondition) => {
                if (tradingCondition.tradingConditionCode === '13') {
                    result = true;
                }
            });
        }
        return result ? ReceptionStatus.NO : ReceptionStatus.YES;
    }

    private getBankCheckResult(sendAccount: any, res: AcceptionResult)
        : Array<{ customerId: string, accounts: AcceptionResultAccount }> {
        // 受付可否チェック（BC申込）では顧客番号が返却されないため、送信した順番で顧客番号と対応させる
        const acceptResult: Array<{ customerId: string, accounts: AcceptionResultAccount }> = [];
        sendAccount.forEach((item, index) => {
            acceptResult.push({ customerId: item, accounts: res.accounts[index] });
        });
        return acceptResult;
    }

    /**
     * 受付可否チェックAPIリクエストに使うパラメータ
     *
     * @private
     * @returns
     * @memberof ExistingAccountChangeRenderer
     */
    private makeAcceptCheckApiParams() {

        const accounts = [];
        this.state.submitData.customerId.forEach((cif) => {
            accounts.push({
                customerId: cif,
            });
        });

        const acceptCheckApiParams = {
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                accounts: accounts,
                businessCode: BusinessCode.BC_COMPLEX_APPLY // クレカ発行(複合)
            }
        };
        return acceptCheckApiParams;
    }
}
