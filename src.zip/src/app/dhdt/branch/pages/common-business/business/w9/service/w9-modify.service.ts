import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services/label.service';

@Injectable()
export class W9ModifyService {
    private labels;

    constructor(labelService: LabelService) {
        this.labels = labelService.labels;
    }

    public get config() {
        const config = new Map();
        // Fatca Status
        config.set(W9ModifyConfigName.FatcaStatus, {
            startOrder: 130,
            endOrder: 130,
            name: 'fatcaStatus',
            currentTitle: this.labels.w9Modify.fatcaStatus,
            pageIndex: 0,
            isCurrentPage: true
        });
        // Name
        config.set(W9ModifyConfigName.NameEnglish, {
            startOrder: 140,
            endOrder: 140,
            name: 'nameEnglish',
            currentTitle: this.labels.w9Modify.nameEnglish,
            pageIndex: 0,
            isCurrentPage: true
        });
        // Address
        config.set(W9ModifyConfigName.Address, {
            startOrder: 150,
            endOrder: 150,
            name: 'addressEnglish',
            currentTitle: this.labels.w9Modify.addressEnglish,
            pageIndex: 0,
            isCurrentPage: true
        });
        // City or town
        config.set(W9ModifyConfigName.City, {
            startOrder: 160,
            endOrder: 160,
            name: 'cityOrTown',
            currentTitle: this.labels.w9Modify.cityOrTown,
            pageIndex: 0,
            isCurrentPage: true
        });
        // State or Province and Zip cod
        config.set(W9ModifyConfigName.Province, {
            startOrder: 165,
            endOrder: 165,
            name: 'province',
            currentTitle: this.labels.w9Modify.province,
            pageIndex: 0,
            isCurrentPage: true
        });
        // Country
        config.set(W9ModifyConfigName.Country, {
            startOrder: 180,
            endOrder: 190,
            name: 'agentCountryEnglish',
            currentTitle: this.labels.w9Modify.agentCountryEnglish,
            pageIndex: 0,
            isCurrentPage: true
        });
        // Social security number
        config.set(W9ModifyConfigName.SocialSecurityNumber, {
            startOrder: 200,
            endOrder: 200,
            name: 'socialSecurityNumber',
            currentTitle: this.labels.w9Modify.socialSecurityNumber,
            pageIndex: 0,
            isCurrentPage: true
        });
        // 署名（宣誓用）
        config.set(W9ModifyConfigName.SignOath, {
            startOrder: 210,
            endOrder: 210,
            name: 'signOath',
            currentTitle: this.labels.w9Modify.signOath,
            pageIndex: 0,
            isCurrentPage: true
        });
        // 署名（同意用）
        config.set(W9ModifyConfigName.SignAgree, {
            startOrder: 230,
            endOrder: 230,
            name: 'signAgree',
            currentTitle: this.labels.w9Modify.signAgree,
            pageIndex: 0,
            isCurrentPage: true
        });

        config.set(W9ModifyConfigName.SignOathAgent, {
            startOrder: 2100,
            endOrder: 2100,
            name: 'signOath',
            currentTitle: this.labels.w9Modify.signOath,
            pageIndex: 0,
            isCurrentPage: true
        });

        config.set(W9ModifyConfigName.SignAgreeAgent, {
            startOrder: 2300,
            endOrder: 2300,
            name: 'signAgree',
            currentTitle: this.labels.w9Modify.signAgree,
            pageIndex: 0,
            isCurrentPage: true
        });

        return config;
    }

    public get mapping() {
        return {
            nameEnglish: 'w9NameAlphabet',
            addressEnglish: 'w9AddressAlphabet',
            cityOrTown: 'w9CityNameAlphabet',
            province: 'w9PrefecturesAlphabet',
            agentCountryName: 'w9CountryNameAlphabet',
            socialSecurityNumber: 'w9SocialSecurityNo',
            signAgree: 'signatureAgree',
            signOath: 'signatureOath',
        };
    }
}

export enum W9ModifyConfigName {
    FatcaStatus = 'fatcaStatus',
    NameEnglish = 'nameEnglish',
    Address = 'addressEnglish',
    City = 'cityOrTown',
    Province = 'province',
    Country = 'agentCountryEnglish',
    SocialSecurityNumber = 'socialSecurityNumber',
    SignAgree = 'signAgree',
    SignOath = 'signOath',
    SignAgreeAgent = 'signAgreeAgent',
    SignOathAgent = 'signOathAgent'
}
