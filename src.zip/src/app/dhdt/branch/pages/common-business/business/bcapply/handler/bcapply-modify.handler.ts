import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { CommonBusinessRendererType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * バンクカードの申し込むかどうかの修正ダイアログの対応handle
 *
 * @export
 * @class
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class BcApplyModifyHandler extends DefaultChatFlowInputHandler {

    constructor(
        private action: CommonBusinessAction,
        private modalService: ModalService
    ) {
        super(action);
    }

    @InputHandler(CommonBusinessRendererType.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({
            text: answer.text,
            value: [
                { key: entity.name, value: answer.value }
            ]
        });
        this.emitMessageRetrivalEvent(answer.next, pageIndex);
    }
 }
