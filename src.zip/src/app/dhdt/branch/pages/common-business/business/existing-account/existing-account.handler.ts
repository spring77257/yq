import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { ScreenTransition } from 'dhdt/branch/pages/common-business/common-business-consts';
import { CommonBusinessRendererType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessState, CommonBusinessStore } from 'dhdt/branch/pages/common-business/store/common-business.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { AudioService } from 'dhdt/branch/shared/services/audio.service';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * `DefaultChatFlowInputHandler`において、自動振込解約画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class ExistingAccountInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class ExistingAccountInputHandler extends DefaultChatFlowInputHandler {
    private state: CommonBusinessState;

    constructor(
        private action: CommonBusinessAction,
        private store: CommonBusinessStore
    ) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(CommonBusinessRendererType.EXISTING_ACCOUNT)
    private onExistingAccount(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {

        // 上記以外を選択する場合、行員認証画面に戻る
        if (answer.value === 'reset') {
            this.setAnswer({
                text: answer.text,
                value: [{ key: 'existingAccount', value: answer.value }]
            });
            this.action.clearReceptionCheckResult();
            this.chatFlowCompelete();
        } else {
            let answerDisplay = '';
            answer.value.forEach((customerId) => {
                this.state.data.existing.forEach((data) => {
                    if (customerId === data.customerId) {
                        answerDisplay = answerDisplay + data.branchNo + COMMON_CONSTANTS.SPACE + data.nameKanji + COMMON_CONSTANTS.NEW_LINE;
                    }
                });
            });

            this.action.setAnswer({
                text: answerDisplay,
                value: [{
                    key: entity.name,
                    value: answer.value
                }]
            });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    @InputHandler(CommonBusinessRendererType.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            this.action.setAnswer({
                text: answer.text,
                value: [
                    { key: entity.name, value: answer.value },
                    { key: answer.name, value: answer.text }
                ]
            });
        }
        if (answer.action.type.length > 0) {
            this.configAction(answer);
        } else if (answer.next !== -1) {
            // 指定したチャットを表示
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        } else if (answer.next === -1) {
            this.chatFlowCompelete();
        }
    }

    private configAction(answer: any) {
        const action = answer.action;
        if (action.type === ScreenTransition.BACK_TO_TOP) {
            this.chatFlowCompelete(action.type);
        }
    }
}
