import { NgModule } from '@angular/core';
import { PassbookModifyHandler } from 'dhdt/branch/pages/common-business/business/passbook/handler/passbook-modify.handler';
import { PassbookModifyRenderer } from 'dhdt/branch/pages/common-business/business/passbook/renderer/passbook-modify.renderer';

@NgModule({
    providers: [
        PassbookModifyHandler,
        PassbookModifyRenderer
    ]
})
export class PassbookModifyModule { }
