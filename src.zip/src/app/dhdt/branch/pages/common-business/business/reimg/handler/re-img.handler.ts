import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { CommonBusinessRendererType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * `DefaultChatFlowInputHandler`において、自動振込解約画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class ReImgHandler extends DefaultChatFlowInputHandler {

    constructor(
        private action: CommonBusinessAction,
        private modalService: ModalService
    ) {
        super(action);
    }

    @InputHandler(CommonBusinessRendererType.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            if (entity.name === 'addIdentityDocumentImg' && answer.value === '1') {
                this.action.revertLastNode();
            } else {
                this.setAnswer({
                    text: answer.text,
                    value: [
                        { key: entity.name, value: answer.value },
                        { key: answer.name, value: answer.value }
                    ]
                });
            }
        }
        this.emitMessageRetrivalEvent(answer.next, pageIndex);
    }

    @InputHandler(CommonBusinessRendererType.CAMERA_BUTTON)
    private onCameraButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === 'skip') {
            this.setAnswer({
                text: 'スキップ',
                value: undefined
            });

            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        } else {
            if (answer.image) {
                this.action.setSubmitData({
                    key: 'identityDocument',
                    value: answer.image
                });
            }

            if (answer.chatFlowChoice.next !== -1) {
                this.emitMessageRetrivalEvent(answer.chatFlowChoice.next, pageIndex);
            }
        }
    }
 }
