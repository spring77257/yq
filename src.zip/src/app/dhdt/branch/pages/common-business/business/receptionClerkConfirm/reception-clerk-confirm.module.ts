import { NgModule } from '@angular/core';
import { ReceptionClerkConfirmHandler } from './handler/reception-clerk-confirm.handler';
import { ReceptionClerkConfirmRenderer } from './renderer/reception-clerk-confrim.renderer';

@NgModule({
    providers: [
        ReceptionClerkConfirmHandler,
        ReceptionClerkConfirmRenderer
    ]
})
export class ReceptionClerkConfirmModule { }
