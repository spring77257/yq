import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import {
    CommonBusinessRenderer, CommonBusinessRendererType, CommonBusinessType
} from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessState, CommonBusinessStore } from 'dhdt/branch/pages/common-business/store/common-business.store';
import { ButtonCameraComponent } from 'dhdt/branch/shared/components/button-group/button-camera.component';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { ReImgHandler } from '../handler/re-img.handler';

export const RE_IMG_RENDERER = 'ReImgRenderer';

/**
 * `DefaultChatFlowRenderer`において、自動振込解約画面に利用できるRendererを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferCancelRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: RE_IMG_RENDERER,
    templateYaml: 'chat-flow-def-re-img.yml'
})
@CommonBusinessRenderer({
    name: RE_IMG_RENDERER,
    type: CommonBusinessType.ReImg
})
export class ReImgRenderer extends DefaultChatFlowRenderer {
    public processType: number = -1;
    private state: CommonBusinessState;

    constructor(
        private action: CommonBusinessAction,
        private store: CommonBusinessStore,
        inputHandler: ReImgHandler) {
        super(action, inputHandler);

        this.state = store.getState();
    }

    protected get userAnswers(): any {
        return null;
    }

    @Renderer(CommonBusinessRendererType.CAMERA_BUTTON)
    public onCameraButton(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options: any = {
            saveFrontPhotoKey: 'holderCardImageFront',
            saveBackPhotoKey: 'holderCardImageBack',
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
        };
        // 写真を取ろうする書類の格納変数の値を取得
        const currentImg = this.state.submitData.identityDocument;
        // 書類に写真が存在する場合は、skipを渡す
        if (currentImg && currentImg.length > 0 && entity.skip) {
            options.skip = entity.skip;
        }

        this.emitRenderEvent({
            class: ButtonCameraComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    @Renderer(CommonBusinessRendererType.BUTTON)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    // @Renderer(CommonBusinessRendererType.BUTTON)
    // private onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
    //     const options = {
    //         logInfo: {
    //             screenName: this.state.currentFileInfo.screenId,
    //             yamlId: this.state.currentFileInfo.yamlId,
    //             yamlOrder: entity.order
    //         }
    //     };

    //     this.emitRenderEvent({
    //         class: ButtonGroupComponent,
    //         data: entity.choices,
    //         options: options
    //     }, entity, pageIndex);
    // }
}
