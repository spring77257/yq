import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import {
    CommonBusinessRenderer, CommonBusinessRendererType, CommonBusinessType
} from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessState, CommonBusinessStore } from 'dhdt/branch/pages/common-business/store/common-business.store';
import { Age, JudgeResultStatus } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { BcApplyModifyHandler } from '../handler/bcapply-modify.handler';

export const BC_APPLY_MODIFY_RENDERER = 'BcApplyModifyRenderer';

/**
 * バンクカードの申し込むかどうかの修正ダイアログの対応render
 *
 * @export
 * @class BcApplyModifyRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: BC_APPLY_MODIFY_RENDERER,
    templateYaml: 'chat-flow-def-principal-agent.yml'
})
@CommonBusinessRenderer({
    name: BC_APPLY_MODIFY_RENDERER,
    type: CommonBusinessType.BcApply
})
export class BcApplyModifyRenderer extends DefaultChatFlowRenderer {
    public processType: number = -1;
    private state: CommonBusinessState;

    constructor(
        private action: CommonBusinessAction,
        private store: CommonBusinessStore,
        inputHandler: BcApplyModifyHandler) {
        super(action, inputHandler);

        this.state = store.getState();
    }

    protected get userAnswers(): any {
        return null;
    }

    @Renderer(CommonBusinessRendererType.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.JUDGE)
    private onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        let judgeResult: string;
        switch (entity.name) {
            // 満18歳判定
            case 'is18YearsOld': {
                judgeResult = InputUtils.calculateAge(this.state.birthdate) === Age.Age_18 ?
                    JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            default:
                break;
        }
    }
    /**
     * typeがjudgeの際に、分岐して次のチャットを開始させる
     *
     * @param entity
     * @param pageIndex
     * @param judgeResult
     */
    private nextChatByJudge(entity: ChatFlowMessageInterface, pageIndex: number, judgeResult: string) {
        entity.choices.forEach((choice) => {
            if (choice.value === judgeResult) {
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
                return;
            }
        });
    }
}
