export * from './ancestor-duplicate-account/inherit-ancestor-duplicate-account.handler';
export * from './ancestor-duplicate-account/inherit-ancestor-duplicate-account.renderer';
