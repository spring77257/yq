import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { CommonBusinessRendererType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';

/**
 * `DefaultChatFlowInputHandler`において、自動振込解約画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class PassbookModifyHandler extends DefaultChatFlowInputHandler {

    constructor(
        private action: CommonBusinessAction,
        private modalService: ModalService
    ) {
        super(action);
    }

    @InputHandler(CommonBusinessRendererType.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name.length > 0 && answer.value.length > 0) {
            if (!answer.action ||
                (answer.action.value !== 'noticeButtonModal' &&
                answer.action.type !== COMMON_CONSTANTS.ACTION_TYPE_MODAL)) {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            { key: entity.name, value: answer.value }
                        ]
                    });
            }
        }

        if (answer.action.type.length > 0) {
            this.configAction(answer, pageIndex);
        } else {
            this.emitMessageRetrivalEvent(answer.next, pageIndex);
        }
    }

    private configAction(choice: any, pageIndex: number) {
        const action = choice.action;
        if (action.type === 'modal') {
            this.modalService.showModal(
                action.value,
                { imgSrc: COMMON_CONSTANTS.REGULATIONS_KOUZA_TOKUCHOU },
                () => {
                    this.action.resetLastNode();
                });
        }
    }
 }
