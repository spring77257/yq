import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services/label.service';
import {
    BcStatus, Constants as ConstantsChange, DoubleBcStatus, DoubleOsStatus, IcStatus, McStatus, OsStatus
} from 'dhdt/branch/pages/change/change-consts';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import {
    CommonBusinessRenderer, CommonBusinessRendererType, CommonBusinessType
} from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import {
    CommonBusinessState, CommonBusinessStateSignal,
    CommonBusinessStore
} from 'dhdt/branch/pages/common-business/store/common-business.store';
import {
    AgentInternalError, AntiSocietyAnswer, BusinessCode, COMMON_CONSTANTS, ContractCategory, CountryCode,
    HasLoanAccountHoldingDetails, JudgeResultStatus, MediumCardTypes, ProductCode
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { MediumInfosRequest } from 'dhdt/branch/pages/common/entity/medium-infos-request.entity';
import { MediumInfosResponse } from 'dhdt/branch/pages/common/entity/medium-infos-response.entity';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { AncestorDuplicateAccount } from 'dhdt/branch/pages/inherit/entity/ancestor-duplicate-account.entity';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { ExistingAccountTableComponent } from 'dhdt/branch/shared/components/existing-account-table/existing-account-table.component';
import { SelectTenpoComponent } from 'dhdt/branch/shared/components/reception-select-tenpo/select-tenpo.component';
import { ReceptionCardTenpoEntity } from 'dhdt/branch/shared/entity/reception-card-tenpo.entity';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { NameBasedAggregationService } from 'dhdt/branch/shared/services/name-based-aggregation.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { ErrorUtils } from 'dhdt/branch/shared/utils/error-utils';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { ReceptionClerkConfirmHandler } from '../handler/reception-clerk-confirm.handler';

export const RECEPTION_CLERK_CONFIRM_RENDERER = 'ReceptionClerkConfirmRenderer';

/**
 * 受付チャット行員認証
 *
 * @export
 * @class AutomaticTransferCancelRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: RECEPTION_CLERK_CONFIRM_RENDERER,
    templateYaml: 'chat-flow-def-reception-self-checkapply.yml'
})
@CommonBusinessRenderer({
    name: RECEPTION_CLERK_CONFIRM_RENDERER,
    type: CommonBusinessType.ReceptionClerkConfirm
})
export class ReceptionClerkConfirmRenderer extends DefaultChatFlowRenderer {
    public processType: number = -1;
    private state: CommonBusinessState;

    constructor(
        private action: CommonBusinessAction,
        private store: CommonBusinessStore,
        private loginStore: LoginStore,
        inputHandler: ReceptionClerkConfirmHandler,
        private modalService: ModalService,
        private labelService: LabelService,
        private nameBasedServce: NameBasedAggregationService,
        private changeUtils: ChangeUtils) {
        super(action, inputHandler);

        this.state = store.getState();
    }

    protected get userAnswers(): any {
        return null;
    }

    @Renderer(CommonBusinessRendererType.SELECT_TENPO)
    public onSelectTenpo(entity: any, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        this.emitRenderEvent({
            class: SelectTenpoComponent,
            data: this.state.submitData.swapableTenpoInfo,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.CHAT_CARD)
    public onChatCard(entity: any, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.RECEPTION_CHANGE_CONTENT)
    public onReceptionChangeContent(entity: any, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.SAVE_SUBMIT)
    public onSaveSubmit(entity: ChatFlowMessageInterface, pageIndex: number): void {
        switch (entity.name) {
            // 全店名寄せ結果には科目コード１２の口座あるかどうかチェック
            case 'isHaveSubjectCode12': {
                const result = this.nameBasedServce.isHaveOridinarySubjectCode(this.state.submitData.allCifInfos);

                this.action.setSubmitData({
                    key: entity.name,
                    value: result ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0
                });
                break;
            }
            case 'isHaveCifInOpenTenban': {
                // 全店名寄せの中に、口座開設店舗に所属CIFあるかどうかを探す
                // 存在する場合は、
                // submitData.customerIdに該当CIFのcidを入れる
                // submitData.indentificationCodeに該当CIFの本人確認コードを入れる
                let openAccountCid;
                let openAccountIdentiCode;
                const result: boolean = this.state.submitData.allCifInfos.some(
                    (cif: CifInfo) => {
                        if (cif.customerManagementBranchCode === this.state.data.tenban) {
                            openAccountCid = cif.customerId;
                            openAccountIdentiCode = cif.identificationCode;
                            return true;
                        }
                    }
                );

                // 口座開設店舗にCIFある場合、CIFのCIDと本人確認コードを設定
                // 口座開設店舗にCIFない場合、undefinedを設定
                this.action.setSubmitData({
                    key: 'customerId',
                    value: openAccountCid
                });
                // 口座開設CIFの顧客番号と本人確認コード
                this.action.setSubmitData({
                    key: 'openAccountCid',
                    value: openAccountCid
                });
                this.action.setSubmitData({
                    key: 'openAccountIdentiCode',
                    value: openAccountIdentiCode
                });

                // 口座開設店舗にCIFある場合 '1'を設定、ない場合は'0'を設定
                this.action.setSubmitData({
                    key: entity.name,
                    value: result ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0
                });

                break;
            }
            case 'isNameAddressTelDiff': {
                const requestParams = {
                    postCode: this.state.data.firstZipCode + this.state.data.lastZipCode,
                    prefectureKana: this.state.data.holderAddressPrefectureFuriKana,
                    countyUrbanVillageKana: this.state.data.holderAddressCountyUrbanVillageFuriKana,
                    streetKana: this.state.data.holderAddressStreetNameFuriKanaSelect || ''
                };

                this.store.registerSignalHandler(CommonBusinessStateSignal.GET_ADDRESS_CODE, () => {
                    this.store.unregisterSignalHandler(CommonBusinessStateSignal.GET_ADDRESS_CODE);

                    // PID配下の各CIFに対して、入力住所と差分あるかどうかを記録
                    const allCifAddressDif = this.changeUtils.getAddressDifInfo(
                        this.state.submitData.allCifInfos,
                        '',
                        this.state.data.holderAddressCode,
                        this.state.data.holderAddressHouseNumberFuriKana);

                    // PID配下の各CIFに対して、入力電話番号と差分あるかどうかを記録
                    const tels = [];
                    if (this.state.data.holderMobileNo) {
                        tels.push(this.state.data.holderMobileNo);
                    }
                    if (this.state.data.holderTelephoneNo) {
                        tels.push(this.state.data.holderTelephoneNo);
                    }
                    const allCifTelDif = this.changeUtils.getTelDiffInfo(
                        this.state.submitData.allCifInfos,
                        '',
                        tels
                    );

                    const allCifNameDif = this.changeUtils.getNameDifInfo(
                        this.state.submitData.allCifInfos,
                        {
                            customerId: '',
                            nationalityCode: CountryCode.Japan,
                            nameKanji: this.state.data.firstName + '　' + this.state.data.lastName,
                            nameKana: this.state.data.firstNameKana + '　' + this.state.data.lastNameKana,
                            nameAlphabet: undefined
                        }
                    );

                    const isHaveAddressDif = allCifAddressDif.some(
                        (item) => {
                            return item.isDifference === true;
                        }
                    );
                    const isHaveTelDif = allCifTelDif.some(
                        (item) => {
                            return item.isDifference === true;
                        }
                    );
                    const isHaveNameDif = allCifNameDif.some(
                        (item) => {
                            return item.isDifference === true;
                        }
                    );

                    // 諸届差分ある場合は、isNameAddressTelDiffにフラグを立つ
                    this.action.setSubmitData({
                        key: entity.name,
                        value: (isHaveAddressDif || isHaveTelDif || isHaveNameDif) ? '1' : '0'
                    });

                    // PID配下氏名差分情報
                    this.action.setSubmitData({
                        key: 'allCifNameDif',
                        value: allCifNameDif
                    });
                    // PID配下と氏名差分あるかどうか
                    this.action.setSubmitData({
                        key: 'isHaveNameDif',
                        value: isHaveNameDif ? '1' : '0'
                    });

                    // PID配下住所差分情報
                    this.action.setSubmitData({
                        key: 'allCifAddressDif',
                        value: allCifAddressDif
                    });
                    // PID配下と住所差分あるかどうか
                    this.action.setSubmitData({
                        key: 'isHaveAddressDif',
                        value: isHaveAddressDif ? '1' : '0'
                    });

                    // PID配下電話差分情報
                    this.action.setSubmitData({
                        key: 'allCifTelDif',
                        value: allCifTelDif
                    });
                    // PID配下と電話差分あるかどうか
                    this.action.setSubmitData({
                        key: 'isHaveTelDif',
                        value: isHaveTelDif ? '1' : '0'
                    });
                });

                this.action.getAddressCode(requestParams);

                break;
            }
            // PID配下に保有媒体をチェックして、条件に該当する場合は、フラグを保存する
            case 'ownedMediaCheck': {
                let result = JudgeResultStatus.RESULT_0;
                if (this.state.submitData.mediumInfos.doubleBc === DoubleBcStatus.DOUBLE_BC_STATUS_ON ||
                    this.state.submitData.mediumInfos.doubleOs === DoubleOsStatus.DOUBLE_OS_STATUS_ON) {
                    // 複数CIFにバンクカード、または複数CIFにワンセットカード、または1CIFに複数ワンセットカードがある場合
                    result = JudgeResultStatus.RESULT_1;
                } else {
                    this.state.submitData.mediumInfos.mediumInfo.forEach((mediumElement) => {
                        if (mediumElement.accountInfo) {
                            mediumElement.accountInfo.forEach((account) => {
                                if (account.mcStatus === McStatus.MC_STATUS_ON && account.icStatus === IcStatus.IC_STATUS_ON) {
                                    // 同じ口座にMCとICがある場合
                                    result = JudgeResultStatus.RESULT_1;
                                } else if (account.mcStatus === McStatus.MC_STATUS_ON && account.bcStatus === BcStatus.BC_STATUS_ON) {
                                    // 同じ口座にMCとBCがある場合
                                    result = JudgeResultStatus.RESULT_1;
                                } else if (account.icStatus === IcStatus.IC_STATUS_ON && account.bcStatus === BcStatus.BC_STATUS_ON) {
                                    // 同じ口座にICとBCがある場合
                                    result = JudgeResultStatus.RESULT_1;
                                } else if (account.icStatus === IcStatus.IC_STATUS_ON && account.osStatus === OsStatus.OS_STATUS_ON) {
                                    // 同じ口座にICとワンセットカードがある場合
                                    result = JudgeResultStatus.RESULT_1;
                                } else if (account.mcStatus === McStatus.MC_STATUS_ON && account.osStatus === OsStatus.OS_STATUS_ON) {
                                    // 同じ口座にMCとワンセットカードがある場合
                                    result = JudgeResultStatus.RESULT_1;
                                }
                            });
                        }
                    });
                }

                // 保有媒体チェック結果を保存
                this.action.setSubmitData({
                    key: entity.name,
                    value: result
                });

                break;
            }
            case 'transactionCheck': {
                let result = JudgeResultStatus.RESULT_0;

                // receptionCheckNameDiffResultは氏名変更対象CIFの受付可否チェック結果
                if (this.state.submitData.receptionCheckNameDiffResult) {
                    this.state.submitData.receptionCheckNameDiffResult.forEach((acceptResult) => {
                        // ジュニアNISA対応
                        const cifInfo =
                            this.state.submitData.allCifInfos.filter((item) => item.customerId === acceptResult.customerId);
                        const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(cifInfo[0].birthDate,
                            acceptResult.accounts.tradingConditions);
                        const level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                        if (level.levelOne || isHaveJuniorNisa) {
                            result = JudgeResultStatus.RESULT_1;
                        }
                    });
                }

                // receptionCheckAddressTelDiffResultは住所、電話番号変更対象CIFの受付可否チェック結果
                if (this.state.submitData.receptionCheckAddressTelDiffResult) {
                    this.state.submitData.receptionCheckAddressTelDiffResult.forEach((acceptResult) => {
                        // ジュニアNISA対応
                        const cifInfo =
                            this.state.submitData.allCifInfos.filter((item) => item.customerId === acceptResult.customerId);
                        const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(cifInfo[0].birthDate,
                            acceptResult.accounts.tradingConditions);
                        const level = this.changeUtils.getTransactionLevel(acceptResult.accounts.tradingConditions);
                        if (level.levelOne || isHaveJuniorNisa) {
                            result = JudgeResultStatus.RESULT_1;
                        }
                    });
                }

                // チェック結果を保存
                this.action.setSubmitData({
                    key: entity.name,
                    value: result
                });
                break;
            }
            case 'outCardContent': {
                // 取引ぶり表示内容
                const transactionLevOneContent: string = this.makeTransactionOutContent().join(',');
                // 最新のCIDを表示
                let cid: string = this.nameBasedServce.getLastestOridinaryAccountCid(this.state.submitData.allCifInfos);
                if (!cid) {
                    // 普通預金口座ない場合は、PID配下に一番若いCIDを取得
                    cid = this.nameBasedServce.getLastestCustomerId(this.state.submitData.allCifInfos);
                }
                // 受付のエラーコードを表示
                const errMessage: string = ErrorUtils.getErrorMessage(
                    this.state.submitData.responseForModal,
                    this.state.submitData.allCifInfos
                );

                this.action.setSubmitData(
                    {
                        key: 'outCardContent',
                        value: {
                            title: this.labelService.labels.reception.clerkConfirm.outCardTitle,
                            datas: this.makeCardData(entity.choices, transactionLevOneContent, cid, errMessage)
                        }
                    }
                );

                break;
            }
            // スワイプできるカードを持っている店舗のデータを保存
            case 'swapableTenpoInfo': {
                const mediumInfos: MediumInfosResponse = this.state.submitData.mediumInfos;
                const tenpoInfos: ReceptionCardTenpoEntity[] = [];  // カード持っている店舗一覧

                mediumInfos.mediumInfo.forEach(
                    (medium) => {
                        medium.accountInfo.forEach(
                            (account) => {
                                const tenpoInfo = new ReceptionCardTenpoEntity();
                                tenpoInfo.tenban = account.tenban;
                                tenpoInfo.branchName = account.branchName;
                                tenpoInfo.customerId = medium.customerId;

                                if (account.holdingCardInfo) {
                                    account.holdingCardInfo.forEach(
                                        (card) => {
                                            if (this.isSwipableCard(card.cardType)) {   // スワイプできるカードを持っていれば
                                                // tenpoInfosに存在するかどうかを判定
                                                const isSaved = tenpoInfos.some(
                                                    (info) => {
                                                        return info.tenban === account.tenban;
                                                    }
                                                );
                                                // tenpoInfosに存在しないときに、対象を入れる
                                                if (!isSaved) {
                                                    tenpoInfos.push(tenpoInfo);
                                                }
                                            }
                                        }
                                    );
                                }
                            }
                        );
                    }
                );

                // スワイプできるカードを持っている店舗のデータを保存
                this.action.setSubmitData(
                    {
                        key: entity.name,
                        value: tenpoInfos
                    }
                );

                break;
            }
            // 口座開設店舗にCIFが存在しない場合、PID配下の一番最新のCIFを選択
            case 'latestCifInPid': {
                const customerId = this.nameBasedServce.getLastestCustomerId(this.state.submitData.allCifInfos);
                this.action.setSubmitData(
                    {
                        key: 'customerId',
                        value: customerId
                    }
                );
                // 新規扱いフラグ
                this.action.setSubmitData(
                    {
                        key: 'isNewCustomerFlg',
                        value: true
                    }
                );
                break;
            }
            // 普通預金以外の取引有無あるかどうか
            // このjudgeの実行前提条件は普通預金が存在しません
            case 'isHaveOtherTransaction': {
                let result = JudgeResultStatus.RESULT_0;

                // 国内口座、外貨口座が存在するかどうか
                const isHaveKouza = this.nameBasedServce.isHaveKouza(this.state.submitData.allCifInfos);
                // 融資保有明細が存在するか
                const hasLoanTransaction = this.state.submitData.allCifReceptionCommonCheckResult.accounts.some(
                    (account) => {
                        return account.hasLoanAccountHoldingDetails === HasLoanAccountHoldingDetails.YES;
                    }
                );
                // 取引ぶりに０８、０９、２９、３１が存在するかどうか
                const isHaveTargetTransaction = this.state.submitData.allCifReceptionCommonCheckResult.accounts.some(
                    (item) => {
                        return item.tradingConditions.some(
                            (tradingItem) => {
                                return tradingItem.tradingConditionCode === ConstantsChange.DBConsts.SpecTransactionCode.Investment
                                    || tradingItem.tradingConditionCode === ConstantsChange.DBConsts.SpecTransactionCode.specialDeposit
                                    || tradingItem.tradingConditionCode === ConstantsChange.DBConsts.SpecTransactionCode.goldBullion
                                    || tradingItem.tradingConditionCode === ConstantsChange.DBConsts.SpecTransactionCode.safeDepositBox;
                            }
                        );
                    }
                );

                // 口座あるか、取引ぶりあるかの場合は’１’を設定します
                if (isHaveKouza || hasLoanTransaction || isHaveTargetTransaction) {
                    result = JudgeResultStatus.RESULT_1;
                }

                // 結果を保存
                this.action.setSubmitData(
                    {
                        key: entity.name,
                        value: result
                    }
                );

                break;
            }
            default:
                if (entity.choices) {
                    entity.choices.forEach((item: any) => {
                        this.action.setSubmitData(
                            {
                                key: item.name,
                                value: item.value
                            }
                        );
                    });
                }
                break;
        }

        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    /**
     * ボタンコンポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    @Renderer(CommonBusinessRendererType.BUTTON)
    public onButton(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    /**
     * 店舗リストポネントを表示する
     * @param entity チャットフローエンティティー
     * @param pageIndex ページ番号
     */
    @Renderer(CommonBusinessRendererType.TENPO_LIST)
    public onTenpoList(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            },
            furiganaOnly: null,
            kanaText: null,
            validationRules: null
        };

        this.emitRenderEvent({
            class: SelectTenpoComponent,
            data: this.state.submitData.swapableTenpoInfo,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.EXISTING_ACCOUNT)
    public onExistingAccount(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        // 同一名義人のインターフェースに合わせるために
        const data = {
            ...this.state.data,
            account: {
                nameKanji: this.state.data.firstName + '　' + this.state.data.lastName,
                address: this.state.data.holderAddressPrefecture +
                    this.state.data.holderAddressCountyUrbanVillage +
                    this.state.data.holderAddressStreetNameSelect +
                    this.state.data.holderAddressHouseNumber,
                holderMobileNo: this.state.data.holderMobileNo,
                holderTelephoneNo: this.state.data.holderTelephoneNo
            }
        };

        this.emitRenderEvent({
            class: ExistingAccountTableComponent,
            data: data,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.JUDGE)
    public onJudge(entity: ChatFlowMessageInterface, pageIndex: number): void {
        let judgeResult: string;
        const customerInfo = this.state.data.account;
        switch (entity.name) {
            case 'nationalityCheck': {
                judgeResult = JudgeResultStatus.RESULT_0;
                if (customerInfo.accountType === '1' && customerInfo.isAgent === '0') {
                    judgeResult = JudgeResultStatus.RESULT_1;
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            case 'isDuplicatePid': {
                judgeResult = JudgeResultStatus.RESULT_1;
                const pidList: any = [];
                this.state.submitData.allCifInfos.forEach((cifInfo) => {
                    if (pidList.indexOf(cifInfo.personalId) === -1) {
                        pidList.push(cifInfo.personalId);
                    }
                });
                // PIDが2件以上存在する、離脱
                if (pidList.length > 1) {
                    judgeResult = JudgeResultStatus.RESULT_0;
                }
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }

            case 'primaryAccountCheck': {
                let primaryCount: number = 0;  // 代表口座件数
                let relationCount: number = 0;  // 関連口座件数
                this.state.submitData.allCifInfos.forEach((cifInfo) => {
                    if (cifInfo.domesticAccountInfo) {
                        cifInfo.domesticAccountInfo.forEach((accountInfo) => {
                            if (accountInfo.ibContractInfo && accountInfo.ibContractInfo.contractCategory) {
                                accountInfo.ibContractInfo.contractCategory === ContractCategory.primary ?
                                    primaryCount++ : relationCount++;
                            }
                        });
                    }
                });
                // PID配下口座なし、または代表口座ありの場合、次のチャットへ進む
                if ((primaryCount === 0 && relationCount === 0) || primaryCount > 0) {
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                } else {
                    // 代表口座なしかつ関連口座１件以上の場合、エラーモーダル
                    this.showErrorModal(AgentInternalError.ERROR_CODE_N_007);
                }
                break;
            }

            case 'hasDoubleCif': {
                if (!InputUtils.isTrngEnv()) {
                    // 研修環境以外の場合、二重CIF判定
                    if (this.doubleCifJudge()) {
                        this.showErrorModal(AgentInternalError.ERROR_CODE_N_004);
                    } else {
                        // 上記エラー事由に該当しない場合
                        this.emitMessageRetrivalEvent(entity.next, pageIndex);
                    }
                } else {
                    // 研修環境の場合
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                }
                break;
            }
            case 'isHaveMobile': {
                judgeResult = this.state.data.firstMobileNo ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            case 'isHaveTel': {
                judgeResult = this.state.data.firstTel ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            // 同一名義人が「該当なし」を選択するか、レコードを選択するか
            case 'isExistingAccountSelected': {
                judgeResult = (this.state.submitData.customerId &&
                    this.state.submitData.customerId.length > 0) ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;
                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            case 'hasOrdinaryDepositAccount': {
                this.hasOrdinaryDepositAccountCheck(entity, pageIndex);
                break;
            }
            // 受付チェックBのセット実施結果を判断
            case 'receptionCheckChangeB': {
                judgeResult = JudgeResultStatus.RESULT_0;

                // 氏名受付結果にNGあるかどうか
                const nameCheckFail = this.state.submitData.receptionCheckNameDiffResult ?
                    this.state.submitData.receptionCheckNameDiffResult.some(
                        (accountInfo) => ErrorUtils.isHostError(accountInfo.accounts.errorCode)) :
                    false;
                // 住所、電話番号受付結果にNGあるかどうか
                const addressTelCheckFail = this.state.submitData.receptionCheckAddressTelDiffResult ?
                    this.state.submitData.receptionCheckAddressTelDiffResult.some(
                        (accountInfo) => ErrorUtils.isHostError(accountInfo.accounts.errorCode)) :
                    false;

                // 保有媒体チェック
                const ownedMediaCheck = this.state.submitData.ownedMediaCheck;

                // 取引ぶりチェック、ジュニアNISAチェック
                const transactionCheck = this.state.submitData.transactionCheck;

                if (!this.isHaveNameDiff()) {   // 氏名変更なし
                    if (addressTelCheckFail || transactionCheck === JudgeResultStatus.RESULT_1) {
                        judgeResult = JudgeResultStatus.RESULT_1;
                    }
                }

                if (this.isHaveNameDiff()) {    // 氏名変更あり
                    if (nameCheckFail || addressTelCheckFail || // 氏名受付結果, 住所、電話番号受付結果
                        transactionCheck === JudgeResultStatus.RESULT_1 ||  // 取引ぶりチェック
                        ownedMediaCheck === JudgeResultStatus.RESULT_1) {   // 保有媒体チェック

                        // 保有媒体によって分岐
                        // tslint:disable-next-line:prefer-conditional-expression
                        if (ownedMediaCheck === JudgeResultStatus.RESULT_0) {
                            judgeResult = JudgeResultStatus.RESULT_2;
                        } else {
                            judgeResult = JudgeResultStatus.RESULT_3;
                        }
                    }
                }

                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            // お客さんが持っているカード状況分岐
            // カード持っている口座情報を保存
            case 'isSwipableCard': {
                judgeResult = JudgeResultStatus.RESULT_0;
                const mediumInfos: MediumInfosResponse = this.state.submitData.mediumInfos;

                let isHaveCard = false;
                let isHaveSwipeableCard = false;

                if (mediumInfos.mediumInfo) { // 存在チェック
                    mediumInfos.mediumInfo.forEach(
                        (medium) => {
                            if (medium.accountInfo) { // 存在チェック
                                medium.accountInfo.forEach(
                                    (account) => {
                                        // 存在する場合は、カードあるかどうかをチェック
                                        if (account.holdingCardInfo) {
                                            account.holdingCardInfo.forEach(
                                                (card) => {
                                                    if (card.cardType) {
                                                        isHaveCard = true;
                                                    }
                                                    if (this.isSwipableCard(card.cardType)) {
                                                        isHaveSwipeableCard = true;
                                                    }
                                                }
                                            );
                                        }
                                    }
                                );
                            }
                        }
                    );
                }

                if (isHaveSwipeableCard) {  // Agentでスワイプできるカード
                    judgeResult = JudgeResultStatus.RESULT_0;
                } else if (isHaveCard) { // カード持っているが、スワイプできない
                    judgeResult = JudgeResultStatus.RESULT_1;
                } else { // カードを持っていない
                    judgeResult = JudgeResultStatus.RESULT_2;
                }

                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            // 選択したカード店舗は口座開設店舗と同じかどうか
            case 'isSwipableCardOpeningAcountSame': {
                judgeResult = JudgeResultStatus.RESULT_0;

                // 一致ではないときに、’１’を設定
                if (this.state.submitData.selectTenpoCode !== this.state.data.tenban) {
                    judgeResult = JudgeResultStatus.RESULT_1;
                }

                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            // 旧姓あるかどうかを判断
            case 'isHaveOldName': {
                // 旧姓なし 0、　旧姓あり　１
                judgeResult = this.state.data.firstNameKanaOld ? JudgeResultStatus.RESULT_1 : JudgeResultStatus.RESULT_0;

                this.nextChatByJudge(entity, pageIndex, judgeResult);
                break;
            }
            default:
                const choice = entity.choices.find((item) => {
                    return item.value === this.state.submitData[entity.name];
                });
                this.emitMessageRetrivalEvent(choice ? choice.next : entity.next, pageIndex);

                break;
        }
    }

    @Renderer(CommonBusinessRendererType.REQUEST)
    public onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        switch (entity.name) {
            case 'receptionCheckCommon': // 受付可否チェック【業務共通NGチェック】
                this.applyCheck(entity, pageIndex, BusinessCode.COMMON_NG);
                break;
            case 'receptionCheckAccountOpen': // 受付可否チェック【口座開設チェック】
                this.receptionCheck(entity, pageIndex, BusinessCode.SAVING_ACCOUNT);
                break;
            case 'receptionCheckNameDiff': // 受付可否チェック【諸届チェック氏名】
                this.receptionCheckChangeDiffName(entity, pageIndex);
                break;
            case 'receptionCheckAddressTelDiff': // 受付可否チェック【諸届チェック住所、電話※氏名実施対象が対象外】
                this.receptionCheckChangeDiffAddressTel(entity, pageIndex);
                break;
            case 'receptionCheckCardSwipableTenpo': // 受付可否チェック【選択した店舗のCIFに対して、カード認証実施 00】
                this.receptionCheckCardSwipableTenpo(entity, pageIndex, BusinessCode.COMMON);
                break;
            case 'receptionCheckOpeningSwipableTenpo': // 受付可否チェック【選択した店舗のCIFに対して、カード認証実施 00】
                this.receptionCheckOpeningSwipableTenpo(entity, pageIndex, BusinessCode.SAVING_ACCOUNT);
                break;
            case 'mediumInfo': // 保有媒体取得
                this.getMediumInfo(entity, pageIndex);
                break;

            default:
                break;
        }
    }

    @Renderer(CommonBusinessRendererType.NAME_AGGREGATION)
    private onNameAggregationInquiry(entity: ChatFlowMessageInterface, pageIndex: number) {
        const customerIdList = this.state.submitData.customerId;
        const maxCnt = customerIdList.length;

        this.store.registerSignalHandler(CommonBusinessStateSignal.GET_NAME_AGGREGATION_INQUIRY, () => {
            this.store.unregisterSignalHandler(CommonBusinessStateSignal.GET_NAME_AGGREGATION_INQUIRY);

            // 画面表示データ作成
            this.processData(this.state.submitData.allSelectedCifInfo);
            this.action.setSubmitData({
                key: 'existingAccount',
                value: this.state.data.ancestorDuplicateAccountForAllCif
            });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });

        customerIdList.forEach((customerId) => {
            const param = {
                tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                params: {
                    receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                    customerId: customerId, // 全店顧客番号
                }
            };
            this.action.nameAggregationInquiry(param, maxCnt);
        });
    }

    /**
     * 受付可否チェック（口座開設認証チェック 01）を実行し、結果保存の上チェックOK/NGより次処理を行う。
     * 業務コードは呼び出し元にて設定する。
     *
     * @private
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     */
    private receptionCheckOpeningSwipableTenpo(entity, pageIndex, businessCode: string) {
        this.registerReceptionLossCorruptionCheckModalHandle(entity, pageIndex);

        // 選択したカード所属店舗のCIDを取得
        const selectedTenpoCif = this.state.submitData.allCifInfos.find(
            (cifInfo: CifInfo) => {
                return cifInfo.customerManagementBranchCode === this.state.submitData.selectTenpoCode;
            }
        );

        // 受付可否チェック（喪失・破損）を実行(実行結果をPID以下の全CIFに対してのチェックとして保存する)
        this.action.receptionCheckApiWithErrorModal({
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                // PID以下全CIFを対象とする
                accounts: [
                    {
                        tenban: null,
                        accountType: null,
                        accountNo: null,
                        customerId: selectedTenpoCif.customerId
                    }
                ],
                // 業務コード
                businessCode: businessCode
            }
        });
    }

    /**
     * 受付可否チェック（カード認証チェック 00）を実行し、結果保存の上チェックOK/NGより次処理を行う。
     * 業務コードは呼び出し元にて設定する。
     *
     * @private
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     */
    private receptionCheckCardSwipableTenpo(entity, pageIndex, businessCode: string) {
        this.registerReceptionLossCorruptionCheckModalHandle(entity, pageIndex);

        // 選択したカード所属店舗のCIDを取得
        const selectedTenpoCif = this.state.submitData.allCifInfos.find(
            (cifInfo: CifInfo) => {
                return cifInfo.customerManagementBranchCode === this.state.submitData.selectTenpoCode;
            }
        );

        // 受付可否チェック（喪失・破損）を実行(実行結果をPID以下の全CIFに対してのチェックとして保存する)
        this.action.receptionCheckApiWithErrorModal({
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                // PID以下全CIFを対象とする
                accounts: [
                    {
                        tenban: null,
                        accountType: null,
                        accountNo: null,
                        customerId: selectedTenpoCif.customerId
                    }
                ],
                // 業務コード
                businessCode: businessCode
            }
        });
    }
    /**
     * 受付可否チェック（業務共通NGチェック）を実行し、結果保存の上チェックOK/NGより次処理を行う。
     * 業務コードは呼び出し元にて設定する。
     *
     * @private
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     */
    private applyCheck(entity, pageIndex, businessCode: string) {
        this.registerReceptionLossCorruptionCheckModalHandle(entity, pageIndex);

        // 受付可否チェック（喪失・破損）を実行(実行結果をPID以下の全CIFに対してのチェックとして保存する)
        this.action.receptionCheckApiWithErrorModal({
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                // PID以下全CIFを対象とする
                accounts: this.state.submitData.allCifInfos.map((cifInfo: CifInfo) => {
                    // 顧客番号をキーに受付可否チェックを行う
                    return {
                        tenban: null,
                        accountType: null,
                        accountNo: null,
                        customerId: cifInfo.customerId
                    };
                }),
                // 業務コード
                businessCode: businessCode
            }
        }, 'allCifReceptionCommonCheckResult');
    }

    /**
     * 受付可否チェック【口座開設チェック(01)】を実行する。
     * 業務コードは呼び出し元にて設定する。
     *
     * @private
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     */
    private receptionCheck(entity, pageIndex: number, businessCode: string) {

        this.registerReceptionLossCorruptionCheckModalHandle(entity, pageIndex);

        // 受付可否チェック（喪失・破損）を実行(実行結果をPID以下の全CIFに対してのチェックとして保存する)
        this.action.receptionCheckApiWithErrorModal({
            tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                // PID以下全CIFを対象とする
                accounts: this.state.submitData.allCifInfos.map((cifInfo: CifInfo) => {
                    // 顧客番号をキーに受付可否チェックを行う
                    return {
                        tenban: null,
                        accountType: null,
                        accountNo: null,
                        customerId: cifInfo.customerId
                    };
                }),
                // 業務コード
                businessCode: businessCode
            }
        });
    }

    /**
     * PID配下に氏名差分あるCIFに対して、氏名変更受付チェックを実施
     *
     * @private
     * @param {*} entity
     * @param {number} pageIndex
     * @memberof ReceptionClerkConfirmRenderer
     */
    private receptionCheckChangeDiffName(entity, pageIndex: number) {
        // PID配下に氏名変更ありCIFのCIDを洗い出す
        const nameDiffCids = this.makeNameDiffCidParams();
        // パラメータ作成
        const accounts = nameDiffCids.map(
            (item) => {
                return {
                    tenban: null,
                    accountType: null,
                    accountNo: null,
                    customerId: item
                };
            }
        );

        if (accounts.length > 0) {
            // 受付可否チェック（諸届名前は１９）を実行
            this.registerReceptionCheckModalHandle(entity, pageIndex, false);

            this.action.receptionChangeCheckApiWithErrorModal(
                {
                    tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
                    params: {
                        receptionTenban: this.loginStore.getState().belongToBranchNo,
                        accounts: accounts,
                        // 業務コード
                        businessCode: BusinessCode.NAME_MENU_CHANGE.toString()
                    }
                },
                'receptionCheckNameDiffResult'
            );
        } else {
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    private receptionCheckChangeDiffAddressTel(entity, pageIndex: number) {
        // 受付可否チェック（諸届住所、電話番号24）を実行
        // 氏名変更Cids
        const nameDiffCids = this.makeNameDiffCidParams();
        // 住所、電話変更Cids
        const addressTelDiffCids = this.makeAddressTelDiffCidParams();

        // 前で氏名変更チェック実施ずみCidsはもう実施しないようにする
        const accountsParams = [];
        addressTelDiffCids.forEach(
            (cid) => {
                if (nameDiffCids.indexOf(cid) === -1) {
                    accountsParams.push(
                        {
                            tenban: null,
                            accountType: null,
                            accountNo: null,
                            customerId: cid
                        }
                    );
                }
            }
        );

        // 受付チェック対象が存在しないときに、何もしない
        if (accountsParams.length > 0) {
            this.registerReceptionCheckModalHandle(entity, pageIndex, false);

            this.action.receptionChangeCheckApiWithErrorModal(
                {
                    tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
                    params: {
                        receptionTenban: this.loginStore.getState().belongToBranchNo,
                        accounts: accountsParams,
                        // 業務コード
                        businessCode: BusinessCode.ADDRESS_TEL_MENU_CHANGE.toString()
                    }
                },
                'receptionCheckAddressTelDiffResult'
            );
        } else {
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        }
    }

    /**
     * PID配下のCIFに氏名変更ありのCIDを取得
     *
     * @private
     * @return {*}  {any[]}
     * @memberof ReceptionClerkConfirmRenderer
     */
    private makeNameDiffCidParams(): any[] {
        let result: string[] = [];
        // 氏名変更あり対象
        const nameDiffItems = this.state.submitData.allCifNameDif.filter(
            (item) => {
                return item.isDifference;
            }
        );

        // 氏名変更ありCID
        result = nameDiffItems.map(
            (item) => {
                return item.customerId;
            }
        );

        return result;
    }

    /**
     * PID配下のCIFに住所また電話番号変更ありのCIDを取得
     *
     * @private
     * @return {*}  {any[]}
     * @memberof ReceptionClerkConfirmRenderer
     */
    private makeAddressTelDiffCidParams(): any[] {
        let result: string[] = [];

        const addressDiffItems = this.state.submitData.allCifAddressDif.filter(
            (item) => {
                return item.isDifference;
            }
        );

        result = addressDiffItems.map(
            (item) => {
                return item.customerId;
            }
        );

        this.state.submitData.allCifTelDif.forEach(
            (item) => {
                if (item.isDifference && result.indexOf(item.customerId) === -1) {
                    result.push(item.customerId);
                }
            }
        );

        return result;
    }

    private registerReceptionLossCorruptionCheckModalHandle(entity, pageIndex, isShowModal: boolean = true) {
        // 受付可否チェック（喪失・破損）の実行後処理を定義
        this.store.registerSignalHandler(CommonBusinessStateSignal.RECEPTION_LOSS_CORRUPTION_CHECK_MODAL, () => {
            this.store.unregisterSignalHandler(CommonBusinessStateSignal.RECEPTION_LOSS_CORRUPTION_CHECK_MODAL);
            // 情報取得後、チェックNGの場合はエラーモーダル、チェックOKの場合は次チャットへ遷移
            if (this.state.submitData.responseForModal && isShowModal) {
                ErrorUtils.errorHandling(
                    this.state.submitData.responseForModal,
                    this.state.submitData.allCifInfos,
                    this.modalService,
                    this.labelService.labels
                );
            } else {
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            }
        });
    }

    private registerReceptionCheckModalHandle(entity, pageIndex, isShowModal: boolean = true) {
        // 受付可否チェック（住変）の実行後処理を定義
        this.store.registerSignalHandler(CommonBusinessStateSignal.RECEPTION_CHANGE_CHECK_MODAL, () => {
            this.store.unregisterSignalHandler(CommonBusinessStateSignal.RECEPTION_CHANGE_CHECK_MODAL);
            // 情報取得後、チェックNGの場合はエラーモーダル、チェックOKの場合は次チャットへ遷移
            if (this.state.submitData.responseForModal && isShowModal) {
                ErrorUtils.errorHandling(
                    this.state.submitData.responseForModal,
                    this.state.submitData.allCifInfos,
                    this.modalService,
                    this.labelService.labels
                );
            } else {
                this.emitMessageRetrivalEvent(entity.next, pageIndex);
            }
        });
    }

    // /**
    //  * 同一名義人照会を呼び出す
    //  */
    // private getSameHolderInquiry() {
    //     // 同一名義人照会を行う
    //     const param = {
    //         tabletApplyId: this.loginStore.getState().tabletApplyId,
    //         params: {
    //             receptionTenban: this.loginStore.getState().belongToBranchNo,
    //             nameKanji: this.state.data.firstName ?
    //                 this.state.data.firstName + COMMON_CONSTANTS.FULL_SPACE + this.state.data.lastName :
    //                 this.state.data.firstNameKanji + COMMON_CONSTANTS.FULL_SPACE + this.state.data.lastNameKanji,
    //             nameKana: StringUtils.convertZankaku2Hankaku(
    //                     this.state.data.firstNameKana + COMMON_CONSTANTS.FULL_SPACE + this.state.data.lastNameKana),
    //             birthdate: this.state.data.birthdate || this.state.data.holderBirthdate,
    //             address: this.getAddress(),
    //             searchMode: SearchMode.ORDINARY,
    //         }
    //     };
    //     this.action.getSameHolderInquiry(param);
    // }

    // private getAddress() {
    //     const prefecture = this.state.data.holderAddressPrefecture ? this.state.data.holderAddressPrefecture : '';
    //     const countyUrbanVillage = this.state.data.holderAddressCountyUrbanVillage ?
    //         this.state.data.holderAddressCountyUrbanVillage : '';
    //     const streetName = this.state.data.showStreet ?
    //         this.state.data.showStreet : this.state.data.getHolderAddressStreetName();
    //     const addressHouseNumber = this.state.data.holderAddressHouseNumber ? this.state.data.holderAddressHouseNumber : '';

    //     return prefecture + countyUrbanVillage + streetName + addressHouseNumber;
    // }

    private processData(sortedList: any) {
        this.state.data.ancestorDuplicateAccountForAllCif = [];
        this.action.setSubmitData({
            key: 'allCifInfos',
            value: []
        });
        sortedList.forEach((cifInfoList) => {
            let customerId = '';
            cifInfoList.forEach((cifInfo) => {
                if (customerId === '') {
                    this.state.submitData.customerId.forEach((cid) => {
                        if (cid === cifInfo.customerId) {
                            customerId = cifInfo.customerId;
                        }
                    });
                }
            });

            cifInfoList.forEach((cifInfo) => {
                const sameOwner = this.state.data.existing.find((account) => account.customerId === customerId);

                const dupicateAccount: AncestorDuplicateAccount = {
                    branchNo: cifInfo.customerManagementBranchCode,
                    branchName: cifInfo.customerManagementBranchName,
                    customerId: cifInfo.customerId,
                    nameKana: cifInfo.kanaName,
                    nameKanji: cifInfo.kanjiNameInfo.kanjiName,
                    nameNonConvert: cifInfo.kanjiNameInfo.unconvertibleCharStatus,
                    birthdate: cifInfo.birthDate,
                    zipCode: cifInfo.addressInfo.postCode,
                    address: cifInfo.addressInfo.kanjiAddress,
                    addressNonConvert: cifInfo.addressInfo.unconvertibleCharStatus,
                    holderTelNo1: cifInfo.phoneNo1,
                    holderTelNo2: cifInfo.phoneNo2,
                    holderTelNo3: cifInfo.phoneNo3,
                    bankCardHoldingStatus: sameOwner.bankCardHoldingStatus,
                    compoundAccountFlag: null,
                    accountHoldingFlag: sameOwner.accountHoldingFlag,
                    attributeMismatchFlag: sameOwner.attributeMismatchFlag,
                    nationalityCode: cifInfo.nationality,
                    accountInfos: [],
                    unacceptables: [],
                    inheritCustomerStatus: '0',
                    status: '0',
                    identificationCode: cifInfo.identificationCode,
                    unacceptableCodeInfo: [],
                    dispUnacceptableCodeInfo: []
                };
                const alreadyPushedAccount = this.state.data.ancestorDuplicateAccountForAllCif.find(
                    (account) => account.customerId === cifInfo.customerId);
                if (alreadyPushedAccount === undefined) {
                    this.state.data.ancestorDuplicateAccountForAllCif.push(dupicateAccount);
                    this.state.submitData.allCifInfos.push(cifInfo);
                }
            });
        });
    }

    /**
     * typeがjudgeの際に、分岐して次のチャットを開始させる
     *
     * @param entity
     * @param pageIndex
     * @param judgeResult
     */
    private nextChatByJudge(entity: ChatFlowMessageInterface, pageIndex: number, judgeResult: string) {
        entity.choices.forEach((choice) => {
            if (choice.value === judgeResult) {
                this.emitMessageRetrivalEvent(choice.next, pageIndex);
                return;
            }
        });
    }

    /**
     * エラーモーダルを表示する
     */
    private showErrorModal(errorCode: string, callback?: any) {
        const buttonList = [
            { text: COMMON_CONSTANTS.UPPERCASE_OK, buttonValue: COMMON_CONSTANTS.LOWERCASE_OK },
        ];
        this.modalService.showAlert(
            this.labelService.labels.common.error.host.support,
            errorCode, 'icon_hourgrass@2x.png', buttonList, 'settings-error-modal',
            callback
        );
    }

    /**
     * 全店名寄せ照会APIの顧客リスト内で顧客管理店番号が重複するCIFが二件以上あるか判定
     */
    private doubleCifJudge(): boolean {
        const accounts = [];
        this.state.submitData.allCifInfos.forEach((cifInfo) => {
            accounts.push(cifInfo.customerManagementBranchCode);
        });
        const list = new Set(accounts);
        return accounts.length !== list.size;
    }

    /**
     * 例外基準のチャットに入るかどうかの判断条件です。
     * 商品コード2101を持っている場合は、例外基準チャットを表示するべき
     *
     * @private
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof ReceptionClerkConfirmRenderer
     */
    private hasOrdinaryDepositAccountCheck(entity: ChatFlowMessageInterface, pageIndex: number) {
        // 普通預金口座を保有するCIFが1件以上存在する、離脱
        let judgeResult = JudgeResultStatus.RESULT_1;
        if (this.state.submitData.mediumInfos && this.state.submitData.mediumInfos.mediumInfo) {
            hasOrdinaryDepositAccount:
            for (const mediumInfo of this.state.submitData.mediumInfos.mediumInfo) {
                if (mediumInfo.accountInfo) {
                    for (const accountInfo of mediumInfo.accountInfo) {
                        if (accountInfo.productCode === ProductCode.OrdinaryDeposit) {
                            judgeResult = JudgeResultStatus.RESULT_0;
                            break hasOrdinaryDepositAccount;
                        }
                    }
                }
            }
        }
        this.nextChatByJudge(entity, pageIndex, judgeResult);
    }

    /**
     * 保有媒体の内容を取得
     *
     * @private
     * @param {ChatFlowMessageInterface} entity
     * @param {number} pageIndex
     * @memberof ReceptionClerkConfirmRenderer
     */
    private getMediumInfo(entity: ChatFlowMessageInterface, pageIndex: number) {
        // 普通預金口座を保有するCIFが1件以上存在する、離脱
        this.store.registerSignalHandler(CommonBusinessStateSignal.GET_MEDIUM_INFO, () => {
            this.store.unregisterSignalHandler(CommonBusinessStateSignal.GET_MEDIUM_INFO);
            // 次のチャットへ進む
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
        // APIの入力パラメータ設置
        const param = new MediumInfosRequest(
            Number(this.loginStore.getState().tabletApplyId),
            this.loginStore.getState().belongToBranchNo,
            this.state.submitData.allCifInfos
        );
        this.action.getMediumInfo(param);
    }

    private isHaveNameDiff(): boolean {
        return this.state.submitData.allCifNameDif.some(
            (item) => {
                return item.isDifference;
            }
        );
    }

    /**
     * 氏名変更受付可否チェック結果、住所、電話受付可否チェック結果からlevelOneの取引ぶり一覧を取得。
     * 重複内容を削除
     *
     * @private
     * @return {*}  {string[]}
     * @memberof ReceptionClerkConfirmRenderer
     */
    private makeTransactionOutContent(): string[] {
        let resultAll: string[] = [];
        if (this.state.submitData.receptionCheckNameDiffResult) {
            this.state.submitData.receptionCheckNameDiffResult.forEach((acceptResult) => {
                // ダメな取引ぶり配列を取得
                const tmpResult = this.changeUtils.getTransactionLevelOneContent(acceptResult.accounts.tradingConditions);
                resultAll = resultAll.concat(tmpResult);

                // ジュニアNISA対応
                const cifInfo =
                    this.state.submitData.allCifInfos.filter((item) => item.customerId === acceptResult.customerId);
                const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(cifInfo[0].birthDate,
                    acceptResult.accounts.tradingConditions);
                if (isHaveJuniorNisa) {
                    resultAll.push('ジュニアNISA');
                }

            });
        }

        if (this.state.submitData.receptionCheckAddressTelDiffResult) {
            this.state.submitData.receptionCheckAddressTelDiffResult.forEach((acceptResult) => {
                // ダメな取引ぶり配列を取得
                const tmpResult = this.changeUtils.getTransactionLevelOneContent(acceptResult.accounts.tradingConditions);
                resultAll = resultAll.concat(tmpResult);

                // ジュニアNISA対応
                const cifInfo =
                    this.state.submitData.allCifInfos.filter((item) => item.customerId === acceptResult.customerId);
                const isHaveJuniorNisa = this.changeUtils.juniorNisaCheckWithCodes(cifInfo[0].birthDate,
                    acceptResult.accounts.tradingConditions);
                if (isHaveJuniorNisa) {
                    resultAll.push('ジュニアNISA');
                }
            });
        }

        // 重複内容を作成
        const resultSet = new Set(resultAll);
        const resultCotent = [];
        resultSet.forEach(
            (code) => {
                switch (code) {
                    case ConstantsChange.DBConsts.SpecTransactionCode.maruyu:
                        resultCotent.push('マル優');
                        break;
                    case ConstantsChange.DBConsts.SpecTransactionCode.marutoku:
                        resultCotent.push('マル特');
                        break;
                    case ConstantsChange.DBConsts.SpecTransactionCode.maruzai:
                        resultCotent.push('マル財');
                        break;
                    case ConstantsChange.DBConsts.SpecTransactionCode.eduFinacialAdmin:
                        resultCotent.push('教育資金管理契約あり');
                        break;
                    case ConstantsChange.DBConsts.SpecTransactionCode.bussinessLoan:
                        resultCotent.push('事業性融資先');
                        break;
                    case ConstantsChange.DBConsts.SpecTransactionCode.currentAccount:
                        resultCotent.push('当座預金先');
                        break;
                    case ConstantsChange.DBConsts.SpecTransactionCode.electronicBond:
                        resultCotent.push('電子記録債権契約先');
                        break;

                    default:
                        resultCotent.push(code);
                        break;
                }
            }
        );

        return resultCotent;
    }

    private makeCardData(choices, transactionContents, cid, errMessage) {
        const contents = [];

        const regx = new RegExp(COMMON_CONSTANTS.NEW_LINE, 'g');
        if (errMessage) {
            contents.push(
                {
                    title: 'エラーコード',
                    content: errMessage.replace(regx, COMMON_CONSTANTS.SPACE)
                }
            );
        }

        // 固定部分はyamlファイルからもらって入れる
        choices.forEach(
            (choice) => {
                switch (choice.text) {
                    case '1人1口座判定':
                        const isHaveOridinaryAccount = this.nameBasedServce.isHaveOridinarySubjectCode(this.state.submitData.allCifInfos);
                        contents.push(
                            {
                                title: choice.text,
                                content: isHaveOridinaryAccount ? '普通預金口座有り' : '普通預金口座無し'
                            }
                        );
                        break;
                    case '例外基準判定':
                        let showConent = '';
                        const accountExceptionCheck = this.state.submitData.accountExceptionCheck;
                        // tslint:disable-next-line:prefer-conditional-expression
                        if (accountExceptionCheck === JudgeResultStatus.RESULT_1) {
                            showConent = '口座開設受付不可';
                        } else {
                            showConent = this.getAccountExceptionReason(this.state.submitData.confirmPurpose);
                        }

                        contents.push(
                            {
                                title: choice.text,
                                content: showConent
                            }
                        );
                        break;
                    case '既存取引有無':
                        contents.push(
                            {
                                title: choice.text,
                                content: this.state.submitData.isHaveOtherTransaction === JudgeResultStatus.RESULT_1 ? '有り' : 'なし'
                            }
                        );
                        break;
                    case '届出事項変更要否':
                        contents.push(
                            {
                                title: choice.text,
                                content: this.state.submitData.isNameAddressTelDiff === JudgeResultStatus.RESULT_1 ? '必要' : '不要'
                            }
                        );
                        break;

                    default:
                        break;
                }
            }
        );

        if (transactionContents) {
            contents.push(
                {
                    title: '取引状況',
                    content: transactionContents
                }
            );
        }

        if (cid) {
            contents.push(
                {
                    title: '顧客番号',
                    content: cid
                },
            );
        }
        return contents;
    }

    private isSwipableCard(cardtype: string): boolean {
        return MediumCardTypes.swipableCard.indexOf(cardtype) > -1;
    }

    private getAccountExceptionReason(confirmPurposeFlg: string): string {
        let result = '口座開設受付可';
        switch (confirmPurposeFlg) {
            case '1':
                result = '口座開設受付可（給与受取）';
                break;
            case '2':
                result = '口座開設受付可（住宅ローン）';
                break;
            case '3':
                result = '口座開設受付可（アパートローン）';
                break;
            case '4':
                result = '口座開設受付可（教育カードローン）';
                break;
            case '5':
                result = '口座開設受付可（横浜銀行カードローン）';
                break;
            case '6':
                result = '口座開設受付可（営業店長承認済み）';
                break;

            default:
                break;
        }

        return result;
    }

}
