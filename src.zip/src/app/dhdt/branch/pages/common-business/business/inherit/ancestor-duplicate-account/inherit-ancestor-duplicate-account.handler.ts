import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { CommonBusinessRendererType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessState, CommonBusinessStore } from 'dhdt/branch/pages/common-business/store/common-business.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { AncestorDuplicateCustomerId } from 'dhdt/branch/pages/inherit/entity/ancestor-duplicate-account.entity';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';

/**
 * `DefaultChatFlowInputHandler`において、死亡者情報入力画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class InheritAncestorInputInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class InheritAncestorDuplicateAccountHandler extends DefaultChatFlowInputHandler {
    private state: CommonBusinessState;

    constructor(
        private action: CommonBusinessAction,
        private store: CommonBusinessStore
    ) {
        super(action);
        this.state = this.store.getState();
    }

    @InputHandler(CommonBusinessRendererType.KEYBOARD)
    private onKeybordHandler(entity: ChatFlowMessageInterface, pageIndex: number, answer: any): any {
        // 文字とフリガらによって、カタカナを転換する
        InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
            const needSpace = InputUtils.needAddSpace(answer.value[0].key);
            if (needSpace) { // 全角スペース必要かを判断する
                const text = results.map((res) => res.value).join(COMMON_CONSTANTS.FULL_SPACE);
                this.setAnswer({
                    text: text,
                    value: [...results, { key: entity.name, value: text }]
                });
            } else {
                this.setAnswer({
                    text: answer.text,
                    value: [...results, { key: entity.name, value: answer.text }]
                });
            }
            this.action.setSubmitData({
                key: 'searchName',
                value: answer.text
            });
            this.emitMessageRetrivalEvent(entity.next, pageIndex);
        });
    }

    @InputHandler(CommonBusinessRendererType.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(CommonBusinessRendererType.DUPLICATE_ACCOUNT_INFO)
    private onDuplicateAccountList(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        let answerDisplay = '';

        if (answer.length === 0) {
            this.chatFlowCompelete();
            return;
        }
        answer.forEach((customerId) => {
            this.state.data.ancestorDuplicateAccount.forEach((data) => {
                if (customerId === data.customerId) {
                    answerDisplay = answerDisplay + data.branchNo + ' ' + data.nameKanji + COMMON_CONSTANTS.NEW_LINE;
                }
            });
        });

        this.action.setAnswer({
            text: answerDisplay,
            value: [{
                key: entity.name,
                value: answer
            }]
        });
        this.action.setSubmitData({
            key: 'inquiryType',
            value: this.state.data.inquiryType
        });
        this.action.setSubmitData({
            key: 'duplicateAccount',
            value: this.state.data.ancestorDuplicateAccount
        });
        const dupicateCustomerId: AncestorDuplicateCustomerId = {
            customerId : this.state.submitData.customerId,
            dataBelongs : this.state.data.inquiryType
        };
        this.action.setSubmitData({
            key: 'ancestorCustomerId',
            value: dupicateCustomerId
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);

    }

    @InputHandler(CommonBusinessRendererType.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (entity.name === 'exit' || entity.name === 'nameAggregation') {
            this.chatFlowCompelete();
        }
    }
}
