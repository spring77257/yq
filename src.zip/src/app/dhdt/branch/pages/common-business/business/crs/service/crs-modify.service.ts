import { Injectable } from '@angular/core';
import { LabelService } from 'adep/services/label.service';

@Injectable()
export class CRSModifyService {
    private labels;

    constructor(labelService: LabelService) {
        this.labels = labelService.labels;
    }

    public get config() {
        const config = new Map();
        config.set(CRSModifyConfigName.OtherCountry, {
            startOrder: 10,
            endOrder: 11,
            name: 'otherCountry',
            currentTitle: this.labels.change.basic.address,
            pageIndex: 0,
            isCurrentPage: true
        });
        config.set(CRSModifyConfigName.Sign, {
            startOrder: 20,
            endOrder: 21,
            name: 'sign',
            currentTitle: this.labels.fatcaTestTitle.signFatca,
            pageIndex: 0,
            isCurrentPage: true
        });
        config.set(CRSModifyConfigName.SignAgent, {
            startOrder: 200,
            endOrder: 210,
            name: 'sign',
            currentTitle: this.labels.fatcaTestTitle.signFatca,
            pageIndex: 0,
            isCurrentPage: true
        });

        return config;
    }

    public get mapping() {
        return {
            otherCountry: 'otherResidenceAddress',
            sign: 'signatureCrs'
        };
    }
}

export enum CRSModifyConfigName {
    OtherCountry    = 'otherCountry',
    Sign            = 'sign',
    SignAgent       = 'signAgent'
}
