import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { W9ModifyHandler } from 'dhdt/branch/pages/common-business/business/w9/handler/w9-modify.handler';
import {
    CommonBusinessRenderer, CommonBusinessRendererType, CommonBusinessType
} from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessState, CommonBusinessStore } from 'dhdt/branch/pages/common-business/store/common-business.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { NumberInputComponent } from 'dhdt/branch/shared/components/number-input/number-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { SignatureComponent } from 'dhdt/branch/shared/components/signature/signature.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

export const W9_MODIFY_RENDERER = 'W9ModifyRenderer';

/**
 * `DefaultChatFlowRenderer`において、自動振込解約画面に利用できるRendererを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferCancelRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: W9_MODIFY_RENDERER,
    templateYaml: 'chat-flow-def-w9-modify.yml'
})
@CommonBusinessRenderer({
    name: W9_MODIFY_RENDERER,
    type: CommonBusinessType.W9
})
export class W9ModifyRenderer extends DefaultChatFlowRenderer {
    public processType: number = -1;
    private state: CommonBusinessState;

    constructor(
        private action: CommonBusinessAction,
        private store: CommonBusinessStore,
        inputHandler: W9ModifyHandler) {
        super(action, inputHandler);

        this.state = store.getState();
    }

    protected get userAnswers(): any {
        return this.state.data.submitData;
    }

    @Renderer(CommonBusinessRendererType.KEYBOARD)
    private onKeybord(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.NUMBER_KEYBORD)
    private onNumberKeybord(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: NumberInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer([
        CommonBusinessRendererType.PHYSICS_PICKER,
        CommonBusinessRendererType.LOGIC_PICKER
    ])
    private onCategoryNameLogicPicker(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.action.getCategoryNameLogic().subscribe((data) => {
            const entryName = entity.type === 'categoryNameLogicPicker' ? 'data' : 'filler1';
            this.emitRenderEvent({
                class: PickerCommonComponent,
                data: data.map((item) => {
                    return {
                        text: item[entryName],
                        value: item.codeValue
                    };
                }),
                options: options
            }, entity, pageIndex);
        });
    }

    @Renderer(CommonBusinessRendererType.SIGN)
    private onSignature(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: SignatureComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }
}
