import { NgModule } from '@angular/core';
import { W9ModifyHandler } from 'dhdt/branch/pages/common-business/business/w9/handler/w9-modify.handler';
import { W9ModifyRenderer } from 'dhdt/branch/pages/common-business/business/w9/renderer/w9-modify.renderer';

@NgModule({
    providers: [
        W9ModifyHandler,
        W9ModifyRenderer
    ]
})
export class W9ModifyModule { }
