import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import {
    InheritAncestorDuplicateAccountHandler
} from 'dhdt/branch/pages/common-business/business/inherit/ancestor-duplicate-account/inherit-ancestor-duplicate-account.handler';
import {
    CommonBusinessRenderer, CommonBusinessRendererType, CommonBusinessType
} from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import {
    CommonBusinessState, CommonBusinessStateSignal, CommonBusinessStore
} from 'dhdt/branch/pages/common-business/store/common-business.store';
import {
    BusinessCode, COMMON_CONSTANTS, HostErrorCodeReceptionNG, InheritAccountInquiryResult
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { CifInfo } from 'dhdt/branch/pages/common/entity/all-customer-infos-response.entity';
import { CustomerInfo, TradingPresenceInquiryResponse } from 'dhdt/branch/pages/common/entity/trading-presence-inquiry-response.entity';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { AncestorDuplicateAccount } from 'dhdt/branch/pages/inherit/entity/ancestor-duplicate-account.entity';
import { InheritConsts } from 'dhdt/branch/pages/inherit/inherit-consts';
import {
    ReceptionCheckAccountInfo, ReceptionLossCorruptionCheckResponse
} from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-response.entity';
import {
    AncestorDuplicateAccountListComponent
} from 'dhdt/branch/shared/components/confirmpage-common/inherit/ancestor-duplicate-account-list.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

export const INHERIT_ANCESTOR_DUPLICATE_ACCOUNT_RENDERER_TYPE = 'InheritAncestorDuplicateAccountRenderer';

/**
 * `DefaultChatFlowRenderer`において、死亡者重複口座照会Rendererを定義しているクラス。
 *
 * @export
 * @class InheritAncestorDuplicateAccountRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: INHERIT_ANCESTOR_DUPLICATE_ACCOUNT_RENDERER_TYPE,
    templateYaml: 'chat-flow-def-inherit-ancestor-duplicate-account.yml'
})
@CommonBusinessRenderer({
    name: INHERIT_ANCESTOR_DUPLICATE_ACCOUNT_RENDERER_TYPE,
    type: CommonBusinessType.InheritAncestorDuplicateAccount
})
export class InheritAncestorDuplicateAccountRenderer extends DefaultChatFlowRenderer {
    public processType = -1;
    private state: CommonBusinessState;

    constructor(
        private action: CommonBusinessAction,
        private store: CommonBusinessStore,
        private loginStore: LoginStore,
        inputHandler: InheritAncestorDuplicateAccountHandler
    ) {
        super(action, inputHandler);
        this.state = this.store.getState();
    }

    protected get userAnswers(): any {
        return this.state.data;
    }

    @Renderer(CommonBusinessRendererType.DUPLICATE_ACCOUNT_INFO)
    private onDuplicateAccountList(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        const { inquiryType, ancestorCifInfoInquiry, ancestorDuplicateAccount, customerId, ancestorCustomerIdSelected,
            defaultCustomerIdList, allCustomerIdList } = this.state.data;
        const { searchName, nameKana } = this.state.submitData;
        this.emitRenderEvent({
            class: AncestorDuplicateAccountListComponent,
            data: {
                inquiryType,
                defaultCustomerIdList,
                allCustomerIdList,
                ancestorDuplicateAccount,
                ancestorCifInfoInquiry,
                ancestorCustomerIdSelected,
                customerId,
                nameKana,
                searchName
            },
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.KEYBOARD)
    private onKeybord(entity: ChatFlowMessageInterface, pageIndex: number): void {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            defaultValues: this.state.data.ancestorBaseInfo.nameKana.split(COMMON_CONSTANTS.FULL_SPACE),
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.REQUEST)
    private onRequest(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.store.registerSignalHandler(CommonBusinessStateSignal.SAME_HOLDER_INHERITANCE_INQUIRY, (value) => {
            this.store.unregisterSignalHandler(CommonBusinessStateSignal.SAME_HOLDER_INHERITANCE_INQUIRY);
            const { result, data } = value;
            const choice = entity.choices.find((item) => item.value === result);

            if (result === InheritAccountInquiryResult.Success) {
                this.action.setStataData({
                    ancestorDuplicateAccount: data
                });
            }
            this.emitMessageRetrivalEvent(choice ? choice.next : entity.next, pageIndex);
        });
        this.action.sameHolderInheritanceInquiry({
            tabletApplyId: this.loginStore.getState().tabletApplyId,
            params: {
                receptionTenban: this.loginStore.getState().belongToBranchNo,
                ...this.state.data.ancestorBaseInfo,
                nameKana: this.state.submitData.nameKana
            }
        }, this.state.data.ancestorCifInfoInquiry ? this.state.data.ancestorCifInfoInquiry.customerId : undefined);
    }

    @Renderer(CommonBusinessRendererType.NAME_AGGREGATION)
    private onNameAggregationInquiry(entity: ChatFlowMessageInterface, pageIndex: number) {
        const customerIdList = this.state.submitData.customerId;
        const maxCnt = customerIdList.length;

        this.store.registerSignalHandler(CommonBusinessStateSignal.GET_NAME_AGGREGATION_INQUIRY, () => {
            this.store.unregisterSignalHandler(CommonBusinessStateSignal.GET_NAME_AGGREGATION_INQUIRY);

            // 複数の名寄せ候補を選択して複数のPIDが返却された場合、PID配下のＣＩＦ情報を1つの一覧に統合して表示する。
            let sortedList = [];
            this.state.submitData.allSelectedCifInfo.forEach((cifInfoList) => {
                cifInfoList.forEach((cifInfo) => {
                    sortedList.push(cifInfo);
                });
            });

            this.store.registerSignalHandler(CommonBusinessStateSignal.RECEPTION_LOSS_CORRUPTION_CHECK,
                (checkResult: ReceptionLossCorruptionCheckResponse) => {
                    this.store.unregisterSignalHandler(CommonBusinessStateSignal.RECEPTION_LOSS_CORRUPTION_CHECK);
                    this.store.registerSignalHandler(CommonBusinessStateSignal.TRADING_PRESENCE_INQUIRY,
                        (tradingResult: TradingPresenceInquiryResponse) => {
                            this.store.unregisterSignalHandler(CommonBusinessStateSignal.TRADING_PRESENCE_INQUIRY);
                            // エラー理由が人格コードエラー(B-STR-005)の場合、名寄せ先から除外する
                            if (checkResult && checkResult.accounts) {
                                sortedList = sortedList.filter((cifInfo) => {
                                    const account = checkResult.accounts.find((item) => item.customerId === cifInfo.customerId);
                                    return !(account && account.errorCode === HostErrorCodeReceptionNG.B_STR_005);
                                });
                            }

                            sortedList.sort((left, right): number => {
                                if (left.personalId > right.personalId) {
                                    return 1;
                                }
                                if (left.personalId < right.personalId) {
                                    return -1;
                                }
                                if (left.customerManagementBranchCode > right.customerManagementBranchCode) {
                                    return 1;
                                }
                                if (left.customerManagementBranchCode < right.customerManagementBranchCode) {
                                    return -1;
                                }
                                return 0;
                            });

                            // 店舗リスト生成
                            this.makeBranchList(sortedList);
                            // 画面表示データ作成
                            this.processData(sortedList, checkResult, tradingResult);
                            this.action.setSubmitData({
                                key: 'duplicateAccount',
                                value: this.state.data.ancestorDuplicateAccountForAllCif
                            });
                            this.emitMessageRetrivalEvent(entity.next, pageIndex);
                        });
                    // 全店名寄せ照会結果に含まれるCIFに対する取引有無照会を実行
                    this.action.tradingPresenceInquiryApi({
                        tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
                        params: {
                            receptionTenban: this.loginStore.getState().belongToBranchNo,
                            // 選択した名寄せCIFの全店名寄せ照会結果に含まれる全CIFを対象とする
                            customerInfo: sortedList.map((cifInfo: CifInfo) => ({
                                customerId: cifInfo.customerId,
                                nationalityCode: cifInfo.nationality
                            }))
                        }
                    });
                });
            // 全店名寄せ照会結果に含まれるCIFに対する受付可否チェックを実行
            this.action.receptionLossCorruptionCheckApi({
                tabletApplyId: Number(this.loginStore.getState().tabletApplyId),
                params: {
                    receptionTenban: this.loginStore.getState().belongToBranchNo,
                    // 選択した名寄せCIFの全店名寄せ照会結果に含まれる全CIFを対象とする
                    accounts: sortedList.map((cifInfo: CifInfo) => {
                        // 顧客番号をキーに受付可否チェックを行う
                        return {
                            tenban: null,
                            accountType: null,
                            accountNo: null,
                            customerId: cifInfo.customerId
                        };
                    }),
                    // 業務コード
                    businessCode: BusinessCode.INHERIT_DUPLICATE as string
                }
            });
        });

        customerIdList.forEach((customerId) => {
            const param = {
                tabletApplyId: this.loginStore.getState().tabletApplyId, // タブレット申込管理ID
                params: {
                    receptionTenban: this.loginStore.getState().belongToBranchNo,   // 取次店番
                    customerId: customerId, // 全店顧客番号
                    inheritFlg: InheritConsts.InheritFlg.flagTrue // 相続業務フラグ
                }
            };
            this.action.nameAggregationInquiry(param, maxCnt);
        });
    }

    @Renderer(CommonBusinessRendererType.TEXT)
    private onText(entity: ChatFlowMessageInterface, pageIndex: number): void {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.BRANCH_LIST)
    private onBranchlist(entity: ChatFlowMessageInterface, pageIndex: number) {
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    private makeBranchList(sortedList: any) {
        const allBranchNameList: string[] = [];
        const customerIdList: string[] = [];
        const branchNameList: string[] = [];
        const firstIndex: string = '１';

        sortedList.forEach((cifInfo) => {
            let branchName = cifInfo.customerManagementBranchName;
            // 支店名が重複した場合、同一支店名リスト作成（初回ループは作成なし）
            const sameBranchNameList = allBranchNameList.filter((item) => item === branchName);
            allBranchNameList.push(branchName);
            // 同一支店名編集
            if (sameBranchNameList.length > 0) {
                if (sameBranchNameList.length === 1) {
                    // 先頭の支店名に”１”を付与
                    const editIndex = branchNameList.findIndex((item) => item === branchName);
                    branchNameList[editIndex] += firstIndex;
                }
                // 同一支店名に数字を付与
                branchName += (sameBranchNameList.length + 1);
                branchName = StringUtils.convertHankaku2Zankaku(branchName);
            }
            branchNameList.push(branchName);
            customerIdList.push(cifInfo.customerId);
        });
        this.action.setSubmitData({
            key: 'branchNameList',
            value: branchNameList
        });
        this.action.setSubmitData({
            key: 'customerId',
            value: customerIdList
        });
        this.state.data.customerId = customerIdList;
    }

    private processData(sortedList: any, checkResult: ReceptionLossCorruptionCheckResponse,
        tradingResult: TradingPresenceInquiryResponse) {
        this.state.data.ancestorDuplicateAccountForAllCif = [];
        sortedList.forEach((cifInfo) => {
            // 受付不可情報（受付可否チェックAPIのレスポンスを元に設定する）
            let unacceptables = [];
            if (checkResult && checkResult.accounts) {
                const account: ReceptionCheckAccountInfo = checkResult.accounts.find((item) => item.customerId === cifInfo.customerId);
                unacceptables = (account && account.unacceptables) ? account.unacceptables : [];
            }
            // 事故・取引禁止・注意コード情報（取引有無照会APIのレスポンスを元に設定する）
            let unacceptableCodeInfo = [];
            let dispUnacceptableCodeInfo = [];
            if (tradingResult && tradingResult.customerInfo) {
                const account: CustomerInfo = tradingResult.customerInfo.find((item) => item.customerId === cifInfo.customerId);
                unacceptableCodeInfo = (account && account.unacceptableCodeInfo) ? account.unacceptableCodeInfo : [];
                dispUnacceptableCodeInfo = account.dispUnacceptableCodeInfo;
            }
            if (dispUnacceptableCodeInfo && dispUnacceptableCodeInfo.length > 0) {
                const settingCodeName = [];
                let codeNameFlag: boolean = false;
                dispUnacceptableCodeInfo.forEach((codeName) => {
                    if (codeName === '口座開設アプリ印鑑未受理') {
                        codeName = '印鑑レス口座';
                        codeNameFlag = true;
                    }
                    settingCodeName.push(codeName);
                });
                if (codeNameFlag) {
                    dispUnacceptableCodeInfo = [];
                    dispUnacceptableCodeInfo = settingCodeName;
                }
            }
            const dupicateAccount: AncestorDuplicateAccount = {
                branchNo: cifInfo.customerManagementBranchCode,
                branchName: cifInfo.customerManagementBranchName,
                customerId: cifInfo.customerId,
                nameKana: cifInfo.kanaName,
                nameKanji: cifInfo.kanjiNameInfo.kanjiName,
                nameNonConvert: cifInfo.kanjiNameInfo.unconvertibleCharStatus,
                birthdate: cifInfo.birthDate,
                zipCode: cifInfo.addressInfo.postCode,
                address: cifInfo.addressInfo.kanjiAddress,
                addressNonConvert: cifInfo.addressInfo.unconvertibleCharStatus,
                holderTelNo1: cifInfo.phoneNo1,
                holderTelNo2: cifInfo.phoneNo2,
                holderTelNo3: cifInfo.phoneNo3,
                bankCardHoldingStatus: '0',
                compoundAccountFlag: null,
                accountHoldingFlag: '0',
                attributeMismatchFlag: '0',
                nationalityCode: cifInfo.nationality,
                accountInfos: [],
                unacceptables: unacceptables,
                inheritCustomerStatus: '0',
                identificationCode: cifInfo.identificationCode,
                status: '0',
                unacceptableCodeInfo: unacceptableCodeInfo,
                dispUnacceptableCodeInfo: dispUnacceptableCodeInfo
            };
            this.state.data.ancestorDuplicateAccountForAllCif.push(dupicateAccount);
        });
    }
}
