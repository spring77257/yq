import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { FATCAModifyHandler } from 'dhdt/branch/pages/common-business/business/fatca/handler/fatca-modify.handler';
import {
    CommonBusinessRenderer, CommonBusinessRendererType, CommonBusinessType
} from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessState, CommonBusinessStore } from 'dhdt/branch/pages/common-business/store/common-business.store';
import { ButtonGroupComponent } from 'dhdt/branch/shared/components/button-group/button-group.component';
import { KeyboardInputComponent } from 'dhdt/branch/shared/components/keyboard-input/keyboard-input.component';
import { PickerCommonComponent } from 'dhdt/branch/shared/components/picker/view/picker-common.component';
import { SignatureComponent } from 'dhdt/branch/shared/components/signature/signature.component';
import { ChatFlowRendererDefinition } from 'dhdt/branch/shared/modules/chat-flow/decorators/chat-flow-renderer-definition';
import { Renderer } from 'dhdt/branch/shared/modules/chat-flow/decorators/renderer';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { DefaultChatFlowRenderer } from 'dhdt/branch/shared/modules/chat-flow/renderers/default-chat-flow.renderer';

export const FATCA_MODIFY_RENDERER = 'FATCAModifyRenderer';

/**
 * `DefaultChatFlowRenderer`において、自動振込解約画面に利用できるRendererを定義しているクラス。
 *
 * @export
 * @class AutomaticTransferCancelRenderer
 * @extends {DefaultChatFlowRenderer}
 */
@Injectable()
@ChatFlowRendererDefinition({
    rendererName: FATCA_MODIFY_RENDERER,
    templateYaml: 'chat-flow-def-fatca-modify.yml'
})
@CommonBusinessRenderer({
    name: FATCA_MODIFY_RENDERER,
    type: CommonBusinessType.FATCA
})
export class FATCAModifyRenderer extends DefaultChatFlowRenderer {
    public processType: number = -1;
    private state: CommonBusinessState;

    constructor(
        private action: CommonBusinessAction,
        private store: CommonBusinessStore,
        inputHandler: FATCAModifyHandler) {
        super(action, inputHandler);

        this.state = store.getState();
    }

    protected get userAnswers(): any {
        return null;
    }

    @Renderer(CommonBusinessRendererType.KEYBOARD)
    private onKeybord(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            validationRules: entity.validationRules,
            skip: entity.skip,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: KeyboardInputComponent,
            data: entity.choices,
            options: options,
        }, entity, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.LOGIC_PICKER)
    private onCategoryNameLogicPicker(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            type: entity.type,
            validationRules: entity.validationRules,
            applyBizCategory: this.state.applyBizCategory,
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.action.getCategoryNameLogic().subscribe((data) => {
            this.emitRenderEvent({
                class: PickerCommonComponent,
                data: data.map((item) => {
                    return {
                        text: item.data,
                        value: item.codeValue
                    };
                }),
                options: options
            }, entity, pageIndex);
        });
    }

    @Renderer(CommonBusinessRendererType.SIGN)
    private onSignature(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };
        this.emitRenderEvent({
            class: SignatureComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }

    @Renderer(CommonBusinessRendererType.BUTTON)
    private onButton(entity: ChatFlowMessageInterface, pageIndex: number) {
        const options = {
            logInfo: {
                screenName: this.state.currentFileInfo.screenId,
                yamlId: this.state.currentFileInfo.yamlId,
                yamlOrder: entity.order
            }
        };

        this.emitRenderEvent({
            class: ButtonGroupComponent,
            data: entity.choices,
            options: options
        }, entity, pageIndex);
    }
}
