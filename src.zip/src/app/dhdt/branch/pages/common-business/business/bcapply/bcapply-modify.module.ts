import { NgModule } from '@angular/core';
import { BcApplyModifyHandler } from './handler/bcapply-modify.handler';
import { BcApplyModifyRenderer } from './renderer/bcapply-modify.renderer';

@NgModule({
    providers: [
        BcApplyModifyRenderer,
        BcApplyModifyHandler
    ]
})
export class BcApplyModifyModule { }
