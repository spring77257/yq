import { NgModule } from '@angular/core';
import { CRSModifyHandler } from 'dhdt/branch/pages/common-business/business/crs/handler/crs-modify.handler';
import { CRSModifyRenderer } from 'dhdt/branch/pages/common-business/business/crs/renderer/crs-modify.renderer';

@NgModule({
    providers: [
        CRSModifyHandler,
        CRSModifyRenderer
    ]
})
export class CRSModifyModule { }
