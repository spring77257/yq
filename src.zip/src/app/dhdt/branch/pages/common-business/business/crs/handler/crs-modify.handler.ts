import { Injectable } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { CRSModifyService } from 'dhdt/branch/pages/common-business/business/crs/service/crs-modify.service';
import { CommonBusinessRendererType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { CommonBusinessStateSignal, CommonBusinessStore } from 'dhdt/branch/pages/common-business/store/common-business.store';
import { COMMON_CONSTANTS } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { LoginStore } from 'dhdt/branch/pages/common/login/store/login.store';
import { InputHandler } from 'dhdt/branch/shared/modules/chat-flow/decorators/input-handler';
import { DefaultChatFlowInputHandler } from 'dhdt/branch/shared/modules/chat-flow/input-handlers/default-chat-flow.input-handler';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { InputUtils } from 'dhdt/branch/shared/utils/input-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';

/**
 * `DefaultChatFlowInputHandler`において、自動振込解約画面に利用できるInputHandlerを定義しているクラス。
 *
 * @export
 * @class ExistingAccountInputHandler
 * @extends {DefaultChatFlowInputHandler}
 */
@Injectable()
export class CRSModifyHandler extends DefaultChatFlowInputHandler {

    constructor(
        private action: CommonBusinessAction,
        private store: CommonBusinessStore,
        private loginStore: LoginStore,
        private modifyService: CRSModifyService
    ) {
        super(action);
    }

    @InputHandler(CommonBusinessRendererType.SIGN)
    private onSignature(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        this.setAnswer({
            text: answer.text,
            value: [{
                key: entity.name, value: answer.value
            }, {
                key: this.modifyService.mapping[entity.name], value: answer.value
            }]
        });
        this.emitMessageRetrivalEvent(entity.next, pageIndex);
    }

    @InputHandler(CommonBusinessRendererType.KEYBOARD)
    private onKeybord(entity: ChatFlowMessageInterface, pageIndex: number, answer: any) {
        if (answer === COMMON_CONSTANTS.SIGN_SKIP) {
            this.setAnswer({ text: COMMON_CONSTANTS.SKIP_TEXT, value: [] });
            this.emitMessageRetrivalEvent(entity.skip, pageIndex);
        } else {
            InputUtils.getKanjiToKana(answer.value).subscribe((results) => {
                if (entity.fullwidthHalfwidthDivisionCode) {
                    this.store.registerSignalHandler(CommonBusinessStateSignal.CHARACTER_CHECK, (data) => {
                        this.store.unregisterSignalHandler(CommonBusinessStateSignal.CHARACTER_CHECK);
                        this.setAnswer({
                            text: answer.text,
                            value: [
                                ...results,
                                ...results.map((item) => {
                                    return {
                                        key: this.modifyService.mapping[item.key],
                                        value: item.value
                                    };
                                })
                            ]
                        });
                        this.emitMessageRetrivalEvent(entity.next, pageIndex);
                    });
                    this.action.characteCheck({
                        tabletApplyId: this.loginStore.getState().tabletApplyId,
                        params: {
                            receptionTenban: this.loginStore.getState().belongToBranchNo,
                            checkStrings: [{
                                checkPattern: entity.fullwidthHalfwidthDivisionCode,
                                checkString: StringUtils.convertHankaku2Zankaku(answer.text)
                            }],
                        }
                    });
                } else {
                    this.setAnswer({
                        text: answer.text,
                        value: [
                            ...results,
                            ...results.map((item) => {
                                return {
                                    key: this.modifyService.mapping[item.key],
                                    value: item.value
                                };
                            })
                        ]
                    });
                    this.emitMessageRetrivalEvent(entity.next, pageIndex);
                }
            });
        }
    }
 }
