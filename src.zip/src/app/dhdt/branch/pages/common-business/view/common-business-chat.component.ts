import { AfterViewChecked, Component, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { AppProperties } from 'app.properties';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { ScreenTransition } from 'dhdt/branch/pages/common-business/common-business-consts';
import { CommonBusinessRendererManager, CommonBusinessType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import {
    CommonBusinessState, CommonBusinessStateSignal, CommonBusinessStore
} from 'dhdt/branch/pages/common-business/store/common-business.store';
import {
    COMMON_CONSTANTS
} from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TopComponent } from 'dhdt/branch/pages/common/top/view/top.component';
import {
    AbstractChatFlowControlComponent
} from 'dhdt/branch/shared/modules/chat-flow/components/abstract-chat-flow-control.component';
import {
    ChatFlowHeaderInterfaces,
    ChatFlowHeaderOptions
} from 'dhdt/branch/shared/modules/chat-flow/components/chat-flow-header.component';
import { App, Content } from 'ionic-angular';
import { Observable } from 'rxjs';

/**
 * 普通預金口座開設（新規）既存CIF名寄せ機能のチャット
 *
 * @export
 * @class CommonBusinessActionTypeChatComponent
 * @extends {AbstractChatFlowControlComponent}
 * @implements {OnInit}
 * @implements {OnDestroy}
 */
@Component({
    selector: 'common-business-chat',
    templateUrl: './common-business-chat.component.html'
})
export class CommonBusinessChatComponent extends AbstractChatFlowControlComponent implements OnInit, OnDestroy, AfterViewChecked {
    @ViewChild(Content) public content: Content;
    public state: CommonBusinessState;
    public headerOptions: ChatFlowHeaderInterfaces.Options;

    constructor(
        private store: CommonBusinessStore,
        private action: CommonBusinessAction,
        injector: Injector,
        private app: App
    ) {
        super(action, injector);

        this.state = this.store.getState();
    }

    /**
     * 初期化処理として以下を行う。
     * * `AbstractChatFlowControlComponent`の初期化メソッド(`initChatFlowControl`)を実行する。
     * * `ChatFlowHeaderComponent`用のオプションをセットアップする。
     * * Storeからのシグナルを登録する。
     *
     * @memberof CommonBusinessActionTypeChatComponent
     */
    public ngOnInit() {
        this.parseParam();
        this.action.onPresent(this.chatFlowNavParam);
        this.action.clearShowChats();
        this.chatFlowNavParam.needPassword = false;

        const rendererType = this.getRendererNameByIndex(this.currentRendererIndex);
        this.currentRenderer = this.setupRenderer(this.currentRendererIndex, rendererType);
        this.currentRenderer.loadTemplate(this.currentRendererIndex);

        this.setupHeaderOptions();

        this.store.registerSignalHandler(CommonBusinessStateSignal.CHAT_FLOW_COMPELETE, (nextComponentType) => {
            if (nextComponentType === ScreenTransition.CLERK_CONFIRM_COMPLETE) {
                this.viewCtrl.dismiss('close');
            } else {
                if (nextComponentType === ScreenTransition.BACK_TO_TOP) {
                    this.app.getRootNav().setRoot(TopComponent).then(() => {
                        this.viewCtrl.dismiss(undefined, undefined, { animate: false });
                    });
                    return;
                }
                this.onChatFlowComplete(nextComponentType, TopComponent);
                this.viewCtrl.dismiss(this.state.submitData);
            }
        });
        this.store.registerSignalHandler(CommonBusinessStateSignal.GET_QUESTION, (pageIndex: number) => {
            // this.onYamlDidLoad(pageIndex);
            this.chatFlowInputField.clear();
            this.action.getNextChatByAnswer(this.chatFlowNavParam.startOrder || 0, pageIndex);
        });
        this.store.registerSignalHandler(CommonBusinessStateSignal.SEND_ANSWER, (data) => {
            this.onNextMessage(data);
        });

        // 前のチャットに戻る
        this.store.registerSignalHandler(CommonBusinessStateSignal.CHAT_FLOW_RETURN, (next) => {
            const copyShowChats = Array.from(this.state.showChats);
            const item = copyShowChats.reverse().find(
                (qus) => {
                    return qus.name === next.name && qus.type !== 'judge';
                }
            );

            this.toEditChat(item.order, item.pageIndex, item.answer.order);
        });
    }

    /**
     * 次のチャットメッセージを取得する。
     *
     * @protected
     * @param {number} order
     * @param {number} pageIndex
     * @param {number} [displayingDelay]
     * @returns
     * @memberof AbstractChatFlowControlComponent
     */
    public getNextChatMessage(order: number, pageIndex: number, displayingDelay?: number): void {
        if (this.chatFlowNavParam.startOrder != null && this.chatFlowNavParam.endOrder != null && order > this.chatFlowNavParam.endOrder) {
            return this.action.chatFlowCompelete(undefined);
        }
        const chatSpeed = displayingDelay !== undefined ? displayingDelay : AppProperties.CHAT_SPEED;
        Observable.timer(Number(chatSpeed)).subscribe(() => {
            this.action.getNextChatByAnswer(order, pageIndex);
        });
    }

    /**
     * クリーンアップ処理として以下を行う。
     * * `AbstractChatFlowControlComponent`のクリーンアップメソッド(`destoyChatFlowControl`)を実行する。
     * * Storeシグナルの登録を解除する。
     *
     * @memberof CommonBusinessActionTypeChatComponent
     */
    public ngOnDestroy() {
        this.destoyChatFlowControl();
        this.store.unregisterSignalHandler(CommonBusinessStateSignal.CHAT_FLOW_COMPELETE);
        this.store.unregisterSignalHandler(CommonBusinessStateSignal.GET_QUESTION);
        this.store.unregisterSignalHandler(CommonBusinessStateSignal.SEND_ANSWER);
    }

    /**
     * ViewCheck後（Viewが変更された後）にメッセージコンテナを最下部へスクロールする。
     *
     * @memberof CommonBusinessActionTypeChatComponent
     */
    public ngAfterViewChecked(): void {
        this.content.scrollToBottom();
    }

    /**
     * この値によって、ヘッダ下部のStepperがどこまで進んでいるかを判断する。
     */
    public get processType() {
        return -1;
    }

    /**
     * Cancel emitter handler
     */
    public cancelEmitterHandler() {
        super.cancelEmitterHandler();
    }

    /**
     * タイトルを取得する。
     *
     * @memberof CommonBusinessActionTypeChatComponent
     */
    public get headerTitle(): string {
        return this.labels.CommonBusiness.title;
    }

    /**
     * Navigationを取得する。
     *
     * @memberof CommonBusinessActionTypeChatComponent
     */
    public get processItems() {
        return [
            {
                type: COMMON_CONSTANTS.ProcessType.RequiredInput,
                value: this.labels.processType.requiredInput,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyInfoConfirm,
                value: this.labels.processType.applyInfoConfirm,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.BankClerkConfirm,
                value: this.labels.processType.bankClerkConfirm,
            },
            {
                type: COMMON_CONSTANTS.ProcessType.ApplyCompletion,
                value: this.labels.processType.completion,
            },
        ];
    }

    /**
     * ページのindexに対して、コンポーネントの名前を取得する
     *
     * @param {number} index
     */
    protected getRendererNameByIndex(index: number) {
        const name = CommonBusinessRendererManager.dequeue(this.state.businessType, index);

        if (!name) {
            throw Error('Could not find a renderer associated');
        }

        return name;
    }

    /**
     * 店舗マスタを更新する
     */
    // tslint:disable-next-line:no-empty
    protected branchStatusUpdate(): void {
    }

    private setupHeaderOptions() {
        switch (this.state.businessType) {
            case CommonBusinessType.ExistingAccount:
                this.headerOptions = {
                    showReturnTopButton: false,
                    title: this.labels.businessTitle.duplicateAccount,
                    leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
                };
                break;
            case CommonBusinessType.OpenStore:
                this.headerOptions = {
                    showReturnTopButton: false,
                    title: this.labels.businessTitle.openStore,
                    leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
                };
                break;
            case CommonBusinessType.InheritAncestorDuplicateAccount:
                this.headerOptions = {
                    showReturnTopButton: false,
                    title: this.labels.inheritContent.title,
                    leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
                };
                break;
            case CommonBusinessType.ReceptionClerkConfirm:
                this.headerOptions = {
                    showReturnTopButton: true,
                    topComponent: TopComponent,
                    title: this.labels.reception.clerkConfirm.modaltitle,
                    leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
                };
                break;
            default:
                this.headerOptions = {
                    showReturnTopButton: false,
                    title: this.chatFlowNavParam.currentTitle,
                    leftButtonType: ChatFlowHeaderOptions.LeftButtonType.BACK
                };
        }
    }

    private toEditChat(order: number, pageIndex: number, answerOrder: number) {
        this.currentRenderer.resetEvents();
        this.action.editAnswer(order, pageIndex, answerOrder);
        this.chatFlowInputField.clear();
        this.currentRendererIndex = pageIndex;
        this.currentRenderer = this.setupRenderer(pageIndex);
        this.getNextChatMessage(order, pageIndex);
        const deleteCount = this.rendererList.length - this.currentRendererIndex - 1;
        this.rendererList.splice(this.currentRendererIndex + 1, deleteCount);
    }
}
