import { Injectable, NgZone } from '@angular/core';
import { ActionBind, State, Store } from 'adep/flux';
import { CommonBusinessActionType } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { CommonBusinessRendererType, CommonBusinessType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';
import { InheritAccountInquiryResult, JudgeResultStatus } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { MediumInfosResponse } from 'dhdt/branch/pages/common/entity/medium-infos-response.entity';
import {
    TradingPresenceInquiryResponse
} from 'dhdt/branch/pages/common/entity/trading-presence-inquiry-response.entity';
import {
    ReceptionLossCorruptionCheckRequest
} from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-request.entity';
import {
    ReceptionCheckAccountInfo,
    ReceptionLossCorruptionCheckResponse
} from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-response.entity';
import { AcceptionResult, AcceptionResultAccount } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import {
    ChatFlowMessageInterface, ChatFlowMessageWithPageIndexInterface
} from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { EditService } from 'dhdt/branch/shared/services/edit.service';
import { ChangeUtils } from 'dhdt/branch/shared/utils/change-util';
import { ErrorUtils } from 'dhdt/branch/shared/utils/error-utils';
import { StringUtils } from 'dhdt/branch/shared/utils/string.utils';
import * as moment from 'moment';
import { Observable } from 'rxjs';

export interface CommonBusinessState extends State {
    questions: ChatFlowMessageInterface[][];
    showChats: ChatFlowMessageWithPageIndexInterface[];
    showConfirm: ChatFlowMessageWithPageIndexInterface[];
    submitData: any;
    currentFileInfo: any;
    data: any;
    businessType: CommonBusinessType;
    duplicateAccountInfos: any[];
    customerSearchStatus: string;
    birthdate: string;
    applyBizCategory: string;
}

export const CommonBusinessStateSignal = {
    GET_QUESTION: 'CommonBusinessStateSignal_GET_QUESTION',
    SEND_ANSWER: 'CommonBusinessStateSignal_SEND_ANSWER',
    CHAT_FLOW_COMPELETE: 'CommonBusinessStateSignal_CHAT_FLOW_COMPELETE',
    CHAT_FLOW_RETURN: 'CommonBusinessStateSignal_CHAT_FLOW_RETURN',

    BRANCH_KANA_LIST: 'CommonBusinessStateSignal_BRANCH_KANA_LIST',
    BRANCH_LIST: 'CommonBusinessStateSignal_BRANCH_LIST',

    CHARACTER_CHECK: 'CommonBusinessStateSignal_CHARACTER_CHECK',
    SAME_HOLDER_INHERITANCE_INQUIRY: 'CommonBusinessStateSignal_SAME_HOLDER_INHERITANCE_INQUIRY',
    GET_NAME_AGGREGATION_INQUIRY: 'CommonBusinessStateSignal_GET_NAME_AGGREGATION_INQUIRY',
    RECEPTION_CHECK_ALL_CIF: 'CommonBusinessStateSignal_RECEPTION_CHECK_ALL_CIF',
    RECEPTION_LOSS_CORRUPTION_CHECK: 'CommonBusinessStateSignal_RECEPTION_LOSS_CORRUPTION_CHECK',
    RECEPTION_LOSS_CORRUPTION_CHECK_MODAL: 'CommonBusinessStateSignal_RECEPTION_LOSS_CORRUPTION_CHECK_MODAL',
    TRADING_PRESENCE_INQUIRY: 'CommonBusinessStateSignal_TRADING_PRESENCE_INQUIRY',
    UNACCEPTABLES_NG: 'CommonBusinessStateSignal_UNACCEPTABLES_NG',
    GET_ADDRESS_CODE: 'CommonBusinessStateSignal_GET_ADDRESS_CODE',
    IS_ADDRESS_DIFFERENCE_FLG: 'CommonBusinessStateSignal_IS_ADDRESS_DIFFERENCE_FLG',
    GET_MEDIUM_INFO: 'CommonBusinessStateSignal.GET_MEDIUM_INFO',
    BC_APPLY: 'CommonBusinessStateSignal.BC_APPLY',

    RECEPTION_CHANGE_CHECK_MODAL: 'CommonBusinessStateSignal_RECEPTION_CHANGE_CHECK_MODAL'
};
@Injectable()
export class CommonBusinessStore extends Store<CommonBusinessState> {
    public indexCnt: number = 0;
    private keysArr: any[] = [];

    constructor(
        private editService: EditService,
        private ngZone: NgZone,
        private changeUtils: ChangeUtils) {
        super();
        this.state = {
            questions: [],
            showChats: [],
            submitData: {},
            currentFileInfo: {},
            showConfirm: [],
            data: undefined,
            businessType: undefined,
            duplicateAccountInfos: null, // 同一名義人
            customerSearchStatus: '',
            birthdate: undefined,
            applyBizCategory: undefined
        };
    }

    /**
     * yamlファイル読込API呼び出し。
     * @param params yamlファイル読込用
     */
    @ActionBind(CommonBusinessActionType.GET_SAVING_QUESTION_TEMPLATE)
    private loadTemplate(params: any) {
        if (params) {
            if (this.state.questions.length === params.pageIndex) {
                this.state.questions.push([]);
            }
            this.saveCurrentYamlInfo(params.fileInfo[0]);
            this.state.questions[params.pageIndex] = params.data;
            this.sendSignal(CommonBusinessStateSignal.GET_QUESTION, params.pageIndex);
        }
    }

    // Save yaml file Information
    private saveCurrentYamlInfo(params: any) {
        if (params) {
            this.state.currentFileInfo.yamlId = params.id;
            this.state.currentFileInfo.screenId = params.screenId;
            this.state.currentFileInfo.screenName = params.screenName;
        }
    }

    /**
     * 次チャットを呼び出し。
     * @param order yamlのorder
     * @param pageIndex ページ番号
     */
    @ActionBind(CommonBusinessActionType.NEXT_CHAT)
    private getNextChatByAnswer(params: { order: number, pageIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        if (this.editService.shouldPrevent(params)) {
            return;
        }
        this.ngZone.runOutsideAngular(() => {
            if (order === 0) {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .min<ChatFlowMessageInterface>((a, b) => a.order < b.order ? -1 : 1).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: this.replaceChatMessage(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (!item.options) {
                            item.options = {};
                        }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order
                        };
                        this.state.showChats.push(qus);
                        this.sendSignal(CommonBusinessStateSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            } else {
                Observable.from<ChatFlowMessageInterface>(this.state.questions[pageIndex])
                    .filter((questions) => questions.order === order).subscribe((item) => {
                        const qus: ChatFlowMessageWithPageIndexInterface = {
                            ...item,
                            question: this.replaceChatMessage(item.question),
                            pageIndex: pageIndex,
                            answer: undefined
                        };
                        if (!item.options) {
                            item.options = {};
                        }
                        if (item.type === CommonBusinessRendererType.CHANGE_ITEM_LIST) {
                            qus.payload = this.changeUtils.makeDifferencePayload(this.state.submitData.allCifInfos,
                            this.state.submitData.customerId, this.state.submitData.nameDifferenceInfos,
                            this.state.submitData.addressDifferenceInfos, this.state.submitData.telDifferenceInfos);
                            this.setSubmitData({
                                key: 'changeDiffInfoList',
                                value: qus.payload
                            });
                         }
                        item.options.logInfo = {
                            screenName: this.state.currentFileInfo.screenId,
                            yamlId: this.state.currentFileInfo.yamlId,
                            yamlOrder: item.order
                        };
                        this.state.showChats.push(qus);
                        this.sendSignal(CommonBusinessStateSignal.SEND_ANSWER, { question: item, pageIndex: pageIndex });
                    });
            }
            this.ngZone.run(() => {
                // DO NOTHING
            });
        });
    }

    /**
     * チャット文字を置換。
     * @param message チャット文字
     */
    private replaceChatMessage(message: string) {
        if (message.indexOf('@') === -1) {
            return message;
        }

        const replaceValues = this.state.data ? [{
            key: '@nameKanji',
            value: this.state.data.account ?  StringUtils.convertHankaku2Zankaku(
                this.state.data.account.nameKana || this.state.data.account.holderNameFurikana
            ) : ''
        }, {
            key: '@birthdate',
            value: this.birthdate
        }, {
            key: '@agentCountry',
            value: this.state.data.agentCountryText
        }, {
            key: '@AgentName',
            value: this.state.data.agentName
        }, {
            key: '@AncestorName',
            value: this.state.data.ancestorBaseInfo ? this.state.data.ancestorBaseInfo.nameKanji : ''
        },
        // 「口座開設受付行員確認」に使用される情報
        {
            key: '@IdenConfirmChatName',
            value: this.state.data.firstName + '　' + this.state.data.lastName
        },
        {
            key: '@IdenConfirmChatSameHolderName', // 同一名義人検索　日本人の場合漢字氏名で表示　外国人の場合カナ氏名で表示
            value: this.state.data.firstNameOld ? '旧姓「' + this.state.data.firstNameOld + '　' + this.state.data.lastNameOld + '」' :
                this.state.data.firstNameKanaOld + '　' + this.state.data.lastNameKanaOld

        },
        {
            key: '@IdenConfirmChatKanaName',
            value: this.state.data.firstNameKana + '　' + this.state.data.lastNameKana
        },
        {
            key: '@IdenConfirmChatAddress',
            value: this.state.data.holderAddressPrefecture +
                    this.state.data.holderAddressCountyUrbanVillage +
                    this.state.data.holderAddressStreetNameSelect +
                    this.state.data.holderAddressHouseNumber
        },
        {
            key: '@IdenConfirmChatKanaAddress',
            value: this.state.data.holderAddressPrefectureFuriKana +
                    this.state.data.holderAddressCountyUrbanVillageFuriKana +
                    this.state.data.holderAddressStreetNameFuriKanaSelect +
                    this.state.data.holderAddressHouseNumberFuriKana
        },
        {
            key: '@IdenConfirmChatBirthdate',
            value: this.state.data.holderBirthdateText
        },
        {
            key: '@IdenConfirmChatOpeningBranchName',
            value: this.state.data.branchName
        },
        {
            key: '@IdenConfirmChatMobileNo',
            value: this.state.data.firstMobileNo + '-' +
                    this.state.data.secondMobileNo + '-' +
                    this.state.data.thirdMobileNo
        },
        {
            key: '@IdenConfirmChatTelNo',
            value: this.state.data.firstTel + '-' +
                    this.state.data.secondTel + '-' +
                    this.state.data.thirdTel
        },
        {
            key: '@ReceptionChangeContent', // 諸届変更ある場所を表示
            value: [
                this.state.submitData.isHaveNameDif === JudgeResultStatus.RESULT_1 ? '氏名' : undefined,
                this.state.submitData.isHaveAddressDif === JudgeResultStatus.RESULT_1 ? '住所' : undefined,
                this.state.submitData.isHaveTelDif === JudgeResultStatus.RESULT_1 ? '電話番号' : undefined
            ].filter(
                (item) => {
                    return item !== undefined;
                }
            ).join('・')
        },
        ] : [];

        let result = message;
        replaceValues.forEach((element) => {
            if (result.indexOf(element.key) !== -1) {
                result = result.replace(element.key, String(element.value));
            }
        });

        return result;
    }

    /**
     * 修正ボタン押下時の処理。
     * @param params yamlのorder,ページ番号
     */
    @ActionBind(CommonBusinessActionType.EDIT_CHAT)
    private editChat(params: { order: number, pageIndex: number, answerOrder: number, showChatIndex: number }) {
        const order = params.order;
        const pageIndex = params.pageIndex;
        const answerOrder = params.answerOrder;

        let i = -1;
        let index = -1;
        if (params.showChatIndex) {
            index = params.showChatIndex;
        } else {
            this.state.showChats.forEach((message) => {
                i += 1;
                if (message.pageIndex === pageIndex && message.order === order) {
                    index = i;
                }
            });
        }

        if (index >= 0) {
            const count = this.state.showChats.length - index;
            this.state.showChats.splice(index, count);
        }

        this.cleanSubmitData(answerOrder);
    }

    /**
     * 顧客入力情報をstateにセット。
     * @param answer 顧客入力情報
     */
    @ActionBind(CommonBusinessActionType.SET_ANSWER)
    private setAnswer(answer: { order: number, text: string, value: Array<{ key: string, value: string }> }) {
        const chat = this.state.showChats[this.state.showChats.length - 1];
        answer.order = this.keysArr.length;
        chat.answer = answer;
        if (answer.value) {
            answer.value.forEach((item) => {
                this.setSubmitData({
                    key: item.key,
                    value: item.value
                });
            });
        }
    }

    /**
     * チャット情報を初期化。
     */
    @ActionBind(CommonBusinessActionType.CLEAR_SHOW_CHATS)
    private clearShowChats() {
        this.state.showChats = [];
    }

    /**
     * submitDataをバックアップ。
     */
    @ActionBind(CommonBusinessActionType.SUBMIT_DATA_BACKUP)
    private submitDataBackup() {
        // this.state.copySubmitData = Object.assign(new AutomaticTransferSubmitEntity(), this.state.submitData);
    }

    /**
     * チャットが完了
     * @param nextChatName 次のチャットの名
     */
    @ActionBind(CommonBusinessActionType.CHAT_FLOW_COMPELETE)
    private chatFlowCompelete(nextChatName: string) {
        this.sendSignal(CommonBusinessStateSignal.CHAT_FLOW_COMPELETE, nextChatName);
    }

    /**
     * 最後のノードをチェックする
     * @param params パラメーター
     */
    @ActionBind(CommonBusinessActionType.RESET_LAST_NODE)
    private resetLastNode(params: { order: number, pageIndex: number }) {
        const lastNode = this.getState().showChats.pop();
        this.getNextChatByAnswer({ order: lastNode.order, pageIndex: lastNode.pageIndex });
    }

    /**
     * 最後のノードをチェックする
     * @param params パラメーター
     */
    @ActionBind(CommonBusinessActionType.REVERT_LAST_NODE)
    private revertLastNode() {
        this.getState().showChats.pop();
    }

    @ActionBind(CommonBusinessActionType.SET_STATE_DATA)
    private setStataData(data: { }) {
        this.state.data = {
            ...this.state.data,
            ...data
        };
    }

    @ActionBind(CommonBusinessActionType.PRESENT)
    private onPresent(params: any) {
        this.state = {
            questions: [],
            showChats: [],
            submitData: {},
            currentFileInfo: {},
            showConfirm: [],
            ...params
        };
    }

    @ActionBind(CommonBusinessActionType.BRANCH_KANA_LIST)
    private getBranchKanaList(data) {
        this.sendSignal(CommonBusinessStateSignal.BRANCH_KANA_LIST, data);
    }

    @ActionBind(CommonBusinessActionType.BRANCH_LIST)
    private getBranchList(data) {
        this.sendSignal(CommonBusinessStateSignal.BRANCH_LIST, data);
    }

    /**
     * submit dataをセットする
     *
     * @param key キー
     * @param value 値
     */
    @ActionBind(CommonBusinessActionType.SET_SUBMIT_DATA)
    private setSubmitData(data) {
        const { key, value } = data;
        let imgDocument;

        if (key === 'identityDocument') {
            imgDocument = this.state.submitData[key] ?
            [...this.state.submitData[key], value] : [value];
        }

        if (key !== undefined) {
            this.state.submitData[key] = (key === 'identityDocument') ? imgDocument : value;
            this.keyPush(key, value);
        }
    }

    /**
     * 文字チェック。
     */
    @ActionBind(CommonBusinessActionType.CHARACTER_CHECK)
    private characteCheck(data: any) {
        this.sendSignal(CommonBusinessStateSignal.CHARACTER_CHECK);
    }

    /**
     * 同一名義人照会（相続）
     */
    @ActionBind(CommonBusinessActionType.SAME_HOLDER_INHERITANCE_INQUIRY)
    private sameHolderInheritanceInquiry(data) {
        const {result, customerId} = data;

        if (result && result.duplicateAccountInfos && result.duplicateAccountInfos.length > 0) {
            const duplicateAccountInfos = customerId
                ? result.duplicateAccountInfos.filter((elemnent) => elemnent.customerId !== customerId)
                : result.duplicateAccountInfos;

            this.sendSignal(CommonBusinessStateSignal.SAME_HOLDER_INHERITANCE_INQUIRY, {
                result: duplicateAccountInfos.length > 0
                    ? InheritAccountInquiryResult.Success
                    : InheritAccountInquiryResult.Fail,
                data: duplicateAccountInfos
            });
        } else {
            this.sendSignal(CommonBusinessStateSignal.SAME_HOLDER_INHERITANCE_INQUIRY, {
                result: InheritAccountInquiryResult.Fail
            });
        }
    }

    private get birthdate() {
        if (this.state.data.account) {
            const birthdate = this.state.data.account.birthdate || this.state.data.account.holderBirthdate;
            if (birthdate) {
                return moment(birthdate).format('YYYY年M月D日');
            }
        }

        return '';
    }

    /**
     * キーと値を配列に保存する
     *
     * @param key キー
     * @param value 値
     */
    private keyPush(key: any, value: any) {
        if (value === null) {
            const index = this.keysArr.indexOf(key);
            if (index >= 0) {
                this.keysArr.splice(index, 1);
            }
        } else if (this.keysArr.indexOf(key) === -1) {
            this.keysArr.push(key);
        } else {
            const index = this.keysArr.indexOf(key);
            this.keysArr[index] = moment().format('YYYYMMDDHHmmss');
            this.keysArr.push(key);
        }
    }

    /**
     * submit dataにremain以降の値をクリーンする
     * @param remain
     */
    private cleanSubmitData(remain: number) {
        this.keysArr = this.keysArr.slice(0, remain);
        for (const item in this.state.submitData) {
            if (item.startsWith('get')) {
                continue;
            }

            if (this.keysArr.indexOf(item) < 0) {
                this.state.submitData[item] = undefined;
            }
        }
    }

    /**
     * 全店名寄せ情報をセット
     */
    @ActionBind(CommonBusinessActionType.NAME_AGGREGATION)
    private setAllCifInfos(data: any) {
        this.indexCnt = this.indexCnt + 1;
        let allAcceptionResult: any;
        let singleCifInfo = data.data;
        allAcceptionResult = this.state.submitData.allSelectedCifInfo;
        const initAcceptionResult: any = [];

        // 既に実行済みの全店名寄せ照会結果に同一CIFが含まれる場合（同じPID配下のCIFを選択した場合）、追加しない
        if (this.state.submitData.allSelectedCifInfo && this.state.submitData.allSelectedCifInfo.length) {
            singleCifInfo = singleCifInfo.filter((cifInfo) => {
                return !this.state.submitData.allSelectedCifInfo.some((customerInfos) => {
                    return customerInfos.some((customerInfo) => (customerInfo.customerId === cifInfo.customerId));
                });
            });
        }

        singleCifInfo.forEach((cifInfo) => {
            cifInfo.kanaName = StringUtils.convertHankaku2Zankaku(cifInfo.kanaName);
            if (cifInfo.addressInfo) {
                cifInfo.addressInfo.kanaAddress = StringUtils.convertHankaku2Zankaku(cifInfo.addressInfo.kanaAddress);
            }
            if (cifInfo.address2Info) {
                cifInfo.address2Info.kanaAddress2 = StringUtils.convertHankaku2Zankaku(cifInfo.address2Info.kanaAddress2);
            }
        });

        if (allAcceptionResult === undefined) {
            initAcceptionResult.push(singleCifInfo);
            this.setStateSubmitDataValuesSpecial([{
                key: 'allSelectedCifInfo',
                value: initAcceptionResult
            }]);
        } else {
            allAcceptionResult.push(singleCifInfo);
            this.setStateSubmitDataValuesSpecial([{
                key: 'allSelectedCifInfo',
                value: allAcceptionResult
            }]);
        }

        if (this.indexCnt === data.maxCnt) {
            this.indexCnt = 0;
            this.sendSignal(CommonBusinessStateSignal.GET_NAME_AGGREGATION_INQUIRY);
        }
    }

    private setStateSubmitDataValuesSpecial(datas: Array<{ key: string, value: any }>) {
        if (datas && datas.length > 0) {
            datas.forEach((item) => {
                this.setSubmitData({
                    key: item.key,
                    value: item.value
                });
            });
        }
    }

    /**
     * 同一名義人照会（相続）
     */
    @ActionBind(CommonBusinessActionType.NAME_AGGREGATION_DEFAULT)
    private setAllCifInfosDefault(data) {
        this.state.submitData.defaultCifInfo = [];
        if (data) {
            const singleCifInfo = data.data;
            singleCifInfo.forEach((cifInfo) => {
                cifInfo.kanaName = StringUtils.convertHankaku2Zankaku(cifInfo.kanaName);
                if (cifInfo.addressInfo) {
                    cifInfo.addressInfo.kanaAddress = StringUtils.convertHankaku2Zankaku(cifInfo.addressInfo.kanaAddress);
                }
                if (cifInfo.address2Info) {
                    cifInfo.address2Info.kanaAddress2 = StringUtils.convertHankaku2Zankaku(cifInfo.address2Info.kanaAddress2);
                }
                this.state.submitData.defaultCifInfo.push(cifInfo);
            });
        }
        this.sendSignal(CommonBusinessStateSignal.GET_NAME_AGGREGATION_INQUIRY);
    }

    /**
     * 受付可否チェック(住変)にてエラーになった旨送信する
     * @param data
     */
    @ActionBind(CommonBusinessActionType.UNACCEPTABLES_NG)
    private signalUnacceptablesNg(data: any) {
        this.sendSignal(CommonBusinessStateSignal.UNACCEPTABLES_NG, data);
    }

    /**
     * Deal with customer status
     * @param params info in chat flow
     */
    @ActionBind(CommonBusinessActionType.RECEPTION_CHECK_ALL_CIF)
    private requestCustomerStatus(params: any) {
        this.state.data.account.receptionCheckResult = params.response;
        this.sendSignal(CommonBusinessStateSignal.RECEPTION_CHECK_ALL_CIF);
    }

    /**
     * 受付可否チェック(喪失・破損)のレスポンスを送信する
     * @param data APIのレスポンス
     */
    @ActionBind(CommonBusinessActionType.RECEPTION_LOSS_CORRUPTION_CHECK)
    private onAcceptCheck(param: { data: ReceptionLossCorruptionCheckResponse }) {
        this.sendSignal(CommonBusinessStateSignal.RECEPTION_LOSS_CORRUPTION_CHECK, param.data);
    }

    /**
     * 受付可否チェック(喪失・破損)のレスポンスを送信する
     * @param data APIのレスポンス
     */
    @ActionBind(CommonBusinessActionType.RECEPTION_LOSS_CORRUPTION_CHECK_MODAL)
    private onAcceptCheckModal(param: {
        name?: string, data: ReceptionLossCorruptionCheckResponse, requestParams: ReceptionLossCorruptionCheckRequest
    }) {

        // 受付可否チェックの実行結果を保存する
        if (param.name) {
            this.setSubmitData({ key: param.name, value: param.data});
        }

        // エラーモーダル表示用データを作成する
        let responseForModal: Array<{customerId?: string, branchCode?: string, subjectCode?: string, bankAccountId?: string,
                                     accounts: ReceptionCheckAccountInfo}> = [];

        if (param.data && (ErrorUtils.isHostError(param.data.errorCode) ||
            param.data.accounts.some((accountInfo) => ErrorUtils.isHostError(accountInfo.errorCode)))) {
            if (param.data.accounts) {
                for (let i = 0; i < param.data.accounts.length; i++) {
                    if (param.requestParams.params.accounts[i].customerId) {
                        responseForModal.push(
                            {
                                customerId: param.requestParams.params.accounts[i].customerId,
                                accounts: param.data.accounts[i]
                            }
                        );
                    }
                }
            }
        } else {
            // エラーがない場合はresponseForModalにundefinedを設定
            responseForModal = undefined;
        }
        // 後続処理にてモーダル表示のため、stateに格納
        this.setSubmitData({key: 'responseForModal', value: responseForModal});

        this.sendSignal(CommonBusinessStateSignal.RECEPTION_LOSS_CORRUPTION_CHECK_MODAL, param.data);
    }

    /**
     * 受付可否チェック(住変)のレスポンスを送信する
     * @param data APIのレスポンス
     */
    @ActionBind(CommonBusinessActionType.RECEPTION_CHANGE_CHECK_MODAL)
    private onAcceptChangeCheckModal(param: {
        name?: string, data: AcceptionResult,
        requestParams: ReceptionLossCorruptionCheckRequest
    }) {

        // 受付可否チェックの実行結果を保存する
        if (param.name) {
            const acceptResult: Array<{ customerId: string, accounts: AcceptionResultAccount }> = [];
            param.requestParams.params.accounts.forEach((item, index) => {
                acceptResult.push({ customerId: item.customerId, accounts: param.data.accounts[index] });
            });
            this.setSubmitData({ key: param.name, value: acceptResult });
        }

        // エラーモーダル表示用データを作成する
        let responseForModal: Array<{
            customerId?: string, branchCode?: string, subjectCode?: string, bankAccountId?: string,
            accounts: AcceptionResultAccount
        }> = [];

        if (param.data && param.data.accounts.some((accountInfo) => ErrorUtils.isHostError(accountInfo.errorCode))) {
            if (param.data.accounts) {
                for (let i = 0; i < param.data.accounts.length; i++) {
                    if (param.requestParams.params.accounts[i].customerId) {
                        responseForModal.push(
                            {
                                customerId: param.requestParams.params.accounts[i].customerId,
                                accounts: param.data.accounts[i]
                            }
                        );
                    }
                }
            }
        } else {
            // エラーがない場合はresponseForModalにundefinedを設定
            responseForModal = undefined;
        }
        // 後続処理にてモーダル表示のため、stateに格納
        this.setSubmitData({ key: 'responseForModal', value: responseForModal });

        this.sendSignal(CommonBusinessStateSignal.RECEPTION_CHANGE_CHECK_MODAL, param.data);
    }

    /**
     * 取引有無照会のレスポンスを送信する
     * @param data APIのレスポンス
     */
    @ActionBind(CommonBusinessActionType.TRADING_PRESENCE_INQUIRY)
    private onTradingPresenceInquiry(param: { data: TradingPresenceInquiryResponse }) {
        this.sendSignal(CommonBusinessStateSignal.TRADING_PRESENCE_INQUIRY, param.data);
    }

    /**
     * 住所コードを格納する
     * @param data APIのレスポンス
     */
    @ActionBind(CommonBusinessActionType.SET_ADDRESS_CODE)
    private setAddressCode(data: any) {
        this.state.data.account.holderAddressCode = data.addressCode;
        this.state.data.holderAddressCode = data.addressCode;
        this.setSubmitData({key: 'holderAddressCode', value: data.addressCode});
        this.sendSignal(CommonBusinessStateSignal.GET_ADDRESS_CODE);
    }

    /**
     * 内部API: 保有通帳・カード・印鑑情報照会のレスポンスをstateにセットする
     * @param data APIのレスポンス
     */
    @ActionBind(CommonBusinessActionType.SET_MEDIUM_INFO)
    private setMediumInfo(data: MediumInfosResponse) {
         this.setSubmitData({key: 'mediumInfos', value: data});
         this.sendSignal(CommonBusinessStateSignal.GET_MEDIUM_INFO);
    }

    @ActionBind(CommonBusinessActionType.BC_APPLY_CHECK)
    private bcApplyCheck(result: any) {
        let tmpAcceptionResult: AcceptionResult;
        let allAcceptionResult: AcceptionResult[] = new Array();
        const initAcceptionResult: AcceptionResult[] = new Array();

        tmpAcceptionResult = result.data;
        allAcceptionResult = this.state.submitData.bcHoldingStatusAllCustomer;
        if (allAcceptionResult === undefined) {
                initAcceptionResult.push(tmpAcceptionResult);
                this.setStateSubmitDataValuesSpecial([{
                key: 'bcHoldingStatusAllCustomer',
                value: initAcceptionResult
                }]);
        } else {
                allAcceptionResult.push(tmpAcceptionResult);
                this.setStateSubmitDataValuesSpecial([{
                key: 'bcHoldingStatusAllCustomer',
                value: allAcceptionResult
                }]);
        }

        this.sendSignal(CommonBusinessStateSignal.BC_APPLY, this.state.submitData.bcHoldingStatusAllCustomer);

    }
    /**
     * 受付可否チェック結果をクリアする
     */
    @ActionBind(CommonBusinessActionType.CLEAR_RECEPTION_CHECK_RESULT)
    private clearReceptionCheckResult() {
        this.state.data.account.receptionCheckResult = null;
    }

    /**
     * 同一名義人照会結果設定
     * @param data response data
     */
    @ActionBind(CommonBusinessActionType.GET_SAME_HOLDER_INQUIRY)
    private signalSameHolderInquiry(data: any) {
        data.result.duplicateAccountInfos.forEach((item: any) => {
            item.nameKana = StringUtils.convertHankaku2Zankaku(item.nameKana);
        });
        // 同一名義人照会結果を発送する
        this.state.data.customerSearchStatus = data.result.customerSearchStatus;
        this.state.data.existing = data.result.duplicateAccountInfos;
        this.state.data.account = {
            holderAddressPrefecture: this.state.data.holderAddressPrefecture,
            holderAddressCountyUrbanVillage: this.state.data.holderAddressCountyUrbanVillage,
            showStreet: this.state.data.showStreet,
            addressHouseNumber: this.state.data.addressHouseNumber
        };
     }

    /**
     * 前のチャットに戻る
     *
     * @private
     * @param {*} next
     * @memberof CommonBusinessStore
     */
    @ActionBind(CommonBusinessActionType.CHAT_FLOW_RETURN)
    private chatFlowReturn(next: any) {
        this.sendSignal(CommonBusinessStateSignal.CHAT_FLOW_RETURN, next);
    }
}
