import { Injectable, NgZone } from '@angular/core';
import { Action } from 'adep/flux';
import { API_URL, HostErrorCodeReceptionNG, HostResultCode } from 'dhdt/branch/pages/common/branch-tablet-consts';
import { TradingPresenceInquiryRequest } from 'dhdt/branch/pages/common/entity/trading-presence-inquiry-request.entity';
import {
    ReceptionLossCorruptionCheckRequest
} from 'dhdt/branch/pages/loss-reissue-finding/entity/reception-loss-corruption-check-request.entity';
import { AcceptionResult } from 'dhdt/branch/shared/components/change-flow/entity/change.entity';
import { ChatFlowActionInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-action.interface';
import { ChatFlowMessageInterface } from 'dhdt/branch/shared/modules/chat-flow/interfaces/chat-flow-message.interface';
import { HostErrorService } from 'dhdt/branch/shared/services/host-error.service';
import { HttpStatusError } from 'dhdt/branch/shared/services/http-status-error';
import { HttpService, HttpStatus } from 'dhdt/branch/shared/services/http.service';
import { SpinnerType } from 'dhdt/branch/shared/services/loading.service';
import { map } from 'rxjs/operators';

export namespace CommonBusinessActionType {
    export const GET_SAVING_QUESTION_TEMPLATE = 'CommonBusinessActionType_GET_SAVING_QUESTION_TEMPLATE';
    export const NEXT_CHAT = 'CommonBusinessActionType_NEXT_CHAT';
    export const EDIT_CHAT = 'CommonBusinessActionType_EDIT_CHAT';
    export const SET_ANSWER = 'CommonBusinessActionType_SET_ANSWER';
    export const SET_SUBMIT_DATA = 'CommonBusinessActionType_SET_SUBMIT_DATA';
    export const SET_STATE_DATA = 'CommonBusinessActionType_SET_STATE_DATA';
    export const CHAT_FLOW_COMPELETE = 'CommonBusinessActionType_CHAT_FLOW_COMPELETE';
    export const RESET_LAST_NODE = 'CommonBusinessActionType_RESET_LAST_NODE';
    export const REVERT_LAST_NODE = 'CommonBusinessActionType_REVERT_LAST_NODE';
    export const CHAT_FLOW_RETURN = 'CommonBusinessActionType_CHAT_FLOW_RETURN';

    export const CLEAR_SHOW_CHATS = 'CommonBusinessActionType_CLEAR_SHOW_CHATS';
    export const SUBMIT_DATA_BACKUP = 'CommonBusinessActionType_SUBMIT_DATA_BACKUP';

    export const PRESENT = 'CommonBusinessActionType_PRESENT';

    export const BRANCH_KANA_LIST = 'CommonBusinessActionType_BRANCH_KANA_LIST';
    export const BRANCH_LIST = 'CommonBusinessActionType_BRANCH_LIST';

    export const CHARACTER_CHECK = 'CommonBusinessActionType_CHARACTER_CHECK';

    export const SAME_HOLDER_INHERITANCE_INQUIRY = 'CommonBusinessActionType_SAME_HOLDER_INHERITANCE_INQUIRY';
    export const NAME_AGGREGATION = 'CommonBusinessActionType_NAME_AGGREGATION';
    export const NAME_AGGREGATION_DEFAULT = 'CommonBusinessActionType_NAME_AGGREGATION_DEFAULT';
    export const RECEPTION_CHECK_ALL_CIF = 'CommonBusinessActionType_CHECK_ALL_CIF';
    export const RECEPTION_LOSS_CORRUPTION_CHECK = 'CommonBusinessActionType_RECEPTION_LOSS_CORRUPTION_CHECK';
    export const RECEPTION_LOSS_CORRUPTION_CHECK_MODAL = 'CommonBusinessActionType_RECEPTION_LOSS_CORRUPTION_CHECK_MODAL';
    export const RECEPTION_CHANGE_CHECK_MODAL = 'CommonBusinessActionType_RECEPTION_CHANGE_CHECK_MODAL';
    export const TRADING_PRESENCE_INQUIRY = 'CommonBusinessActionType_TRADING_PRESENCE_INQUIRY';
    export const UNACCEPTABLES_NG = 'CommonBusinessActionType_UNACCEPTABLES_NG';
    export const SET_ADDRESS_CODE = 'CommonBusinessActionType_SET_ADDRESS_CODE';
    export const SET_MEDIUM_INFO = 'CommonBusinessActionType_SET_MEDIUM_INFO';
    export const BC_APPLY_CHECK = 'CommonBusinessActionType_BC_APPLY_CHECK';
    export const CLEAR_RECEPTION_CHECK_RESULT = 'CommonBusinessActionType_CLEAR_RECEPTION_CHECK_RESULT';

    export const GET_SAME_HOLDER_INQUIRY = 'CommonBusinessActionType_GET_SAME_HOLDER_INQUIRY';
    export const SET_SUBMIT_DATA_SUB = 'CommonBusinessActionType_SET_SUBMIT_DATA_SUB';
}

@Injectable()
export class CommonBusinessAction extends Action implements ChatFlowActionInterface {

    constructor(
        private httpService: HttpService,
        private hostErrorService: HostErrorService,
        private ngZone: NgZone) {
        super();
    }
    /**
     * チャットテンプレートをロードする
     * @param file yamlファイル名
     * @param pageIndex ページインデックス
     */
    public loadTemplate(file: string, pageIndex: number) {
        this.httpService.get(API_URL.CHATFLOW_DEFINITION + file, null, null, SpinnerType.NO_SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CommonBusinessActionType.GET_SAVING_QUESTION_TEMPLATE,
                data: {
                    data: response.result.questions,
                    pageIndex: pageIndex,
                    fileInfo: response.result.fileInfos
                }
            });
        });
    }

    /**
     * 次のステップを取得する
     * @param order オーダー
     * @param pageIndex ページインデックス
     */
    public getNextChatByAnswer(order: number, pageIndex: number) {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.NEXT_CHAT,
            data: { order: order, pageIndex: pageIndex }
        });
    }

    /**
     * 回答を編集する。
     *
     * @param {number} order
     * @param {number} pageIndex
     * @memberof ChatFlowActionInterface
     */
    public editAnswer(order: number, pageIndex: number, answerOrder: number, showChatIndex?: number) {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.EDIT_CHAT,
            data: {
                order: order, pageIndex: pageIndex, answerOrder: answerOrder, showChatIndex: showChatIndex
            }
        });
    }

    /**
     * ユーザからの回答をStateに保存する。
     *
     * @param {{ text: string, value: Array<{ key: string, value: string }> }} answer
     * @memberof ChatFlowActionInterface
     */
    public setAnswer(answer: { text: string, value: Array<{ key: string, value: string }> }) {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.SET_ANSWER,
            data: answer
        });
    }

    /**
     * submit dataをセットする
     *
     * @param key キー
     * @param value 値
     */
    public setSubmitData(data: { key: string, value: any }) {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.SET_SUBMIT_DATA,
            data: data
        });
    }

    /**
     * ChatFlowを完了させる。
     *
     * @param {string} nextChatName
     * @memberof ChatFlowActionInterface
     */
    public chatFlowCompelete(nextChatName: string) {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.CHAT_FLOW_COMPELETE,
            data: nextChatName
        });
    }

    /**
     * 現在のChatFlowの最後のMessageを初期化する。
     *
     * @memberof ChatFlowActionInterface
     */
    public resetLastNode() {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.RESET_LAST_NODE
        });
    }
    public revertLastNode() {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.REVERT_LAST_NODE
        });
    }

    /**
     * チャットの表示内容をクリアする
     */
    public clearShowChats() {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.CLEAR_SHOW_CHATS
        });
    }

    /**
     * 回答中のChatFlowのデータのバックアップを行う。
     *
     * @memberof ChatFlowActionInterface
     */
    public submitDataBackup(): void {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.SUBMIT_DATA_BACKUP
        });
    }

    /**
     * stateのdataをセット
     * @param data データ
     */
    public setStataData(data: {}) {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.SET_STATE_DATA,
            data: data
        });
    }

    public onPresent(params: any) {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.PRESENT,
            data: params
        });
    }

    public getBranchKanaList() {
        this.httpService.get(API_URL.BRANCH_KANA_LIST).subscribe((res) => {
            this.dispatcher.dispatch({
                actionType: CommonBusinessActionType.BRANCH_KANA_LIST,
                data: res.result
            });
        });
    }

    public getBranchList(branchKana: any) {
        this.httpService.post(API_URL.BRANCH_LIST, {
            branchNameKana: branchKana
        }).subscribe((res) => {
            this.dispatcher.dispatch({
                actionType: CommonBusinessActionType.BRANCH_LIST,
                data: res.result
            });
        });
    }

    public characteCheck(params: any) {
        this.httpService.post(API_URL.CHARACTER_CHECK, params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CommonBusinessActionType.CHARACTER_CHECK,
                data: response.result
            });
        });
    }

    public getCategoryNameLogic() {
        return this.httpService.get('/categoryCodes/retrieve', { params: { categoryCode: '049' } })
            .pipe(map((res) => res.result));
    }

    /**
     * 同一名義人照会（相続）
     */
    public sameHolderInheritanceInquiry(
        data: {
            tabletApplyId,
            params: { receptionTenban, nameKana, nameKanji, birthdate, address?, phoneNo1?, phoneNo2?, phoneNo3?}
        },
        customerId: string,
        spinnerType = SpinnerType.SHOW
    ) {
        this.httpService.post('core-banking/same-holder-inheritance/inquiry', {
            tabletApplyId: data.tabletApplyId,
            params: {
                ...data.params,
                searchMode: 3,   // 相続を設定。
                business: 15     // 業務コードは、「15」をセット。業務受付可否チェックで使用。
            }
        }, null, spinnerType).pipe(
            map((res) => res.result)
        ).subscribe((result) => {
            this.dispatcher.dispatch({
                actionType: CommonBusinessActionType.SAME_HOLDER_INHERITANCE_INQUIRY,
                data: {
                    result: result,
                    customerId: customerId,
                }
            });
        });
    }

    /**
     * 全店名寄せ照会
     * @param params パラメータ
     */
    public nameAggregationInquiry(params: any, maxCnt: number) {
        this.httpService.post(API_URL.NAME_AGGREGATION, params, undefined, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CommonBusinessActionType.NAME_AGGREGATION,
                data: {
                    data: response.result.customerInfo,
                    maxCnt: maxCnt
                }
            });
        });
    }

    /**
     * 全店名寄せ照会（相続）
     */
    public nameAggregationInquiryDefault(params: any) {
        this.httpService.post(API_URL.NAME_AGGREGATION, params, undefined, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CommonBusinessActionType.NAME_AGGREGATION_DEFAULT,
                data: {
                    data: response.result.customerInfo,
                }
            });
        });
    }

    /**
     * 受付可否チェック(全店CIF用)
     * @param params 受付可否チェックパラメータ
     */
    public receptionCheckAllCif(questions: ChatFlowMessageInterface, params: any) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, params, undefined, undefined, true).subscribe((response: any) => {

            // 返却されたエラーコードが、受付可否チェック検出対象かを確認する。
            function isHostError(errorCode: string): boolean {
                return (Object.keys(HostErrorCodeReceptionNG).some((key) => HostErrorCodeReceptionNG[key] === errorCode));
            }

            // エラー発生時
            if (response instanceof HttpStatusError) {
                // 事故取引禁止注意コードエラーの場合、受付可否チェック（住変）NGとしてSignalを送信する
                if (response.errors && response.errors.data && isHostError(response.errors.data.errorCode)) {
                    this.dispatcher.dispatch({
                        actionType: CommonBusinessActionType.UNACCEPTABLES_NG,
                        data: response.errors.data
                    });
                    return;
                } else {
                    // 上記以外のエラーの場合、共通エラーハンドリング処理にて処理する
                    this.ngZone.runTask(() => {
                        throw response;
                    });
                    return;
                }
            }

            const result: AcceptionResult = response.result || {};
            // 次の業務に移動する
            this.dispatcher.dispatch({
                actionType: CommonBusinessActionType.RECEPTION_CHECK_ALL_CIF,
                data: {
                    item: questions,
                    response: result || {}
                }
            });
        });
    }

    /**
     * 受付可否チェック(喪失・破損)APIを実行する
     * @param params 受付可否チェックパラメータ
     */
    public receptionLossCorruptionCheckApi(params: ReceptionLossCorruptionCheckRequest) {
        this.httpService.post(API_URL.RECEPTION_LOSS_CORRUPTION_CHECK, params, undefined, SpinnerType.SHOW, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.RECEPTION_LOSS_CORRUPTION_CHECK, response.status, response.errors);
                    });
                } else if (response instanceof HttpStatusError && response.errors && response.errors.data
                    && response.errors.data.accounts
                    && response.errors.data.accounts.some((item) => {
                        return item.resultCode === HostResultCode.SUPPORT
                            && item.errorCode !== HostErrorCodeReceptionNG.B_STR_005
                            && item.errorCode !== HostErrorCodeReceptionNG.B_STR_006;
                    })) {
                    const errorItem = response.errors.data.accounts.find((item) => {
                        return item.resultCode === HostResultCode.SUPPORT
                            && item.errorCode !== HostErrorCodeReceptionNG.B_STR_005
                            && item.errorCode !== HostErrorCodeReceptionNG.B_STR_006;
                    });
                    this.hostErrorService.push({
                        resultCode: errorItem.resultCode,
                        errorCode: errorItem.errorCode,
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: CommonBusinessActionType.RECEPTION_LOSS_CORRUPTION_CHECK,
                        data: {
                            data: response instanceof HttpStatusError ? response.errors.data : response.result
                        }
                    });
                }
            }
        );
    }

    /**
     * 受付可否チェックAPIを実行する。実行後処理は呼び出し元に委任する。
     * 受付失敗する場合は、失敗内容をポップアップに表示
     * @param params 受付可否チェックパラメータ
     */
    public receptionCheckApiWithErrorModal(params: ReceptionLossCorruptionCheckRequest, name?: string) {
        this.httpService.post(API_URL.RECEPTION_LOSS_CORRUPTION_CHECK, params, undefined, undefined, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.RECEPTION_LOSS_CORRUPTION_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: CommonBusinessActionType.RECEPTION_LOSS_CORRUPTION_CHECK_MODAL,
                        data: {
                            name: name,
                            data: response instanceof HttpStatusError ? response.errors.data : response.result,
                            requestParams: params
                        }
                    });
                }
            }
        );
    }

    /**
     * 受付可否チェックAPI（住変）を実行する。実行後処理は呼び出し元に委任する。
     * 受付失敗する場合は、失敗内容をポップアップに表示
     * @param params 受付可否チェックパラメータ
     */
    public receptionChangeCheckApiWithErrorModal(params: any, name?: string) {
        this.httpService.post(API_URL.ADDRESS_CHANGE_CHECK, params, undefined, undefined, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.ADDRESS_CHANGE_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: CommonBusinessActionType.RECEPTION_CHANGE_CHECK_MODAL,
                        data: {
                            name: name,
                            data: response instanceof HttpStatusError ? response.errors.data : response.result,
                            requestParams: params
                        }
                    });
                }
            }
        );
    }

    public receptionCheckChangeApi(params: ReceptionLossCorruptionCheckRequest) {
        this.httpService.post(API_URL.RECEPTION_LOSS_CORRUPTION_CHECK, params, undefined, undefined, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.RECEPTION_LOSS_CORRUPTION_CHECK, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: CommonBusinessActionType.RECEPTION_LOSS_CORRUPTION_CHECK,
                        data: {
                            data: response instanceof HttpStatusError ? response.errors.data : response.result,
                        }
                    });
                }
            }
        );
    }

    /**
     * 取引有無照会APIを実行する
     * @param params 取引有無照会パラメータ
     */
    public tradingPresenceInquiryApi(param: TradingPresenceInquiryRequest) {
        this.httpService.post(API_URL.TRADING_PRESENCE_INQUIRY, param, undefined, SpinnerType.SHOW, true).subscribe(
            (response) => {
                if (response.status === HttpStatus.SYSTEM_ERROR) {
                    this.ngZone.runTask(() => {
                        throw new HttpStatusError(API_URL.TRADING_PRESENCE_INQUIRY, response.status, response.errors);
                    });
                } else {
                    this.dispatcher.dispatch({
                        actionType: CommonBusinessActionType.TRADING_PRESENCE_INQUIRY,
                        data: {
                            data: response instanceof HttpStatusError ? response.errors.data : response.result
                        }
                    });
                }
            }
        );
    }

    /**
     * 内部API：住所コード取得
     * @param params
     */
    public getAddressCode(params: any) {
        this.httpService.get(API_URL.GET_ADDRESS_CODE, { params: params }).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CommonBusinessActionType.SET_ADDRESS_CODE,
                data: response.result
            });
        });
    }

    /**
     * 内部API: 保有通帳・カード・印鑑情報照会
     * @param params
     */
    public getMediumInfo(params: any) {
        this.httpService.post(API_URL.MEDIUM_INFO_INQUIRY, params, null, SpinnerType.SHOW).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CommonBusinessActionType.SET_MEDIUM_INFO,
                data: response.result
            });
        });
    }

    /**
     * BC受付可否チェックAPI
     * @param {*} params
     */
    public bankCardApplyCheck(params: any) {
        this.httpService.post(API_URL.BC_APPLY_CHECK, params, undefined, undefined, true).subscribe(
            (response) => {
                this.dispatcher.dispatch({
                    actionType: CommonBusinessActionType.BC_APPLY_CHECK,
                    data: {
                        data: response instanceof HttpStatusError ? response.errors.data : response.result,
                    }
                });
            }
        );
    }
    /**
     * 受付可否チェック結果をクリアする
     */
    public clearReceptionCheckResult() {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.CLEAR_RECEPTION_CHECK_RESULT,
        });
    }

    /**
     * 同一名義人照会
     * @param params 同一名義人照会用パラメータ
     * @param component 遷移先コンポーネント
     */
    public getSameHolderInquiry(params: any) {
        this.httpService.post('/core-banking/same-holder/inquiry', params).subscribe((response) => {
            this.dispatcher.dispatch({
                actionType: CommonBusinessActionType.GET_SAME_HOLDER_INQUIRY,
                data: { result: response.result }
            });
        });
    }

    /**
     * 前のチャットに戻る
     *
     * @param {string} nextChatName
     * @param {*} [options=null]
     * @memberof CommonBusinessAction
     */
    public chatFlowReturn(nextChatName: string, options: any = null) {
        this.dispatcher.dispatch({
            actionType: CommonBusinessActionType.CHAT_FLOW_RETURN,
            data: {
                name: nextChatName,
                options: options
            }
        });
    }
}
