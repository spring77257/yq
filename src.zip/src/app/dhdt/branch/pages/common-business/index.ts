export { CommonBusinessType } from 'dhdt/branch/pages/common-business/manager/common-business.manager';

// export modify services
export * from 'dhdt/branch/pages/common-business/business/w9/service/w9-modify.service';
export * from 'dhdt/branch/pages/common-business/business/fatca/service/fatca-modify.service';
export * from 'dhdt/branch/pages/common-business/business/crs/service/crs-modify.service';
