export class JudgeResultStatus {
    public static readonly RESULT_01 = '01';
    public static readonly RESULT_02 = '02';
    public static readonly RESULT_03 = '03';
    public static readonly RESULT_04 = '04';
    public static readonly RESULT_0 = '0';
    public static readonly RESULT_1 = '1';
}

// 画面遷移
export class ScreenTransition {
    // TOPに戻る
    public static readonly BACK_TO_TOP = 'top';
    public static readonly COMPLETE = 'complete';
    public static readonly CLERK_CONFIRM_COMPLETE = 'clerkConfirmComplete';
    // 「次へ」ボタン
    public static readonly NEXT_TO_COMPLETE = 'nextToComplete';
}

// 業務コード
export class BussinessCode {
    // 普通預金口座開設（日本人）（名寄せ時）
    public static readonly DUPLICATE_ACCOUNT_JAPAN = '28';
    // 普通預金口座開設（外国人）（名寄せ時）
    public static readonly DUPLICATE_ACCOUNT_FOREIGNER = '17';
}
