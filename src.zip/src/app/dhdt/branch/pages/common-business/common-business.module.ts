import { NgModule } from '@angular/core';
import { CommonBusinessAction } from 'dhdt/branch/pages/common-business/action/common-business.action';
import { CRSModifyModule } from 'dhdt/branch/pages/common-business/business/crs/crs-modify.module';
import { CRSModifyService } from 'dhdt/branch/pages/common-business/business/crs/service/crs-modify.service';
import {
    ExistingAccountInputHandler, ExistingAccountRenderer
} from 'dhdt/branch/pages/common-business/business/existing-account';
import { FATCAModifyModule } from 'dhdt/branch/pages/common-business/business/fatca/fatca-modify.module';
import { FATCAModifyService } from 'dhdt/branch/pages/common-business/business/fatca/service/fatca-modify.service';
import {
    InheritAncestorDuplicateAccountHandler, InheritAncestorDuplicateAccountRenderer
} from 'dhdt/branch/pages/common-business/business/inherit/index';
import { OpenStoretInputHandler, OpenStoretRenderer } from 'dhdt/branch/pages/common-business/business/open-store';
import { PassbookModifyModule } from 'dhdt/branch/pages/common-business/business/passbook/passbook-modify.module';
import { W9ModifyService } from 'dhdt/branch/pages/common-business/business/w9/service/w9-modify.service';
import { W9ModifyModule } from 'dhdt/branch/pages/common-business/business/w9/w9-modify.module';
import { CommonBusinessStore } from 'dhdt/branch/pages/common-business/store/common-business.store';
import { CommonBusinessChatComponent } from 'dhdt/branch/pages/common-business/view/common-business-chat.component';
import { AccountShopModule } from 'dhdt/branch/shared/components/account-shop/account-shop.module';
import { BranchListModule } from 'dhdt/branch/shared/components/branch-list/branch-list.module';
import { SharedModule } from 'dhdt/branch/shared/shared.module';
import { IonicModule } from 'ionic-angular/module';
import { BcApplyModifyModule } from './business/bcapply/bcapply-modify.module';
import { ReceptionClerkConfirmModule } from './business/receptionClerkConfirm/reception-clerk-confirm.module';
import { ReImgModule } from './business/reimg/re-img.module';

@NgModule({
    imports: [
        IonicModule,
        SharedModule,
        AccountShopModule,
        W9ModifyModule,
        FATCAModifyModule,
        CRSModifyModule,
        PassbookModifyModule,
        ReImgModule,
        BranchListModule,
        BcApplyModifyModule,
        ReceptionClerkConfirmModule
    ],
    entryComponents: [
        CommonBusinessChatComponent
    ],
    declarations: [
        CommonBusinessChatComponent
    ],
    providers: [
        CommonBusinessAction,
        CommonBusinessStore,
        ExistingAccountRenderer,
        ExistingAccountInputHandler,
        OpenStoretRenderer,
        OpenStoretInputHandler,
        W9ModifyService,
        FATCAModifyService,
        CRSModifyService,
        InheritAncestorDuplicateAccountRenderer,
        InheritAncestorDuplicateAccountHandler,
    ]
})
export class CommonBusinessModule {
}
