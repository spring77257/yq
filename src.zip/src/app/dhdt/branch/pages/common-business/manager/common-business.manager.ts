import { ChatFlowQuestionTypes } from 'dhdt/branch/shared/modules/chat-flow/chat-flow-question-types';

export class CommonBusinessRendererManager {

    private static renderers = new Map();

    public static register(renderer: {
        name: string;
        type: CommonBusinessType;
        index?: number;
    }) {
        const stack = this.renderers.get(renderer.type) || new Map();
        stack.set(renderer.index || 0, renderer.name);
        this.renderers.set(renderer.type, stack);
    }

    public static dequeue(type: CommonBusinessType, index?: number) {
        const stack = this.renderers.get(type);
        if (stack) {
            return stack.get(index || 0);
        }
        throw Error('Could not find a renderer associated');
    }
}

export function CommonBusinessRenderer(renderer: {
    name: string;
    type: CommonBusinessType;
    index?: number;
}) {
    return (target) => {
        CommonBusinessRendererManager.register(renderer);
    };
}

export enum CommonBusinessType {
    ExistingAccount,    // 重複口座
    OpenStore,          // 口座開設店舗
    W9,
    FATCA,
    CRS,
    InheritAncestorDuplicateAccount, // 死亡者重複口座照会
    PassBook, // 通帳
    ReImg, // 写真再撮影
    BcApply, // BCの申し込む
    ReceptionClerkConfirm, // 受付行員確認
}

export class CommonBusinessRendererType extends ChatFlowQuestionTypes {
    public static readonly EXISTING_ACCOUNT = 'existingAccount';
    public static readonly SELECT_BRANCH = 'selectbranch';
    public static readonly PHYSICS_PICKER = 'categoryNamePhysicsPicker';
    public static readonly LOGIC_PICKER = 'categoryNameLogicPicker';
    public static readonly SIGN = 'sign';
    public static readonly DUPLICATE_ACCOUNT_INFO = 'duplicateAccountInfo';
    public static readonly NAME_AGGREGATION = 'nameAggregation';
    public static readonly BRANCH_LIST = 'branchlist';
    public static readonly CHANGE_ITEM_LIST = 'changeItemList';
}
