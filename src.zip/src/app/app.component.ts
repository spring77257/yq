import { AfterViewInit, Component, OnDestroy } from '@angular/core';
import { LabelService } from 'adep/services';
import { DeviceService } from 'dhd/common/services/device.service';
import { LoginComponent } from 'dhdt/branch/pages/common/login/view/login.component';
import { ModalService } from 'dhdt/branch/shared/services/modal.service';
import { MorphologyService } from 'dhdt/branch/shared/services/morphology.service';
import { Platform } from 'ionic-angular';

@Component({
    templateUrl: 'app.component.html'
})
export class AppComponent implements AfterViewInit, OnDestroy {
    public rootPage: any = LoginComponent;
    private observer: MutationObserver;

    constructor(
        platform: Platform, deviceService: DeviceService, morphologyService: MorphologyService,
        modalService: ModalService, labelService: LabelService) {
        platform.ready().then(() => {
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.
            deviceService.init();
            morphologyService.init(modalService, labelService);
        });
    }

    public ngAfterViewInit() {
        this.observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                const contents = document.querySelector('ion-nav').getElementsByClassName('scroll-content');
                // チャットが進む途中に左側のチャットバブルが一瞬消えたりすることを対応（一旦対応）
                // tslint:disable-next-line:prefer-for-of
                // for (let index = 0; index < contents.length; index++) {
                //     const element = contents[index] as HTMLElement;
                //     element.style.overflowY = mutation.addedNodes.length > 0 ? 'hidden' : 'auto';
                // }
            });
        });
        this.observer.observe(document.querySelector('ion-app'), {childList: true});
    }

    public ngOnDestroy() {
        this.observer.takeRecords();
    }
}
